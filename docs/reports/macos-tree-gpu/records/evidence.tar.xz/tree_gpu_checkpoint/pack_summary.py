from pathlib import Path
import json,statistics,math,hashlib
p=Path('/private/tmp/vellum-macos-tree-gpu')
def pct(s,p):return sorted(s)[math.ceil(len(s)*p)-1]
c=json.loads((p/'packed-campaign.json').read_text());assert c['result']=='PASS_NATIVE_PACKED_PROCESSES'and len(c['records'])==20
runs=[];layouts={}
for rec in c['records']:
 assert rec['exit_code']==0 and not rec['error']and rec['source_prepared_stable']and rec['overlay_stable']
 f=p/(rec['name']+'.stdout');assert hashlib.sha256(f.read_bytes()).hexdigest()==rec['stdout_sha256']
 data=[json.loads(x)for x in f.read_text().splitlines()]
 event=lambda name:[x for x in data if x['event']==name]
 for name in ['tree.perf.setup','tree.perf.geometry','tree.perf.first-scroll','tree.perf.ready','tree.perf.finished']:assert len(event(name))==1
 setup=event('tree.perf.setup')[0];initial=event('tree.perf.geometry')[0]['initial'];ready=event('tree.perf.ready')[0];end=event('tree.perf.finished')[0];rows=event('tree.perf.sample')
 assert setup['nodes']==100000 and setup['deep']==rec['deep']and setup['target_p95_ns']==4000000 and ready['warmup']==128 and len(rows)==240 and end['frame_tickets']==370
 offset=initial['Viewport']['ScrollY'];values=[]
 for i,x in enumerate(rows):
  g=x['geometry'];f=x['frame'];phase=i%32;offset+=12 if phase<16 else-12
  assert x['index']==i and x['phase']==phase and f['Tag']==131+i and f['Generation']==initial['Generation']+131+i and f['Completed']and not f['Failure']and x['tree_notifications']==1
  assert f['TotalUIWorkNS']==sum(f[k]for k in ['InputNS','OwnerNS','ReconcileNS','LayoutPaintNS','GatherNS','RasterUploadNS','EncodeSubmitNS'])
  assert g['Viewport']['ScrollY']==offset and 64<=g['ClippedRows']<=500 and g['RetainedRows']<=500 and g['MaterializedRows']<=500
  shape={k:g[k]for k in ['Scale','Bounds','ClippedRows','RetainedRows','MaterializedRows','LayoutSHA256']};shape.update({k:g['Viewport'][k]for k in ['Width','Height']});key=(rec['deep'],phase)
  if key in layouts:assert layouts[key]==shape,(rec['name'],i)
  else:layouts[key]=shape
  values.append(f['TotalUIWorkNS'])
 runs.append({k:rec[k]for k in ['name','build','deep','repeat']}|{'samples':len(rows),'p95_ns':pct(values,.95),'p99_ns':pct(values,.99),'mean_ns':statistics.mean(values),'max_ns':max(values),'mallocs_mean':statistics.mean(x['mallocs']for x in rows),'allocation_bytes_mean':statistics.mean(x['allocation_bytes']for x in rows),'target_p95_pass':pct(values,.95)<=4000000})
cases=[]
for deep in [False,True]:
 d={'deep':deep,'builds':{}}
 for build in ['baseline','packed']:
  rs=[r for r in runs if r['deep']==deep and r['build']==build];assert len(rs)==5
  d['builds'][build]={'p95_ms_mean_of_runs':statistics.mean(r['p95_ns']for r in rs)/1e6,'p99_ms_mean_of_runs':statistics.mean(r['p99_ns']for r in rs)/1e6,'mean_ms_mean_of_runs':statistics.mean(r['mean_ns']for r in rs)/1e6,'mallocs_mean':statistics.mean(r['mallocs_mean']for r in rs),'allocation_bytes_mean':statistics.mean(r['allocation_bytes_mean']for r in rs),'target_passes':sum(r['target_p95_pass']for r in rs)}
 for key in ['p95_ms_mean_of_runs','mallocs_mean','allocation_bytes_mean']:
  d[key+'_change_percent']=(d['builds']['packed'][key]/d['builds']['baseline'][key]-1)*100
 cases.append(d)
s={'result':'VALIDATED_PACKED_GPU_TREE_COMPARISON','processes':20,'samples':4800,'cases':cases,'runs':runs,'identical_phase_geometry':True,'full_p6_qualified':False,'gpu_default_changed':False,'physical_gpu_execution_qualified':False}
(p/'packed-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({'result':s['result'],'cases':cases},indent=2))
