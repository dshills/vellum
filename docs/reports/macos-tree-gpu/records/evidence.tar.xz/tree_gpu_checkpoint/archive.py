from pathlib import Path
import json,hashlib,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-tree-gpu');dest=r/'docs/reports/macos-tree-gpu/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text());assert process['exit_code']==0 and not process['error']and process['source_index_stable']and review['coverage']['complete']and review['coverage']['files']==10 and not review['findings']
sources=json.loads((p/'checkpoint-source.json').read_text())['sources'];assert all(sha(r/n)==h for n,h in sources.items())
inputs={}
allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.pprof','.md'}
for f in sorted(p.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['tree_gpu_checkpoint/'+f.relative_to(p).as_posix()]=f
for n,h in sources.items():inputs['reviewed_source/'+n]=r/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()}
archive=dest/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:
  assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(dest/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Native/profile/source-routing investigation, rejected compaction overlays and negative regression,20process4800sample comparison, final five-mode600sample preflights,4nativeCLIrefusals, source/internal/Prism reviews. Raw failures and unused adoption helper retained. Native binaries excluded; hashes in receipts.'},indent=2)+'\n')
final=json.loads((p/'final-summary.json').read_text());comparison=json.loads((p/'packed-summary.json').read_text());baseline=json.loads((p/'baseline.json').read_text());after=json.loads((p/'final-baseline.json').read_text());assert baseline['prepared']==after['prepared']and len(after['prepared'])==6204
q={'result':'REVIEWED_TREE_RENDERER_MODES_AND_REJECTED_COMPACTION','base_commit':baseline['commit'],'sources':sources,'internal_review':'APPROVED_SOURCE; shipping modes and rejected prototype separately reviewed; no findings','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':0,'prism_coverage_complete':True,'prism_files':10,'prism_findings':0,'comparison_processes':20,'comparison_samples':4800,'final_preflight_processes':5,'final_preflight_samples':600,'final_ordinary_samples':360,'final_source_diagnostic_samples':240,'cli_refusals':4,'prepared_files':6204,'prepared_changed':False,'production_renderer_changed':False,'prototype_adopted':False,'gpu_default_changed':False,'all_compaction_target_runs_failed':all(not run['target_p95_pass']for run in comparison['runs']if run['build']=='packed'),'full_p6_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(dest/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
