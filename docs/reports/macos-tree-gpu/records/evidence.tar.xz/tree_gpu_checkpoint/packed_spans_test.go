// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package sceneplan

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"testing"
)

func spanPackFixture() *Builder {
	b := New(image.Rect(0, 0, 48, 64))
	b.BeginSpans(color.RGBA{13, 37, 79, 129}, draw.Over)
	// Deliberately leave holes and preserve overlapping order within each row.
	for y := 4; y < 52; y++ {
		if y%5 == 0 {
			continue
		}
		b.Span(y, 0, 33, 257)
		b.Span(y, 7, 41, 32768)
		b.Span(y, 11, 48, 65535)
	}
	return b
}

// Compaction is the only measured work: rebuild staging after each flush
// outside the allocation counters so per-row allocation cannot hide there.
func TestVellumScenePlanSpanCompactionAllocations(t *testing.T) {
	b := spanPackFixture()
	allocations := testing.AllocsPerRun(20, func() {
		testingBuilder := *b
		// flush replaces row storage without mutating the staged source rows.
		testingBuilder.flush()
		if testingBuilder.failed || testingBuilder.count != 1 {
			panic("valid stream refused")
		}
	})
	if allocations > 8 {
		t.Fatalf("span compaction allocated %.0f objects for one stream; want <=8", allocations)
	}
}

func TestVellumScenePlanPackedSpansDetachedAndBounded(t *testing.T) {
	b := spanPackFixture()
	staged := b.stream.rows
	p := b.Seal(false)
	if p == nil || len(p.ops) != 1 {
		t.Fatal("valid stream refused")
	}
	e, ok := p.Encode()
	if !ok {
		t.Fatal("encode refused")
	}
	expected := image.NewRGBA(p.Bounds())
	for i := range expected.Pix {
		expected.Pix[i] = byte(i*29 + 7)
	}
	if !p.Replay(expected) {
		t.Fatal("replay refused")
	}
	for _, row := range p.ops[0].rows {
		if cap(row) != len(row) {
			t.Fatal("row retains capacity outside its own spans")
		}
	}
	// Staging may be reused/mutated after sealing. The packet remains immutable.
	for _, row := range staged {
		clear(row)
	}
	next := New(p.Bounds())
	next.BeginSpans(color.RGBA{A: 255}, draw.Src)
	next.Span(20, 0, 48, 65535)
	if next.Seal(false) == nil {
		t.Fatal("subsequent stream refused")
	}
	after, ok := p.Encode()
	if !ok || !bytes.Equal(e.Ops, after.Ops) || !bytes.Equal(e.Rows, after.Rows) || !bytes.Equal(e.Refs, after.Refs) || !bytes.Equal(e.Data, after.Data) {
		t.Fatal("sealed packet aliases retired/reused construction rows")
	}
	got := image.NewRGBA(p.Bounds())
	for i := range got.Pix {
		got.Pix[i] = byte(i*29 + 7)
	}
	if !p.Replay(got) || !bytes.Equal(expected.Pix, got.Pix) {
		t.Fatal("later construction changed packet pixels")
	}
}
