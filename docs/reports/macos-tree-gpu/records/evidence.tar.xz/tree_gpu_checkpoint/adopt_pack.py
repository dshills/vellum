from pathlib import Path
import json,hashlib,difflib,subprocess
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-tree-gpu');dest=r/'drivers/cogent/native/patches/spanpacking'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r).strip()
s=json.loads((p/'packed-summary.json').read_text());assert s['result']=='VALIDATED_PACKED_GPU_TREE_COMPARISON'and s['processes']==20 and s['samples']==4800
assert all(c['mallocs_mean_change_percent']<-10 for c in s['cases'])
# Adoption is for deterministic allocation-object reduction. Timing and bytes
# remain distinct measures and are reported without changed acceptance targets.
files={'paint/renderers/sceneplan/builder.go':p/'packed-builder.go','paint/renderers/sceneplan/packed_spans_test.go':p/'packed_spans_test.go'}
subprocess.run(['gofmt','-w',*[str(v)for v in files.values()]],check=True)
# gofmt cannot change the previously compared production source semantically;
# preserve both original overlay bytes and the exact prepared output separately.
original={};output={};diff=[]
for rel,f in files.items():
 old=r/'drivers/cogent/build/upstream'/rel;before=old.read_text()if old.exists()else'';after=f.read_text()
 original[rel]=hashlib.sha256(old.read_bytes()).hexdigest()if old.exists()else None
 output[rel]=hashlib.sha256(f.read_bytes()).hexdigest()
 diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if old.exists()else'/dev/null',tofile='b/'+rel))
dest.mkdir(exist_ok=False);patch=dest/'0056-pack-sealed-span-rows.patch';patch.write_text(''.join(diff))
for name,value in [('original-hashes.json',original),('output-hashes.json',output)]: (dest/name).write_text(json.dumps(value,indent=2)+'\n')
manifest=r/'drivers/cogent/native/dependencies.json';d=json.loads(manifest.read_text());stages=d['dependencies'][0]['stages'];assert stages[-1]['patches'][-1]['file'].endswith('0055-passive-local-text-layout.patch')
stages.append({'origin':'drivers/cogent/native/patches/spanpacking','inputs':'native/patches/spanpacking/original-hashes.json','outputs':'native/patches/spanpacking/output-hashes.json','patches':[{'file':'native/patches/spanpacking/'+patch.name,'sha256':hashlib.sha256(patch.read_bytes()).hexdigest()}]});manifest.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'stage':56,'files':output,'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest()}))
