from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-tree-gpu')
for name in ['main.go','perf.go','perf_test.go']:(p/('before-'+name)).write_bytes((r/'examples/loadedtree'/name).read_bytes())
f=r/'examples/loadedtree/perf.go';s=f.read_text();s=s.replace('Deep                   bool','Deep                   bool\n GPUSceneRendering, SourceDetails bool',1);needle='\treturn nil\n}\nfunc treePerfDelta';assert needle in s;s=s.replace(needle,'\tif c.SourceDetails && c.Warmup+c.Samples+2 > cogent.MaxSourceFrameMetricsCapacity {\n\t\treturn errors.New("loadedtree perf: source diagnostics exceed bounded recorder capacity")\n\t}\n'+needle,1)
s=s.replace('func treePerfEmit(event string, value map[string]any) error {\n\tvalue["event"] = event','func (c treePerfConfig) record(event string, value map[string]any) map[string]any {\n value["event"] = event\n value["gpu_scene_rendering"] = c.GPUSceneRendering\n value["source_details"] = c.SourceDetails\n return value\n}\nfunc (c treePerfConfig) emit(event string, value map[string]any) error {\n value = c.record(event, value)',1).replace('treePerfEmit(', 'c.emit(')
s=s.replace('metrics, err := cogent.NewFrameMetrics(c.Warmup + c.Samples + 2)','newMetrics := cogent.NewFrameMetrics\n if c.SourceDetails {\n  newMetrics = cogent.NewFrameMetricsWithSourceDetails\n }\n metrics, err := newMetrics(c.Warmup + c.Samples + 2)',1).replace('driver := cogent.Driver{FrameMetrics: metrics,','driver := cogent.Driver{GPUSceneRendering: c.GPUSceneRendering, FrameMetrics: metrics,',1);f.write_text(s)
f=r/'examples/loadedtree/main.go';s=f.read_text();s=s.replace('\tflag.Parse()','\tgpuScene := flag.Bool("perf-gpu-scene", false, "opt into GPU scene rendering for this performance run")\n\tsourceDetails := flag.Bool("perf-source-details", false, "additional diagnostic source clocks/counters; exclude from ordinary timing")\n\tflag.Parse()',1).replace('(*deep || *samples != 240 || *warmup != 128)','(*deep || *gpuScene || *sourceDetails || *samples != 240 || *warmup != 128)',1).replace('Deep: *deep}', 'Deep: *deep, GPUSceneRendering: *gpuScene, SourceDetails: *sourceDetails}',1);f.write_text(s)
f=r/'examples/loadedtree/perf_test.go';s=f.read_text().replace('treePerfConfig{nodes, 240, 128, deep}','treePerfConfig{Nodes: nodes, Samples: 240, Warmup: 128, Deep: deep}',1)
for n,samples,warm in [(1000,240,128),(10000,119,128),(10000,2049,128),(10000,240,31),(10000,240,33),(10000,240,2049)]:s=s.replace('{'+f'{n}, {samples}, {warm}, false'+'}', '{'+f'Nodes: {n}, Samples: {samples}, Warmup: {warm}'+'}',1)
s+='''
func TestTreePerfModesAndSourceCapacity(t *testing.T) {
 for _, gpu := range []bool{false, true} {
  for _, detailed := range []bool{false, true} {
   c := treePerfConfig{Nodes: 100000, Samples: 2048, Warmup: 128, GPUSceneRendering: gpu, SourceDetails: detailed}
   if err := c.validate(); err != nil { t.Fatal(err) }
   value := c.record("tree.perf.sample", map[string]any{"gpu_scene_rendering": !gpu, "source_details": !detailed, "event": "incorrect"})
   if value["event"] != "tree.perf.sample" || value["gpu_scene_rendering"] != gpu || value["source_details"] != detailed { t.Fatal("run mode was omitted or overridden", value) }
  }
 }
 // Ordinary recorders have a larger capacity. Detailed mode must refuse the
 // same workload before construction/mount rather than silently shrink it.
 c := treePerfConfig{Nodes: 100000, Samples: 2048, Warmup: 2048}
 if err := c.validate(); err != nil { t.Fatal(err) }
 c.SourceDetails = true
 if c.validate() == nil { t.Fatal("oversized diagnostic recorder admitted") }
 c.Samples = cogent.MaxSourceFrameMetricsCapacity - c.Warmup - 2
 if err := c.validate(); err != nil { t.Fatal("exact diagnostic capacity refused", err) }
 c.Samples++
 if c.validate() == nil { t.Fatal("capacity overflow admitted") }
}
''';f.write_text(s)
