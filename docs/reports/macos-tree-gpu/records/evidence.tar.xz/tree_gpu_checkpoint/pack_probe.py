from pathlib import Path
import json
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-tree-gpu');f=r/'drivers/cogent/build/upstream/paint/renderers/sceneplan/builder.go';s=f.read_text();old='''	exact := make([][]span, len(o.rows))
	for i, row := range o.rows {
		exact[i] = make([]span, len(row))
		copy(exact[i], row)
	}''';new='''	exact := make([][]span, len(o.rows))
	n := 0
	for _, row := range o.rows {
		n += len(row)
	}
	packed := make([]span, n)
	at := 0
	for i, row := range o.rows {
		end := at + len(row)
		exact[i] = packed[at:end:end]
		copy(exact[i], row)
		at = end
	}''';assert old in s;s=s.replace(old,new,1);o=p/'packed-builder.go';o.write_text(s);(p/'gpu-packed-overlay.json').write_text(json.dumps({'Replace':{str(f):str(o),str(r/'examples/loadedtree/perf.go'):str(p/'gpu-ordinary.go')}},indent=2)+'\n')
