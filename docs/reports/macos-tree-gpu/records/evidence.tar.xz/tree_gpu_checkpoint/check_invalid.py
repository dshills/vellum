from pathlib import Path
import hashlib,json,sys,datetime,time
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-tree-gpu');sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
binary=p/'loadedtree-final';h=hashlib.sha256(binary.read_bytes()).hexdigest();checks=[]
for name,args in [('gpu-requires-perf',['-perf-gpu-scene']),('details-requires-perf',['-perf-source-details']),('smoke-excludes-perf',['-perf','-smoke','-perf-gpu-scene']),('capacity-refused',['-perf','-perf-source-details','-perf-warmup=2048','-perf-samples=2048'])]:
 argv=[str(binary),*args];start=time.monotonic();out=run_child(argv,cwd=r/'examples/loadedtree',env=child_environment(),capture_output=True,timeout=5);(p/('invalid-'+name+'.stdout')).write_bytes(out.stdout);(p/('invalid-'+name+'.stderr')).write_bytes(out.stderr)
 assert out.returncode==1 and not out.stdout,(name,out.returncode,out.stdout)
 message=b'perf flags require -perf and exclude -smoke'if name!='capacity-refused'else b'source diagnostics exceed bounded recorder capacity'
 assert message in out.stderr,(name,out.stderr)
 checks.append({'name':name,'argv':argv,'exit_code':out.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(out.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(out.stderr).hexdigest()})
assert hashlib.sha256(binary.read_bytes()).hexdigest()==h
(p/'invalid-cli.json').write_text(json.dumps({'result':'PASS_EARLY_CLI_REFUSALS','executable_sha256':h,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks},indent=2)+'\n');print('PASS_EARLY_CLI_REFUSALS',len(checks))
