# GPU scanline span compaction

The optional scene renderer now seals all spans in one stream into one exact
contiguous allocation. Each relative row has a full-slice capacity fence, so an
append cannot overwrite the next row. This removes the separate exact allocation
for every nonempty row while preserving detached packet ownership, span order,
byte accounting, encoding, GPU commands, fallback and public APIs.

The source change is only sceneplan.Builder.flush. Existing per-stream staging
still charges spans and row headers before allocation; compaction occurs only
after the existing byte/operation admission succeeds. The exact count is bounded
by already admitted span bytes. No allocator pool, borrowed source, global cache,
GPU handle, thread or caller callback is introduced. The default renderer remains
the CPU renderer.

The sceneplan reference corpus compares detached bytes and encoded Ops/Rows/Refs/
Data with the independent prior full-target builder, and replay pixels with the
reference scanner, including both blend operators, overlapping spans, gaps,
arrival order, target limits and zero coverage. The added compaction regression
isolates flush allocation count and checks staged-row mutation cannot affect
sealed bytes/pixels. The original implementation must fail the allocation test.

The tree route investigation preceding this patch includes separate diagnostic
source-timing and CPU-profile runs. CPU source diagnostics report a full 3072×1152
scene and 14,155,776 logical RGBA upload bytes per scroll. A separate temporary
counter confirms one SetFromGoImage attempt in each of 120 observed intervals;
it does not support a duplicate-upload explanation. GPU source diagnostics report
no CPU raster/copy availability and zero image API upload attempts on all 120
frames. These additional clocks, counters and profiles are excluded from ordinary
latency comparisons. Sampled Go CPU stacks attribute substantial samples to cgo,
which does not isolate native CPU work, physical GPU execution or presentation.

Ordinary native comparison will be summarized here after independent validation.
Both artifacts use the optional GPU scene renderer and identical consumer bytes;
only flush differs. Five runs per build/view alternate build order for wide and
deep sealed 100k-node trees, each with 128 guarded warmups and 240 measured native
scrolls. At least 64 clipped rows are required; source/binary/overlay and prepared
endpoint hashes are recorded, and complete phase geometry must match.

The original 4 ms tree target and default CPU mode remain unchanged. This scoped
allocation optimization does not close full tree interaction/cold-cache/maximum
rows, complete P6/P11, physical GPU or native memory, overnight soak, human
accessibility or Mac distribution qualification.
