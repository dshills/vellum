from pathlib import Path
import datetime,hashlib,json,sys,time
p=Path('/private/tmp/vellum-macos-tree-gpu');sys.path.insert(0,str(p));import run
sys.path.insert(0,str(run.ROOT/'scripts'));from child_process import run_child
from sdk_environment import child_environment
before=run.baseline();auth=p/'testing-authorization.json';assert json.loads(auth.read_text())['live_window_input_performance_tests_allowed']
exe={'baseline':p/'loadedtree-gpu','packed':p/'loadedtree-gpu-packed'}
overlay={name:json.loads((p/('gpu-ordinary-overlay.json'if name=='baseline'else'gpu-packed-overlay.json')).read_text())for name in exe}
inputs={str(path):run.sha(path)for spec in overlay.values()for path in spec['Replace'].values()}
(p/'packed-campaign-inputs.json').write_text(json.dumps({'source_commit':before['commit'],'overlays':overlay,'targets':inputs,'executables':{k:run.sha(v)for k,v in exe.items()}},indent=2)+'\n')
env={**child_environment(runtime=True),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
records=[];result='FAILED';began=time.monotonic()
try:
 for repeat in range(5):
  for deep in [False,True]:
   for build in (['baseline','packed']if repeat%2==0 else['packed','baseline']):
    name=f'pack-{build}-'+('deep'if deep else'wide')+f'-r{repeat+1}'
    argv=[str(exe[build]),'-perf','-nodes=100000','-perf-samples=240','-perf-warmup=128']+(['-perf-deep']if deep else[])
    rec={'name':name,'build':build,'nodes':100000,'deep':deep,'repeat':repeat+1,'argv':argv,'source_commit':before['commit'],'baseline_sha256':run.sha(p/'baseline.json'),'authorization_sha256':run.sha(auth),'producer_sha256':run.sha(__file__),'executable_sha256':run.sha(exe[build]),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':None,'error':None};start=time.monotonic()
    try:
     with(p/(name+'.stdout')).open('xb')as out,(p/(name+'.stderr')).open('xb')as err:rec['exit_code']=run_child(argv,cwd=run.ROOT/'examples/loadedtree',env=env,stdout=out,stderr=err,timeout=300).returncode
    except BaseException as e:rec['error']={'type':type(e).__name__,'message':str(e)}
    rec['elapsed_seconds']=time.monotonic()-start;rec['source_prepared_stable']=run.identity()==before;rec['overlay_stable']=all(run.sha(k)==v for k,v in inputs.items())
    for channel in ['stdout','stderr']:rec[channel+'_sha256']=run.sha(p/(name+'.'+channel))
    (p/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');records.append(rec);print(json.dumps({k:rec[k]for k in ['name','exit_code','error','elapsed_seconds','source_prepared_stable','overlay_stable']}),flush=True)
    assert rec['exit_code']==0 and not rec['error']and rec['source_prepared_stable']and rec['overlay_stable'],name
 result='PASS_NATIVE_PACKED_PROCESSES'
finally:
 (p/'packed-campaign.json').write_text(json.dumps({'result':result,'records':records,'elapsed_seconds':time.monotonic()-began},indent=2)+'\n')
print(result,len(records),flush=True)
