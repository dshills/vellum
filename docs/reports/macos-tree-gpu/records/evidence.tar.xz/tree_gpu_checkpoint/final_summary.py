from pathlib import Path
import json,hashlib,statistics,math,importlib.util,sys
p=Path('/private/tmp/vellum-macos-tree-gpu');r=Path('/private/tmp/vellum-large-data');sys.path.insert(0,str(r/'scripts'))
spec=importlib.util.spec_from_file_location('benchmark_grid',r/'scripts/benchmark-grid.py');benchmark=importlib.util.module_from_spec(spec);spec.loader.exec_module(benchmark)
fields=['InputNS','OwnerNS','ReconcileNS','LayoutPaintNS','GatherNS','RasterUploadNS','EncodeSubmitNS'];runs=[];shapes={}
for name,gpu,details,deep in [('final-cpu',False,False,False),('final-gpu',True,False,False),('final-cpu-details',False,True,False),('final-gpu-details',True,True,False),('final-gpu-deep',True,False,True)]:
 receipt=json.loads((p/(name+'.json')).read_text());assert receipt['exit_code']==0 and receipt['error']is None and receipt['source_prepared_stable']
 raw=p/(name+'.stdout');assert hashlib.sha256(raw.read_bytes()).hexdigest()==receipt['stdout_sha256']
 records=[json.loads(l)for l in raw.read_text().splitlines()];assert all(x['gpu_scene_rendering']is gpu and x['source_details']is details for x in records)
 expected=['tree.perf.setup','tree.perf.geometry','tree.perf.first-scroll','tree.perf.ready']+['tree.perf.sample']*120+['tree.perf.finished'];assert [x['event']for x in records]==expected
 setup,geom,first,ready=records[:4];end=records[-1];initial=geom['initial'];rows=records[4:-1];assert setup['nodes']==100000 and setup['deep']is deep and ready['warmup']==64 and end['frame_tickets']==186 and end['samples']==120 and end['full_p6_qualified']is False
 offset=initial['Viewport']['ScrollY'];work=[];sources=[]
 for i,x in enumerate(rows):
  f=x['frame'];g=x['geometry'];phase=i%32;offset+=12 if phase<16 else-12
  assert x['index']==i and x['phase']==phase and x['tree_notifications']==1 and f['Tag']==67+i and f['Generation']==initial['Generation']+67+i and f['Completed']and not f['Failure']and f['TotalUIWorkNS']==sum(f[k]for k in fields)
  assert g['Viewport']['ScrollY']==offset and 64<=g['ClippedRows']<=500 and g['RetainedRows']<=500 and g['MaterializedRows']<=500
  shape={k:g[k]for k in ['Scale','Bounds','ClippedRows','RetainedRows','MaterializedRows','LayoutSHA256']};shape.update({k:g['Viewport'][k]for k in ['Width','Height']});key=(deep,phase)
  if key in shapes:assert shapes[key]==shape,(name,i)
  else:shapes[key]=shape
  if details:
   benchmark.validate_source_details(f['SourceDetails'],f['RasterUploadNS']);ds=f['SourceDetails'];assert ds['Compositions']==1 and len(ds['Records'])==1
   src=ds['Records'][0];assert src['Composition']==1 and src['Source']==0 and src['Kind']==1 and src['ImageWidth']==3072 and src['ImageHeight']==1152 and src['ImageChanged']and src['ImageUploadTimingAvailable']
   assert src['RasterAvailable']is(not gpu)and src['CopyAvailable']is(not gpu)and src['SetFromGoImageAttempts']==(0 if gpu else 1)and src['LogicalUploadRGBABytes']==(0 if gpu else 14155776)
   sources.append(src)
  else:assert 'SourceDetails'not in f
  work.append(f['TotalUIWorkNS'])
 row={'name':name,'gpu_scene_rendering':gpu,'source_details':details,'deep':deep,'samples':len(rows),'receipt_sha256':hashlib.sha256((p/(name+'.json')).read_bytes()).hexdigest(),'executable_sha256':receipt['executable_sha256'],'source_prepared_stable':True,'p95_ns':sorted(work)[math.ceil(len(work)*.95)-1],'mean_ns':statistics.mean(work),'ordinary_target_qualified':False}
 if sources:row['diagnostic_source_means']={k:statistics.mean(x[k]for x in sources)for k in ['DrawNS','RasterNS','CopyNS','SetFromGoImageNS','SetFromGoImageAttempts','LogicalUploadRGBABytes']}
 runs.append(row)
code=[]
for name in ['final-consumer-race','final-consumer-vet','final-consumer-build']:
 d=json.loads((p/(name+'.json')).read_text());assert d['exit_code']==0 and not d['error']and d['source_delta_stable']and d['prepared_before']==d['prepared_after']and len(d['prepared_before'])==6204;code.append({'name':name,'exit_code':0,'source_delta_stable':True,'prepared_files':6204})
invalid=json.loads((p/'invalid-cli-v2.json').read_text());assert invalid['result']=='PASS_EARLY_CLI_REFUSALS'and len(invalid['checks'])==4
s={'result':'VALIDATED_TREE_RENDERER_MODE_PREFLIGHTS','processes':5,'samples':600,'ordinary_samples':360,'source_diagnostic_samples':240,'runs':runs,'code_checks':code,'cli_refusals':4,'native_geometry_matched':True,'gpu_mode_is_requested':True,'additional_diagnostic_clocks_excluded_from_ordinary_latency':True,'full_p6_qualified':False,'prepared_renderer_change':False}
(p/'final-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
