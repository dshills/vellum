"""Local Unix transport must work; direct IPv4/IPv6 sockets must be refused."""
import errno
import json
from pathlib import Path
import socket
import tempfile

refused = []
for family, address, label in [(socket.AF_INET, '127.0.0.1', 'ipv4'), (socket.AF_INET6, '::1', 'ipv6')]:
    for kind, operation in [(socket.SOCK_STREAM, 'bind'), (socket.SOCK_STREAM, 'connect'),
                            (socket.SOCK_DGRAM, 'bind'), (socket.SOCK_DGRAM, 'sendto')]:
        sock = None
        try:
            sock = socket.socket(family, kind)
            sock.settimeout(1)
            if operation == 'bind':
                sock.bind((address, 0))
            elif operation == 'connect':
                sock.connect((address, 9))
            else:
                sock.sendto(b'control', (address, 9))
        except OSError as error:
            assert error.errno in [errno.EPERM, errno.EACCES], (label, operation, error.errno)
            refused.append(dict(family=label, operation=operation, type=kind.name, errno=error.errno))
        else:
            raise AssertionError('IP operation unexpectedly allowed')
        finally:
            if sock is not None:
                sock.close()

with tempfile.TemporaryDirectory(prefix='vellum-sdk-unix-', dir='/private/tmp') as temporary:
    path = str(Path(temporary) / 'test.sock')
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as server:
        server.bind(path)
        server.listen(1)
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(path)
            with server.accept()[0] as peer:
                client.sendall(b'control')
                assert peer.recv(7) == b'control'
                peer.sendall(b'ok')
                assert client.recv(2) == b'ok'
print(json.dumps(dict(result='PASS_UNIX_ALLOWED_DIRECT_IP_DENIED', unix_roundtrip=True, refusals=refused)))
