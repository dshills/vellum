"""Bounded offline SDK checks of this implementation; never launch a native app."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
P = Path('/private/tmp/vellum-source-gpu-sdk-a274e8a')
spec = importlib.util.spec_from_file_location('sdk_candidate_owned_guard', W.parent / 'macos-sdk-native-238b3b6/run.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
sha, read, need = g.sha, g.read, g.need
STOP = Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
LIBRARY = Path('/private/tmp/vellum-source-built-gpu-276a654/build-target-v1/aarch64-apple-darwin/release/libwgpu_native.a')
PYTHON = Path('/opt/homebrew/bin/python3').resolve()


def main(phase):
    need(phase in ['unit', 'unit-v2', 'unit-v3', 'package', 'check', 'package-v2', 'check-v2', 'network-probe'], 'fixed check phase')
    P.mkdir(mode=0o700, exist_ok=True)
    for name in ['go-cache', 'temp']:
        (P / name).mkdir(mode=0o700, exist_ok=True)
    need(not (W / (phase + '.json')).exists() and not (P / ('stop-' + phase)).exists(), 'one-shot checks')
    paths = [Path(__file__), W / 'gpu-provenance.json', LIBRARY, PYTHON,
             Path('/opt/homebrew/bin/go'), Path('/opt/homebrew/bin/go').resolve()]
    paths += [p for p in (T / 'scripts').glob('*.py')]
    # Source and prepared bytes are sampled at both owned-process boundaries.
    import subprocess
    names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=T).decode().split('\0')
    paths += [T / name for name in names if name]
    paths += [p for name in ['upstream', 'typesetting'] for p in (T / 'drivers/cogent/build' / name).rglob('*') if p.is_file()]
    pins = {str(p): sha(p) for p in paths}
    stop = lambda: STOP.exists() or (P / ('stop-' + phase)).exists()
    stable = lambda: all(sha(p) == h for p, h in pins.items())
    sdk = P / ('candidate-sdk-v2.tar.gz' if phase in ['package-v2','check-v2'] else 'candidate-sdk.tar.gz')
    profile = '(version 1)(allow default)(deny network* (remote ip) (local ip))' if phase in ['network-probe','check-v2'] else '(version 1)(allow default)(deny network*)'
    prefix = ['/usr/bin/sandbox-exec', '-p', profile, '/usr/bin/env',
              'PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'GOCACHE=' + str(P / 'go-cache'),
              'TMPDIR=' + str(P / 'temp'), 'GOMAXPROCS=2', 'GOWORK=off', 'GOENV=off', 'GOTOOLCHAIN=local', str(PYTHON), '-B']
    if phase.startswith('unit'):
        args = ['-c', "import sys,unittest;sys.path.insert(0,'scripts');unittest.main(module=None,argv=['sdk-checks','native_gpu_test','release-sdk_test','check-sdk_test','native_archive_test','-v'])"]
    elif phase in ['package','package-v2']:
        need(read(W / ('unit-v3.json' if phase == 'package-v2' else 'unit-v2.json'))['error'] is None, 'unit checks complete')
        args = [str(T / 'scripts/release-sdk.py'), '--output', str(sdk), '--include-untracked',
                '--macos-gpu-library', str(LIBRARY), '--macos-gpu-sha256',
                '786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883',
                '--macos-gpu-provenance', str(W / 'gpu-provenance.json')]
    elif phase == 'network-probe':
        args = [str(W / 'network_probe.py')]
        pins[str(W / 'network_probe.py')] = sha(W / 'network_probe.py')
    else:
        need(read(W / ('package-v2.json' if phase == 'check-v2' else 'package.json'))['error'] is None, 'package complete')
        if phase == 'check-v2':
            need(read(W / 'network-probe.json')['result'] == 'PASS_NETWORK-PROBE', 'local-only transport policy probed')
        pins[str(sdk)] = sha(sdk)
        args = [str(T / 'scripts/check-sdk.py'), '--archive', str(sdk), '--sha256', sha(sdk)]
    d = dict(result='INCOMPLETE', inputs=pins, phase=phase, error=None, native_application_started=False)
    try:
        with g.LiveLease() as lease:
            need(lease.held(), 'machine lease')
            run = g.execute(prefix + args, T, P / phase, stop, stable, timeout=900, limit=8 << 20)
            d['run'] = run
            need(run['created'] and run['exit_code'] == 0 and run['error'] is None and
                 not run['observation_errors'] and run['logs_complete'] and run['pins_stable'] and
                 not run['stop_at_exit'] and run['owned']['terminal'] and run['owned']['group_absent'] and
                 not run['owned']['errors'] and lease.held(), 'owned offline SDK check')
            if phase in ['package', 'check', 'package-v2', 'check-v2', 'network-probe']:
                d['record'] = read(P / phase / 'stdout')
            d['result'] = 'PASS_' + phase.upper()
    except BaseException as error:
        d['error'] = dict(type=type(error).__name__, message=str(error))
        d['result'] = 'FAILED_' + phase.upper()
    finally:
        (P / ('stop-' + phase)).touch()
        with (W / (phase + '.json')).open('x') as stream:
            stream.write(json.dumps(d, indent=2) + '\n')
        print(json.dumps({k: v for k, v in d.items() if k not in ['inputs', 'run']}), flush=True)
    need(d['error'] is None, 'offline checks failed')


if __name__ == '__main__':
    need(len(sys.argv) == 2, 'one check phase')
    main(sys.argv[1])
