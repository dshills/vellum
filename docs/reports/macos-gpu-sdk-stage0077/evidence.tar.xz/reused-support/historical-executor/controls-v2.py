"""Actual non-native owned children exercise deadline, stop, logs and cleanup."""
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
from run import W,P,need,execute,validate_record,sha
root=P/'controls-v2';root.mkdir(mode=0o700);results=[]
def case(name, code, *, stopped=lambda:False, timeout=2, limit=1024):
 d=execute([sys.executable,'-c',code],root,root/name,stopped,lambda:True,timeout,limit);results.append(dict(name=name,receipt=d));return d
d=case('success',"print('ok')");need(d['error']is None and d['exit_code']==0 and d['logs_complete']and d['owned']['group_absent'],'successful child')
d=case('pre-stop',"raise Exception('must not launch')",stopped=lambda:True);need(d['error']and not d['owned']['created'],'prelaunch stop')
d=case('timeout','import time;time.sleep(30)',timeout=.15);need(d['error']['type']=='TimeoutError'and d['owned']['terminal']and d['owned']['group_absent'],'timeout cleanup')
d=case('overflow',"import os,time;os.write(1,b'x'*4096);time.sleep(30)");need(d['error']['message']=='log byte bound'and d['logs']['stdout']['bytes']==1024 and d['owned']['group_absent'],'overflow cleanup')
out=root/'mid-stop'
d=case('mid-stop',"import time;time.sleep(30)",stopped=lambda:(out/'owned.json').exists());need(d['error']['message']=='stop requested'and d['owned']['terminal']and d['owned']['group_absent'],'midrun stop cleanup')
d=case('pipe-descendant',"import os,time\nif os.fork()==0:time.sleep(30)",timeout=.2);need(d['error']and d['owned']['terminal']and d['owned']['group_absent'],'descendant group cleanup')
r=dict(event='vellum.native.ready',geometry_persistence_disabled_in_fixture=True,startup_to_verified_gpu_ns=1,heap_alloc_bytes=1,width=1,height=1,render_readback_ns=[1,2,3],go_version='go1.test')
valid=json.dumps(r).encode();need(validate_record(valid)==r,'record accepted');negative=0
for payload in [valid+b'\n'+valid,b'{}',json.dumps({**r,'geometry_persistence_disabled_in_fixture':False}).encode(),json.dumps({**r,'width':True}).encode(),json.dumps({**r,'render_readback_ns':[1,2]}).encode(),json.dumps({**r,'render_readback_ns':[1,2,0]}).encode()]:
 try:validate_record(payload)
 except ValueError:negative+=1
need(negative==6,'parser refuses malformed/duplicate metrics')
d=dict(result='PASS_NON_NATIVE_CONTROLLER_CONTROLS',producer_sha256=sha(__file__),native_runtime_executed=False,controller_cases=6,actual_children=5,parser_negative_controls=negative,runner_sha256=sha(W/'run.py'),results=results)
(W/'controls-v2.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='results'}))
