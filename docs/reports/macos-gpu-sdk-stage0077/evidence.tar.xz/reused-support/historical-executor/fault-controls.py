"""Non-native cleanup failures must preserve ownership and attempt later stages."""
from pathlib import Path
import json,signal,sys
sys.dont_write_bytecode=True
import run as m
root=m.P/'fault-controls';root.mkdir(mode=0o700);results=[]
def execute(name,code,stable=lambda:True):
 d=m.execute([sys.executable,'-c',code],root,root/name,lambda:False,stable,timeout=.2,limit=1024);results.append(dict(name=name,receipt=d));return d
original_killpg=m.os.killpg;original_group=m.terminate_owned_group;original_sha=m.sha
def denied_term(pid,sig):
 if sig==signal.SIGTERM:raise PermissionError('injected TERM failure')
 return original_killpg(pid,sig)
try:
 m.os.killpg=denied_term
 d=execute('term-failure','import time;time.sleep(30)')
 m.need(d['created']and d['owned']['terminal']and d['owned']['group_absent']and [e['stage']for e in d['owned']['errors']]==['graceful-retirement'],'TERM failure still kills/reaps group')
 def denied_group(child):raise PermissionError('injected group-KILL failure')
 m.terminate_owned_group=denied_group
 d=execute('group-fallback','import time;time.sleep(30)')
 m.need(d['created']and d['owned']['terminal']and d['owned']['group_absent']and [e['stage']for e in d['owned']['errors']]==['graceful-retirement','forced-group-retirement'],'both group failures still direct-kill/reap child')
finally:m.os.killpg=original_killpg;m.terminate_owned_group=original_group
counter=[0]
def bad_final_stability():
 counter[0]+=1
 if counter[0]==3:raise OSError('injected final pin observation')
 return True
d=execute('pin-observation',"print('ok')",bad_final_stability)
m.need(d['created']and d['owned']['terminal']and d['owned']['group_absent']and not d['pins_stable']and d['observation_errors'][0]['stage']=='pin-observation','pin failure preserves created/owned result')
try:
 def bad_log_hash(path):
  if Path(path)==root/'log-observation/stdout':raise OSError('injected final log observation')
  return original_sha(path)
 m.sha=bad_log_hash;d=execute('log-observation',"print('ok')")
 m.need(d['created']and d['owned']['terminal']and d['owned']['group_absent']and not d['logs_complete']and d['observation_errors'][0]['stage']=='log-observation','log failure preserves created/owned result')
finally:m.sha=original_sha
# Isolate multiple pipe-close and process-observation failures without signaling a real PID.
class BadPipe:
 def close(self):raise OSError('injected close failure')
class FakeChild:
 pid=99999999;stdout=BadPipe();stderr=BadPipe()
 def poll(self):return 0
 def wait(self,timeout):return 0
saved_absent=m.absent;saved_group=m.terminate_owned_group
try:
 m.terminate_owned_group=lambda child:None
 def bad_absent(pid):raise OSError('injected process observation')
 m.absent=bad_absent;d=m.retire(FakeChild())
 m.need(d['created']and d['terminal']and not d['group_absent']and [e['stage']for e in d['errors']]==['stdout-close','stderr-close','group-observation'],'each failed terminal observation retained')
 results.append(dict(name='terminal-observation-failures',receipt=d))
finally:m.absent=saved_absent;m.terminate_owned_group=saved_group
result=dict(result='PASS_NON_NATIVE_FAULT_CONTROLS',producer_sha256=m.sha(__file__),runner_sha256=m.sha(m.W/'run.py'),native_runtime_executed=False,actual_children=4,isolated_fake_child_controls=1,results=results)
(m.W/'fault-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='results'}))
