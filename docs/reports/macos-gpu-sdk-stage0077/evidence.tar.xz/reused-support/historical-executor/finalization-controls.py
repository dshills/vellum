"""No native launch: final stop and terminal receipt fail independently."""
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
import run as m
root=m.P/'finalization-controls';root.mkdir(mode=0o700);results=[]
for name in ['normal','seal-failure','existing-receipt','existing-run']:(root/name).mkdir()
d=m.finalize(root/'normal',dict(error=None,native_runtime_executed=False));m.need(d['result']=='PASS_SCOPED_PRIVATE_SDK_NATIVE_SMOKE'and not d['finalization_errors']and (root/'normal/stop-live').exists(),'normal finalization');results.append(dict(name='normal',receipt=d))
original_touch=Path.touch
try:
 def bad_touch(self,*args,**kwargs):
  if self==root/'seal-failure/stop-live':raise OSError('injected local seal failure')
  return original_touch(self,*args,**kwargs)
 Path.touch=bad_touch;d=m.finalize(root/'seal-failure',dict(error=None,native_runtime_executed=False))
 m.need(d['result']=='FAILED_OR_CANCELED_PRIVATE_SDK_NATIVE_SMOKE'and not d['local_stop_present']and m.read(root/'seal-failure/receipt.json')==d and d['finalization_errors'][0]['stage']=='seal-stop','seal failure still records receipt');results.append(dict(name='seal-failure',receipt=d))
finally:Path.touch=original_touch
sentinel=root/'existing-receipt/receipt.json';sentinel.write_text('immutable prior terminal\n')
d=m.finalize(root/'existing-receipt',dict(error=None,native_runtime_executed=False));m.need(sentinel.read_text()=='immutable prior terminal\n'and d['result']=='FAILED_OR_CANCELED_PRIVATE_SDK_NATIVE_SMOKE'and d['finalization_errors'][0]['stage']=='exclusive-receipt','existing receipt never overwritten');results.append(dict(name='existing-receipt',receipt=d))
(root/'existing-run/run').mkdir();refused=0
for name in ['existing-receipt','existing-run']:
 try:m.fresh_output(root/name)
 except ValueError:refused+=1
m.need(refused==2,'existing run/terminal refuses fresh admission')
result=dict(result='PASS_NON_NATIVE_FINALIZATION_CONTROLS',producer_sha256=m.sha(__file__),runner_sha256=m.sha(m.W/'run.py'),native_runtime_executed=False,finalization_cases=3,fresh_admission_refusals=refused,results=results)
(m.W/'finalization-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='results'}))
