"""Discriminate actual relative metadata from wrong or absent SDK lineage."""
from pathlib import Path
import copy,hashlib,json
from lineage import embedded_gpu_directory,GPU_MODULE
W=Path(__file__).resolve().parent;M=Path('/private/tmp/vellum-gpu-sdk-stage0077/drawing-metadata/stdout');SDK=Path('/private/tmp/vellum-gpu-sdk-stage0077/relocated SDK/vellum-v0.1.0-alpha.2');CWD=SDK/'examples/drawing';EXPECTED=SDK/'drivers/cogent/build/libs-darwin'
info=json.loads(M.read_bytes());tests=[]
assert embedded_gpu_directory(info,CWD,EXPECTED)==str(EXPECTED);tests.append('actual relative build metadata accepted')
record=next(m for m in info['Deps']if m['Path']==GPU_MODULE);assert record['Replace']['Path']!=str(EXPECTED);tests.append('old absolute-string predicate discriminated')
def changed(path):
 d=copy.deepcopy(info);next(m for m in d['Deps']if m['Path']==GPU_MODULE)['Replace']['Path']=path;return d
assert embedded_gpu_directory(changed(str(EXPECTED)),CWD,EXPECTED)==str(EXPECTED);tests.append('equivalent absolute path accepted')
for label,data in [('wrong relative capsule',changed('../..')),('different SDK same candidate library',changed('/private/tmp/vellum-source-gpu-sdk-native/relocated SDK/vellum-v0.1.0-alpha.2/drivers/cogent/build/libs-darwin')),('empty replacement',changed(''))]:
 try:embedded_gpu_directory(data,CWD,EXPECTED)
 except ValueError:tests.append(label+' refused')
 else:raise AssertionError(label)
for label,data in [('missing module',{'Deps':[]}),('duplicate module',{'Deps':[record,record]})]:
 try:embedded_gpu_directory(data,CWD,EXPECTED)
 except ValueError:tests.append(label+' refused')
 else:raise AssertionError(label)
result=dict(result='PASS_EIGHT_LINEAGE_CONTROLS',count=len(tests),checks=tests,native_runtime_executed=False,compiler_executed=False,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),W/'lineage.py',M]})
with(W/'lineage-controls.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(result=result['result'],count=len(tests))))
