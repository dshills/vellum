"""Retain the current SDK and four executable/map pairs after the docs checkpoint."""
from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-gpu-sdk-stage0077';OLDP=Path('/private/tmp/vellum-gpu-sdk-stage0077')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def main():
 receipt=read(W/'commit-receipt.json');result=read(W/'report/result.json');build=read(W/'build.json');donor=read(OLD/'build.json')
 assert receipt['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED'and receipt['both_clean']and receipt['canonical_promoted']and not receipt['error']and not receipt['finalization_errors']and receipt['source_files']==4742 and receipt['prepared_files']==6250 and not receipt['checkout_preparation_pending']
 assert result['result']=='PASS_CURRENT_PRIVATE_SDK_THREE_NATIVE_DEMOS'and build['result']=='PASS_BUILD'and donor['result']=='FAILED_BUILD'
 assert all(read(W/('native-'+name+'.json'))['result']=='PASS_NATIVE-'+name.upper()for name in ['drawing','viewport3d','imaging'])
 destination=W/('checkpoint-'+receipt['commit'][:7]);assert not destination.exists()and not(W/'checkpoint-receipt.json').exists()
 entries={'workspace/'+p.relative_to(W).as_posix():p for p in W.rglob('*')if p.is_file()and not p.is_symlink()and not any(part.startswith('checkpoint-')or part=='__pycache__'for part in p.relative_to(W).parts)}
 principals={'current-sdk.tar.gz':OLDP/'sdk.tar.gz','source-built-libwgpu_native.a':Path(build['sdk_root'])/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'}
 for item in result['binaries']:
  assert sha(item['path'])==item['sha256']and sha(item['linkmap']['path'])==item['linkmap']['sha256']
  principals[item['name']]=Path(item['path']);principals[item['name']+'.linkmap']=Path(item['linkmap']['path'])
 assert sha(principals['current-sdk.tar.gz'])=='e1acb49f0941fca3f691aec35878e4f1c19ae15fcb37325718f0942b30bf5b69'
 assert sha(principals['source-built-libwgpu_native.a'])=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
 for name,path in principals.items():entries['principal-artifacts/'+name]=path
 index={n:dict(bytes=p.stat().st_size,sha256=sha(p),mode=p.stat().st_mode&0o777,origin=str(p))for n,p in sorted(entries.items())};destination.mkdir()
 for name,path in sorted(entries.items()):
  target=destination/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
  assert target.stat().st_size==index[name]['bytes']and sha(target)==index[name]['sha256']and target.stat().st_mode&0o777==index[name]['mode']
 manifest=dict(evidence_commit=receipt['commit'],tested_clean_sdk_source='5eef84168c37582181d418b2d73e18502f0effad',files=index,source_after_docs_commit=4742,prepared_files=6250,sdk_payload_files=7441,framework_code_changed=False,original_failed_endpoint_preserved=True,three_native_sdk_cases_pass=True,full_macos_qualified=False,scope='Private SDK functional consumption and source-specific native assertions/readbacks. W10 failed metadata-representation validator remains failed. Actual3headless cancellation cases are distinct from33component build commands and3native cases. SDK/binaries retain tested clean5eef841 identity; not relabeled as rebuilt from the later documentation commit. No physical/presentation/performance/native-memory/endurance/rights/public-distribution qualification.')
 with(destination/'MANIFEST.json').open('x')as output:output.write(json.dumps(manifest,indent=2)+'\n')
 summary=dict(commit=receipt['commit'],path=str(destination),manifest_sha256=sha(destination/'MANIFEST.json'),files=len(index),bytes=sum(v['bytes']for v in index.values()))
 with(W/'checkpoint-receipt.json').open('x')as output:output.write(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary))
if __name__=='__main__':main()
