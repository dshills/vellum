"""Continue the immutable current SDK after correcting relative metadata lineage."""
from pathlib import Path
import importlib.util,json,struct,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-gpu-sdk-lineage-stage0077');OLD=W.parent/'macos-gpu-sdk-stage0077';OLDP=Path('/private/tmp/vellum-gpu-sdk-stage0077')
s=importlib.util.spec_from_file_location('immutable_sdk_parent',OLD/'run.py');h=importlib.util.module_from_spec(s);sys.modules[s.name]=h;s.loader.exec_module(h)
h.need(h.sha(OLD/'run.py')=='8497474902d770c9b0cc37d6b7dc2192c84ebcfab5408b7f74f7b777ab148dc8','unchanged admitted parent');h.W,h.P=W,P
sys.path.insert(0,str(W))
from lineage import embedded_gpu_directory
s=importlib.util.spec_from_file_location('continued_sdk_fixtures',W/'fixtures.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f);f.h=h

def prepare():
    h.need(not P.exists()and not(W/'plan.json').exists()and not h.STOP.exists(),'fresh continuation')
    donor=h.read(OLD/'build.json');review=h.read(OLD/'result-review.json')
    h.need(donor['result']=='FAILED_BUILD'and donor['error']==dict(type='ValueError',message='SDK embedded GPU lineage')and not donor['finalization_errors']and len(donor['commands'])==17,'precise preserved donor failure')
    h.need(review['evidence_reconciled']and review['scoped_reuse_ready'],'independently reconciled reuse')
    h.need(all(h.terminal(c['run'])for c in donor['commands']),'seventeen zero-exit donor commands')
    pins=dict(donor['inputs']);h.need(all(h.sha(p)==v for p,v in pins.items()),'immutable donor inputs')
    source=h.read(OLD/'source.json');h.need(h.identity(h.T)==h.identity(h.C)==source,'clean current source/prepared parity')
    sdk=Path(donor['sdk_root']);h.sdk_identity(sdk,h.read(sdk/'SDK_MANIFEST.json'))
    paths=[Path(__file__),W/'fixtures.py',W/'lineage.py',W/'lineage_controls.py',W/'lineage-controls.json',W/'validators.py',W/'plan-draft.md',OLD/'build.json',OLD/'result-review.json',OLD/'plan.json',OLD/'source.json']
    for command in donor['commands']:
        for name in ['stdout','stderr','owned.json']:paths.append(OLDP/command['name']/name)
    for path in paths:h.pin_once(pins,path)
    P.mkdir(mode=0o700)
    for name in ['go-cache','go-tmp','temp']:(P/name).mkdir(mode=0o700)
    h.exclusive(W/'source.json',source);h.pin_once(pins,W/'source.json')
    h.exclusive(W/'plan.json',dict(source_commit=h.HEAD,inputs=pins,sdk_root=str(sdk),sdk_archive=donor['archive'],donor_full_build_remains_failed=True,reused_direct_command_outcomes=17,fresh_direct_commands=16,reused_go_build_cache=str(OLDP/'go-cache'),native_cases=h.CASES,native_separate_review=True,new_source_or_sdk=False))
    print(json.dumps(dict(result='PREPARED_SDK_LINEAGE_CONTINUATION',inputs=len(pins),sdk_files=7441,native_started=False)))

def inspect_drawing(sdk,pin):
    binary=OLDP/'drawing';linkmap=OLDP/'drawing.linkmap';cwd=sdk/'examples/drawing'
    info=h.read(OLDP/'drawing-metadata/stdout');embedded_gpu_directory(info,cwd,sdk/'drivers/cogent/build/libs-darwin')
    h.need('libwgpu_native'not in(OLDP/'drawing-links/stdout').read_text()and'minos 13.0'in(OLDP/'drawing-load/stdout').read_text(),'retained linkage/load metadata')
    settings={}
    for item in info['Settings']:
        h.need(set(item)<={'Key','Value'}and item['Key']not in settings and type(item.get('Value',''))is str,'unique typed metadata');settings[item['Key']]=item.get('Value','')
    h.need(info['GoVersion']=='go1.27.2'and info['Path']=='github.com/dshills/vellum/examples/drawing'and all(settings.get(k)==v for k,v in {'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'1','-race':'true'}.items())and'vcs.revision'not in settings,'retained independent drawing build')
    with binary.open('rb')as stream:header=stream.read(32)
    h.need(len(header)==32 and struct.unpack_from('<I',header)[0]==0xFEEDFACF and struct.unpack_from('<I',header,4)[0]==0x0100000C and struct.unpack_from('<I',header,12)[0]==2,'retained thin ARM64 executable')
    library=sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a';archive=h.native_archive.archive_members(library);mapping=h.native_archive.linker_objects(linkmap);selected=h.native_archive.selected_archive_members(mapping,library,archive)
    h.need(archive['sha256']==h.LIBSHA and mapping['architecture']=='arm64'and selected and len(selected)==len([v for v in mapping['objects']if'libwgpu_native'in v]),'exact retained static archive selection')
    inspection=W/'inspection-drawing.json';h.exclusive(inspection,dict(name='drawing',metadata=info,selected_archive_members=selected,relative_gpu_replacement_resolved=str(sdk/'drivers/cogent/build/libs-darwin'),retained_donor_outcomes=True));pin(inspection);pin(binary);pin(linkmap)
    return dict(name='drawing',path=str(binary),bytes=binary.stat().st_size,sha256=h.sha(binary),linkmap=dict(path=str(linkmap),bytes=linkmap.stat().st_size,sha256=h.sha(linkmap)),static_archive_members=len(selected),race=True,minimum_macos='13.0',retained_donor=True)

def build():
    phase='build';h.need(not(W/'build.json').exists()and not h.stopped(phase),'one-shot corrected build')
    pins,reviewsha=h.certificate(phase);plan=h.read(W/'plan.json');sdk=Path(plan['sdk_root']);manifest=h.read(sdk/'SDK_MANIFEST.json');vector=h.sdk_identity(sdk,manifest)
    stable=lambda:all(h.sha(p)==v for p,v in pins.items())and h.sdk_identity(sdk,manifest)==vector
    d=dict(result='INCOMPLETE',source_commit=h.HEAD,inputs=pins,readiness_sha256=reviewsha,commands=[],fixtures=[],error=None,finalization_errors=[],sdk_root=str(sdk),sdk_archive=plan['sdk_archive'],donor_full_build_remains_failed=True,reused_direct_command_outcomes=17,new_source_or_sdk=False,native_execution='not_started')
    def pin(path):h.pin_once(pins,path)
    def command(name,args,cwd,timeout=180):
        env=h.environment();indices=[i for i,v in enumerate(env)if v.startswith('GOCACHE=')];h.need(len(indices)==1,'one controlled cache setting');env[indices[0]]='GOCACHE='+str(OLDP/'go-cache')
        run=h.g.execute(env+args,cwd,P/name,lambda:h.stopped(phase),stable,timeout=timeout,limit=8<<20);d['commands'].append(dict(name=name,run=run));h.need(h.terminal(run),'owned continued command '+name);return(P/name/'stdout').read_bytes()
    try:
        with h.g.LiveLease()as lease:
            h.need(lease.held()and stable()and not h.stopped(phase),'corrected build admission');h.need(h.identity(h.T)==h.identity(h.C)==h.read(W/'source.json'),'current source/prepared parity')
            d['fixtures'].append(inspect_drawing(sdk,pin));d['fixtures']+=f.build(sdk,command,pin,['viewport3d','imaging'])
            h.need(len(d['commands'])==16 and len(d['fixtures'])==3 and stable()and h.identity(h.T)==h.identity(h.C)==h.read(W/'source.json')and not h.stopped(phase)and lease.held(),'terminal corrected build closure')
    except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
    finally:h.finish(phase,d)
if __name__=='__main__':
    h.need(sys.argv[1:]in[['prepare'],['build']]+[['native',name]for name in h.CASES],'fixed continuation phase')
    if sys.argv[1]=='native':f.native(sys.argv[2])
    else:{'prepare':prepare,'build':build}[sys.argv[1]]()
