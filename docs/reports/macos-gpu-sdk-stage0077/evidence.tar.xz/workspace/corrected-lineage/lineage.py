"""Resolve Go build metadata's replacement spelling from the consuming module."""
from pathlib import Path
GPU_MODULE='github.com/oliverbestmann/webgpu/libs-darwin'
def embedded_gpu_directory(info,cwd,expected):
    matches=[m for m in info.get('Deps',[])if m.get('Path')==GPU_MODULE]
    if len(matches)!=1:raise ValueError('one embedded SDK GPU module required')
    replacement=matches[0].get('Replace')or{};spelling=replacement.get('Path')
    if type(spelling)is not str or not spelling:raise ValueError('explicit embedded SDK GPU replacement required')
    path=Path(spelling);resolved=(path if path.is_absolute()else Path(cwd)/path).resolve(strict=True)
    wanted=Path(expected).resolve(strict=True)
    if resolved!=wanted or not resolved.is_dir():raise ValueError('embedded GPU replacement is outside selected SDK capsule')
    return str(resolved)
