# Correct relative SDK module lineage validation

Preserve the prior W10 overall FAILED_BUILD and one-shot seal. Its seventeen
commands all exited zero and were retired; the verifier then rejected Go's
legitimate relative replacement spelling. Resolve that path from the consuming
module and still require the exact selected SDK capsule directory.

Reuse the unchanged clean5eef841 SDK (7441 payload leaves,7336 source/prepared
counterparts,89 modules,11 overlays), hosted public API checks, generated starter
and drawing race/vet/compile/rawmetadata outcomes after independent reconciliation.
Finish drawing header/linkmap/static-archive inspection using retained inputs.
Build/test/vet only the remaining viewport3d and imaging fixtures:16 direct Go/tool
commands in fresh outputs. No SDK regeneration, source edit or provider call.

Admit three native fixture cases separately after corrected build review. All use
the same immutable SDK. Scope remains source assertions/readbacks and normal
closure; physical input, presentation, ordinary performance, memory/endurance,
rights/distribution and full Mac qualification remain open.
