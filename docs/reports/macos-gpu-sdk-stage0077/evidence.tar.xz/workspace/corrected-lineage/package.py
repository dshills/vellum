"""Package source-unchanged SDK evidence with the failed lineage endpoint retained."""
from pathlib import Path
import hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;R=W/'report';T=Path('/private/tmp/vellum-macos-native-results-97aee13')
OLD=W.parent/'macos-gpu-sdk-stage0077';P=Path('/private/tmp/vellum-gpu-sdk-lineage-stage0077');OLDP=Path('/private/tmp/vellum-gpu-sdk-stage0077')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
MAX_MEMBERS=384;MAX_EXPANDED=256<<20;MAX_COMPRESSED=32<<20
def need(ok,msg):
 if not ok:raise ValueError(msg)
class BoundedWriter:
 def __init__(self,stream,bound):self.stream,self.bound=stream,bound
 def write(self,body):
  need(self.stream.tell()+len(body)<=self.bound,'compressed evidence byte bound')
  return self.stream.write(body)
 def tell(self):return self.stream.tell()
 def flush(self):return self.stream.flush()
def main():
 need(not R.exists(),'fresh evidence output')
 reviewbody=(W/'report-review.json').read_bytes();review=json.loads(reviewbody);reviewsha=hashlib.sha256(reviewbody).hexdigest()
 need(review['report_ready']and not review['unresolved_findings'],'independent report review')
 stable=lambda:sha(W/'report-review.json')==reviewsha and all(sha(p)==v for p,v in review['inputs'].items())
 need(stable(),'reviewed evidence closure')
 build=read(W/'build.json');donor=read(OLD/'build.json');results=read(W/'result-review.json')
 need(build['result']=='PASS_BUILD'and not build['error']and not build['finalization_errors']and len(build['commands'])==16,'actual corrected component completion')
 need(donor['result']=='FAILED_BUILD'and len(donor['commands'])==17 and donor['error']==dict(type='ValueError',message='SDK embedded GPU lineage'),'original failed endpoint')
 need(results['result_ready']and not results['unresolved_findings'],'actual native results reconciled')
 need('PENDING'not in(W/'README.final.md').read_text(),'completed prose')
 entries={};runs=[]
 def add(name,path):
  path=Path(path);need(name not in entries and path.is_file()and not path.is_symlink()and path.stat().st_size<=32<<20,'unique bounded regular artifact');entries[name]=path
 for label,workspace in [('failed-lineage',OLD),('corrected-lineage',W)]:
  for path in sorted(workspace.rglob('*')):
   if not path.is_file():continue
   rel=path.relative_to(workspace)
   if any(part in ['report','__pycache__','commit-logs']or part.startswith('checkpoint-')for part in rel.parts):continue
   add('workspace/'+label+'/'+rel.as_posix(),path)
 for label,workspace,root in [('failed-lineage',OLD,OLDP),('corrected-lineage',W,P)]:
  for command in read(workspace/'build.json')['commands']:
   run=command['run'];need(run['exit_code']==0 and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'retained completed command')
   for name in ['stdout','stderr','owned.json']:
    path=root/command['name']/name
    if name in run['logs']:need(run['logs'][name]==dict(bytes=path.stat().st_size,sha256=sha(path)),'raw build stream identity')
    add('build-runs/'+label+'/'+command['name']+'/'+name,path)
   runs.append(dict(phase=label,name=command['name'],exit_code=run['exit_code'],group=run['group'],seconds=run['seconds']))
 native=[]
 for name in ['drawing','viewport3d','imaging']:
  d=read(W/('native-'+name+'.json'));need(d['result']=='PASS_NATIVE-'+name.upper()and not d['error']and not d['finalization_errors'],'native fixture actual pass')
  for stream in ['stdout','stderr','owned.json']:
   path=P/('native-'+name)/stream
   if stream in d['run']['logs']:need(d['run']['logs'][stream]==dict(bytes=path.stat().st_size,sha256=sha(path)),'raw native stream identity')
   add('native-runs/'+name+'/'+stream,path)
  native.append(dict(name=name,run=d['run'],record=d['record']))
 controls=read(OLD/'grouped-stop-controls.json');need(controls['result']=='PASS_THREE_ACTUAL_GROUPED_CANCELLATION_CONTROLS'and not controls['error'],'actual headless cancellation controls')
 for path in sorted((OLDP/'grouped-cancellation-controls').rglob('*')):
  if path.is_file():add('actual-cancellation-controls/'+path.relative_to(OLDP/'grouped-cancellation-controls').as_posix(),path)
 sdk=Path(build['sdk_root']);lib=sdk/'drivers/cogent/build/libs-darwin'
 for name in ['SDK_MANIFEST.json','THIRD_PARTY_INVENTORY.json']:add('sdk/'+name,sdk/name)
 for name in ['go.mod','libs.go','PROVENANCE.json']:add('sdk-capsule/'+name,lib/name)
 binaries=[dict(name='generated-starter',path=donor['binary']['path'],bytes=donor['binary']['bytes'],sha256=donor['binary']['sha256'],linkmap=donor['linkmap'])]+build['fixtures']
 for binary in binaries:
  need(sha(binary['path'])==binary['sha256']and sha(binary['linkmap']['path'])==binary['linkmap']['sha256'],'retained build pair identity');add('linkmaps/'+binary['name']+'.linkmap',binary['linkmap']['path'])
 helpers={'owned-executor.py':W.parent/'macos-sdk-native-238b3b6/run.py','retained-sdk-parent.py':W.parent/'macos-source-gpu-sdk-native/run.py','live-lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),'commit-git-guard.py':W.parent/'macos-grid-native-stacks/commit-pending.py'}
 for name in ['child_process.py','sdk_environment.py','native_archive.py','native_gpu.py','check-sdk.py','release-sdk.py','artifact_io.py','new-app.py']:helpers[name]=T/'scripts'/name
 for name,path in helpers.items():add('helpers/'+name,path)
 for label,workspace,names in [('retained-sdk',W.parent/'macos-source-gpu-sdk-native',['controls.py','controls.json']),('historical-executor',W.parent/'macos-sdk-native-238b3b6',['controls-v2.py','controls-v2.json','fault-controls.py','fault-controls.json','finalization-controls.py','finalization-controls.json','blocked-v2/run.py']),('gpu-provenance',W.parent/'macos-source-gpu-sdk-a274e8a',['gpu-provenance.json','network-probe.json','network_probe.py','checks.py'])]:
  for name in names:add('reused-support/'+label+'/'+name,workspace/name)
 for name in ['stdout','stderr','owned.json']:add('reused-support/gpu-network-probe/'+name,Path('/private/tmp/vellum-source-gpu-sdk-a274e8a/network-probe')/name)
 index={name:dict(bytes=path.stat().st_size,sha256=sha(path))for name,path in sorted(entries.items())};need(len(index)<=MAX_MEMBERS and sum(v['bytes']for v in index.values())<=MAX_EXPANDED,'finite evidence limits')
 principals=[Path(item['path'])for item in binaries]+[OLDP/'sdk.tar.gz',lib/'arm64/libwgpu_native.a']
 excluded=[dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))for path in principals]
 R.mkdir()
 with(R/'evidence.tar.xz').open('xb')as raw:
  with tarfile.open(fileobj=BoundedWriter(raw,MAX_COMPRESSED),mode='w:xz',preset=6)as archive:
   for name,path in sorted(entries.items()):
    data=path.read_bytes();need(hashlib.sha256(data).hexdigest()==index[name]['sha256'],'stable origin');info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
 with tarfile.open(R/'evidence.tar.xz','r:xz')as archive:
  need(archive.getnames()==sorted(index),'exact archive membership')
  for item in archive:
   data=archive.extractfile(item).read();need(len(data)==index[item.name]['bytes']and hashlib.sha256(data).hexdigest()==index[item.name]['sha256'],'archive readback')
 manifest=dict(files=index,archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz')),excluded_principal_artifacts=excluded,limits=dict(members=MAX_MEMBERS,expanded_bytes=MAX_EXPANDED,compressed_bytes=MAX_COMPRESSED,member_bytes=32<<20))
 (R/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 result=dict(result='PASS_CURRENT_PRIVATE_SDK_THREE_NATIVE_DEMOS',tested_clean_source='5eef84168c37582181d418b2d73e18502f0effad',source_files=4738,prepared_files=6250,sdk_archive=build['sdk_archive'],sdk_files=7441,source_prepared_counterparts=7336,module_overlays=11,go_module_inventory=89,source_sdk_reconciliation=donor['source_sdk_reconciliation'],relocated_check=donor['relocated_check'],build_runs=runs,native=native,binaries=binaries,original_full_build_remains_failed=True,reused_completed_build_outcomes=17,fresh_build_commands=16,actual_headless_cancellation_cases=3,actual_headless_cancellation_processes=6,lineage_control_cases=8,reused_guard_cases=27,standalone_sdk_child_timeouts_qualified=False,new_framework_source=False,new_prism_calls=0,result_review_sha256=sha(W/'result-review.json'),report_review_sha256=reviewsha,settings_changes=False,physical_input_generated=False,presentation_qualified=False,ordinary_frame_latency_qualified=False,native_gpu_memory_qualified=False,endurance_qualified=False,rights_distribution_qualified=False,full_macos_qualified=False,public_distribution=False)
 (R/'result.json').write_text(json.dumps(result,indent=2)+'\n');(R/'README.md').write_bytes((W/'README.final.md').read_bytes());need(stable(),'terminal reviewed closure')
 print(json.dumps(dict(result='PACKAGED_PRIVATE_SDK_NATIVE_EVIDENCE',members=len(index),expanded_bytes=sum(v['bytes']for v in index.values()),archive=manifest['archive'])))
if __name__=='__main__':main()
