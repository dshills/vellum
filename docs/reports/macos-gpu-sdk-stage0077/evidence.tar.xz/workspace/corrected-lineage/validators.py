import json

def need(ok,message):
 if not ok:raise ValueError(message)

def validate_advanced(name,stdout,stderr):
 records=[]
 for line in stdout.splitlines():
  value=json.loads(line);need(type(value)is dict,'JSON record');records.append(value)
 need(len(records)==1,'exactly one native summary');r=records[0]
 need(r.get('event')=='vellum.'+name+'.smoke' and r.get('geometry_persistence_disabled_in_fixture')is True,'actual fixture geometry isolation')
 if name=='drawing':
  for key in ['gradient_and_linear_alpha_pixels','transparent_snapshot','static_pan_retains_mesh','independent_windows','empty_frame_clear','budget_refusal','error_callback_resource_query','resource_rebuild','repeated_resize']:need(r.get(key)is True,'drawing assertion '+key)
  need(r.get('schematic_source_objects')==100000 and r.get('waveform_source_samples')==1000000,'drawing source workload')
  image=r.get('retained_image');need(type(image)is dict and image.get('initial_tiles')==1024 and image.get('changed_tiles')==1 and image.get('changed_upload_bytes')==65536,'retained tile workload')
 else:need(r.get('result')=='pass'and r.get('independentBufferNamespaces')is True and r.get('orbitPixelsChanged')is True,'viewport source assertions')
 errors=stderr.decode().splitlines();expected=['budget exceeded']if name=='drawing'else['budget exceeded','controlled preparation','controlled draw']
 need(len(errors)==len(expected)and all(sum(part in error for error in errors)==1 for part in expected)and all(sum(part in error for part in expected)==1 for error in errors),'only deliberate native fault diagnostics')
 return r

def validate_imaging(name,stdout,stderr):
 need(name=='imaging','fixed imaging summary')
 records=[json.loads(line)for line in stdout.splitlines()]
 need(len(records)==1 and type(records[0])is dict,'one imaging JSON summary');r=records[0]
 need(r.get('event')=='vellum.imaging.smoke'and r.get('result')=='pass'and r.get('geometry_persistence_disabled_in_fixture')is True,'actual isolated imaging success')
 for key in ['transparentTop','nativeAdmissionRefusals','explicitSyncThenAsync','partialAlpha','busyInsideCallback','independentResources','quietCancelRebuildClose']:need(r.get(key)is True,'imaging assertion '+key)
 need(r.get('exposure1')==dict(R=213,G=156,B=0,A=128)and r.get('exposure2')==dict(R=231,G=188,B=0,A=128),'quantitative exposure/alpha reference')
 close=r.get('normalClose');need(type(close)is dict,'normal close record')
 for key in ['nativeClosed','nativeDrawingLockRefused','windowLifetimeCanceled','appLifetimeCanceled','unregistered','programReleased']:need(close.get(key)is True,'normal close assertion '+key)
 need(type(close.get('callbackCount'))is int and close['callbackCount']==0,'no canceled/closed capture delivery')
 need(type(r.get('deliveryAfterResize'))is bool,'record actual scheduling overlap without requiring it')
 initial=r.get('initial');need(type(initial)is dict and initial.get('BufferBytes')==1048608 and initial.get('TextureBytes')==524288,'compute storage/uniform and float texture accounting')
 need(stderr==b'','no unexpected imaging diagnostics')
 return r
