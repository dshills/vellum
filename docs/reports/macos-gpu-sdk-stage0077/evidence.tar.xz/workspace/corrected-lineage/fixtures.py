"""Bounded, source-unchanged SDK fixture builds and separate native checks."""
from pathlib import Path
import importlib.util,json,struct
from lineage import embedded_gpu_directory
h=None
BASELINE=Path('/private/tmp/vellum-source-gpu-sdk-native/relocated SDK/vellum-v0.1.0-alpha.2/SDK_MANIFEST.json')

def verify_sources(sdk,manifest,pin):
    old=h.read(BASELINE);pin(BASELINE)
    added={'drivers/cogent/native/patches/eventpublication/'+name for name in ['0077-key-event-publication-ownership.patch','README.md','original-hashes.json','output-hashes.json']}
    added.add('drivers/cogent/build/upstream/events/source_key_ownership_vellum_test.go')
    h.need(set(manifest['files'])==set(old['files'])|added and len(manifest['files'])==7441,'exact current SDK file-set increment')
    spec=importlib.util.spec_from_file_location('source_sdk_producer',h.T/'scripts/release-sdk.py');producer=importlib.util.module_from_spec(spec);spec.loader.exec_module(producer)
    sources=dict(producer.source_files(h.T));overlays=manifest['native_gpu']['go_mod_overlays']
    h.need(len(overlays)==11,'eleven explicit SDK Go module overlays')
    for name,path in sources.items():
        original=h.sha(path);expected=overlays.get(name,{}).get('source_sha256',manifest['files'].get(name))
        h.need(original==expected,'current source/prepared SDK counterpart '+name)
        if name in overlays:h.need(h.sha(sdk/name)==overlays[name]['archived_sha256'],'archived module overlay '+name)
    for name,digest in h.read(h.T/'drivers/cogent/native/patches/eventpublication/output-hashes.json').items():
        h.need(h.sha(sdk/'drivers/cogent/build/upstream'/name)==digest,'stage0077 prepared output')
    inventory=h.read(sdk/'THIRD_PARTY_INVENTORY.json');h.need(len(inventory['modules'])==89 and inventory['distribution_audit']=='pending','private inventory remains unqualified')
    return dict(source_prepared_counterparts=len(sources),payload_files=len(manifest['files']),module_overlays=len(overlays))

def build(sdk,command,pin,names=None):
    binaries=[]
    origins={'github.com/dshills/vellum':str(sdk),'github.com/dshills/vellum/drivers/cogent':str(sdk/'drivers/cogent'),'cogentcore.org/core':str(sdk/'drivers/cogent/build/upstream'),'github.com/go-text/typesetting':str(sdk/'drivers/cogent/build/typesetting'),'github.com/oliverbestmann/webgpu/libs-darwin':str(sdk/'drivers/cogent/build/libs-darwin')}
    for name in (h.CASES if names is None else names):
        cwd=sdk/'examples'/name;binary=h.P/name;linkmap=h.P/(name+'.linkmap');h.fresh_outputs(binary,linkmap)
        modules=h.checker.decode_objects(command(name+'-modules',[str(h.GO),'list','-mod=readonly','-m','-json','all'],cwd).decode())
        h.need({m['Path']:m['Replace'].get('Dir') for m in modules if m.get('Replace')}==origins,'five exact SDK fixture origins '+name)
        packages=h.checker.decode_objects(command(name+'-sources',[str(h.GO),'list','-race','-test','-mod=readonly','-deps','-json','./...'],cwd).decode())
        h.need(packages and not any(p.get('Incomplete')or p.get('Error')or p.get('DepsErrors')for p in packages),'complete SDK fixture test graph')
        generated=[]
        for package in packages:
            for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles']:
                for value in package.get(field,[]):
                    path=Path(value)if Path(value).is_absolute()else Path(package['Dir'])/value
                    if not path.is_file():
                        h.need(field=='GoFiles'and package.get('Name')=='main'and package['ImportPath'].endswith('.test')and path.name=='_testmain.go','only generated test-main need not persist');generated.append(str(path));continue
                    pin(path)
            module=package.get('Module')or{};module=module.get('Replace')or module
            if module.get('GoMod'):pin(module['GoMod'])
        command(name+'-race',[str(h.GO),'test','-race','-count=1','-mod=readonly','./...'],cwd,600)
        command(name+'-vet',[str(h.GO),'vet','-mod=readonly','./...'],cwd,300)
        command(name+'-compile',[str(h.GO),'build','-race','-mod=readonly','-p=2','-buildvcs=false','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',str(binary),'.'],cwd,600)
        h.need(binary.is_file()and not binary.is_symlink()and 0<binary.stat().st_size<128<<20 and linkmap.is_file()and not linkmap.is_symlink(),'retained SDK fixture build pair');pin(binary);pin(linkmap)
        links=command(name+'-links',['/usr/bin/otool','-L',str(binary)],h.P,30).decode();h.need('libwgpu_native'not in links,'no WGPU dylib')
        load=command(name+'-load',['/usr/bin/otool','-l',str(binary)],h.P,30).decode();h.need('minos 13.0'in load,'minimum macOS13')
        info=json.loads(command(name+'-metadata',[str(h.GO),'version','-m','-json',str(binary)],h.P,30));settings={}
        for item in info['Settings']:
            h.need(set(item)<={'Key','Value'}and item['Key']not in settings and type(item.get('Value',''))is str,'unique typed build setting');settings[item['Key']]=item.get('Value','')
        h.need(info['GoVersion']=='go1.27.2'and info['Path']=='github.com/dshills/vellum/examples/'+name and all(settings.get(k)==v for k,v in {'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'1','-race':'true'}.items())and 'vcs.revision'not in settings,'independent SDK fixture race metadata')
        embedded_gpu_directory(info,cwd,sdk/'drivers/cogent/build/libs-darwin')
        with binary.open('rb')as stream:header=stream.read(32)
        h.need(len(header)==32 and struct.unpack_from('<I',header)[0]==0xFEEDFACF and struct.unpack_from('<I',header,4)[0]==0x0100000C and struct.unpack_from('<I',header,12)[0]==2,'thin ARM64 executable')
        library=sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a';archive=h.native_archive.archive_members(library);mapping=h.native_archive.linker_objects(linkmap);selected=h.native_archive.selected_archive_members(mapping,library,archive)
        h.need(archive['sha256']==h.LIBSHA and mapping['architecture']=='arm64'and selected and len(selected)==len([v for v in mapping['objects']if'libwgpu_native'in v]),'exact SDK static archive selection')
        inspection=h.W/('inspection-'+name+'.json');h.exclusive(inspection,dict(name=name,origins=origins,metadata=info,selected_archive_members=selected,package_count=len(packages),generated_test_main_not_retained=generated));pin(inspection)
        binaries.append(dict(name=name,path=str(binary),bytes=binary.stat().st_size,sha256=h.sha(binary),linkmap=dict(path=str(linkmap),bytes=linkmap.stat().st_size,sha256=h.sha(linkmap)),static_archive_members=len(selected),package_count=len(packages),race=True,minimum_macos='13.0'))
    return binaries

def native(name):
    phase='native-'+name;h.need(name in h.CASES and not(h.W/(phase+'.json')).exists()and not h.stopped(phase),'fresh SDK native endpoint')
    pins,reviewsha=h.certificate('native')
    built=h.read(h.W/'build.json');h.need(built['result']=='PASS_BUILD'and not built['error']and not built['finalization_errors'],'reviewed SDK build complete')
    sdk=Path(built['sdk_root']);manifest=h.read(sdk/'SDK_MANIFEST.json');binary=next(v for v in built['fixtures']if v['name']==name)
    sdk_vector=h.sdk_identity(sdk,manifest);stable=lambda:all(h.sha(p)==v for p,v in pins.items())and h.sdk_identity(sdk,manifest)==sdk_vector
    spec=importlib.util.spec_from_file_location('sdk_native_validators',h.W/'validators.py');validators=importlib.util.module_from_spec(spec);spec.loader.exec_module(validators)
    d=dict(result='INCOMPLETE',source_commit=h.HEAD,inputs=pins,readiness_sha256=reviewsha,error=None,finalization_errors=[],native_execution='not_started',physical_input_generated=False,settings_changes=False,full_macos_qualified=False)
    try:
        with h.g.LiveLease()as lease:
            h.need(lease.held()and stable()and not h.stopped(phase),'native admission')
            h.need(h.identity(h.T)==h.identity(h.C)==h.read(h.W/'source.json'),'committed source/prepared parity');h.sdk_identity(sdk,manifest)
            run=h.g.execute(h.environment(True)+['GORACE=halt_on_error=1 exitcode=66 atexit_sleep_ms=0',binary['path'],'--smoke'],sdk/'examples'/name,h.P/phase,lambda:h.stopped(phase),stable,timeout=75,limit=2<<20)
            d['run']=run;d['native_execution']='created_not_qualified'if run['created']else'not_started';h.need(h.terminal(run),'owned SDK native completion')
            validator=validators.validate_imaging if name=='imaging'else validators.validate_advanced
            d['record']=validator(name,(h.P/phase/'stdout').read_bytes(),(h.P/phase/'stderr').read_bytes());d['native_execution']='source_assertions_passed'
            h.sdk_identity(sdk,manifest);h.need(stable()and h.identity(h.T)==h.identity(h.C)==h.read(h.W/'source.json')and not h.stopped(phase)and lease.held(),'terminal native source/SDK closure')
    except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
    finally:h.finish(phase,d)
