# Private current SDK verification

Run only after the event-publication checkpoint is committed and both checkouts
have the tested 6250-file dependency vector. Package a private SDK from the clean
new source; retain the existing exact source-built ARM64 static GPU archive.
Verify archive membership/hashes, all source/prepared counterparts and the eleven
explicit module overlays. Require exactly 7441 payload files: the retained baseline member set plus four
stage-0077 patch metadata/source leaves and one prepared regression leaf. Run the existing relocated generated-consumer
and public API race/vet/build verifier. Retain a separate extraction with spaces
in its path, and build/test/vet drawing, viewport3d and imaging against only that
SDK's five module origins. Preserve executable/linker-map/static archive identities.

Admit native cases separately after build review. Execute those three smoke
fixtures serially, under the existing owned-process executor, shared lease, global
stop marker, bounded logs/watchdogs and IP denial with Unix IPC allowed. Validate
existing source-specific summaries. No physical input, settings changes, public
release or performance/memory qualification is implied. No new Prism call is
planned for source-unchanged SDK packaging evidence.

Only the existing relocated public API checker receives Unix IPC permission during
build, because its transport regression binds a local Unix socket. All IP traffic
remains denied. Packaging and the other direct build commands retain deny-all
network. Native fixtures use the established IP-deny/Unix-allow profile. SDK
member sets and hashes are rechecked throughout owned execution after extraction.
