"""Headless fixture: existing SDK helper owns one separately grouped child."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,'/private/tmp/vellum-macos-native-results-97aee13/scripts')
from child_process import run_child
CHILD="import json,os,sys,time;from pathlib import Path;Path(sys.argv[1]).write_text(json.dumps(dict(pid=os.getpid(),group=os.getpgrp())));time.sleep(45)"
run_child([sys.executable,'-B','-c',CHILD,sys.argv[1]],timeout=30,check=True)
