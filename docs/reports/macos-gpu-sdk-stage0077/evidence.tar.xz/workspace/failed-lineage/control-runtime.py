"""Current private SDK, independent generated consumer and three separately admitted GPU fixtures."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, struct, subprocess, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
PREV = W.parent/'macos-source-gpu-sdk-a274e8a'
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
P = Path('/private/tmp/vellum-gpu-sdk-stage0077')
STOP = Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
HEAD = '5eef84168c37582181d418b2d73e18502f0effad'
CHECKPOINT=W.parent/'macos-event-transport-e96f642'
CASES=['drawing','viewport3d','imaging']
GO = Path('/opt/homebrew/bin/go').resolve()
PYTHON = Path('/opt/homebrew/bin/python3').resolve()
CLANG = Path('/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang')
SDK = Path('/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk')
LIBRARY = Path('/private/tmp/vellum-source-built-gpu-276a654/build-target-v1/aarch64-apple-darwin/release/libwgpu_native.a')
LIBSHA = '786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
ARCHIVE = P/'sdk.tar.gz'
APP = P/'independent application'
BINARY = P/'hello'
LINKMAP = P/'hello.linkmap'
s = importlib.util.spec_from_file_location('retained_sdk_owned_guard', W.parent/'macos-sdk-native-238b3b6/run.py')
g = importlib.util.module_from_spec(s); s.loader.exec_module(g)
sha, read, need = g.sha, g.read, g.need
sys.path.insert(0, str(T/'scripts'))
import native_archive
s = importlib.util.spec_from_file_location('retained_sdk_verifier', T/'scripts/check-sdk.py')
checker = importlib.util.module_from_spec(s); s.loader.exec_module(checker)


def exclusive(path, value):
    with Path(path).open('x') as out: out.write(json.dumps(value, indent=2)+'\n')


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, timeout=30)


def identity(root):
    need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain','-z'), 'clean exact framework checkout')
    names=git(root,'ls-files','-z').decode().split('\0')[:-1]
    need(len(names)==4738, 'framework source count')
    hidden=git(root,'ls-files','-v','-z').decode().split('\0')
    need(not [n for n in hidden if n and (n[0].islower() or n[0]=='S')], 'no hidden index state')
    files={}
    for name in names:
        p=root/name;need(p.is_file() and not p.is_symlink(),'regular tracked source');files[name]=sha(p)
    prepared={}
    for name in ['upstream','typesetting']:
        for p in (root/'drivers/cogent/build'/name).rglob('*'):
            need(not p.is_symlink(),'prepared source symlink')
            if p.is_file(): prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
    need(len(prepared)==6250,'prepared leaf count')
    return dict(commit=HEAD,files=files,prepared=prepared)


def stopped(phase): return STOP.exists() or (P/('stop-'+phase)).exists()


def sdk_identity(sdk, manifest):
    leaves={}
    for path in sdk.rglob('*'):
        need(not path.is_symlink(),'retained SDK symlink')
        if path.is_file():leaves[path.relative_to(sdk).as_posix()]=sha(path)
    expected=dict(manifest['files']);expected['SDK_MANIFEST.json']=sha(sdk/'SDK_MANIFEST.json')
    need(leaves==expected,'exact retained SDK member set and bytes')
    return leaves


def environment(native=False):
    # Fixed argv entries replace ambient compiler/Go flags only in the child.
    env=['PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GOWORK=off','GOTOOLCHAIN=local','GOENV=off','GOFLAGS=','GOPROXY=off','GOSUMDB=off','GONOPROXY=','GONOSUMDB=','CGO_ENABLED=1','GOOS=darwin','GOARCH=arm64','GOMAXPROCS=2','GOCACHE='+str(P/'go-cache'),'GOTMPDIR='+str(P/'go-tmp'),'TMPDIR='+str(P/'temp'),'GOROOT='+str(GO.parent.parent),'CC='+str(CLANG),'CGO_CFLAGS=','CGO_CPPFLAGS=','CGO_CXXFLAGS=','CGO_LDFLAGS=','MACOSX_DEPLOYMENT_TARGET=13.0','DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer','SDKROOT='+str(SDK),'PYTHONDONTWRITEBYTECODE=1']
    profile='(version 1)(allow default)(deny network* (remote ip) (local ip))' if native else '(version 1)(allow default)(deny network*)'
    return ['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env',*env]


def terminal(run):
    return run['created'] and run['exit_code']==0 and run['error'] is None and not run['observation_errors'] and run['logs_complete'] and run['pins_stable'] and not run['stop_at_exit'] and run['owned']['terminal'] and run['owned']['group_absent'] and not run['owned']['errors']


def pin_once(pins, path, expected=None):
    observed=sha(path);key=str(path);expected=observed if expected is None else expected
    need(observed==expected and (key not in pins or pins[key]==expected),'new or unchanged admitted input '+key)
    pins[key]=expected


def fresh_outputs(*paths):
    need(all(not path.exists() and not path.is_symlink() for path in paths),'fresh nonsymlink build outputs')


def prepare():
    need(not P.exists() and not (W/'plan.json').exists() and not STOP.exists(),'fresh qualification workspace')
    receipt=read(CHECKPOINT/'commit-receipt.json')
    installed=read(CHECKPOINT/'prepare-install.json');need(installed['result']=='PASS_PREPARE-INSTALL'and installed['both_prepared_equal_tested_vector']and not installed['checkout_preparation_pending'],'completed postcommit preparation')
    need(receipt['commit']==HEAD and receipt['both_clean'] and receipt['canonical_promoted'] and not receipt['error'] and not receipt['finalization_errors'],'completed implementation checkpoint')
    source=identity(T);need(identity(C)==source,'source/prepared parity');need(source['prepared']==read(Path('/private/tmp/vellum-event-publication-e96f642/prepare-result.json'))['files'],'checkout matches tested stage0077 reconstruction')
    pins={}
    for root in [T,C]:
        pins.update({str(root/n):h for n,h in source['files'].items()})
        pins.update({str(root/'drivers/cogent/build'/n):h for n,h in source['prepared'].items()})
    tools=[Path(__file__),CHECKPOINT/'commit-receipt.json',CHECKPOINT/'prepare-install.json',PREV/'gpu-provenance.json',PREV/'network-probe.json',LIBRARY,GO,Path('/opt/homebrew/bin/go'),PYTHON,Path('/opt/homebrew/bin/python3'),CLANG,CLANG.parent/'ld',CLANG.parent.parent/'lib/libclang.dylib',SDK/'SDKSettings.json',W.parent/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),Path('/usr/bin/otool'),Path('/usr/bin/sandbox-exec'),W.parent/'macos-source-gpu-sdk-native/run.py',W/'fixtures.py',W/'validators.py',W/'plan-draft.md',Path('/private/tmp/vellum-event-publication-e96f642/prepare-result.json'),Path('/private/tmp/vellum-source-gpu-sdk-native/relocated SDK/vellum-v0.1.0-alpha.2/SDK_MANIFEST.json'),W.parent/'macos-source-gpu-sdk-native/controls.py',W.parent/'macos-source-gpu-sdk-native/controls.json']
    for p in tools:need(p.is_file(),'regular qualification input');pins[str(p)]=sha(p)
    need(sha(LIBRARY)==LIBSHA and read(PREV/'network-probe.json')['result']=='PASS_NETWORK-PROBE','selected archive and direct-IP policy probe')
    P.mkdir(mode=0o700)
    for name in ['temp','go-tmp','go-cache']:(P/name).mkdir(mode=0o700)
    exclusive(W/'source.json',source)
    pins[str(W/'source.json')]=sha(W/'source.json')
    exclusive(W/'plan.json',dict(source_commit=HEAD,inputs=pins,source_files=4738,prepared_files=6250,private_build=True,library_sha256=LIBSHA,archive=str(ARCHIVE),application=str(APP),binary=str(BINARY),linkmap=str(LINKMAP),package_then_build=True,native_separate_review=True,native_cases=CASES,native_argv={name:[str(P/name),'--smoke']for name in CASES},generated_consumer_runtime=False,physical_input_generated=False,settings_changes=False,full_macos_qualified=False))
    print(json.dumps(dict(result='PREPARED_CLEAN_PRIVATE_SDK_QUALIFICATION',source_commit=HEAD,inputs=len(pins),native_runtime_executed=False)))


def certificate(phase):
    path=W/(phase+'-readiness.json');body=path.read_bytes();certificate=json.loads(body);digest=hashlib.sha256(body).hexdigest()
    need(certificate['execution_ready'] is True and not certificate['unresolved_findings'],'separate '+phase+' admission')
    pins=dict(certificate['inputs']);pins[str(path)]=digest
    return pins,digest


def finish(phase, d):
    try:(P/('stop-'+phase)).touch()
    except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__,message=str(error)))
    d['result']=('PASS_' if d['error'] is None and not d['finalization_errors'] else 'FAILED_')+phase.upper()
    d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:print(json.dumps({**{k:v for k,v in d.items() if k not in ['inputs','commands']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
    except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));d['result']='FAILED_'+phase.upper()
    try:exclusive(W/(phase+'.json'),d)
    except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));d['result']='FAILED_'+phase.upper()
    need(d['error'] is None and not d['finalization_errors'],phase+' qualification failed')


def build():
    phase='build';need(not(W/'build.json').exists() and not stopped(phase),'one-shot build')
    pins,review_sha=certificate(phase);admitted_sdk=None
    stable=lambda:all(sha(p)==h for p,h in pins.items())and(admitted_sdk is None or sdk_identity(admitted_sdk[0],admitted_sdk[1])==admitted_sdk[2])
    d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,readiness_sha256=review_sha,commands=[],error=None,finalization_errors=[],native_execution='not_started',public_distribution=False)
    pin=lambda path,expected=None:pin_once(pins,path,expected)
    def command(name,argv,cwd,timeout=180,local_ipc=False):
        run=g.execute(environment(local_ipc)+argv,cwd,P/name,lambda:stopped(phase),stable,timeout=timeout,limit=8<<20)
        d['commands'].append(dict(name=name,run=run));need(terminal(run),'owned build command '+name)
        return (P/name/'stdout').read_bytes()
    try:
        with g.LiveLease() as lease:
            need(lease.held() and stable() and not stopped(phase),'build admission')
            need(identity(T)==identity(C)==read(W/'source.json'),'current framework parity')
            fresh_outputs(ARCHIVE,APP,BINARY,LINKMAP)
            package=json.loads(command('package',[str(PYTHON),'-B',str(T/'scripts/release-sdk.py'),'--output',str(ARCHIVE),'--macos-gpu-library',str(LIBRARY),'--macos-gpu-sha256',LIBSHA,'--macos-gpu-provenance',str(PREV/'gpu-provenance.json')],T,900))
            need(package['modules']==89,'same Go inventory module count');need(package['private_build'] is True and package['sha256']==sha(ARCHIVE),'package exact identity')
            pin(ARCHIVE,package['sha256'])
            verified=checker.verify_archive(ARCHIVE,package['sha256']);manifest=verified['manifest']
            need(manifest['source']==dict(clean=True,commit=HEAD) and manifest['private_build'] is True and len(manifest['files'])==7441 and manifest['native_gpu']['files']['arm64/libwgpu_native.a']==LIBSHA,'clean private SDK endpoint')
            sdk=checker.extract_verified(ARCHIVE,P/'relocated SDK',verified)
            sdk_files={n:sha(sdk/n) for n in manifest['files']};need(sdk_files==manifest['files'],'retained SDK file hashes');admitted_sdk=(sdk,manifest,sdk_identity(sdk,manifest))
            for name,h in sdk_files.items():pin(sdk/name,h)
            pin(sdk/'SDK_MANIFEST.json')
            d.update(sdk_root=str(sdk),archive=dict(bytes=ARCHIVE.stat().st_size,sha256=sha(ARCHIVE)),sdk_files=len(sdk_files),sdk_source=manifest['source'],native_gpu=manifest['native_gpu'])
            d['source_sdk_reconciliation']=fixture_module().verify_sources(sdk,manifest,pin)
            relocated=json.loads(command('relocation-check',[str(PYTHON),'-B',str(T/'scripts/check-sdk.py'),'--archive',str(ARCHIVE),'--sha256',package['sha256']],T,900,local_ipc=True))
            need(relocated['event']=='vellum.sdk.relocated'and relocated['source']==dict(clean=True,commit=HEAD)and relocated['verified_files']==7441 and relocated['native_runtime']=='not executed'and relocated['digest_verified_against_expected'],'relocated consumer/public API checks')
            d['relocated_check']=relocated
            fresh_outputs(APP)
            command('generate',[str(PYTHON),'-B',str(sdk/'scripts/new-app.py'),str(APP),'--module','example.com/vellum-sdk-native-check'],P,60)
            app_files={str(p):sha(p) for p in APP.iterdir() if p.is_file()};need(len(app_files)==6 and not any(p.is_symlink() for p in APP.iterdir()),'six regular generated files')
            for name,h in app_files.items():pin(name,h)
            d['generated_files']=app_files
            modules=checker.decode_objects(command('modules',[str(GO),'list','-mod=readonly','-m','-json','all'],APP).decode())
            d['module_origins']=checker.check_origin(modules,sdk,gpu=manifest['native_gpu'])
            packages=checker.decode_objects(command('sources',[str(GO),'list','-mod=readonly','-deps','-json','.'],APP).decode())
            need(packages and not any(p.get('Incomplete') or p.get('Error') or p.get('DepsErrors') for p in packages),'complete consumer package graph')
            fields=['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles']
            for package in packages:
                directory=Path(package['Dir']) if package.get('Dir') else None
                for field in fields:
                    for name in package.get(field,[]):
                        p=Path(name) if Path(name).is_absolute() else directory/name
                        need(p.is_file(),'listed consumer input');pin(p)
                module=package.get('Module') or {};module=module.get('Replace') or module
                if module.get('GoMod'):pin(module['GoMod'])
            d['consumer_packages']=len(packages)
            fresh_outputs(BINARY,LINKMAP)
            command('compile',[str(GO),'build','-mod=readonly','-p=2','-buildvcs=false','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(LINKMAP),'-o',str(BINARY),'.'],APP,600)
            need(BINARY.is_file() and not BINARY.is_symlink() and 0<BINARY.stat().st_size<128<<20 and LINKMAP.is_file() and not LINKMAP.is_symlink(),'bounded retained build pair')
            pin(BINARY);pin(LINKMAP)
            links=command('links',['/usr/bin/otool','-L',str(BINARY)],P,30).decode()
            need('libwgpu_native' not in links,'no WGPU runtime library dependency')
            load=command('load',['/usr/bin/otool','-l',str(BINARY)],P,30).decode();need('minos 13.0' in load,'minimum macOS13 observed')
            info=json.loads(command('metadata',[str(GO),'version','-m','-json',str(BINARY)],P,30));settings={}
            for item in info['Settings']:
                need(set(item)<={'Key','Value'} and item['Key'] not in settings and type(item.get('Value','')) is str,'typed unique build setting')
                settings[item['Key']]=item.get('Value','')
            need(info['GoVersion']=='go1.27.2' and info['Path']=='example.com/vellum-sdk-native-check' and all(settings.get(k)==v for k,v in dict(GOOS='darwin',GOARCH='arm64',CGO_ENABLED='1').items()) and 'vcs.revision' not in settings,'independent native consumer metadata')
            gpu_replacements=[m.get('Replace',{}).get('Path') for m in info.get('Deps',[]) if m['Path']=='github.com/oliverbestmann/webgpu/libs-darwin']
            need(gpu_replacements==[str(sdk/'drivers/cogent/build/libs-darwin')],'embedded SDK GPU module lineage')
            with BINARY.open('rb') as stream:header=stream.read(32)
            need(len(header)==32 and struct.unpack_from('<I',header)[0]==0xFEEDFACF and struct.unpack_from('<I',header,4)[0]==0x0100000C and struct.unpack_from('<I',header,12)[0]==2,'thin ARM64 MH_EXECUTE header')
            library=sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'
            archive_record=native_archive.archive_members(library);map_record=native_archive.linker_objects(LINKMAP)
            selected=native_archive.selected_archive_members(map_record,library,archive_record)
            native_entries=[n for n in map_record['objects'] if 'libwgpu_native' in n]
            need(archive_record['sha256']==LIBSHA and map_record['architecture']=='arm64' and selected and len(native_entries)==len(selected),'only exact SDK static archive object entries')
            d.update(binary=dict(path=str(BINARY),bytes=BINARY.stat().st_size,sha256=sha(BINARY),go_version=info['GoVersion'],target='darwin-arm64',minimum_macos='13.0',static_archive_entries=len(selected),dynamic_wgpu_dependency=False),linkmap=dict(path=str(LINKMAP),bytes=LINKMAP.stat().st_size,sha256=sha(LINKMAP)),selected_archive_members=selected)
            d['fixtures']=fixture_module().build(sdk,command,pin)
            sdk_identity(sdk,manifest)
            need(stable() and identity(T)==identity(C)==read(W/'source.json') and not stopped(phase) and lease.held(),'terminal build/source closure')
    except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
    finally:finish(phase,d)




def fixture_module():
    spec=importlib.util.spec_from_file_location('current_sdk_fixtures',W/'fixtures.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.h=sys.modules[__name__]
    return module

if __name__=='__main__':
    need(sys.argv[1:]in[['prepare'],['build']]+[['native',name]for name in CASES],'fixed SDK phase')
    if sys.argv[1]=='native':fixture_module().native(sys.argv[2])
    else:{'prepare':prepare,'build':build}[sys.argv[1]]()
