"""Private SDK test host: keep Python-created descendants in one owned group.

This tests SDK consumption under outer-controller supervision; it does not
qualify standalone SDK helper cancellation or change installed/source files.
"""
from pathlib import Path
import os,runpy,subprocess,sys

def main():
    if os.getpid()!=os.getpgrp():raise ValueError('new outer-controller process group required')
    script=Path(sys.argv[1]).resolve(strict=True)
    allowed={Path('/private/tmp/vellum-macos-native-results-97aee13/scripts')/name for name in ['release-sdk.py','check-sdk.py']}
    allowed.add(Path('/private/tmp/vellum-gpu-sdk-stage0077/relocated SDK/vellum-v0.1.0-alpha.2/scripts/new-app.py'))
    allowed.add(Path(__file__).resolve().parent/'grouped_stop_fixture.py')
    if script not in allowed or not script.is_file():raise ValueError('exact planned SDK entrypoint required')
    original=subprocess.Popen
    def inherited_group(*args,**kwargs):
        if len(args)!=1 or kwargs.get('preexec_fn')is not None or kwargs.get('process_group')is not None or kwargs.get('creationflags',0)or kwargs.get('shell',False):
            raise ValueError('only planned argv children with inherited group are supported')
        kwargs['start_new_session']=False
        return original(*args,**kwargs)
    subprocess.Popen=inherited_group
    sys.argv=sys.argv[1:];sys.argv[0]=str(script);sys.path.insert(0,str(script.parent))
    try:runpy.run_path(str(script),run_name='__main__')
    finally:subprocess.Popen=original
if __name__=='__main__':main()
