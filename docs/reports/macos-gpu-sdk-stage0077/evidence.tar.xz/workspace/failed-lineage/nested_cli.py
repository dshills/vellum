"""Let the SDK child's existing exception cleanup handle controller cancellation."""
from pathlib import Path
import runpy,signal,sys

def interrupted(signum,frame):
    raise KeyboardInterrupt('owned SDK controller signal '+str(signum))

def main():
    script=Path(sys.argv[1]).resolve(strict=True)
    if not script.is_file():raise ValueError('regular planned SDK entrypoint required')
    old={s:signal.signal(s,interrupted)for s in [signal.SIGTERM,signal.SIGINT]}
    sys.argv=sys.argv[1:];sys.argv[0]=str(script);sys.path.insert(0,str(script.parent))
    try:runpy.run_path(str(script),run_name='__main__')
    finally:
        for signum,handler in old.items():signal.signal(signum,handler)
if __name__=='__main__':main()
