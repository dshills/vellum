"""Three actual headless process-group controls, including creation and held cleanup."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-gpu-sdk-stage0077');C=P/'grouped-cancellation-controls'
s=importlib.util.spec_from_file_location('sdk_group_control_runtime',W/'control-runtime.py');h=importlib.util.module_from_spec(s);sys.modules[s.name]=h;s.loader.exec_module(h)
def main():
    h.need(not C.exists()and not(W/'grouped-stop-controls.json').exists()and not h.STOP.exists(),'fresh grouped controls')
    C.mkdir(mode=0o700)
    paths=[Path(__file__),W/'grouped_cli.py',W/'grouped_stop_fixture.py',W/'control-runtime.py',h.T/'scripts/child_process.py',W.parent/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),h.PYTHON,Path('/usr/bin/sandbox-exec')]
    pins={str(p):h.sha(p)for p in paths};stable=lambda:all(h.sha(p)==digest for p,digest in pins.items())
    d=dict(result='INCOMPLETE',inputs=pins,cases=[],native_runtime_executed=False,compiler_executed=False,error=None)
    try:
        with h.g.LiveLease()as lease:
            h.need(lease.held()and stable()and not h.STOP.exists(),'control admission')
            for mode in ['communicating','creation-before-try','held-cleanup']:
                root=C/mode;root.mkdir(mode=0o700);armed=root/'armed.json'
                run=h.g.execute(h.environment()+[str(h.PYTHON),'-B',str(W/'grouped_cli.py'),str(W/'grouped_stop_fixture.py'),mode,str(root)],P,root/'wrapper',lambda:armed.exists()or h.STOP.exists(),stable,timeout=15,limit=1<<20)
                case=dict(mode=mode,run=run);d['cases'].append(case)
                h.need(armed.is_file()and not armed.is_symlink(),'own nested identity recorded');record=h.read(armed);case['nested']=record
                h.need(record['mode']==mode and record['parent']==run['pid']and record['group']==run['group']and type(record['pid'])is int and record['pid']>1 and record['pid']!=run['pid'],'child belongs to exact owned group')
                case['absence']=h.g.absent(run['group'])
                h.need(run['created']and run['error']==dict(type='ValueError',message='stop requested')and run['stop_at_exit']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'expected deliberate stopped endpoint')
                if mode=='held-cleanup':
                    case['cleanup_entered']=h.read(root/'cleanup-entered.json');h.need(case['cleanup_entered']==dict(pid=record['pid'],group=run['group'])and run['owned']['exit_code']==-9,'force kill covers held cleanup past TERM grace')
                h.need(stable()and lease.held()and not h.STOP.exists(),'control terminal closure')
            d['result']='PASS_THREE_ACTUAL_GROUPED_CANCELLATION_CONTROLS'
    except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error));raise
    finally:
        h.exclusive(W/'grouped-stop-controls.json',d);print(json.dumps(dict(result=d['result'],cases=len(d['cases']),native_runtime_executed=False,compiler_executed=False,error=d['error'])),flush=True)
if __name__=='__main__':main()
