"""Actual controlled process states; all descendants inherit the owned outer PGID."""
from pathlib import Path
import json,os,signal,sys,time
sys.dont_write_bytecode=True
sys.path.insert(0,'/private/tmp/vellum-macos-native-results-97aee13/scripts')
import child_process
mode=sys.argv[1];root=Path(sys.argv[2]);armed=root/'armed.json';ready=root/'child-ready.json'
if mode not in ['communicating','creation-before-try','held-cleanup']:raise ValueError('fixed control mode')
def write(path,value):
    pending=path.with_suffix('.pending');pending.write_text(json.dumps(value));os.replace(pending,path)
def arm(process):
    deadline=time.monotonic()+3
    while not ready.exists():
        if time.monotonic()>deadline:raise TimeoutError('controlled child readiness')
        time.sleep(.01)
    record=json.loads(ready.read_bytes())
    if record!={'pid':process.pid,'group':os.getpgrp()}:raise ValueError('inherited nested group required')
    write(armed,dict(mode=mode,parent=os.getpid(),pid=process.pid,group=record['group']))
original=child_process.subprocess.Popen

def tracked(*args,**kwargs):
    process=original(*args,**kwargs)
    if mode=='creation-before-try':
        arm(process);time.sleep(45) # Inside Popen wrapper, before SDK run_child enters try.
    else:
        communicate=process.communicate
        def entered(*a,**kw):
            arm(process);return communicate(*a,**kw)
        process.communicate=entered
    return process
child_process.subprocess.Popen=tracked
if mode=='held-cleanup':
    def interrupted(signum,frame):raise KeyboardInterrupt('controlled TERM')
    signal.signal(signal.SIGTERM,interrupted)
    def held(process):
        write(root/'cleanup-entered.json',dict(pid=process.pid,group=os.getpgrp()));time.sleep(45)
    child_process.terminate_owned_group=held
child="import json,os,signal,sys,time;from pathlib import Path;signal.signal(signal.SIGTERM,signal.SIG_IGN);p=Path(sys.argv[1]);q=p.with_suffix('.pending');q.write_text(json.dumps(dict(pid=os.getpid(),group=os.getpgrp())));os.replace(q,p);time.sleep(45)"
child_process.run_child([sys.executable,'-B','-c',child,str(ready)],timeout=30,check=True)
