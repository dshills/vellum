# Private current SDK verification

Run only after the event-publication checkpoint is committed and both checkouts
have the tested 6250-file dependency vector. Package a private SDK from the clean
new source; retain the existing exact source-built ARM64 static GPU archive.
Verify archive membership/hashes, all source/prepared counterparts and the eleven
explicit module overlays. Require exactly 7441 payload files: the retained baseline member set plus four
stage-0077 patch metadata/source leaves and one prepared regression leaf. Run the existing relocated generated-consumer
and public API race/vet/build verifier. Retain a separate extraction with spaces
in its path, and build/test/vet drawing, viewport3d and imaging against only that
SDK's five module origins. Preserve executable/linker-map/static archive identities.

Admit native cases separately after build review. Execute those three smoke
fixtures serially, under the existing owned-process executor, shared lease, global
stop marker, bounded logs/watchdogs and IP denial with Unix IPC allowed. Validate
existing source-specific summaries. No physical input, settings changes, public
release or performance/memory qualification is implied. No new Prism call is
planned for source-unchanged SDK packaging evidence.

Only the existing relocated public API checker receives Unix IPC permission during
build, because its transport regression binds a local Unix socket. All IP traffic
remains denied. Packaging and the other direct build commands retain deny-all
network. Native fixtures use the established IP-deny/Unix-allow profile. SDK
member sets and hashes are rechecked at each direct command launch and terminal
check after extraction; the retained executor does not poll those identities
continuously.

The three Python CLI entrypoints run through grouped_cli.py. The fixed SDK
graph's Python-created descendants inherit the outer controller's one process
group. Three actual headless controls verify termination during communication,
inside Popen before the SDK helper's try, and while cleanup is blocked; each
includes a TERM-ignoring child and strict total group absence. Held cleanup
requires the outer forced kill. This hosts functional SDK checks under outer
supervision, and does not qualify standalone SDK helper timeouts or arbitrary
programs that leave their group. Normal argv and sibling imports are preserved.
The SDK scripts use their production child environment, including configured
proxy/SumDB values; the OS sandbox blocks IP networking and execution uses cached
dependencies. No claim that all nested CLI environments have GOPROXY=off is made.
