"""One actual owned cancellation control; no native app or compiler execution."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-gpu-sdk-stage0077');C=P/'nested-cancellation-control'
s=importlib.util.spec_from_file_location('current_owned_sdk_control',W/'run.py');h=importlib.util.module_from_spec(s);sys.modules[s.name]=h;s.loader.exec_module(h)
def main():
    h.need(not C.exists()and not(W/'nested-stop-control.json').exists()and not h.STOP.exists(),'fresh actual cancellation control')
    C.mkdir(mode=0o700);record=C/'nested.json'
    paths=[Path(__file__),W/'nested_cli.py',W/'nested_stop_fixture.py',W/'run.py',h.T/'scripts/child_process.py',W.parent/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),h.PYTHON,Path('/usr/bin/sandbox-exec')]
    pins={str(p):h.sha(p)for p in paths};stable=lambda:all(h.sha(p)==digest for p,digest in pins.items())
    d=dict(result='INCOMPLETE',inputs=pins,native_runtime_executed=False,compiler_executed=False,error=None)
    try:
        with h.g.LiveLease()as lease:
            h.need(lease.held()and stable()and not h.STOP.exists(),'control admission')
            run=h.g.execute(h.environment()+[str(h.PYTHON),'-B',str(W/'nested_cli.py'),str(W/'nested_stop_fixture.py'),str(record)],P,C/'wrapper',lambda:record.exists()or h.STOP.exists(),stable,timeout=15,limit=1<<20)
            d['run']=run;h.need(record.is_file()and not record.is_symlink(),'own nested child identity')
            nested=h.read(record);h.need(type(nested.get('pid'))is int and nested['pid']>1 and nested['group']==nested['pid']and nested['pid']!=run['pid'],'separate own nested group')
            d['nested']=nested;d['nested_absence']=h.g.absent(nested['group'])
            h.need(run['created']and run['error']==dict(type='ValueError',message='stop requested')and run['stop_at_exit']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'expected owned stop endpoint')
            h.need(stable()and lease.held()and not h.STOP.exists(),'control terminal closure');d['result']='PASS_ACTUAL_NESTED_CANCELLATION'
    except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error));raise
    finally:
        h.exclusive(W/'nested-stop-control.json',d);print(json.dumps({k:v for k,v in d.items()if k not in ['inputs','run']}),flush=True)
if __name__=='__main__':main()
