"""Native-summary admission controls; these never execute a native consumer."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('advanced_controls',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
checks=[]
drawing=dict(event='vellum.drawing.smoke',geometry_persistence_disabled_in_fixture=True,schematic_source_objects=100000,waveform_source_samples=1000000,retained_image=dict(initial_tiles=1024,changed_tiles=1,changed_upload_bytes=65536))
for key in ['gradient_and_linear_alpha_pixels','transparent_snapshot','static_pan_retains_mesh','independent_windows','empty_frame_clear','budget_refusal','error_callback_resource_query','resource_rebuild','repeated_resize']:drawing[key]=True
viewport=dict(event='vellum.viewport3d.smoke',geometry_persistence_disabled_in_fixture=True,result='pass',independentBufferNamespaces=True,orbitPixelsChanged=True)
def encode(r):return(json.dumps(r)+'\n').encode()
diagnostics={'drawing':b'budget exceeded\n','viewport3d':b'budget exceeded\ncontrolled preparation failure\ncontrolled draw failure\n'}
for name,base in [('drawing',drawing),('viewport3d',viewport)]:
 assert m.validate(name,encode(base),diagnostics[name])==base;checks.append(name+' exact summary accepted')
 for label,changed,stderr in [
  ('missing geometry flag',{k:v for k,v in base.items()if k!='geometry_persistence_disabled_in_fixture'},diagnostics[name]),
  ('false geometry flag',dict(base,geometry_persistence_disabled_in_fixture=False),diagnostics[name]),
  ('numeric geometry flag',dict(base,geometry_persistence_disabled_in_fixture=1),diagnostics[name]),
  ('foreign event',dict(base,event='foreign'),diagnostics[name]),
  ('missing expected diagnostic',base,b''),
  ('unknown extra diagnostic',base,diagnostics[name]+b'unexpected failure\n')]:
  try:m.validate(name,encode(changed),stderr)
  except ValueError:checks.append(name+' refuses '+label)
  else:raise AssertionError(label)
 try:m.validate(name,encode(base)*2,diagnostics[name])
 except ValueError:checks.append(name+' refuses duplicate summaries')
 else:raise AssertionError('duplicate')
for label,record,stderr in [
 ('wrong retained tile byte count',dict(drawing,retained_image=dict(initial_tiles=1024,changed_tiles=1,changed_upload_bytes=1)),diagnostics['drawing']),
 ('overlapping diagnostic coverage cannot hide an unrelated line',viewport,b'budget exceeded\ncontrolled preparation and controlled draw\nunexpected failure\n'),
 ('failed viewport result',dict(viewport,result='fail'),diagnostics['viewport3d'])]:
 name='drawing'if 'tile'in label else'viewport3d'
 try:m.validate(name,encode(record),stderr)
 except ValueError:checks.append('refuses '+label)
 else:raise AssertionError(label)
record=dict(result='PASS_ADVANCED_SUMMARY_CONTROLS',count=len(checks),checks=checks,runner_sha256=m.sha(W/'run.py'),producer_sha256=m.sha(__file__),native_executed=False,guard_source_reused=str(m.OLD/'run.py'))
with(W/'controls.json').open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(result=record['result'],count=record['count'])))
