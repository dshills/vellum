"""Isolate public drawing/3D smoke geometry without changing interactive runs."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='8e88634187f1ce9c80bc8d79858225faa13d2e7d'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
def main():
 for root in [T,C]:assert git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain','-z')
 paths=[f'examples/{example}/{name}'for example in ['drawing','viewport3d']for name in ['main.go','smoke.go','README.md']]+['specs/drawing.md','specs/advanced-gpu.md'];before={}
 for name in paths:
  p=W/'original'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes());before[name]=sha(T/name)
 for example in ['drawing','viewport3d']:
  p=T/f'examples/{example}/main.go';text=p.read_text();needle='\tflag.Parse()\n';assert text.count(needle)==1
  text=text.replace(needle,needle+'''\tif *smoke {
\t\t// Fixture windows must neither load nor save user geometry. Keep this
\t\t// process-local setting through application and native window teardown.
\t\tpreviousGeometrySaver := core.DebugSettings.DisableWindowGeometrySaver
\t\tcore.DebugSettings.DisableWindowGeometrySaver = true
\t\tdefer func() { core.DebugSettings.DisableWindowGeometrySaver = previousGeometrySaver }()
\t}
''',1)
  if '"cogentcore.org/core/core"'not in text:text=text.replace('import (\n','import (\n\t"cogentcore.org/core/core"\n',1)
  p.write_text(text)
  p=T/f'examples/{example}/smoke.go';text=p.read_text();text=text.replace('import (\n','import (\n\t"cogentcore.org/core/core"\n',1)
  if example=='drawing':text=text.replace('"event": "vellum.drawing.smoke",','"event": "vellum.drawing.smoke", "geometry_persistence_disabled_in_fixture": core.DebugSettings.DisableWindowGeometrySaver,',1)
  else:text=text.replace('report := map[string]any{','report := map[string]any{"event": "vellum.viewport3d.smoke", "geometry_persistence_disabled_in_fixture": core.DebugSettings.DisableWindowGeometrySaver,',1)
  p.write_text(text)
  p=T/f'examples/{example}/README.md';text=p.read_text();text+='''
The `--smoke` fixture disables native window-geometry loading and saving before
constructing the application and keeps that process-local setting through teardown.
It restores the prior process value on normal return; ordinary interactive runs
retain their usual geometry behavior. The JSON result reports the observed
`geometry_persistence_disabled_in_fixture` flag. This isolates fixture windows
from saved user geometry and avoids persisting the deliberate resize sequence.
''';p.write_text(text)
 for name in ['specs/drawing.md','specs/advanced-gpu.md']:
  p=T/name;p.write_text(p.read_text()+'''
## Isolated native smoke geometry

The independent example's `--smoke` mode disables backend window-geometry loading
and saving before creating the application. The process-local setting remains
active through native teardown and restores its prior value on normal return.
Interactive mode retains the normal persistence behavior. The smoke result emits
its actual `geometry_persistence_disabled_in_fixture` flag, so external validation
can reject a run that did not isolate fixture geometry. Geometry isolation does
not establish physical input, compositor presentation, native/GPU memory, sustained
performance or complete Mac acceptance.
''')
 gofiles=[str(T/name)for name in paths if name.endswith('.go')]
 subprocess.run(['/opt/homebrew/bin/gofmt','-w',*gofiles],check=True,timeout=30)
 after={name:sha(T/name)for name in paths}
 for name in paths:
  p=W/'draft'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
 with(W/'source-binding.json').open('x')as out:out.write(json.dumps(dict(base_commit=HEAD,before=before,after=after),indent=2)+'\n')
 assert set(git(T,'diff','--name-only').decode().splitlines())==set(paths)
 print(json.dumps(dict(result='IMPLEMENTED_SMOKE_GEOMETRY_ISOLATION',changed_files=len(paths))))
if __name__=='__main__':main()
