from pathlib import Path
import hashlib,json,subprocess,shutil
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-advanced-native-8e88634';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.loads((OLD/'source-binding.json').read_text());assert all(sha(T/n)==h for n,h in b['after'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip()==b['base_commit']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=T)
shutil.copytree(OLD/'original',W/'original')
for name in b['after']:
 p=W/'prediagnostic'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
p=T/'examples/viewport3d/smoke.go';s=p.read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,old;s=s.replace(old,new)
anchor='\tif err := owner(a, func() error {\n\t\tif m.vertices == otherModel.vertices'
block='\t// Observe only the independent adapter; retain the original first-ready\n\t// baseline and exact failure predicate while diagnosing its lifetime.\n\ttype independentObservation struct {\n\t\tPhase string\n\t\tStats cogent.GPUViewStats\n\t\tRevision uint64\n\t\tModelGeneration uint64\n\t\tModelReleases int\n\t}\n\tvar observations []independentObservation\n\tobserveOther := func(phase string) error {\n\t\treturn owner(a, func() error {\n\t\t\tstats, e := other.Stats()\n\t\t\tif e != nil { return e }\n\t\t\tobservations = append(observations, independentObservation{phase, stats, other.Revision, otherModel.generation, otherModel.releases})\n\t\t\treturn nil\n\t\t})\n\t}\n\tif err := observeOther("initial-depth-readbacks"); err != nil { return err }\n'
replace(anchor,block+anchor)
replace('\tif initial.BufferBytes != 880', '\tif err := observeOther("chrome"); err != nil { return err }\n\tif initial.BufferBytes != 880')
replace('\tif err := owner(a, func() error { g.MaxGPUBytes = 1;', '\tif err := observeOther("camera-reset"); err != nil { return err }\n\tif err := owner(a, func() error { g.MaxGPUBytes = 1;')
replace('\tlast := resetCamera', '\tif err := observeOther("budget-refusal"); err != nil { return err }\n\tlast := resetCamera')
replace('\t\tlast = repaired', '\t\tif err := observeOther(phase+"-repaired"); err != nil { return err }\n\t\tlast = repaired')
replace('\tfor _, size := range []image.Point', '\tif err := observeOther("resource-rebuild"); err != nil { return err }\n\tfor _, size := range []image.Point')
replace('\t\tif last.Size == before.Size', '\t\tif err := observeOther(fmt.Sprintf("primary-resize-%dx%d", size.X, size.Y)); err != nil { return err }\n\t\tif last.Size == before.Size')
replace('\tvar otherAfter cogent.GPUViewStats', '\tif err := observeOther("primary-cleared"); err != nil { return err }\n\tvar otherAfter cogent.GPUViewStats')
replace('return fmt.Errorf("first-window changes affected independent resources")', 'body, e := json.Marshal(observations)\n\t\t\tif e != nil { return e }\n\t\t\treturn fmt.Errorf("first-window changes affected independent resources: initial=%+v final=%+v observations=%s", independent, otherAfter, body)')
replace('"independent": otherAfter,', '"independent": otherAfter, "independent_observations": observations,')
p.write_text(s)
subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(p)],check=True)
for name in b['after']:
 p=W/'draft'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
result=dict(base_commit=b['base_commit'],before=b['before'],after={n:sha(T/n)for n in b['after']},diagnostic_only=True,prior_failed_source_binding_sha256=sha(OLD/'source-binding.json'))
(W/'source-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(result='DIAGNOSTIC_OBSERVATIONS_INSTALLED',changed_from_failed_fixture=['examples/viewport3d/smoke.go'],assertion_weakened=False,native_started=False)))
