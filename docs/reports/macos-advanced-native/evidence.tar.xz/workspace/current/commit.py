"""Commit isolated native GPU fixtures and joint startup baseline; integrate canonical checkout."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');B=W
spec=importlib.util.spec_from_file_location('commit_guard',W.parent/'macos-grid-native-stacks/commit-pending.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W
sha=m.sha;git=m.git
def prepared(root):
 out={}
 for module in ['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/module).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():out[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 return out
assert not(W/'commit-receipt.json').exists()
d=dict(result='INCOMPLETE',mutations=[],error=None)
try:
 b=json.loads((W/'binding.json').read_bytes());r=json.loads((W/'final-review.json').read_bytes());assert r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
 assert git(T,'rev-parse','HEAD').decode().strip()==b['base_commit']==git(C,'rev-parse','HEAD').decode().strip()
 assert git(T,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/macos-native-results'and git(C,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/foundation-completion'
 assert m.clean(C)and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
 assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources'])
 assert all(sha(T/p)==h for p,h in b['sources'].items())and hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256']
 original_prepared={str(Path(p).relative_to(T/'drivers/cogent/build')):h for p,h in json.loads((B/'build-readiness.json').read_bytes())['inputs'].items()if Path(p).is_relative_to(T/'drivers/cogent/build')};assert prepared(T)==original_prepared
 admissions={name:m.git_admission(root)for name,root in [('candidate',T),('canonical',C)]};d['git_admission']=admissions
 message=W/'commit-message.txt';message.write_text('fix(examples): isolate native GPU fixtures and settle startup targets\n\nDisable saved geometry only in drawing/viewport3d smoke mode and report observed isolation. Establish a joint stable initial frame pair before capturing both retention baselines; keep all later GPU/depth/resource/closure assertions and bounded diagnostics.\n\nAdd deterministic startup/readiness regressions and retain original native failures beside current-source native results, exact private ARM64 static linkage and one Anthropic Claude Sonnet 5.5 Prism checkpoint. Keep physical interaction, presentation, latency/memory/endurance and complete Mac release qualification open.\n')
 assert m.git_admission(T)==admissions['candidate']and m.git_admission(C)==admissions['canonical']
 m.mutation(T,'source-commit',['git','commit','--file',str(message)],d)
 commit=git(T,'rev-parse','HEAD').decode().strip();assert git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit']and m.clean(T)
 assert set(git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources'])
 assert m.clean(C)and git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==admissions['canonical']
 m.mutation(C,'canonical-fast-forward',['git','merge','--ff-only',commit],d)
 names=git(T,'ls-files','-z').decode().split('\0')[:-1];assert len(names)==b['source_files']==4730
 assert all(sha(T/name)==sha(C/name)for name in names)and prepared(T)==prepared(C)==original_prepared and len(original_prepared)==6249
 assert m.clean(T)and m.clean(C)and git(C,'rev-parse','HEAD').decode().strip()==commit
 d.update(result='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED',commit=commit,parent=b['base_commit'],both_clean=True,canonical_promoted=True,source_files=len(names),prepared_files=len(original_prepared),native_runtime_executed_by_commit_controller=False,review_sha256=sha(W/'final-review.json'),binding_sha256=sha(W/'binding.json'))
except BaseException as e:
 d['error']=dict(type=type(e).__name__,message=str(e));raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['producer_sha256']=sha(__file__);observation_failed=False
 for name,root in [('canonical',C),('candidate',T)]:
  try:d[name+'_observation']=m.observation(root)
  except BaseException as e:d[name+'_observation_error']=dict(type=type(e).__name__,message=str(e));observation_failed=True
 if observation_failed:d.update(pre_terminal_result=d['result'],result='FAILED_TERMINAL_OBSERVATION',both_clean=False,canonical_promoted_unverified=True)
 d['finalization_errors']=[]
 def finalization_failed(stage,error):
  d['finalization_errors'].append(dict(stage=stage,type=type(error).__name__,message=str(error)));d.setdefault('pre_finalization_result',d['result']);d['result']='FAILED_TERMINAL_FINALIZATION'
 try:print(json.dumps({**{k:v for k,v in d.items()if k!='git_admission'},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
 except BaseException as error:finalization_failed('report',error)
 try:
  with (W/'commit-receipt.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
 except BaseException as error:finalization_failed('exclusive-receipt',error)
 if d['finalization_errors']and d['error']is None:raise RuntimeError('commit controller finalization failed; preserve mutation observations and receipt when present')
 if observation_failed and d['error']is None:raise RuntimeError('terminal checkout observation failed; see exclusive receipt')
