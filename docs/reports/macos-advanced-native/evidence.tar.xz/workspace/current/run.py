"""Current public drawing/3D consumers of the exact source-built private GPU archive."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-viewport-startup-8e88634');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='8e88634187f1ce9c80bc8d79858225faa13d2e7d'
OLD=W.parent/'macos-source-gpu-sdk-native';spec=importlib.util.spec_from_file_location('advanced_owned_parent',OLD/'run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
need,sha,read,g=h.need,h.sha,h.read,h.g
need(sha(OLD/'run.py')=='d995d9d2b4ca70ba98c8bdc753c550925cd0ca063a06b96438c76157c082c0f7','unchanged validated parent guard')
h.W,h.P=W,P
SDK=Path(read(OLD/'build.json')['sdk_root']);LIB=SDK/'drivers/cogent/build/libs-darwin';LIBSHA='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
CASES=['viewport3d'];GO=h.GO
ROOTS={'github.com/dshills/vellum':T,'github.com/dshills/vellum/drivers/cogent':T/'drivers/cogent','cogentcore.org/core':T/'drivers/cogent/build/upstream','github.com/go-text/typesetting':T/'drivers/cogent/build/typesetting','github.com/oliverbestmann/webgpu/libs-darwin':LIB}
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
def status():
 need(all(git(root,'rev-parse','HEAD').decode().strip()==HEAD for root in [T,C]),'unchanged source HEADs')
 need(not git(C,'status','--porcelain','-z') and not git(T,'ls-files','--others','--exclude-standard'),'clean canonical/no unexpected sources')
 binding=read(W/'source-binding.json');need(set(git(T,'diff','HEAD','--name-only').decode().splitlines())==set(binding['after']),'only intended source changes')
 need(all(sha(T/n)==v and sha(C/n)==binding['before'][n]for n,v in binding['after'].items()),'reviewed geometry source bytes')
def stopped(phase):return h.STOP.exists() or(P/('stop-'+phase)).exists()
def command(args,native=False):return h.environment(native)+['GORACE=halt_on_error=1 exitcode=66 atexit_sleep_ms=0',*args]
def prepare():
 need(not P.exists() and not(W/'plan.json').exists() and not h.STOP.exists(),'fresh advanced consumers')
 review=read(W/'source-review.json');need(not review['unresolved_findings'],'source review resolved')
 status();names=git(C,'ls-files','-z').decode().split('\0')[:-1];need(names==git(T,'ls-files','-z').decode().split('\0')[:-1] and len(names)==4726,'source counts')
 pins={}
 for root in [C,T]:
  for name in names:
   p=root/name;need(p.is_file()and not p.is_symlink(),'regular source');pins[str(p)]=sha(p)
  hidden=git(root,'ls-files','-v','-z').decode().split('\0');need(not[n for n in hidden if n and(n[0].islower()or n[0]=='S')],'no hidden source changes')
 prepared={}
 for root in [C,T]:
  vector={}
  for name in ['upstream','typesetting']:
   for p in(root/'drivers/cogent/build'/name).rglob('*'):
    need(not p.is_symlink(),'prepared symlink')
    if p.is_file():vector[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p);pins[str(p)]=sha(p)
  need(len(vector)==6249 and(not prepared or vector==prepared),'equal prepared input vectors');prepared=vector
 manifest=read(SDK/'SDK_MANIFEST.json');need(manifest['source']==dict(clean=True,commit='3da753ed4e49ef18ca5ef2377c171efb970b46a1'),'retained clean SDK identity')
 for name,digest in h.sdk_identity(SDK,manifest).items():pins[str(SDK/name)]=digest
 need(sha(LIB/'arm64/libwgpu_native.a')==LIBSHA,'exact source-built static archive')
 # Every compiled framework/prepared counterpart comes from the same SDK payload;
 # only the separately bound example fixture sources are changed here.
 prefixes=('app/','automation/','ui/','canvas/','command/','history/','document/','editor/','execution/','replay/','tasks/','virtual/','workbench/','drivers/cogent/')
 counterparts=0
 for name,digest in manifest['files'].items():
  if name.startswith(prefixes) and not name.startswith('drivers/cogent/build/libs-darwin/'):
   expected=manifest['native_gpu']['go_mod_overlays'].get(name,{}).get('source_sha256',digest)
   need((T/name).is_file() and sha(T/name)==expected,'SDK/current framework counterpart '+name);counterparts+=1
 tools=[Path(__file__),W/'source-binding.json',W/'source-review.json',OLD/'run.py',OLD/'build.json',OLD/'native.json',GO,Path('/opt/homebrew/bin/go'),h.PYTHON,h.CLANG,h.CLANG.parent/'ld',h.CLANG.parent.parent/'lib/libclang.dylib',h.SDK/'SDKSettings.json',W.parent/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),Path('/usr/bin/otool'),Path('/usr/bin/sandbox-exec')]
 tools += [W.parent/'macos-advanced-native-8e88634'/name for name in ['native-drawing.json','native-viewport3d.json','source-binding.json']]
 tools += [W.parent/'macos-viewport-independence-8e88634'/name for name in ['native-viewport3d.json','result-review.json','source-binding.json']]
 for path in tools:pins[str(path)]=sha(path)
 P.mkdir(mode=0o700)
 for name in ['go-cache','go-tmp','temp']:(P/name).mkdir(mode=0o700)
 jobs=[]
 for name in CASES:
  cwd=T/'examples'/name;original=(cwd/'go.mod').read_text();start=original.index('replace (');end=original.index(')',start)+1
  need(original.count('replace (')==1 and not original[end:].strip(),'single final replacement block')
  block='replace (\n'+''.join(' '+module+' => '+json.dumps(str(path))+'\n'for module,path in ROOTS.items())+')'
  modfile=P/(name+'.mod');modfile.write_text(original[:start]+block+original[end:]);modfile.with_suffix('.sum').write_bytes((cwd/'go.sum').read_bytes())
  pins[str(modfile)]=sha(modfile);pins[str(modfile.with_suffix('.sum'))]=sha(modfile.with_suffix('.sum'))
  jobs.append(dict(name=name,cwd=str(cwd),modfile=str(modfile),binary=str(P/name),linkmap=str(P/(name+'.linkmap'))))
 h.exclusive(W/'plan.json',dict(source_commit=HEAD,inputs=pins,jobs=jobs,expected_origins={k:str(v)for k,v in ROOTS.items()},library_sha256=LIBSHA,sdk_source=manifest['source'],sdk_root=str(SDK),unchanged_sdk_framework_counterparts=counterparts,current_framework=True,new_sdk_archive=False,modified_source_binding_sha256=sha(W/'source-binding.json'),native_separate_review=True,source_files=4726,prepared_files=6249))
 print(json.dumps(dict(result='PREPARED_ADVANCED_SOURCE_CONSUMERS',inputs=len(pins),framework_counterparts=counterparts,native_started=False)))
def build():
 phase='build';need(not(W/'build.json').exists() and not stopped(phase),'one-shot advanced build')
 pins,reviewsha=h.certificate('build');stable=lambda:all(sha(p)==v for p,v in pins.items());plan=read(W/'plan.json')
 d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,readiness_sha256=reviewsha,commands=[],binaries=[],error=None,finalization_errors=[],native_execution='not_started')
 def run(label,args,cwd,timeout=180):
  record=g.execute(command(args),cwd,P/label,lambda:stopped(phase),stable,timeout=timeout,limit=8<<20);d['commands'].append(dict(name=label,run=record));need(h.terminal(record),'owned advanced command '+label);return(P/label/'stdout').read_bytes()
 try:
  with g.LiveLease()as lease:
   need(lease.held() and stable() and not stopped(phase),'build admission');status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'))
   for job in plan['jobs']:
    name=job['name'];cwd=Path(job['cwd']);mod='-modfile='+job['modfile'];binary=Path(job['binary']);linkmap=Path(job['linkmap']);h.fresh_outputs(binary,linkmap)
    modules=h.checker.decode_objects(run(name+'-modules',[str(GO),'list',mod,'-mod=readonly','-m','-json','all'],cwd).decode())
    origins={m['Path']:m['Replace'].get('Dir')for m in modules if m.get('Replace')};need(origins==plan['expected_origins'],'exact five current/private module origins')
    packages=h.checker.decode_objects(run(name+'-sources',[str(GO),'list','-race',mod,'-mod=readonly','-deps','-json','.'],cwd).decode());need(packages and not any(p.get('Incomplete')or p.get('Error')or p.get('DepsErrors')for p in packages),'complete race package graph')
    for package in packages:
     for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles']:
      for value in package.get(field,[]):
       path=Path(value)if Path(value).is_absolute()else Path(package['Dir'])/value;h.pin_once(pins,path)
     module=package.get('Module')or{};module=module.get('Replace')or module
     if module.get('GoMod'):h.pin_once(pins,module['GoMod'])
    run(name+'-race',[str(GO),'test','-race','-count=1',mod,'-mod=readonly','./...'],cwd,600)
    run(name+'-vet',[str(GO),'vet',mod,'-mod=readonly','./...'],cwd,300)
    h.fresh_outputs(binary,linkmap)
    run(name+'-compile',[str(GO),'build','-race',mod,'-mod=readonly','-p=2','-buildvcs=true','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',str(binary),'.'],cwd,600)
    need(binary.is_file()and not binary.is_symlink()and 0<binary.stat().st_size<128<<20 and linkmap.is_file()and not linkmap.is_symlink(),'retained build pair');h.pin_once(pins,binary);h.pin_once(pins,linkmap)
    links=run(name+'-links',['/usr/bin/otool','-L',str(binary)],P,30).decode();need('libwgpu_native'not in links,'no WGPU dylib dependency')
    load=run(name+'-load',['/usr/bin/otool','-l',str(binary)],P,30).decode();need('minos 13.0'in load,'minimum macOS13')
    info=json.loads(run(name+'-metadata',[str(GO),'version','-m','-json',str(binary)],P,30));settings={}
    for item in info['Settings']:
     need(set(item)<={'Key','Value'}and item['Key']not in settings and type(item.get('Value',''))is str,'unique typed build settings');settings[item['Key']]=item.get('Value','')
    need(info['GoVersion']=='go1.27.2'and info['Path']=='github.com/dshills/vellum/examples/'+name and all(settings.get(k)==v for k,v in {'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'1','-race':'true','vcs.revision':HEAD,'vcs.modified':'true'}.items()),'current modified-source race build identity')
    need([m.get('Replace',{}).get('Path')for m in info.get('Deps',[])if m['Path']=='github.com/oliverbestmann/webgpu/libs-darwin']==[str(LIB)],'embedded private module lineage')
    with binary.open('rb')as stream:header=stream.read(32)
    need(len(header)==32 and struct.unpack_from('<I',header)[0]==0xFEEDFACF and struct.unpack_from('<I',header,4)[0]==0x0100000C and struct.unpack_from('<I',header,12)[0]==2,'ARM64 MH_EXECUTE')
    framed=h.native_archive.archive_members(LIB/'arm64/libwgpu_native.a');mapping=h.native_archive.linker_objects(linkmap);selected=h.native_archive.selected_archive_members(mapping,LIB/'arm64/libwgpu_native.a',framed)
    need(framed['sha256']==LIBSHA and mapping['architecture']=='arm64'and selected and len(selected)==len([v for v in mapping['objects']if'libwgpu_native'in v]),'only exact source-built static members')
    inspection=W/('inspection-'+name+'.json');h.exclusive(inspection,dict(name=name,selected_members=selected,package_count=len(packages),origins=origins,metadata=info,static_archive_sha256=LIBSHA));h.pin_once(pins,inspection)
    d['binaries'].append(dict(name=name,path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary),linkmap=dict(path=str(linkmap),bytes=linkmap.stat().st_size,sha256=sha(linkmap)),private_static_members=len(selected),package_count=len(packages),race=True,minimum_macos='13.0'))
   status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'));need(stable()and not stopped(phase)and lease.held(),'terminal build closure')
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:h.finish(phase,d)
def validate(name,stdout,stderr):
 records=[]
 for line in stdout.splitlines():
  value=json.loads(line);need(type(value)is dict,'JSON record');records.append(value)
 need(len(records)==1,'exactly one native summary');r=records[0]
 need(r.get('event')=='vellum.'+name+'.smoke' and r.get('geometry_persistence_disabled_in_fixture')is True,'actual fixture geometry isolation')
 if name=='drawing':
  for key in ['gradient_and_linear_alpha_pixels','transparent_snapshot','static_pan_retains_mesh','independent_windows','empty_frame_clear','budget_refusal','error_callback_resource_query','resource_rebuild','repeated_resize']:need(r.get(key)is True,'drawing assertion '+key)
  need(r.get('schematic_source_objects')==100000 and r.get('waveform_source_samples')==1000000,'drawing source workload')
  image=r.get('retained_image');need(type(image)is dict and image.get('initial_tiles')==1024 and image.get('changed_tiles')==1 and image.get('changed_upload_bytes')==65536,'retained tile workload')
 else:need(r.get('result')=='pass'and r.get('independentBufferNamespaces')is True and r.get('orbitPixelsChanged')is True,'viewport source assertions')
 errors=stderr.decode().splitlines();expected=['budget exceeded']if name=='drawing'else['budget exceeded','controlled preparation','controlled draw']
 need(len(errors)==len(expected)and all(sum(part in error for error in errors)==1 for part in expected)and all(sum(part in error for part in expected)==1 for error in errors),'only deliberate native fault diagnostics')
 return r
def native(name):
 phase='native-'+name;need(name in CASES and not(W/(phase+'.json')).exists()and not stopped(phase),'one-shot case')
 pins,reviewsha=h.certificate('native');stable=lambda:all(sha(p)==v for p,v in pins.items());built=read(W/'build.json');need(built['result']=='PASS_BUILD'and not built['error']and not built['finalization_errors'],'terminal reviewed builds')
 if name=='viewport3d':need(read(W.parent/'macos-advanced-native-8e88634/native-drawing.json')['result']=='PASS_NATIVE-DRAWING','retained first native case passed')
 binary=next(v for v in built['binaries']if v['name']==name)
 d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,readiness_sha256=reviewsha,error=None,finalization_errors=[],native_execution='not_started',physical_input_generated=False,settings_changes=False,full_macos_qualified=False)
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopped(phase),'native case admission');status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'))
   run=g.execute(command([binary['path'],'--smoke'],True),T/'examples'/name,P/phase,lambda:stopped(phase),stable,timeout=75,limit=2<<20)
   d['run']=run;d['native_execution']='created_not_qualified'if run['created']else'not_started';need(h.terminal(run),'owned native smoke '+name)
   d['record']=validate(name,(P/phase/'stdout').read_bytes(),(P/phase/'stderr').read_bytes());d['native_execution']='confirmed_by_source_assertions_and_summary'
   status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'));need(stable()and not stopped(phase)and lease.held(),'terminal native closure')
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:h.finish(phase,d)
if __name__=='__main__':
 need(sys.argv[1:]in[['prepare'],['build'],['native-drawing'],['native-viewport3d']],'fixed advanced phase')
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='build':build()
 else:native(sys.argv[1].removeprefix('native-'))
