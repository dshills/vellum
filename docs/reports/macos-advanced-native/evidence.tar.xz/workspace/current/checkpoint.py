"""Retain the reviewed native fixtures, original failures and principal artifacts durably."""
from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-viewport-startup-8e88634')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 receipt=json.loads((W/'commit-receipt.json').read_bytes());build=json.loads((W/'build.json').read_bytes());native=json.loads((W/'native-viewport3d.json').read_bytes())
 assert receipt['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED' and receipt['both_clean'] and receipt['canonical_promoted'] and not receipt['error'] and not receipt['finalization_errors']
 assert build['result']=='PASS_BUILD' and native['result']=='PASS_NATIVE-VIEWPORT3D'
 commit=receipt['commit'];destination=W/('checkpoint-'+commit[:7]);assert not destination.exists()
 entries={'workspace/'+p.relative_to(W).as_posix():p for p in W.rglob('*')if p.is_file() and not p.is_symlink() and not any(part.startswith('checkpoint-')or part=='__pycache__'for part in p.relative_to(W).parts)}
 sdk=Path(json.loads((W/'plan.json').read_text())['sdk_root']);principal={'clean-sdk.tar.gz':Path('/private/tmp/vellum-source-gpu-sdk-native/sdk.tar.gz'),'source-built-libwgpu_native.a':sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'}
 for label,workspace in [('initial',W.parent/'macos-advanced-native-8e88634'),('diagnostic',W.parent/'macos-viewport-independence-8e88634'),('current',W)]:
  for binary in json.loads((workspace/'build.json').read_text())['binaries']:
   for suffix,path,expected in [('',Path(binary['path']),binary['sha256']),('.linkmap',Path(binary['linkmap']['path']),binary['linkmap']['sha256'])]:
    assert sha(path)==expected;principal[label+'-'+binary['name']+suffix]=path
 for name,p in principal.items():entries['principal-artifacts/'+name]=p
 assert sha(principal['clean-sdk.tar.gz'])=='82f63da6eb5023da88e531b5766676ed94367c043a4340d7e459e27d26e15600'
 assert sha(principal['source-built-libwgpu_native.a'])=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
 index={n:dict(bytes=p.stat().st_size,sha256=sha(p),mode=p.stat().st_mode&0o777,origin=str(p))for n,p in sorted(entries.items())}
 destination.mkdir()
 for name,p in sorted(entries.items()):
  target=destination/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  assert target.stat().st_size==index[name]['bytes']and sha(target)==index[name]['sha256']and target.stat().st_mode&0o777==index[name]['mode']
 manifest=dict(evidence_commit=commit,tested_source_base=build['source_commit'],files=index,drawing_and_viewport_source_assertions_pass=True,historical_failed_native_endpoints_preserved=True,full_macos_qualified=False,scope='Drawing source-specific native PASS and corrected paired-startup viewport PASS; original failed viewports retain their identities/statuses. Current binaries were built from the recorded modified base before this evidence commit; they are not relabeled clean new-commit builds. No physical/presentation/performance/native-memory/endurance/public-release qualification.')
 with(destination/'MANIFEST.json').open('x')as out:out.write(json.dumps(manifest,indent=2)+'\n')
 result=dict(commit=commit,path=str(destination),manifest_sha256=sha(destination/'MANIFEST.json'),files=len(index),bytes=sum(v['bytes']for v in index.values()))
 with(W/'checkpoint-receipt.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
if __name__=='__main__':main()
