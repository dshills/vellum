from pathlib import Path
import hashlib,json,subprocess,shutil
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-viewport-independence-8e88634';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.loads((OLD/'source-binding.json').read_text());assert all(sha(T/n)==h for n,h in b['after'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip()==b['base_commit']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=T)
extra='examples/viewport3d/model_test.go';b['before'][extra]=sha(C/extra)
assert sha(T/extra)==b['before'][extra]
shutil.copytree(OLD/'original',W/'original');o=W/'original'/extra;o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes((C/extra).read_bytes())
for name in b['before']:
 p=W/'prediagnostic'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
p=T/'examples/viewport3d/smoke.go';s=p.read_text()
s=s.replace('retain the original first-ready', 'retain the paired initial')
old='\tinitial, err := waitFrame(ctx, a, g, 0)\n\tif err != nil {\n\t\treturn err\n\t}\n\tindependent, err := waitFrame(ctx, a, other, 0)\n\tif err != nil {\n\t\treturn err\n\t}\n'
new='\tinitialPair, err := stableInitialFrames(ctx, a, g, other)\n\tif err != nil { return err }\n\tinitial, independent := initialPair[0], initialPair[1]\n'
assert s.count(old)==1;s=s.replace(old,new)
old='\t\tinitial, e = g.Stats()\n\t\tif e != nil {\n\t\t\treturn e\n\t\t}\n\t\tchrome()\n'
new='\t\tinitial, e = g.Stats()\n\t\tif e != nil { return e }\n\t\tindependent, e = other.Stats()\n\t\tif e != nil { return e }\n\t\tcurrent := [2]cogent.GPUViewStats{initial, independent}\n\t\tif !initial.Ready || !independent.Ready || initialFrameStates(current) != initialFrameStates(initialPair) {\n\t\t\treturn fmt.Errorf("initial targets changed after paired quiet interval: settled=%+v current=%+v", initialPair, current)\n\t\t}\n\t\tchrome()\n'
assert s.count(old)==1;s=s.replace(old,new)
assert s.count('"initial": initial,')==1;s=s.replace('"initial": initial,','"initial": initial, "initial_pair": initialPair, "initial_baselines": [2]cogent.GPUViewStats{initial, independent},')
s+='\n'+(W/'initial-frames.go.txt').read_text();p.write_text(s)
p=T/extra;s=p.read_text().replace('"math"','"math"\n"fmt"\n"image"\n"time"\n"github.com/dshills/vellum/drivers/cogent"');s+='\n'+(W/'initial-frames-test.go.txt').read_text();p.write_text(s)
for name in ['examples/viewport3d/README.md','specs/advanced-gpu.md']:
 p=T/name;p.write_text(p.read_text()+'\nThe 3D smoke establishes a paired 100 ms quiet interval for both initial targets,\nthen captures both baselines together before its first chrome mutation. It refuses\nlater frame/resource drift with the original strict retention checks. This avoids\nusing a provisional first layout as the retention baseline; the quiet interval is\nan operational fixture barrier, not a guarantee that all OS work has drained.\nBounded owner-thread observations retain independent-window state for diagnosis.\nNo frame, budget, depth, pixel, fault-repair, resize or closure assertion is waived.\n')
subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(T/'examples/viewport3d/smoke.go'),str(T/extra)],check=True)
for name in b['before']:
 p=W/'draft'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
result=dict(base_commit=b['base_commit'],before=b['before'],after={n:sha(T/n)for n in b['before']},confirmed_initial_layout_baseline_fix=True,prior_failed_source_binding_sha256=sha(OLD/'source-binding.json'))
(W/'source-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(result='PAIRED_INITIAL_BASELINE_FIX_INSTALLED',source_files=9,assertion_weakened=False,native_started=False)))
