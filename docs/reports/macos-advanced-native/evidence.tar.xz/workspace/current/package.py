"""Retain the original failures beside the reviewed current native fixtures."""
from pathlib import Path
import hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=W/'report'
W3=W.parent/'macos-advanced-native-8e88634';W4=W.parent/'macos-viewport-independence-8e88634'
P3=Path('/private/tmp/vellum-advanced-native-8e88634');P4=Path('/private/tmp/vellum-viewport-independence-8e88634');P=Path('/private/tmp/vellum-viewport-startup-8e88634')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
MAX_MEMBERS=384;MAX_EXPANDED=256<<20;MAX_COMPRESSED=32<<20
def need(ok,msg):
 if not ok:raise ValueError(msg)
class BoundedWriter:
 def __init__(self,stream,bound):self.stream,self.bound=stream,bound
 def write(self,body):
  need(self.stream.tell()+len(body)<=self.bound,'compressed evidence byte bound')
  return self.stream.write(body)
 def tell(self):return self.stream.tell()
 def flush(self):return self.stream.flush()
def main():
 need(not R.exists(),'fresh evidence output')
 body=(W/'report-review.json').read_bytes();review_sha=hashlib.sha256(body).hexdigest();review=json.loads(body)
 need(review['report_ready']and not review['unresolved_findings'],'independent report review')
 stable=lambda:sha(W/'report-review.json')==review_sha and all(sha(p)==h for p,h in review['inputs'].items())
 need(stable(),'reviewed report closure')
 drawing=read(W3/'native-drawing.json');initial=read(W3/'native-viewport3d.json');diagnostic=read(W4/'native-viewport3d.json');viewport=read(W/'native-viewport3d.json')
 need(drawing['result']=='PASS_NATIVE-DRAWING'and viewport['result']=='PASS_NATIVE-VIEWPORT3D','current source-specific native passes')
 need(all(v['result']=='FAILED_NATIVE-VIEWPORT3D'and v['run']['exit_code']==1 for v in [initial,diagnostic]),'original failures preserved')
 need(all(v['run']['owned']['terminal']and v['run']['owned']['group_absent']and not v['run']['owned']['errors']for v in [drawing,initial,diagnostic,viewport]),'all native groups retired')
 provider=read(W/'prism/receipt.json');need(provider['result']=='COMPLETE_SCOPED_PROVIDER_REVIEW'and provider['coverage']['llmCalls']==1,'one complete provider checkpoint')
 need('PENDING'not in(W/'README.final.md').read_text(),'completed report prose')
 entries={};principals=[];runs=[]
 def add(name,path):
  p=Path(path);need(name not in entries and p.is_file()and not p.is_symlink()and p.stat().st_size<=32<<20,'unique regular bounded member');entries[name]=p
 for label,workspace,root,native_names in [('initial',W3,P3,['drawing','viewport3d']),('diagnostic',W4,P4,['viewport3d']),('current',W,P,['viewport3d'])]:
  for path in sorted(workspace.rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(workspace)
   if any(part.startswith('checkpoint-')or part in ['report','__pycache__','commit-logs']for part in relative.parts):continue
   if workspace==W3 and relative.as_posix()in ['package.py','prism_review.py','prism-rules.json','commit.py']:continue
   add('workspace/'+label+'/'+relative.as_posix(),path)
  build=read(workspace/'build.json');need(build['result']=='PASS_BUILD'and not build['error']and not build['finalization_errors'],'actual build phase pass')
  commands=build['commands']+[dict(name='native-'+name,run=read(workspace/('native-'+name+'.json'))['run'])for name in native_names]
  for command in commands:
   run=command['run'];need(run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'retained command retirement')
   for name in ['stdout','stderr','owned.json']:
    path=root/command['name']/name
    if name in run['logs']:need(run['logs'][name]==dict(bytes=path.stat().st_size,sha256=sha(path)),'exact raw command log')
    add('runs/'+label+'/'+command['name']+'/'+name,path)
   runs.append(dict(phase=label,name=command['name'],exit_code=run['exit_code'],group=run['group'],seconds=run['seconds']))
  for binary in build['binaries']:
   add('linkmaps/'+label+'/'+binary['name']+'.linkmap',binary['linkmap']['path']);principals.append(Path(binary['path']))
  for name in ['drawing.mod','drawing.sum','viewport3d.mod','viewport3d.sum']:
   if(root/name).exists():add('private-modules/'+label+'/'+name,root/name)
 sdk=Path(read(W/'plan.json')['sdk_root']);lib=sdk/'drivers/cogent/build/libs-darwin'
 for name in ['SDK_MANIFEST.json','THIRD_PARTY_INVENTORY.json']:add('sdk/'+name,sdk/name)
 for name in ['go.mod','libs.go','PROVENANCE.json']:add('sdk-capsule/'+name,lib/name)
 helpers={'retained_parent.py':W.parent/'macos-source-gpu-sdk-native/run.py','owned_process.py':W.parent/'macos-sdk-native-238b3b6/run.py','live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')}
 for name in ['child_process.py','sdk_environment.py','native_archive.py']:helpers[name]=T/'scripts'/name
 for name,path in helpers.items():add('helpers/'+name,path)
 index={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in sorted(entries.items())}
 need(len(index)<=MAX_MEMBERS and sum(v['bytes']for v in index.values())<=MAX_EXPANDED,'finite three-phase evidence bounds')
 principals += [Path('/private/tmp/vellum-source-gpu-sdk-native/sdk.tar.gz'),lib/'arm64/libwgpu_native.a']
 excluded=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in principals]
 R.mkdir()
 with(R/'evidence.tar.xz').open('xb')as raw:
  with tarfile.open(fileobj=BoundedWriter(raw,MAX_COMPRESSED),mode='w:xz',preset=6)as archive:
   for name,path in sorted(entries.items()):
    data=path.read_bytes();need(hashlib.sha256(data).hexdigest()==index[name]['sha256'],'stable member origin')
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
 with tarfile.open(R/'evidence.tar.xz','r:xz')as archive:
  need(archive.getnames()==sorted(index),'exact archive members')
  for item in archive:
   data=archive.extractfile(item).read();need(len(data)==index[item.name]['bytes']and hashlib.sha256(data).hexdigest()==index[item.name]['sha256'],'archive readback identity')
 evidence=dict(files=index,archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz')),limits=dict(members=MAX_MEMBERS,expanded_bytes=MAX_EXPANDED,compressed_bytes=MAX_COMPRESSED,member_bytes=32<<20),excluded_principal_artifacts=excluded,other_exclusions='Go/cache/temp directories, unrelated user/system data and unexecuted initial provider/package drafts are omitted. Principal binaries, SDK archive and library remain in their private run roots; a separate local checkpoint will copy them after commit. Fingerprints remain here.')
 (R/'evidence.manifest.json').write_text(json.dumps(evidence,indent=2)+'\n')
 result=dict(result='PASS_CURRENT_ISOLATED_NATIVE_DRAWING_AND_VIEWPORT_FIXTURES',source_commit=read(W/'plan.json')['source_commit'],source_state='nine exact reviewed modified leaves before commit',new_sdk_archive=False,unchanged_sdk_framework_counterparts=7027,drawing_binary=read(W3/'build.json')['binaries'][0],viewport_binary=read(W/'build.json')['binaries'][0],drawing_record=drawing['record'],viewport_record=viewport['record'],drawing_reuse=read(W/'drawing-selected-source-reuse.json'),historical_failures=[dict(phase='initial',receipt_result=initial['result'],stderr=initial['run']['logs']['stderr']),dict(phase='diagnostic',receipt_result=diagnostic['result'],stderr=diagnostic['run']['logs']['stderr'])],runs=runs,provider=provider,report_review_sha256=review_sha,summary_controls_reused=19,guard_controls_reused=27,new_startup_regression_roots=3,settings_changes=False,physical_input_generated=False,presentation_qualified=False,ordinary_frame_latency_qualified=False,native_gpu_memory_qualified=False,endurance_qualified=False,full_macos_qualified=False,public_distribution_qualified=False)
 (R/'result.json').write_text(json.dumps(result,indent=2)+'\n');(R/'README.md').write_bytes((W/'README.final.md').read_bytes())
 need(stable(),'terminal report certificate/source stability')
 print(json.dumps(dict(result='PACKAGED_THREE_PHASE_NATIVE_FIXTURE_EVIDENCE',members=len(index),expanded_bytes=sum(v['bytes']for v in index.values()),archive=evidence['archive'])))
if __name__=='__main__':main()
