from pathlib import Path
import hashlib,json,sys
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
r=run_child(['/opt/homebrew/bin/python3','-B',str(W/'prism-symlink-probe.py')],cwd=T,capture_output=True,timeout=30)
(W/'prism-symlink-probe.stdout').write_bytes(r.stdout);(W/'prism-symlink-probe.stderr').write_bytes(r.stderr)
(W/'prism-symlink-probe.json').write_text(json.dumps({'exit_code':r.returncode,'cases':json.loads(r.stdout),'probe_sha256':hashlib.sha256((W/'prism-symlink-probe.py').read_bytes()).hexdigest()},indent=2)+'\n');sys.exit(r.returncode)
