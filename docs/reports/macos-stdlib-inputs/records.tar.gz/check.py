from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('stdlib_owned',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
name=sys.argv[1];scripts={'inventory':'distribution-inventory_test.py','build':'build-macos_test.py','release':'release-sdk_test.py','check':'check-sdk_test.py','package':'package-app_test.py'};key=name.split('-v')[0];assert key in scripts
pins={str(T/p.relative_to(W/'candidate')):h.sha(T/p.relative_to(W/'candidate'))for p in (W/'candidate').rglob('*.py')};pins[str(Path(__file__))]=h.sha(__file__)
r=h.g.execute(['/opt/homebrew/bin/python3','-B',str(T/'scripts'/scripts[key])],T,W/name,lambda:(W/'stop-headless').exists(),lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=600,limit=4<<20);r['source_pins']=pins;(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']else 1)
