from pathlib import Path
import importlib.util,json,sys,tempfile
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'))
s=importlib.util.spec_from_file_location('inventory',T/'scripts/distribution-inventory.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
results=[]
for kind in ['root-file','package-file','dangling-file']:
 with tempfile.TemporaryDirectory() as temporary:
  root=Path(temporary);package=root/'src/runtime';package.mkdir(parents=True);(package/'runtime.go').write_text('package runtime\n');(root/'notice-real').write_text('candidate')
  link=(root if kind=='root-file' else package)/'LICENSE';link.symlink_to(root/('absent' if kind=='dangling-file' else 'notice-real'))
  try:m.standard_library_inventory([{'Standard':True,'ImportPath':'runtime','Dir':str(package),'GoFiles':['runtime.go']}],root)
  except ValueError as error:
   assert 'symlinks' in str(error),str(error);results.append({'kind':kind,'refused':True,'error':str(error)})
  else:raise AssertionError('symlink accepted: '+kind)
print(json.dumps(results,indent=2))
