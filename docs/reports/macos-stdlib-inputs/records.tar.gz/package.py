from pathlib import Path
import datetime,hashlib,json,shutil,sys,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-stdlib-inputs'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((W/'internal-results-review.json').read_text())['approved']
closure=json.loads((W/'internal-prism-closure.json').read_text());assert closure['approved']
for name in ['prism.json','prism-disposition.json']:
 assert closure['inputs'][str(W/name)]==sha(W/name),name
prism=json.loads((W/'prism.json').read_text());assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1
assert prism['findings']==[] and prism['suppressed']==[]
assert [x['finding']['id']for x in prism['discarded']]==['e18e108c1556bdeb']
disposition=json.loads((W/'prism-disposition.json').read_text())
assert disposition['addressed_or_disposed']==[] and disposition['retained']==0 and disposition['discarded']==1 and disposition['suppressed']==0
assert len(disposition['discarded_dispositions'])==1
assert disposition['discarded_dispositions'][0]['id']=='e18e108c1556bdeb' and disposition['discarded_dispositions'][0]['disposition']=='refuted-by-existing-helper-and-targeted-probe'
r=json.loads((W/'real-build-v2.json').read_text());assert r['exit_code']==0 and r['pins_stable']and r['owned']['group_absent']and not r['error']
for p in (W/'candidate').rglob('*.py'):assert p.read_bytes()==(T/p.relative_to(W/'candidate')).read_bytes()
shared=W/'shared';shared.mkdir();mapping={}
for i,(source,digest)in enumerate(sorted(r['source_pins'].items())):
 src=Path(source);assert sha(src)==digest
 if src.suffix=='.py':
  name=f'{i:02d}-'+src.name;shutil.copyfile(src,shared/name);mapping[source]={'stored':name,'bytes':src.stat().st_size,'sha256':digest}
 else:mapping[source]={'stored':None,'kind':'tool-executable-identity-only','bytes':src.stat().st_size,'sha256':digest}
(shared/'sources.json').write_text(json.dumps(mapping,indent=2)+'\n')
diff=run_child(['git','diff','--cached','--binary'],cwd=T,capture_output=True,check=True,timeout=30).stdout;(W/'final-source-docs.diff').write_bytes(diff)
checks={'base':'d3d4eb8f575c20d52d9e9a6e958d9e6283ee7aef','production_change':'Go standard-library selected-source/declaration input coverage in existing collector/build comparison','runtime_changed':False,'tests':96,'final_headless_build':'real-build-v2','go_version':'go1.25.6','standard_packages':236,'standard_files':1348,'standard_file_bytes':13972226,'declaration_candidates':9,'rights_approved':False,'runtime_executed':False,'prism_calls':1,'prism_cli_exit':json.loads((W/'prism-command.json').read_text())['exit_code'],'prism_retained':[x['id']for x in prism['findings']],'prism_discarded':[x['finding']['id']for x in prism['discarded']],'prism_suppressed':[x['id']for x in prism['suppressed']],'prism_disposition_sha256':sha(W/'prism-disposition.json'),'closed_mac_gates':[],'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for leaf in sorted(W.rglob('*')):
 assert not leaf.is_symlink(),leaf
 if not leaf.is_file()or '__pycache__'in leaf.parts or 'final-docs'in leaf.parts or leaf.name.startswith('stop-')or leaf.name in ['vellum-workbench','standard-method.txt','draft-release-addition.md','report-draft.md']or leaf.suffix=='.map':continue
 assert leaf.stat().st_size<8<<20,(leaf,leaf.stat().st_size);name=leaf.relative_to(W).as_posix();files[name]={'bytes':leaf.stat().st_size,'sha256':sha(leaf)};sources[name]=leaf
assert len(files)<150 and sum(x['bytes']for x in files.values())<40<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<10<<20;record={'archive':archive.name,'archive_sha256':sha(archive),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
