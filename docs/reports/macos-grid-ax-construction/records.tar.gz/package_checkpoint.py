from pathlib import Path
import hashlib,json,tarfile,subprocess,statistics,re
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'docs/reports/macos-grid-ax-construction'
native=json.loads((W/'native-comparison.json').read_text());race=json.loads((W/'full-race-command.json').read_text());prism=json.loads((W/'prism.json').read_text())
assert native['result']=='MEASURED' and race['exit_code']==0 and prism['coverage']['complete']
assert native['prepared_before']==native['prepared_after']
assert json.loads((W/'vet-command.json').read_text())['exit_code']==0
assert json.loads((W/'build-command.json').read_text())['exit_code']==0
D.mkdir(exist_ok=True)
bench={}
for mode in ['legacy','direct']:
 rows=re.findall(r'BenchmarkGridAccessibilityConstruction/'+mode+r'-2\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(W/'benchmark.stdout').read_text());assert len(rows)==5
 bench[mode]={k:statistics.median(int(x[i])for x in rows)for i,k in enumerate(['ns','bytes','allocations'])}
summary={}
for label,c in native['cases'].items():
 assert len(c['runs'])==5 and all(r['exit_code']==0 for r in c['runs'])
 summary[label]={'p95_ms':[r['ui_work_ns']['p95']/1e6 for r in c['runs']],'p99_ms':[r['ui_work_ns']['p99']/1e6 for r in c['runs']],'median_run_p95_ms':statistics.median(r['ui_work_ns']['p95']/1e6 for r in c['runs']),'median_run_alloc_bytes':statistics.median(r['go_process_alloc_bytes']['p50']for r in c['runs']),'target_met':c['target_met']}
result={'source_base':native['source_base'],'benchmark':bench,'native':summary,'native_target_met':native['candidate_target_met'],'full_driver_race_seconds':race['seconds'],'review':'Internal approved; Prism one complete 7-file/26999-byte call, raw one medium/CLIexit1, refuted for actual initialized-map callers.','prepared':native['prepared_after'],'physical_pointer_tested':False,'full_mac_qualified':False,'decision':'REJECT_RUNTIME_CANDIDATE_NATIVE_REGRESSION'}
(W/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(W/'source.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=T))
files=[]
for p in sorted(W.iterdir()):
 if p.is_file() and (p.suffix in ['.json','.stdout','.stderr','.txt','.diff']or p.name in ['native_compare.py','package_checkpoint.py']):files.append((p.name,p))
for p in sorted((W/'native').rglob('*')):
 if p.is_file()and p.name in ['result.json','native.log']:files.append((p.relative_to(W).as_posix(),p))
with tarfile.open(D/'records.tar.gz','w:gz')as tar:
 for name,p in files:tar.add(p,arcname=name,recursive=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records={'archive':{'file':'records.tar.gz','bytes':(D/'records.tar.gz').stat().st_size,'sha256':sha(D/'records.tar.gz')},'members':[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)}for name,p in files],'result':result}
(D/'records.json').write_text(json.dumps(records,indent=2)+'\n')
rows='\n'.join('| '+label+' | '+', '.join(f'{v:.3f}'for v in s['p95_ms'])+' | '+f"{s['median_run_p95_ms']:.3f}"+' | '+str(s['target_met'])+' |'for label,s in summary.items())
(D/'README.md').write_text(f'''# Direct managed-grid accessibility construction

This rejected experiment halves local accessibility construction cost, but its
ordinary native p95 is slower in all five matched pairs. The runtime candidate
and its experimental tests were reverted; no implementation gain is claimed.
The ordinary native target remains
{'open' if not native['candidate_target_met'] else 'subject to the remaining table matrix'};
this is not full Mac performance qualification.

## Experimental implementation and correctness

Grid records append directly to the owner snapshot and handler map. Visible row
identity and union bounds are computed once per row. Detached frame values are
copied from the immutable completed measurement. Late stamping reuses them only
while that exact measurement is current and all original readiness/editor fences
pass. Measurement replacement, unknown descendants and pending layout use the
unchanged legacy stamping path; only producer-added frame fields are cleared.
This avoids a frame-only replacement becoming a pending scope with no retry.
The experiment introduces no public API, retained cache or native transport
change. Its full source/test/spec diff is retained in the archive, based on
ea20486; the committed runtime remains ea20486.

The frozen ea20486 constructor/stamper are independently retained in offscreen
tests. A recorded parity check confirms they differ only by names/whitespace.
Tests compare complete Go records and semantic JSON at DPI96/162/192, disabled
states, preceding records/handlers, selected rows and empty rows/headers seeded
before construction. Deterministic replacement/pending/unknown-child and real
inline-editor tests cover fallback. Original projection indexes remain captured
by actions; the full root suite covers routing, stale actions and lifecycle.

Full driver-root offscreen race passes in {race['seconds']:.3f}s; vet and optimized
native build pass. Existing AppKit deprecation and duplicate-library warnings are
retained. The initial preparation attempt did not install the new test file;
its existing-test output is retained but is not the new regression evidence.
Focused-v2 installed it and passed; the complete final race includes the later
same-pointer test strengthening.

## Measurement

Five same-process 200ms benchmark observations per path, GOMAXPROCS2, Go1.27.2,
without race/profiler: legacy median {bench['legacy']['ns']:,}ns,
{bench['legacy']['bytes']:,}B/{bench['legacy']['allocations']:,}allocations;
direct median {bench['direct']['ns']:,}ns,
{bench['direct']['bytes']:,}B/{bench['direct']['allocations']:,}allocations.
This covers 400-cell construction, merging and stamping, excluding full refresh,
JSON and native publication. It is not a native frame result.

Native timing uses the existing grid runner and shared exclusive live lease,
normal runtime GOMAXPROCS/GOMEMLIMIT unset, GPU requested, five interleaved pairs,
128 warm events and120 samples per run at10k fixed rows. Both binaries exit0;
matched geometry is checked per trajectory sample. Actual window/display metadata,
raw sample logs, binary hashes/linkage and module origins are retained. Baseline
reuses the previous verified stage0078 runtime binary; its prepared dependencies
and original root source leaves match clean ea20486. Candidate is an optimized
working-tree build, without overlay/VCS stamping. Neither is presented as a new
independent clean historical rebuild.

| Build | Per-run p95 UI work(ms) | Median run p95(ms) | All runs meet4ms/6ms |
| --- | --- | --- | --- |
{rows}

All five candidate p95 values exceed the paired baseline. This result is a
rejection decision, not proof of a particular causal mechanism or a statistically
isolated estimate. Median run p95 rises from
{summary['baseline']['median_run_p95_ms']:.3f}ms to
{summary['candidate']['median_run_p95_ms']:.3f}ms. The source is reverted despite
lower allocation observations and passing semantic checks. Phase medians are
retained for diagnosis, without summing independent percentiles.

Process allocation observations include runtime and measurement overhead; they
are not framework-only allocation or retained-memory qualification. GPU requested
is not proof of actual route selection in these ordinary runs. Routed native
scrolling is separate from physical-pointer, screen-reader and presentation
verification. Complete table/tree/general-UI/pacing/memory/endurance/SDK gates stay
open; this first workload does not substitute for the full matrix.

## Review and evidence

Internal source/test/spec review approved. One complete Prism Anthropic
Claude Sonnet5.5 review covered7files/26,999bytes in1chunk/1fresh provider call.
Raw retained medium1c816691ecec034e and CLIexit1 are preserved. It hypothesized a
nil handler map on a disabled private-helper call. Both production callers pass
initialized maps; the raw wrapper retains its original non-nil empty map, and
the enabled helper initializes nil itself. Independent internal review refuted a
reachable bug; no second unchanged provider call was made.

[records.json](records.json) identifies the bounded [raw archive](records.tar.gz),
its member hashes and summary. No SDK or executable copies are archived.
''')
p=T/'specs/macos-delivery.md';s=p.read_text();s=s.replace('Updated 17 October 2026. Baseline: clean `762dcbf`;','Updated 17 October 2026. Runtime baseline before the latest AX construction checkpoint: clean `ea20486`;');s+='''

### Direct grid accessibility construction checkpoint

The [direct construction result](../docs/reports/macos-grid-ax-construction/README.md)
records an experiment with passing race/vet/internal semantic checks and a Prism
review, but slower native p95 in all five matched pairs. The runtime candidate
was rejected and reverted. The local construction reduction does not close M3; all unchanged
frame thresholds and the complete table/tree/application matrix still apply.
The next bottleneck investigation must use full refresh/scene capture and native
publication costs, rather than extrapolating another small isolated allocation
win into framework completion. M4–M7 and native M2/M5 remain open.
''';p.write_text(s)
print(json.dumps(result,indent=2));print(json.dumps(records['archive']))
