//go:build offscreen

package cogent

import (
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"math"
	"reflect"
	"testing"

	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
)

func segmentedNodes(s *accessibilitySegmentedSnapshot) []accessibilityNode {
	view := s.view()
	nodes := make([]accessibilityNode, view.len())
	for i := range nodes {
		nodes[i] = view.at(i)
	}
	return nodes
}

func segmentedKeys[T any](m map[string]T) map[string]bool {
	keys := map[string]bool{}
	for k := range m {
		keys[k] = true
	}
	return keys
}

func TestAccessibilitySegmentedActualParityAndSharing(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 162, 192} {
		for _, disabled := range []bool{false, true} {
			t.Run(fmt.Sprintf("%v/%v", dpi, disabled), func(t *testing.T) {
				one, _ := testNativeGrid(t, 10000)
				two, _ := testNativeGrid(t, 10000)
				cfg := manualConfig(t, 7)
				cfg.LogicalDPI = dpi
				m, a := gridManual(t, cfg, func() ui.Node {
					return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Disabled: disabled, Children: []ui.Node{
						{ID: "before", Kind: ui.Button, Text: "<before>&", Activate: func() {}},
						{ID: "one", Kind: ui.DataGrid, Grid: one, Grow: true},
						{ID: "between", Kind: ui.Label, Text: "😀 between"},
						{ID: "two", Kind: ui.DataGrid, Grid: two, Grow: true},
						{ID: "after", Kind: ui.StatusBar, Text: "after"},
					}}
				})
				gridFrame(t, m)
				b := newAccessibilityBridge(a)
				b.bind("one")
				t.Cleanup(b.close)
				if err := a.Do(func() {
					root := m.implementation.find("one").state.root
					old, oldHandlers := segmentedLegacySnapshot(root, b, false)
					s := buildAccessibilitySegmented(root, b)
					if s == nil || len(s.groups) != 2 {
						t.Fatal("eligible actual fixture fell back")
					}
					want, err := json.Marshal(old)
					if err != nil {
						t.Fatal(err)
					}
					got, ok := accessibilityBuiltinSemanticView(s.view(), false, 0)
					if !ok || got != string(want) {
						t.Fatalf("segmented wire differs\nwant%s\ngot%s", want, got)
					}
					if !reflect.DeepEqual(segmentedKeys(oldHandlers), segmentedKeys(s.handlers)) {
						t.Fatal("handler admission changed")
					}
					flat := segmentedNodes(s)
					for i := range old {
						old[i].activationGuard = nil
						// Baseline getters intentionally omit Go-only focus metadata.
						old[i].pressFocusID = ""
					}
					if !reflect.DeepEqual(old, flat) {
						t.Fatal("complete Go wire record/order differs")
					}
					if !b.updateSegmentedReady(s) || b.lastSnapshot != got {
						t.Fatal("positive publication path not used")
					}
					if len(b.pendingBaseline) != 0 || len(b.readyBaseline) != len(flat) {
						t.Fatal("flattened baseline retained")
					}
					for id, group := range s.groups {
						if &group[0] != &b.gridPublications[id][0] {
							t.Fatal("final group copied again")
						}
						for i := range group {
							if group[i].activationGuard != nil {
								t.Fatal("cache retained owner callback")
							}
						}
					}
					if !disabled && b.activationGuards[accessibilityManagedID("before")] == nil {
						t.Fatal("guard stripped before extraction")
					}
					generation := b.generation.Load()
					held := b.gridPublications[accessibilityManagedID("one")]
					duplicate := buildAccessibilitySegmented(root, b)
					if duplicate == nil || !b.updateSegmentedReady(duplicate) || b.generation.Load() != generation || &held[0] != &b.gridPublications[accessibilityManagedID("one")][0] {
						t.Fatal("duplicate retired valid cache/epoch")
					}
				}); err != nil {
					t.Fatal(err)
				}
			})
		}
	}
}

func TestAccessibilitySegmentedPendingRemovalAndActionsMatchLegacy(t *testing.T) {
	one, _ := testNativeGrid(t, 10000)
	two, _ := testNativeGrid(t, 10000)
	showTwo := true
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node {
		children := []ui.Node{{ID: "one", Kind: ui.DataGrid, Grid: one, Grow: true}, {ID: "middle", Kind: ui.Label, Text: "middle"}}
		if showTwo {
			children = append(children, ui.Node{ID: "two", Kind: ui.DataGrid, Grid: two, Grow: true})
		}
		return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Children: children}
	})
	gridFrame(t, m)
	old := newAccessibilityBridge(a)
	old.bind("one")
	t.Cleanup(old.close)
	current := newAccessibilityBridge(a)
	current.bind("one")
	t.Cleanup(current.close)
	var staleOld, staleNew accessibilityHandler
	check := func(requireFast bool) {
		t.Helper()
		if err := a.Do(func() {
			root := m.implementation.find("one").state.root
			nodes, handlers := segmentedLegacySnapshot(root, old, false)
			old.updateOwned(nodes, handlers)
			s := buildAccessibilitySegmented(root, current)
			if (s != nil) != requireFast {
				t.Fatalf("route fast=%v expected%v", s != nil, requireFast)
			}
			if s != nil {
				if !current.updateSegmentedReady(s) {
					t.Fatal("admitted route refused")
				}
			} else {
				n, h := accessibilitySnapshot(root, current)
				current.updateOwned(n, h)
			}
			if old.lastSnapshot != current.lastSnapshot || old.completedSnapshot != current.completedSnapshot || old.generation.Load() != current.generation.Load() || !reflect.DeepEqual(old.geometryMembers, current.geometryMembers) || !reflect.DeepEqual(segmentedKeys(old.handlers), segmentedKeys(current.handlers)) {
				t.Fatal("bridge lifecycle differs from legacy")
			}
			if staleOld == nil {
				for _, n := range nodes {
					if n.Role == "grid-cell" && n.GridScope == accessibilityManagedID("one") {
						staleOld = old.handlers[n.ID]
						staleNew = current.handlers[n.ID]
						break
					}
				}
			}
		}); err != nil {
			t.Fatal(err)
		}
	}
	check(true)
	check(true)
	if err := a.Do(func() {
		if err := one.Scroll(0, 48); err != nil {
			t.Fatal(err)
		}
		_ = a.Invalidate("one")
	}); err != nil {
		t.Fatal(err)
	}
	if err := m.implementation.refresh(m.implementation.find("one")); err != nil {
		t.Fatal(err)
	}
	check(false)
	if err := a.Do(func() {
		binding := gBinding(t, one)
		original := binding.r.control.onError
		defer func() { binding.r.control.onError = original }()
		refusals := 0
		binding.r.control.onError = func(err error) {
			if !errors.Is(err, virtual.ErrGridStale) {
				t.Errorf("unexpected stale-action error: %v", err)
			}
			refusals++
		}
		defer func() {
			if refusals != 2 {
				t.Errorf("stale error callbacks=%d want2", refusals)
			}
		}()
		if staleOld == nil || staleNew == nil || staleOld(accessibilityAction{Kind: "press"}) || staleNew(accessibilityAction{Kind: "press"}) {
			t.Fatal("pending generation accepted old cell action")
		}
	}); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
	check(true)
	retired := current.gridPublications[accessibilityManagedID("two")]
	if err := a.Do(func() { showTwo = false; _ = a.Invalidate("one") }); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
	check(true)
	if _, ok := current.gridPublications[accessibilityManagedID("two")]; ok {
		t.Fatal("retired sibling retained")
	}
	addresses := map[*accessibilityNode]bool{}
	for i := range retired {
		addresses[&retired[i]] = true
	}
	for _, ref := range current.readyBaseline {
		if addresses[ref.node] {
			t.Fatal("wire vector retains retired group")
		}
	}
	current.close()
	if current.readyBaseline != nil || current.gridPublications != nil || current.handlers != nil || current.activationGuards != nil {
		t.Fatal("close retained segments or callbacks")
	}
}

func TestAccessibilitySegmentedRefusalBeforeMutation(t *testing.T) {
	g, _ := testNativeGrid(t, 10000)
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: g, Grow: true} })
	gridFrame(t, m)
	b := newAccessibilityBridge(a)
	b.bind("one")
	t.Cleanup(b.close)
	if err := a.Do(func() {
		r := m.implementation.find("one").state.root
		s := buildAccessibilitySegmented(r, b)
		if s == nil {
			t.Fatal("no positive ready route")
		}
		before := b.lastSnapshot
		generation := b.generation.Load()
		binding := gBinding(t, g)
		binding.layoutPending.Store(true)
		if b.updateSegmentedReady(s) || b.lastSnapshot != before || b.generation.Load() != generation || b.gridPublications != nil {
			t.Fatal("incoherent capture mutated bridge")
		}
		binding.layoutPending.Store(false)
		if !b.updateSegmentedReady(s) {
			t.Fatal("restored coherent capture refused")
		}
		for _, change := range []func(){func() { r.node.Custom = &VirtualTable{} }, func() { r.node.Kind = ui.Extension }} {
			node := r.node
			change()
			if buildAccessibilitySegmented(r, b) != nil {
				t.Fatal("custom/namespace-capable route admitted")
			}
			r.node = node
		}
		b.generation.Store(math.MaxUint64)
		before = b.lastSnapshot
		if b.updateSegmentedReady(s) || b.lastSnapshot != before || b.pendingExhausted {
			t.Fatal("overflow mutated before legacy fallback")
		}
	}); err != nil {
		t.Fatal(err)
	}
}

func TestAccessibilitySegmentedEditorFallback(t *testing.T) {
	inline, owner, _, _, _ := inlineFixture(t, 162)
	gridFrame(t, inline)
	if err := owner.Do(func() {
		if buildAccessibilitySegmented(inline.implementation.find("one").state.root, nil) != nil {
			t.Fatal("inline editor admitted")
		}
	}); err != nil {
		t.Fatal(err)
	}
}

func TestAccessibilitySegmentedViewCustomFallbackAndNilActions(t *testing.T) {
	_, b := newAXTest(t, 8)
	calls := 0
	nodes := []accessibilityNode{{ID: "a", Value: semanticMutator{&calls, func() {}}}}
	s := &accessibilitySegmentedSnapshot{groups: map[string][]accessibilityNode{}, guards: map[string]func() bool{}}
	s.appendOwned(nodes, "")
	if b.updateSegmentedReady(s) || calls != 0 || b.generation.Load() != 0 || b.lastSnapshot != "" {
		t.Fatal("refusal invoked custom code or changed bridge")
	}
	b.updateOwned(nodes, nil)
	if calls != 1 {
		t.Fatal("whole legacy fallback callback count", calls)
	}
	for _, actions := range [][]string{nil, {}, {"press"}} {
		n := []accessibilityNode{{ID: "x", Actions: actions, Value: false}}
		want, _ := json.Marshal(n)
		v := &accessibilitySegmentedSnapshot{groups: map[string][]accessibilityNode{}, guards: map[string]func() bool{}}
		v.appendOwned(n, "")
		got, ok := accessibilityBuiltinSemanticView(v.view(), false, 0)
		if !ok || got != string(want) {
			t.Fatal("reference view lost nil/empty wire", got, string(want))
		}
	}
}

// Start with an actual completed measurement, then detach its cells/headers and
// inject the otherwise rare empty-first geometry and row-selection wire state.
// This tests producer parity, not the domain model's row-selection implementation.
func TestAccessibilitySegmentedRowSelectionEmptyFirstParity(t *testing.T) {
	g, _ := testNativeGrid(t, 10000)
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: g, Grow: true} })
	gridFrame(t, m)
	if err := a.Do(func() {
		binding := gBinding(t, g)
		original := binding.measurement.Load()
		copy := *original
		copy.Cells = append(copy.Cells[:0:0], original.Cells...)
		copy.Headers = append(copy.Headers[:0:0], original.Headers...)
		if len(copy.Cells) < 2 || len(copy.Headers) < 2 {
			t.Fatal("fixture lacks geometry")
		}
		row := copy.Cells[0].RowKey
		copy.RowSelection = true
		for i := range copy.Cells {
			copy.Cells[i].Selected = copy.Cells[i].RowKey == row
		}
		copy.Cells[0].Bounds = image.Rectangle{}
		copy.Headers[0].Bounds = image.Rectangle{}
		binding.measurement.Store(&copy)
		defer binding.measurement.Store(original)
		root := m.implementation.find("one").state.root
		old, _ := segmentedLegacySnapshot(root, nil, false)
		s := buildAccessibilitySegmented(root, nil)
		if s == nil {
			t.Fatal("detached coherent measurement refused")
		}
		want, err := json.Marshal(old)
		if err != nil {
			t.Fatal(err)
		}
		got, ok := accessibilityBuiltinSemanticView(s.view(), false, 0)
		if !ok || got != string(want) {
			t.Fatal("row-selection/empty-first wire or geometry differs")
		}
		selectedRows, selectedCells := 0, 0
		for _, n := range segmentedNodes(s) {
			if n.Role == "grid-row" && n.Selected {
				selectedRows++
			}
			if n.Role == "grid-cell" && n.Selected {
				selectedCells++
			}
			if n.DomainID == copy.Cells[0].ID || n.DomainID == copy.Headers[0].ID {
				t.Fatal("empty geometry emitted")
			}
		}
		if selectedRows != 1 || selectedCells == 0 {
			t.Fatal("selection fixture was not exercised")
		}
	}); err != nil {
		t.Fatal(err)
	}
}

func TestAccessibilitySegmentedFreshPressSelectionChangeAndFocus(t *testing.T) {
	g, _ := testNativeGrid(t, 10000)
	var events []ui.GridEvent
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node {
		return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: g, Grow: true, GridChange: func(e ui.GridEvent) { events = append(events, e) }}
	})
	gridFrame(t, m)
	b := newAccessibilityBridge(a)
	b.bind("one")
	t.Cleanup(b.close)
	if err := a.Do(func() {
		root := m.implementation.find("one").state.root
		s := buildAccessibilitySegmented(root, b)
		if s == nil || !b.updateSegmentedReady(s) {
			t.Fatal("fresh route refused")
		}
		before, err := g.State()
		if err != nil {
			t.Fatal(err)
		}
		measurement := gBinding(t, g).currentMeasurement()
		events = nil // Exclude initial viewport/layout notifications.
		for _, c := range measurement.Cells {
			if c.Bounds.Empty() || c.Active {
				continue
			}
			h := b.handlers[accessibilityManagedID(c.ID)]
			if h == nil || !h(accessibilityAction{Kind: "press"}) {
				t.Fatal("fresh cell press refused")
			}
			after, err := g.State()
			if err != nil {
				t.Fatal(err)
			}
			if after.Generation <= before.Generation || after.Active.RowKey != c.RowKey || after.Active.ColumnID != fmt.Sprintf("c%d", c.Column) {
				t.Fatal("press did not select target")
			}
			if len(events) != 1 || events[0].ID != "g" || events[0].Reason != ui.GridSelection || events[0].State != after {
				t.Fatalf("press change events=%+v want state=%+v", events, after)
			}
			if focus := b.pendingFocus.Load(); focus == nil || *focus != accessibilityManagedID("g") {
				t.Fatal("press did not request grid focus")
			}
			return
		}
		t.Fatal("fixture lacks a nonactive visible cell")
	}); err != nil {
		t.Fatal(err)
	}
}
