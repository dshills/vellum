//go:build offscreen

// Frozen 9d3c97f producer, independent of the segmented visitor and grid builder.
package cogent

import (
	"cogentcore.org/core/styles/states"
	"github.com/dshills/vellum/drivers/cogent/internal/textinput"
	"github.com/dshills/vellum/editor"
	"github.com/dshills/vellum/ui"
	"strings"
)

func segmentedLegacySnapshot(root *record, b *accessibilityBridge, inheritedDisabled bool) ([]accessibilityNode, map[string]accessibilityHandler) {
	nodes := []accessibilityNode{}
	handlers := map[string]accessibilityHandler{}
	scoped, namespace := root, ""
	if !inheritedDisabled {
		scoped, namespace = visibleAccessibilityScope(root)
	}
	if scoped == nil {
		return nodes, handlers
	}
	var visit func(*record, string, bool)
	visit = func(r *record, parent string, disabled bool) {
		start := len(nodes)
		n := r.node
		disabled = disabled || n.Disabled
		if n.Kind == ui.MenuButton {
			disabled = disabled || !ui.MenuEnabled(n)
		}
		if n.Kind == ui.Dialog && (!n.Open || disabled || (r.control != nil && r.control.dialog != nil && r.control.dialog.dismissed)) {
			return
		}
		if n.Kind == ui.Separator || ((n.Kind == ui.Icon || n.Kind == ui.Image) && strings.TrimSpace(n.Accessibility.Name) == "" && strings.TrimSpace(n.Text) == "") {
			return
		} // decorative, no accessible target
		name := n.Accessibility.Name
		if name == "" || ((n.Kind == ui.Icon || n.Kind == ui.Image) && strings.TrimSpace(name) == "") {
			name = n.Text
		}
		x := accessibilityNode{ID: accessibilityManagedID(n.ID), DomainID: n.ID, Parent: parent, Role: string(n.Kind), Name: name, Help: n.Accessibility.Help, Disabled: disabled, Focusable: ui.IsFocusable(n.Kind), Actions: []string{}}
		if widget, err := focusWidget(r); err == nil && !accessibilityTreeNil(widget) {
			x.Focused = widget.AsWidget().StateIs(states.Focused)
			if r.control != nil && r.control.tabs != nil {
				for _, button := range r.control.tabs.buttons {
					if !accessibilityTreeNil(button) && button.StateIs(states.Focused) {
						x.Focused = true
						break
					}
				}
			}
		}
		switch extension := n.Custom.(type) {
		case *VirtualTable:
			if extension != nil {
				x.Role = "table"
			}
		case *VirtualTree:
			if extension != nil {
				x.Role = "outline"
			}
		}
		switch n.Kind {
		case ui.Canvas2D:
			if len(n.CanvasObjects) > 0 {
				x.Role = "canvas"
				x.Value = canvasCompletedSelection(r)
			}
		case ui.Icon:
			x.Role = "image"
		case ui.SplitPane:
			x.Focusable, x.Focused = false, false // The divider owns focus.
		case ui.StatusBar:
			x.Value = n.Text
		case ui.DataTree:
			x.Role = "outline"
			if r.control != nil && r.control.outline != nil {
				x.RowCount = r.control.outline.projection.State.VisibleRows
			}
		case ui.DataGrid:
			x.Role = "table"
			if r.control != nil && r.control.grid != nil {
				state := r.control.grid.projection.State
				x.RowCount = state.Stamp.Rows
				x.ColumnCount = state.Columns
				x.GridGeneration = state.Generation
			}
		case ui.Label:
			x.Value = n.Text
		case ui.TextField, ui.MultilineText:
			x.Value = n.Text
			selection := editor.Selection{}
			if n.Kind == ui.MultilineText {
				snapshot := n.Editor.Snapshot()
				x.Value = snapshot.VisibleText
				selection = snapshot.Selection
			}
			if r.control != nil {
				x.TextClient = r.control.client
				if n.Kind == ui.TextField && r.control.fieldState != nil {
					x.Value = r.control.fieldState.Text
					selection = editor.Selection{Anchor: r.control.fieldState.Anchor, Focus: r.control.fieldState.Focus}
				}
			}
			text, _ := x.Value.(string)
			anchor, _ := textinput.UTF16Offset(text, selection.Anchor)
			focus, _ := textinput.UTF16Offset(text, selection.Focus)
			rangeValue := [2]int{min(anchor, focus), max(anchor, focus) - min(anchor, focus)}
			x.TextSelection = &rangeValue
			x.TextFocus = focus
		case ui.MenuButton:
			opened := menuOpen(r)
			x.Expanded = &opened
			if opened {
				x.Focused = false
			}
		case ui.Checkbox, ui.Switch, ui.ToggleButton:
			x.Value = n.Checked
		case ui.ProgressBar, ui.ProgressRing, ui.ProgressGauge:
			x.Role = "progress-bar"
			x.Value = n.Number
			minimum, maximum := float32(0), float32(1)
			x.Min, x.Max = &minimum, &maximum
		case ui.Slider, ui.NumberField:
			x.Value = n.Number
			minimum, maximum := n.Numeric.Min, n.Numeric.Max
			x.Min = &minimum
			x.Max = &maximum
		case ui.RadioGroup, ui.SegmentedControl, ui.ListBox:
			x.Role = "radio-group"
			if n.Kind == ui.ListBox {
				x.Role = "list-box"
				x.RowCount = len(n.Options)
				x.activationGuard = listBoxHostGuard(r)
			}
			x.Value = n.SelectedID
			for _, option := range n.Options {
				if option.ID == n.SelectedID {
					x.Value = option.Label
					break
				}
			}
			_, x.Focusable = ui.FocusTarget(n, n.ID)
			// Keyboard focus belongs to one option; group focus is a managed proxy.
			x.Focused = false
		case ui.Selector, ui.Tabs:
			x.Value = n.SelectedID
			for _, o := range n.Options {
				if o.ID == n.SelectedID {
					x.Value = o.Label
					break
				}
			}
		}
		if !disabled {
			if x.Focusable {
				x.Actions = append(x.Actions, "focus")
			}
			if n.Kind == ui.Button && n.Activate != nil {
				x.Actions = append(x.Actions, "press")
			}
			if n.Kind == ui.MenuButton {
				x.Actions = append(x.Actions, "press", "expand")
				if menuOpen(r) {
					x.Actions = append(x.Actions, "cancel", "collapse")
				}
			}
			if (n.Kind == ui.Checkbox || n.Kind == ui.Switch || n.Kind == ui.ToggleButton) && n.Change != nil {
				x.Actions = append(x.Actions, "press", "set")
			}
			if n.Kind == ui.MultilineText {
				x.Actions = append(x.Actions, "set", "selection")
			}
			if n.Kind == ui.TextField && n.Change != nil {
				x.Actions = append(x.Actions, "selection")
			}
			if (n.Kind == ui.TextField || n.Kind == ui.Slider || n.Kind == ui.NumberField) && n.Change != nil {
				x.Actions = append(x.Actions, "set")
			}
			if (n.Kind == ui.Slider || n.Kind == ui.NumberField) && n.Change != nil {
				x.Actions = append(x.Actions, "increment", "decrement")
			}
			if (n.Kind == ui.Selector || n.Kind == ui.Tabs || n.Kind == ui.RadioGroup || n.Kind == ui.SegmentedControl || n.Kind == ui.ListBox) && n.Change != nil {
				x.Actions = append(x.Actions, "set")
			}
			if n.Kind == ui.Dialog && n.Dismiss != nil {
				x.Actions = append(x.Actions, "cancel")
			}
		}
		if n.Kind == ui.Button && r.control != nil {
			x.activationGuard = placementActivationGuard(r)
		}
		nodes = append(nodes, x)
		if len(x.Actions) > 0 {
			allowed := append([]string(nil), x.Actions...)
			handlers[x.ID] = func(action accessibilityAction) bool {
				if n.Kind == ui.ListBox && !x.activationGuard() {
					return false
				}
				if !containsAccessibilityAction(allowed, action.Kind) {
					return false
				}
				if action.Kind == "focus" {
					accessibilityFocus(b, x.ID)
					return true
				}
				return applyAccessibilityAction(r, action)
			}
		}
		if n.Kind == ui.Disclosure && r.control != nil && r.control.disclosure != nil {
			nodes[len(nodes)-1].Focusable = false
			nodes[len(nodes)-1].Focused = false
			nodes[len(nodes)-1].Actions = []string{}
			delete(handlers, x.ID)
			heading, handler := disclosureAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, heading)
			if handler != nil {
				handlers[heading.ID] = handler
			}
		}
		if n.Kind == ui.Canvas2D && len(n.CanvasObjects) > 0 && r.control != nil && r.control.placement != nil {
			extra, actions := canvasAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, extra...)
			for id, action := range actions {
				handlers[id] = action
			}
		}
		if n.Kind == ui.DataTree && r.control != nil && r.control.outline != nil {
			extra, actions := treeAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, extra...)
			for id, action := range actions {
				handlers[id] = action
			}
		}
		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			extra, actions := segmentedLegacyGridAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, extra...)
			for id, action := range actions {
				handlers[id] = action
			}
		}
		if n.Kind == ui.Extension {
			extra, actions := extensionAccessibility(r, b, disabled)
			nodes = append(nodes, extra...)
			for id, action := range actions {
				handlers[id] = action
			}
		}
		if r.control != nil && r.control.choice != nil {
			extra, actions := choiceAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, extra...)
			for id, handler := range actions {
				handlers[id] = handler
			}
		}
		if n.Kind == ui.MenuButton {
			extra, actions := menuAccessibility(r, x.ID, b)
			nodes = append(nodes, extra...)
			for id, handler := range actions {
				handlers[id] = handler
			}
		}
		if n.Kind == ui.Tabs || n.Kind == ui.Selector {
			for _, o := range n.Options {
				id := accessibilityOptionID(n.ID, o.ID)
				child := accessibilityNode{ID: id, Parent: x.ID, Role: "option", DomainID: o.ID, Name: o.Label, Selected: o.ID == n.SelectedID, Value: o.ID == n.SelectedID, Disabled: disabled || o.Disabled, Actions: []string{}}
				if !child.Disabled && n.Change != nil {
					child.Actions = []string{"press"}
					optionID := o.ID
					handlers[id] = func(action accessibilityAction) bool {
						if action.Kind != "press" {
							return false
						}
						return applyAccessibilityAction(r, accessibilityAction{Kind: "set", Value: optionID})
					}
				}
				nodes = append(nodes, child)
				if n.Kind == ui.Tabs && o.Closable {
					close, handler := tabCloseAccessibility(r, o, id, disabled)
					nodes = append(nodes, close)
					if handler != nil {
						handlers[close.ID] = handler
					}
				}
			}
		}
		if edit := gridEditingRecord(r); edit != nil {
			visit(edit, x.ID, disabled)
		}
		for i, c := range r.children {
			if n.Kind == ui.SplitPane && i == 1 && r.control != nil && r.control.split != nil {
				handle, action := splitAccessibility(r, x.ID, b, disabled)
				nodes = append(nodes, handle)
				if action != nil {
					handlers[handle.ID] = action
				}
			}
			if n.Kind == ui.Disclosure && !n.Checked || n.Kind == ui.Tabs && c.node.ID != n.SelectedID {
				continue
			}
			visit(c, x.ID, disabled)
		}
		if n.Kind == ui.Canvas2D && len(n.CanvasObjects) > 0 && r.control != nil && r.control.placement != nil {
			stampCanvasAccessibility(r, nodes[start:], handlers)
		}
		if n.Kind == ui.DataTree && r.control != nil && r.control.outline != nil {
			stampTreeAccessibility(r, nodes[start:])
			guardTreeAccessibility(r.control.outline, nodes[start:], handlers)
		}
		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			stampGridAccessibility(r, nodes[start:])
			guardGridAccessibility(r.control.grid, nodes[start:], handlers)
		}
	}
	visit(scoped, "", inheritedDisabled)
	return namespaceAccessibility(nodes, handlers, namespace, b)
}

func segmentedLegacyGridAccessibility(r *record, parent string, b *accessibilityBridge, disabled bool) ([]accessibilityNode, map[string]accessibilityHandler) {
	g := r.control.grid
	m := g.currentMeasurement()
	nodes := []accessibilityNode{}
	handlers := map[string]accessibilityHandler{}
	if m == nil || m.Generation != g.projection.State.Generation {
		return nodes, handlers
	}
	rows := map[string]string{}
	visibleCells, visibleHeaders := 0, 0
	for _, c := range m.Cells {
		if !c.Bounds.Empty() {
			visibleCells++
			rows[c.RowKey] = ""
		}
	}
	for _, h := range m.Headers {
		if !h.Bounds.Empty() {
			visibleHeaders++
		}
	}
	// Count the exact completed visible records, including one row per key.
	// Empty overscan remains absent and first appearance still orders rows.
	nodes = make([]accessibilityNode, 0, visibleCells+visibleHeaders+len(rows))
	if !disabled {
		handlers = make(map[string]accessibilityHandler, visibleCells)
	}
	rowSelection := m.RowSelection
	for i, c := range m.Cells {
		if c.Bounds.Empty() {
			continue
		}
		rowID := accessibilityRowID(r.node.ID, c.RowKey)
		if rows[c.RowKey] == "" {
			rows[c.RowKey] = rowID
			nodes = append(nodes, accessibilityNode{ID: rowID, DomainID: gridRowID(r.node.ID, c.RowKey), Parent: parent, Role: "grid-row", Name: c.RowKey, RowIndex: c.Row + 1, RowCount: m.Stamp.Rows, Selected: rowSelection && c.Selected, Disabled: disabled, Actions: []string{}})
		}
		id := accessibilityManagedID(c.ID)
		selected := c.Active
		if rowSelection {
			selected = c.Selected
		}
		x := accessibilityNode{pressFocusID: parent, ID: id, DomainID: c.ID, Parent: rowID, Role: "grid-cell", Name: c.Text, Value: c.Text, Disabled: disabled, Selected: selected, RowIndex: c.Row + 1, ColumnIndex: c.Column + 1, Actions: []string{}}
		if !disabled {
			x.Actions = []string{"press"}
			ref := g.projection.Cells[i].Ref
			handlers[id] = func(a accessibilityAction) bool {
				if a.Kind != "press" || !g.eligible() {
					return false
				}
				before, e := g.model.State()
				if e != nil {
					return false
				}
				if e = g.model.Activate(ref); e != nil {
					g.fail(e)
					return false
				}
				after, e := g.model.State()
				if e != nil {
					return false
				}
				if before.Generation != after.Generation {
					if cb := r.node.GridChange; cb != nil {
						cb(ui.GridEvent{ID: r.node.ID, Reason: ui.GridSelection, State: after})
					}
					_ = g.owner.Invalidate(g.window)
				}
				if b != nil {
					accessibilityFocus(b, parent)
				}
				return true
			}
		}
		nodes = append(nodes, x)
	}
	for _, h := range m.Headers {
		if h.Bounds.Empty() {
			continue
		}
		nodes = append(nodes, accessibilityNode{ID: accessibilityManagedID(h.ID), DomainID: h.ID, Parent: parent, Role: "grid-column", Name: h.Title, Value: h.Title, ColumnIndex: h.Column + 1, Disabled: disabled, Actions: []string{}})
	}
	return nodes, handlers
}
