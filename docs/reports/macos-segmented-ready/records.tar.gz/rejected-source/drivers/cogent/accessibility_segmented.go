// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package cogent

import (
	"image"
	"math"

	"github.com/dshills/vellum/ui"
)

type accessibilitySegmentedRow struct {
	id     string
	first  int
	bounds image.Rectangle
}

type accessibilitySegmentedGrid struct {
	measurement *GridInspection
	rows        map[string]accessibilitySegmentedRow
	count       int
}

// All records in a segment are freshly constructed, privately owned and frozen
// before bridge admission. Grid groups are also the final completed cache. No
// group shares an array backing with a sibling; the ordered vector owns refs only.
type accessibilitySegmentedSnapshot struct {
	plans    map[*record]accessibilitySegmentedGrid
	groups   map[string][]accessibilityNode
	refs     []accessibilityNodeRef
	handlers map[string]accessibilityHandler
	guards   map[string]func() bool
}

func (s *accessibilitySegmentedSnapshot) view() accessibilityWireBaseline {
	return accessibilityWireBaseline{references: s.refs}
}

func coherentAccessibilitySegment(r *record, m *GridInspection) bool {
	if r.control == nil || r.control.grid == nil || len(r.children) != 0 || gridEditingRecord(r) != nil {
		return false
	}
	g := r.control.grid
	if !g.live() || !g.projectionReady || r.node.Grid != g.model || m == nil || m.Editor != nil ||
		m.Incarnation != g.incarnation || m.CellIncarnation != g.epoch || g.currentMeasurement() != m || len(m.Cells) != len(g.projection.Cells) {
		return false
	}
	state, err := g.model.State()
	return err == nil && state.Generation == m.Generation && state.Stamp == m.Stamp && state.Viewport == m.Viewport
}

func (s *accessibilitySegmentedSnapshot) coherent() bool {
	for r, plan := range s.plans {
		if !coherentAccessibilitySegment(r, plan.measurement) {
			return false
		}
	}
	return true
}

// Keep the first admission deliberately explicit. Other controls may stamp an
// entire descendant interval or introduce a modal/namespace/editor/custom view;
// they use the full old producer before any bridge state is touched.
func buildAccessibilitySegmented(root *record, b *accessibilityBridge) *accessibilitySegmentedSnapshot {
	if root == nil {
		return nil
	}
	// Reject the whole shape before allocating row plans. This whitelist cannot
	// introduce modal scopes or Workbench namespaces, so it also makes a separate
	// visibleAccessibilityScope pre-scan redundant.
	var grids []*record
	count := 0
	var admit func(*record) bool
	admit = func(r *record) bool {
		if r == nil || r.node.Custom != nil {
			return false
		}
		switch r.node.Kind {
		case ui.Column, ui.Row, ui.Scroll, ui.Label, ui.Button, ui.StatusBar:
			count++
		case ui.Separator:
			return len(r.children) == 0
		case ui.DataGrid:
			if r.control == nil || r.control.grid == nil || len(r.children) != 0 || gridEditingRecord(r) != nil {
				return false
			}
			grids = append(grids, r)
		default:
			return false
		}
		if count > 1<<20 {
			return false
		}
		for _, child := range r.children {
			if !admit(child) {
				return false
			}
		}
		return true
	}
	if !admit(root) || len(grids) == 0 {
		return nil
	}
	s := &accessibilitySegmentedSnapshot{plans: make(map[*record]accessibilitySegmentedGrid, len(grids)), groups: make(map[string][]accessibilityNode, len(grids)), guards: map[string]func() bool{}}
	for _, r := range grids {
		m := r.control.grid.currentMeasurement()
		if !coherentAccessibilitySegment(r, m) {
			return nil
		}
		plan := accessibilitySegmentedGrid{measurement: m, rows: map[string]accessibilitySegmentedRow{}, count: 1}
		for i, c := range m.Cells {
			if c.Bounds.Empty() {
				continue
			}
			row, exists := plan.rows[c.RowKey]
			if !exists {
				row = accessibilitySegmentedRow{id: accessibilityRowID(r.node.ID, c.RowKey), first: i}
				plan.count++
			}
			row.bounds = row.bounds.Union(c.Bounds)
			plan.rows[c.RowKey] = row
			plan.count++
		}
		for _, h := range m.Headers {
			if !h.Bounds.Empty() {
				plan.count++
			}
		}
		s.plans[r] = plan
		count += plan.count
		if count > 1<<20 {
			return nil // Reservation only; old path retains its contract.
		}
	}
	s.refs = make([]accessibilityNodeRef, 0, count)
	accessibilityBuildSnapshot(root, b, false, s)
	if !s.coherent() {
		return nil
	}
	return s
}

func (s *accessibilitySegmentedSnapshot) appendOwned(nodes []accessibilityNode, scope string) {
	for i := range nodes {
		n := &nodes[i]
		if n.activationGuard != nil {
			s.guards[n.ID] = n.activationGuard
		}
		// Action callbacks belong only to current handlers/guards, never cache refs.
		n.activationGuard = nil
		if scope == "" {
			n.pressFocusID = ""
		}
		s.refs = append(s.refs, accessibilityNodeRef{node: n, actionsNil: n.Actions == nil})
	}
	if scope != "" {
		s.groups[scope] = nodes
	}
}

func (s *accessibilitySegmentedSnapshot) grid(r *record, host accessibilityNode, b *accessibilityBridge, disabled bool, handlers map[string]accessibilityHandler) []accessibilityNode {
	plan := s.plans[r]
	m, g := plan.measurement, r.control.grid
	nodes := make([]accessibilityNode, 0, plan.count)
	frames := make([][4]float32, plan.count)
	// Shared only by immutable nodes in this private group. Appending detaches.
	press := []string{"press"}
	appendNode := func(n accessibilityNode, bounds image.Rectangle) {
		i := len(nodes)
		frames[i] = [4]float32{float32(bounds.Min.X), float32(bounds.Min.Y), float32(bounds.Dx()), float32(bounds.Dy())}
		n.GridScope, n.GridIncarnation = host.ID, g.incarnation
		n.GridGeneration, n.GridTargetGeneration = m.Generation, g.projection.State.Generation
		n.GridFrame = &frames[i]
		nodes = append(nodes, n)
	}
	appendNode(host, m.Bounds)
	for i, c := range m.Cells {
		if c.Bounds.Empty() {
			continue
		}
		row := plan.rows[c.RowKey]
		if row.first == i {
			appendNode(accessibilityNode{ID: row.id, DomainID: gridRowID(r.node.ID, c.RowKey), Parent: host.ID, Role: "grid-row", Name: c.RowKey, RowIndex: c.Row + 1, RowCount: m.Stamp.Rows, Selected: m.RowSelection && c.Selected, Disabled: disabled, Actions: []string{}}, row.bounds)
		}
		id := accessibilityManagedID(c.ID)
		selected := c.Active
		if m.RowSelection {
			selected = c.Selected
		}
		n := accessibilityNode{pressFocusID: host.ID, ID: id, DomainID: c.ID, Parent: row.id, Role: "grid-cell", Name: c.Text, Value: c.Text, Disabled: disabled, Selected: selected, RowIndex: c.Row + 1, ColumnIndex: c.Column + 1, Actions: []string{}}
		if !disabled {
			n.Actions = press[:1:1]
			ref := g.projection.Cells[i].Ref
			handlers[id] = func(a accessibilityAction) bool {
				if a.Kind != "press" || !g.eligible() {
					return false
				}
				before, err := g.model.State()
				if err != nil {
					return false
				}
				if err = g.model.Activate(ref); err != nil {
					g.fail(err)
					return false
				}
				after, err := g.model.State()
				if err != nil {
					return false
				}
				if before.Generation != after.Generation {
					if cb := r.node.GridChange; cb != nil {
						cb(ui.GridEvent{ID: r.node.ID, Reason: ui.GridSelection, State: after})
					}
					_ = g.owner.Invalidate(g.window)
				}
				if b != nil {
					accessibilityFocus(b, host.ID)
				}
				return true
			}
		}
		appendNode(n, c.Bounds)
	}
	for _, h := range m.Headers {
		if h.Bounds.Empty() {
			continue
		}
		appendNode(accessibilityNode{ID: accessibilityManagedID(h.ID), DomainID: h.ID, Parent: host.ID, Role: "grid-column", Name: h.Title, Value: h.Title, ColumnIndex: h.Column + 1, Disabled: disabled, Actions: []string{}}, h.Bounds)
	}
	return nodes
}

func (b *accessibilityBridge) sameSegmentedMetadata(s *accessibilitySegmentedSnapshot) bool {
	if len(b.gridPublications) != len(s.groups) {
		return false
	}
	for id, group := range s.groups {
		previous := b.gridPublications[id]
		if len(group) != len(previous) {
			return false
		}
		for i := range group {
			if group[i].ID != previous[i].ID || group[i].pressFocusID != previous[i].pressFocusID || group[i].Value != previous[i].Value {
				return false
			}
		}
	}
	return true
}

// Refusal precedes bridge/cache/generation mutation. No custom callback can enter
// this path: the producer whitelist and builtin writer must both admit it.
func (b *accessibilityBridge) updateSegmentedReady(s *accessibilitySegmentedSnapshot) bool {
	if !s.coherent() || b.closed.Load() {
		return false
	}
	view := s.view()
	b.mu.Lock()
	if b.closed.Load() || b.pendingExhausted || b.generation.Load() == math.MaxUint64 {
		b.mu.Unlock()
		return false
	}
	baseline := b.wireBaseline()
	same := b.completedSnapshot != "" && b.completedSnapshot == b.lastSnapshot && baseline.len() == view.len()
	if same {
		for i := 0; i < view.len(); i++ {
			if !accessibilitySameWireNode(baseline.at(i), *view.pointer(i)) {
				same = false
				break
			}
		}
	}
	if same && b.sameSegmentedMetadata(s) {
		b.handlers, b.activationGuards = s.handlers, s.guards
		b.mu.Unlock()
		return true
	}
	b.mu.Unlock()
	semantic, ok := accessibilityBuiltinSemanticView(view, false, b.semanticAllocationHint(view.len()))
	if !ok || !s.coherent() {
		return false
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed.Load() || b.pendingExhausted || b.generation.Load() == math.MaxUint64 {
		return false
	}
	unchanged := b.lastSnapshot == semantic
	b.handlers, b.activationGuards = s.handlers, s.guards
	b.gridPublications, b.completedSnapshot = s.groups, semantic
	b.pendingBaseline, b.readyBaseline = nil, s.refs
	b.lastSnapshot = semantic
	if unchanged {
		return true
	}
	b.updateGeometryMembershipView(view)
	generation := b.generation.Add(1)
	nativeAccessibilityUpdate(b.token, accessibilityPayload(generation, semantic))
	return true
}
