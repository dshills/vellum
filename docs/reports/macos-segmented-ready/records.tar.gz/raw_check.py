from pathlib import Path
import json,statistics,hashlib
W=Path(__file__).resolve().parent;assessment=json.loads((W/'assessment.json').read_text());runs=[]
for pair in range(1,6):
 r={'pair':pair}
 for label in ['baseline','candidate']:
  p=W/'native/native'/f'{pair}-{label}'/'native.log';records=[json.loads(l) for l in p.read_text().splitlines() if l.startswith('{')];samples=[d for d in records if d.get('event')=='grid.perf.sample'];assert len(samples)==120
  ordered=sorted(x['metrics']['ui_work_ns'] for x in samples);r[label]={'count':len(ordered),'p95_ns':ordered[(95*len(ordered)+99)//100-1],'p99_ns':ordered[(99*len(ordered)+99)//100-1],'process_alloc_p50_bytes':sorted(x['go_process_alloc_bytes'] for x in samples)[(50*len(samples)+99)//100-1],'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  expected=assessment['runs'][pair-1];assert r[label]['p95_ns']==expected[label+'_p95_ns'] and r[label]['p99_ns']==expected[label+'_p99_ns'];assert all('AccessibilitySegmentedUpdates' not in x['native_sample'] for x in samples)
 runs.append(r)
for label in ['baseline','candidate']:
 assert statistics.median(r[label]['process_alloc_p50_bytes'] for r in runs)==assessment['median_run_median_process_alloc_bytes'][label]
(W/'independent-raw-check.json').write_text(json.dumps({'result':'ALL_TEN_ORDINARY_LOGS_RECOMPUTED','runs':runs,'method':'Integer nearest rank, independently recomputed from raw ordinary sample metrics; diagnostic field absent on all1200ordinarysamples'},indent=2)+'\n');print('All10logs/1200samples match report; ordinary diagnostic field omitted')
