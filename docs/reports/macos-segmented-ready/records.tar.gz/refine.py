from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13/drivers/cogent')
p=T/'accessibility_segmented.go';s=p.read_text();a=s.index('\tscoped, namespace := visibleAccessibilityScope(root)');z=s.index('\ts.refs = make(',a)
s=s[:a]+'''\t// Reject the whole shape before allocating row plans. This whitelist cannot
	// introduce modal scopes or Workbench namespaces, so it also makes a separate
	// visibleAccessibilityScope pre-scan redundant.
	var grids []*record
	count := 0
	var admit func(*record) bool
	admit = func(r *record) bool {
		if r == nil || r.node.Custom != nil {
			return false
		}
		switch r.node.Kind {
		case ui.Column, ui.Row, ui.Scroll, ui.Label, ui.Button, ui.StatusBar:
			count++
		case ui.Separator:
			return len(r.children) == 0
		case ui.DataGrid:
			if r.control == nil || r.control.grid == nil || len(r.children) != 0 || gridEditingRecord(r) != nil {
				return false
			}
			grids = append(grids, r)
		default:
			return false
		}
		if count > 1<<20 {
			return false
		}
		for _, child := range r.children {
			if !admit(child) {
				return false
			}
		}
		return true
	}
	if !admit(root) || len(grids) == 0 {
		return nil
	}
	s := &accessibilitySegmentedSnapshot{plans: make(map[*record]accessibilitySegmentedGrid, len(grids)), groups: make(map[string][]accessibilityNode, len(grids)), guards: map[string]func() bool{}}
	for _, r := range grids {
		m := r.control.grid.currentMeasurement()
		if !coherentAccessibilitySegment(r, m) {
			return nil
		}
		plan := accessibilitySegmentedGrid{measurement: m, rows: map[string]accessibilitySegmentedRow{}, count: 1}
		for i, c := range m.Cells {
			if c.Bounds.Empty() {
				continue
			}
			row, exists := plan.rows[c.RowKey]
			if !exists {
				row = accessibilitySegmentedRow{id: accessibilityRowID(r.node.ID, c.RowKey), first: i}
				plan.count++
			}
			row.bounds = row.bounds.Union(c.Bounds)
			plan.rows[c.RowKey] = row
			plan.count++
		}
		for _, h := range m.Headers {
			if !h.Bounds.Empty() {
				plan.count++
			}
		}
		s.plans[r] = plan
		count += plan.count
		if count > 1<<20 {
			return nil // Reservation only; old path retains its contract.
		}
	}
''' + s[z:];p.write_text(s)
p=T/'accessibility_segmented_offscreen_test.go';s=p.read_text().replace('"fmt"','"fmt"\n\t"image"');s+='''
// Start with an actual completed measurement, then detach its cells/headers and
// inject the otherwise rare empty-first geometry and row-selection wire state.
// This tests producer parity, not the domain model's row-selection implementation.
func TestAccessibilitySegmentedRowSelectionEmptyFirstParity(t *testing.T) {
	g, _ := testNativeGrid(t, 10000)
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: g, Grow: true} })
	gridFrame(t, m)
	if err := a.Do(func() {
		binding := gBinding(t, g)
		original := binding.measurement.Load()
		copy := *original
		copy.Cells = append(copy.Cells[:0:0], original.Cells...)
		copy.Headers = append(copy.Headers[:0:0], original.Headers...)
		if len(copy.Cells) < 2 || len(copy.Headers) < 2 { t.Fatal("fixture lacks geometry") }
		row := copy.Cells[0].RowKey
		copy.RowSelection = true
		for i := range copy.Cells { copy.Cells[i].Selected = copy.Cells[i].RowKey == row }
		copy.Cells[0].Bounds = image.Rectangle{}
		copy.Headers[0].Bounds = image.Rectangle{}
		binding.measurement.Store(&copy)
		defer binding.measurement.Store(original)
		root := m.implementation.find("one").state.root
		old, _ := segmentedLegacySnapshot(root, nil, false)
		s := buildAccessibilitySegmented(root, nil)
		if s == nil { t.Fatal("detached coherent measurement refused") }
		want, err := json.Marshal(old); if err != nil { t.Fatal(err) }
		got, ok := accessibilityBuiltinSemanticView(s.view(), false, 0)
		if !ok || got != string(want) { t.Fatal("row-selection/empty-first wire or geometry differs") }
		selectedRows, selectedCells := 0, 0
		for _, n := range segmentedNodes(s) {
			if n.Role == "grid-row" && n.Selected { selectedRows++ }
			if n.Role == "grid-cell" && n.Selected { selectedCells++ }
			if n.DomainID == copy.Cells[0].ID || n.DomainID == copy.Headers[0].ID { t.Fatal("empty geometry emitted") }
		}
		if selectedRows != 1 || selectedCells == 0 { t.Fatal("selection fixture was not exercised") }
	}); err != nil { t.Fatal(err) }
}

func TestAccessibilitySegmentedFreshPressSelectionChangeAndFocus(t *testing.T) {
	g, _ := testNativeGrid(t, 10000)
	var events []ui.GridEvent
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node {
		return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: g, Grow: true, GridChange: func(e ui.GridEvent) { events = append(events, e) }}
	})
	gridFrame(t, m)
	b := newAccessibilityBridge(a); b.bind("one"); t.Cleanup(b.close)
	if err := a.Do(func() {
		root := m.implementation.find("one").state.root
		s := buildAccessibilitySegmented(root, b)
		if s == nil || !b.updateSegmentedReady(s) { t.Fatal("fresh route refused") }
		before, err := g.State(); if err != nil { t.Fatal(err) }
		measurement := gBinding(t, g).currentMeasurement()
		for _, c := range measurement.Cells {
			if c.Bounds.Empty() || c.Active { continue }
			h := b.handlers[accessibilityManagedID(c.ID)]
			if h == nil || !h(accessibilityAction{Kind: "press"}) { t.Fatal("fresh cell press refused") }
			after, err := g.State(); if err != nil { t.Fatal(err) }
			if after.Generation <= before.Generation || after.Active.RowKey != c.RowKey || after.Active.ColumnID != measurementColumnID(gBinding(t, g), c.Column) { t.Fatal("press did not select target") }
			if len(events) != 1 || events[0].ID != "g" || events[0].Reason != ui.GridSelection || events[0].State != after { t.Fatal("press did not publish exactly one selection change") }
			if focus := b.pendingFocus.Load(); focus == nil || *focus != accessibilityManagedID("g") { t.Fatal("press did not request grid focus") }
			return
		}
		t.Fatal("fixture lacks a nonactive visible cell")
	}); err != nil { t.Fatal(err) }
}
'''
# Column identity is carried in the projection's public cell record.
s=s.replace('measurementColumnID(gBinding(t, g), c.Column)', 'gBinding(t, g).projection.Cells[c.Slot].ColumnID') if False else s
s=s.replace('measurementColumnID(gBinding(t, g), c.Column)', 'fmt.Sprintf("c%d", c.Column)')
p.write_text(s)
