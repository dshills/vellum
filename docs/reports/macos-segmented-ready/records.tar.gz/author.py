from pathlib import Path

T = Path('/private/tmp/vellum-macos-native-results-97aee13')
W = Path(__file__).resolve().parent
p = T / 'drivers/cogent/accessibility.go'
source = p.read_text()
legacy = source[source.index('func accessibilitySnapshotInherited('):source.index('func accessibilityIDPart(')]
legacy = legacy.replace('func accessibilitySnapshotInherited(', 'func segmentedLegacySnapshot(').replace('gridAccessibility(r,', 'segmentedLegacyGridAccessibility(r,')
grid = (T / 'drivers/cogent/grid_accessibility.go').read_text()
grid = grid[grid.index('func gridAccessibility('):grid.index('func gridAccessibilityBounds(')].replace('func gridAccessibility(', 'func segmentedLegacyGridAccessibility(')
header = '''//go:build offscreen

// Frozen 9d3c97f producer, independent of the segmented visitor and grid builder.
package cogent

import (
 "strings"
 "cogentcore.org/core/styles/states"
 "github.com/dshills/vellum/drivers/cogent/internal/textinput"
 "github.com/dshills/vellum/editor"
 "github.com/dshills/vellum/ui"
)

'''
(T / 'drivers/cogent/accessibility_segmented_reference_offscreen_test.go').write_text(header + legacy + '\n' + grid)

# The original entrypoint retains the complete flat path. Only a separately
# preflighted segmented owner producer passes a nonnil collector.
needle = 'func accessibilitySnapshotInherited(root *record, b *accessibilityBridge, inheritedDisabled bool) ([]accessibilityNode, map[string]accessibilityHandler) {\n'
replacement = needle + '\treturn accessibilityBuildSnapshot(root, b, inheritedDisabled, nil)\n}\n\nfunc accessibilityBuildSnapshot(root *record, b *accessibilityBridge, inheritedDisabled bool, segmented *accessibilitySegmentedSnapshot) ([]accessibilityNode, map[string]accessibilityHandler) {\n'
assert source.count(needle) == 1
source = source.replace(needle, replacement)
needle = '\tvisit = func(r *record, parent string, disabled bool) {\n\t\tstart := len(nodes)'
replacement = '\tvisit = func(r *record, parent string, disabled bool) {\n\t\tif segmented != nil && r.node.Kind == ui.DataGrid {\n\t\t\tsegmented.appendOwned(nodes, "")\n\t\t\tnodes = nil\n\t\t}\n\t\tstart := len(nodes)'
assert source.count(needle) == 1
source = source.replace(needle, replacement)
needle = '''		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			extra, actions := gridAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, extra...)
			for id, action := range actions {
				handlers[id] = action
			}
		}'''
replacement = '''		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			if segmented != nil {
				nodes = segmented.grid(r, nodes[0], b, disabled, handlers)
			} else {
				extra, actions := gridAccessibility(r, x.ID, b, disabled)
				nodes = append(nodes, extra...)
				for id, action := range actions {
					handlers[id] = action
				}
			}
		}'''
assert source.count(needle) == 1
source = source.replace(needle, replacement)
needle = '''		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			stampGridAccessibility(r, nodes[start:])
			guardGridAccessibility(r.control.grid, nodes[start:], handlers)
		}'''
replacement = '''		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			if segmented == nil {
				stampGridAccessibility(r, nodes[start:])
			}
			guardGridAccessibility(r.control.grid, nodes[start:], handlers)
			if segmented != nil {
				segmented.appendOwned(nodes, nodes[0].ID)
				nodes = nil
			}
		}'''
assert source.count(needle) == 1
source = source.replace(needle, replacement)
needle = '\tvisit(scoped, "", inheritedDisabled)\n\treturn namespaceAccessibility(nodes, handlers, namespace, b)'
replacement = '\tvisit(scoped, "", inheritedDisabled)\n\tif segmented != nil {\n\t\tsegmented.appendOwned(nodes, "")\n\t\tsegmented.handlers = handlers\n\t\treturn nil, handlers\n\t}\n\treturn namespaceAccessibility(nodes, handlers, namespace, b)'
assert source.count(needle) == 1
source = source.replace(needle, replacement)
needle = '''	nodes, handlers := accessibilitySnapshot(w.root, b)
	// A modal projection'''
replacement = '''	scope := ""
	segmented := buildAccessibilitySegmented(w.root, b)
	if segmented != nil && b.updateSegmentedReady(segmented) {
		scope = segmented.view().pointer(0).ID
		if w.metrics != nil && w.metrics.metrics.sourceDetails && w.axSegmented.Load() != math.MaxUint64 {
			w.axSegmented.Add(1)
		}
	} else {
		nodes, handlers := accessibilitySnapshot(w.root, b)
		if len(nodes) != 0 {
			scope = nodes[0].ID
		}
		b.updateOwned(nodes, handlers)
	}
	// A modal projection'''
assert source.count(needle) == 1
source = source.replace(needle, replacement)
needle = '''	scope := ""
	if len(nodes) != 0 {
		scope = nodes[0].ID
	}
	b.updateOwned(nodes, handlers)
	if scope != w.axScope'''
assert source.count(needle) == 1
source = source.replace(needle, '\tif scope != w.axScope')
p.write_text(source)

# Iterate the same fixed writer over direct pointers; no flat record copies.
p = T / 'drivers/cogent/accessibility_semantic.go'
s = p.read_text()
needle = 'func accessibilityBuiltinSemanticHinted(nodes []accessibilityNode, hint int) (string, bool) {\n\tfor i := range nodes {\n\t\tn := &nodes[i]'
replacement = '''func accessibilityBuiltinSemanticHinted(nodes []accessibilityNode, hint int) (string, bool) {
	return accessibilityBuiltinSemanticView(accessibilityWireBaseline{nodes: nodes}, nodes == nil, hint)
}

func accessibilityBuiltinSemanticView(nodes accessibilityWireBaseline, isNil bool, hint int) (string, bool) {
	for i := 0; i < nodes.len(); i++ {
		n := nodes.pointer(i)
		if n == nil { return "", false }'''
assert s.count(needle) == 1
s = s.replace(needle, replacement).replace('if nodes == nil {', 'if isNil {').replace('len(nodes)', 'nodes.len()')
s = s.replace('for i := range nodes {', 'for i := 0; i < nodes.len(); i++ {')
s = s.replace('e.node(&nodes[i])', '''if nodes.references != nil && nodes.references[i].actionsNil {
			n := *nodes.pointer(i)
			n.Actions = nil
			e.node(&n)
		} else {
			e.node(nodes.pointer(i))
		}''')
p.write_text(s)
p = T / 'drivers/cogent/accessibility_pending.go'
s = p.read_text()
needle = 'func (b accessibilityWireBaseline) at(i int) accessibilityNode {'
assert s.count(needle) == 1
s = s.replace(needle, '''func (b accessibilityWireBaseline) pointer(i int) *accessibilityNode {
	if b.references != nil { return b.references[i].node }
	return &b.nodes[i]
}

''' + needle)
p.write_text(s)
p = T / 'drivers/cogent/accessibility_geometry_cache.go'
s = p.read_text()
s = s.replace('func (b *accessibilityBridge) updateGeometryMembership(nodes []accessibilityNode) {', '''func (b *accessibilityBridge) updateGeometryMembership(nodes []accessibilityNode) {
	b.updateGeometryMembershipView(accessibilityWireBaseline{nodes: nodes})
}

func (b *accessibilityBridge) updateGeometryMembershipView(nodes accessibilityWireBaseline) {''')
s = s.replace('for _, node := range nodes {', 'for i := 0; i < nodes.len(); i++ {\n\t\tnode := nodes.pointer(i)')
p.write_text(s)
p = T / 'drivers/cogent/driver.go'
s = p.read_text().replace('\taxScope          string', '\taxSegmented      atomic.Uint64 // cumulative source-details-only segmented snapshot updates\n\taxScope          string')
p.write_text(s)
p = T / 'drivers/cogent/frame_metrics.go'
s = p.read_text().replace('type FrameSample struct {', '''type FrameSample struct {
	// Cumulative window-lifetime owner update count, observed when this ticket
	// is collected, only in source-details mode. Not per-frame timing/accounting.
	AccessibilitySegmentedUpdates uint64 `json:"AccessibilitySegmentedUpdates,omitempty"`''')
needle = '\t\t\tm.tags[sample.Tag] = len(m.samples)'
s = s.replace(needle, '''			if m.sourceDetails {
				m.samples[len(m.samples)-1].AccessibilitySegmentedUpdates = window.window.axSegmented.Load()
			}
''' + needle)
p.write_text(s)
