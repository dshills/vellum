from pathlib import Path
W=Path(__file__).resolve().parent
s=(W.parent/'macos-ax-semantic-02f8dbe/native_compare.py').read_text()
s=s.replace("['drivers/cogent/accessibility.go','drivers/cogent/accessibility_semantic.go']", "['drivers/cogent/'+n for n in ['accessibility.go','accessibility_segmented.go','accessibility_geometry_cache.go','accessibility_pending.go','accessibility_semantic.go','driver.go','frame_metrics.go']]")
a=s.index("old=json.loads(");z=s.index("d={'result'",a)
s=s[:a]+'''receipt=W.parent.parent/'macos-ax-semantic-02f8dbe/binary-receipt.json';old=json.loads(receipt.read_text());commit=git(C,'rev-parse','HEAD').decode().strip()
binaries={'baseline':{'path':old['path'],'sha256':old['sha256']},'candidate':{'path':str(P/'bin/segmented'),'sha256':sha(P/'bin/segmented')}}
'''+s[z:]
a=s.index("'candidate_scope':");z=s.index(",'source_diff_sha256'",a)
s=s[:a]+"'candidate_scope':'M3-A private final detached ready grid segments + ordered wire references, same native transport. Baseline reuses verified bd672a6 serializer release binary; 9d3c97f is docs-only. No prepared changes. Eligible ready leaf grids only; full old route for other shapes/coherence.'"+s[z:]
s=s.replace("sha(W.parent.parent/'macos-text-batch-0c59fe0/native-v2/native-comparison.json')", "sha(receipt)")
a=s.index("require(commit=='02f8");z=s.index("d['prepared_before']=prepared()",a)
s=s[:a]+"require(commit=='9d3c97f6b0d670e64ea1271cd8d47a6a6f37999e','baseline commit');require(not git(C,'diff','bd672a6',commit,'--','drivers/cogent','go.mod','examples/loadedgrid'),'baseline runtime source unchanged');require(all(sha(C/'drivers/cogent'/n)==h for n,h in old['compiled_leaves'].items()),'baseline compiled leaves');"+s[z:]
a=s.index("   print(json.dumps({'diagnostic':label")
s=s[:a]+'''   counters=[sample['native_sample'].get('AccessibilitySegmentedUpdates',0) for sample in data]
   d['diagnostics'][label]['segmented_updates']={'first':counters[0],'last':counters[-1],'distinct':len(set(counters)),'nonzero_samples':sum(x>0 for x in counters),'scope':'Cumulative owner snapshot count at ticket collection; source-details-only route evidence, not timing attribution'}
   require((label=='baseline' and not any(counters)) or (label=='candidate' and counters[-1]>counters[0]>0 and all(a<=b for a,b in zip(counters,counters[1:]))),'positive native segmented route evidence')
'''+s[a:]
(W/'native').mkdir(exist_ok=False)
(W/'native_compare.py').write_text(s)
