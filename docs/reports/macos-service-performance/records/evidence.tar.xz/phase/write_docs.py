"""Write the bounded checkpoint after all native processes have terminated."""
import json
from candidate_run import ROOT, PHASE, sha

comparison = json.loads((PHASE / 'comparison/qualification.json').read_text())
receipt = json.loads((PHASE / 'compare-native-v1.json').read_text())
assert receipt['exit_code'] == 0 and receipt['error'] is None and receipt['source_prepared_stable']
assert comparison['result'] == 'PASS_MATCHED_COMPARISON'
summary = json.loads((PHASE / 'comparison/summary.json').read_text())
assert not any(comparison['warm_target_met'].values())
rows = []
for case in ['fixed-10000', 'fixed-1000000', 'variable-10000', 'variable-1000000']:
    a = summary['baseline'][case]['timings_ns']['ui_work_ns']['pooled']
    b = summary['candidate'][case]['timings_ns']['ui_work_ns']['pooled']
    old = summary['baseline'][case]['go_process_alloc_bytes']['p50']
    new = summary['candidate'][case]['go_process_alloc_bytes']['p50']
    rows.append(f"| {case} | {a['p95']/1e6:.3f} / {a['p99']/1e6:.3f} | {b['p95']/1e6:.3f} / {b['p99']/1e6:.3f} | {old:,} → {new:,} ({100*(new/old-1):+.1f}%) |")
report = ROOT / 'docs/reports/macos-service-performance'
report.mkdir(exist_ok=False)
(report / 'README.md').write_text('''# Native services and accessibility allocation

The Mac menu/tray lifecycle fixture passes 100 extra create/clear cycles, and the
candidate passes the stored 400-cell Cocoa accessibility fixture. Accessibility
publication now avoids one semantic byte-to-string copy and preallocates completed
visible grid records. Process-wide allocations fall in the matched table campaign;
frame timing remains mixed and every case still fails the unchanged 4/6 ms targets.

## Implementation and ownership

The baseline is commit `2338d7f56d6acf7c5213b21f1a78cfc8f471909c`. The candidate changes
two adapter implementation leaves and one independent-oracle test leaf. A local
JSON encoder writes compact semantics into an unreused string builder; only its
record-terminating newline is removed. Its output must equal stdlib `json.Marshal`,
including escaping, unusual values and encoding refusal. Later calls cannot mutate
the returned string. Publication rejection ordering, pending/completed transactions,
detached grid caches, action guards and native envelope ownership remain unchanged.

The grid prepass counts nonempty completed cells/headers and unique visible row
keys, then reserves node/action capacity. It preserves first-visible row order and
excludes empty overscan. It introduces no domain callback or native geometry read.

## Native services and correctness

The existing real Cocoa menu/tray fixture passes native selector dispatch, disabled
and stale action refusal, menu replacement/reordering, named/template bitmap
metadata, one-window closure with a surviving service and terminal cleanup. Its
final report records 100 extra create/clear cycles, the original application menu
restored, tray/targets retired, callbacks stopped and no tracked window, bridge,
pending callback or native operation. It takes about 1.66 seconds. Native selector
dispatch is not a physical click, VoiceOver or third-party service workflow.

The candidate separately passes the stored 400-cell Cocoa publication/identity/
action/geometry fixture. Focused accessibility race tests run three times; the full
adapter offscreen race suite and vet pass. These checks do not change input sources,
VoiceOver, clipboard contents or OS preferences. Live execution uses the human's
fresh machine-availability authorization; continuous host isolation is not proven.

## Matched ordinary performance

Two optimized executables use the default scene renderer, the same 6,198 prepared
dependency identities and 710 selected source identities apart from the exact
three candidate leaves. Four fixed/variable 10k/million-row cases each retain five
fresh interleaved baseline/candidate process pairs, alternating launch order,
128 guarded warmups and 120 measured events. All 4,800 ordinary samples are retained.
Every paired geometry record matches exactly and each frame has at least 400 clipped
cells. No profiling or source-detail instrumentation is enabled in this campaign.

Pooled total recorded UI work p95/p99 in milliseconds and median process-wide
allocation bytes per event:

| Case | Baseline p95 / p99 | Candidate p95 / p99 | Allocation p50 bytes |
| --- | ---: | ---: | ---: |
''' + '\n'.join(rows) + '''

These observations support lower process-wide allocation for this campaign, not
a consistent frame-latency improvement. Both builds fail p95 ≤4 ms / p99 ≤6 ms.
Per-run distributions, maxima, source callbacks, geometry and end-only RSS remain
in the raw records. Process allocations include inspection/output and concurrent
runtime work; they are not framework-only or native/GPU allocation counts.

Separate baseline/candidate differential Go allocation profiles are diagnostic
only. They include observers and profile encoding and are excluded from ordinary
timings. Sampled profile attribution cannot establish retained-memory savings,
physical transfers, GPU completion, presentation or input-to-photon latency.

## Evidence and review

Internal source review checks the exact three candidate leaves; protocol review
checks child ownership and the matched workload; independent evidence review
checks receipts and raw observations. Prism reviews this source/spec/report batch
using Anthropic Claude Sonnet 5.5. The [checkpoint](records/checkpoint.json),
[archive](records/evidence.tar.xz) and [member index](records/evidence-index.json)
bind sources, producers, receipts, profiles, raw logs and review results.

See the [checkpoint contract](../../../specs/macos-service-performance.md).
Selected source/prepared/binary identities are not a complete compiler/SDK/cache
closure. Human input/VoiceOver, physical menu/tray use, notification delivery,
cross-display, GPU loss, sustained P6 performance, integrated P11/endurance and
distribution/release qualification remain open.
''')
spec = ROOT / 'specs/macos-service-performance.md'
spec.write_text('''# Mac services and accessibility allocation checkpoint

Semantic encoding may use a local, never-reused string builder to avoid a separate
byte-to-string copy. The resulting compact JSON must equal independent stdlib
Marshal output after removing only the encoder's final record newline. Refusal
returns no partial publication. Escaping, nil/empty input, RawMessage, large integer
and invalid values require parity; subsequent calls cannot mutate prior output.
Initial rejection remains before cache preparation and completed encoding after it.

Completed grid records may reserve exact capacity from nonempty measured cells,
headers and unique visible rows. First-visible row order, empty-overscan exclusion,
semantic actions and stale-action eligibility stay unchanged. The prepass must not
introduce domain callbacks, native geometry reads or cache ownership transfer.

Correctness requires the focused repeated race checks, complete adapter offscreen
race suite, vet and the stored 400-cell Cocoa publication fixture. Native menu/tray
lifecycle checks separately verify actual selector routing, replacement, stale
action refusal, window survival and final native service retirement. Physical
pointer/keyboard, VoiceOver and notification workflows remain separate.

The ordinary comparison uses preceding committed and candidate optimized binaries,
the same prepared dependencies, all four stored-table cases, five fresh interleaved
process pairs per case, 128 guarded warmups, 120 events/process and exact paired
geometry. Preserve all samples and per-run variability. The runner owns the native
process and observer group through normal completion, refusal and hard timeout.
Diagnostic allocation profiles run separately and never satisfy warm acceptance.

Unchanged targets remain total recorded UI work p95 ≤4 ms and p99 ≤6 ms. Lower
process-wide Go allocation does not establish framework-only/retained/native/GPU
memory savings or consistent latency improvement. P6, P11 and full Mac qualification
require their broader workloads. The [report](../docs/reports/macos-service-performance/README.md)
records current results, ownership scope and remaining gates.
''')
for name, heading, paragraph in [
    ('specs/grid-performance.md', '## Accessibility capacity and semantic string comparison',
     'The [service/allocation checkpoint](../docs/reports/macos-service-performance/README.md) compares exact completed-grid capacity reservation and owned semantic string encoding against the preceding committed build. Five interleaved process pairs per stored case retain all 4,800 samples with exact paired geometry. Process-wide allocation is lower, while frame timings are mixed and all unchanged warm targets remain failed. Separate sampled Go allocation profiles remain diagnostic; cache ownership, visible semantics and action guards are unchanged.'),
    ('specs/macos-completion.md', '## Native service and accessibility allocation checks',
     'The [service/allocation checkpoint](../docs/reports/macos-service-performance/README.md) passes 100 additional real Cocoa menu/tray create/clear cycles and final service cleanup, plus the candidate stored 400-cell Cocoa accessibility fixture. Two small adapter changes reduce process-wide allocation in a matched 4,800-sample table campaign; frame timing is mixed and unchanged 4/6 ms targets remain failed. Native selectors do not qualify physical menu/tray interaction or human VoiceOver. This advances scoped implementation and acceptance without completing P6, P11/endurance, notification delivery or full Mac/release qualification.')]:
    path = ROOT / name
    text = path.read_text()
    assert heading not in text
    path.write_text(text.rstrip() + '\n\n' + heading + '\n\n' + paragraph + '\n')
names = ['drivers/cogent/accessibility.go', 'drivers/cogent/grid_accessibility.go',
         'drivers/cogent/accessibility_payload_test.go', 'specs/macos-service-performance.md',
         'specs/grid-performance.md', 'specs/macos-completion.md',
         'docs/reports/macos-service-performance/README.md']
(PHASE / 'checkpoint-source.json').write_text(json.dumps({'sources': {n: sha(ROOT/n) for n in names}}, indent=2) + '\n')
print('Wrote seven checkpoint source leaves.')
