"""Interleaved default-renderer comparison of baseline and candidate binaries."""
from pathlib import Path
import importlib.util, json, os, subprocess
from candidate_run import ROOT, PHASE, baseline, sha

spec = importlib.util.spec_from_file_location('benchmark', ROOT / 'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)

class OwnedBenchmarkSubprocess:
    """Change only this imported benchmark module's native process admission."""
    def __getattr__(self, name):
        return getattr(subprocess, name)

    def Popen(self, *args, **options):
        assert options.pop('start_new_session') is True
        process = subprocess.Popen(*args, **options)
        try:
            assert os.getpgid(process.pid) == os.getpgrp()
        except BaseException:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=5)
            raise
        return process

def stop_native_child(process):
    # Local run_case failures join this direct child through its existing
    # finally. The outer runner separately owns hard cleanup of the group.
    if process.poll() is None:
        process.kill()

benchmark.subprocess = OwnedBenchmarkSubprocess()
benchmark.terminate_owned_group = stop_native_child
before = baseline()
original = json.loads((PHASE / 'baseline.json').read_text())
assert original['prepared'] == before['prepared']
assert set(original['selected_source']) == set(before['selected_source'])
changed = {name for name in original['selected_source']
           if original['selected_source'][name] != before['selected_source'][name]}
assert changed == {'drivers/cogent/accessibility.go', 'drivers/cogent/grid_accessibility.go',
                   'drivers/cogent/accessibility_payload_test.go'}
review = json.loads((PHASE / 'source-review.json').read_text())
assert review['result'] == 'APPROVED_SOURCE' and not review['findings']
assert all(before['selected_source'][name] == review['reviewed_file_sha256'][str(ROOT / name)]
           for name in changed)
binaries = {'baseline': PHASE / 'loadedgrid', 'candidate': PHASE / 'loadedgrid-candidate'}
digests = {name: sha(path) for name, path in binaries.items()}
assert digests['baseline'] == json.loads((PHASE / 'allocation-qualification.json').read_text())['binary_sha256']
out = PHASE / 'comparison'
out.mkdir(exist_ok=False)
results = {mode: {} for mode in binaries}
progress = []
for variable in [False, True]:
    for rows in [10000, 1000000]:
        case = f"{'variable' if variable else 'fixed'}-{rows}"
        for mode in binaries:
            results[mode][case] = []
        for repetition in range(5):
            order = ['baseline', 'candidate'] if repetition % 2 == 0 else ['candidate', 'baseline']
            for mode in order:
                samples, process = benchmark.run_case(binaries[mode], out / mode / case / f'run-{repetition+1}',
                                                      rows, variable, 120, 128, False, 180)
                assert process['result'] == 'PASS' and process['exit_code'] == 0
                assert all(record.get('warmup_guard') == 1 for record in process['records'])
                assert process['records'][1]['warmup'] == process['records'][1]['warm_callbacks'] == 128
                assert before == baseline() and sha(binaries[mode]) == digests[mode]
                results[mode][case].append(samples)
                progress.append({'mode': mode, 'case': case, 'repetition': repetition+1,
                                 'result_sha256': sha(out / mode / case / f'run-{repetition+1}/result.json')})
                (out / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n')
                print(mode, case, repetition+1, flush=True)
            benchmark.compare_geometry(results['baseline'][case][-1], results['candidate'][case][-1])
            assert all(a['geometry'] == b['geometry']
                       for a, b in zip(results['baseline'][case][-1], results['candidate'][case][-1]))
for mode in binaries:
    for prefix in ['fixed', 'variable']:
        for small, large in zip(results[mode][prefix+'-10000'], results[mode][prefix+'-1000000']):
            benchmark.compare_geometry(small, large)
summary = {mode: {case: {'timings_ns': benchmark.summarize(runs),
                         'go_process_alloc_bytes': benchmark.distribution([s['go_process_alloc_bytes'] for run in runs for s in run]),
                         'go_process_mallocs': benchmark.distribution([s['go_process_mallocs'] for run in runs for s in run])}
                  for case, runs in cases.items()} for mode, cases in results.items()}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
qualification = {'result': 'PASS_MATCHED_COMPARISON', 'runtime_baseline_sha256': sha(PHASE / 'baseline.json'),
                 'candidate_baseline_sha256': sha(PHASE / 'candidate-baseline-v1.json'), 'binary_sha256': digests,
                 'processes': 40, 'ordinary_samples': 4800, 'changed_source': sorted(changed),
                 'warm_target_met': {mode: benchmark.warm_target_met(cases) for mode, cases in summary.items()},
                 'summary_sha256': sha(out / 'summary.json'), 'producer_sha256': sha(__file__),
                 'scope': 'Two optimized binaries, four stored cases, five interleaved process pairs per case, exact paired geometry. All observations retained. Process-wide allocations include helpers/runtime; no full P6/Mac or physical GPU/presentation/native-allocation qualification.'}
(out / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
print(json.dumps(qualification), flush=True)
