# Independent matched allocation/timing and profile review

APPROVED_EVIDENCE for completed raw measurements and final factual claims. No unresolved measurement mismatch. Packaging/archive/checkpoint closure is pending a separate audit.

The comparison parent exits0 in353.835415916seconds with stable recorded candidate source/prepared endpoints. Forty fresh processes retain all4,800 ordinary samples. Every result is raw0/PASS; its123 records match native.log exactly. Four stored fixed/variable10k/million cases have five process pairs each, alternating baseline/candidate launch order. Every process has128 guarded warm callbacks, a closed warm viewport and120 completed uniquely correlated tags. Every scalar reported timing matches its raw native ticket, and total UI work equals only the seven measured work phases. Diagnostic flags arefalse; external process observations occur at end only.

Independent nearest-rank p50/p95/p99, min/max, means, sample SD/CV, per-run and pooled values, and variation of run p95 match the producer for all11 timing metrics. All outliers are retained. Process-wide allocation and malloc distributions also match, and GC sums are retained separately. All2,400 paired sample geometry dictionaries and source callback dictionaries are identical. The2,400 within-build10k/million workload comparisons agree on measured cells/rows/columns/scale/layout hash. Every frame has at least400 clipped cells.

| Case | Allocation p50 before→after bytes | Change | UI p95 change | UI p99 change |
|---|---:|---:|---:|---:|
| fixed-10000 |8,200,640→7,475,848|-8.84%|-1.89%|+1.69%|
| fixed-1000000 |7,609,184→6,871,280|-9.70%|+1.08%|+8.98%|
| variable-10000 |7,767,016→7,125,848|-8.26%|-0.07%|+2.03%|
| variable-1000000 |7,464,864→6,761,632|-9.42%|+0.40%|-0.09%|

These observations support lower process-wide allocation for this campaign. Latency changes are mixed, and every run fails the unchanged p95≤4ms/p99≤6ms limits. Percentiles of separate phases are never added. The report's rounded p95/p99/allocation table agrees with independent raw recomputation.

Separate baseline and candidate fixed10k allocation diagnostics each contain120 samples with profiling enabled consistently and ordinary timing instrumentation disabled. Both before/after pprof files match declared hashes, are nonempty gzip profiles within64MiB and have0600 permissions. Live and alloc_space top/cumulative receipts exit0 with their recorded baseline/candidate endpoints; they refer to the correct differential profile files. These sampled Go allocation diagnostics include observers, runtime and profile encoding, and do not establish retained-memory savings, exact framework attribution, native/GPU allocation or latency acceptance. They are excluded from the ordinary4,800-sample population.

Baseline/candidate binaries, recorded build receipts, original/current source manifests, approved three-leaf source and comparison protocol records, completed raw results/logs and final seven report/spec/source leaves are bound. The completed menu/tray and native AX facts remain in the separate service-evidence-review certificate; baseline service execution is not relabeled as a candidate binary execution.

One internal factual precision correction changes only specs/macos-completion.md: repeated100-cycle work is explicitly tray SetTray/ClearTray, with menu activation/replacement checked separately. The preserved original document and original seven-leaf Prism input remain exact. Prism raw0/complete7/onecall/no findings is retained; six leaves, including all runtime/test leaves, are unchanged. Final seven-leaf approval includes this internally checked prose delta without a provider/runtime rerun.

Selected identities are not a complete compiler/module-cache/SDK closure. No consistent universal speedup, native/GPU heap/endurance, physical GPU transfer/completion, input-to-photon, human input/VoiceOver, P6/P11/fullMac or release pass follows. Future archive/checkpoint/index links require packaging and their own final closure audit; this certificate does not assert they already exist.

Verifier:/private/tmp/vellum-service-comparison-review/audit.py.txt. PASS record:/private/tmp/vellum-service-comparison-review/verification.json. Processing used only stdlib read/hash/raw JSON/statistics and gzip checks, without importing/executing the benchmark, validator, producer, tests, native/UI, provider or Git.
