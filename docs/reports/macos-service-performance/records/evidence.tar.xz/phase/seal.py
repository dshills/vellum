"""Seal immutable terminal evidence and the exact reviewed source checkpoint."""
import hashlib
import io
import json
import tarfile
from pathlib import Path
from candidate_run import ROOT, PHASE, sha, identity

records = ROOT / 'docs/reports/macos-service-performance/records'
records.mkdir(exist_ok=False)
base = json.loads((PHASE / 'baseline.json').read_text())
candidate = json.loads((PHASE / 'candidate-baseline-v1.json').read_text())
actual = identity()
assert actual['commit'] == base['commit'] == candidate['commit']
assert actual['selected_source'] == candidate['selected_source']
assert actual['prepared'] == base['prepared'] == candidate['prepared']
provider_sources = json.loads((PHASE / 'checkpoint-source.json').read_text())['sources']
sources = json.loads((PHASE / 'final-source.json').read_text())['sources']
disposition = json.loads((PHASE / 'provider-dispositions.json').read_text())
assert disposition['changed_files'] == ['specs/macos-completion.md']
assert {n for n in provider_sources if provider_sources[n] != sources[n]} == set(disposition['changed_files'])
assert disposition['before_sha256'] == provider_sources['specs/macos-completion.md']
assert disposition['after_sha256'] == sources['specs/macos-completion.md']
assert disposition['provider_source_sha256'] == sha(PHASE/'checkpoint-source.json')
assert disposition['final_source_sha256'] == sha(PHASE/'final-source.json')
assert all(sha(ROOT/n) == h for n, h in sources.items())
required = ['build-services-v1', 'build-grid-v1', 'services-live-v1', 'allocation-live-v1',
            'allocation-top-v1', 'allocation-cumulative-v1', 'ax-race-v1',
            'build-grid-candidate-v1', 'ax-native-v1', 'adapter-race-v1', 'adapter-vet-v1',
            'compare-native-v1', 'candidate-allocation-live-v1',
            'candidate-allocation-top-v1', 'candidate-allocation-cumulative-v1']
receipts = {}
for name in required:
    receipt = json.loads((PHASE / (name+'.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['error'] is None
    if 'source_prepared_stable' in receipt:
        assert receipt['source_prepared_stable']
    else:
        assert receipt['source_delta_stable'] and receipt['prepared_before'] == receipt['prepared_after'] == base['prepared']
    for channel in ['stdout', 'stderr']:
        assert sha(PHASE/(name+'.'+channel)) == receipt[channel+'_sha256']
    receipts[name] = sha(PHASE/(name+'.json'))
reviews = {}
for name in ['source-review', 'compare-protocol-review', 'service-evidence-review', 'performance-evidence-review']:
    review = json.loads((PHASE/(name+'.json')).read_text())
    assert review.get('result', review.get('status')).startswith('APPROVED') and not review['findings']
    for key in ['reviewed_artifact_sha256', 'reviewed_file_sha256']:
        for filename, digest in review.get(key, {}).items():
            assert sha(filename) == digest, filename
    reviews[name] = sha(PHASE/(name+'.json'))
    (records/(name+'.json')).write_bytes((PHASE/(name+'.json')).read_bytes())
prism = json.loads((PHASE/'prism-v1/prism.json').read_text())
process = json.loads((PHASE/'prism-v1/process.json').read_text())
assert process['exit_code'] == 0 and process['error'] is None and process['source_index_stable']
assert process['before'] == process['after'] == provider_sources
assert prism['coverage']['complete'] and prism['coverage']['files'] == len(sources)
assert not prism['findings']
comparison = json.loads((PHASE/'comparison/qualification.json').read_text())
assert comparison['result'] == 'PASS_MATCHED_COMPARISON'
assert comparison['processes'] == 40 and comparison['ordinary_samples'] == 4800
assert not any(comparison['warm_target_met'].values())
qualification = {'result': 'REVIEWED_ALLOCATION_REDUCTION_WITH_FAILED_LATENCY_TARGETS',
    'base_commit': base['commit'], 'source': sources, 'prepared_files': len(base['prepared']),
    'selected_source_files': len(base['selected_source']), 'required_receipts': receipts,
    'reviews': reviews, 'comparison_sha256': sha(PHASE/'comparison/qualification.json'),
    'comparison_summary_sha256': sha(PHASE/'comparison/summary.json'),
    'allocation_diagnostics': {n: sha(PHASE/n) for n in ['allocation-qualification.json', 'candidate-allocation-qualification.json']},
    'prism_provider': 'anthropic', 'prism_model': 'claude-sonnet-5-5', 'prism_findings': 0,
    'prism_sha256': sha(PHASE/'prism-v1/prism.json'),
    'provider_reviewed_source': provider_sources,
    'post_provider_internal_correction_sha256': sha(PHASE/'provider-dispositions.json'),
    'limits': ['Process-wide sampled Go allocation includes observers/runtime and is not retained/native/GPU attribution.',
               'Ordinary frame timing is mixed; unchanged 4/6 ms targets remain failed.',
               'Native selector and lifecycle fixtures do not establish physical interaction, human VoiceOver or notification delivery.',
               'Selected source/prepared/binary identities do not establish complete compiler/SDK/cache closure or full P6/P11/Mac/release qualification.']}
(PHASE/'qualification.json').write_text(json.dumps(qualification, indent=2)+'\n')
suffixes = {'.go', '.py', '.json', '.md', '.txt', '.stdout', '.stderr', '.log', '.pprof'}
excluded = {'endpoints.json', 'final-evidence-review.json', 'final-evidence-review.md'}
members = {'phase/'+p.relative_to(PHASE).as_posix(): p.read_bytes()
           for p in sorted(PHASE.rglob('*')) if p.is_file() and p.suffix in suffixes and p.name not in excluded}
members.update({'root/'+n: (ROOT/n).read_bytes() for n in sources})
index = {n: {'sha256': hashlib.sha256(blob).hexdigest(), 'bytes': len(blob)} for n, blob in members.items()}
with tarfile.open(records/'evidence.tar.xz', 'x:xz') as archive:
    for n, blob in members.items():
        info = tarfile.TarInfo(n)
        info.size = len(blob)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(blob))
(records/'evidence-index.json').write_text(json.dumps(index, indent=2)+'\n')
endpoints = {'qualification_sha256': sha(PHASE/'qualification.json'),
             'source_manifest_sha256': sha(PHASE/'final-source.json'),
             'archive_sha256': sha(records/'evidence.tar.xz'),
             'index_sha256': sha(records/'evidence-index.json'),
             'archive_members': len(members), 'source': sources, 'reviews': reviews,
             'prism_sha256': qualification['prism_sha256'],
             'provider_reviewed_source': provider_sources,
             'post_provider_internal_correction_sha256': sha(PHASE/'provider-dispositions.json')}
(PHASE/'endpoints.json').write_text(json.dumps(endpoints, indent=2)+'\n')
print(json.dumps(endpoints, indent=2))
