# Service allocation/frame comparison protocol

APPROVED_SOURCE for the exact producers and common helper bytes bound in the JSON certificate. The nested native group hole is fixed using a scoped subprocess facade; no global module patch is used. Launch through candidate_run.py so outer watchdog cleanup covers the comparison, native children and observers.

The protocol now binds exactly the three approved source deltas, unchanged prepared inputs and128 closed guard1 warmups. It plans40 interleaved fresh processes and4800 ordinary measurements, retaining raw records and requiring full paired geometry equality. Incomplete/guard-failed runs cannot qualify the campaign.

This is source/protocol approval only. No workload/test/build/provider process was run by the reviewer; source/linkage and actual statistical outcomes need separate receipt audit. Physical GPU/presentation, native-memory attribution and full P6/Mac acceptance are excluded.
