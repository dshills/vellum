"""Validate a separately launched diagnostic; never launch native processes."""
import importlib.util
import json
from pathlib import Path
from candidate_run import ROOT, PHASE, sha

spec = importlib.util.spec_from_file_location('benchmark', ROOT / 'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)
receipt = json.loads((PHASE / 'candidate-allocation-live-v1.json').read_text())
assert receipt['exit_code'] == 0 and receipt['error'] is None and receipt['source_prepared_stable']
for channel in ['stdout', 'stderr']:
    assert sha(PHASE / ('candidate-allocation-live-v1.' + channel)) == receipt[channel + '_sha256']
records = [json.loads(line) for line in (PHASE / 'candidate-allocation-live-v1.stdout').read_text().splitlines()
           if line.startswith('{')]
samples = benchmark.validate_records(records, 10000, False, 120, False, allow_alloc_profile=True)
assert len(samples) == 120 and all(record.get('warmup_guard') == 1 for record in records)
assert records[1]['warmup'] == records[1]['warm_callbacks'] == 128
prefix = PHASE / 'candidate-table-alloc'
assert receipt['argv'] == [str(PHASE / 'loadedgrid-candidate'), '-perf', '-rows=10000',
                           '-perf-samples=120', '-perf-warmup=128', '-perf-alloc-profile=' + str(prefix)]
files = ['candidate-table-alloc.before.pprof', 'candidate-table-alloc.after.pprof']
assert all(0 < (PHASE / name).stat().st_size <= 64 << 20 for name in files)
qualification = {'result': 'PASS_ALLOCATION_DIAGNOSTIC', 'samples': len(samples),
                 'binary_sha256': sha(PHASE / 'loadedgrid-candidate'),
                 'candidate_baseline_sha256': sha(PHASE / 'candidate-baseline-v1.json'),
                 'receipt_sha256': sha(PHASE / 'candidate-allocation-live-v1.json'),
                 'profiles': {name: sha(PHASE / name) for name in files},
                 'validator_sha256': sha(__file__),
                 'scope': 'Separate process-wide sampled Go allocation diagnostic. Includes observers/runtime/profile encoding; not ordinary latency, framework-only, native/GPU or retained-memory evidence.'}
(PHASE / 'candidate-allocation-qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
print(json.dumps(qualification))
