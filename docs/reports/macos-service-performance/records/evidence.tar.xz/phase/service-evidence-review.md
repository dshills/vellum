# Completed menu/tray and candidate accessibility evidence

APPROVED_EVIDENCE for these completed receipts only. No evidence mismatch was found.

The menu/tray native selector fixture runs on clean base2338d7f56d6acf7c5213b21f1a78cfc8f471909c and its recorded710-source/6198-prepared baseline. It exits0 in1.659939375seconds. Its215 raw JSON records include100 paired extra tray create/clear observations with monotonically new identities2..101, installed/current/disabled/stale menu and tray action checks, original-menu restoration, first-window closure with a second survivor, and empty tracked terminal inventories. The source's owner Post barrier verifies callback counts; these are real AppKit selector/object observations, not physical clicks or heap/endurance proof. Menu activation/replacement checks are not100 separate menu cycles. Physical clicks, clipboard access and preference changes are explicitlyfalse.

Candidate Cocoa accessibility acceptance uses the candidate binary and exact three-file source delta. It exits0 in1.410488792seconds and records the10,000-row stored grid with a400-cell minimum,2268 accumulated overlapping-object reuses,459 replacement retirements, admitted current native press and refused closed attachment query. These counters describe the fixture's operations, not distinct permanent objects or broader VoiceOver eligibility.

Candidate offscreen focused AX race count3, whole adapter race(90.755946667seconds) and vet all exit0 with unchanged three-file source and prepared maps. The source reviewer approves exactly accessibility.go,grid_accessibility.go andaccessibility_payload_test.go. Every current candidate selected source and prepared leaf matches its recorded endpoint; the baseline and candidate differ only in those three leaves. The earlier menu/tray process is not relabeled as a candidate-binary execution.

The optimization's wire helper writes JSON into a fresh private Builder and retains its successful immutable string; visible completed grid records seed bounded capacity hints. JSON encoding still allocates and performs work. This source/evidence review establishes neither zero-copy output nor a measured allocation reduction/speedup. The matched comparison and profiles require separate numerical audits; they are deliberately excluded here.

Exact original production payloads, source review, build/live/code receipts, binaries, authorization and raw stdout/stderr hashes are bound. Selected endpoint identities are not complete compiler/module-cache/SDK closure. No full Mac, P6/P11, native/GPU heap, human input/VoiceOver or release qualification follows.

Verification recipe/result: /private/tmp/vellum-service-evidence-review/verify.py.txt andverification.json. Reviewer processing was stdlib reads/hashes/parsing only; no tests, builds, live/UI calls, providers, Git or repository edits.
