"""One current native allocation diagnostic, excluded from warm acceptance."""
from pathlib import Path
import importlib.util, json
from run import ROOT, PHASE, baseline, sha

spec = importlib.util.spec_from_file_location('benchmark', ROOT / 'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)
before = baseline()
binary = PHASE / 'loadedgrid'
digest = sha(binary)
out = PHASE / 'allocation'
samples, process = benchmark.run_case(binary, out, 10000, False, 120, 128, False, 180,
                                     alloc_profile=PHASE / 'table-alloc')
assert process['result'] == 'PASS' and process['exit_code'] == 0
assert before == baseline() and sha(binary) == digest
files = ['table-alloc.before.pprof', 'table-alloc.after.pprof']
result = {'result': 'PASS_ALLOCATION_DIAGNOSTIC', 'binary_sha256': digest,
          'samples': len(samples), 'baseline_sha256': sha(PHASE / 'baseline.json'),
          'profiles': {name: sha(PHASE / name) for name in files},
          'scope': 'Process-wide Go allocation between guarded warmup and observations. Includes inspection/output/runtime work; not framework-only attribution or ordinary latency acceptance.'}
(PHASE / 'allocation-qualification.json').write_text(json.dumps(result, indent=2) + '\n')
