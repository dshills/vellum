"""Close the archive audit before committing the local checkpoint."""
import json
from candidate_run import ROOT, PHASE, sha

records = ROOT/'docs/reports/macos-service-performance/records'
endpoints = json.loads((PHASE/'endpoints.json').read_text())
review = json.loads((PHASE/'final-evidence-review.json').read_text())
assert review.get('result', review.get('status')) == 'APPROVED_EVIDENCE' and not review['findings']
assert review['endpoints'] == endpoints
for name, digest in review['reviewed_artifact_sha256'].items():
    assert sha(name) == digest, name
assert all(sha(ROOT/n) == h for n, h in endpoints['source'].items())
assert sha(records/'evidence.tar.xz') == endpoints['archive_sha256']
assert sha(records/'evidence-index.json') == endpoints['index_sha256']
(records/'evidence-review.json').write_bytes((PHASE/'final-evidence-review.json').read_bytes())
checkpoint = {'result': 'REVIEWED_ALLOCATION_REDUCTION_WITH_FAILED_LATENCY_TARGETS',
    'base_commit': json.loads((PHASE/'baseline.json').read_text())['commit'],
    **endpoints, 'evidence_review_sha256': sha(PHASE/'final-evidence-review.json'),
    'prism_provider': 'anthropic', 'prism_model': 'claude-sonnet-5-5',
    'prism_coverage_complete': True, 'prism_findings': 0, 'prism_findings_resolved': True,
    'ordinary_processes': 40, 'ordinary_samples': 4800, 'ordinary_latency_targets_met': False,
    'additional_native_tray_cycles': 100,
    'checkpoint_producer_sha256': sha(__file__), 'promotion_producer_sha256': sha(PHASE/'promote.py')}
(records/'checkpoint.json').write_text(json.dumps(checkpoint, indent=2)+'\n')
for name in ['checkpoint.json', 'evidence.tar.xz', 'evidence-index.json']:
    assert (records/name).is_file() and (records/name).stat().st_size > 0
print('Reviewed checkpoint, archive and member index are present.')
