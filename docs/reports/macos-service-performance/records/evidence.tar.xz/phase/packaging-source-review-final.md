# Bounded post-provider packaging correction

APPROVED_SOURCE for the current three producers and correction inputs. Only seal.py changed; checkpoint.py/promote.py are byte-identical to the earlier approval. The sealer explicitly retains original provider sources and publishes the final7-source manifest plus correction digest.

The sole spec change accurately restricts100 repeated create/clear cycles to the tray, while retaining separate menu fixture acceptance. Its single inverse phrase replacement reproduces the original provider digest exactly. Original packaging review remains unchanged; exact old sealer/spec snapshots are preserved as inert history for archive verification.

No runtime/source3/provider rerun or producer execution occurred. The actual sealed archive/source-link audit remains a separate mandatory step before commit/promotion.
