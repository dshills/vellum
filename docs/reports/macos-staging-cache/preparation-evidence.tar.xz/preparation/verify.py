from pathlib import Path
import json,hashlib,importlib.util,sys,os
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());d=load(q/'build-identity.json');assert sha(q/'bytecheck')==d['binary_sha256'] and os.access(q/'bytecheck',os.X_OK);assert sha(Path(d['native_root'])/'libs-darwin/arm64/libwgpu_native.a')==d['archive_sha256']
for group in ['private_source_pins','overlay_pins','probe_pin']:assert all(sha(Path(p))==h for p,h in d[group].items())
assert sha(Path('/private/tmp/vellum-staging-reuse/libs-darwin/arm64/libwgpu_native.a'))==d['original_library_untouched_sha256']
for name,folder in [('build','build'),('go-build-v2','go-build-v2')]+[(n,n) for n in ['python-tests','cache-compile','writecombined','default_mode','refuse_late_configuration']]:
 receipt=load(q/(name+'-receipt.json'));r=receipt['run'];assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent'] and r['pins_stable'] and r['logs_complete']
 for stream,e in r['logs'].items():assert sha(q/folder/stream)==e['sha256']
 for p,h in receipt['inputs'].items():
  path=Path(p)
  if name not in ['build','go-build-v2'] and path.name=='run.py':path=q/'pre-overlay-pin-run.py'
  if name not in ['build','go-build-v2'] and path.name=='probe_darwin.go':path=q/'probe-pre-testdata.go'
  if name not in ['build','go-build-v2'] and path.name=='PLAN.md':path=q/'PLAN-pre-testdata.md'
  assert sha(path)==h,(name,p)
s=importlib.util.spec_from_file_location('texture_cache_SDK',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS private native/Go builds,2wrapper/3isolatedRustmethods;exactsource/native/binary/overlay/test/log/SDK8321pins;pool/completionunchanged;noGPUattemptorqualification yet')
