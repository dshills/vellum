from pathlib import Path
import json,sys,hashlib,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');c=t/'tools/macos-calibration/stagingcache';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in c.iterdir() if p.is_file()}
sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('cached_focused_owned',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
commands=[('python-tests',['/usr/bin/python3','-B','-m','unittest','discover','-s',str(c),'-p','*_test.py']),('cache-compile',['/Users/dshills/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustc','--edition=2021','--deny','warnings','--test',str(c/'control.rs'),'-o',str(q/'cache-tests')])]+[(name,[str(q/'cache-tests'),'--exact','tests::'+name]) for name in ['writecombined','default_mode','refuse_late_configuration']]
for name,argv in commands:
 r=g.execute(argv,t,q/name,lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=60,limit=2<<20)
 (q/(name+'-receipt.json')).write_text(json.dumps({'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({name:{k:r[k] for k in ['exit_code','error','seconds']}}),flush=True);assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent']
