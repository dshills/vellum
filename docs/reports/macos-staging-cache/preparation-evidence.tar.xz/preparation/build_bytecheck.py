from pathlib import Path
import importlib.util,sys,hashlib,json
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;code=Path('/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/stagingreuse/bytecheck');lib=Path('/private/tmp/vellum-staging-cache/libs-darwin/arm64/libwgpu_native.a');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in code.iterdir() if p.is_file()};pins[str(lib)]=sha(lib)
pins.update({str(p):sha(p) for p in [q/'bytecheck.mod',q/'bytecheck.sum',q/'overlay.json',Path('/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/stagingcache/probe_darwin.go')]})
sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('bytecheck_build_owned',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
argv=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/bin/sh',str(q.parent/'macos-app-examples/go-check'),'build','-modfile='+str(q/'bytecheck.mod'),'-overlay='+str(q/'overlay.json'),'-ldflags=-buildid='+sha(lib),'-o',str(q/'bytecheck'),'.']
r=g.execute(argv,code,q/'go-build',lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=180,limit=2<<20)
(q/'go-build-receipt.json').write_text(json.dumps({'argv':argv,'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','error','seconds']}));assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent']
