from pathlib import Path
import json,importlib.util,sys,hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'macos-grid-capture-repair/preflight-v2'))
w=Path(__file__).resolve().parent;p=Path('/private/tmp/vellum-staging-cache');old='/private/tmp/vellum-source-built-gpu-276a654'
s=importlib.util.spec_from_file_location('owned_build',w.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
plan=json.loads((w.parent/'macos-source-built-gpu-276a654/build-plan.json').read_text());argv=plan['build_argv'];argv=[v.replace(old+'/build-target-v1',str(p/'target')).replace(old,str(p)) for v in argv if v!='--locked']
profile='(version 1)(allow default)(deny network*)'+''.join('(deny file-write* (subpath '+json.dumps(x)+'))' for x in [old,'/private/tmp/vellum-staging-reuse','/private/tmp/vellum-upload-probe','/private/tmp/vellum-cache-control','/Users/dshills/Development/projects/Vellum','/private/tmp/vellum-doclinks-sdk-bd3cbc9'])
argv[argv.index('-p')+1]=profile
pins={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for root in [p/'source',p/'core',p/'hal'] for f in root.rglob('*') if f.is_file() and f.name!='Cargo.lock'}
r=g.execute(argv,p/'source',w/'build',lambda:(w/'stop-build').exists(),lambda:all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in pins.items()),timeout=600,limit=16<<20)
(w/'build-receipt.json').write_text(json.dumps({'argv':argv,'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','error','seconds']}));assert r['exit_code']==0 and r['error'] is None and r['owned']['group_absent']

import shutil
archive=p/'target/aarch64-apple-darwin/release/libwgpu_native.a';assert archive.is_file()
shutil.copy2(archive,p/'libs-darwin/arm64/libwgpu_native.a')
print('Private staging prototype library built; no GPU correctness or app execution yet.')
