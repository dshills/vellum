from pathlib import Path
import subprocess,json,hashlib,re
q=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');core=Path('/private/tmp/vellum-raster-cost-repro-core');sdk='/private/tmp/vellum-doclinks-sdk-bd3cbc9/retained SDK/vellum-v0.1.0-alpha.2'
s=subprocess.run(['python3','-B',str(r/'tools/macos-calibration/rastercost/prepare.py'),'--sdk',sdk,'--core',str(core),'--artifacts',str(q/'repro')],capture_output=True,text=True,timeout=30);assert s.returncode==0,s.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ref=Path('/private/tmp/vellum-raster-cost-core');assert {str(p.relative_to(ref)):sha(p) for p in ref.rglob('*') if p.is_file()}=={str(p.relative_to(core)):sha(p) for p in core.rglob('*') if p.is_file()}
assert (q/'framework.mod').read_text()==(q/'repro/framework.mod').read_text().replace(str(core),str(ref));assert (q/'framework.sum').read_bytes()==(q/'repro/framework.sum').read_bytes()
for n in ['fixture.go','replay_test.go']:assert (q/n).read_bytes()==(q/'repro'/n).read_bytes()
print('PASS preparation reproduces exact fixture/test/module/sum and unchanged full Core vector; regenerated overlay omits ignored native-only probe override under offscreen tag.')
(q/'prepare-verification.json').write_text(json.dumps({'passed':True,'command':s.args,'stdout':s.stdout,'stderr':s.stderr,'scope':'Preparation reproduction only; no second Go or native run.'},indent=2)+'\n')
