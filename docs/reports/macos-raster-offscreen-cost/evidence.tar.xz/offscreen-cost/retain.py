from pathlib import Path
import tarfile,io,json,hashlib
q=Path(__file__).resolve().parent
paths=sorted(p for p in q.rglob('*') if p.is_file() and not any(x in p.relative_to(q).parts for x in ['__pycache__','tmp']) and p.name not in ['evidence.tar.xz','evidence-index.json'])
index={};archive=q/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for p in paths:
  data=p.read_bytes();name='offscreen-cost/'+p.relative_to(q).as_posix();m=tarfile.TarInfo(name);m.mode=0o644;m.uid=m.gid=0;m.mtime=0;m.uname=m.gname='';m.size=len(data);t.addfile(m,io.BytesIO(data));index[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as t:
 assert sorted(t.getnames())==sorted(index)
 for m in t:
  data=t.extractfile(m).read();assert len(data)==index[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==index[m.name]['sha256']
(q/'evidence-index.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':index,'scope':'Offscreen CPU replay investigation. No native app, release gate qualification, production repair or public push. No binaries, credentials or complete SDK included.'},indent=2)+'\n')
print(json.dumps({'bytes':archive.stat().st_size,'members':len(index),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
