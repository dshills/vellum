from pathlib import Path
import hashlib,json,os,signal,subprocess,time
ROOT=Path('/private/tmp/vellum-large-data/drivers/cogent/build/upstream')
OUT=Path('/private/tmp/vellum-local-layout-v2')
OWNED=json.loads((OUT/'final-source.json').read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def current(): return {p:sha(ROOT/p) for p in OWNED}
def run(name,argv):
    log=OUT/(name+'.log')
    started=time.monotonic()
    record={'name':name,'argv':argv,'cwd':'/private/tmp/vellum-large-data/drivers/cogent','timeout_seconds':60}
    proc=None
    try:
        with log.open('xb') as stream:
            proc=subprocess.Popen(argv,cwd=record['cwd'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            try: record['exit_code']=proc.wait(timeout=60)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                record['exit_code']=proc.wait()
                record['timeout']=True
    except OSError as e:
        record['error']=str(e)
    record['elapsed_seconds']=time.monotonic()-started
    record['log']=str(log)
    record['log_sha256']=sha(log) if log.is_file() else None
    return record
before=current()
assert before==OWNED, 'source changed before checks'
checks=[]
for name,argv in [
    ('final-race3',['go','test','-race','-tags','offscreen','-count=3','-run','^TestVellumLocalLayout|^TestVellumManualTimerDeliveryFIFOAndCancellation$|^TestVellumManualCanceledLifetimeRetiresInputAndTimers$','cogentcore.org/core/core']),
    ('final-vet-offscreen',['go','vet','-tags','offscreen','-composites=false','-unreachable=false','cogentcore.org/core/core']),
    ('final-vet-default',['go','vet','-composites=false','-unreachable=false','cogentcore.org/core/core']),
]:
    c=run(name,argv);checks.append(c)
    if c.get('exit_code')!=0 or c.get('timeout'): break
after=current()
record={'status':'PASS' if before==after==OWNED and len(checks)==3 and all(c.get('exit_code')==0 for c in checks) else 'FAIL','owned_source_before':before,'owned_source_after':after,'checks':checks,'producer_sha256':sha(Path(__file__)),'limits':['Prepared Core only; no GUI, GPU, full raster test suite, provider or pin regeneration.','Both vet scopes explicitly exclude existing composites/unreachable diagnostics.','Source maps cover six owned Core inputs, not the full dependency closure.']}
(OUT/'qualification.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record,sort_keys=True))
raise SystemExit(record['status']!='PASS')
