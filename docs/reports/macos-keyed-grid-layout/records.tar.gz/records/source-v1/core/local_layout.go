// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package core

import (
	"reflect"

	"cogentcore.org/core/tree"
)

const localLayoutCapacity = 64
const localLayoutMaxAncestors = 256

// LocalLayoutRoot is an explicitly fixed-allocation widget subtree. LayoutLocal
// updates its descendants within its existing allocated outer rectangle and
// applies their scene positions. It must return false when ordinary scene
// sizing, styling or layout is required. It must not change its own allocation,
// position or outer bounds, run another scene's work, or dispatch events.
//
// LayoutLocal runs under the existing originating render-context ownership.
// Its ordinary Go panic/Goexit behavior is preserved. A successful local pass
// records the complete scene in painter order, without sizing the whole scene.
type LocalLayoutRoot interface {
	Widget
	LayoutLocal() bool
}

type localLayoutRequest struct {
	root   LocalLayoutRoot
	parent *tree.NodeBase
}

// NeedsLocalLayout requests bounded local layout followed by scene repaint.
// Requests coalesce by actual initialized tree identity, not name. Call only
// while owning this scene's originating render context, or during exclusive
// construction before its loop starts; this method does not acquire any lock.
// A callback may request another pass, including one for itself.
//
// It returns false for retired, detached, foreign, or excessively deep roots.
// At capacity it also returns false and promotes work to ordinary scene layout.
// Full scene rebuild/restyle/layout takes precedence over preexisting requests.
func (sc *Scene) NeedsLocalLayout(root LocalLayoutRoot) bool {
	actual, wb := sc.localLayoutIdentity(root)
	if wb == nil || !sc.localLayoutAttached(wb) {
		return false
	}
	parent := wb.Parent.AsTree()
	for i := range sc.localLayouts {
		if sc.localLayouts[i].root.AsWidget() == wb {
			sc.localLayouts[i] = localLayoutRequest{actual, parent}
			sc.requestPaint() // repeat requests must also restore paint admission
			return true
		}
	}
	if len(sc.localLayouts) == localLayoutCapacity {
		sc.clearLocalLayouts()
		sc.setFlag(true, sceneNeedsLayout)
		return false
	}
	sc.localLayouts = append(sc.localLayouts, localLayoutRequest{actual, parent})
	sc.requestPaint()
	return true
}

func (sc *Scene) localLayoutIdentity(root LocalLayoutRoot) (LocalLayoutRoot, *WidgetBase) {
	if sc == nil || sc.This == nil || sc.localLayoutClosed || root == nil {
		return nil, nil
	}
	value := reflect.ValueOf(root)
	if value.Kind() != reflect.Pointer || value.IsNil() {
		return nil, nil
	}
	wb := root.AsWidget()
	if wb == nil || wb.This == nil || wb.Scene != sc {
		return nil, nil
	}
	actual, ok := wb.This.(LocalLayoutRoot)
	if !ok || actual.AsWidget() != wb {
		return nil, nil
	}
	return actual, wb
}

// Parent pointers may survive detachment. Require live membership on every
// bounded ancestor edge, including the Core parts/scrollbar ownership edges.
func (sc *Scene) localLayoutAttached(wb *WidgetBase) bool {
	for depth := 0; depth < localLayoutMaxAncestors; depth++ {
		if wb == nil || wb.This == nil || wb.Scene != sc || wb.Parent == nil {
			return false
		}
		parent, ok := wb.Parent.(Widget)
		if !ok || parent.AsTree().This == nil {
			return false
		}
		pw := parent.AsWidget()
		member := wb.IndexInParent() >= 0
		if !member && pw.Parts != nil {
			member = pw.Parts.AsWidget() == wb
		}
		if !member {
			if frame := AsFrame(parent); frame != nil {
				for _, scrollbar := range frame.Scrolls {
					if scrollbar != nil && scrollbar.AsWidget() == wb {
						member = true
					}
				}
			}
		}
		if !member {
			return false
		}
		if pw == sc.AsWidget() {
			return true
		}
		wb = pw
	}
	return false
}

func (sc *Scene) clearLocalLayouts() {
	clear(sc.localLayouts)
	sc.localLayouts = nil
}

func (sc *Scene) drainLocalLayouts() (applied, fallback bool) {
	batch := sc.localLayouts
	sc.localLayouts = nil // detach before callouts; new requests belong to next pass
	defer clear(batch)    // no retired or abnormal-callback root survives the batch
	for _, request := range batch {
		_, wb := sc.localLayoutIdentity(request.root)
		if wb == nil || !sc.localLayoutAttached(wb) || wb.Parent.AsTree() != request.parent {
			continue
		}
		allocation, actual, position, bounds := wb.Geom.Size.Alloc.Total, wb.Geom.Size.Actual.Total, wb.Geom.RelPos, wb.Geom.TotalBBox
		if !request.root.LayoutLocal() {
			return applied, true
		}
		if sc.localLayoutClosed || sc.This == nil {
			return applied, false
		}
		if !sc.localLayoutAttached(wb) || wb.Parent.AsTree() != request.parent {
			continue
		}
		if wb.Geom.Size.Alloc.Total != allocation || wb.Geom.Size.Actual.Total != actual || wb.Geom.RelPos != position || wb.Geom.TotalBBox != bounds {
			return applied, true
		}
		applied = true
		if sc.hasFlag(sceneNeedsLayout) {
			return applied, true
		}
	}
	return applied, false
}

// GlobalLayoutPending reports the ordinary requested full-scene layout fence.
// Unlike native geometry or scene flags, this query is safe without owning the
// scene's render context, including from another application owner/window. It
// does not make arbitrary foreign geometry/style mutation safe or observable.
// Inspectors must still verify their own lifetime and publication identity.
// Full layout/rebuild/restyle clears the fence only after normal full paint
// when no newer layout request arose during callback work;
// panic/Goexit leaves it set rather than admitting an incomplete publication.
func (sc *Scene) GlobalLayoutPending() bool {
	return sc != nil && sc.globalLayoutPending.Load()
}
