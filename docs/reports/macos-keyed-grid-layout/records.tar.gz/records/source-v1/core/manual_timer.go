package core

import (
	"cogentcore.org/core/events"
	"context"
	"time"
)

// ManualTimer is the checked timer seam's cancellation handle. Native defaults
// still use time.AfterFunc. A replay adapter wraps its bounded Clock.AfterFunc.
type ManualTimer interface{ Stop() bool }

type manualTimer struct {
	owner      *ManualWindow
	scene      *Scene
	callback   func()
	underlying ManualTimer
	state      uint8 // 0 armed; 1 queued; 2 running; 3 retired; 4 canceled queued
}
type manualTimerEvent struct {
	events.CustomEvent
	timer *manualTimer
}

func (e *manualTimerEvent) Ready() bool                     { return true }
func (e *manualTimerEvent) Merge(events.DeferredEvent) bool { return false }
func (e *manualTimerEvent) runOwned() {
	t := e.timer
	m := t.owner
	m.mu.Lock()
	if t.state == 4 {
		t.state = 3
		delete(m.timers, t)
		m.mu.Unlock()
		return
	}
	if t.state != 1 {
		m.mu.Unlock()
		return
	}
	t.state = 2
	m.mu.Unlock()
	defer func() { m.mu.Lock(); t.state = 3; delete(m.timers, t); m.mu.Unlock() }()
	if m.lifetime.Err() != nil || t.scene == nil || t.scene.This == nil {
		return
	}
	t.callback()
	e.SetHandled()
}
func (t *manualTimer) Stop() bool {
	m := t.owner
	m.mu.Lock()
	if t.state >= 2 {
		m.mu.Unlock()
		return false
	}
	if t.state == 1 {
		// Its origin node still exists. Retain credit until dispatch/unlink so
		// repeated fire/cancel cannot create unbounded tombstones.
		t.state = 4
	} else {
		t.state = 3
		delete(m.timers, t)
	}
	underlying := t.underlying
	m.mu.Unlock()
	if underlying != nil {
		underlying.Stop()
	}
	return true
}
func (m *ManualWindow) stopTimers() {
	m.mu.Lock()
	timers := make([]*manualTimer, 0, len(m.timers))
	for t := range m.timers {
		timers = append(timers, t)
	}
	m.mu.Unlock()
	for _, t := range timers {
		t.Stop()
	}
}
func (sc *Scene) afterEvent(delay time.Duration, callback func()) ManualTimer {
	rc := sc.renderContext()
	if rc == nil || rc.manual == nil {
		return time.AfterFunc(delay, callback)
	}
	m := rc.manual
	if m.lifetime.Err() != nil {
		return nil
	}
	if m.window == nil {
		m.fail(ErrManualStartupTimer)
		return nil
	}
	t := &manualTimer{owner: m, scene: sc, callback: callback}
	m.mu.Lock()
	if len(m.timers) >= m.config.EventCapacity {
		m.mu.Unlock()
		m.fail(ErrManualCapacity)
		return nil
	}
	m.timers[t] = struct{}{}
	m.mu.Unlock()
	source := m.window.SystemWindow.Events()
	underlying, err := m.config.AfterFunc(m.lifetime, delay, func() {
		// No widget/owner callout. Admission consumes this timer's already-owned
		// credit and places work behind previously admitted ordinary native input.
		q := &source.Deque
		_ = q.SendDeferred(func() (events.DeferredEvent, error) {
			m.mu.Lock()
			defer m.mu.Unlock()
			if t.state != 0 || m.lifetime.Err() != nil {
				return nil, nil
			}
			t.state = 1
			event := &manualTimerEvent{timer: t}
			event.Typ = events.Custom
			event.SetUnique()
			event.GenTime.SetTime(m.config.Now())
			return event, nil
		})
	})
	if err != nil || manualNil(underlying) {
		t.Stop()
		if err == nil {
			err = ErrManualConfig
		}
		m.fail(err)
		return nil
	}
	m.mu.Lock()
	t.underlying = underlying
	retired := t.state == 3
	m.mu.Unlock()
	if retired {
		underlying.Stop()
	}
	return t
}

// Compile-time signature documentation for adapter authors. Conversion is
// explicit because Go method return types are invariant across timer interfaces.
var _ func(context.Context, time.Duration, func()) (ManualTimer, error)

// Scene retirement cancels that scene's pending manual deadlines even when its
// originating native window and another dialog remain alive.
func (sc *Scene) stopManualTimers() {
	if rc := sc.renderContext(); rc != nil && rc.manual != nil {
		m := rc.manual
		m.mu.Lock()
		var timers []*manualTimer
		for timer := range m.timers {
			if timer.scene == sc {
				timers = append(timers, timer)
			}
		}
		m.mu.Unlock()
		for _, timer := range timers {
			timer.Stop()
		}
	}
}
func (sc *Scene) Destroy() {
	// Retire local roots before any timer/child cleanup can call back.
	sc.localLayoutClosed = true
	sc.clearLocalLayouts()
	defer sc.clearLocalLayouts()
	sc.stopManualTimers()
	sc.Frame.Destroy()
}

// ManualExecution reports whether this scene has the explicit manual owner.
// It does not switch driver mode or create a timer.
func (sc *Scene) ManualExecution() bool {
	if sc == nil {
		return false
	}
	rc := sc.renderContext()
	return rc != nil && rc.manual != nil
}

// ManualAfterFunc admits a bounded callback to this scene's originating FIFO.
// Clock callbacks only enqueue; the callback itself runs during ManualWindow.Step.
// This API refuses normal mode rather than silently creating a wall timer.
func (sc *Scene) ManualAfterFunc(delay time.Duration, callback func()) (ManualTimer, error) {
	if !sc.ManualExecution() {
		return nil, ErrManualUnsupported
	}
	m := sc.renderContext().manual
	if callback == nil || delay < 0 {
		return nil, ErrManualConfig
	}
	if err := m.lifetime.Err(); err != nil {
		return nil, err
	}
	timer := sc.afterEvent(delay, callback)
	if timer != nil {
		return timer, nil
	}
	m.mu.Lock()
	err := m.failure
	m.mu.Unlock()
	if err == nil {
		err = m.lifetime.Err()
	}
	if err == nil {
		err = ErrManualConfig
	}
	return nil, err
}

// ManualFailure records a checked scheduling refusal in the manual controller.
func (sc *Scene) ManualFailure(err error) {
	if err != nil && sc.ManualExecution() {
		sc.renderContext().manual.fail(err)
	}
}
