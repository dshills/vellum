# Keyed Grid and local layout: independent design review

The proposed checkpoint is feasible if keyed identity, shaping invalidation, and geometric publication are kept separate. Accept the direction with the conditions below; this is a read-only design review, not implementation or timing qualification. I read `/private/tmp/vellum-next-render-plan.md` and the current sources in `/private/tmp/vellum-large-data`; no tests, builds, native processes, providers, or Git operations were run.

## Required reconciliation rules

1. Use a comparable `{RowKey, ColumnID}` key, and a separate header key `{ColumnID}`. Do not concatenate strings. The lookup belongs only to the current binding/accepted source incarnation; never reuse an old opaque Ref or event identity merely because a Text survives. Revalidate the full new bounded snapshot, reject duplicate key assignments defensively, build the new ordered slices, then commit them. A source-incarnation change should conservatively take the full path. Same-incarnation revision/reorder may retain a widget when its text and presentation remain equal, but must still replace its accepted Ref/epoch/metadata.
2. Match all retained keys before assigning donors. Each retiring widget is used at most once; new allocation is needed only after donors are exhausted. Clear surplus slice backing/map entries, delete unused widgets, and drop old keys/projections so the retention bound covers current slots plus bounded staging, not an accumulating cache. A donor must replace text, rectangle, cursor, selected/invisible state, and any private cache metadata together before exposure. Avoid capturing its old semantic key in a persistent Styler/event closure.
3. Preserve `g.cells`/`g.headers` in accepted snapshot order: `capture()` and `refAt()` correlate by ordinal. Rebuild each pane's child slice once in its projected painter order, without repeated `MoveToParent` for same-parent reorder. A pane also owns the private inline TextField; preserve that child and place it after cell Texts, so it remains an overlay. Headers/cells moving between frozen/scrolling panes need proper parent/Scene assignment and inherited-style refresh; use the full fallback initially for pane changes. Never reorder the host's panes/scrollbars accidentally.

Evidence: `grid.go:644` currently materializes/places ordinal slots; `grid_geometry.go:127` reads geometry by that same ordinal. `tree/admin.go:77` removes and appends on MoveToParent, while `Frame.RenderChildren` paints in child order. `grid_editing.go:160` creates the private field in a cell pane and later moves it between panes.

## Required dirty classification and fallback

Use distinct content/style and geometry dirtiness. A pure position/clip change at unchanged content allocation can reuse `Text.PaintText()`; it still needs new `RelPos`, absolute positions, clipped TotalBBox/ContentBBox and paint. Text/selected/cursor/visible changes need the necessary updater/style work. Selection/cursor can change foreground/state layers and inside-border content size, so they are not automatically paint-only. A newly visible widget with nil shaped output must be shaped even if its string is unchanged. Width/height/content-box changes, changed unit context, rich style/font/shaper context, pane inheritance or uncertain allocation must invalidate shaping or use the full path.

Do not call `Text.Update()` on the dirty subset and expect a local pass: `WidgetBase.Update` traverses descendants, runs updater then Style, and calls NeedsLayout. A local path needs an explicit updater/style operation that does not introduce a global request, followed by correct fixed-allocation text layout. `Text.FinalUpdater` parses and shapes; `Text.FinalStyler` reparses with final styles and updates shaped style. Preserve that ordering and actual final content allocation. Compare actual software output against the full path rather than guessing that Pre whitespace makes sizing irrelevant.

Full fallback must remain for initial/show iterations, rebuild/restyle, parent or node style/theme/help/disabled changes, topology/reparent, allocation/resize/DPI/font/context changes, and editor visibility/session/focus transitions. Do not invent a small style fingerprint: Core Style inherits fields, recomputes units from parent and element allocation, and size-final processing can update relative-unit style. Reuse an explicit successful full-layout/style epoch and checked host/parent/Scene/allocation identity, or fail conservatively. An unchanged descriptor does not prove unchanged inherited style.

`syncGridEditing` currently ends with unconditional `field.Update()`. Keep native editing synchronization and global-layout precedence; initially an active editor may therefore force the full path even without a visible transition. Do not suppress its update to meet the local-path counter oracle. Existing private selection/preedit/restore/focus behavior is independently observable at the same portable generation.

## Required Core request contract

`Scene.NeedsLocalLayout(LocalLayoutRoot)` must be bounded, coalesced by stable root identity, and tied to the originating Scene/lifetime. Request admission must not call LayoutLocal or domain/user callbacks. An unsupported/full queue must request ordinary global layout instead of silently dropping geometry work. Deleted/reparented/closed roots cannot be executed against a replacement scene. Do not let queue entries keep retired widgets/windows alive indefinitely.

Drain under the originating RC before paint. Rebuild/restyle/global layout takes precedence. A global layout that incorporates current state may retire the detached initial local batch, but cannot clear requests or global flags raised during that pass. Likewise a root that requeues itself during LayoutLocal must remain pending for the next bounded pass. Two roots must both be handled deterministically; define ancestor/descendant coalescing, or permit only disjoint fixed roots in this checkpoint. LayoutLocal returning false must mean safe ordinary-layout fallback, not successful completion. If it raises global NeedsLayout midway, run the full path before publishing a completed image. Panic/Goexit must leave the scene non-current and terminal cleanup available.

Grid LayoutLocal consumes only already admitted projection/widget state; it performs no source Cell/RowKey/State reads, no owner acquisition/user callbacks, and no cross-window geometry reads. Its fixed allocation must be checked again at execution, not solely when queued. Set global-natural rounded edges once, preserve the existing inside-border exterior contract, perform complete position/BBox propagation, and leave unaffected ancestor/sibling allocations unchanged.

After local positioning, retain whole-scene paint ordering. Painting only changed cells or the grid host is not established equivalent for deleted/moved/translucent cells, scrims, later overlapping siblings, or changed order. Clear/reconstruct the ordinary scene command stream exactly as the existing full paint path does; this checkpoint changes layout/updating, not compositing.

## Measurement, actions and lifetime

Withdraw the completed measurement immediately for any newly pending geometric transition, including same-generation native geometry changes. The old readonly AX cache may still represent the last drawn frame under the existing publication contract, but current hit/AX actions and InspectGrid must refuse until a successful new capture. Retained Text identity must never retain old current-generation action eligibility. Increment/ref-bind the normal accepted epoch even when the same widget survives.

A failed snapshot, styling, reparent, local admission or local execution cannot leave `projectionReady` or measurement indicating a mixed old/new frame. Removal/close must clear queued roots and measurement; queued old press, captured AX action, editor settlement and cross-window owner messages continue through their existing incarnation/lifetime gates. Keep normalized scrollbar restoration independent of whether cell content changed.

## Minimum meaningful regression matrix

- Actual Manual scroll one row/column: overlapping keys retain exact Text and shaped output identity; entering keys reuse only retiring donors; pane child order, accepted slices, refs, geometry, software RGBA and AX/current IDs agree with full baseline. Repeat reverse-direction scroll, no overlap, empty/repopulation and surplus shrink; retained counts never accumulate.
- Text/selection/cursor and visibility transitions: only affected widgets run necessary updater/style passes; recycled selected/cursor styling resets; same-string source revision still updates refs/metadata. Include escaped text, multibyte/bidi, initially invisible-to-visible and same-key changed value.
- Fixed and variable row heights, odd widths, both axes and frozen headers/columns at DPI 96/120/144/192. Assert exact shared rounded exterior edges and inside cursor border, not relaxed tolerances. Include changed allocations and clips that expose old pixels.
- Local-only path: toolbar/ancestor layout counters remain zero while all moved cell BBoxes/pixels update. Full path: typography/theme/help/disabled/parent move/resize/DPI force correct synchronization. An unrelated global request wins; request during local/full execution survives; two grids do not starve each other.
- Private editor: visible field remains last in pane, typed/marked text and native selection/restore/focus settle correctly across scroll/hide/conflict/Cancel/rebegin. No local-layout claim where its ordinary update raises global NeedsLayout.
- Pending/removal: queue layout then remove/reparent/close before frame; no stale callbacks/source reads/retained queue roots. Press before scroll/reorder and AX action before pending refuse; current action after capture works. Modal/tab/disabled/lifetime gates remain intact.
- Actual batches 1/7/64 produce equal semantic/layout/pixel checkpoints without implicit clocks or workers. Use overlay original implementation for differential evidence; retain negative tests that omit BBox propagation, donor state reset, editor-last ordering and global-layout precedence.

Reuse `grid_update_offscreen_test.go` for baseline style/pixel fixtures; `grid_projection_refresh_offscreen_test.go` for no-op/inherited-style/private-edit/slider coverage; grid selection/edit/publication tests for actual router and pending action guards. Counter expectations must distinguish unchanged overlapping cells from dirty donors; do not simply carry the old every-slot-once assertion into the keyed workload.

## Inspected source identities

These hashes identify the code read, not a complete frozen build graph:

```
drivers/cogent/grid.go 6e5601f16448d1313de9def6b1c957eb59d763084b6d45539b94aabdecea5b0c
drivers/cogent/grid_geometry.go 80cec072a8b9ddd01af3b87f7b5a198f244a9d3b5b68bb3b0e16320fa0914e54
drivers/cogent/grid_editing.go c70a39637c02e2e9576a1ae3d0b2d4a043af9fc92d1ea493847d3c42abf403d3
drivers/cogent/reconcile.go fe7f5ebf38cdb4168e9a9f6edcf20ae54658346604d9175775093cd4950161ef
core/update.go 16e4f84616d958d1fce8b80eaea0906a5e00c14cbec2099fda74aa87626991ca
core/text.go 247b126f88c56893329541726c37e4452a9482e16e49cde9622bdfe19ab0d02d
core/layout.go 79b61d34aea411361af7b8109317d685d0c5042d680342b4f3f15640a309e873
core/render.go a3c63a4eedf85cb5a2dc519a0e56fd4a967e1e3b5e02dfecc7dde6fffabceba9
core/frame.go 6d1c45af703c25946f2b4740e2854a90d901672c83e24c6968b6169a9578beab
core/style.go 50ca543d3755ec22621bb1409ff68668e45dfc82efa4f0c222f5840845a7bbeb
tree/admin.go 512b4c3a8b8241e1a064298a8189b55e403372e6af03ffabd71025053e5d4142
```

Core/tree paths above are relative to `drivers/cogent/build/upstream/`. The measured stage costs motivate investigation; they neither prove attribution to these operations nor promise a latency improvement. Software differential results alone cannot qualify GPU/display work or complete P6.
