# Conditional private Grid field Update: scoped review

The proposed dirty gate is sound for the observed capture → owner refresh → field.Update → global layout loop. Keep all `syncGridEditing` synchronization in its current order and gate only the final `field.Update()`. This is a read-only advice record; no source edits or tests were performed.

Dirty should include:

- Newly created field or replacement edit session.
- Deep theme inequality, compared before overwriting the private record theme.
- Accepted revision/text replacement or an explicit restore, even if replacement bytes are equal (SetText must retire native composition/shadows).
- A queued `fieldSelection` request consumed, even if the requested selection equals the live selection; the existing setter validation/failure contract stays unchanged.
- Actual field Invisible/Disabled state changed, and any focus transition performed by this function.
- Field parent/Scene or indexed rectangle changed. A visible field whose rectangle property is absent/wrongly typed is dirty. First mount/hidden-to-visible must retain sizing.

Capture actual Invisible/Disabled/Focused flags before mutation and compare at the end. In particular `syncSemantics` writes inherited disabled state before the later explicit conflict/read-only state; comparing only the descriptor's previous Disabled field can miss an actual native state transition. Keep the existing explicit state assignments and host Focusable policy; do not replace them with conditional branches.

The ordinary field APIs already arrange rendering for private native state changes:

- `TextField.SetText` → `revert()` clears composition/render-visible cache and calls NeedsRender.
- `SetEditingSelection` updates directional scalar selection, line position and calls NeedsRender.
- `ApplyNativeEdit` updates preedit/undo/selection, clears visual caches and calls NeedsRender.
- `TextField.Render` → `autoScroll()` shapes the current complete text with current styles before publishing native geometry.

Consequently, a different owner-cached `fieldState`/Caret/VisualLine, native marked range, or native listener notification is not by itself a reason to call full Update again. Making these unconditional dirty triggers recreates the same loop after each rendered geometry publication. Do not call SetText merely to make a no-op field appear synchronized: it would reset preedit/undo. Native text and selection code must continue running exactly as before.

Generated Accessibility.Name changes (header title/row ordinal) are semantic-only and `syncSemantics` must still run on every refresh. They do not currently affect the private field's Tooltip, whose generated Help is empty. If future code changes private Help/Tooltip, include that transition because Core style derives hover/press abilities from it. Theme/node typography, Scene DPI/restyle and changed active projection retain ordinary full host/style passes. Host Update can still update the field recursively; this gate must not suppress that legitimate ancestor update.

Keep focusedOnce semantics unchanged: ordinary Tab/focus-loss must not refocus on every owner refresh. A focus attempt performed by this function can conservatively mark dirty, but a stable already-focused field must not. StartFocus during creation is already covered by the creation gate.

Meaningful regression additions:

1. Begin a real inline edit, finish one frame, then count its Updater/Styler across completed capture invalidation and several unchanged owner invalidations. Require bounded settling and zero redundant field updates on the tail; preserve client/session/text/directional selection/focus/host Tab stop. This is the direct loop regression.
2. Keep the existing actual queued directional selection → restore → Return settlement test unchanged. For queued selection/restore require one necessary update followed by a zero-update tail, with the native editor identity retained.
3. Apply native marked preview at the same Grid generation; refresh while composing and verify text/marked range/undo baseline remains intact, then seal/cancel and check exact draft/history. No extra full Update is needed solely for preview state; the APIs' existing render path must still produce current geometry and publication.
4. Change private theme, conflict/ready Disabled, visible/hidden, indexed rect (including variable height) and pane/parent. Require changed style/geometry/focus admission and then quiescent tail. Preserve editor-last ordering and draft recovery while hidden/conflicted.
5. Cancel/rebegin session and window retirement around a queued field-selection/settlement; no old client/session updates or late callbacks. Existing inline editing route and lifetime tests supply this coverage.

Current inspected public implementations are `drivers/cogent/grid_editing.go`, `controls.go`, and prepared Core `textfield.go`, `textfield_editing.go`, `textfield_native.go`, `widgetevents.go`, `events.go`. The proposed skip does not change their owner/origin read confinement or introduce new native reads at callback delivery. Final source/test certification must bind the actual implemented bytes separately.
