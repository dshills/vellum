from pathlib import Path
import hashlib,json
P=Path('/private/tmp/vellum-macos-breadcrumb-composed')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((P/'build-cycles-v2.json').read_text())
assert r['exit_code']==0 and r['error']is None and r['source_delta_stable'] and r['prepared_before']==r['prepared_after'] and len(r['prepared_after'])==6216
source={'commit':r['source_commit'],'delta':r['source_delta_after'],'prepared':r['prepared_after']}
(P/'native-inputs.json').write_text(json.dumps({'source':source,'code_run_sha256':sha(P/'code_run.py'),'binaries':{'window-cycle-smoke':{'sha256':sha(P/'window-cycle-smoke')}},'build_receipts':{'cycles':{'path':str(P/'build-cycles-v2.json'),'sha256':sha(P/'build-cycles-v2.json')}}},indent=2)+'\n')
print('inputs_bound',len(source['delta']),len(source['prepared']))
