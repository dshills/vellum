APPROVED_SOURCE. No unresolved findings.

Initial false identity-replacement expectation is fixed: ordinary same-ID AX objects may be reused when Models becomes passive static text. Completion still requires the expected role/name, positive identity/geometry and old Current leaf absence. Home rejection and Models truncation are acknowledged through exact owner callback counters, separately from native publication; accepted actions cannot be repeated while waiting for semantics. Fresh per-window models and stale closures are covered.

Breadcrumb now occupies a separate controls-column row after the initial real geometry failure. Current native-command/full-adapter race and tagged build receipts bind the seven-source vector/6216 prepared leaves. These are source/code gates, not native runtime/P11/GPU acceptance.
