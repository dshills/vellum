"""One bounded owned Cocoa fixture, serialized against ordinary benchmarks."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,signal,subprocess,sys,time
R=Path('/private/tmp/vellum-breadcrumb-composed');P=Path('/private/tmp/vellum-macos-breadcrumb-composed');Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
name=sys.argv[1];binary=P/sys.argv[2];argv=[str(binary),*sys.argv[3:]]
assert binary.name=='window-cycle-smoke' and argv[1:]==['-composed','-cycles=5','-sample-every=5','-timeout=180s']
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def source():
 names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'delta':{n:sha(R/n)for n in names if(R/n).is_file()},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
def stop():
 if(Q/'stop-live').exists()or(P/'stop-live').exists():raise InterruptedError('live testing cancelled by shared or phase stop marker')
stop();review=json.loads((P/'harness-review.json').read_text());assert review['result']=='APPROVED_SOURCE_AND_HARNESS' and not review['unresolved_findings'];assert all(sha(P/n)==h for n,h in review['harness_sources'].items());before=source();assert len(before['prepared'])==6216
inputs=json.loads((P/'native-inputs.json').read_text());inputs_digest=sha(P/'native-inputs.json');review_digest=sha(P/'harness-review.json')
reviewed_artifacts={str(P/n):h for n,h in review['harness_sources'].items()}
reviewed_artifacts.update({str(P/'harness-review.json'):review_digest,str(P/'native-inputs.json'):inputs_digest,str(binary):sha(binary)})
reviewed_artifacts.update({v['path']:v['sha256']for v in inputs['build_receipts'].values()})
def reviewed_stable():return all(sha(n)==h for n,h in reviewed_artifacts.items())
assert reviewed_stable()
assert before==inputs['source'] and sha(binary)==inputs['binaries'][binary.name]['sha256']
assert sha(P/'code_run.py')==inputs['code_run_sha256']
for selected in inputs['build_receipts'].values():
 f=Path(selected['path']);assert sha(f)==selected['sha256'];r=json.loads(f.read_text())
 assert r['exit_code']==0 and r['error']is None and r['source_delta_stable']
 assert r['source_commit']==before['commit'] and r['source_delta_before']==r['source_delta_after']==before['delta']
 assert r['prepared_before']==r['prepared_after']==before['prepared']
lock=(Q/'native-live.lock').open('a+');locked=False;child=None;start=time.monotonic()
d={'argv':argv,'inputs_sha256':inputs_digest,'harness_review_sha256':review_digest,'mode':'native_cocoa','source_before':before,'producer_sha256':sha(__file__),'executable_sha256':sha(binary),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':190,'exit_code':None,'error':None,'preferences_changed':False,'clipboard_access':False}
try:
 while not locked:
  stop()
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);locked=True
  except BlockingIOError:
   if time.monotonic()-start>90:raise TimeoutError('live-test lock wait expired')
   time.sleep(.25)
 assert reviewed_stable(), 'reviewed native inputs changed while waiting for lock'
 assert source()==before, 'source changed while waiting for the native lock'
 assert sha(P/'native-inputs.json')==inputs_digest, 'native inputs changed while waiting for lock'
 assert sha(binary)==d['executable_sha256'], 'native executable changed while waiting for lock'
 launch=time.monotonic()
 with(P/(name+'.stdout')).open('xb')as so,(P/(name+'.stderr')).open('xb')as se:
  child=subprocess.Popen(argv,cwd=R/'drivers/cogent',env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
  (P/(name+'.owned-process.json')).write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'owner_pid':os.getpid(),'executable_sha256':d['executable_sha256']}))
  while child.poll()is None:
   stop()
   if time.monotonic()-launch>190:raise TimeoutError('native Cocoa fixture watchdog expired')
   if(P/(name+'.stdout')).stat().st_size+(P/(name+'.stderr')).stat().st_size>1<<20:raise ValueError('native fixture output exceeded1MiB')
   time.sleep(.05)
  d['exit_code']=child.returncode
except BaseException as exc:d['error']={'type':type(exc).__name__,'message':str(exc)}
finally:
 if child is not None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait(timeout=5);d['exit_code']=child.returncode
 d['owned_group_retired']=child is not None
 try:
  d['source_after']=source();d['reviewed_artifacts_stable']=reviewed_stable();d['source_stable']=before==d['source_after'] and d['reviewed_artifacts_stable']
 except BaseException as exc:
  d['source_stable']=False;d['reviewed_artifacts_stable']=False;d['terminal_stability_error']={'type':type(exc).__name__,'message':str(exc)}
 if locked:fcntl.flock(lock,fcntl.LOCK_UN)
 lock.close();d['elapsed_seconds']=time.monotonic()-start
 for channel in ['stdout','stderr']:
  f=P/(name+'.'+channel);d[channel+'_sha256']=sha(f)if f.exists()else None
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['source_before','source_after']}),flush=True)
sys.exit(0 if d['exit_code']==0 and d['error']is None and d['source_stable']else 1)
