from pathlib import Path
import datetime,hashlib,json,subprocess
P=Path('/private/tmp/vellum-macos-breadcrumb-composed');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
t=json.loads((P/'native-composed.json').read_text());o=json.loads((P/'native-composed.owned-process.json').read_text());assert t['exit_code']==0 and t['error']is None and t['owned_group_retired']and t['source_stable']and o['pid']==o['process_group']and o['executable_sha256']==t['executable_sha256']and t['producer_sha256']==sha(P/'live.py')
r=subprocess.run(['ps','-axo','pid=,pgid=,comm='],capture_output=True,text=True,check=True,timeout=5)
members=[]
for line in r.stdout.splitlines():
 fields=line.split(None,2)
 if len(fields)>=2 and int(fields[1])==o['process_group']:members.append(line.strip())
q={'result':'PASS_RECORDED_GROUP_ABSENT'if not members else'FAIL_RECORDED_GROUP_PRESENT','group':o['process_group'],'members':members,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_sha256':sha(P/'native-composed.json'),'owned_sha256':sha(P/'native-composed.owned-process.json'),'producer_sha256':sha(__file__),'scope':'Exact recorded process-group absence at this observation; not native/GPU-resource inventory or broader descendant proof.'};(P/'post-terminal-group.json').write_text(json.dumps(q,indent=2)+'\n');print(q['result']);assert not members
