from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-breadcrumb-composed');P=Path('/private/tmp/vellum-macos-breadcrumb-composed');D=R/'docs/reports/macos-breadcrumb-composed/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((P/'final-summary.json').read_text());sources=s['sources'];assert len(sources)==8 and all(sha(R/n)==h for n,h in sources.items())
i=json.loads((P/'final-review.json').read_text());assert i['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not i['unresolved_findings']and i['sources']==sources
r=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and process['error']is None and process['source_index_stable']and process['before']==process['after']==sources
assert r['coverage']['complete']and r['coverage']['files']==8 and not r['findings']and r['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
allowed={'.json','.stdout','.stderr','.txt','.py','.log','.md'}
inputs={'checkpoint/'+f.relative_to(P).as_posix():f for f in sorted(P.rglob('*')) if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed}
inputs.update({'reviewed_source/'+n:R/n for n in sources})
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in sorted(inputs.items())}
D.mkdir(parents=True,exist_ok=True);a=D/'evidence.tar.xz'
with tarfile.open(a,'x:xz',preset=3)as t:
 for n,f in sorted(inputs.items()):t.add(f,arcname=n,recursive=False)
with tarfile.open(a,'r:xz')as t:
 assert set(t.getnames())==set(index)
 for m in t:assert m.isfile()and hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(a),'files':index,'excluded_executables':{'window-cycle-smoke':sha(P/'window-cycle-smoke')}},indent=2)+'\n')
q={**s,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','internal_review_sha256':sha(P/'final-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':8,'prism_findings':0,'prism_unresolved_findings':0,'prism_raw_exit_code':0,'prism_calls':r['coverage']['llmCalls'],'archive_sha256':sha(a),'archive_members':len(index),'archive_bytes':a.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','prism_files','prism_findings','archive_sha256','archive_members','archive_bytes']}))
