from pathlib import Path
import hashlib,json,math,subprocess
R=Path('/private/tmp/vellum-breadcrumb-composed');P=Path('/private/tmp/vellum-macos-breadcrumb-composed');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
name='native-composed';count,every=5,5
inputs=json.loads((P/'native-inputs.json').read_text());run=json.loads((P/(name+'.json')).read_text());build=json.loads((P/'build-cycles-v2.json').read_text())
review=json.loads((P/'harness-review.json').read_text());assert review['result']=='APPROVED_SOURCE_AND_HARNESS'and not review['unresolved_findings']
assert run['harness_review_sha256']==sha(P/'harness-review.json')and run['reviewed_artifacts_stable']
assert review['sources']==inputs['source']['delta']and all(sha(P/n)==h for n,h in review['harness_sources'].items())
assert run['exit_code']==0 and run['error']is None and run['source_stable']and run['owned_group_retired']
assert run['source_before']==run['source_after']==inputs['source']and run['inputs_sha256']==sha(P/'native-inputs.json')and run['producer_sha256']==sha(P/'live.py')and run['executable_sha256']==sha(P/'window-cycle-smoke')==inputs['binaries']['window-cycle-smoke']['sha256']
assert run['argv']==[str(P/'window-cycle-smoke'),'-composed','-cycles=5','-sample-every=5','-timeout=180s']and run['timeout_seconds']==190 and not run['preferences_changed']and not run['clipboard_access']
assert build['exit_code']==0 and build['error']is None and build['source_delta_stable']and build['source_delta_before']==build['source_delta_after']==inputs['source']['delta']and build['prepared_before']==build['prepared_after']==inputs['source']['prepared']and len(build['prepared_after'])==6216
assert sha(P/'build-cycles-v2.json')==inputs['build_receipts']['cycles']['sha256']and sha(P/'code_run.py')==inputs['code_run_sha256']==build['producer_sha256']
for channel in ['stdout','stderr']:assert run[channel+'_sha256']==sha(P/(name+'.'+channel))and build[channel+'_sha256']==sha(P/('build-cycles-v2.'+channel))
events=[json.loads(line)for line in (P/(name+'.stdout')).read_text().splitlines()if line.startswith('{')]
cycles=[x for x in events if x.get('event')=='vellum.composed-cycle'];partials=[x for x in events if x.get('event')=='vellum.native-action'];results=[x for x in events if x.get('event')=='vellum.window-cycle.result']
assert len(cycles)==count and len(partials)==count*26 and len(results)==1 and [c['cycle']for c in cycles]==list(range(1,count+1))
plan=[('check','set','false'),('switch','press',''),('toggle','press',''),('check','set','true'),('slider','set','37'),('number','increment',''),('radio','set','a'),('segment','set','b'),('selector','set','a'),('button','press',''),('disclosure','collapse',''),('disclosure','expand',''),('tabs','set','about'),('tabs','set','live'),('tabs','set','colors'),('color/color/red','set','12'),('color/color/hex','set','#3567B580'),('tabs','set','live'),('tree:b3V0bGluZQ:row:bjA','press',''),('tree:b3V0bGluZQ:row:bjA','collapse',''),('tree:b3V0bGluZQ:row:bjA','expand',''),('text','set','Cocoa composed edit'),('dialog-open','press',''),('dialog-close','press',''),('workspace-path/breadcrumb/item/aG9tZQ','press',''),('workspace-path/breadcrumb/item/bW9kZWxz','press','')]
for i,c in enumerate(cycles):
 assert all(c[k] for k in ['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])
 assert c['native_breadcrumb_requests']==2 and c['native_breadcrumb_rejected'] and c['native_breadcrumb_truncated']
 assert c['tree_accessibility_rows']>0 and c['native_color_edits']==2 and c['native_tree_disclosures']==2
 assert c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and not c['full_p11_qualified']
 actions=c['native_actions'];assert len(actions)==26 and [(a['Target'],a['Kind'],a['Value'])for a in actions]==plan
 assert [p['action']for p in partials[i*26:(i+1)*26]]==actions
 assert all(p['window']==f'native-cycle-{i:04d}'for p in partials[i*26:(i+1)*26])
 for a in actions:
  assert type(a['Attempts']) is int and type(a['Admissions']) is int and 1<=a['Admissions']<=a['Attempts'] and a['OwnerAndNativeCompleted'] is True and a['NativeRole']
  assert isinstance(a['ElapsedSeconds'],(int,float))and math.isfinite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5
 for index,role in [(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton')]:assert actions[index]['NativeRole']==role
result=results[0]
assert result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['requested_cycles']==result['completed_cycles']==count and result['composed_workspace']and result['dense_labels_per_composed_window']==1000
assert result['cooperative_timeout_seconds']==180 and not result['full_p11_qualified']and not result['gpu_memory_qualified']and not result['native_heap_qualified']and not result['preferences_changed']and not result['clipboard_access']
cleanup=result['native_cleanup'];assert cleanup['MainThread']and cleanup['CleanupObserved']and cleanup['CallbacksStopped']and not cleanup['WindowTitles']and cleanup['NativeOutstanding']==cleanup['AccessibilityWindows']==cleanup['PendingCallbacks']==0
samples=result['samples'];assert [s['Completed']for s in samples]==list(range(0,count+1,every))and [x['sample']for x in events if x.get('event')=='vellum.window-cycle.sample']==samples
assert result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20 and result['samples_after_forced_gc']and result['geometry_persistence_disabled_in_fixture']
assert all(s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 for s in samples)
assert not result['heap_profile_requested']

q={'result':'PASS_FIVE_CURRENT_COMPOSED_NATIVE_CYCLES','base_commit':inputs['source']['commit'],'sources':inputs['source']['delta'],'prepared_count':6216,'cycles':5,'activity_steps':130,'run_receipt_sha256':sha(P/(name+'.json')),'build_receipt_sha256':sha(P/'build-cycles-v2.json'),'binary_sha256':run['executable_sha256'],'inputs_sha256':sha(P/'native-inputs.json'),'producer_sha256':sha(__file__),'native_cleanup':cleanup,'tree_ax_rows_counts':sorted(set(c['tree_accessibility_rows']for c in cycles)),'dense_labels_per_cycle':1000,'total_attempts':sum(a['Attempts']for c in cycles for a in c['native_actions']),'total_admissions':sum(a['Admissions']for c in cycles for a in c['native_actions']),'retry_steps':sum(a['Attempts']!=1 or a['Admissions']!=1 for c in cycles for a in c['native_actions']),'retry_cause_observed':False,'full_p4_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,'scope':'Current Breadcrumb fixture delta onb003 with6216prepared; fivecomposedwindowcycles/130owner-native step completions andtracked mainthread nativecleanup only. Queueadmissions are notacceptedcallbacks. No finalsource1000cycle/overnight,physicalinput/humanaccessibility,nativeGPUmemorybudget or ordinaryframegain qualification.'};(P/'native-summary.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in ['sources','native_cleanup']}))
