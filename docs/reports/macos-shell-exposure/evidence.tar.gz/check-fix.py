from pathlib import Path
import os,json,sys,importlib.util,time,subprocess,tempfile,hashlib,shutil
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;S=Path('/private/tmp/vellum-shell-exposure-20261027/sdk');C=S/'drivers/cogent/build/upstream'
sys.path.insert(0,str(R/'scripts'));from child_process import run_child
from sdk_environment import child_environment
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',GOTOOLCHAIN='local',GOWORK='off',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
checks=[]
def run(name,args,cwd=C,expected=0):
 start=time.monotonic()
 with (X/(name+'.stdout')).open('wb') as out,(X/(name+'.stderr')).open('wb') as err:p=run_child(args,cwd=cwd,env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=4<<20)
 rec={'name':name,'exit_code':p.returncode,'expected_exit_code':expected,'seconds':round(time.monotonic()-start,3)};checks.append(rec);print(json.dumps(rec),flush=True);assert p.returncode==expected,(name,(X/(name+'.stdout')).read_text()[-2000:],(X/(name+'.stderr')).read_text()[-2000:])
fixed=(C/'core/renderwindow.go').read_bytes();(C/'core/renderwindow.go').write_bytes((X/'renderwindow-before.go').read_bytes())
try:run('baseline-final-regressions',['go','test','-mod=readonly','-race','-tags','offscreen','./core','-run','^TestVellumExposure','-count=1'],expected=1)
finally:(C/'core/renderwindow.go').write_bytes(fixed)
run('fixed-exposure-regressions',['go','test','-mod=readonly','-race','-tags','offscreen','./core','-run','^TestVellumExposure','-count=1'])
run('related-composition-lifecycle',['go','test','-mod=readonly','-race','-tags','offscreen','./core','-run','^(TestVellumBusy|TestVellumDisplayAdmission|TestQueuedClose|TestSceneShow|TestNewWindowSizing|TestSameWindowStage)','-count=1'])
run('core-vet',['go','vet','-mod=readonly','-tags','offscreen','./core'])
run('patch-recipe-pins',[sys.executable,'-B','-m','unittest','prepare_test.PreparationChecks.test_manifest_pin_and_patch_order'],R/'drivers/cogent')
spec=importlib.util.spec_from_file_location('prepare',R/'drivers/cogent/prepare.py');prepare=importlib.util.module_from_spec(spec);spec.loader.exec_module(prepare)
stage=json.loads((R/'drivers/cogent/native/dependencies.json').read_text())['dependencies'][0]['stages'][-1]
with tempfile.TemporaryDirectory(prefix='vellum-exposure-recipe-') as tmp:
 root=Path(tmp);(root/'core').mkdir();(root/'core/renderwindow.go').write_bytes((X/'renderwindow-before.go').read_bytes());prepare.apply_stage(stage,root)
 assert (root/'core/renderwindow.go').read_bytes()==fixed
 assert (root/'core/exposure_vellum_test.go').read_bytes()==(C/'core/exposure_vellum_test.go').read_bytes()
with tempfile.TemporaryDirectory(prefix='vellum-exposure-drift-') as tmp:
 root=Path(tmp);(root/'core').mkdir();(root/'core/renderwindow.go').write_bytes((X/'renderwindow-before.go').read_bytes()+b'\n')
 try:prepare.apply_stage(stage,root)
 except RuntimeError as e:assert 'Patch input mismatch' in str(e)
 else:raise AssertionError('drifted preimage accepted')
 assert not (root/'core/exposure_vellum_test.go').exists()
outputs=json.loads((R/'drivers/cogent/native/patches/exposure/output-hashes.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(C/n)==h for n,h in outputs.items())
result={'baseline_failures_expected':True,'fixed_regressions_pass':True,'checks':checks,'recipe_replay_matches_tested_sources':True,'drifted_input_refused_before_new_file':True,'runtime_changed_files':['core/renderwindow.go'],'native_archive_sha256':sha(S/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'),'features_and_api_unchanged':True,'experimental_options_unchanged':True}
(X/'fix-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':True,'focused_checks':len(checks)}))
