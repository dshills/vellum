from pathlib import Path
import sys,os,json,hashlib,subprocess,shutil,time,importlib.util,copy
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;W=Path('/private/tmp/vellum-shell-exposure-20261027');S=W/'sdk';B=Path('/private/tmp/vellum-v1-public-checks-20261027/public-sdk/vellum-v1.0.0');D=X.parents[1]/'deliveries/macos-shell-exposure-20261027';D.mkdir()
sys.path.insert(0,str(R/'scripts'));from sdk_environment import child_environment
from child_process import run_child
import app_notices
spec=importlib.util.spec_from_file_location('checker',R/'scripts/check-sdk.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain');source='examples/macapps/cmd/macshell/main.go';assert subprocess.check_output(['git','show',head+':'+source],cwd=R)==(S/source).read_bytes()
manifest=json.loads((S/'SDK_MANIFEST.json').read_text());changes=[n for n,h in manifest['files'].items() if sha(S/n)!=h];assert set(changes)=={source,'drivers/cogent/build/upstream/core/renderwindow.go'}
patch_outputs=json.loads((R/'drivers/cogent/native/patches/exposure/output-hashes.json').read_text())
assert all(sha(S/'drivers/cogent/build/upstream'/n)==h for n,h in patch_outputs.items())
previous=json.loads((R/'docs/reports/macos-shell-contrast/replacement-package.json').read_text())
assert sha(S/source)==previous['main_sha256']
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',GOTOOLCHAIN='local',GOWORK='off',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
checks=[]
def run(name,args,cwd=R):
 start=time.monotonic()
 with (X/(name+'.stdout')).open('wb') as out,(X/(name+'.stderr')).open('wb') as err:p=run_child([str(a) for a in args],cwd=cwd,env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=4<<20)
 c={'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)};checks.append(c);print(json.dumps(c),flush=True);assert p.returncode==0,(name,(X/(name+'.stderr')).read_text()[-2000:]);return (X/(name+'.stdout')).read_text()
oldmods=checker.decode_objects(run('baseline-modules',['go','list','-mod=readonly','-m','-json','all'],B/'examples/macapps'))
newmods=checker.decode_objects(run('replacement-modules',['go','list','-mod=readonly','-m','-json','all'],S/'examples/macapps'))
def identity(mods,root):
 answer={}
 for m in mods:
  rec={k:m[k] for k in ('Path','Version','Sum','GoVersion') if k in m}
  if 'Replace' in m:
   q=m['Replace'];rec['Replace']={k:q[k] for k in ('Version','Sum','GoVersion') if k in q}
   rec['Replace']['origin']=str(Path(q['Dir']).resolve().relative_to(root)) if 'Dir' in q and Path(q['Dir']).is_relative_to(root) else q.get('Path')
  answer[m['Path']]=rec
 return answer
assert identity(oldmods,B)==identity(newmods,S)
origins=checker.check_origin(newmods,S,manifest['release']['module'],manifest['native_gpu'])
binary=W/'Vellum Mac Shell';linkmap=W/'shell.map'
run('replacement-build',['go','build','-mod=readonly','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',binary,'./cmd/macshell'],S/'examples/macapps')
native=S/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a';assert sha(native)=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883';assert str(native).encode() in linkmap.read_bytes()
lines=[l for l in linkmap.read_text(errors='replace').splitlines() if str(native) in l];(X/'native-link-excerpt.txt').write_text('\n'.join(lines)+'\n')
oldnotice=Path('/private/tmp/vellum-shell-contrast-20261027/notices');old=json.loads((oldnotice/'INVENTORY.json').read_text());app_notices.load(oldnotice,old['artifact_sha256'])
try:app_notices.load(oldnotice,sha(binary))
except ValueError:pass
else:raise AssertionError('old binary notice binding incorrectly accepted new binary')
notices=W/'notices';shutil.copytree(oldnotice,notices);new=copy.deepcopy(old);new['artifact_sha256']=sha(binary);(notices/'INVENTORY.json').write_text(json.dumps(new,indent=2,sort_keys=True)+'\n');nr,_=app_notices.load(notices,sha(binary));assert len(new['files'])==418;tmp=copy.deepcopy(new);tmp['artifact_sha256']=old['artifact_sha256'];assert tmp==old
for n in old['files']:assert (oldnotice/n).read_bytes()==(notices/n).read_bytes()
app=W/'Vellum Mac Shell.app';run('replacement-public-package',[sys.executable,'-B','scripts/package-app.py','--public','--binary',binary,'--notice-bundle',notices,'--output',app,'--name','Vellum Mac Shell','--identifier','com.dshills.vellum.macshell.v1','--version','1.0.0','--build-version','12','--sign-identity','-'])
archive=D/'Vellum Mac Shell.zip';run('replacement-zip',['ditto','-c','-k','--norsrc','--noextattr','--keepParent',app,archive]);ex=W/'exact';ex.mkdir();run('replacement-extract',['ditto','-x','-k',archive,ex]);exact=ex/app.name;run('replacement-signature',['codesign','--verify','--deep','--strict',exact]);launch=W/'launch';launch.mkdir();appcopy=launch/app.name;run('replacement-launch-copy',['ditto','--norsrc','--noextattr',exact,appcopy]);run('replacement-launch-signature',['codesign','--verify','--deep','--strict',appcopy])
m=json.loads((appcopy/'Contents/Resources/APP_MANIFEST.json').read_text());assert not m['private_build'] and not m['notarized'] and m['native_distribution_audit']=='approved' and m['source_binary_sha256']==sha(binary) and m['build_version']=='12';assert m['component_notices']==nr;assert m['release_authorization']['source']=={'commit':head,'clean':True};assert sha(appcopy/'Contents/MacOS/Vellum Mac Shell')==sha(exact/'Contents/MacOS/Vellum Mac Shell')
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
oldresult=json.loads((R/'docs/reports/macos-v1-public-packaging/package-result.json').read_text());prior=json.loads((R/'docs/reports/macos-shell-contrast/replacement-package.json').read_text())
result={'schema':1,'source_commit':head,'baseline_product_source':oldresult['product_source'],'baseline_sdk_sha256':oldresult['sdk']['sha256'],'changed_product_files':changes,'module_records_unchanged':len(newmods),'module_origins':origins,'native_archive_sha256':sha(native),'linkmap_sha256':sha(linkmap),'main_sha256':sha(S/source),'previous_source_binary_sha256':old['artifact_sha256'],'source_binary_sha256':sha(binary),'previous_notice_inventory_sha256':sha(oldnotice/'INVENTORY.json'),'notice_inventory_sha256':sha(notices/'INVENTORY.json'),'notice_original_files_unchanged':418,'notice_inventory_only_changed_field':'artifact_sha256','old_notice_binding_rejects_replacement':True,'previous_zip_sha256':prior['archive_sha256'],'archive':archive.name,'archive_sha256':sha(archive),'packaged_binary_sha256':sha(appcopy/'Contents/MacOS/Vellum Mac Shell'),'manifest_sha256':sha(appcopy/'Contents/Resources/APP_MANIFEST.json'),'build_version':'12','private_build':False,'notarized':False,'native_distribution_audit':'approved','prepared_go_patch':{'file':'drivers/cogent/native/patches/exposure/0108-window-exposure-repaint.patch','sha256':sha(R/'drivers/cogent/native/patches/exposure/0108-window-exposure-repaint.patch'),'output_hashes':patch_outputs},'runtime_delta_from_build11':['core/renderwindow.go'],'runtime_result':'not-yet-run','audit_scope':'Reviewed prepared-Go exposure repair plus unchanged build11 fixture source; original notices, dependencies and native archive bytes unchanged. Historical exact-payload owner approval remains unchanged, not relabeled as approval of this new binary/archive hash. Separate final-asset publication decision still required.','publication_authorized':False,'uploaded':False,'checks':checks}
(X/'replacement-package.json').write_text(json.dumps(result,indent=2)+'\n');(D/'MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({'complete':True,'source':head,'archive_sha256':sha(archive),'delivery':str(D)}))
