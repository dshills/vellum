from pathlib import Path
import os,json,hashlib,shutil,sys,time
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;W=Path('/private/tmp/vellum-shell-exposure-20261027');W.mkdir();S=W/'sdk';prior=Path('/private/tmp/vellum-shell-contrast-20261027/sdk');shutil.copytree(prior,S)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((S/'SDK_MANIFEST.json').read_text());changed=[n for n,h in m['files'].items() if sha(S/n)!=h];assert changed==['examples/macapps/cmd/macshell/main.go']
shutil.copyfile(X/'exposure_vellum_test.go',S/'drivers/cogent/build/upstream/core/exposure_vellum_test.go')
sys.path.insert(0,str(R/'scripts'));from child_process import run_child
from sdk_environment import child_environment
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',GOTOOLCHAIN='local',GOWORK='off',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
with (X/'baseline-regression.stdout').open('wb') as out,(X/'baseline-regression.stderr').open('wb') as err:
 p=run_child(['go','test','-mod=readonly','-race','-tags','offscreen','./core','-run','^TestVellumExposure','-count=1'],cwd=S/'drivers/cogent/build/upstream',env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=4<<20)
print(json.dumps({'exit_code':p.returncode,'stdout':(X/'baseline-regression.stdout').read_text()[-5000:],'stderr':(X/'baseline-regression.stderr').read_text()[-1500:]}))
