from pathlib import Path
import json,hashlib,difflib,subprocess,shutil
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;S=Path('/private/tmp/vellum-shell-exposure-20261027/sdk');core=S/'drivers/cogent/build/upstream';file='core/renderwindow.go';before=(core/file).read_text();after=before.replace('\tw.SystemWindow.Raise()\n}', '\tw.SystemWindow.Raise()\n\t// Native exposure needs one presentation even when the model is unchanged.\n\t// Closing another window restores focus through this same Raise path.\n\tw.flags.SetFlag(true, winRenderSkipped)\n\tw.requestPaintAfter(0)\n}',1)
after=after.replace('\t\tcase events.WinShow:\n\t\t\te.SetHandled()', '\t\tcase events.WinShow:\n\t\t\te.SetHandled()\n\t\t\tw.flags.SetFlag(true, winRenderSkipped)',1)
after=after.replace('\t\t\tif !w.flags.HasFlag(winGotFocus) {', '\t\t\tw.flags.SetFlag(true, winRenderSkipped)\n\t\t\tif !w.flags.HasFlag(winGotFocus) {',1)
old='''\tif !spriteMods && !rebuild && !stageMods && !sceneMods { // nothing to do!
\t\tif w.flags.HasFlag(winRenderSkipped) {
\t\t\tw.flags.SetFlag(false, winRenderSkipped)
\t\t} else {
\t\t\ttraceUnchanged = true
\t\t\treturn
\t\t}
\t}'''
new='''\tif !spriteMods && !rebuild && !stageMods && !sceneMods && !w.flags.HasFlag(winRenderSkipped) {
\t\ttraceUnchanged = true
\t\treturn
\t}'''
assert old in after;after=after.replace(old,new,1)
after=after.replace('\tif !w.isVisible() || w.SystemWindow.Is(system.Minimized) {\n', '\tif !w.isVisible() || w.SystemWindow.Is(system.Minimized) {\n\t\t// updateAll may consume scene dirty state while no native frame can show.\n\t\t// Retain a single presentation request until visibility returns.\n\t\tw.flags.SetFlag(true, winRenderSkipped)\n',1)
after=after.replace('\tcp := w.SystemWindow.Composer()\n\tcp.Start()', '\tcp := w.SystemWindow.Composer()\n\tw.flags.SetFlag(false, winRenderSkipped)\n\tcp.Start()',1)
assert after!=before;(X/'renderwindow-before.go').write_text(before);(core/file).write_text(after)
test=core/'core/exposure_vellum_test.go';txt=test.read_text();insert='''
func (w *exposureVisibilityWindow) ManualExecution() bool { return w.Window.(manualSystemWindow).ManualExecution() }
func (w *exposureVisibilityWindow) ManualState() system.ManualWindowState { return w.Window.(manualSystemWindow).ManualState() }
func (w *exposureVisibilityWindow) FlushReadyPaint() bool { return w.Window.(manualSystemWindow).FlushReadyPaint() }
func (w *exposureVisibilityWindow) RequestPaint() { w.Window.(requestedPainter).RequestPaint() }
func (w *exposureVisibilityWindow) IsOnDemand() bool { return w.Window.(requestedPainter).IsOnDemand() }
''';txt=txt.replace('\nfunc TestVellumExposureSurvivesHiddenPresentation',insert+'\nfunc TestVellumExposureSurvivesHiddenPresentation');test.write_text(txt)
go='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin/gofmt';subprocess.run([go,'-w',str(core/file),str(test)],check=True)
sha=lambda b:hashlib.sha256(b).hexdigest();P=R/'drivers/cogent/native/patches/exposure';P.mkdir();testfile='core/exposure_vellum_test.go';patch=''.join(difflib.unified_diff(before.splitlines(True),(core/file).read_text().splitlines(True),fromfile='a/'+file,tofile='b/'+file))+''.join(difflib.unified_diff([],test.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+testfile))
(P/'0108-window-exposure-repaint.patch').write_text(patch);(P/'original-hashes.json').write_text(json.dumps({file:sha(before.encode()),testfile:None},indent=2)+'\n');(P/'output-hashes.json').write_text(json.dumps({file:sha((core/file).read_bytes()),testfile:sha(test.read_bytes())},indent=2)+'\n')
f=R/'drivers/cogent/native/dependencies.json';v=json.loads(f.read_text());v['dependencies'][0]['stages'].append({'origin':'Vellum bounded native window exposure repaint repair','inputs':'native/patches/exposure/original-hashes.json','outputs':'native/patches/exposure/output-hashes.json','patches':[{'file':'native/patches/exposure/0108-window-exposure-repaint.patch','sha256':sha(patch.encode())}]});f.write_text(json.dumps(v,indent=2)+'\n')
f=R/'drivers/cogent/prepare_test.py';s=f.read_text();s=s.replace('self.assertEqual(numbers, list(range(1, 108)))','self.assertEqual(numbers, list(range(1, 109)))');s=s.replace('core["stages"][-2]["patches"][0]["file"]).name, "0106','core["stages"][-3]["patches"][0]["file"]).name, "0106').replace('core["stages"][-1]["patches"][0]["file"]).name, "0107','core["stages"][-2]["patches"][0]["file"]).name, "0107');needle='        stage105 = core["stages"][index105]\n';assert needle in s
s=s.replace(needle,needle+'''        exposure = core["stages"][-1]
        self.assertEqual(Path(exposure["patches"][0]["file"]).name, "0108-window-exposure-repaint.patch")
        exposure_inputs = json.loads((ROOT / exposure["inputs"]).read_text())
        prior_outputs = {}
        for stage in core["stages"][:-1]:
            if "outputs" in stage:
                prior_outputs.update(json.loads((ROOT / stage["outputs"]).read_text()))
        self.assertEqual(exposure_inputs, {"core/renderwindow.go": prior_outputs["core/renderwindow.go"],
                                          "core/exposure_vellum_test.go": None})
''');f.write_text(s)
shutil.copyfile(test,X/'exposure-final_test.go');print(json.dumps({'patch_sha256':sha(patch.encode()),'original_renderwindow_sha256':sha(before.encode()),'output_renderwindow_sha256':sha((core/file).read_bytes())}))
