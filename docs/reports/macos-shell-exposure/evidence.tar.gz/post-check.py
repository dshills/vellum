from pathlib import Path
import hashlib,json,subprocess,sys,datetime
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;W=Path('/private/tmp/vellum-shell-exposure-20261027');D=X.parents[1]/'deliveries/macos-shell-exposure-20261027';OLD=X.parents[1]/'deliveries/macos-v1-public-candidates-20261027';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(R/'scripts'));import app_notices
p=json.loads((X/'replacement-package.json').read_text());app=W/'launch/Vellum Mac Shell.app';binary=app/'Contents/MacOS/Vellum Mac Shell';manifest=app/'Contents/Resources/APP_MANIFEST.json'
assert sha(binary)==p['packaged_binary_sha256'];assert sha(manifest)==p['manifest_sha256'];assert sha(D/p['archive'])==p['archive_sha256']
c=subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,text=True,timeout=30);(X/'post-signature.stdout').write_text(c.stdout);(X/'post-signature.stderr').write_text(c.stderr);assert c.returncode==0
nr,_=app_notices.load(app/'Contents/Resources/THIRD_PARTY_NOTICES',p['source_binary_sha256']);assert nr['inventory_sha256']==p['notice_inventory_sha256'] and nr['files']==418
ps=subprocess.check_output(['ps','-axo','pid=,comm=,args='],text=True);assert not any(str(binary) in line for line in ps.splitlines())
for line in (OLD/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(OLD/n)==h
priorD=X.parents[1]/'deliveries/macos-shell-contrast-20261027';assert sha(priorD/p['archive'])==p['previous_zip_sha256']
N=X/'native'
for n in ['baseline-after-close.txt','baseline-a-after-edited-b.txt','fixed1-a-native-close.txt','fixed1-a-raised.txt','fixed2-a0-native-close.txt','fixed3-a0-content-close.txt']:assert 'Document A edits: 0' in (N/n).read_text(),n
assert 'Document B edits: 2' in (N/'fixed2-b2.txt').read_text();assert 'Document A edits: 1' in (N/'fixed3-a1.txt').read_text();assert 'button (disabled) Description: Edit document B' in (N/'fixed3-b-locked.txt').read_text();assert 'Value: off' in (N/'fixed3-b-unlocked.txt').read_text()
for n in ['fixed1-closed.txt','fixed2-closed.txt','fixed3-closed.txt']:
 text=(N/n).read_text();assert 'App quit' in text or 'procNotFound' in text,n
captures=[{'path':'native/'+f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(N.iterdir()) if f.is_file()]
result={'schema':1,'source_commit':p['source_commit'],'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_build11_controls':{'runs':2,'result':'A0 correctly observed without model action; earlier mismatch intermittent, not erased or proven capture-only'},'replacement_build12_cases':[{'case':'native B0 close to A0, plus native Raise','result':'AX and pixels match A0 without model edit'},{'case':'native B2 close to A0','result':'AX and pixels match A0 without model edit; B2 pixels distinct'},{'case':'content Close B to A0','result':'AX and pixels match A0 before any A action'}],'toolbar_and_lock':'B increments to2, lock disables/reenables its toolbar; A later increments once to1','contrast':'readable Light window/background in all replacement captures','normal_final_window_close':'observed in all three runs; final exact process path absent','postlaunch_strict_signature':True,'signed_binary_and_manifest_unchanged':True,'binary_bound_notice_files_verified':418,'historical_archives_unchanged':{'public_candidates':7,'contrast_build11':True},'exposure_acceptance':'pass within the three bounded Shell cases; deterministic missing-presentation regression fixed','scope':'Native AX actions and captured pixels; not physical-pointer, cross-platform, other-host, performance, human IME/VoiceOver or downloaded-quarantine qualification','recommended_for_final_asset_decision':True,'publication_authorized':False,'uploaded':False,'evidence':captures}
(X/'replacement-native.json').write_text(json.dumps(result,indent=2)+'\n');final=dict(p);final['runtime_result']='pass: three bounded exposure cases without model edit';final['native_check']=result;final['recommended_for_final_asset_decision']=True;(D/'MANIFEST.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'exposure_cases_pass':3,'post_signature_notice_integrity_pass':True,'prior_public_archives_unchanged':7,'prior_build11_unchanged':True,'candidate_process_absent':True}))
