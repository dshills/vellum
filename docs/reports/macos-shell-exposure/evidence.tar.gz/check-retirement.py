from pathlib import Path
import os,sys,json,time
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;S=Path('/private/tmp/vellum-shell-exposure-20261027/sdk')
sys.path.insert(0,str(R/'scripts'));from child_process import run_child
from sdk_environment import child_environment
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',GOTOOLCHAIN='local',GOWORK='off',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
with (X/'retirement-race.stdout').open('wb') as out,(X/'retirement-race.stderr').open('wb') as err:
 p=run_child(['go','test','-mod=readonly','-race','-tags','offscreen','./core','-run','^(TestVellumWindowRetirement|TestVellumWindowListNativeFocusCloseEvents|TestVellumWindowFocusRetirement)','-count=1'],cwd=S/'drivers/cogent/build/upstream',env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=4<<20)
assert p.returncode==0,(X/'retirement-race.stdout').read_text()+(X/'retirement-race.stderr').read_text()
v=json.loads((X/'fix-checks.json').read_text());v['retirement_focus_race_regressions_pass']=True;(X/'fix-checks.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'retirement_focus_race_regressions_pass':True}))
