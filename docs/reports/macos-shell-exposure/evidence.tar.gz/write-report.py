from pathlib import Path
import json,hashlib,shutil,tarfile,gzip,io
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;D=X.parents[1]/'deliveries/macos-shell-exposure-20261027';O=R/'docs/reports/macos-shell-exposure';O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((X/'replacement-package.json').read_text());n=json.loads((X/'replacement-native.json').read_text())
p['audit_scope']='Reviewed prepared-Core Go exposure repair; build11 fixture source, dependency module identities/versions, assets, original notices and native archive unchanged. Prepared Core Go source is explicitly changed by pinned stage0108. Historical owner approval is unchanged, not relabeled as approval of the new binary/archive. Final asset publication remains unapproved.'
(X/'replacement-package.json').write_text(json.dumps(p,indent=2)+'\n')
curated=dict(p);curated['runtime_result']='pass: three bounded exposure cases without model edit';curated['runtime_evidence']='replacement-native.json';curated['recommended_for_final_asset_decision']=True
(O/'replacement-package.json').write_text(json.dumps(curated,indent=2)+'\n');shutil.copyfile(X/'replacement-native.json',O/'replacement-native.json');shutil.copyfile(D/'SHA256SUMS',O/'SHA256SUMS')
final=dict(curated);final['native_check']=n;(D/'MANIFEST.json').write_text(json.dumps(final,indent=2)+'\n')
old=json.loads((R/'docs/reports/macos-v1-public-packaging/package-result.json').read_text())
assets=[{'file':old['sdk']['archive'],'sha256':old['sdk']['sha256'],'local_delivery':'macos-v1-public-candidates-20261027','source':old['sdk']['source']}]
for app in old['apps']:
 if app['id']=='shell':assets.append({'file':p['archive'],'sha256':p['archive_sha256'],'local_delivery':D.name,'source_commit':p['source_commit'],'build':'12','prepared_go_overlay':'stage0108'})
 else:assets.append({'file':app['archive'],'sha256':app['archive_sha256'],'local_delivery':'macos-v1-public-candidates-20261027','product_source':old['product_source'],'packaging_source':old['packaging_source']})
packet={'schema':1,'assets':assets,'source_tag_unchanged':old['product_source'],'historical_audits_unchanged':True,'publication_authorized':False,'uploaded':False,'signing_route':'ad-hoc signed, unnotarized developer download; no downloaded-quarantine qualification','scope':'SDK and five previous app archives unchanged. Only Shell is replaced by build12. Source/metadata origins differ explicitly; no tag movement or claim old SDK contains stage0108.'}
(O/'PUBLICATION_SET.json').write_text(json.dumps(packet,indent=2)+'\n');(D/'PUBLICATION_SET.json').write_text(json.dumps(packet,indent=2)+'\n')
files=sorted(f for f in X.iterdir() if f.is_file() and f.suffix in {'.py','.json','.stdout','.stderr','.txt','.go'})+sorted((X/'native').iterdir());index=[{'path':str(f.relative_to(X)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
with (O/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for f in files:
    b=f.read_bytes();m=tarfile.TarInfo(str(f.relative_to(X)));m.size=len(b);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(b))
(O/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(O/'evidence.tar.gz'),'members':index},indent=2)+'\n')
for src,dst in [('fixed2-b2.jpg','before-b2.jpg'),('fixed2-a0-native-close.jpg','after-a0.jpg')]:shutil.copyfile(X/'native'/src,O/dst)
(O/'README.md').write_text('''# Mac Shell window-exposure repair — verified build12

**Build12 passes the bounded window-exposure acceptance checks.** Closing B,
including an edited B2, reveals A's own unchanged A0 content without an action in
A. Both native and application Close paths pass. Native Raise also preserves A0.
The earlier contrast repair remains intact. Features, public APIs, backend,
experimental rendering/pacing and release/performance policy are unchanged.

## Cause and correction

The native path requested paint on focus/show, but the clean-scene fast path
could skip composition. Raise (used to restore a survivor after sibling closure)
also did not request its own presentation. Thus a native destination requiring
restoration could remain stale until a model edit made scene content dirty.

[Checksum-pinned stage0108](../../../drivers/cogent/native/patches/exposure/README.md)
marks one per-window presentation request on Raise/focus/show and consumes it only
after visibility and native ownership admit composition. A hidden pass preserves
one request. The existing paint coalescer handles repeated/in-flight requests;
normal unchanged idle still skips work. No timer loop, value edit, command,
new backend or pacing option is used as a workaround.

Source commit: `'''+p['source_commit']+'''`.
The new stage changes `core/renderwindow.go` and adds an offscreen regression
file. Build11's Shell source/appearance/artwork is unchanged. Existing window
lifetime and registration guards remain in use. [Prism/test checkpoint](../../reviews/macos-shell-exposure/README.md).

## Evidence and its limits

The same real retained-scene/software-compositor tests fail on the prior path
and pass on the repair. They overwrite only destination pixels, then restore the
owner's cached scene without any model/scene edit through close-other, Raise,
focus and show. Hidden/in-flight and repeated requests are coalesced/retained;
idle stays idle. Related busy/display-admission, concurrent focus/retirement,
Core vet and patch-pin checks pass. The normal preparer reproduces the exact
tested output hashes and rejects drift before creating the new regression file.

Two fresh bounded live controls of unchanged build11 happened to pass. These
passes do not erase the earlier failed captures or establish that the capture
service caused them. The deterministic missing-presentation gap is established
and repaired; it is not claimed as proof of the sole cause of every old capture.

The exact ZIP-extracted build12 was observed in three independent launches:

1. Native close of B0 exposes correct A0; native Raise still shows A0.
2. Native close of visibly distinct B2 exposes correct A0, with no action in A.
3. The application Close button exposes correct A0; A's own toolbar then makes
   exactly one edit to A1. B's lock disables/reenables its native toolbar.

![B2 before native close](before-b2.jpg)
![A0 after native close, before any action in A](after-a0.jpg)

Each run ends with normal last-window closure. The final exact executable process
path is absent. After closure, strict signature, signed binary/manifest and ZIP
hashes and all418 original notice files still verify. The previous seven public
candidate archives plus build11 remain byte-identical. [Native result](replacement-native.json)
and [indexed raw evidence](evidence-index.json) retain AX states, unedited captures,
expected baseline failures and actual command logs. These are native AX/capture
observations, not physical-pointer, human IME/VoiceOver, other-host/platform,
performance or downloaded-quarantine qualification. No exit code was fabricated.

## Exact replacement and distribution delta

- Version1.0.0 **build12**, replacing held build10/build11 only.
- Source executable SHA256: `'''+p['source_binary_sha256']+'''`.
- Signed executable SHA256: `'''+p['packaged_binary_sha256']+'''`.
- Notice inventory SHA256: `'''+p['notice_inventory_sha256']+'''`.
- Final ZIP SHA256: `'''+p['archive_sha256']+'''`.

The build starts with the verified prior SDK plus the unchanged build11 fixture
and the exact committed stage0108 prepared-Go outputs. Relative to build11 only
one runtime Go source changes. All'''+str(p['module_records_unchanged'])+''' module identities/versions, selected asset
bytes, original license/notice declarations and native archive786aaad8… remain
unchanged. **Prepared Core Go bytes do change**; they are not described as an
unchanged dependency payload. The actual link map selects the same native archive.
The SDK itself and other app downloads were not regenerated and do not acquire
this new patch. Updated source preparation includes it for future builds.

All418 notice bodies/component references remain identical; only their inventory's
artifact_sha256 is rebound to the new executable. The old binding correctly
rejects the new executable. The [package record](replacement-package.json) pins
all old/new hashes and the exact prepared-Go patch. Its final runtime outcome
references replacement-native.json. The unmodified pre-launch timing/status
snapshot in raw evidence records its capture-time not-yet-run state.

The unchanged public producer passes its clean-source/native-audit and exact
notice guards; manifests say private_build=false, native_distribution_audit=approved
and notarized=false. Those producer declarations are not approval to upload this
new archive. Historical exact-payload audit approvals and the v1.0.0 tag remain
unchanged; the new first-party prepared-Go source delta is explicit and reviewed.
No rights grant or owner approval of these new exact ZIP bytes is inferred.

Durable files: research workspace `deliveries/macos-shell-exposure-20261027/`.
Use [SHA256SUMS](SHA256SUMS), never substitute a loose temporary app directory.
The replacement can now join the unchanged SDK and five apps in the separately
proposed [publication set](PUBLICATION_SET.json). Both older Shell ZIPs remain
held historical artifacts; this checkpoint supersedes their hold only for build12.
Ad-hoc signing/unnotarized limits remain disclosed. No upload, tag movement,
merge, signing identity, notarization, notebook or global preference change occurred.
''')
(O/'PUBLICATION_PACKET.md').write_text('''# Updated local asset decision packet — unpublished

[PUBLICATION_SET.json](PUBLICATION_SET.json) lists the exact proposed seven files
and their current durable delivery folders. It replaces only the Shell entry
with verified build12; SDK, Notes, Mac Widgets, Forma, Luma and Pulse hashes are
unchanged. Old Shell build10/build11 are excluded. No assets are uploaded.

The prepared-Go exposure source delta is reviewed and explicit. The SDK and five
other apps retain their prior source identities and do not contain stage0108;
the new Shell source is9961ecf. Do not move the existing v1.0.0 source tag or claim
that it contains the later repair/report commits. All public API and support
limits remain the same. Original native/module/license/notice inputs are carried
forward; the exact replacement binary/archive hashes are new, not automatically
covered by a historical owner decision.

A final owner decision must identify these exact seven files, the disclosed
ad-hoc/unnotarized route, source/packaging revisions and destination/release text.
After authorization, recheck all asset hashes, upload only the selected bytes
and verify their remote hashes. Do not upload private inputs/evidence or the old
held Shell archives. Developer ID/notarization would require separate authority
and produce a new hash packet. No signing identity or security bypass is used here.
''')
(D/'README.md').write_text('''# Vellum Mac Shell — exposure-corrected build12

Source '''+p['source_commit']+'''. Version1.0.0, build12.
Verify SHA256SUMS, extract Vellum Mac Shell.zip and open the app. Both windows
use fixed Light appearance and matching backgrounds. Requires Apple Silicon
macOS. Ad-hoc signed and unnotarized; downloaded-quarantine acceptance remains
unqualified. No security bypass or public upload is part of this handoff.

Try editing B with its toolbar, then close B with the native close button or
Close this window. A should reveal its own unchanged Document A edits:0 without
needing a click/edit to repaint it. A's toolbar then edits only A. Disable editing
controls its window's toolbar availability. Closing the last window exits.

Three bounded packaged launch/exposure/close runs pass; read-only pixels and AX
match A0 immediately after B closes. Deterministic retained-scene tests fail on
the old path and pass after the repair; hidden/busy requests stay bounded and idle
stays idle. All post-launch signatures/hashes/notices verify. Human accessibility,
physical-pointer, other hosts and broad performance remain outside these checks.

Other app/SDK packages and both older Shell ZIPs are retained unchanged. This app
adds one reviewed prepared-Go rendering repair; the older SDK itself does not
contain it. PUBLICATION_SET.json identifies the proposed updated asset set;
final public upload still requires an owner decision for those exact files.
''')
f=R/'README.md';s=f.read_text().replace('A [contrast-corrected Mac Shell replacement](docs/reports/macos-shell-contrast/README.md)\nis verified locally; a separate exposure/capture discrepancy keeps that optional\nfixture outside the proposed public set.', 'The [Mac Shell build12 replacement](docs/reports/macos-shell-exposure/README.md)\nalso passes bounded window-exposure checks and can join the proposed asset set.\nIt includes a reviewed prepared-Go repair; the older SDK/app archives stay unchanged.');f.write_text(s)
f=R/'docs/macos-v1.md';s=f.read_text().replace('now has a [contrast-corrected replacement](reports/macos-shell-contrast/README.md),\nwith a separate unresolved exposure/capture discrepancy. It remains outside the\nproposed public upload set.', 'now has a [verified build12 replacement](reports/macos-shell-exposure/README.md)\ncovering contrast and bounded window exposure without model edits. It can join\nthe proposed asset set after a separate final-asset decision. Other SDK/app\narchives remain unchanged and do not gain its prepared-Go exposure repair.');f.write_text(s)
f=R/'docs/README.md';s=f.read_text().replace('- [Mac Shell contrast correction]', '- [Mac Shell exposure correction](reports/macos-shell-exposure/README.md): verified build12 and updated proposed asset set.\n- [Mac Shell contrast correction]');s=s.replace('verified replacement, unchanged notices and a remaining exposure/capture discrepancy.', 'historical build11, unchanged notices and its recorded exposure/capture discrepancy.');f.write_text(s)
f=R/'docs/reviews/macos-shell-exposure/README.md';f.write_text(f.read_text()+'''\nThe committed fix is rebuilt as version1.0.0 build12 through unchanged public\nproducer guards. Three packaged native launch/exposure checks pass without an A\nmodel edit after B closes (B0 native close, B2 native close, application Close),\nincluding a native Raise control. A later toolbar edit and B lock availability\nremain correct. All three runs close normally; post-launch signatures, notices\nand archive integrity verify. Historical SDK/app/build11 archives are unchanged.\nThe current report closes bounded Shell exposure acceptance while retaining the\nold intermittent captures and limits. No upload/audit/tag change is performed.\n''')
print(json.dumps({'evidence_members':len(index),'evidence_bytes':(O/'evidence.tar.gz').stat().st_size,'proposed_assets':len(assets),'report':str(O)}))
