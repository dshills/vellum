"""Interleaved opt-in GPU scene comparison of baseline and candidate binaries."""
from pathlib import Path
import importlib.util, json, os, subprocess
from run import ROOT, PHASE, baseline, sha

spec = importlib.util.spec_from_file_location('benchmark', ROOT / 'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)

class OwnedBenchmarkSubprocess:
    """Change only this imported benchmark module's native process admission."""
    def __getattr__(self, name):
        return getattr(subprocess, name)

    def Popen(self, *args, **options):
        assert options.pop('start_new_session') is True
        process = subprocess.Popen(*args, **options)
        try:
            assert os.getpgid(process.pid) == os.getpgrp()
        except BaseException:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=5)
            raise
        return process

def stop_native_child(process):
    # Local run_case failures join this direct child through its existing
    # finally. The outer runner separately owns hard cleanup of the group.
    if process.poll() is None:
        process.kill()

benchmark.subprocess = OwnedBenchmarkSubprocess()
benchmark.terminate_owned_group = stop_native_child
before = baseline()
overlay = json.loads((PHASE/'candidate-overlay.json').read_text())['Replace']
review = json.loads((PHASE/'overlay-source-review.json').read_text())
assert review['result'] == 'APPROVED_SOURCE' and not review['findings']
assert all(sha(path) == digest for path,digest in review['reviewed_file_sha256'].items())
assert set(review['reviewed_file_sha256']) == set(overlay.values())
changed = sorted(str(Path(path).relative_to(ROOT/'drivers/cogent/build/upstream')) for path in overlay)
for name in ['packed-native-v2','build-candidate-v2']:
    receipt=json.loads((PHASE/(name+'.json')).read_text())
    assert receipt['exit_code']==0 and receipt['error']is None and receipt['source_delta_stable']
    assert receipt['prepared_before']==receipt['prepared_after']==before['prepared']
    assert receipt['overlay_inputs_before']==receipt['overlay_inputs_after']
    assert all(receipt['overlay_inputs_after'][path]==digest for path,digest in review['reviewed_file_sha256'].items())
binaries = {'baseline': PHASE / 'loadedgrid', 'candidate': PHASE / 'loadedgrid-candidate'}
digests = {name: sha(path) for name, path in binaries.items()}
build = json.loads((PHASE / 'build-grid-v1.json').read_text())
assert build['exit_code'] == 0 and build['error'] is None and build['source_delta_stable'] and build['prepared_before']==build['prepared_after']==before['prepared']
(PHASE / 'binary-identities.json').write_text(json.dumps(digests,indent=2)+'\n')
out = PHASE / 'pilot'
out.mkdir(exist_ok=False)
results = {mode: {} for mode in binaries}
progress = []
for variable in [False]:
    for rows in [10000]:
        case = f"{'variable' if variable else 'fixed'}-{rows}"
        for mode in binaries:
            results[mode][case] = []
        for repetition in range(2):
            order = ['baseline', 'candidate'] if repetition % 2 == 0 else ['candidate', 'baseline']
            for mode in order:
                samples, process = benchmark.run_case(binaries[mode], out / mode / case / f'run-{repetition+1}',
                                                      rows, variable, 120, 128, False, 180, gpu_scene_rendering=True)
                assert process['result'] == 'PASS' and process['exit_code'] == 0
                assert all(record.get('warmup_guard') == 1 for record in process['records'])
                assert process['records'][1]['warmup'] == process['records'][1]['warm_callbacks'] == 128
                assert before == baseline() and sha(binaries[mode]) == digests[mode]
                results[mode][case].append(samples)
                progress.append({'mode': mode, 'case': case, 'repetition': repetition+1,
                                 'result_sha256': sha(out / mode / case / f'run-{repetition+1}/result.json')})
                (out / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n')
                print(mode, case, repetition+1, flush=True)
            benchmark.compare_geometry(results['baseline'][case][-1], results['candidate'][case][-1])
            assert all(a['geometry'] == b['geometry']
                       for a, b in zip(results['baseline'][case][-1], results['candidate'][case][-1]))
summary = {mode: {case: {'timings_ns': benchmark.summarize(runs),
                         'go_process_alloc_bytes': benchmark.distribution([s['go_process_alloc_bytes'] for run in runs for s in run]),
                         'go_process_mallocs': benchmark.distribution([s['go_process_mallocs'] for run in runs for s in run])}
                  for case, runs in cases.items()} for mode, cases in results.items()}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
qualification = {'result': 'PASS_MATCHED_COMPARISON', 'runtime_baseline_sha256': sha(PHASE / 'baseline.json'),
                 'candidate_overlay_sha256': sha(PHASE / 'candidate-overlay.json'), 'binary_sha256': digests,
                 'processes': 4, 'ordinary_samples': 480, 'changed_prepared_overlay_source': sorted(changed), 'gpu_scene_rendering': True,
                 'warm_target_met': {mode: benchmark.warm_target_met(cases) for mode, cases in summary.items()},
                 'summary_sha256': sha(out / 'summary.json'), 'producer_sha256': sha(__file__),
                 'scope': 'Two optimized binaries, fixed10k pilot only, two interleaved pairs, exact paired geometry. All observations retained. Process-wide allocations include helpers/runtime; same observer implementation, original versus checked packed-input buffer overlay in opt-in GPU scene rendering; no full P6/Mac or physical GPU/presentation/native-allocation qualification.'}
(out / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
print(json.dumps(qualification), flush=True)
