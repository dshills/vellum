// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import "cogentcore.org/core/paint/renderers/sceneplan"

// One detached byte copy per input slot. Total retained capacity never exceeds
// 32MiB+16 bytes, independently of mutable/foreign Encoded slice backing.
const inputCopyMaxBytes = sceneplan.MaxBytes + 16

type inputCopies struct {
	data     [5][]byte
	retained int
}

func (c *inputCopies) clear(slot int) { c.retained -= cap(c.data[slot]); c.data[slot] = nil }
func (c *inputCopies) remember(slot int, src []byte) {
	if len(src) > inputCopyMaxBytes {
		c.clear(slot)
		return
	}
	if cap(c.data[slot]) < len(src) {
		c.clear(slot)
		if len(src) > inputCopyMaxBytes-c.retained {
			return
		}
		c.data[slot] = make([]byte, len(src))
		c.retained += len(src)
	} else {
		c.data[slot] = c.data[slot][:len(src)]
	}
	copy(c.data[slot], src)
}
