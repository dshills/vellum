// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"bytes"
	"testing"
)

func TestVellumInputCopiesDetachedCapacityAndRetirement(t *testing.T) {
	var c inputCopies
	src := []byte{1, 2, 3, 4}
	c.remember(1, src)
	src[0] = 9
	if bytes.Equal(c.data[1], src) {
		t.Fatal("cache borrowed mutable input")
	}
	c.remember(1, src)
	if !bytes.Equal(c.data[1], src) || c.retained != 4 {
		t.Fatal("same-size cache not reused")
	}
	c.remember(1, src[:2])
	if len(c.data[1]) != 2 || cap(c.data[1]) != 4 || c.retained != 4 {
		t.Fatal("short slice lost capacity accounting")
	}
	c.remember(2, make([]byte, inputCopyMaxBytes-4))
	if c.retained != inputCopyMaxBytes {
		t.Fatal("capacity boundary not retained")
	}
	c.remember(1, make([]byte, 8))
	if c.data[1] != nil || c.retained != inputCopyMaxBytes-4 {
		t.Fatal("overbudget replacement retained")
	}
	c.remember(2, make([]byte, inputCopyMaxBytes+1))
	if c.data[2] != nil || c.retained != 0 {
		t.Fatal("oversized source retained")
	}
	c.remember(0, make([]byte, 16))
	c.clear(0)
	if c.retained != 0 || c.data[0] != nil {
		t.Fatal("buffer replacement retained stale bytes")
	}
}
