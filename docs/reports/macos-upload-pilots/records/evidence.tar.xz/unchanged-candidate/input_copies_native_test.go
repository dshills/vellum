//go:build !js

// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"bytes"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"encoding/binary"
	"image"
	"image/color"
	"image/draw"
	"testing"
)

func TestVellumInputCopiesNativeMutationAndReplacement(t *testing.T) {
	_, dev := nativeDevice(t)
	res := &resources{}
	defer res.release()
	reserve := func(uint64) error { return nil }
	size := image.Pt(23, 19)
	if err := res.initialize(dev, size, reserve); err != nil {
		t.Fatal(err)
	}
	b := sceneplan.New(image.Rectangle{Max: size})
	b.Draw(image.Rectangle{Max: size}, image.NewUniform(color.RGBA{17, 31, 53, 255}), image.Point{}, nil, image.Point{}, draw.Src)
	packet := b.Seal(false)
	e, ok := packet.Encode()
	if !ok {
		t.Fatal("fixture refused")
	}
	expected := image.NewRGBA(image.Rectangle{Max: size})
	packet.Replay(expected)
	for range 3 {
		if err := res.render(e, reserve); err != nil {
			t.Fatal(err)
		}
		if got := readTexture(t, dev, res.texture); !bytes.Equal(got.Pix, expected.Pix) {
			t.Fatal("unchanged inputs changed pixels")
		}
	}
	saved := append([]byte(nil), res.uploads.data[1]...)
	binary.LittleEndian.PutUint32(e.Ops[16:], 65*257)
	if !bytes.Equal(res.uploads.data[1], saved) {
		t.Fatal("encoded mutation rewrote uploaded-byte cache")
	}
	if err := res.render(e, reserve); err != nil {
		t.Fatal(err)
	}
	draw.Draw(expected, expected.Bounds(), image.NewUniform(color.RGBA{65, 31, 53, 255}), image.Point{}, draw.Src)
	if got := readTexture(t, dev, res.texture); !bytes.Equal(got.Pix, expected.Pix) {
		t.Fatal("in-place encoded change skipped necessary write")
	}
	old := res.buffers[4]
	large := *e
	large.Data = make([]byte, 64<<10)
	copy(large.Data, e.Data)
	if err := res.render(&large, reserve); err != nil {
		t.Fatal(err)
	}
	if res.buffers[4] == old || !bytes.Equal(res.uploads.data[4], large.Data) {
		t.Fatal("replacement retained old buffer/cache")
	}
	if got := readTexture(t, dev, res.texture); !bytes.Equal(got.Pix, expected.Pix) {
		t.Fatal("replacement with unchanged shader bytes used stale input")
	}
	res.release()
	if res.uploads.retained != 0 || res.uploads.data[0] != nil || res.uploads.data[1] != nil || res.uploads.data[2] != nil || res.uploads.data[3] != nil || res.uploads.data[4] != nil {
		t.Fatal("released input cache retained bytes")
	}
}
