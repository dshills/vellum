"""Record bounded negative performance evidence; adopt neither prototype."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-grid-profile-55');dest=r/'docs/reports/macos-upload-pilots';rec=dest/'records';rec.mkdir(parents=True,exist_ok=False)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
base=json.loads((p/'baseline.json').read_text());assert len(base['prepared'])==6202
from run import identity
assert identity()==base
variants={}
for name in ['pilot','copies-pilot']:
 summary=json.loads((p/name/'summary.json').read_text());q=json.loads((p/name/'qualification.json').read_text());assert q['ordinary_samples']==480 and q['processes']==4 and q['warm_target_met']=={'baseline':False,'candidate':False}
 variants[name]={'baseline':summary['baseline']['fixed-10000'],'candidate':summary['candidate']['fixed-10000'],'result':'REJECTED_NO_USEFUL_PILOT_GAIN','qualification_sha256':sha(p/name/'qualification.json')}
 # Production validator consumed every raw record in run_case; revalidate independent saved JSON here.
 import importlib.util
 spec=importlib.util.spec_from_file_location('bench',r/'scripts/benchmark-grid.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
 for mode in ['baseline','candidate']:
  for run in [1,2]:
   file=p/name/mode/'fixed-10000'/f'run-{run}'/'result.json';d=json.loads(file.read_text());assert d['result']=='PASS' and d['exit_code']==0
   records=d['records'];samples=bench.validate_records(records,10000,False,120,False,gpu_scene_rendering=True);assert len(samples)==120
   assert sha(p/name/mode/'fixed-10000'/f'run-{run}'/'native.log')==d['log_sha256']
# Diagnostic profile is explicitly separate from ordinary timings.
records=[json.loads(line)for line in (p/'gpu-profile-v1.stdout').read_text().splitlines()]
assert len(bench.validate_records(records,10000,False,512,False,allow_profile=True,gpu_scene_rendering=True))==512
q={'result':'REJECTED_BOTH_UPLOAD_PROTOTYPES','base_commit':base['commit'],'ordinary_processes':8,'ordinary_samples':960,'diagnostic_samples':512,'prepared_files':6202,'renderer_changed':False,'variants':variants,'limits':['Two repetitions and one fixed10k case per prototype; no complete performance campaign','Profiler samples include native waits/process activity; no GPU completion or physical CPU attribution','No new timing, allocation, P6, P11 or Mac acceptance claimed'],'next_evidence_priority':'Layout/paint and reconciliation currently remain substantial parts of warm UI work; examine cell renderer reuse before more upload-call changes.'}
(rec/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
entries={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f==rec/'evidence.tar.xz':continue
 if f.name.startswith('loadedgrid') or f.name=='binary-identities.json':continue
 if f.suffix not in ['.py','.json','.stdout','.stderr','.go','.md','.log','.pprof']:continue
 entries[f.relative_to(p).as_posix()]=f
with tarfile.open(rec/'evidence.tar.xz','w:xz')as t:
 for n,f in entries.items():t.add(f,arcname=n,recursive=False)
index={n:sha(f)for n,f in entries.items()}
with tarfile.open(rec/'evidence.tar.xz')as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t.getmembers()if m.isfile()}==index
(rec/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(rec/'evidence.tar.xz'),'verified_members':len(index),'members':index},indent=2)+'\n')
(dest/'README.md').write_text('''# Mac upload optimization pilots

Two tested renderer prototypes were rejected: neither reduced warm native UI
work in its bounded pilot. No native patch was added and the production renderer
remains unchanged at this checkpoint. This prevents adopting additional memory
or lifetime complexity without a demonstrated benefit.

A current optimized GPU-scene process recorded 512 fixed10k scroll samples with
a CPU profile. Cumulative CPU samples included0.64s under resources.uploadInput
and Queue.TryWriteBuffer, compared0.18s under Packet.Encode. About4.42s appears
under native WaitEventsTimeout; this is process-level sampling and must not be
classified as UI CPU execution. The diagnostic run cannot qualify warm targets.

The first prototype packed config and four inputs into one bounded upload while
keeping shader bindings and painter order. Exact native integer/text/path parity,
shared-device fallback, resize, resource retirement and allocation-refusal tests
passed; internal review caught and fixed a separate padding-bound discrepancy.
The second kept the original five GPU buffers and skipped writes whose bytes
matched detached bounded copies. Native repeated/mutable input, replacement,
pixel parity, fallback and retirement tests passed. Neither prototype was adopted.

Each pilot ran four sequential release processes: two alternating baseline/
candidate pairs,128 guarded warmup callbacks and120 samples per process. All
paired400-cell geometry and callback guards passed. Both use the same observer
and opt-in GPU scene mode. Profiling was disabled for all ordinary processes.

| Prototype | Baseline / candidate p95 (ms) | Baseline / candidate p99 (ms) | Mean UI work (ms) | Mean Go allocation (MiB/sample) |
| --- | --- | --- | --- | --- |
''')
with(dest/'README.md').open('a')as f:
 for name,label in [('pilot','Packed upload'),('copies-pilot','Unchanged upload copies')]:
  v=variants[name];a=v['baseline']['timings_ns']['ui_work_ns']['pooled'];b=v['candidate']['timings_ns']['ui_work_ns']['pooled'];aa=v['baseline']['go_process_alloc_bytes']['mean']/2**20;bb=v['candidate']['go_process_alloc_bytes']['mean']/2**20
  f.write(f"| {label} | {a['p95']/1e6:.3f} / {b['p95']/1e6:.3f} | {a['p99']/1e6:.3f} / {b['p99']/1e6:.3f} | {a['mean']/1e6:.3f} / {b['mean']/1e6:.3f} | {aa:.3f} / {bb:.3f} |\n")
 f.write('''
Two runs of one case are a screening pilot, not statistical proof of a general
regression or a complete P6 campaign. The observations provide no useful gain
that warrants a full campaign or production adoption. Every process still fails
the unchanged4ms p95 /6ms p99 targets. Process allocation includes observers,
helpers and runtime, rather than framework-only attribution.

Current baseline mean phase observations are approximately1.39ms reconciliation,
1.94ms layout/paint and2.26ms raster/upload. These are separately measured
boundaries in this fixture, not independent percentiles to add. The next priority
is cell layout/render reuse and reconciliation costs; another upload-only change
is not justified by these pilots.

[Qualification](records/qualification.json) and [archive index](records/evidence-index.json)
retain both prototypes, source reviews, raw native logs/receipts, the profile and
producer scripts. The archive excludes executables; their hashes remain in build
and measurement receipts. The6262-byte distinction is not relevant: prepared
source stayed exact at6202 files. No full P6/P11, native memory, GPU completion,
presentation, human input/accessibility or distribution gate is closed.
''')
# correct accidental drafting typo before review
f=dest/'README.md';s=f.read_text().replace('The6262-byte distinction is not relevant: prepared\nsource stayed exact at6202 files.', 'Prepared\nsource stayed exact at6202 files.').replace('unchanged4ms p95 /6ms','unchanged 4ms p95 /6ms');f.write_text(s)
