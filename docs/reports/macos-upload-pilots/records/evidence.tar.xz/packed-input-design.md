# Packed ordered-scene input upload

Current diagnostic profile records 512 real table-scroll samples on aad1b4b.
CPU sample table shows resources.uploadInput → Queue.TryWriteBuffer about0.64s,
compared0.18s packet encoding; mainloop cgocall idle dominates overall profile and
must not be classified as UI work. This is diagnostic evidence, not target pass.

Proposal: retain one GPU input buffer for config plus four encoded inputs,
instead of five independently owned GPU buffers. Keep the same WGSL bindings:
0 config,1 ops,2 tile rows,3 refs,4 packed masks/pixels;5 output is unchanged.
Each binding uses explicit offset/size in the one owned buffer. Offset0 contains
16-byte config; subsequent offsets align to actual device
MinStorageBufferOffsetAlignment. Uniformoffset0 automaticallyaligned. Check each
input length >=4/alignment4/maxStorageBinding and checked combined <=MaxBuffer.

A pure bounded plan helper computes offsets and packs one detached contiguous
[]byte. Cap total staging with sceneplan.MaxBytes plus fixed bounded alignment
padding, checked against device and a small maximum alignment. No new source,
font/widget references or reusable CPU cache. Padding iszero. Shader bindings use exact logical input lengths instead of old buffer capacity;
validated packet accesses remain equivalent. outputbuffer/stride unchanged. One queue write
per accepted frame replacesfivewrites. Keep budget reservation before newinput
allocation, capacitypoweroftwo withindevicecap, retired oldbuffer list<=16 with
queue callback flags/ownerrelease; newandoldbudgeted untilcallback. Failure
routes unchanged wholebatch CPUfallback; source journal/CPU snapshots unchanged.

Retained input owns one reference. BindGroup binding aliases do not own/release
that reference independently. Release drains device before freeing input,output,
texture,pipeline andretiredbuffers. No shader or packet-byte changes. Test pure
plan overflow/alignment/onebufferbindings plus exact native pixel parity and
same-device fallback/resize/lifecycle. Measure matched ordinary release native
fourcases fivealternatingpairs after focusedsource/race/headlessGPU review.
Prototype via Gooverlay; preparedsources remainunchanged untilpinnedpatch0055.
