// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"cogentcore.org/core/paint/renderers/sceneplan"
	"encoding/binary"
	"fmt"
	"image"
)

// Encoded owns bounded payload; padding additionally stays below256KiB, even
// for foreign/malformed device limits. No fonts/images/widgets are retained.
const maxPackedInputBytes = sceneplan.MaxBytes + (256 << 10)

type inputBinding struct{ offset, size uint64 }
type inputPlan struct {
	bindings [5]inputBinding
	total    uint64
}

func planInput(e *sceneplan.Encoded, size image.Point, stride uint32, alignment, maxBinding, maxBuffer uint64) (inputPlan, error) {
	var p inputPlan
	if e == nil || size.X <= 0 || size.Y <= 0 || stride == 0 || stride%4 != 0 || e.Tiles.X <= 0 || alignment == 0 || alignment%4 != 0 {
		return p, fmt.Errorf("gpuscene: invalid packed input layout")
	}
	p.bindings[0] = inputBinding{size: 16}
	p.total = 16
	padding := uint64(0)
	for i, data := range [4][]byte{e.Ops, e.Rows, e.Refs, e.Data} {
		n := uint64(len(data))
		if n < 4 || n%4 != 0 || n > maxBinding {
			return inputPlan{}, fmt.Errorf("gpuscene: input exceeds device binding limits")
		}
		pad := (alignment - p.total%alignment) % alignment
		if pad > (256<<10)-padding {
			return inputPlan{}, fmt.Errorf("gpuscene: packed padding exceeds limit")
		}
		padding += pad
		// Compare before adding, so arbitrary u64 limits cannot overflow staging.
		if p.total > maxPackedInputBytes || pad > maxPackedInputBytes-p.total || n > maxPackedInputBytes-p.total-pad {
			return inputPlan{}, fmt.Errorf("gpuscene: packed input exceeds staging limit")
		}
		p.total += pad
		p.bindings[i+1] = inputBinding{offset: p.total, size: n}
		p.total += n
	}
	if p.total > maxBuffer {
		return inputPlan{}, fmt.Errorf("gpuscene: packed input exceeds device buffer limit")
	}
	return p, nil
}

// pack copies immutable encoded bytes once. Binding ranges remain exact while
// every unused/padded byte is zero; shader data and its indexing are unchanged.
func (p inputPlan) pack(e *sceneplan.Encoded, size image.Point, stride uint32) []byte {
	data := make([]byte, p.total)
	for i, v := range [4]uint32{uint32(size.X), uint32(size.Y), stride / 4, uint32(e.Tiles.X)} {
		binary.LittleEndian.PutUint32(data[i*4:], v)
	}
	for i, src := range [4][]byte{e.Ops, e.Rows, e.Refs, e.Data} {
		copy(data[p.bindings[i+1].offset:], src)
	}
	return data
}
