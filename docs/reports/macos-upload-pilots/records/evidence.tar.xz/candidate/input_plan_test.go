// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"bytes"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"encoding/binary"
	"image"
	"math"
	"testing"
)

func TestVellumPackedInputExactBindingsAndDetachment(t *testing.T) {
	e := &sceneplan.Encoded{Ops: bytes.Repeat([]byte{1, 2, 3, 4}, 17), Rows: []byte{5, 6, 7, 8}, Refs: bytes.Repeat([]byte{9, 10, 11, 12}, 13), Data: []byte{13, 14, 15, 16, 17, 18, 19, 20}, Tiles: image.Pt(2, 3)}
	for _, alignment := range []uint64{4, 256, 512, 4096} {
		p, err := planInput(e, image.Pt(31, 45), 256, alignment, 1<<20, 1<<20)
		if err != nil {
			t.Fatal(err)
		}
		data := p.pack(e, image.Pt(31, 45), 256)
		want := [4]uint32{31, 45, 64, 2}
		for i, v := range want {
			if binary.LittleEndian.Uint32(data[i*4:]) != v {
				t.Fatal("changed shader config")
			}
		}
		used := make([]bool, len(data))
		for i := range 16 {
			used[i] = true
		}
		for i, src := range [4][]byte{e.Ops, e.Rows, e.Refs, e.Data} {
			b := p.bindings[i+1]
			if b.offset%alignment != 0 || b.size != uint64(len(src)) || !bytes.Equal(data[b.offset:b.offset+b.size], src) {
				t.Fatal("changed shader-visible bytes", alignment, i, b)
			}
			for j := b.offset; j < b.offset+b.size; j++ {
				if used[j] {
					t.Fatal("overlapping binding")
				}
				used[j] = true
			}
		}
		for i, u := range used {
			if !u && data[i] != 0 {
				t.Fatal("nonzero padding")
			}
		}
		saved := append([]byte(nil), data...)
		e.Ops[0] ^= 255
		if !bytes.Equal(data, saved) {
			t.Fatal("packing retained borrowed bytes")
		}
		e.Ops[0] ^= 255
		// Exact combined-size limit admits, one byte less refuses before packing.
		if _, err := planInput(e, image.Pt(31, 45), 256, alignment, 1<<20, p.total); err != nil {
			t.Fatal(err)
		}
		if _, err := planInput(e, image.Pt(31, 45), 256, alignment, 1<<20, p.total-1); err == nil {
			t.Fatal("combined device cap bypassed")
		}
	}
}
func TestVellumPackedInputRefusesMalformedAndHugeLimits(t *testing.T) {
	base := sceneplan.Encoded{Ops: make([]byte, 4), Rows: make([]byte, 4), Refs: make([]byte, 4), Data: make([]byte, 4), Tiles: image.Pt(1, 1)}
	for _, alignment := range []uint64{0, 3, math.MaxUint64, math.MaxUint64 - 3, 1 << 32, 8 << 20} {
		if _, err := planInput(&base, image.Pt(1, 1), 256, alignment, math.MaxUint64, math.MaxUint64); err == nil {
			t.Fatal("unbounded/invalid alignment admitted", alignment)
		}
	}
	for _, bad := range [][]byte{nil, make([]byte, 3), make([]byte, 8)} {
		e := base
		e.Data = bad
		if _, err := planInput(&e, image.Pt(1, 1), 256, 256, 4, 1<<20); err == nil {
			t.Fatal("invalid/oversized binding admitted", len(bad))
		}
	}
	e := base
	e.Ops = make([]byte, maxPackedInputBytes)
	if _, err := planInput(&e, image.Pt(1, 1), 256, 256, math.MaxUint64, math.MaxUint64); err == nil {
		t.Fatal("unbounded staging admitted")
	}
	if _, err := planInput(nil, image.Pt(1, 1), 256, 256, 1<<20, 1<<20); err == nil {
		t.Fatal("nil packet admitted")
	}
}
