//go:build !js

// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"bytes"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"errors"
	"image"
	"image/color"
	"image/draw"
	"testing"
)

func TestVellumPackedInputNativeGrowthRefusalAndRetirement(t *testing.T) {
	_, dev := nativeDevice(t)
	res := &resources{}
	defer res.release()
	blocked := false
	var ceiling uint64
	denied := errors.New("test replacement budget")
	reserve := func(n uint64) error {
		if n > ceiling && blocked {
			return denied
		}
		return nil
	}
	size := image.Pt(23, 19)
	if err := res.initialize(dev, size, reserve); err != nil {
		t.Fatal(err)
	}
	builder := sceneplan.New(image.Rectangle{Max: size})
	builder.Draw(image.Rectangle{Max: size}, image.NewUniform(color.RGBA{17, 31, 53, 255}), image.Point{}, nil, image.Point{}, draw.Src)
	packet := builder.Seal(false)
	e, ok := packet.Encode()
	if !ok {
		t.Fatal("fixture rejected")
	}
	if err := res.render(e, reserve); err != nil {
		t.Fatal(err)
	}
	old, oldBindings := res.input, res.bindings
	ceiling = res.bytes()
	blocked = true
	large := *e
	large.Data = make([]byte, 64<<10)
	copy(large.Data, e.Data)
	if err := res.uploadInput(&large, reserve); !errors.Is(err, denied) {
		t.Fatal("replacement bypassed preallocation budget", err)
	}
	if res.input != old || res.bindings != oldBindings || res.bytes() != ceiling {
		t.Fatal("budget refusal changed old owned resources")
	}
	expected := image.NewRGBA(image.Rectangle{Max: size})
	packet.Replay(expected)
	if got := readTexture(t, dev, res.texture); !bytes.Equal(got.Pix, expected.Pix) {
		t.Fatal("refusal changed previous frame")
	}
	blocked = false
	if err := res.render(&large, reserve); err != nil {
		t.Fatal(err)
	}
	if res.input == old || len(res.retired) != 1 || res.retired[0].buffer != old {
		t.Fatal("old allocation not tracked once through replacement")
	}
	dev.WaitDone()
	if err := res.render(e, reserve); err != nil {
		t.Fatal(err)
	}
	if len(res.retired) != 0 {
		t.Fatal("completed retired input retained")
	}
	if got := readTexture(t, dev, res.texture); !bytes.Equal(got.Pix, expected.Pix) {
		t.Fatal("packed binding/replacement changed pixels")
	}
	res.release()
	if res.input != nil || res.output != nil || res.texture != nil || res.pipeline != nil || len(res.retired) != 0 || res.bindings != ([5]inputBinding{}) || res.bytes() != 0 {
		t.Fatal("retirement retained resources or binding aliases")
	}
}
