// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

// Package gpuscene compiles detached scene paint batches and composites their
// exact premultiplied bytes on the window drawer's existing logical GPU device.
package gpuscene

import (
	_ "embed"
	"fmt"
	"image"
	"sync/atomic"

	"cogentcore.org/core/gpu"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"github.com/oliverbestmann/webgpu/wgpu"
)

//go:embed scene.wgsl
var shader string

// resources holds GPU handles only. All methods run inside the owning drawer's
// lease callback; retirement must never enter a Scene RC or application lock.
type resources struct {
	device   gpu.Device // borrowed handles, never released here
	size     image.Point
	stride   uint32
	output   *wgpu.Buffer
	texture  *gpu.Texture
	pipeline *wgpu.ComputePipeline
	input    *wgpu.Buffer    // one owned packed config/ops/rows/refs/data allocation
	bindings [5]inputBinding // non-owning exact ranges into input
	retired  []retiredBuffer
	ready    bool
}
type retiredBuffer struct {
	buffer *wgpu.Buffer
	done   *atomic.Bool
}

func (r *resources) release() {
	// Teardown drains queue uses, including later scene composition, before
	// retiring budget. GPU callbacks only publish flags and never enter locks.
	if r.device.Device.IsValid() && r.device.LossError() == nil {
		r.device.WaitDone()
	}
	for _, retired := range r.retired {
		retired.buffer.Release()
	}
	r.retired = nil
	if r.input != nil {
		r.input.Release()
		r.input = nil
	}
	r.bindings = [5]inputBinding{}
	if r.output != nil {
		r.output.Release()
		r.output = nil
	}
	if r.texture != nil {
		r.texture.Release()
		r.texture = nil
	}
	if r.pipeline != nil {
		r.pipeline.Release()
		r.pipeline = nil
	}
	r.device = gpu.Device{}
	r.size = image.Point{}
	r.stride = 0
	r.ready = false
}
func (r *resources) bytes() uint64 {
	var n uint64
	if r.output != nil {
		n += r.output.GetSize()
	}
	if r.input != nil {
		n += r.input.GetSize()
	}
	for _, retired := range r.retired {
		n += retired.buffer.GetSize()
	}
	if r.texture != nil {
		n += uint64(r.size.X) * uint64(r.size.Y) * 4
	}
	return n
}
func outputLayout(size image.Point) (uint32, uint64, bool) {
	if size.X <= 0 || size.Y <= 0 || size.X > sceneplan.MaxDimension || size.Y > sceneplan.MaxDimension || size.X*size.Y > sceneplan.MaxPixels {
		return 0, 0, false
	}
	stride := uint32((size.X*4 + 255) / 256 * 256)
	return stride, uint64(stride) * uint64(size.Y), true
}
func (r *resources) initialize(dev *gpu.Device, size image.Point, reserve func(uint64) error) (err error) {
	if r.output != nil || r.texture != nil || r.pipeline != nil || r.device.Device.IsValid() {
		return fmt.Errorf("gpuscene: initialization requires retired resources")
	}
	if dev == nil || !dev.Device.IsValid() || !dev.Queue.IsValid() {
		return fmt.Errorf("gpuscene: live borrowed device required")
	}
	if err = dev.LossError(); err != nil {
		return err
	}
	stride, n, valid := outputLayout(size)
	if !valid {
		return fmt.Errorf("gpuscene: source dimensions exceed limits")
	}
	limits := dev.Device.GetLimits()
	if n > limits.MaxStorageBufferBindingSize || n > limits.MaxBufferSize {
		return fmt.Errorf("gpuscene: output exceeds device buffer limits")
	}
	if err = reserve(n + uint64(size.X)*uint64(size.Y)*4); err != nil {
		return err
	}
	defer func() {
		if err != nil {
			r.release()
			_ = reserve(0)
		}
	}()
	r.device, r.size, r.stride = *dev, size, stride
	module, err := dev.Device.TryCreateShaderModule(&wgpu.ShaderModuleDescriptor{Label: "Vellum ordered scene", WGSLSource: &wgpu.ShaderSourceWGSL{Code: shader}})
	if err != nil {
		return err
	}
	defer module.Release()
	r.pipeline, err = dev.Device.TryCreateComputePipeline(&wgpu.ComputePipelineDescriptor{Label: "Vellum ordered scene", Compute: wgpu.ProgrammableStageDescriptor{Module: module, EntryPoint: "main"}})
	if err != nil {
		return err
	}
	r.output, err = dev.Device.TryCreateBuffer(&wgpu.BufferDescriptor{Label: "Vellum scene RGBA bytes", Size: n, Usage: wgpu.BufferUsageStorage | wgpu.BufferUsageCopySrc | wgpu.BufferUsageCopyDst})
	if err != nil {
		return err
	}
	r.texture = gpu.NewTexture(dev)
	r.texture.Name = "Vellum scene sampled RGBA"
	r.texture.ConfigGoImage(size, 1)
	if err = r.texture.CreateTexture(wgpu.TextureUsageTextureBinding | wgpu.TextureUsageCopyDst | wgpu.TextureUsageCopySrc); err != nil {
		return err
	}

	return reserve(r.bytes())
}

// uploadInput admits retained plus transient replacement allocation before any
// allocation. Old buffers survive failed replacement; a successful replacement
// releases only our reference (queued WebGPU work retains its own references).
func (r *resources) uploadInput(e *sceneplan.Encoded, reserve func(uint64) error) error {
	retained := r.retired[:0]
	for _, retired := range r.retired {
		if retired.done.Load() {
			retired.buffer.Release()
		} else {
			retained = append(retained, retired)
		}
	}
	clear(r.retired[len(retained):])
	r.retired = retained
	if err := reserve(r.bytes()); err != nil {
		return err
	}
	limits := r.device.Device.GetLimits()
	plan, err := planInput(e, r.size, r.stride, uint64(limits.MinStorageBufferOffsetAlignment), limits.MaxStorageBufferBindingSize, limits.MaxBufferSize)
	if err != nil {
		return err
	}
	if r.input == nil || r.input.GetSize() < plan.total {
		capacity := uint64(4)
		for capacity < plan.total {
			capacity *= 2
		}
		if capacity > limits.MaxBufferSize || len(r.retired) >= 16 {
			return fmt.Errorf("gpuscene: input replacement exceeds limits")
		}
		if err := reserve(r.bytes() + capacity); err != nil {
			return err
		}
		buffer, err := r.device.Device.TryCreateBuffer(&wgpu.BufferDescriptor{Label: "Vellum packed scene input", Size: capacity, Usage: wgpu.BufferUsageUniform | wgpu.BufferUsageStorage | wgpu.BufferUsageCopyDst})
		if err != nil {
			_ = reserve(r.bytes())
			return err
		}
		if r.input != nil {
			done := &atomic.Bool{}
			r.retired = append(r.retired, retiredBuffer{r.input, done})
			r.device.Queue.OnSubmittedWorkDone(func(status wgpu.QueueWorkDoneStatus) {
				if status == wgpu.QueueWorkDoneStatusSuccess {
					done.Store(true)
				}
			})
		}
		r.input = buffer
		if err := reserve(r.bytes()); err != nil {
			return err
		}
	}
	data := plan.pack(e, r.size, r.stride)
	if err := r.device.Queue.TryWriteBuffer(r.input, 0, data); err != nil {
		return err
	}
	r.bindings = plan.bindings
	return nil
}
func (r *resources) seed(img *image.RGBA) error {
	if img == nil || img.Bounds() != (image.Rectangle{Max: r.size}) {
		return fmt.Errorf("gpuscene: seed bounds differ")
	}
	// Only used after CPU fallback/device replacement; never an ordinary accepted
	// packet's full-image upload. Queue writes remain in submission order.
	row := make([]byte, r.stride)
	for y := 0; y < r.size.Y; y++ {
		copy(row, img.Pix[img.PixOffset(0, y):][:r.size.X*4])
		if err := r.device.Queue.TryWriteBuffer(r.output, uint64(y)*uint64(r.stride), row); err != nil {
			return err
		}
	}
	return nil
}
func (r *resources) render(e *sceneplan.Encoded, reserve func(uint64) error) error {
	if err := r.device.LossError(); err != nil {
		return err
	}
	if err := r.uploadInput(e, reserve); err != nil {
		return err
	}
	layout := r.pipeline.GetBindGroupLayout(0)
	defer layout.Release()
	entries := make([]wgpu.BindGroupEntry, 6)
	for i, binding := range r.bindings {
		entries[i] = wgpu.BindGroupEntry{Binding: uint32(i), Buffer: r.input, Offset: binding.offset, Size: binding.size}
	}
	entries[5] = wgpu.BindGroupEntry{Binding: 5, Buffer: r.output, Size: r.output.GetSize()}
	group, err := r.device.Device.TryCreateBindGroup(&wgpu.BindGroupDescriptor{Layout: layout, Entries: entries})
	if err != nil {
		return err
	}
	defer group.Release()
	encoder, err := r.device.Device.TryCreateCommandEncoder(nil)
	if err != nil {
		return err
	}
	defer encoder.Release()
	// This pinned WebGPU API has no TryBeginComputePass/Dispatch/Submit methods.
	// Checked resource creation and encoding do not claim GPU completion.
	pass := encoder.BeginComputePass(nil)
	pass.SetPipeline(r.pipeline)
	pass.SetBindGroup(0, group, nil)
	pass.DispatchWorkgroups(uint32((r.size.X+7)/8), uint32((r.size.Y+7)/8), 1)
	err = pass.TryEnd()
	pass.Release()
	if err != nil {
		return err
	}
	if err = r.texture.CopyFromBuffer(encoder, r.output, r.stride); err != nil {
		return err
	}
	command, err := encoder.TryFinish(nil)
	if err != nil {
		return err
	}
	defer command.Release()
	r.device.Queue.Submit(command)
	if err = r.device.LossError(); err != nil {
		return err
	}
	r.ready = true
	return nil
}
