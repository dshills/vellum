// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
//go:build !js

package gpu

import (
	"bytes"
	"encoding/json"
	"image"
	"os"
	"testing"

	"github.com/oliverbestmann/webgpu/wgpu"
)

// Tiny headless resources exercise the production upload followed by real
// texture-to-buffer copy/map. No native windows, input or presentation are used.
func TestVellumRGBAUploadNativeRows(t *testing.T) {
	if os.Getenv("VELLUM_TEXTURE_GPU_TEST") != "1" {
		t.Skip("explicit headless texture correctness fixture required")
	}
	var gp *GPU
	var dev *Device
	defer func() {
		if dev != nil {
			dev.Release()
		}
		if gp != nil {
			gp.Release()
		}
		ReleaseInstance()
	}()
	var err error
	gp, dev, err = NoDisplayGPU()
	if err != nil || gp == nil || dev == nil {
		t.Fatal("headless GPU unavailable", err)
	}
	parent := image.NewRGBA(image.Rect(-5, -4, 2, 2))
	for y := parent.Rect.Min.Y; y < parent.Rect.Max.Y; y++ {
		for x := parent.Rect.Min.X; x < parent.Rect.Max.X; x++ {
			i := parent.PixOffset(x, y)
			copy(parent.Pix[i:i+4], []byte{byte(x + 30), byte(y + 40), byte(x + y + 50), 255})
		}
	}
	cases := map[string]*image.RGBA{
		"parent-stride-subimage": parent.SubImage(image.Rect(-3, -2, 0, 1)).(*image.RGBA),
		"odd-padded-stride":      {Pix: []byte{10, 20, 30, 255, 9, 9, 9, 40, 50, 60, 255}, Stride: 7, Rect: image.Rect(3, 5, 4, 7)},
		"short-final-padding":    {Pix: []byte{70, 80, 90, 255, 9, 9, 9, 9, 100, 110, 120, 255}, Stride: 8, Rect: image.Rect(-2, -3, -1, -1)},
		"single-row":             {Pix: []byte{130, 140, 150, 255}, Stride: int(^uint(0) >> 1), Rect: image.Rect(2, 3, 3, 4)},
	}
	for name, source := range cases {
		t.Run(name, func(t *testing.T) {
			size := source.Rect.Size()
			want := make([]byte, size.X*size.Y*4)
			for y := range size.Y {
				for x := range size.X {
					c := source.RGBAAt(source.Rect.Min.X+x, source.Rect.Min.Y+y)
					copy(want[(y*size.X+x)*4:], []byte{c.R, c.G, c.B, c.A})
				}
			}
			tx := NewTexture(dev)
			defer tx.Release()
			tx.Format = TextureFormat{Size: size, Layers: 1, Samples: 1, Format: wgpu.TextureFormatRGBA8UnormSrgb}
			if err := tx.CreateTexture(wgpu.TextureUsageTextureBinding | wgpu.TextureUsageCopyDst | wgpu.TextureUsageCopySrc); err != nil {
				t.Fatal(err)
			}
			if err := tx.SetFromGoImage(source, 0); err != nil {
				t.Fatal("production upload refused valid RGBA rows", err)
			}
			// The immediate queue write consumes bytes; later caller mutation must
			// not change the enqueued upload, even before the copy is submitted.
			for i := range source.Pix {
				source.Pix[i] = 0
			}
			if err := tx.ConfigReadBuffer(); err != nil {
				t.Fatal(err)
			}
			cmd, err := dev.Device.TryCreateCommandEncoder(nil)
			if err != nil {
				t.Fatal(err)
			}
			defer cmd.Release()
			if err := tx.CopyToReadBuffer(cmd); err != nil {
				t.Fatal(err)
			}
			buffer, err := cmd.TryFinish(nil)
			if err != nil {
				t.Fatal(err)
			}
			defer buffer.Release()
			dev.Queue.Submit(buffer)
			got, err := tx.ReadGoImage()
			if err != nil || got == nil || got.Rect != image.Rect(0, 0, size.X, size.Y) || !bytes.Equal(got.Pix, want) {
				t.Fatalf("RGBA upload row readback differs: error=%v got=%v want=%v", err, got, want)
			}
			if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "vellum.rgba-upload.native", "case": name, "pixels": size.X * size.Y, "source_stride": source.Stride, "pixels_match": true, "post_upload_source_mutation_isolated": true, "windows_created": 0}); err != nil {
				t.Fatal(err)
			}
		})
	}
}
