from pathlib import Path
import hashlib, json, subprocess

R = Path('/private/tmp/vellum-rgba-upload')
P = Path('/private/tmp/vellum-macos-rgba-upload')
def sha(f): return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(n): return json.loads((P/n).read_text())

adopt = read('adoption.json')
before, after = read('prepared-baseline.json'), read('prepared-final.json')
assert len(before) == 6211 and len(after) == 6214
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip() == adopt['base_commit']
review = read('candidate-review.json')
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
assert all(sha(P/n) == h for n,h in review['candidate_files'].items())
assert all(after['upstream/'+n] == h for n,h in adopt['outputs'].items())
assert all(sha(R/'drivers/cogent/build'/n) == h for n,h in after.items())
changed = {'upstream/'+n for n in adopt['outputs']}
assert {n:h for n,h in before.items() if n not in changed} == {n:h for n,h in after.items() if n not in changed}
names = sorted(set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines()) | set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()))
assert len(names) == 8
code = {n:sha(R/n) for n in names if n.startswith('drivers/')}
checks = {}
for name in ['final-preparation-tests','final-prepare','final-gpu-race','final-gpu-vet','final-headless-texture','final-adapter-race','final-adapter-vet','final-native-build']:
    d = read(name+'.json')
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable'], name
    assert d['source_commit'] == adopt['base_commit']
    assert all(d['source_delta_before'][n] == d['source_delta_after'][n] == h for n,h in code.items()), name
    assert d['overlay_inputs_before'] == d['overlay_inputs_after'] == {}
    if name == 'final-preparation-tests': assert d['prepared_before'] == d['prepared_after'] == before
    else: assert d['prepared_before'] == (before if name == 'final-prepare' else after) and d['prepared_after'] == after
    producer = P/('code_run_v1.py' if name in ['final-preparation-tests','final-prepare'] else 'code_run.py')
    assert d['producer_sha256'] == sha(producer)
    for c in ['stdout','stderr']: assert d[c+'_sha256'] == sha(P/(name+'.'+c))
    checks[name] = {'receipt_sha256':sha(P/(name+'.json')), 'argv':d['argv'], 'elapsed_seconds':d['elapsed_seconds'], 'uses_real_prepared_dependencies':name != 'final-preparation-tests'}
records = [json.loads(l) for l in (P/'final-headless-texture.stdout').read_text().splitlines() if l.startswith('{')]
ends = [r for r in records if r.get('Test') and r.get('Action') in ['pass','fail','skip']]
roots = [r for r in ends if '/' not in r['Test']]
assert {r['Test'] for r in roots} == {'TestVellumRGBAUploadNativeRows','TestVellumTextureNativeOwnershipAndReadback'}
assert all(r['Action'] == 'pass' for r in ends)
native = [json.loads(r['Output']) for r in records if '"event":"vellum.rgba-upload.native"' in r.get('Output','')]
assert len(native) == 4 and all(r['pixels_match'] and r['post_upload_source_mutation_isolated'] and r['windows_created'] == 0 for r in native)
fault = read('rgba-headless-stride-fault.json')
assert fault['exit_code'] == 1 and fault['error'] is None and fault['source_delta_stable']
fault_records = [json.loads(l) for l in (P/'rgba-headless-stride-fault.stdout').read_text().splitlines() if l.startswith('{')]
failed = [r['Test'].split('/',1)[1] for r in fault_records if r.get('Action') == 'fail' and '/' in r.get('Test','')]
assert set(failed) == {'parent-stride-subimage','odd-padded-stride','short-final-padding'}
assert any(r.get('Test') == 'TestVellumRGBAUploadNativeRows/single-row' and r.get('Action') == 'pass' for r in fault_records)
for c in ['stdout','stderr']: assert fault[c+'_sha256'] == sha(P/('rgba-headless-stride-fault.'+c))
binary = read('native-binary.json')
assert binary['produced_file_sha256'] == sha(P/'gallery') and binary['binary_launched'] is False
report = R/'docs/reports/macos-rgba-upload/README.md'
s = report.read_text()
old = 'Normal preparation, final integration gates and checkpoint reviews remain pending.'
assert old in s
report.write_text(s.replace(old, '''Normal preparation reproduces the four pinned outputs: 6,211 to 6,214 dependency
leaves, with every other leaf unchanged. Eight final code/build gates pass:
preparation tests, regeneration, full GPU-package race/vet, both native texture
roots with no skipped tests, full adapter race/vet and native Gallery build.
Preparation unit tests use mocked installations and stable pre-regeneration
snapshots; runtime tests separately bind the complete regenerated tree. The
native Gallery binary is built but was not launched. Final internal source and
evidence review and one bounded Anthropic Claude Sonnet 5.5 Prism review precede
commit.'''))
sources = {n:sha(R/n) for n in names}
manifest = {'base_commit':adopt['base_commit'], 'sources':sources}
(P/'checkpoint-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary = {**manifest,'result':'PASS_SCOPED_RGBA_UPLOAD_ROWS','checks':checks,'prepared_before_files':6211,'prepared_after_files':6214,'all_other_dependency_leaves_unchanged':True,'seeded_layout_cases':600,'native_row_cases_passed':4,'native_texture_roots_passed':2,'native_fault_cases_failed':3,'windows_created':0,'native_binary_launched':False,'native_build_sha256':sha(P/'gallery'),'frame_performance_gain_qualified':False,'image_composition_geometry_qualified':False,'physical_gpu_memory_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'mac_distribution_qualified':False}
(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS eight code/build gates, two native texture roots and three detected row faults; eight sources bound')
