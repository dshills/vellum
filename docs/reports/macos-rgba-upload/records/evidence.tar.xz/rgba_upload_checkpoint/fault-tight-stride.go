// Copyright (c) 2024, Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gpu

import (
	"fmt"
	"image"

	"cogentcore.org/core/base/errors"
	"cogentcore.org/core/base/iox/imagex"
	"cogentcore.org/core/base/slicesx"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// Texture represents a WebGPU Texture with an associated TextureView.
// The WebGPU Texture is in device memory, in an optimized format.
type Texture struct {
	// Name of the texture, e.g., same as Value name if used that way.
	// This is helpful for debugging. Is auto-set to filename if loaded from
	// a file and otherwise empty.
	Name string

	// Format & size of texture
	Format TextureFormat

	// Sampler defines how the texture is sampled on the GPU.
	// Needed for textures used as fragment shader inputs.
	Sampler Sampler

	// indicates that this texture is shared with some other
	// resource, and therefore should not be released when done.
	// Use SetShared method to set texture in this way.
	shared bool

	// WebGPU texture handle, in device memory
	texture *wgpu.Texture `display:"-"`

	// WebGPU texture view -- needed for most textures
	view *wgpu.TextureView `display:"-"`

	// keep track of device for destroying view
	device Device `display:"-"`

	// readBuffer is an optional buffer for reading the contents of a texture
	readBuffer *wgpu.Buffer

	// current size of the readBuffer
	ReadBufferDims TextureBufferDims
}

func NewTexture(dev *Device) *Texture {
	tx := &Texture{}
	tx.device = *dev
	tx.Format.Defaults()
	return tx
}

// ConfigGoImage configures the texture for storing an texture
// of the given size. Texture format will be set to default
// unless format is already set.  Layers is number of separate textures
// of given size allocated in a texture array.
func (tx *Texture) ConfigGoImage(sz image.Point, layers int) {
	if tx.Format.Format != wgpu.TextureFormatRGBA8UnormSrgb {
		tx.Format.Defaults()
	}
	tx.Format.Size = sz
	if layers <= 0 {
		layers = 1
	}
	tx.Format.Layers = layers
}

// SetFromGoImage sets texture data from a standard Go texture at given layer.
// This is most efficiently done using an texture.RGBA, but other
// formats will be converted as necessary.
// This starts the full WriteTexture call to upload to device.
func (tx *Texture) SetFromGoImage(img image.Image, layer int) error {
	// A recycled drawer Value may still borrow its last owner's texture.
	// Detach even for an identical format; never upload into borrowed storage.
	if tx.shared {
		tx.ReleaseTexture()
	}
	if !tx.device.Device.IsValid() || !tx.device.Queue.IsValid() {
		return fmt.Errorf("gpu.Texture.SetFromGoImage: live device and queue required")
	}
	if img == nil {
		return fmt.Errorf("gpu.Texture.SetFromGoImage: nil image")
	}
	rimg := imagex.AsRGBA(img)
	sz, pixels, _, err := rgbaTextureUpload(rimg)
	if err != nil {
		return err
	}

	nfmt := TextureFormat{Size: sz, Format: wgpu.TextureFormatRGBA8UnormSrgb, Layers: 1, Samples: 1}

	if !tx.texture.IsValid() || !tx.view.IsValid() || tx.Format != nfmt || tx.texture.GetUsage()&(wgpu.TextureUsageTextureBinding|wgpu.TextureUsageCopyDst) != (wgpu.TextureUsageTextureBinding|wgpu.TextureUsageCopyDst) {
		tx.Format = nfmt
		err := tx.CreateTexture(wgpu.TextureUsageTextureBinding | wgpu.TextureUsageCopyDst)
		if err != nil { // already logged
			return err
		}
	}

	size := tx.Format.Extent3D()

	// https://www.w3.org/TR/webgpu/#gpuimagecopytexture
	return tx.device.Queue.TryWriteTexture(
		&wgpu.TexelCopyTextureInfo{
			Aspect:   wgpu.TextureAspectAll,
			Texture:  tx.texture,
			MipLevel: 0,
			Origin:   wgpu.Origin3D{X: 0, Y: 0, Z: 0},
		},
		pixels,
		&wgpu.TexelCopyBufferLayout{
			Offset:       0,
			BytesPerRow:  4 * uint32(sz.X),
			RowsPerImage: uint32(sz.Y),
		},
		&size,
	)
}

// CreateTexture creates the texture based on current settings,
// and a view of that texture.  Calls release first.
func (tx *Texture) CreateTexture(usage wgpu.TextureUsage) error {
	tx.ReleaseTexture()
	if !tx.device.Device.IsValid() || !tx.device.Queue.IsValid() {
		return fmt.Errorf("gpu.Texture.CreateTexture: live device and queue required")
	}

	size := tx.Format.Extent3D()
	t, view, err := createTexturePair(func() (*wgpu.Texture, error) {
		return tx.device.Device.TryCreateTexture(&wgpu.TextureDescriptor{
			Label:         tx.Name,
			Size:          size,
			MipLevelCount: 1,
			SampleCount:   uint32(tx.Format.Samples),
			Dimension:     wgpu.TextureDimension2D,
			Format:        tx.Format.Format,
			Usage:         usage,
		})
	}, func(texture *wgpu.Texture) (*wgpu.TextureView, error) {
		return texture.TryCreateView(nil)
	})
	if errors.Log(err) != nil {
		return err
	}
	tx.texture, tx.view, tx.shared = t, view, false
	return nil
}

// https://eliemichel.github.io/LearnWebGPU/advanced-techniques/headless.html

// ConfigRenderTexture configures this texture as a render texture
// using format.  Sets multisampling to 1, layers to 1.
func (tx *Texture) ConfigRenderTexture(dev *Device, imgFmt *TextureFormat) error {
	if dev == nil || imgFmt == nil {
		return fmt.Errorf("gpu.Texture.ConfigRenderTexture: device and format required")
	}
	nfmt := *imgFmt
	nfmt.SetMultisample(1)
	if tx.reusableConfiguration(dev, nfmt, wgpu.TextureUsageRenderAttachment|wgpu.TextureUsageCopySrc|wgpu.TextureUsageTextureBinding) {
		return nil
	}
	tx.configureDevice(dev)
	tx.Format = nfmt
	return tx.CreateTexture(wgpu.TextureUsageRenderAttachment | wgpu.TextureUsageCopySrc | wgpu.TextureUsageTextureBinding)
}

// ConfigDepth configures this texture as a depth texture
// using given depth texture format, and other format information
// from the given render texture format.
// If current texture is identical format, does not recreate.
func (tx *Texture) ConfigDepth(dev *Device, depthType Types, imgFmt *TextureFormat) error {
	if dev == nil || imgFmt == nil {
		return fmt.Errorf("gpu.Texture.ConfigDepth: device and format required")
	}
	nfmt := *imgFmt
	nfmt.Format = depthType.TextureFormat()
	if tx.reusableConfiguration(dev, nfmt, wgpu.TextureUsageRenderAttachment|wgpu.TextureUsageCopySrc) {
		return nil
	}
	tx.configureDevice(dev)
	tx.Format = nfmt
	return tx.CreateTexture(wgpu.TextureUsageRenderAttachment | wgpu.TextureUsageCopySrc)
}

// ConfigMulti configures this texture as a mutisampling texture
// using format.
func (tx *Texture) ConfigMulti(dev *Device, imgFmt *TextureFormat) error {
	if dev == nil || imgFmt == nil {
		return fmt.Errorf("gpu.Texture.ConfigMulti: device and format required")
	}
	nfmt := *imgFmt
	if tx.reusableConfiguration(dev, nfmt, wgpu.TextureUsageRenderAttachment) {
		return nil
	}
	tx.configureDevice(dev)
	tx.Format = nfmt
	return tx.CreateTexture(wgpu.TextureUsageRenderAttachment)
}

// SetShared sets this texture to point to the given Texture's
// underlying GPU texture, with the shared flag set so that
// it will not be released.
func (tx *Texture) SetShared(ot *Texture) {
	tx.ReleaseTexture()
	tx.texture = ot.texture
	tx.view = ot.view
	tx.shared = true
	tx.Format = ot.Format
}

// ReleaseView destroys any existing view
func (tx *Texture) ReleaseView() {
	if tx.view == nil {
		return
	}
	if !tx.shared {
		tx.view.Release()
	}
	tx.view = nil
}

// ReleaseTexture frees device memory version of texture that we own
func (tx *Texture) ReleaseTexture() {
	tx.ReleaseView()
	texture, shared := tx.texture, tx.shared
	tx.texture, tx.shared = nil, false
	if texture != nil && !shared {
		texture.Release()
	}
}

// Release destroys any existing view, nils fields
func (tx *Texture) Release() {
	tx.ReleaseTexture()
	tx.Sampler.Release()
	if tx.readBuffer != nil {
		tx.readBuffer.Release()
		tx.readBuffer = nil
	}
	tx.ReadBufferDims = TextureBufferDims{}
}

///////////////////////////////////////////////////////////////
// 	ReadBuffer

// ConfigReadBuffer configures the [readBuffer] for this Texture.
// Must have this in place prior to render pass with a
// [CopyToReadBuffer] command added to it.
func (tx *Texture) ConfigReadBuffer() error {
	dims, err := textureReadLayout(tx.Format)
	if err != nil {
		return err
	}
	if !tx.device.Device.IsValid() || !tx.device.Queue.IsValid() {
		return fmt.Errorf("gpu.Texture.ConfigReadBuffer: live device and queue required")
	}
	return errors.Log(replaceReadBuffer(&tx.readBuffer, &tx.ReadBufferDims, dims, func() (*wgpu.Buffer, error) {
		return tx.device.Device.TryCreateBuffer(&wgpu.BufferDescriptor{
			Size: dims.PaddedSize(), Usage: wgpu.BufferUsageMapRead | wgpu.BufferUsageCopyDst,
		})
	}))
}

// CopyToReadBuffer adds a command to the given command encoder
// to copy this texture to its [readBuffer]. Must have called
// [ConfigReadBuffer] prior to start of render pass for this to work.
func (tx *Texture) CopyToReadBuffer(cmd *wgpu.CommandEncoder) error {
	dims, err := textureReadLayout(tx.Format)
	if err != nil {
		return err
	}
	if tx.ReadBufferDims != dims || !tx.readBuffer.IsValid() {
		return fmt.Errorf("gpu.Texture.CopyToReadBuffer: configure matching read buffer before encoding")
	}
	return tx.CopyToBuffer(cmd, tx.readBuffer, uint32(dims.PaddedRowSize))
}

// ReadGoImage reads the GPU-resident Texture and returns
// a Go image.NRGBA image of the texture.
func (tx *Texture) ReadGoImage() (*image.NRGBA, error) {
	var data []byte
	err := tx.ReadData(&data, true)
	if err != nil {
		return nil, err
	}
	normalizeReadImageChannels(data, tx.Format.Format)
	img := &image.NRGBA{
		Pix:    data,
		Stride: int(tx.ReadBufferDims.UnpaddedRowSize), // note: this is actually unpadded here
		Rect:   image.Rect(0, 0, int(tx.ReadBufferDims.Width), int(tx.ReadBufferDims.Height)),
	}
	return img, nil
}

// ReadData reads the data from a GPU-resident Texture,
// setting the given data bytes, which will be resized to fit
// the data. If removePadding is true, then extra padding will be
// removed, if present.
func (tx *Texture) ReadData(data *[]byte, removePadding bool) error {
	ud, err := tx.ReadDataMapped()
	if err != nil {
		return err
	}
	if !removePadding || tx.ReadBufferDims.HasNoPadding() {
		buffSize := tx.ReadBufferDims.PaddedSize()
		*data = slicesx.SetLength(*data, int(buffSize))
		copy(*data, ud)
		tx.UnmapReadData()
		return nil
	}
	dataSize := tx.ReadBufferDims.UnpaddedSize()
	*data = slicesx.SetLength(*data, int(dataSize))
	dims := tx.ReadBufferDims
	for r := range dims.Height {
		dStart := r * dims.UnpaddedRowSize
		dEnd := dStart + dims.UnpaddedRowSize
		sStart := r * dims.PaddedRowSize
		sEnd := sStart + dims.UnpaddedRowSize
		copy((*data)[dStart:dEnd], ud[sStart:sEnd])
	}
	tx.UnmapReadData()
	return nil
}

// ReadDataMapped reads the data from a GPU-resident Texture,
// returning the bytes as mapped from the readBuffer,
// so they must be used immediately, followed by an [UnmapReadData]
// call to unmap the data. See [ReadData] for a version that copies
// the data into a bytes slice, which is safe for indefinite use.
// There is alignment padding as reflected in the
// [ReadBufferDims] data.
func (tx *Texture) ReadDataMapped() ([]byte, error) {
	dims, err := textureReadLayout(tx.Format)
	if err != nil {
		return nil, err
	}
	if !tx.readBuffer.IsValid() || tx.ReadBufferDims != dims || !tx.device.Device.IsValid() || !tx.device.Queue.IsValid() {
		return nil, fmt.Errorf("gpu.Texture.ReadDataMapped: live matching read buffer and device required; configure and copy before reading")
	}
	buffSize := dims.PaddedSize()

	err = BufferReadSync(&tx.device, int(buffSize), tx.readBuffer)
	if errors.Log(err) != nil {
		return nil, err
	}
	return tx.readBuffer.GetMappedRange(0, uint(buffSize)), nil
}

// UnmapReadData unmaps the data from a prior ReadDataMapped call.
func (tx *Texture) UnmapReadData() error {
	if tx.readBuffer == nil {
		return errors.Log(errors.New("gpu.Texture.UnmapReadData: buffer is nil"))
	}
	tx.readBuffer.Unmap()
	return nil
}
