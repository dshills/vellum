// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
	"bytes"
	"image"
	"math/rand"
	"testing"
)

func TestVellumRGBAUploadSubimageRows(t *testing.T) {
	parent := image.NewRGBA(image.Rect(-5, -4, 2, 2))
	for y := parent.Rect.Min.Y; y < parent.Rect.Max.Y; y++ {
		for x := parent.Rect.Min.X; x < parent.Rect.Max.X; x++ {
			i := parent.PixOffset(x, y)
			copy(parent.Pix[i:i+4], []byte{byte(x + 10), byte(y + 10), byte(x + y + 20), 255})
		}
	}
	sub := parent.SubImage(image.Rect(-3, -2, 0, 1)).(*image.RGBA)
	size, data, stride, err := rgbaTextureUpload(sub)
	if err != nil || size != image.Pt(3, 3) || stride != 28 || len(data) != 68 {
		t.Fatalf("subimage layout: size=%v stride=%d bytes=%d error=%v", size, stride, len(data), err)
	}
	for y := range size.Y {
		for x := range size.X {
			c := sub.RGBAAt(sub.Rect.Min.X+x, sub.Rect.Min.Y+y)
			got := data[y*int(stride)+x*4:][:4]
			if !bytes.Equal(got, []byte{c.R, c.G, c.B, c.A}) {
				t.Fatalf("row=%d col=%d: %v", y, x, got)
			}
		}
	}
	data[0] ^= 1
	if data[0] != sub.Pix[0] {
		t.Fatal("upload description unexpectedly copied borrowed input")
	}
}

func TestVellumRGBAUploadSeededLayouts(t *testing.T) {
	rng := rand.New(rand.NewSource(61))
	for n := range 600 {
		w, h := 1+rng.Intn(31), 1+rng.Intn(19)
		stride := 4*w + rng.Intn(24)
		need := (h-1)*stride + 4*w
		pixels := make([]byte, need+rng.Intn(8))
		_, _ = rng.Read(pixels)
		x, y := rng.Intn(201)-100, rng.Intn(201)-100
		img := &image.RGBA{Pix: pixels, Stride: stride, Rect: image.Rect(x, y, x+w, y+h)}
		size, data, rowStride, err := rgbaTextureUpload(img)
		wantStride := stride
		if h == 1 {
			wantStride = 4 * w
		}
		if err != nil || size != image.Pt(w, h) || int(rowStride) != wantStride || len(data) != need {
			t.Fatalf("case=%d dimensions=%dx%d stride=%d: %v %d %d %v", n, w, h, stride, size, rowStride, len(data), err)
		}
		for row := range h {
			for col := range w {
				c := img.RGBAAt(x+col, y+row)
				i := row*int(rowStride) + 4*col
				if !bytes.Equal(data[i:i+4], []byte{c.R, c.G, c.B, c.A}) {
					t.Fatalf("case=%d row=%d col=%d", n, row, col)
				}
			}
		}
	}
}

func TestVellumRGBAUploadRefusesMalformedStorage(t *testing.T) {
	maxInt := int(^uint(0) >> 1)
	minInt := -maxInt - 1
	for name, img := range map[string]*image.RGBA{
		"reversed-overflow": {Pix: make([]byte, 4), Stride: 4, Rect: image.Rectangle{Min: image.Pt(maxInt, 0), Max: image.Pt(minInt, 1)}},
		"nil":               nil,
		"empty":             {},
		"negative-size":     {Pix: make([]byte, 4), Stride: 4, Rect: image.Rectangle{Max: image.Pt(-1, 1)}},
		"row-overflow":      {Pix: make([]byte, 4), Stride: maxInt, Rect: image.Rect(0, 0, maxInt, 1)},
		"short-stride":      {Pix: make([]byte, 8), Stride: 3, Rect: image.Rect(0, 0, 1, 2)},
		"short-first-row":   {Pix: make([]byte, 3), Stride: 4, Rect: image.Rect(0, 0, 1, 1)},
		"short-final-row":   {Pix: make([]byte, 15), Stride: 8, Rect: image.Rect(0, 0, 2, 2)},
		"span-overflow":     {Pix: make([]byte, 8), Stride: maxInt, Rect: image.Rect(0, 0, 1, maxInt)},
	} {
		t.Run(name, func(t *testing.T) {
			if size, data, stride, err := rgbaTextureUpload(img); err == nil || size != (image.Point{}) || data != nil || stride != 0 {
				t.Fatalf("malformed input accepted: %v %v %d %v", size, data, stride, err)
			}
		})
	}
	img := &image.RGBA{Pix: []byte{1, 2, 3, 255}, Stride: maxInt, Rect: image.Rect(0, 0, 1, 1)}
	if _, data, stride, err := rgbaTextureUpload(img); err != nil || stride != 4 || len(data) != 4 {
		t.Fatal("unused single-row stride was narrowed", stride, err)
	}
}
