// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
	"fmt"
	"image"
	"math"
)

// rgbaTextureUpload describes borrowed pixels consumed by the immediate queue
// write. RGBA subimages retain their parent's row stride; their Pix begins at
// Rect.Min, and the final row need not include its trailing padding.
func rgbaTextureUpload(img *image.RGBA) (image.Point, []byte, uint32, error) {
	if img == nil {
		return image.Point{}, nil, 0, fmt.Errorf("gpu.Texture.SetFromGoImage: nil RGBA image")
	}
	if img.Rect.Empty() {
		return image.Point{}, nil, 0, fmt.Errorf("gpu.Texture.SetFromGoImage: empty or reversed RGBA bounds")
	}
	size := img.Rect.Size()
	if size.X <= 0 || size.Y <= 0 || size.X > int(^uint(0)>>1)/4 || uint64(size.X) > math.MaxUint32/4 || uint64(size.Y) > math.MaxUint32 {
		return image.Point{}, nil, 0, fmt.Errorf("gpu.Texture.SetFromGoImage: invalid RGBA dimensions")
	}
	rowBytes := size.X * 4
	if img.Stride < rowBytes || len(img.Pix) < rowBytes {
		return image.Point{}, nil, 0, fmt.Errorf("gpu.Texture.SetFromGoImage: invalid RGBA row storage")
	}
	stride := img.Stride
	if size.Y == 1 {
		// No inter-row offset is used; avoid narrowing an arbitrary unused stride.
		stride = rowBytes
	}
	if uint64(stride) > math.MaxUint32 || size.Y > 1 && stride > (len(img.Pix)-rowBytes)/(size.Y-1) {
		return image.Point{}, nil, 0, fmt.Errorf("gpu.Texture.SetFromGoImage: incomplete RGBA pixel storage")
	}
	end := rowBytes + (size.Y-1)*stride // Checked against len(Pix) before multiplication.
	return size, img.Pix[:end], uint32(stride), nil
}
