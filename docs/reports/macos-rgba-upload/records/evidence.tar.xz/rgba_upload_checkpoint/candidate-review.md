APPROVED_SOURCE. No unresolved findings.

The upload now uses checked RGBA row stride and exact required storage, including nonzero-origin subimages and an unpadded final row. Division bounds precede last-row multiplication. Shared-slot/device/usage order remains unchanged and input is borrowed only through the immediate write.

RGBA-UPLOAD-01 is resolved by rejecting empty/reversed endpoints before Rect.Size; the directly constructed extreme-bound regression covers the wrapping case. Pure pixel oracles and four proposed headless readback cases are meaningful; all remain unexecuted. Pinned queue API excludes256-byte row alignment, while actual odd-stride backend acceptance still needs its explicit fixture.

No native, performance, memory, or full Mac acceptance is approved. Exact four candidate, original/current source and support hashes are in candidate-review.json.
