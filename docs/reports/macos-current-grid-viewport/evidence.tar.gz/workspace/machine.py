from pathlib import Path
import importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('viewport_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
O=b.P/'machine';O.mkdir();commands={'cpu':['sysctl','-n','machdep.cpu.brand_string'],'ram':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'arch':['uname','-m'],'display_gpu':['system_profiler','SPDisplaysDataType','-json'],'power':['pmset','-g','custom']};d={}
for name,argv in commands.items():
 start=time.monotonic()
 with(O/(name+'.stdout')).open('xb')as out,(O/(name+'.stderr')).open('xb')as err:r=b.run_child(argv,env=b.child_environment(False),stdout=out,stderr=err,timeout=20,log_limit_bytes=2<<20)
 d[name]=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,logs={n:dict(bytes=(O/(name+'.'+n)).stat().st_size,sha256=b.sha(O/(name+'.'+n)))for n in ['stdout','stderr']});assert r.returncode==0
(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(result='PASS_READ_ONLY_MACHINE_METADATA',commands=len(d),native_window_created=False,settings_changed=False)))
