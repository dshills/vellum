"""Independently revalidate all current native records and paired workload geometry."""
from pathlib import Path
import importlib.util,json,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('current_viewport_run',W/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);P=r.P;sha=r.sha
read=r.read;need=r.need
review=r.load_review();need(r.approved_stable(review),'approved analysis inputs');need(r.build.identity()==read(P/'build/source.json'),'analysis source state')
need(not(W/'analysis.json').exists(),'analysis output already exists')
cases={};records={};groups={}
for name in r.ORDER:
 receipt,raw,receipt_sha=r.saved_case(name,review);validation=receipt['validation'];records[name]=raw
 mode,height,_,rows=name.split('-');group=f'{mode}-{height}-{rows}';groups.setdefault(group,[]).append(raw[2:-1]);cases[name]=dict(receipt_sha256=receipt_sha,native_window=validation['native_window'],ui_work_ns=validation['ui_work_ns'],warm_target_met=validation['warm_target_met'],seconds=receipt['seconds'])
pairs={}
for repeat in range(1,6):
 for mode in ['cpu','gpu']:
  for height in ['fixed','variable']:
   a,b=[f'{mode}-{height}-r{repeat}-{rows}'for rows in [10000,1000000]]
   need(cases[a]['native_window']==cases[b]['native_window'],'native pair '+a)
   r.benchmark.compare_geometry(records[a][2:-1],records[b][2:-1]);need(all(x['geometry']==y['geometry']for x,y in zip(records[a][2:-1],records[b][2:-1])),'full grid pair '+a)
   pairs[f'{mode}-{height}-r{repeat}']=dict(samples=120,native_and_full_grid_geometry_equal=True,million_to_10k_p95_ratio=cases[b]['ui_work_ns']['p95']/cases[a]['ui_work_ns']['p95'])
summary={group:dict(timings_ns=r.benchmark.summarize(runs))for group,runs in groups.items()}
result=dict(status='CURRENT_ORDINARY_RECORDS_VALIDATED',cases=cases,groups=summary,pairs=pairs,total_processes=40,total_samples=4800,geometry_pairs=2400,warm_target_met=r.benchmark.warm_target_met(summary),individual_processes_failing_p95=sum(c['ui_work_ns']['p95']>4000000 for c in cases.values()),individual_processes_failing_p99=sum(c['ui_work_ns']['p99']>6000000 for c in cases.values()),analyzer_sha256=sha(__file__),readiness_sha256=review['_receipt_sha256'],source_sha256=sha(P/'build/source.json'),old_results_requalified=False,algorithmic_speedup_established=False,physical_input_verified=False,gpu_execution_verified=False,native_gpu_memory_qualified=False,full_macos_qualified=False)
need(r.approved_stable(review),'analysis inputs changed')
with(W/'analysis.json').open('x')as output:output.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['status','total_processes','total_samples','geometry_pairs','warm_target_met','individual_processes_failing_p95','individual_processes_failing_p99']}))
