"""Package reviewed current-viewport measurements; no process, settings or UI actions."""
from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-current-viewport-native-23ea03f');CHECKS=Path('/private/tmp/vellum-current-viewport-checks');D=T/'docs/reports/macos-current-grid-viewport'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
a=read(W/'analysis.json');review=read(W/'result-review.json');assert review['result_accepted']and not review['unresolved_findings'];assert (P/'stop-live').exists()
assert a['status']=='CURRENT_ORDINARY_RECORDS_VALIDATED'and a['total_processes']==40 and a['total_samples']==4800 and a['geometry_pairs']==2400 and not a['warm_target_met']
source=read(W/'source-review.json');assert source['source_ready']and not source['unresolved_findings'];sources=read(W/'native-readiness.json')['sources'];assert len(sources)==6 and all(sha(T/n)==h for n,h in sources.items())
members={};excluded={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file()or'__pycache__'in p.parts:continue
  name=label+p.relative_to(root).as_posix()
  if p.name=='loadedgrid'and p.parent.name=='MacOS':excluded[name]=dict(sha256=sha(p),bytes=p.stat().st_size,reason='compiled executable excluded; exact source/build/runtime hashes retained');continue
  members[name]=p
add('workspace/',W);add('native/',P);add('checks/',CHECKS)
for n in sources:members['source/'+n]=T/n
for n,p in {'owned-native-runner.py':W.parent/'macos-grid-native-stacks/run.py','owned-native-build.py':W.parent/'macos-grid-native-stacks/build.py','live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),'child_process.py':T/'scripts/child_process.py','sdk_environment.py':T/'scripts/sdk_environment.py'}.items():members['shared/'+n]=p
assert len(members)<260
expanded=sum(p.stat().st_size for p in members.values());assert expanded<24<<20
D.mkdir();manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},excluded_executables=excluded,count=len(members),expanded_bytes=expanded)
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,p in members.items():
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();assert len(entries)==len(members)
 for e in entries:assert e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256']
result=dict(status='REVIEWED_CURRENT_GRID_VIEWPORT_MEASUREMENTS',tested_source_base_commit='23ea03fc70febdd1a8dd9f32e02cc482a32bfb72',tested_source_state='Exact six dirty fixture/parser/test/spec files on committed framework; optimized CGO build, no race or overlays. Not a clean rebuilt commit or release binary.',sources=sources,build=read(P/'build/receipt.json'),analysis=a,review=dict(source_sha256=sha(W/'source-review.json'),readiness_sha256=sha(W/'native-readiness.json'),result_sha256=sha(W/'result-review.json'),provider_calls_this_phase=0,provider_basis='Fixture metadata and parser validation checkpoint reviewed internally; latest shipping sizing implementation already reviewed once with Prism Anthropic Claude Sonnet 5.5 in preceding checkpoint.'),tests={n:read(CHECKS/n/'receipt.json')for n in ['python','go','vet']},evidence=dict(file='evidence.tar.gz',sha256=sha(D/'evidence.tar.gz'),compressed_bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded,manifest_sha256=sha(D/'evidence.manifest.json')),full_macos_qualified=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for group,d in a['groups'].items():
 mode,height,count=group.split('-');timing=d['timings_ns']['ui_work_ns'];pooled=timing['pooled'];rows.append(f"| {'CPU'if mode=='cpu'else'GPU requested'} | {height} | {int(count):,} | {pooled['p95']/1e6:.3f} | {pooled['p99']/1e6:.3f} | {statistics.median(x['p95']for x in timing['per_run'])/1e6:.3f} |")
(D/'README.md').write_text('''# Current native grid viewport measurements — macOS

The current ordinary stored-table workload still misses its unchanged 4 ms p95 /
6 ms p99 UI-work target. All 40 native processes completed valid measurements;
all 40 failed p95 and 32 failed p99. Successful collection does not qualify the
performance gate. P6, P11 and full macOS completion remain open.

The fixture now records actual native window geometry after warm-up and after
measurement. Native queries wait for main-queue publication and run on main;
geometry is copied under the native lock outside measured work. The consumer
refuses partial or changed endpoints, invalid extents, grid clips outside render
or DPI/scale mismatch. Historical records without this guard retain their old
scope. This checkpoint changes fixture observation, validation, tests and specs;
shipping framework implementation and timing regions are unchanged.

## Observed workload and results

An optimized CGO build from base `23ea03fc70febdd1a8dd9f32e02cc482a32bfb72`
plus six exact fixture/parser/test/spec changes ran without overlays, race or
profiling instrumentation. Its original dirty VCS metadata, complete source and
prepared-file hashes, binary hash and launch arguments are preserved. The tested
binary is not relabeled as a clean build of this later checkpoint.

The requested initial client was 1500 × 1250 Dp. Observed native client and render
were 1519 × 1266 pixels on LG HDR DQHD, screen 0, 5120 × 1440, logical DPI 162,
DPR 1. Window-manager client units were also 1519 × 1266. The intended 768 × 624
logical grid viewport rounded to an observed 767 × 624; initial grid bounds were
(9, 32)–(1325, 1106) at scale 1.6875. The required minimum 400 clipped cells,
50 rows and eight columns was maintained. Native endpoint geometry and complete
per-sample grid geometry agreed for every paired 10k/million run.

Five serial repeat sets covered CPU and GPU-requested modes, fixed and stable-key
indexed variable heights, and 10,000 / 1,000,000 stored rows. Mode, height and row
order reversed on even repeats. Each process warmed 128 routed events and
measured 120, totaling 4,800 tickets and 2,400 row-count geometry comparisons.
The table reports milliseconds; each pooled group contains 600 samples. Per-run
p95/p99, tails, variation, pairs and raw samples remain in the evidence.

| Mode | Heights | Rows | Pooled p95 ms | Pooled p99 ms | Median process p95 ms |
|---|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

## Checks and review

The Python consumer suite passed 53 tests, including guard completeness, endpoint
changes, invalid native geometry, scale and clipping rejection, plus historical
compatibility. The loaded-grid offscreen race tests and vet passed. Native
observation tests cover queued execution, lock ordering, detached values and
closed/wrong/multiple-window refusal. Worker completion joins native teardown.

Internal source, launch-readiness and result reviews cover this fixture checkpoint.
Prelaunch review corrected evidence handling: parse and hash the same review
bytes; validate saved launch/owned-process/binary/source/review/log bindings;
consume both stdout and stderr; preserve analysis with exclusive creation.
These corrections preceded native execution. The previous sizing implementation
received one Prism review using Anthropic Claude Sonnet 5.5; no additional
provider call is claimed for this measurement checkpoint.

All 40 owned groups exited 0, were reaped and observed absent. Streams reached
EOF with matching counts/hashes; source, prepared bytes and reviewed inputs stayed
stable. An exclusive native-test lease, stop markers, process deadline and output
bounds governed collection. This campaign is sealed against further execution.
No input-source, VoiceOver, clipboard, power, permission or other OS preferences
were changed. Scrolling entered the native event deque programmatically; physical
pointer/key interaction was not verified.

See [structured results](result.json), [manifest](evidence.manifest.json),
[raw evidence](evidence.tar.gz) and [measurement contract](../../../specs/grid-performance.md).

## Limits and next work

These measurements use the corrected current native viewport. There is no old
binary/viewport comparison, algorithmic-speedup claim or retroactive qualification
of historical failures. Native observations are endpoints and do not prove every
intervening extent or continuous host quietness. GPU-requested mode does not
establish GPU execution, native/GPU allocation or presentation latency. End-only
process observations are not retained-control memory attribution.

The next performance work should isolate remaining frame costs at this same
workload, then compare reviewed implementation changes with matched ordinary
runs. The complete table/tree target, 1,000-control/canvas stress, native/GPU
memory, endurance, physical interaction, cross-display and broader accessibility
qualification remain open. Public release remains gated.
''')
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Current native grid viewport](macos-current-grid-viewport/README.md): actual native geometry, 40 ordinary processes and 4,800 frames; unchanged 4/6 ms targets still fail.\n')
p=T/'docs/implementation.md';p.write_text(p.read_text()+'''\n## Current native table viewport checkpoint\n\nThe stored-grid performance fixture now validates native client/render/screen\ngeometry outside measured frames and joins worker teardown. Its consumer refuses\npartial or drifting endpoints, clipping outside render and scale mismatch.\n[Forty current native runs](reports/macos-current-grid-viewport/README.md)\ncompleted with matched row-count geometry; all 40 missed the unchanged 4 ms p95\ntarget and 32 missed 6 ms p99. The actual logical grid was 767×624 after rounding.\nThis fixture checkpoint does not establish an algorithmic speedup, GPU execution,\nphysical input or full Mac qualification.\n''')
p=T/'specs/macos-completion.md';p.write_text(p.read_text()+'''\n## Current native table viewport measurements\n\n[Current measurements](../docs/reports/macos-current-grid-viewport/README.md)\nrecord native endpoints and display scale for 40 ordinary processes, 4,800 frames\nand 2,400 complete paired row-count geometry comparisons. The corrected initial\nclient is 1519×1266 pixels at DPI162/DPR1; logical grid rounding yields 767×624.\nAll runs meet the 400-cell/50-row/eight-column workload minimum, but all miss\n4 ms p95 and 32 miss 6 ms p99. P6/P11 remain open. Historical failures retain\ntheir workload/status; GPU execution, native/GPU memory, physical interaction,\ncontinuous extent/host stability and complete Mac qualification are unproven.\n''')
print(json.dumps(dict(report=str(D),archive_sha256=sha(D/'evidence.tar.gz'),members=len(members),expanded_bytes=expanded)))
