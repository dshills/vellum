"""Stage only the reviewed current fixture and its result documentation."""
from pathlib import Path
import hashlib,json,subprocess
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
def main():
 assert not(W/'binding.json').exists()and not(W/'staged.diff').exists()
 assert git('rev-parse','HEAD').decode().strip()=='23ea03fc70febdd1a8dd9f32e02cc482a32bfb72'and not git('diff','--cached','--name-only')
 expected=sorted(['examples/loadedgrid/perf_runtime.go','examples/loadedgrid/perf_window.go','examples/loadedgrid/perf_window_test.go','scripts/benchmark-grid.py','scripts/benchmark-grid_test.py','specs/grid-performance.md','docs/implementation.md','docs/reports/README.md','specs/macos-completion.md']+['docs/reports/macos-current-grid-viewport/'+n for n in ['README.md','result.json','evidence.manifest.json','evidence.tar.gz']])
 names=sorted(set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()));assert names==expected,names
 sources={n:sha(T/n)for n in names};git('add','--',*names);assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard')
 assert all(hashlib.sha256(git('show',':'+n)).hexdigest()==sources[n]for n in names)
 with(W/'staged.diff').open('xb')as out:out.write(git('diff','--cached','--binary'))
 b=dict(base_commit=git('rev-parse','HEAD').decode().strip(),sources=sources,files=len(sources),staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=(W/'staged.diff').stat().st_size,producer_sha256=sha(__file__))
 with(W/'binding.json').open('x')as out:out.write(json.dumps(b,indent=2)+'\n')
 print(json.dumps({k:b[k]for k in ['base_commit','files','staged_diff_bytes','staged_diff_sha256']}))
if __name__=='__main__':main()
