"""Build the exact current fixture, optimized and without overlays; no UI."""
from pathlib import Path
import hashlib,json,plistlib,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-current-viewport-native-23ea03f');COMMIT='23ea03fc70febdd1a8dd9f32e02cc482a32bfb72'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
def identity():
 assert git('rev-parse','HEAD').decode().strip()==COMMIT
 names=git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')[:-1]
 files={n:sha(T/n)for n in sorted(set(names))if(T/n).is_file()};prepared={}
 for module in ['upstream','typesetting']:
  for p in(T/'drivers/cogent/build'/module).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():prepared[p.relative_to(T/'drivers/cogent/build').as_posix()]=sha(p)
 assert len(files)==4641 and len(prepared)==6245
 return dict(commit=COMMIT,files=files,prepared=prepared)
def main():
 P.mkdir(mode=0o700);O=P/'build';O.mkdir();source=identity();(O/'source.json').write_text(json.dumps(source,indent=2)+'\n')
 exe=O/'loadedgrid.app/Contents/MacOS/loadedgrid';exe.parent.mkdir(parents=True)
 with(exe.parent.parent/'Info.plist').open('xb')as f:plistlib.dump(dict(CFBundleIdentifier='com.vellum.currentviewport',CFBundleName='Vellum current viewport',CFBundleExecutable='loadedgrid',CFBundlePackageType='APPL',CFBundleVersion='1',NSHighResolutionCapable=True),f)
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};argv=['go','build','-p=1','-trimpath','-o',str(exe),'.'];start=time.monotonic()
 with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(T/'examples/loadedgrid'),env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20)
 d=dict(argv=argv,cwd=str(T/'examples/loadedgrid'),exit_code=r.returncode,seconds=time.monotonic()-start,source_stable=identity()==source,source_sha256=sha(O/'source.json'),producer_sha256=sha(__file__),native_runtime_executed=False,overlays=False,exact_uncommitted_fixture=True,binary=dict(path=str(exe),sha256=sha(exe)if exe.exists()else None,bytes=exe.stat().st_size if exe.exists()else None),plist_sha256=sha(exe.parent.parent/'Info.plist'),logs={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']})
 if r.returncode==0:
  v=run_child(['go','version','-m',str(exe)],env=env,capture_output=True,timeout=20);assert v.returncode==0 and not v.stderr;(O/'go-version.txt').write_bytes(v.stdout);text=v.stdout.decode();assert 'vcs.revision='+COMMIT in text and 'vcs.modified=true'in text and 'CGO_ENABLED=1'in text and '-race=true'not in text;d['go_metadata_sha256']=sha(O/'go-version.txt')
 (O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert r.returncode==0 and d['source_stable']
if __name__=='__main__':main()
