"""Independent raw reconciliation of the fixed conditional native comparison."""
from pathlib import Path
import hashlib,importlib.util,json,math,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('paint_validate',W/'validate.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dist(a):
 a=sorted(a);return {k:a[math.ceil(len(a)*f)-1]for k,f in[('p50',.5),('p95',.95),('p99',.99),('max',1)]}
p=read(W/'plan.json');r=read(W/'result.json');a=read(W/'assessment.json');adopt=a['adoption_bar_met'];names=list(p['cases'])if adopt else list(p['cases'])[:26]
assert r['result']==('MEASURED_CANDIDATE_FULL_MATRIX'if adopt else'MEASURED_PRIVATE_REJECTION_NO_EXTENSION')and r['completed']==names and(W/'stop-live').exists()
assert all(sha(k)==z for k,z in p['pins'].items())
inputs={str(W/n):sha(W/n)for n in['plan.json','admission.json','result.json','assessment.json','analyze.py','validate.py']};runs={};geos={};candidate_groups={};baseline_groups={}
for name in names:
 case=p['cases'][name];cr=read(W/(name+'-result.json'));assert cr['case']==case and cr['result']=='PASS_SCOPED_CURRENT_GRID_CASE'and cr['lease_held_through_cleanup']and(W/('stop-'+name)).exists()
 run=cr['run'];assert run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
 for stream in['stdout','stderr']:
  f=W/name/stream;assert sha(f)==run['logs'][stream]['sha256']and f.stat().st_size==run['logs'][stream]['bytes'];inputs[str(f)]=sha(f)
 assert not(W/name/'stderr').read_bytes()
 summary=v.validate((W/name/'stdout').read_text(),case,Path(p['sdk']));assert summary==cr['summary'];geos[name]=summary['geometry']
 raw=[json.loads(x)for x in(W/name/'stdout').read_text().splitlines()if x.strip()];samples=[e for e in raw if e['event']=='grid.perf.sample'];assert len(samples)==120
 ui=dist([e['metrics']['ui_work_ns']for e in samples]);allocation=dist([e['go_process_alloc_bytes']for e in samples]);assert ui=={k:summary['ui_work_ns'][k]for k in ui}and allocation=={k:summary['allocation_bytes'][k]for k in allocation}
 runs[name]={'ui_work_ns':ui,'allocation_bytes':allocation,'terminal_heap_bytes':summary['terminal_heap_bytes'],'samples':120,'binary':case['binary'],'diagnostic':case['diagnostic'],'allocation_profile':case['allocation'],'raw_sha256':sha(W/name/'stdout')}
 if not case['diagnostic']and not case['allocation']:
  key=('gpu'if case['gpu']else'cpu')+('-variable-'if case['variable']else'-fixed-')+str(case['rows']);(candidate_groups if case['binary']=='candidate'else baseline_groups).setdefault(key,[]).append(runs[name])
 if case['allocation']:
  for profile in cr['profiles'].values():assert sha(profile['path'])==profile['sha256'];inputs[profile['path']]=profile['sha256']
 inputs[str(W/(name+'-result.json'))]=sha(W/(name+'-result.json'))
# Recompute the frozen adoption rule directly from raw distributions.
paired={}
for mode in['cpu','gpu']:
 groups={k:[runs[f'{mode}-pair{i}-{k}']for i in range(1,6)]for k in['baseline','candidate']};med={k:statistics.median(x['ui_work_ns']['p95']for x in rows)for k,rows in groups.items()};tail={k:statistics.median(x['ui_work_ns']['p99']for x in rows)for k,rows in groups.items()};failed={k:sum(x['ui_work_ns']['p99']>6000000 for x in rows)for k,rows in groups.items()};heap={k:statistics.median(x['terminal_heap_bytes']for x in rows)for k,rows in groups.items()};improved=sum(groups['baseline'][i]['ui_work_ns']['p95']>groups['candidate'][i]['ui_work_ns']['p95']for i in range(5))
 assert all(geos[f'{mode}-pair{i}-baseline']==geos[f'{mode}-pair{i}-candidate']for i in range(1,6))
 passed=med['baseline']-med['candidate']>=400000 and improved>=4 and tail['candidate']<=tail['baseline']and failed['candidate']<=failed['baseline']and heap['candidate']<=heap['baseline']+(1<<20)
 for k,val in [('median_run_p95_ns',med),('median_run_p99_ns',tail),('p99_failed_runs',failed),('median_terminal_heap_bytes',heap),('improved_pairs',improved),('adoption_bar_met',passed)]:assert a['cases'][mode][k]==val
 paired[mode]={'median_p95_ns':med,'median_p99_ns':tail,'improved_pairs':improved,'adoption_bar_met':passed}
assert adopt==all(z['adoption_bar_met']for z in paired.values())
table={}
for key,rows in candidate_groups.items():
 assert len(rows)==5
 table[key]={'median_run_p95_ns':statistics.median(x['ui_work_ns']['p95']for x in rows),'median_run_p99_ns':statistics.median(x['ui_work_ns']['p99']for x in rows),'p95_4ms_pass_runs':sum(x['ui_work_ns']['p95']<=4000000 for x in rows),'p99_6ms_pass_runs':sum(x['ui_work_ns']['p99']<=6000000 for x in rows),'median_allocation_p50_bytes':statistics.median(x['allocation_bytes']['p50']for x in rows),'median_terminal_heap_bytes':statistics.median(x['terminal_heap_bytes']for x in rows)}
assert len(candidate_groups)==(8 if adopt else 2)
paired_geometry=[]
if adopt:
 for name in names:
  case=p['cases'][name]
  if case['rows']!=1000000:continue
  if not case['variable']:
   other=('gpu'if case['gpu']else'cpu')+'-diagnostic'if case['diagnostic']else('gpu'if case['gpu']else'cpu')+f'-pair{case["repetition"]}-candidate'
  else:other=name.replace('1000000','10000')
  assert geos[name]==geos[other],(name,other);paired_geometry.append([other,name])
 assert len(paired_geometry)==24
out={'result':'RECOMPUTED_CONDITIONAL_PAINT_COMPARISON','inputs':inputs,'adoption_bar_met':adopt,'paired':paired,'candidate_matrix':table,'cases':runs,'total_processes':len(names),'ordinary_samples':sum(120 for c in p['cases'].values()if not c['diagnostic']and not c['allocation']and (adopt or not c.get('extension'))),'candidate_ordinary_samples':sum(120*len(x)for x in candidate_groups.values()),'baseline_ordinary_samples':sum(120*len(x)for x in baseline_groups.values()),'diagnostic_samples':sum(120 for n in names if p['cases'][n]['diagnostic']),'allocation_samples':480,'paired_10k_million_geometry':paired_geometry,'full_candidate_table_matrix_measured':adopt,'full_matrix_target_pass':adopt and all(z['p95_4ms_pass_runs']==z['p99_6ms_pass_runs']==5 for z in table.values()),'runtime_adopted':False,'full_mac_qualified':False,'physical_input_qualified':False}
(W/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in['result','adoption_bar_met','paired','candidate_matrix','total_processes','ordinary_samples','full_matrix_target_pass']},indent=2))
