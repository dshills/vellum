"""Commit the reviewed checkpoint, then fast-forward the clean calling checkout."""
from pathlib import Path
import hashlib,json,sys
W=Path(__file__).resolve().parent
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
C=Path('/Users/dshills/Development/projects/Vellum')
BASE='51dbe40521d34c76abcc1ab82300b394a55fdb01'
sys.dont_write_bytecode=True
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):
 r=run_child(['git',*args],cwd=root,timeout=60,capture_output=True,check=True)
 return r.stdout
assert not(W/'committed.json').exists()
review=json.loads((W/'internal-final-review.json').read_text())
assert review['approved'] and not review['unresolved_findings']
archive_review=json.loads((W/'internal-archive-review.json').read_text())
assert archive_review['approved'] and not archive_review['unresolved_findings']
report=T/'docs/reports/macos-grid-paint'
cp=json.loads((report/'checkpoint.json').read_text())
assert cp['source_base']==BASE
assert cp['files']==review['files'],'checkpoint differs from reviewed four-file map'
required_archive_inputs=[report/'checkpoint.json',report/'records.tar.gz',Path(__file__)]
for p in required_archive_inputs:
 assert archive_review['inputs'].get(str(p))==sha(p),(str(p),'archive review binding')
assert sha(report/'records.tar.gz')==cp['archive']['sha256']
assert sha(W/'internal-final-review.json')==cp['reviews']['final']['sha256']
for name,z in cp['files'].items():assert sha(T/name)==z,(name,'reviewed file changed')
assert git(T,'rev-parse','HEAD').decode().strip()==BASE
assert git(C,'rev-parse','HEAD').decode().strip()==BASE
assert not git(C,'status','--porcelain')
assert not git(T,'diff')
git(T,'diff','--cached','--check')
staged=set(git(T,'diff','--cached','--name-only','-z').decode().rstrip('\0').split('\0'))
expected=set(cp['files'])|{'docs/reports/macos-grid-paint/'+n for n in['records.tar.gz','checkpoint.json']}
assert staged==expected,staged^expected
logs={}
logs['commit']=git(T,'commit','-m','docs(macos): reject render-local paint style experiment').decode()
head=git(T,'rev-parse','HEAD').decode().strip()
assert not git(T,'status','--porcelain')
assert not git(C,'status','--porcelain')
logs['fast_forward']=git(C,'merge','--ff-only',head).decode()
assert git(C,'rev-parse','HEAD').decode().strip()==head and not git(C,'status','--porcelain')
d={'base':BASE,'commit':head,'canonical_clean':True,'candidate_clean':True,'archive_sha256':sha(report/'records.tar.gz'),'logs':logs,'native_executed':False,'pushed':False}
(W/'committed.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d,indent=2))
