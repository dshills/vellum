//go:build offscreen

package cogent

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"reflect"
	"testing"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
)

// Saved operations must own their paint values even after another render changes
// inherited colors and the value surface is replaced by ordinary native cells.
func TestGridCellSurfacePaintRecordsSurviveLaterRenders(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 162, 192} {
		for _, selected := range []bool{false, true} {
			t.Run(fmt.Sprintf("dpi%g/selected%v", dpi, selected), func(t *testing.T) {
				source := &surfaceEditableSource{selectionNativeSource: selectionNativeSource{selectionNativeIndex: selectionNativeIndex{total: 10000, revision: 1}}, value: "Paint é <b>\tאבג"}
				model, e := virtual.NewGrid(source, []virtual.GridColumn{{ID: "c0", Width: 121}, {ID: "c1", Width: 121}, {ID: "c2", Width: 121}}, virtual.GridConfig{RowHeight: 23, HeaderHeight: 27, FrozenColumns: 1, RowSelection: true}, virtual.GridViewport{Width: 300, Height: 180})
				if e != nil {
					t.Fatal(e)
				}
				cfg := manualConfig(t, 7)
				cfg.LogicalDPI = dpi
				m, a := gridManual(t, cfg, func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: model, Grow: true} })
				gridFrame(t, m)
				if e = a.Do(func() {
					if e := model.SelectToKey("selection-0", "c1", virtual.GridSelectReplace); e != nil {
						t.Fatal(e)
					}
					if !selected {
						if e := model.SelectToKey("selection-0", "c1", virtual.GridSelectToggle); e != nil {
							t.Fatal(e)
						}
					}
					_ = a.Invalidate("one")
				}); e != nil {
					t.Fatal(e)
				}
				gridFrame(t, m)
				g := surfaceBinding(t, m, a)
				surfaceEnable(t, m, a, g)
				var old render.Render
				var original *image.RGBA
				var replayOld func()
				if e = a.Do(func() {
					scene := g.host.Scene
					paint := func(items render.Render) *image.RGBA {
						return rasterx.New(math32.FromPoint(scene.SceneGeom.Size)).Render(items).Image().(*image.RGBA)
					}
					var classes uint8
					for _, cell := range g.cellSurface.cells {
						if !cell.box.Empty() && cell.shape != nil {
							classes |= 1 << cell.class
						}
					}
					want := uint8(1<<0 | 1<<2) // normal and unselected active cursor
					if selected {
						want = 1<<0 | 1<<1 | 1<<3 // normal, selected and selected cursor
					}
					if classes&want != want {
						t.Fatalf("visible paint classes %04b, want %04b", classes, want)
					}
					templates, epoch := g.cellSurface.styles, g.cellSurface.epoch
					scene.RenderWidget()
					old = scene.Painter.RenderDone()
					if !reflect.DeepEqual(templates, g.cellSurface.styles) || epoch != g.cellSurface.epoch {
						t.Fatal("render mutated resolved style templates or shape epochs")
					}
					original = paint(old)
					capture := rasterx.New(math32.FromPoint(scene.SceneGeom.Size)).(*rasterx.Renderer)
					packet := capture.ScenePacket(old)
					if packet == nil {
						t.Fatal("saved operations were not capturable")
					}
					replayOld = func() {
						if !bytes.Equal(paint(old).Pix, original.Pix) {
							t.Fatal("saved operations changed after later painting or surface retirement")
						}
						pixels := image.NewRGBA(original.Bounds())
						if !packet.Replay(pixels) || !bytes.Equal(pixels.Pix, original.Pix) {
							t.Fatal("saved packet changed after later painting or surface retirement")
						}
					}
					for _, pane := range g.panes[2:] {
						pane.OverrideStyle = true
						pane.Styles.Color = image.NewUniform(color.RGBA{R: 231, G: 37, B: 19, A: 255})
						pane.Styles.Background = image.NewUniform(color.RGBA{R: 31, G: 55, B: 91, A: 255})
						pane.Styles.ActualBackground = pane.Styles.Background
					}
					g.host.ApplyScenePos()
					templates, epoch = g.cellSurface.styles, g.cellSurface.epoch
					scene.RenderWidget()
					changed := scene.Painter.RenderDone()
					if !reflect.DeepEqual(templates, g.cellSurface.styles) || epoch != g.cellSurface.epoch {
						t.Fatal("changed render mutated resolved templates or shape epochs")
					}
					if bytes.Equal(paint(changed).Pix, original.Pix) {
						t.Fatal("color-change fixture did not produce different visible pixels")
					}
					replayOld()
				}); e != nil {
					t.Fatal(e)
				}
				// This compares the changed frame with an independent native-widget
				// oracle and retires the value surface while the old operations live.
				surfaceCompareWithOriginal(t, m, a, g)
				if e = a.Do(func() {
					if g.cellSurface != nil {
						t.Fatal("reference transition did not retire value ownership")
					}
					replayOld()
				}); e != nil {
					t.Fatal(e)
				}
			})
		}
	}
}
