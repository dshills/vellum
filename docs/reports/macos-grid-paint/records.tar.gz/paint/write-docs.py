from pathlib import Path
import json,statistics
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');D=W/'docs-draft'
a=json.loads((W/'assessment.json').read_text());analysis=json.loads((W/'analysis.json').read_text());assert not a['adoption_bar_met']and analysis['total_processes']==26
files={}
files['docs/reports/macos-grid-paint/README.md']='''# Render-local grid paint styles: measured and rejected

The private four-style-per-pane rendering experiment is rejected. It reduces
sampled Go allocation substantially but fails the frozen ordinary latency bar.
No production, public API, prepared dependency or SDK change is adopted. The
latest complete eight-case table measurement remains the
[current `a2b4143` matrix](../macos-grid-current/README.md); full M3 and Mac
completion remain open.

## Change and correctness evidence

The original `renderCellSurface` copies a large resolved style for every visible
cell. Minimum Go 1.25.6 compiler output explicitly moves that per-cell `style` to
the heap. The candidate instead copies four resolved classes once per pane
render and computes invariant batch eligibility once per class. Compiler output
moves this one `paintStyles` array outside the cell loop to the heap. Every render
owns fresh copies; resolved templates remain immutable. There is no cross-frame
cache or new retained field. Paint order, cell clipping, projection, input,
accessibility, fallback and native editing stay unchanged.

The internal source review approves the candidate's ownership and class invariants.
The full driver race suite, loaded-grid example race tests, vet and optimized
ordinary/observer native builds pass with exact source pins and terminal owned
group absence. The new lifetime regression covers 96/120/144/162/192 DPI, normal,
selected and active-cursor classes, meaningful inherited color changes, stable
resolved templates/shape epochs, independent ordinary-widget pixels and geometry,
and replay of saved render operations and detached ScenePackets after later
renders and value-surface retirement. The earlier focused run preceded only an
added positive class-mask assertion; the full final driver race includes it.
Compiler evidence precedes that test-only change; exact old inputs and the
unchanged production bytes are preserved.

These are automated software/routing proofs. They do not establish physical
pointer behavior, a real display transition, screen-reader use or presentation.

## Fixed native comparison

The clean source base is `51dbe40521d34c76abcc1ab82300b394a55fdb01`, with unchanged
`a2b4143` production code. The baseline is the current normal `81b85e39…` binary,
not the earlier widget-based SDK binary. The normal candidate is `0da934c8…`;
`93412302…` is a separate observer build. Ordinary timing uses optimized Go
1.25.6 without race, offscreen, escape-analysis or observer instrumentation.
Both variants use the unchanged retained private SDK's source-built `786a…`
native archive, with stage0080 Go overlays. This does not qualify the default
checkout native archive or constitute a refreshed SDK.

All measured runs have 10,000 stored fixed-height rows, 400 or more nonempty
clipped cells, the same 1519×1266 native render size and logical DPI 162. Each
fresh process executes 128 guarded warm events and 120 measured events. Five
interleaved baseline/candidate pairs run separately for CPU and GPU. All ten
paired geometry arrays match exactly. Percentiles are nearest-rank per run,
then median across five runs; samples are never pooled for percentile claims.

| Ordinary result | CPU baseline → candidate | GPU baseline → candidate |
| --- | --- | --- |
| Median run-p95 | 4.748167 → 4.690332 ms | 4.254502 → 4.104204 ms |
| Median p95 improvement | 0.057835 ms | 0.150298 ms |
| Improved pairs | 3/5 | 5/5 |
| Median run-p99 | 5.162665 → 5.243124 ms | 4.577459 → 4.442754 ms |
| Runs with p95 ≤4 ms | 0/5 → 0/5 | 0/5 → 0/5 |
| Runs with p99 ≤6 ms | 5/5 → 5/5 | 5/5 → 5/5 |
| Median per-run allocation p50 | 4,160,840 → 3,457,944 B | 5,749,032 → 5,043,288 B |
| Median terminal process Go heap | 26,007,216 → 26,043,696 B | 27,376,960 → 27,409,600 B |

The admission bar was frozen before execution: at least 0.4 ms lower median
run-p95 and four improved pairs out of five in **both** modes, nonincreasing
median p99 and count of runs above 6 ms, no more than 1 MiB extra median terminal
Go heap, exact geometry and correctness. CPU fails the gain, pair-count and
median-tail guards; GPU fails the gain guard. All twenty ordinary p95s still
exceed 4 ms. Lower allocation alone does not justify adoption under this bar.

Exactly 26 native processes execute: two separate functional diagnostics
(240 measured frames), twenty ordinary timing runs (2,400 samples), and four
separate allocation captures (480 samples). Both diagnostics positively observe
current value layouts/shapes and zero native body children; CPU proves fresh
raster/copy, GPU a fresh final accepted scene with five input writes, one submit
and no fallback. The validator permits valid intermediate reuse while requiring
a fresh final scene. Its pure controls retain three positive and 27 negative
cases, including fresh-prefix/reused-final rejection.

The reviewed plan permits 36 further processes only if the paired bar passes:
six remaining route diagnostics and thirty remaining candidate timing runs.
Rejection seals the scope after the first 26; all 36 stay unexecuted. No new full
candidate table matrix is claimed. Every executed process has complete raw
streams, stable pins, shared-lease cleanup and terminal owned-group absence.
No failed or canceled native case is retried. No live app remains from this scope.

## Separate allocation attribution

Four before/after cumulative Go allocation captures use sampling rate 524,288;
twelve offline `go tool pprof` commands subtract the warmed baseline and inspect
flat/cumulative allocated space and allocated objects. These sampled process
profiles include concurrent adapter/observer work and profile encoding. They do
not measure native/GPU allocation, retained memory, framework-only budgets or
ordinary latency. Pprof's printed MB units here correspond to MiB.

| Sampled allocated space | CPU baseline → candidate | GPU baseline → candidate |
| --- | --- | --- |
| Total process difference | 495.00 → 387.19 MiB | 666.25 → 561.30 MiB |
| Flat `renderCellSurface` attribution | 74.63 → 1.01 MiB | 90.15 → 2.52 MiB |

The compiler and sampled profiles support the intended allocation mechanism.
They do not turn a failed latency comparison into a pass or qualify the general
64 KiB/100-allocation frame budget. The small terminal heap increases stay inside
the experiment's retention guard, but full M4 resource/endurance gates remain.

## Failure history, review and next work

The first preparation refuses SDK drift before any native launch: Python imports
from pure validator controls create three bytecode cache files. Their exact
bytes/hashes are preserved, only those generated files are removed, bytecode
creation is disabled, and the complete original 7,880-file SDK vector is restored
before fresh preparation and independent admission. No original SDK source
changes. This failure and restoration remain in the records.

The archive retains the private candidate and baseline source, exact compiler
versions, raw native/profile records, conditional plan, controls and owned
execution receipts. Native executable payloads are referenced by hash rather
than copied. Internal results and final reviews and one conserved Prism review
with Anthropic Claude Sonnet 5.5 are recorded in `checkpoint.json`; their exact
coverage and all retained/discarded finding dispositions are preserved. The
checkpoint and commit/promotion receipts follow the archived evidence snapshot.

Retire this style experiment without further style/cache micro-tuning. The next
concrete integration deliverable is M2's complete native professional workspace
workflow at 10k/1M rows, using the existing records and domain assertions; the
18-action smoke remains insufficient. M3 still needs a materially different,
measured implementation decision and the complete table/tree/general-UI matrix.
The [Mac delivery plan](../../../specs/macos-delivery.md) retains every remaining
M1–M7 exit criterion and the unchanged performance/resource budgets. No soak,
physical input, system preference change or public distribution follows from
this experiment.
'''
for name in ['specs/macos-delivery.md','specs/macos-completion.md','specs/grid-performance.md']:files[name]=(C/name).read_text()
s=files['specs/macos-delivery.md'];s=s.replace('Updated 17 October 2026. The latest complete table matrix measures clean\n`bd672a6` with stage0079; the current headless-qualified private SDK uses clean `abe67c6`, Go 1.25.6 and\nstage0079.','Updated 18 October 2026. The latest complete table matrix measures `a2b4143`\nGo code with stage0080 overlays over the retained source-built native library.\nThe unchanged private SDK uses clean `abe67c6`, Go 1.25.6 and stage0079.')
s=s.replace('allocation at the per-cell render-style copy. Next is a bounded render-local\nstyle ownership fix with correctness and matched ordinary evidence, then the\nremaining table/tree/general-UI matrix and other M1–M7 exit criteria.','allocation at the per-cell render-style copy. The subsequent\n[render-local style experiment](../docs/reports/macos-grid-paint/README.md) passes\ncorrectness checks and reduces sampled allocation, but is rejected: CPU/GPU\nmedian run-p95 gains are only 0.057835/0.150298 ms, CPU improves 3/5 pairs and\nmedian p99 worsens. The fixed 0.4 ms/4-of-5 both-mode bar fails; no runtime is\nadopted and no conditional full candidate matrix runs. Retire this style\nexperiment. Next complete M2\'s full native workspace integration at 10k/1M\nrows; the existing 18-action smoke is insufficient. A materially different\nmeasured M3 decision and the remaining table/tree/general-UI matrix still precede\nfull resource/endurance qualification and M7 closure.')
s=s.replace('Sampled allocation profiles locate the per-cell paint-style copy; next is a per-render style ownership fix with correctness and matched ordinary evidence.','The [render-local style experiment](../docs/reports/macos-grid-paint/README.md) reduces allocation but fails the frozen latency bar (CPU/GPU median p95 gains 0.058/0.150 ms; CPU 3/5 improved pairs and worse median p99). It stays private and is rejected; no further style/cache tuning or conditional matrix is run. Next close full native M2 integration, then select a materially different measured M3 implementation.')
files['specs/macos-delivery.md']=s
s=files['specs/macos-completion.md'];target='allocation site to address. The initial intermediate-composition validator';s=s.replace(target,'allocation site. The [render-local style experiment](../docs/reports/macos-grid-paint/README.md)\nsubsequently reduces allocation but fails its frozen latency bar: CPU/GPU\nmedian p95 gains are 0.058/0.150 ms, CPU improves only 3/5 pairs and its median\np99 worsens. All twenty ordinary p95s exceed 4 ms. No runtime change is adopted;\nthe 26-process scope seals with all 36 conditional extension cases unexecuted.\nNext close full native M2 workspace integration, then make a materially different\nmeasured M3 implementation decision. The initial intermediate-composition validator');files['specs/macos-completion.md']=s
s=files['specs/grid-performance.md'];s+='''

## Render-local paint ownership experiment: rejected

The [paint-style experiment](../docs/reports/macos-grid-paint/README.md) replaces
per-cell style copies with four fresh copies per pane render. Compiler escape
output, retained paint/ScenePacket lifetime and independent pixel/geometry tests
at five DPIs, full driver/example race checks, vet and builds pass. Separate
native CPU/GPU diagnostics confirm the value route and fresh final pipeline.

Five ordinary fixed-10k pairs per mode use the current `81b85e39…` baseline and
an isolated candidate, with exact geometry and 120 measured/128 warm events per
process. Median run-p95 improves CPU 4.748167→4.690332 ms and GPU
4.254502→4.104204 ms. CPU improves 3/5 pairs, GPU 5/5; CPU median p99 worsens
5.162665→5.243124 ms. Both miss the frozen 0.4 ms gain; all twenty ordinary p95s
exceed 4 ms, all p99s meet 6 ms. Ordinary median per-run allocation p50 falls
4,160,840→3,457,944 B CPU and 5,749,032→5,043,288 B GPU. Separate sampled process
profiles show the intended paint allocation reduction, without qualifying a
framework-only budget or latency pass.

Reject the private candidate, preserve all evidence and stop style follow-up
tuning. Exactly 26 native processes complete (2 diagnostics +20 ordinary
+4 allocation captures); the reviewed conditional 36-case wider matrix remains
unexecuted. No source/prepared/SDK runtime change is adopted. The preceding
`a2b4143` full matrix remains the current production result; all unchanged M3
and broader Mac gates remain open. Next complete native M2 integration, then
choose a materially different measured M3 implementation.
''';files['specs/grid-performance.md']=s
for n,s in files.items():p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
print(json.dumps({'draft_files':list(files),'bytes':sum(len(s.encode())for s in files.values())}))
