"""Archive immutable initial failure and completed recovery evidence together."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent
out=W/'checkpoint-records.tar.gz';index=W/'archive-index.json'
assert not out.exists()and not index.exists()
files={}
for prefix,root in[('paint',W)]:
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),str(p)
  if not p.is_file():continue
  if '__pycache__'in p.parts and 'excluded-generated-bytecode'not in p.parts:continue
  if p.parent==W and p.name in ['grid-baseline','grid-candidate','grid-diagnostic']:continue
  if root==W and p.name in['checkpoint-records.tar.gz','archive-index.json']:continue
  assert p.stat().st_size<=16<<20,(str(p),'record bound')
  files[prefix+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
assert sum(map(len,files.values()))<=128<<20
manifest={'schema':1,'scope':'Rejected private render-local style experiment. Initial preparation cache-drift failure/restoration, baseline/candidate/compiler versions, all26native records/statuses, skipped36conditionalcases, allprofilebytes and12offlineanalyses retained. Executables and SDK/dependency payloads referenced by identities, notcopied. Packaging/commit transaction records follow thissnapshot.','files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in files.items()}}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with out.open('xb')as raw,gzip.GzipFile(fileobj=raw,filename='',mtime=0,mode='wb')as zipped,tarfile.open(fileobj=zipped,mode='w')as tar:
 for name,data in files.items():
  member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.uid=member.gid=0;member.mtime=0;tar.addfile(member,io.BytesIO(data))
with tarfile.open(out,'r:gz')as tar:
 names=tar.getnames();assert len(names)==len(files)and set(names)==set(files)
 for member in tar:
  assert member.isfile()and not member.name.startswith('/')and'..'not in Path(member.name).parts
  assert tar.extractfile(member).read()==files[member.name]
d={'file':'records.tar.gz','sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(files),'expanded_bytes':sum(map(len,files.values())),'manifest_sha256':hashlib.sha256(files['MANIFEST.json']).hexdigest(),'validated_every_member':True}
index.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
