"""Pure historical-shape/synthetic-observer controls; no native evidence."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('surface_validate_controls',W/'validate.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
sdk=Path(json.loads((W.parent/'macos-grid-cell-surface-410a98c/native-plan.json').read_text())['sdk']);fixture=W.parent/'macos-grid-cell-surface-410a98c/final-native/cpu/stdout'
events=[]
for line in fixture.read_text().splitlines():
 try:x=json.loads(line)
 except ValueError:continue
 if str(x.get('event','')).startswith('grid.perf.'):events.append(x)
events[0]['go_version']='go1.25.6'
ordinary=copy.deepcopy(events)
for e in ordinary:
 e['source_details']=False
 if 'native_sample'in e:e['native_sample'].pop('SourceDetails',None)
render=lambda e:'\n'.join(json.dumps(x)for x in e)
v.validate(render(ordinary),{'diagnostic':False,'gpu':False,'rows':10000,'variable':False},sdk)
diag=[]
for e in events:
 if e['event']=='grid.perf.sample':
  count=e['geometry']['materialized_cells'];diag.append({'event':'grid.surface.diagnostic','generation':e['generation'],'frame':e['frame'],'native_children':0,'native_body_cells':0,'value_layouts':count,'shapes':count,'complete':True})
 diag.append(e)
v.validate(render(diag),{'diagnostic':True,'gpu':False,'rows':10000,'variable':False},sdk)
results={}
for name in ['missing-observer','duplicate-observer','body-widget-remains','incomplete-surface','shape-missing','stale-frame','wrong-generation','small-workload','duplicate-callback','missing-terminal','work-sum-drift','diagnostic-in-ordinary','cpu-source-unavailable','cpu-source-no-op']:
 a=copy.deepcopy(diag if name not in ['diagnostic-in-ordinary']else ordinary);case={'diagnostic':name!='diagnostic-in-ordinary','gpu':False,'rows':10000,'variable':False};oi=next((i for i,x in enumerate(a)if x['event']=='grid.surface.diagnostic'),None);si=next(i for i,x in enumerate(a)if x['event']=='grid.perf.sample')
 if name=='cpu-source-unavailable':a[si]['native_sample']['SourceDetails']['Records'][0]['RasterAvailable']=False
 elif name=='cpu-source-no-op':a[si]['native_sample']['SourceDetails']['Records'][0]['ImageChanged']=False
 elif name=='missing-observer':a.pop(oi)
 elif name=='duplicate-observer':a.insert(oi,copy.deepcopy(a[oi]))
 elif name=='body-widget-remains':a[oi]['native_children']=1
 elif name=='incomplete-surface':a[oi]['complete']=False
 elif name=='shape-missing':a[oi]['shapes']-=1
 elif name=='stale-frame':a[oi]['frame']-=1
 elif name=='wrong-generation':a[oi]['generation']+=1
 elif name=='small-workload':a[si]['geometry']['cells']=399
 elif name=='duplicate-callback':a[si]['callbacks']=2
 elif name=='missing-terminal':a.pop()
 elif name=='work-sum-drift':a[si]['metrics']['ui_work_ns']+=1
 elif name=='diagnostic-in-ordinary':a.insert(si,copy.deepcopy(diag[2]))
 try:v.validate(render(a),case,sdk)
 except Exception as e:results[name]={'rejected':True,'type':type(e).__name__,'message':str(e)}
 else:raise AssertionError('accepted '+name)
for name,case in [('wrong-row-case',{'diagnostic':False,'gpu':False,'rows':1000000,'variable':False}),('wrong-variable-case',{'diagnostic':False,'gpu':False,'rows':10000,'variable':True}),('wrong-gpu-case',{'diagnostic':False,'gpu':True,'rows':10000,'variable':False}),('missing-alloc-mode',{'diagnostic':False,'gpu':False,'rows':10000,'variable':False,'allocation':True})]:
 try:v.validate(render(ordinary),case,sdk)
 except Exception as e:results[name]={'rejected':True,'type':type(e).__name__,'message':str(e)}
 else:raise AssertionError('accepted '+name)
allocated=copy.deepcopy(ordinary)
for e in allocated:e['alloc_profile']=True
try:v.validate(render(allocated),{'diagnostic':False,'gpu':False,'rows':10000,'variable':False},sdk)
except Exception as e:results['allocated-in-ordinary']={'rejected':True,'type':type(e).__name__,'message':str(e)}
else:raise AssertionError('accepted allocated ordinary')
# The actual failed native frame includes a valid intermediate reuse, followed
# by a fresh final composition. Parser controls do not create native evidence.
failure_fixture=W.parent/'macos-grid-current-a2b4143/diagnostic-gpu-variable-10000/stdout'
actual=[json.loads(x)for x in failure_fixture.read_text().splitlines()if x.strip()]
case={'diagnostic':True,'gpu':True,'rows':10000,'variable':True}
v.validate(render(actual),case,sdk)
fi=next(i for i,e in enumerate(actual)if e.get('event')=='grid.perf.sample'and e['generation']==237)
for name in ['final-reused','fresh-prefix-reused-final','reused-only','final-fallback','final-input-error','missing-final-source','intermediate-fallback','duplicate-final-scene']:
 a=copy.deepcopy(actual);details=a[fi]['native_sample']['SourceDetails'];records=details['Records'];final=records[-1];host=final['SceneHost']
 if name=='final-reused':host['Reused']=True
 elif name=='fresh-prefix-reused-final':
  records.reverse()
  for ordinal,r in enumerate(records,1):r['Composition']=ordinal
 elif name=='reused-only':records[:]=[records[0]];details['Compositions']=1
 elif name=='final-fallback':host['Fallback']=True
 elif name=='final-input-error':host['InputWriteErrors']=1
 elif name=='missing-final-source':records.pop()
 elif name=='intermediate-fallback':records[0]['SceneHost']['Fallback']=True
 elif name=='duplicate-final-scene':records.append(copy.deepcopy(final))
 try:v.validate(render(a),case,sdk)
 except Exception as e:results[name]={'rejected':True,'type':type(e).__name__,'message':str(e)}
 else:raise AssertionError('accepted '+name)
d={'result':'PASS_PURE_VALIDATOR_CONTROLS','native_executed':False,'historical_fixture':str(fixture),'historical_fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'scope':'HistoricalCPUsource-details grid shape copied onlyinmemory; metadata go_version adapted and synthetic value counters inserted for parser controls. Ordinarycopy removes details. No currentnative/routing/performancequalification. Raw native fixture unchanged.','positive_controls':3,'negative_controls':results}
(W/'controls.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'positive':3,'negative':len(results)}))
