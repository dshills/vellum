"""Package the reviewed rejected experiment; no implementation is installed."""
from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
final=read(W/'internal-final-review.json');assert final['approved']and not final['unresolved_findings']
assert all(sha(T/n)==z for n,z in final['files'].items())
archive=read(W/'archive-index.json');assert sha(W/'checkpoint-records.tar.gz')==archive['sha256']and archive['validated_every_member']
plan=read(W/'plan.json');result=read(W/'result.json');disposition=read(W/'prism-disposition.json');assert result['result']=='MEASURED_PRIVATE_REJECTION_NO_EXTENSION'and len(result['completed'])==26
assert disposition['calls']==1 and disposition['complete']and disposition['retained']==0 and disposition['discarded']==2 and disposition['suppressed']==0
report=T/'docs/reports/macos-grid-paint';assert not(report/'checkpoint.json').exists()and not(report/'records.tar.gz').exists()
reviews={key:{'record':name,'sha256':sha(W/name)}for key,name in [('source','internal-source-review.json'),('native_admission','admission.json'),('results','internal-results-review.json'),('pre_prism','internal-pre-prism-review.json'),('provider','prism.json'),('provider_disposition','prism-disposition.json'),('final','internal-final-review.json')]}
cp={'schema':1,'result':'REJECT_PRIVATE_OVERLAY','source_base':plan['head'],'runtime_commit':'a2b4143578631cbc57f29fcc1ee18b513e4567a3','runtime_changed':False,'candidate_adopted':False,'files':final['files'],'archive':archive,'reviews':reviews,'native_plan_sha256':sha(W/'plan.json'),'native_result_sha256':sha(W/'result.json'),'analysis_sha256':sha(W/'analysis.json'),'prism':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':1,'complete':True,'files':4,'chunks':1,'retained':0,'discarded':2,'suppressed':0,'dispositions':'Both accepted as editorial clarity; no measured result or source change. See archived prism-disposition.json.'},'native_processes':26,'ordinary_samples':2400,'diagnostic_samples':240,'allocation_samples':480,'conditional_cases_unexecuted':36,'offline_pprof_commands':12,'prepared_files':6261,'sdk_files':7880,'sdk_payload_files':7879,'sdk_source':'abe67c625a498d27b78f9719e6038cc1d6c23e88','sdk_native_archive_sha256':'786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883','sdk_unchanged':True,'full_matrix_target_pass':False,'full_mac_qualified':False,'closed_mac_gates':[],'next':'Complete full native M2 professional workspace workflow at10k/1M; current18-action smoke insufficient. Reject furtherstyle/cachemicrotuning; fullM3architecture/table/tree/generalUI andM4-M7remain.'}
shutil.copy2(W/'checkpoint-records.tar.gz',report/'records.tar.gz');(report/'checkpoint.json').write_text(json.dumps(cp,indent=2)+'\n')
run_child(['git','add','--','docs/reports/macos-grid-paint/checkpoint.json','docs/reports/macos-grid-paint/records.tar.gz'],cwd=T,timeout=30,capture_output=True,check=True)
run_child(['git','diff','--cached','--check'],cwd=T,timeout=30,capture_output=True,check=True)
print(json.dumps({'checkpoint_sha256':sha(report/'checkpoint.json'),'archive':archive,'staged_extra_files':2},indent=2))
