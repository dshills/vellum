"""Recompute each ordinary run; never pool observations or accept diagnostics."""
from pathlib import Path
import hashlib,json,statistics
W=Path(__file__).resolve().parent
p=json.loads((W/'plan.json').read_text());out={'cases':{},'runtime_adopted':False,'closed_mac_gates':[]}
def need(ok,message):
 if not ok:raise ValueError(message)
def nr(values,percent):
 values=sorted(values);return values[(len(values)*percent+99)//100-1]
def read(name):
 r=json.loads((W/(name+'-result.json')).read_text());need(r['result']=='PASS_SCOPED_CURRENT_GRID_CASE'and r['run']['owned']['group_absent']and(W/('stop-'+name)).exists(),'terminal scoped run')
 raw=(W/name/'stdout').read_bytes();events=[json.loads(x)for x in raw.splitlines()if x.strip()];rows=events[2:-1];need(len(rows)==120 and all(x['event']=='grid.perf.sample'for x in rows),'ordinary only120samples')
 values=[x['metrics']['ui_work_ns']for x in rows];s=r['summary'];need(nr(values,95)==s['ui_work_ns']['p95']and nr(values,99)==s['ui_work_ns']['p99'],'nearest-rank reconciliation')
 return {'samples':120,'p95_ns':nr(values,95),'p99_ns':nr(values,99),'max_ns':max(values),'allocation_p50_bytes':nr([x['go_process_alloc_bytes']for x in rows],50),'terminal_heap_bytes':events[-1]['memory_after_measured_gc']['HeapAlloc'],'geometry':s['geometry'],'log_sha256':hashlib.sha256(raw).hexdigest()}
def assess():
 global out
 out={'cases':{},'runtime_adopted':False,'closed_mac_gates':[]}
 for mode in ['cpu','gpu']:
  runs={label:[read(f'{mode}-pair{i}-{label}')for i in range(1,6)]for label in ['baseline','candidate']}
  geometry=all(a['geometry']==b['geometry']for a,b in zip(runs['baseline'],runs['candidate']));need(geometry,'exact pairwise geometry')
  med={k:statistics.median(x['p95_ns']for x in v)for k,v in runs.items()};tail={k:statistics.median(x['p99_ns']for x in v)for k,v in runs.items()};failed99={k:sum(x['p99_ns']>6000000 for x in v)for k,v in runs.items()};heap={k:statistics.median(x['terminal_heap_bytes']for x in v)for k,v in runs.items()};improved=sum(a['p95_ns']>b['p95_ns']for a,b in zip(runs['baseline'],runs['candidate']))
  for group in runs.values():
   for x in group:del x['geometry']
  admitted=med['baseline']-med['candidate']>=400000 and improved>=4 and tail['candidate']<=tail['baseline']and failed99['candidate']<=failed99['baseline']and heap['candidate']<=heap['baseline']+(1<<20)
  out['cases'][mode]={'runs':runs,'median_run_p95_ns':med,'median_run_p99_ns':tail,'p99_failed_runs':failed99,'improved_pairs':improved,'median_p95_reduction_ns':med['baseline']-med['candidate'],'median_terminal_heap_bytes':heap,'geometry_matched':geometry,'adoption_bar_met':admitted,'p95_failed_runs':{k:sum(x['p95_ns']>4000000 for x in v)for k,v in runs.items()},'max_ns':{k:max(x['max_ns']for x in v)for k,v in runs.items()}}
 out['adoption_bar_met']=all(x['adoption_bar_met']for x in out['cases'].values());out['result']='ADMIT_FOR_PRODUCTION_CHECKPOINT'if out['adoption_bar_met']else'REJECT_PRIVATE_OVERLAY';out['ordinary_samples_recomputed']=2400;out['scope']='Five120sample ordinarypairs eachCPU/GPU, separate native120sample diagnosticseachmode. Per-run nearest-rank, no pooling.10kfixed400clippedcells fixture prototype only, unchanged full4/6ms fullmatrix and allM1-M7 gatesremain.'
 (W/'assessment.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'result':out['result'],'cases':{k:{f:v[f]for f in ['median_run_p95_ns','median_p95_reduction_ns','median_run_p99_ns','improved_pairs','adoption_bar_met']}for k,v in out['cases'].items()}},indent=2))
 return out
if __name__=='__main__':assess()
