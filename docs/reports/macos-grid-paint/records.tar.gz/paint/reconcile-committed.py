"""Verify the docs-only promotion and unchanged measured implementation."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('committed_grid_scope',W/'run.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
def read(p):return json.loads(p.read_text())
committed=read(W/'committed.json');plan=read(W/'plan.json');cp=read(q.h.C/'docs/reports/macos-grid-paint/checkpoint.json')
assert not cp['runtime_changed']and cp['source_base']==plan['head']
expected=set(cp['files'])|{'docs/reports/macos-grid-paint/'+n for n in['checkpoint.json','records.tar.gz']}
source=read(q.S/'integration-installed-v4.json')['files']
for root in[q.h.C,q.h.T]:
 assert q.git(root,'rev-parse','HEAD').decode().strip()==committed['commit']and not q.git(root,'status','--porcelain')
 assert set(q.git(root,'diff','--name-only',plan['head'],committed['commit']).decode().splitlines())==expected
 assert all(q.h.sha(root/n)==z for n,z in source.items())
 assert q.prepared(root)==plan['prepared']
 assert all(q.h.sha(root/n)==z for n,z in cp['files'].items())
 assert q.h.sha(root/'docs/reports/macos-grid-paint/records.tar.gz')==cp['archive']['sha256']
assert q.vector(Path(plan['sdk']))==plan['sdk_files']
d={'commit':committed['commit'],'canonical_clean':True,'candidate_clean':True,'runtime_changed':False,'measured_runtime_commit':plan['head'],'tracked_paths':len(q.git(q.h.C,'ls-files','-z').split(b'\0'))-1,'prepared_files':len(plan['prepared']),'prepared_sha256':hashlib.sha256(json.dumps(plan['prepared'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'sdk_unchanged':True,'native_app_executed':False,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(W/'promoted-unchanged.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
