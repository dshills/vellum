"""Current compiled Go route: full table matrix and separate allocation diagnostics."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
S=W.parent/'macos-grid-cell-surface-410a98c'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
prior=load('current_grid_prior',S/'native.py');h=prior.h;g=prior.g;b=prior.b;v=load('current_grid_validator',W/'validate.py')
HEAD='51dbe40521d34c76abcc1ab82300b394a55fdb01'
sys.path.insert(0,str(h.T/'scripts'))
from child_process import run_child
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def vector(root):
 out={}
 for p in root.rglob('*'):
  h.need(not p.is_symlink(),'regular source tree '+str(p))
  if p.is_file():out[p.relative_to(root).as_posix()]=h.sha(p)
 return out
def source(root):
 h.need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean current checkout')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1]
 h.need(len(names)==5323,'bounded current tracked source')
 return {n:h.sha(root/n)for n in names}
def prepared(root):
 return {module+'/'+n:z for module in['upstream','typesetting']for n,z in vector(root/'drivers/cogent/build'/module).items()}
def cases():
 out={}
 def add(name,gpu,variant='candidate',diagnostic=False,allocation=False,variable=False,rows=10000,**more):
  out[name]={'gpu':gpu,'binary':'diagnostic'if diagnostic else variant,'diagnostic':diagnostic,'allocation':allocation,'variable':variable,'rows':rows,**more}
 for mode in ['cpu','gpu']:add(mode+'-diagnostic',mode=='gpu',diagnostic=True)
 for mode in ['cpu','gpu']:
  for pair in range(1,6):
   for variant in (['baseline','candidate']if pair%2 else['candidate','baseline']):add(f'{mode}-pair{pair}-{variant}',mode=='gpu',variant,pair=pair)
 for mode in ['cpu','gpu']:
  for variant in ['baseline','candidate']:add('allocation-'+mode+'-'+variant,mode=='gpu',variant,allocation=True)
 for variable,rows in [(False,1000000),(True,10000),(True,1000000)]:
  for mode in ['cpu','gpu']:add(f'diagnostic-{mode}-{variable}-{rows}',mode=='gpu',diagnostic=True,variable=variable,rows=rows,extension=True)
 for rep in range(1,6):
  for variable,rows in [(False,1000000),(True,10000),(True,1000000)]:
   for mode in ['cpu','gpu']:add(f'candidate-{mode}-{variable}-{rows}-run{rep}',mode=='gpu',variable=variable,rows=rows,extension=True,repetition=rep)
 return out
CASES=cases()
def prepare():
 h.need(not(W/'plan.json').exists()and not(W/'stop-live').exists(),'fresh scope')
 scope=json.loads((W/'scope.json').read_text());sdk=Path(scope['sdk'])
 closure=json.loads((W.parent/'macos-grid-current-recovery-a2b4143/promoted-unchanged.json').read_text())
 old=json.loads((S/'native-plan.json').read_text());final=json.loads((S/'final-native/plan.json').read_text())
 h.need(vector(sdk)==old['sdk_files'],'retained SDK exact')
 current=source(h.C);h.need(source(h.T)==current,'C/T current source parity')
 dep=prepared(h.C);h.need(prepared(h.T)==dep==final['isolated_prepared'],'current exact stage80')
 installed=json.loads((S/'integration-installed-v4.json').read_text())
 h.need(all(h.sha(h.C/n)==z for n,z in installed['files'].items()),'committed reviewed source')
 for n,z in installed['files'].items():h.need(h.sha(W/'baseline'/n)==z,'current baseline '+n)
 review=json.loads((W/'internal-source-review.json').read_text());h.need(review['approved']and not review['unresolved_findings'],'source review approved')
 h.need(all(h.sha(k)==z for k,z in review['inputs'].items()),'review source identities')
 checks=['driver-all-v1','vet-v1','example-v1','build-v1','diag-build-v1']
 for name in checks:
  r=json.loads((W/(name+'.json')).read_text());h.need(r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors'],'terminal prerequisite '+name)
  for p in(W/'candidate').rglob('*'):
   if p.is_file():h.need(r['source_pins'].get(str(p))==h.sha(p),'checked final source '+name+str(p))
 binaries={'baseline':final['ordinary_binary'],'candidate':{'path':str(W/'grid-candidate'),'sha256':h.sha(W/'grid-candidate')},'diagnostic':{'path':str(W/'grid-diagnostic'),'sha256':h.sha(W/'grid-diagnostic')}}
 h.need(binaries['baseline']['sha256']=='81b85e39e2626d612ea61729a4085e289dd29b2332aa83d5ee85623db37f03db','correct current normal baseline')
 for value in binaries.values():h.need(h.sha(value['path'])==value['sha256'],'compiled binary pinned')
 paths=[p for p in(W/'candidate').rglob('*')if p.is_file()]+[W/n for n in ['scope.json','run.py','validate.py','controls.py','controls.json','assess.py','check.py','build-diagnostic.py','diagnostic-grid-geometry.go','integrated-diagnostic-overlay.json','internal-source-review.json','escape-source-correspondence.json']]+[W/(n+'.json')for n in checks]
 paths+=[h.GO,Path(h.__file__),h.GUARD,S/'native.py',S/'validate.py',prior.B/'run.py',prior.B/'validate.py',prior.B/'owned-executor.py',sdk/'scripts/benchmark-grid.py',h.T/'scripts/child_process.py',h.T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),S/'integration-installed-v4.json',S/'integrated-build-v3.json',S/'final-native/plan.json',W.parent/'macos-grid-current-recovery-a2b4143/promoted-unchanged.json']
 p={'head':HEAD,'launch_deadline_utc':scope['reassess_by_utc'],'source':current,'prepared':dep,'sdk':str(sdk),'sdk_files':old['sdk_files'],'pins':{str(p):h.sha(p)for p in paths},'binaries':binaries,'cases':CASES,'adoption_bar':{'median_run_p95_reduction_ns':400000,'improved_pairs_each_mode':4,'both_modes_required':True,'median_p99_nonincreasing':True,'p99_failed_runs_nonincreasing':True,'median_terminal_heap_allowance_bytes':1048576,'exact_pairwise_geometry':True},'scope':'Exactly26 initial cases:2 candidate route diagnostics,20 ordinary baseline/candidate fixed10k paired runs,4 separate sampledallocationcaptures. After those, recompute frozen pairedbar. If rejected, seal as successful measured rejection with36 extensioncases intentionally unexecuted. Only if bothmodes pass bar run6 remainingdiagnostics and30 remainingordinarycandidate cases: candidate full40ordinary/8diagnosticmatrix,10 extraordinarybaseline,4allocation =62total.120samples/128warm perprocess; unchanged4/6mstargets. No diagnostics/profile/escapecompiler flags in ordinarybinary. Current81b85 baseline not oldSDKwidgetbinary. Fixedstage80overlay over unchanged retained786aSDKnative, not defaultcheckout7d8/nativeSDKrefresh. Freshstop/sharedlease/330s8MiBownedprocessretirement; any error seals scope, no replay. No physical input/settings/operator/publicrelease.'}
 (W/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(W/'plan.json'),'cases':len(CASES),'source_files':len(current),'prepared_files':len(dep),'native_executed':False}))
def run():
 raw=(W/'plan.json').read_bytes();araw=(W/'admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw);stop=W/'stop-live';sdk=Path(p['sdk'])
 h.need(a['approved']and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'reviewed exact scope');h.need(not stop.exists()and not(W/'result.json').exists(),'fresh execution')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==araw and all(h.sha(k)==z for k,z in p['pins'].items())and all(h.sha(e['path'])==e['sha256']for e in p['binaries'].values())
 def boundary():
  h.need(not stop.exists()and stable(),'stop and exact pins');h.need(source(h.C)==source(h.T)==p['source']and prepared(h.C)==prepared(h.T)==p['prepared']and vector(sdk)==p['sdk_files'],'whole current source/prepared/SDK unchanged')
 def interrupted(signum,frame):raise InterruptedError('matrix signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted);result={'result':'INCOMPLETE','error':None,'completed':[],'native_executed':False,'full_mac_qualified':False}
 try:
  with g.LiveLease()as lease:
   for name,case in p['cases'].items():
    if case.get('extension')and 'assessment'in result and not result['assessment']['adoption_bar_met']:break
    if case.get('extension')and 'assessment'not in result:
     assessment=load('paint_assessment',W/'assess.py').assess();result['assessment']={'adoption_bar_met':assessment['adoption_bar_met'],'sha256':h.sha(W/'assessment.json')}
     if not assessment['adoption_bar_met']:break
    boundary();h.need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease and launch deadline');h.need(not(W/(name+'-result.json')).exists()and not(W/('stop-'+name)).exists(),'fresh case')
    exe=p['binaries'][case['binary']];args=[exe['path'],'-perf','-rows='+str(case['rows']),'-perf-warmup=128','-perf-samples=120']
    if case['variable']:args+=['-variable-rows']
    if case['gpu']:args+=['-gpu-scene']
    if case['diagnostic']:args+=['-perf-source-details']
    prefix=W/(name+'-alloc')
    if case['allocation']:args+=['-perf-alloc-profile='+str(prefix)]
    cr={'case':case,'result':'INCOMPLETE','error':None}
    try:
     r=g.execute(args,sdk/'examples/loadedgrid',W/name,lambda:stop.exists()or(W/('stop-'+name)).exists(),stable,timeout=330,limit=8<<20);cr['run']=r;result['native_executed']|=r['created']
     h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned terminal case '+name)
     h.need(not(W/name/'stderr').read_bytes(),'empty native stderr');summary=v.validate((W/name/'stdout').read_text(),case,sdk)
     if case['allocation']:
      cr['profiles']={}
      for suffix in['before','after']:
       f=Path(str(prefix)+'.'+suffix+'.pprof');h.need(f.is_file()and not f.is_symlink()and 0<f.stat().st_size<=64<<20,'bounded profile');cr['profiles'][suffix]={'path':str(f),'bytes':f.stat().st_size,'sha256':h.sha(f)}
     boundary();h.need(lease.held(),'lease through cleanup');cr.update(result='PASS_SCOPED_CURRENT_GRID_CASE',summary=summary,lease_held_through_cleanup=True);result['completed'].append(name)
    except BaseException as e:cr.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
    finally:
     (W/('stop-'+name)).touch();cr['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/(name+'-result.json')).write_text(json.dumps(cr,indent=2)+'\n');print(json.dumps({'case':name,'result':cr['result'],'error':cr['error'],'completed':len(result['completed']),'p95_ms':cr.get('summary',{}).get('ui_work_ns',{}).get('p95',0)/1e6}),flush=True)
   result['result']='MEASURED_CANDIDATE_FULL_MATRIX'if result['assessment']['adoption_bar_met']else'MEASURED_PRIVATE_REJECTION_NO_EXTENSION'
 except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':result['result'],'completed':len(result['completed']),'error':result['error']}),flush=True)
 if result['error']:sys.exit(1)
if __name__=='__main__':h.need(sys.argv[1:]in[['prepare'],['run']],'known fixed phase');prepare()if sys.argv[1]=='prepare'else run()
