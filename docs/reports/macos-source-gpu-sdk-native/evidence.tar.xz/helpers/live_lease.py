"""Cooperative exclusive ownership for these Mac acceptance controllers."""
from pathlib import Path
import fcntl,os,stat
LOCK_PATH=Path('/private/tmp/vellum-macos-live-oct15.lock')
class LiveLease:
 def __init__(self):self.fd=None;self.path=LOCK_PATH
 def __enter__(self):
  fd=os.open(self.path,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
  try:
   info=os.fstat(fd)
   if not stat.S_ISREG(info.st_mode)or info.st_uid!=os.getuid():raise ValueError('invalid owned live lease file')
   try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError as error:raise RuntimeError('another Vellum live fixture owns the shared lease')from error
  except BaseException:os.close(fd);raise
  self.fd=fd;return self
 def held(self):return self.fd is not None
 def __exit__(self,*ignored):
  fd=self.fd;self.fd=None
  if fd is not None:
   try:fcntl.flock(fd,fcntl.LOCK_UN)
   finally:os.close(fd)
