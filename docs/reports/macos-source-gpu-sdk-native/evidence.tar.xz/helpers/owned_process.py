"""One bounded native launch of the already compiled, relocated private SDK hello."""
from pathlib import Path
import datetime, hashlib, json, os, selectors, signal, subprocess, sys, time
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
P = Path('/private/tmp/vellum-sdk-native-238b3b6')
STOP = Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
HEAD = 'e88941b2c749cf8b4ce4ee8aee1081fcac966057'
SDK_SOURCE = '238b3b619e5ef274c218cb62d0b348e44e3fcaf8'
sys.path.insert(0, str(T/'scripts'))
sys.path.insert(0, '/private/tmp/vellum-empty-text-native-isolated-v2')
from child_process import run_child, terminate_owned_group
from sdk_environment import child_environment
from live_lease import LiveLease
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
def need(ok, message):
    if not ok: raise ValueError(message)
def identity(root):
    def git(*args): return run_child(['git', *args], cwd=root, capture_output=True, check=True, timeout=20).stdout
    need(git('rev-parse', 'HEAD').decode().strip() == HEAD and not git('status', '--porcelain', '-z'), 'clean exact current checkout')
    files = {}
    for n in git('ls-files', '-z').decode().split('\0')[:-1]:
        p = root/n; need(p.is_file() and not p.is_symlink(), 'tracked regular file'); files[n] = sha(p)
    prepared = {}
    for name in ['upstream', 'typesetting']:
        for p in (root/'drivers/cogent/build'/name).rglob('*'):
            need(not p.is_symlink(), 'prepared symlink')
            if p.is_file(): prepared[p.relative_to(root/'drivers/cogent/build').as_posix()] = sha(p)
    need(len(files) == 4658 and len(prepared) == 6246, 'current source counts')
    return dict(commit=HEAD, files=files, prepared=prepared)
def inputs_stable(pins): return all(sha(p) == h for p, h in pins.items())
def sdk_valid(provenance):
    root = Path(provenance['sdk_root']); manifest = read(root/'SDK_MANIFEST.json')
    need(manifest['source'] == dict(clean=True, commit=SDK_SOURCE) and manifest['private_build'] is True, 'private packaged source')
    need(len(manifest['files']) == 7411, 'SDK manifest count')
    leaves = {}
    for p in root.rglob('*'):
        need(not p.is_symlink(), 'SDK symlink')
        if p.is_file(): leaves[p.relative_to(root).as_posix()] = sha(p)
    expected = dict(manifest['files']); expected['SDK_MANIFEST.json'] = provenance['manifest_sha256']
    need(leaves == expected, 'complete SDK integrity')
def absent(pid):
    need(type(pid) is int and pid > 0, 'owned PID')
    result = run_child(['/bin/ps', '-axo', 'pid=,pgid=,stat='], env=child_environment(), capture_output=True, check=True, timeout=5)
    need(not result.stderr and result.stdout.strip(), 'process observation')
    for line in result.stdout.decode().splitlines():
        fields = line.split(); need(len(fields) == 3 and fields[0].isdecimal() and fields[1].isdecimal(), 'process fields')
        need(int(fields[1]) != pid, 'owned group remains')
    return dict(group=pid, members=[], observation_sha256=hashlib.sha256(result.stdout).hexdigest())
def retire(child):
    if child is None: return dict(created=False)
    d = dict(created=True, pid=child.pid, group=child.pid, terminal=False, group_absent=False, exit_code=None, errors=[])
    def failed(stage, error): d['errors'].append(dict(stage=stage, type=type(error).__name__, message=str(error)))
    try:
        if child.poll() is None:
            try: os.killpg(child.pid, signal.SIGTERM); child.wait(timeout=2)
            except (ProcessLookupError, subprocess.TimeoutExpired): pass
    except BaseException as e: failed('graceful-retirement', e)
    try: terminate_owned_group(child)
    except BaseException as e: failed('forced-group-retirement', e)
    try:
        if child.poll() is None: child.kill()
    except BaseException as e: failed('direct-child-fallback', e)
    try: d['exit_code'] = child.wait(timeout=5); d['terminal'] = child.poll() is not None
    except BaseException as e: failed('reap', e)
    for name in ['stdout', 'stderr']:
        try:
            pipe = getattr(child, name)
            if pipe is not None: pipe.close()
        except BaseException as e: failed(name+'-close', e)
    try: d['observation'] = absent(child.pid); d['group_absent'] = True
    except BaseException as e: failed('group-observation', e)
    return d
def execute(argv, cwd, out, stopping, stable, timeout=45, limit=8<<20):
    out.mkdir(mode=0o700); child = None; start = time.monotonic(); eof = [False, False]
    counts = [0, 0]; digests = [hashlib.sha256(), hashlib.sha256()]
    d = dict(argv=argv, cwd=str(cwd), started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), watchdog_seconds=timeout, error=None, exit_code=None, created=False, observation_errors=[], logs_complete=False, pins_stable=False, stop_at_exit=True)
    try:
        need(not stopping() and stable(), 'launch admission')
        with (out/'stdout').open('xb') as stdout, (out/'stderr').open('xb') as stderr, selectors.DefaultSelector() as ready:
            need(not stopping() and stable(), 'final launch admission')
            child = subprocess.Popen(argv, cwd=cwd, env={**child_environment(True), 'GOMAXPROCS':'2'}, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            d.update(created=True, pid=child.pid, group=child.pid)
            (out/'owned.json').write_text(json.dumps(dict(pid=child.pid, group=child.pid, argv=argv, cwd=str(cwd)), indent=2)+'\n')
            for i, pipe in enumerate([child.stdout, child.stderr]): ready.register(pipe, selectors.EVENT_READ, i)
            terminal = None
            while ready.get_map() or child.poll() is None:
                need(not stopping(), 'stop requested')
                if time.monotonic()-start > timeout: raise TimeoutError('native watchdog')
                if child.poll() is not None:
                    if terminal is None: terminal = time.monotonic()
                    if ready.get_map() and time.monotonic()-terminal > 3: raise TimeoutError('pipe writers survived child')
                for key, _ in ready.select(.05):
                    data = os.read(key.fd, 64<<10); i = key.data
                    if not data: eof[i] = True; ready.unregister(key.fileobj); continue
                    accepted = min(len(data), limit-counts[i])
                    if accepted:
                        need([stdout, stderr][i].write(data[:accepted]) == accepted, 'short log write'); [stdout, stderr][i].flush()
                        counts[i] += accepted; digests[i].update(data[:accepted])
                    need(accepted == len(data), 'log byte bound')
            d['exit_code'] = child.wait(timeout=5)
    except BaseException as e: d['error'] = dict(type=type(e).__name__, message=str(e))
    finally:
        d['owned'] = retire(child); d['seconds'] = time.monotonic()-start
        def failed(stage, e): d['observation_errors'].append(dict(stage=stage, type=type(e).__name__, message=str(e)))
        try:
            d['logs'] = {n: dict(bytes=(out/n).stat().st_size, sha256=sha(out/n)) for n in ['stdout', 'stderr'] if (out/n).exists()}
            d['logs_complete'] = all(eof) and all(d['logs'][n] == dict(bytes=counts[i], sha256=digests[i].hexdigest()) for i,n in enumerate(['stdout','stderr']))
        except BaseException as e: failed('log-observation', e)
        try: d['pins_stable'] = stable()
        except BaseException as e: failed('pin-observation', e)
        try: d['stop_at_exit'] = stopping()
        except BaseException as e: failed('stop-observation', e)
    return d
def validate_record(stdout):
    records = []
    for line in stdout.splitlines():
        try: value = json.loads(line)
        except (ValueError, UnicodeDecodeError): continue
        if isinstance(value, dict) and value.get('event') == 'vellum.native.ready': records.append(value)
    need(len(records) == 1, 'exactly one native ready record'); r = records[0]
    need(r.get('geometry_persistence_disabled_in_fixture') is True, 'geometry persistence disabled')
    for n in ['startup_to_verified_gpu_ns', 'heap_alloc_bytes', 'width', 'height']:
        need(type(r.get(n)) is int and 0 < r[n] < 1<<63, 'positive bounded metric '+n)
    need(isinstance(r.get('render_readback_ns'), list) and len(r['render_readback_ns']) == 3 and all(type(n) is int and 0 < n < 45_000_000_000 for n in r['render_readback_ns']), 'three readback samples')
    need(isinstance(r.get('go_version'), str) and 0 < len(r['go_version']) < 100, 'Go version')
    return r
def fresh_output(root):
    need(not (root/'receipt.json').exists() and not (root/'run').exists(), 'fresh native output; no restart')
def finalize(root, d):
    d['finalization_errors'] = []; d['local_stop_present'] = False
    try: (root/'stop-live').touch(); d['local_stop_present'] = True
    except BaseException as e: d['finalization_errors'].append(dict(stage='seal-stop', type=type(e).__name__, message=str(e)))
    d['result'] = 'PASS_SCOPED_PRIVATE_SDK_NATIVE_SMOKE' if d['error'] is None and not d['finalization_errors'] else 'FAILED_OR_CANCELED_PRIVATE_SDK_NATIVE_SMOKE'
    try:
        with (root/'receipt.json').open('x') as f: f.write(json.dumps(d, indent=2)+'\n')
    except BaseException as e:
        d['finalization_errors'].append(dict(stage='exclusive-receipt', type=type(e).__name__, message=str(e)))
        d['result'] = 'FAILED_OR_CANCELED_PRIVATE_SDK_NATIVE_SMOKE'
    return d
def main():
    need(len(sys.argv) == 1, 'no runtime overrides')
    fresh_output(P)
    review = read(W/'readiness.json'); need(review['execution_ready'] is True and review['unresolved_findings'] == [], 'internal execution approval')
    pins = review['inputs']; provenance = read(W/'provenance.json'); source = read(P/'source.json')
    stopping = lambda: STOP.exists() or (P/'stop-live').exists()
    stable = lambda: inputs_stable(pins)
    need(not stopping() and stable(), 'initial admission')
    d = dict(source_commit=SDK_SOURCE, current_checkout_commit=HEAD, producer_sha256=sha(__file__), review_sha256=sha(W/'readiness.json'), native_runtime_executed=False, public_distribution=False, physical_input_generated=False, settings_changes=False, full_macos_qualified=False, error=None)
    try:
        with LiveLease() as lease:
            need(lease.held() and not stopping() and stable(), 'lease admission')
            need(identity(T) == source and identity(C) == source, 'current source parity'); sdk_valid(provenance)
            d['run'] = execute([provenance['binary']['path'], '--benchmark', '--idle=1s', '--samples=3'], Path(provenance['sdk_root'])/'examples/hello', P/'run', stopping, stable)
            run = d['run']; d['native_runtime_executed'] = run['created']
            need(run['error'] is None and not run['observation_errors'] and run['exit_code'] == 0 and run['owned']['terminal'] and run['owned']['group_absent'] and not run['owned']['errors'] and run['logs_complete'] and run['pins_stable'] and not run['stop_at_exit'], 'native launch failed or canceled')
            d['native_record'] = validate_record((P/'run/stdout').read_bytes())
            d['source_stable'] = identity(T) == source and identity(C) == source; sdk_valid(provenance)
            d['sdk_stable'] = True; d['pins_stable'] = stable(); d['lease_held_through_cleanup'] = lease.held()
            need(d['source_stable'] and d['pins_stable'] and not stopping(), 'final stability')
    except BaseException as e: d['error'] = dict(type=type(e).__name__, message=str(e))
    finally:
        finalize(P, d); print(json.dumps(d), flush=True)
    need(d['error'] is None and not d['finalization_errors'], 'native smoke failed')
if __name__ == '__main__': main()
