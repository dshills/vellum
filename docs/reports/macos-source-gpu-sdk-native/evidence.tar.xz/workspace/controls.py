"""Exercise refusal boundaries without launching a child or GPU."""
from pathlib import Path
import contextlib, copy, importlib.util, io, json, tempfile
from unittest import mock
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('sdk_retained_controls',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
checks=[]
def ok(name):checks.append(name)
def refuses(name, action):
 try:action()
 except ValueError:ok(name)
 else:raise AssertionError('did not refuse: '+name)
with tempfile.TemporaryDirectory(prefix='vellum-retained-sdk-controls-')as tmp:
 root=Path(tmp);file=root/'input';file.write_bytes(b'original');pins={};m.pin_once(pins,file);m.pin_once(pins,str(file));ok('new and repeated unchanged pin')
 original=dict(pins);file.write_bytes(b'drift');refuses('known input cannot rebase',lambda:m.pin_once(pins,file));assert pins==original
 fresh=root/'new';fresh.write_bytes(b'bytes');refuses('explicit wrong expected digest',lambda:m.pin_once(pins,fresh,'0'*64));assert str(fresh)not in pins
 m.fresh_outputs(root/'absent');ok('missing output accepted')
 refuses('regular output refused',lambda:m.fresh_outputs(file))
 directory=root/'directory';directory.mkdir();refuses('directory output refused',lambda:m.fresh_outputs(directory))
 link=root/'dangling';link.symlink_to(root/'missing');refuses('dangling output symlink refused',lambda:m.fresh_outputs(link))
 sdk=root/'sdk';sdk.mkdir();(sdk/'SDK_MANIFEST.json').write_text('{}');(sdk/'source').write_bytes(b'source');manifest=dict(files={'source':m.sha(sdk/'source')});m.sdk_identity(sdk,manifest);ok('exact SDK tree accepted')
 (sdk/'extra').write_bytes(b'extra');refuses('extra SDK leaf refused',lambda:m.sdk_identity(sdk,manifest));(sdk/'extra').unlink()
 (sdk/'source').write_bytes(b'drift');refuses('SDK byte drift refused',lambda:m.sdk_identity(sdk,manifest));(sdk/'source').unlink();(sdk/'source').symlink_to(file);refuses('SDK symlink refused',lambda:m.sdk_identity(sdk,manifest))
 base=dict(created=True,exit_code=0,error=None,observation_errors=[],logs_complete=True,pins_stable=True,stop_at_exit=False,owned=dict(terminal=True,group_absent=True,errors=[]));assert m.terminal(base);ok('complete owned terminal accepted')
 for key,value in [('created',False),('exit_code',1),('error',{}),('observation_errors',['failure']),('logs_complete',False),('pins_stable',False),('stop_at_exit',True)]:
  d=copy.deepcopy(base);d[key]=value;assert not m.terminal(d);ok('terminal refuses '+key)
 for key,value in [('terminal',False),('group_absent',False),('errors',['failure'])]:
  d=copy.deepcopy(base);d['owned'][key]=value;assert not m.terminal(d);ok('terminal refuses owned '+key)
 for case in ['success','prior-error','seal-error','report-error','receipt-error']:
  case_root=root/case;case_root.mkdir();(case_root/'private').mkdir();(case_root/'workspace').mkdir()
  d=dict(result='INCOMPLETE',error=None if case!='prior-error' else dict(message='retained original failure'),finalization_errors=[],commands=[],inputs={})
  with mock.patch.object(m,'P',case_root/'private'),mock.patch.object(m,'W',case_root/'workspace'),contextlib.redirect_stdout(io.StringIO()):
   context=contextlib.ExitStack()
   with context:
    if case=='seal-error':context.enter_context(mock.patch.object(Path,'touch',side_effect=PermissionError('injected seal error')))
    if case=='report-error':context.enter_context(mock.patch('builtins.print',side_effect=BrokenPipeError('injected report error')))
    if case=='receipt-error':context.enter_context(mock.patch.object(m,'exclusive',side_effect=OSError('injected receipt error')))
    if case=='success':m.finish('control',d);assert d['result']=='PASS_CONTROL'
    else:refuses('finalization fails '+case,lambda:m.finish('control',d));assert d['result']=='FAILED_CONTROL'
  if case=='success':ok('success requires exclusive receipt');assert json.loads((case_root/'workspace/control.json').read_bytes())['result']=='PASS_CONTROL'
  elif case!='receipt-error':assert json.loads((case_root/'workspace/control.json').read_bytes())['result']=='FAILED_CONTROL'
body=dict(result='PASS_RETAINED_SDK_GUARD_CONTROLS',count=len(checks),checks=checks,producer_sha256=m.sha(__file__),runner_sha256=m.sha(W/'run.py'),native_runtime_executed=False,child_process_created=False)
with(W/'controls.json').open('x')as out:out.write(json.dumps(body,indent=2)+'\n')
print(json.dumps(dict(result=body['result'],count=body['count'])))
