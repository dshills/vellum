"""Package the independently reviewed clean SDK consumer evidence."""
from pathlib import Path
import hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-gpu-sdk-native');T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=W/'report'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
MAX_MEMBERS=256
MAX_EXPANDED=128<<20
MAX_COMPRESSED=32<<20
def need(ok,msg):
 if not ok:raise ValueError(msg)
class BoundedWriter:
 def __init__(self,stream,bound):self.stream,self.bound=stream,bound
 def write(self,body):
  need(self.stream.tell()+len(body)<=self.bound,'compressed evidence byte bound')
  return self.stream.write(body)
 def tell(self):return self.stream.tell()
 def flush(self):return self.stream.flush()
def main():
 need(not R.exists(),'fresh report output')
 review_body=(W/'result-review.json').read_bytes();review_sha=hashlib.sha256(review_body).hexdigest();review=json.loads(review_body);need(review['report_ready'] and not review['unresolved_findings'],'independent final result review')
 reviewed=lambda:sha(W/'result-review.json')==review_sha and all(sha(p)==h for p,h in review['inputs'].items())
 need(reviewed(),'reviewed result bytes')
 build,native=read(W/'build.json'),read(W/'native.json')
 need(build['result']=='PASS_BUILD' and native['result']=='PASS_NATIVE' and all(d['error']is None and not d['finalization_errors']for d in [build,native]),'both owned phases pass')
 need(native['native_execution']=='qualified_three_readbacks' and len(native['native_record']['render_readback_ns'])==3,'exact qualified native fixture')
 need('PENDING'not in(W/'README.final.md').read_text(),'completed prose')
 need(read(W/'sdk-payload-comparison.json')['result']=='EXACT_SAME_7436_MANIFEST_PAYLOAD_HASHES','explicit dirty versus clean payload comparison')
 sdk=Path(build['sdk_root']);manifest=read(sdk/'SDK_MANIFEST.json')
 entries={}
 def add(name,path):
  p=Path(path);need(name not in entries and p.is_file() and not p.is_symlink(),'regular unique evidence')
  need(p.stat().st_size<=32<<20,'bounded evidence member');entries[name]=p
 for p in sorted(W.rglob('*')):
  if p.is_file() and not p.is_symlink() and not p.is_relative_to(R) and not any(part.startswith('checkpoint-')or part in ['__pycache__','commit-logs']for part in p.relative_to(W).parts):add('workspace/'+p.relative_to(W).as_posix(),p)
 for item in build['commands']+[dict(name='native',run=native['run'])]:
  run=item['run'];need(run['owned']['terminal'] and run['owned']['group_absent'] and not run['owned']['errors'],'owned terminal groups')
  for name in ['stdout','stderr','owned.json']:
   path=P/item['name']/name
   if name in run['logs']:need(run['logs'][name]==dict(bytes=path.stat().st_size,sha256=sha(path)),'retained command log identity')
   add('runs/'+item['name']+'/'+name,path)
 add('build/hello.linkmap',build['linkmap']['path'])
 for p in sorted((P/'independent application').iterdir()):add('generated-app/'+p.name,p)
 for name in ['SDK_MANIFEST.json','THIRD_PARTY_INVENTORY.json']:
  add('sdk-metadata/'+name,sdk/name)
 for name in manifest['native_gpu']['go_mod_overlays']:add('sdk-modules/'+name,sdk/name)
 for name in ['go.mod','libs.go','PROVENANCE.json']:add('sdk-capsule/'+name,sdk/'drivers/cogent/build/libs-darwin'/name)
 helpers={'owned_process.py':W.parent/'macos-sdk-native-238b3b6/run.py','live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')}
 for name in ['child_process.py','sdk_environment.py','native_archive.py','native_gpu.py','check-sdk.py','release-sdk.py','new-app.py']:helpers[name]=T/'scripts'/name
 for name,path in helpers.items():add('helpers/'+name,path)
 index={name:dict(bytes=path.stat().st_size,sha256=sha(path))for name,path in sorted(entries.items())}
 need(len(index)<=MAX_MEMBERS and sum(item['bytes']for item in index.values())<=MAX_EXPANDED,'total evidence member and expanded bounds')
 principal=[P/'sdk.tar.gz',P/'hello',sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a']
 excluded=[dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))for path in principal]
 R.mkdir()
 with(R/'evidence.tar.xz').open('xb')as raw:
  with tarfile.open(fileobj=BoundedWriter(raw,MAX_COMPRESSED),mode='w:xz',preset=6)as archive:
   for name,path in sorted(entries.items()):
    body=path.read_bytes();need(hashlib.sha256(body).hexdigest()==index[name]['sha256'],'stable evidence origin')
    info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(body))
 need((R/'evidence.tar.xz').stat().st_size<=MAX_COMPRESSED,'complete compressed evidence bound')
 with tarfile.open(R/'evidence.tar.xz','r:xz')as archive:
  need(archive.getnames()==sorted(index),'exact archive membership')
  for item in archive:
   body=archive.extractfile(item).read();need(len(body)==index[item.name]['bytes']and hashlib.sha256(body).hexdigest()==index[item.name]['sha256'],'readback evidence hash')
 evidence=dict(files=index,archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz')),limits=dict(members=MAX_MEMBERS,expanded_bytes=MAX_EXPANDED,compressed_bytes=MAX_COMPRESSED,member_bytes=32<<20),excluded_principal_artifacts=excluded,other_exclusions='Go/cache/temp files, unrelated system/user data and full system tool bytes omitted. Selected source/tool fingerprints remain in phase receipts. Principal artifacts retained separately in the local workspace checkpoint.')
 (R/'evidence.manifest.json').write_text(json.dumps(evidence,indent=2)+'\n')
 result=dict(result='PASS_CLEAN_PRIVATE_SDK_NATIVE_CONSUMER',sdk_source=build['sdk_source'],sdk_archive=build['archive'],sdk_files=build['sdk_files'],module_origins=build['module_origins'],consumer_packages=build['consumer_packages'],binary=build['binary'],linkmap=build['linkmap'],selected_static_archive_entries=len(build['selected_archive_members']),native_record=native['native_record'],native_execution=native['native_execution'],owned_group_absent=native['run']['owned']['group_absent'],native_run_seconds=native['run']['seconds'],compiler_warning=build['commands'][4]['run']['logs']['stderr'],sdk_payload_comparison=read(W/'sdk-payload-comparison.json'),guard_controls=27,provider_calls=0,review='Internal build admission, actual build/linkage result review, separate native admission and final result review. No new provider call; previous implementation has separately retained Anthropic Prism review.',result_review_sha256=review_sha,settings_changes=False,physical_input_generated=False,presentation_qualified=False,ordinary_frame_latency_qualified=False,native_gpu_memory_qualified=False,full_macos_qualified=False,public_distribution_qualified=False)
 (R/'result.json').write_text(json.dumps(result,indent=2)+'\n');(R/'README.md').write_bytes((W/'README.final.md').read_bytes())
 need(reviewed(),'terminal result/certificate stability')
 print(json.dumps(dict(result='PACKAGED',members=len(index),archive=evidence['archive'])))
if __name__=='__main__':main()
