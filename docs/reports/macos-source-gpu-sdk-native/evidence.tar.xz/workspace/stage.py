"""Stage only the clean private SDK native evidence and its documentation."""
from pathlib import Path
import hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='3da753ed4e49ef18ca5ef2377c171efb970b46a1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=60)
def main():
 assert not(W/'binding.json').exists()
 review=read(W/'result-review.json');assert review['report_ready'] and not review['unresolved_findings'] and all(sha(p)==h for p,h in review['inputs'].items())
 for root in [T,C]:assert git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain','-z')
 report=W/'report';manifest=read(report/'evidence.manifest.json');assert manifest['archive']==dict(bytes=(report/'evidence.tar.xz').stat().st_size,sha256=sha(report/'evidence.tar.xz'))
 result=read(report/'result.json');assert result['result']=='PASS_CLEAN_PRIVATE_SDK_NATIVE_CONSUMER' and result['sdk_source']==dict(clean=True,commit=HEAD) and result['selected_static_archive_entries']==141 and result['owned_group_absent']
 target=Path('docs/reports/macos-source-gpu-sdk-native')
 sources={str(target/n):(report/n).read_bytes()for n in ['README.md','result.json','evidence.manifest.json','evidence.tar.xz']}
 name='docs/reports/README.md';text=(C/name).read_text();needle='- [Private source-built GPU SDK overlay]';assert text.count(needle)==1
 sources[name]=text.replace(needle,'- [Clean private SDK native consumer](macos-source-gpu-sdk-native/README.md)\n\n'+needle,1).encode()
 paragraph='''The [clean private SDK native consumer](%s)
builds the explicit ARM64 GPU overlay from committed `3da753e`, verifies all
7,436 SDK payload hashes and five local module origins, and links 141 exact
packaged static-archive entries with no WGPU dylib dependency. The retained Go
1.27.2 ARM64 executable declares minimum macOS 13.0 and passes one owned native
starter check: initial Snapshot center predicate `G >= 100, R <= 150, B >= 80`,
three further successful GPU Snapshot/readback calls, geometry persistence
disabled and normal closure/group absence. Compiler warnings remain retained.
All payload hashes equal the earlier non-GUI-tested precommit SDK, with changed
source/untracked metadata recorded separately. This is a private compatibility
checkpoint; full-image/presentation, physical/human workflows, ordinary frame
latency, native/GPU memory, endurance, rights/public release and full Mac
acceptance remain open. Internal reviews cover build, native admission/results
and report packaging; no new Prism call for this evidence-only checkpoint.
'''
 name='docs/implementation.md';sources[name]=((C/name).read_text()+'\n'+paragraph%'reports/macos-source-gpu-sdk-native/README.md').encode()
 name='specs/macos-completion.md';text=(C/name).read_text();needle='## Latest unattended evidence\n\n';assert text.count(needle)==1
 sources[name]=text.replace(needle,needle+paragraph%'../docs/reports/macos-source-gpu-sdk-native/README.md'+'\n',1).encode()
 name='specs/sdk.md';sources[name]=((C/name).read_text()+'''
## Clean private Mac candidate verification

The [clean SDK consumer evidence](../docs/reports/macos-source-gpu-sdk-native/README.md)
binds one `3da753e` private SDK to an independently generated native starter after
relocation with spaces. All 7,436 payload hashes match the prior non-GUI-tested
precommit archive; source/untracked manifest metadata is separately identified.
The retained ARM64 Go 1.27.2 build declares minimum macOS 13.0, maps 141 entries
to exact packaged static-archive members and has no WGPU dylib dependency.
One separately admitted native run passes the permissive initial Snapshot center
predicate and three further successful Snapshot calls, then retires its owned
group. Image-wide equality, compositor presentation, physical input, ordinary
latency/memory/endurance, other SDK candidates and public distribution are not
qualified by this check. The raw warnings and internal reviews remain retained.
''').encode()
 links=0
 for name,body in sources.items():
  if not name.endswith('.md'):continue
  for dest in re.findall(r'\[[^\]]*\]\(([^\n)]+)\)',body.decode()):
   dest=dest.strip('<>').split('#',1)[0]
   if not dest or ':'in dest or dest.startswith('/'):continue
   path=(C/name).parent.joinpath(dest).resolve();relative=str(path.relative_to(C));assert relative in sources or path.exists(),(name,dest);links+=1
 for name,body in sources.items():p=T/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(sources)
 git(T,'add','--',*sorted(sources));git(T,'diff','--cached','--check')
 assert not git(T,'diff','--name-only') and not git(T,'ls-files','--others','--exclude-standard') and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(sources)
 diff=git(T,'diff','--cached','--binary');(W/'staged.diff').write_bytes(diff)
 binding=dict(base_commit=HEAD,sources={n:sha(T/n)for n in sources},staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(diff),source_files=4726,prepared_files=6249,relative_file_links=links)
 assert len(git(T,'ls-files','-z').decode().split('\0')[:-1])==4726
 with(W/'binding.json').open('x')as out:out.write(json.dumps(binding,indent=2)+'\n')
 print(json.dumps(dict(result='STAGED_EIGHT_EVIDENCE_DOCUMENTS',files=len(sources),bytes=len(diff),sha256=binding['staged_diff_sha256'],links=links)))
if __name__=='__main__':main()
