# Next macOS services acceptance checks

Use one small single-window `cmd/native-services-smoke` (or an opt-in services mode in the existing editor) with a bounded worker, deterministic command counters and a unique temporary-directory manifest. The public services already cover the operations; no production OS preference or input-source change is needed. Service calls must stay outside owner/native callbacks.

1. Establish real panel visibility and use actual Open/Save/Cancel controls, checking only owned paths. SaveFile selects a destination without writing it.
2. Inspect and activate the installed AppKit menu item, then observe exactly one owner command. Keep external menu-click/keyboard traversal distinct from in-process AppKit action coverage.
3. Reuse file-drop-smoke `-interactive -timeout 120s <absolute owned temp path>` for Finder drag. Its selector fixture is already qualified; prior physical attempt timed out.
4. Do not run the existing text-only clipboard restoration flag on an ordinary clipboard. A private pasteboard fixture is safe but does not close the general-service gate. A real transaction needs complete bounded flavor backup/restoration plus interference policy first.
5. Once panel selection passes, run editor Save As/Open with Choose=nil and known temporary bytes to extend the existing settlement/persistence evidence.

Future receipts should retain current selected source/prepared hashes, exact built binary hash, commands, timeout/exit, ordered stages, actual action route, returned path equality/counter/history evidence and owned-file cleanup. Keep no user clipboard payload in logs. No new acceptance runtime, UI or test was run for this review; Windows/Linux remain deferred.
