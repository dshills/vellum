# Existing editor: real chooser acceptance without a new consumer

Yes. Launch the ordinary `examples/editor` binary with **no flags or positional paths**. `run(false)` creates `editor-one` and `editor-two`; neither supplies `windowOptions.choose` or a store. `document.New` supplies `FileStore`, and its chooser calls real `Services.ChooseFile` when `Choose=nil`. Toolbar actions pass an empty path and settle originating native input before starting persistence. This is sufficient for a bounded actual Open / Save As / native Cancel workflow without editing the application.

## Future launch and ownership

Use a source-bound, already-built editor binary; capture its SHA, selected source/prepared identities and stdout/stderr. Example future build context (not executed by this review): source `drivers/cogent/env.sh`, build from `examples/editor`, output to a unique `/private/tmp` acceptance directory. Launch argv `[absolute_binary]` from that owned directory. The ordinary app has no watchdog or READY/PASS output, so the external orchestrator must own its process, use a bounded overall deadline (for example 180 seconds), and record forced termination as failure rather than normal shutdown. Do not use `-smoke` for this workflow: it performs unrelated deterministic actions.

Create only a fresh temporary directory, a small known valid UTF-8 `input <unique-token> Ω.txt`, and a unique initially absent `saved <unique-token> Ω.txt` destination. Keep exact expected bytes/hashes outside the app. The CLI does not load positional paths. Preflight already-available automation trust without prompting/changing preferences. Find the owned PID's two windows, raise `Vellum document editor — editor-one`, and retain its window identity; leave `editor-two` untouched as a survivor. Wait for visible enabled Open…/Save As… buttons and the document/filename/status elements before acting.

## Deterministic action sequence

1. **Actual Open.** Press the first window's `Open…` toolbar button once. Wait for the actual Cocoa panel titled `Open document`; navigate using the panel's normal Go to Folder UI (Command-Shift-G) to the owned temporary directory, select the exact fixture filename and activate its Open button. Check the selected path belongs to the manifest before confirming. Wait for panel disappearance, `Document opened`, the fixture basename without ` • Unsaved`, exact Document text AX value, and re-enabled Open/Save As with Cancel operation disabled. Re-read only the owned input file to prove it was unchanged.
2. **Actual Save As Cancel.** Press `Save As…`; wait for `Save document`. Navigate to the owned directory and enter the unique destination name, then activate the panel's **Cancel** button. Expect `Document operation canceled`, unchanged document text and filename, normal enabled toolbar state, and no destination file. This exercises user-panel cancellation (`app.ErrCanceled`), not application `Cancel operation`/context cancellation.
3. **Actual Save As acceptance.** Press `Save As…` again, navigate/enter the same owned nonexistent destination, verify its path/extension, and activate native Save. Wait for `Document saved`, saved basename without Unsaved, normal toolbar state, and the new file containing exact known input bytes. Do not accept an overwrite confirmation or any destination outside the manifest. This verifies real panel choice plus FileStore persistence; `ChooseFile` alone is not a file writer.
4. **Open Cancel and recovery.** Press `Open…` from the now-clean document; activate native Cancel. Require canceled status, same saved basename/text, unchanged file bytes and restored controls. Optionally open a second owned file with different known contents; exact AX text plus filename/status proves owner installation. Dirty Open adds a separate managed decision dialog (`Discard and Open…` / `Cancel`); keep that out of the minimum clean workflow unless explicitly exercising it.
5. **Normal close.** Close the clean first window through its native close control, observe the untouched second window remains usable, then close its clean native window. Require both gone and process exit 0 with no `editor native:` errors. If timeout occurs, retire only the owned process and classify refusal/failure honestly.

## Exact controls and observations

Consumer node IDs are `open`, `save`, `save-as`, `cancel-operation`, `document`, `filename`, `status`, `undo`, `redo`; text area name is `Document text`. Native accessibility IDs are `node:` plus raw-URL-base64 of the node ID. Labels expose their text as AXValue; the multiline control exposes exact visible text/selection. Identify controls within the retained first-window hierarchy, not by a global label search across both windows. Use native AXPress or actual pointer activation, followed by observed transitions; an action admission result alone is not completion.

There is **no** registered consumer command registry/menu or documented Meta+O/Meta+S/Meta+Shift+S route here. Use toolbar controls, not guessed shortcuts. Tab in the document inserts text (`TabInserts=true`); it is not a reliable escape to the toolbar. Standard native panel navigation keys are separate from editor shortcuts. Avoid clipboard-based text injection.

Existing `-ax-fixture` is an optional one-window alternative: it also leaves Choose=nil, prints PID/known text as `EDITOR_AX_FIXTURE`, and closes after 60 seconds. Its short lifetime and read-only-inspector purpose make ordinary no-flag mode with an external deadline preferable for several dialogs. The current `check-editor-accessibility.py` always launches `-ax-fixture` and is read-only; it cannot directly drive this workflow. Its existing no-prompt trust check and owned-process patterns can be reused by an external receipt orchestrator.

## Evidence limits

Record ordered external action/observation receipts, native panel title/mode/selected owned path, exact file bytes, AX document/filename/status/enabled state, source/binary hashes and final exit. Ordinary mode prints no full owner session path, revision, operation number or result counter. Basename/status alone cannot prove those internal values; exact owned destination bytes and panel path evidence are needed. The richer `actionState`/`press` helpers in smoke.go are private and only called by `-smoke`; they are not a public out-of-process receipt hook. An optional observation-only owner snapshot hook would be needed only if the next gate insists on exact internal path/revision/CAS telemetry.

This closes selected-panel/document workflow evidence at the observed scope; it does not test menu activation, clipboard roundtrip, Finder drag, human IME/VoiceOver, preferences, or Windows/Linux. No new fixture or production change is necessary for the minimum chooser checks. No application launch, UI, build, test, provider or Git operation was run for this plan.

## Selected source identities

- `examples/editor/main.go`: `548d2002b0864e6c638f7b1b02b056cb62d28d84d1ea0a5a30d446d3f7c6cfc4`
- `examples/editor/document.go`: `edde07061196f6b8ce1e93bfa142e52db56f83186bcdf5e040cfa422fff3c5fe`
- `examples/editor/smoke.go`: `a1331f71ad02a183bdaccb7cce5b4debc3f7bbefe0745459fbc630e3c86d2744`
- `examples/editor/README.md`: `9980f95671e6ae64989af7a0dc3137c37e99182726c26e337ec31d9fb363c37f`
- `document/session.go`: `0257151d6bcfae89bb51e77573d1abc1cc7abf28bdabb16ec8cade2c4573a2eb`
- `drivers/cogent/services_darwin.m`: `17c0a89037f9f1106e499f17c0bdae6bddb26b57e7b7b1b337cb542711f98ef2`
- `drivers/cogent/accessibility.go`: `76c4b1adce00b21a992e2bdfa599b3f25c6b3adba1336f5c620b68404bb7143a`
- `drivers/cogent/accessibility_darwin.go`: `a745af3d8046deee71312410688ab2a0f7c40cde2a429b84a23b148eeedf1cb9`
- `scripts/check-editor-accessibility.py`: `dd9ac257060f8b3595832118507092e2a0188b511f9b5faea27be5f95f66eab3`
- `scripts/check-editor-accessibility.swift`: `a4846a841f6fb212be13489a30f0c60f60063db97f74e284d1956f49078a8cf7`
