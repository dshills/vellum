import hashlib,json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-storage-readback');records=r/'docs/reports/macos-storage-readback/records';certificate=Path('/private/tmp/vellum-storage-evidence-review/evidence-review-final.json')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();q=json.loads((p/'qualification.json').read_text());e=json.loads(certificate.read_text())
assert not e['findings']
for n,h in e['reviewed_artifact_sha256'].items():assert sha(Path(n))==h,(n,'reviewed evidence changed')
for n,h in q['source'].items():assert sha(r/n)==h
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()};assert prepared==q['prepared'] and len(prepared)==6195
(records/'evidence-review.json').write_bytes(certificate.read_bytes())
index=json.loads((records/'evidence-index.json').read_text())
checkpoint={'result':'PASS_STORAGE_READBACK_OWNERSHIP','base_commit':q['base_commit'],'qualification_sha256':sha(p/'qualification.json'),'source':q['source'],'decoded_outputs':q['decoded_outputs'],'source_review_sha256':sha(records/'source-review.json'),'evidence_review_sha256':sha(records/'evidence-review.json'),'post_test_document_sha256':sha(records.parent/'README.md'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_reviewed_files':8,'prism_raw_exit_code':0,'prism_findings':0,'prism_findings_resolved':True,'archive':{'sha256':sha(records/'evidence.tar.gz'),'index_sha256':sha(records/'evidence-index.json'),'members':len(index)},'prepared_files':6195,'raw_receipts':len(q['receipts']),'failed_receipts_preserved':sum(x['exit_code']!=0 for x in q['receipts'].values()),'python_preparation_tests':11,'native_compiled_sha256':q['native_build_sha256'],'final_owned_source_headless_gpu_executed':True,'final_owned_source_native_window_executed':False,'headless_gpu_observations':q['native_observations'],'physical_gpu_fault_injection':False,'native_memory_qualified':False,'gpu_memory_qualified':False,'sustained_performance_qualified':False,'macos_completion':False,'next_live_tests_deferred':True}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
print(json.dumps({'checkpoint_sha256':sha(records/'checkpoint.json'),'evidence_review_sha256':sha(certificate),'sealed_artifacts_reasserted':len(e['reviewed_artifact_sha256'])}))
