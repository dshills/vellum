# Storage readback candidate V2 review

NEEDS_FIX: ReadToBytes must quarantine its attached staging after refused unmap; currently it remains Ready and can be read again. Batch rollback already follows the required quarantine policy.

The six observed leaves are source-bound in review.json. The author race receipt is supporting evidence only; this reviewer ran no tests or native code. Buffer-backed StorageTexture fidelity, automatic staging repair, callback-channel isolation and temporary layout retirement are otherwise sound under serialized ownership. No live or performance acceptance is implied.
