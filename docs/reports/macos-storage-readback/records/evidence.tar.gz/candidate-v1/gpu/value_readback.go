// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"cogentcore.org/core/base/errors"
	"fmt"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// Buffer shape arithmetic is checked before native allocation or Go slicing.
// Texture readback uses Texture's distinct layout/copy contract.
func (vl *Value) bufferSizeChecked() (int, error) {
	if vl == nil || vl.Texture != nil {
		return 0, fmt.Errorf("gpu: buffer value required")
	}
	stride, count := vl.VarSize, vl.ArrayN
	if vl.isDynamic {
		stride, count = vl.AlignVarSize, vl.dynamicN
	}
	if count < 0 || stride < 1 || count > int(^uint(0)>>1)/stride {
		return 0, fmt.Errorf("gpu: invalid or overflowing value buffer shape")
	}
	return stride * count, nil
}
func (vl *Value) storageReadSize() (int, error) {
	if vl == nil || vl.vvar == nil || (vl.role != Storage && vl.role != StorageTexture) || vl.vvar.ReadOnly {
		return 0, fmt.Errorf("gpu: writable storage buffer required")
	}
	size, err := vl.bufferSizeChecked()
	if err != nil {
		return 0, err
	}
	if size < 1 || size%4 != 0 {
		return 0, fmt.Errorf("gpu: readback size must be positive and four-byte aligned")
	}
	return size, nil
}
func (vl *Value) bufferAdmission() error {
	if vl == nil || vl.vvar == nil || !vl.device.Device.IsValid() || !vl.device.Queue.IsValid() {
		return fmt.Errorf("gpu: buffer requires a live device, queue and variable")
	}
	if vl.readMapped {
		return fmt.Errorf("gpu: mapped readback must be consumed or released before upload")
	}
	return nil
}
func (vl *Value) reusableBuffer(size int) bool {
	return vl.buffer.IsValid() && vl.AllocSize == size && vl.buffer.GetSize() >= uint64(size) && vl.buffer.GetUsage()&vl.vvar.bufferUsages() == vl.vvar.bufferUsages()
}

// Candidate factories return fresh owned handles. Refusal preserves the previous
// staging reference; successful replacement retires it explicitly.
type sizedOwnedBuffer interface {
	liveOwnedReference
	GetSize() uint64
	GetUsage() wgpu.BufferUsage
}

func replaceValueReadBuffer[B sizedOwnedBuffer](current *B, size uint64, allocate func() (B, error)) error {
	var zero B
	usage := wgpu.BufferUsageMapRead | wgpu.BufferUsageCopyDst
	if *current != zero && (*current).IsValid() && (*current).GetSize() == size && (*current).GetUsage()&usage == usage {
		return nil
	}
	candidate, err := allocate()
	if err != nil || candidate == zero || !candidate.IsValid() || candidate.GetSize() != size || candidate.GetUsage()&usage != usage {
		if candidate != zero {
			candidate.Release()
		}
		if err == nil {
			err = fmt.Errorf("gpu: staging factory returned incompatible buffer")
		}
		return err
	}
	old := *current
	*current = candidate
	if old != zero {
		old.Release()
	}
	return nil
}

// Every preflight precedes native copy/map. Caller submits/completes the encoded
// copy and serializes all value operations; values/native ownership are not copied.
func (vl *Value) readNilCheck() error {
	size, err := vl.storageReadSize()
	if err != nil {
		return err
	}
	if !vl.device.Device.IsValid() || !vl.device.Queue.IsValid() || !vl.buffer.IsValid() || !vl.readBuffer.IsValid() {
		return fmt.Errorf("gpu: readback requires live owner and buffer references")
	}
	if size != vl.AllocSize || vl.buffer.GetSize() != uint64(size) || vl.readBuffer.GetSize() != uint64(size) {
		return fmt.Errorf("gpu: stale readback/source size")
	}
	if vl.buffer.GetUsage()&wgpu.BufferUsageCopySrc == 0 || vl.readBuffer.GetUsage()&(wgpu.BufferUsageMapRead|wgpu.BufferUsageCopyDst) != (wgpu.BufferUsageMapRead|wgpu.BufferUsageCopyDst) {
		return fmt.Errorf("gpu: incompatible readback/source usage")
	}
	return nil
}

// Read callbacks may be spontaneous on foreign native threads. Buffered channels
// transfer status without racing the owner. The synchronous poll/callback wait is
// intentionally not a new deadline/cancellation guarantee. Request errors admit
// no mapping; callbacks are delivered exactly once for admitted requests.
func mapReadBatch(n int, request func(int, func(wgpu.MapAsyncStatus)) error, poll func(), unmap func(int) error) ([]bool, error) {
	channels := make([]chan wgpu.MapAsyncStatus, n)
	admitted := make([]bool, n)
	mapped := make([]bool, n)
	var errs []error
	for i := 0; i < n; i++ {
		ch := make(chan wgpu.MapAsyncStatus, 1)
		channels[i] = ch
		if err := request(i, func(status wgpu.MapAsyncStatus) { ch <- status }); err != nil {
			errs = append(errs, err)
		} else {
			admitted[i] = true
		}
	}
	any := false
	for _, ok := range admitted {
		any = any || ok
	}
	if any {
		poll()
	}
	for i, ok := range admitted {
		if !ok {
			continue
		}
		status := <-channels[i]
		if err := BufferMapAsyncError(status); err != nil {
			errs = append(errs, err)
		} else {
			mapped[i] = true
		}
	}
	if len(errs) > 0 {
		for i, ok := range mapped {
			if ok {
				if err := unmap(i); err != nil {
					errs = append(errs, err)
				} else {
					mapped[i] = false
				}
			}
		}
	}
	return mapped, errors.Join(errs...)
}
