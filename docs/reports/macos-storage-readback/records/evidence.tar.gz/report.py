import hashlib,json,tarfile,io
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-storage-readback');out=r/'docs/reports/macos-storage-readback';records=out/'records'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
source=read('source-final.json');review=read('source-review-final.json');assert review['files']==source['sources'] and not review['findings'] and review['source_manifest_sha256']==sha(p/'source-final.json') and review['decoded_output_sha256']==source['decoded_output_sha256']
assert all(sha(r/n)==h for n,h in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()};assert len(prepared)==6195
for n,h in source['decoded_output_sha256'].items():assert prepared['upstream/'+n]==h
pr=read('prism-v1/prism.json');proc=read('prism-v1/process.json');assert proc['source_index_stable'] and proc['before']==proc['after']==source['sources'] and proc['error']is None and proc['exit_code']==0 and not pr['findings']
assert pr['coverage']['complete'] and pr['coverage']['files']==8 and pr['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
receipts={}
for f in sorted(p.glob('*.json')):
 q=json.loads(f.read_text())
 if 'argv'not in q:continue
 assert q['source_commit']==source['base_commit'] and q['error']is None and q['source_delta_stable'] and q['overlay_inputs_before']==q['overlay_inputs_after']
 for channel in ['stdout','stderr']:assert sha(p/(f.stem+'.'+channel))==q[channel+'_sha256']
 if not f.stem.startswith('owned-prepare'):assert q['prepared_before']==q['prepared_after']
 receipts[f.stem]={'exit_code':q['exit_code'],'receipt_sha256':sha(f),'stdout_sha256':q['stdout_sha256'],'stderr_sha256':q['stderr_sha256']}
final_names=['gpu-offscreen-race','gpu-vet','driver-offscreen-race','prepare-tests','native-build','storage-headless-shader-owned']
for n in final_names:
 q=read(n+'.json');assert q['exit_code']==0 and q['source_delta_before']==q['source_delta_after']==source['sources'] and q['prepared_before']==q['prepared_after']==prepared and not q['overlay_inputs_before']
observations={}
for line in(p/'storage-headless-shader-owned.stdout').read_text().splitlines():
 if line.startswith('VELLUM_STORAGE_NATIVE ')or line.startswith('VELLUM_COMPUTE_NATIVE '):
  obj=json.loads(line.split(' ',1)[1]);observations[obj['case']]=obj
assert len(observations)==11 and observations['private_device_and_active_recording']['computed_words_checked']==32
assert sum(o.get('verified_words',0)for name,o in observations.items()if name not in ['private_device_and_active_recording','partial_device_queue'])==32
assert observations['automatic_repair_WriteDynamicBuffer']['verified_bytes']==512 and observations['staging_size_cycle']['retired_refs']==2
assert all(o['windows_created']==o['surfaces_created']==0 for o in observations.values())
assert receipts['storage-original-regression-v2']['exit_code']==receipts['storage-headless-original']['exit_code']==1
assert 'SIGABRT' in(p/'storage-original-regression.stdout').read_text()
coverage=pr['coverage'];q={'result':'PASS_STORAGE_READBACK_OWNERSHIP','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'decoded_outputs':source['decoded_output_sha256'],'source_review_sha256':sha(p/'source-review-final.json'),'receipts':receipts,'native_observations':observations,'native_build_sha256':sha(p/'window-cycle-smoke-owned'),'prism_source':source['sources'],'prism_raw_exit_code':0,'prism_findings':0,'prism_findings_resolved':True,'prism_coverage':coverage,'headless_gpu_executed':True,'native_windows_executed':False,'physical_gpu_fault':False,'native_memory_qualified':False,'gpu_memory_qualified':False,'sustained_performance_qualified':False,'macos_completion':False,'live_tests_deferred':True,'preferences_changed':False,'history':'V1/V2 candidate overlay receipts have their separate fingerprints, retained candidate snapshots and exact recovered old overlay payloads. Candidate internalV2 requires unmap-quarantine fix; V3 approves it. First original-wrapper refusal probe enters a nil native device and Rust aborts before remaining assertions; raw1 preserved, not a physicalGPU fault or passing check. Revised nil-first probe restores three original source files atop final prepared dependency, disables new helper/unit-test files and uses new original-compatible fixtures; four Go-side refusal assertions fail safely. Native baseline is the unchanged parent6191 with only two original-compatible test overlays; six selected cases fail eight assertions. Final owned6195 passes eleven native storage/compute subcases. Later fixture-only explicit cancellation and nil-first fixes have final reviewed source pins.','limits':'Eight selected root identities/all6195 prepared files, not a complete compiler/SDK closure. No window/surface/input/presentation/performance execution. Counted faults do not inject hardware errors. Map ownership assumes one serialized initially-unmapped owner with no externally mapped/native alias/copy. Post-Poll callback wait30seconds does not bound synchronous Poll. Temporary BGL release is source-verified and successful shader integration, not independently counted native layout invalidation or heap reclamation. Automatic staging refusal can follow a valid upload; no atomic GPU content rollback.'}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');records.mkdir(parents=True,exist_ok=True);(records/'source-review.json').write_bytes((p/'source-review-final.json').read_bytes())
files=[f for f in sorted(p.rglob('*'))if f.is_file() and f.name!='window-cycle-smoke-owned' and '__pycache__'not in f.parts and f.suffix not in ['.gz','.tar']]
index={f.relative_to(p).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as archive:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(p).as_posix());info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
tokens=coverage['tokens'];input_tokens=sum(t['input']for t in tokens);output_tokens=sum(t['output']for t in tokens)
(out/'README.md').write_text(f'''# Mac storage readback ownership

Storage staging reused a buffer based on the GPU allocation size, allowing a
16→8→16 shape change to retain an eight-byte staging buffer. Matching GPU-buffer
upload paths also skipped repair of missing staging. Batch mapping published
callback statuses into an unsynchronized slice and admitted members before
checking the complete batch. Reads could silently truncate a short destination.

Patch 51 checks shape operands before multiplication/slicing, live buffer
size/usage and known device/queue identities. Staging reuse checks staging's own
size; successful replacement retires the old reference and refusal preserves it.
CreateBuffer, SetFromBytes and WriteDynamicBuffer propagate staging errors and
repair matching-buffer paths. A valid upload can precede a staging refusal; GPU
content is not atomically rolled back. Legacy buffer-backed StorageTexture roles
retain their prior route; real textures use their separate layout/copy contract.

Full batch preflight precedes mapping. Foreign-thread callbacks capture only
buffered per-attempt status channels. After synchronous Poll, callback delivery
has a 30-second bound, which does not bound Poll itself. Failure cancels all attempted
exact buffers; refused cleanup quarantines staging until explicit ReleaseRead.
Late callback delivery cannot mutate owner state or replacement staging. Values
share one serialized, initially-unmapped owner; external native mappings and
copied native ownership are outside this contract.

Reads require this API's completed mapping and exact full-byte destination,
including dynamic padding. Short-target refusal preserves the mapping for retry.
Range/unmap refusal quarantines it before another read. Vars.Config retains
native layout validation and releases its temporary layouts immediately rather
than leaving them to finalizers; pipelines create independent layouts.

## Verification

Final GPU/gpudraw suites pass three race repetitions; the complete offscreen
adapter race suite, vet, eleven preparation tests and native consumer compilation
pass. Fault kernels cover staging allocation/admission/refusal, checked arithmetic,
foreign callback delivery, partial mapping, cleanup refusal, missing/late callback
and short-read quarantine. These are controlled Go factories, not hardware faults.

Nine tiny real headless storage cases verify 32 words, 512 dynamic bytes including
padding, two staging reference retirements, automatic repair through all three
upload routes, short-read retry, unmapped-range refusal and late-nil/duplicate/
mixed-device batch refusal with first-member reuse. The existing eight-dispatch
compute fixture additionally checks 32 shader result words and its resource
retirement. No native windows, surfaces, input or presentation are used.

The unchanged parent dependency with two test-only overlays fails six selected
native cases and eight assertions. The corrected original-compatible refusal
probe fails four Go-side assertions using an original-three-file overlay on the
final prepared dependency; new helper/unit-test files are disabled. It is not a
full parent-checkout execution. The first refusal probe accidentally reached an
invalid native device and Rust aborted before remaining assertions. Its raw exit 1
and complete log remain preserved; no physical GPU fault or passing acceptance
is inferred. The probe was corrected to encounter the nil member first in Go.
Earlier candidate/owned source versions remain separately identified.

## Review and evidence

Internal candidate review caught refused-unmap state remaining readable; the fix
quarantines it and has a regression that forbids a second range access. Final
internal review binds all eight source leaves, both static pin maps, independent
patch replay and seven decoded/prepared outputs. Prism ran once using Anthropic
Claude Sonnet 5.5, complete eight-file coverage, {coverage['chunks']} chunks,
{input_tokens} input/{output_tokens} output tokens, raw exit 0 and no findings.

[Checkpoint](records/checkpoint.json) binds the source/evidence reviews and
[archive](records/evidence.tar.gz) with its [member index](records/evidence-index.json).
Raw failures, source variants, inert review snapshots, producers and receipts are
preserved; binaries/caches are excluded. All 6,195 prepared identities are bound,
not a complete compiler/SDK closure. Actual temporary-layout invalidation is not
independently counted. Native/GPU heap reclamation, physical faults, sustained
performance/endurance and full Mac acceptance remain open. Desktop work remains
deferred while the human uses the computer; no settings or input sources changed.
''')
print(json.dumps({'qualification_sha256':sha(p/'qualification.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared),'prism_input_tokens':input_tokens,'prism_output_tokens':output_tokens,'report_sha256':sha(out/'README.md')}))
