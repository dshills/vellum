// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"github.com/oliverbestmann/webgpu/wgpu"
	"testing"
)

// Original-compatible refusal checks; zero wrappers never enter native calls.
func TestVellumStorageReadbackRefusesRetiredReferences(t *testing.T) {
	v := &Value{Name: "retired", VarSize: 4, ArrayN: 1, AllocSize: 4, role: Storage, vvar: &Var{}, readBuffer: &wgpu.Buffer{}}
	if err := v.readNilCheck(); err == nil {
		t.Error("retired nonnil staging accepted")
	}
	func() {
		defer func() {
			if v := recover(); v != nil {
				t.Errorf("invalid batch panicked: %v", v)
			}
		}()
		if err := ValueReadSync(nil, nil, v); err == nil {
			t.Error("invalid map owner/batch accepted")
		}
	}()
	func() {
		defer func() {
			if v := recover(); v != nil {
				t.Errorf("invalid copy panicked: %v", v)
			}
		}()
		if err := v.GPUToRead(nil); err == nil {
			t.Error("invalid copy owner accepted")
		}
	}()
	func() {
		defer func() {
			if v := recover(); v != nil {
				t.Errorf("invalid raw map panicked: %v", v)
			}
		}()
		if err := BufferReadSync(nil, 4, nil); err == nil {
			t.Error("invalid raw map accepted")
		}
	}()
}
