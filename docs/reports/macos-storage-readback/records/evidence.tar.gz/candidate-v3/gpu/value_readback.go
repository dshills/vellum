// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"cogentcore.org/core/base/errors"
	"fmt"
	"github.com/oliverbestmann/webgpu/wgpu"
	"time"
)

// Buffer shape arithmetic is checked before native allocation or Go slicing.
// Texture readback uses Texture's distinct layout/copy contract.
func (vl *Value) bufferSizeChecked() (int, error) {
	if vl == nil || vl.Texture != nil {
		return 0, fmt.Errorf("gpu: buffer value required")
	}
	stride, count := vl.VarSize, vl.ArrayN
	if vl.isDynamic {
		stride, count = vl.AlignVarSize, vl.dynamicN
	}
	if count < 0 || stride < 1 || count > int(^uint(0)>>1)/stride {
		return 0, fmt.Errorf("gpu: invalid or overflowing value buffer shape")
	}
	return stride * count, nil
}
func (vl *Value) storageReadSize() (int, error) {
	if vl == nil || vl.vvar == nil || (vl.role != Storage && vl.role != StorageTexture) || vl.vvar.ReadOnly {
		return 0, fmt.Errorf("gpu: writable storage buffer required")
	}
	size, err := vl.bufferSizeChecked()
	if err != nil {
		return 0, err
	}
	if size < 1 || size%4 != 0 {
		return 0, fmt.Errorf("gpu: readback size must be positive and four-byte aligned")
	}
	return size, nil
}
func (vl *Value) bufferAdmission() error {
	if vl == nil || vl.vvar == nil || !vl.device.Device.IsValid() || !vl.device.Queue.IsValid() {
		return fmt.Errorf("gpu: buffer requires a live device, queue and variable")
	}
	if vl.readState != valueReadIdle {
		return fmt.Errorf("gpu: mapped readback must be consumed or released before upload")
	}
	return nil
}
func (vl *Value) reusableBuffer(size int) bool {
	return vl.buffer.IsValid() && vl.AllocSize == size && vl.buffer.GetSize() >= uint64(size) && vl.buffer.GetUsage()&vl.vvar.bufferUsages() == vl.vvar.bufferUsages()
}

// Candidate factories return fresh owned handles. Refusal preserves the previous
// staging reference; successful replacement retires it explicitly.
type sizedOwnedBuffer interface {
	liveOwnedReference
	GetSize() uint64
	GetUsage() wgpu.BufferUsage
}

func replaceValueReadBuffer[B sizedOwnedBuffer](current *B, size uint64, allocate func() (B, error)) error {
	var zero B
	usage := wgpu.BufferUsageMapRead | wgpu.BufferUsageCopyDst
	if *current != zero && (*current).IsValid() && (*current).GetSize() == size && (*current).GetUsage()&usage == usage {
		return nil
	}
	candidate, err := allocate()
	if err != nil || candidate == zero || !candidate.IsValid() || candidate.GetSize() != size || candidate.GetUsage()&usage != usage {
		if candidate != zero {
			candidate.Release()
		}
		if err == nil {
			err = fmt.Errorf("gpu: staging factory returned incompatible buffer")
		}
		return err
	}
	old := *current
	*current = candidate
	if old != zero {
		old.Release()
	}
	return nil
}

// Every preflight precedes native copy/map. Caller submits/completes the encoded
// copy and serializes all value operations; values/native ownership are not copied.
func (vl *Value) readNilCheck() error {
	size, err := vl.storageReadSize()
	if err != nil {
		return err
	}
	if !vl.device.Device.IsValid() || !vl.device.Queue.IsValid() || !vl.buffer.IsValid() || !vl.readBuffer.IsValid() {
		return fmt.Errorf("gpu: readback requires live owner and buffer references")
	}
	if size != vl.AllocSize || vl.buffer.GetSize() != uint64(size) || vl.readBuffer.GetSize() != uint64(size) {
		return fmt.Errorf("gpu: stale readback/source size")
	}
	if vl.buffer.GetUsage()&wgpu.BufferUsageCopySrc == 0 || vl.readBuffer.GetUsage()&(wgpu.BufferUsageMapRead|wgpu.BufferUsageCopyDst) != (wgpu.BufferUsageMapRead|wgpu.BufferUsageCopyDst) {
		return fmt.Errorf("gpu: incompatible readback/source usage")
	}
	return nil
}

type valueReadMapState uint8

const (
	valueReadIdle valueReadMapState = iota
	valueReadReady
	// A refused rollback cannot publish a readable mapping. Only explicit
	// ReleaseRead may retire quarantined staging; newer requests cannot reuse it.
	valueReadQuarantined
	storageCallbackWait = 30 * time.Second
)

// Callbacks capture only per-attempt buffered channels, never owner/value state.
// Poll itself remains synchronous; a separate post-poll callback wait is bounded.
// Under the serialized/unmapped-owner precondition, failure cancels every attempted
// exact buffer, including requests whose error callback can arrive after return.
func mapReadBatch(n int, request func(int, func(wgpu.MapAsyncStatus)) error, poll func(), unmap func(int) error, wait time.Duration) ([]valueReadMapState, error) {
	channels := make([]chan wgpu.MapAsyncStatus, n)
	admitted := make([]bool, n)
	states := make([]valueReadMapState, n)
	var errs []error
	for i := 0; i < n; i++ {
		ch := make(chan wgpu.MapAsyncStatus, 1)
		channels[i] = ch
		if err := request(i, func(status wgpu.MapAsyncStatus) { ch <- status }); err != nil {
			errs = append(errs, err)
		} else {
			admitted[i] = true
		}
	}
	any := false
	for _, ok := range admitted {
		any = any || ok
	}
	if any {
		poll()
	}
	timer := time.NewTimer(wait)
	defer timer.Stop()
	timedOut := false
	for i, ok := range admitted {
		if !ok {
			continue
		}
		if timedOut {
			continue
		}
		select {
		case status := <-channels[i]:
			if err := BufferMapAsyncError(status); err != nil {
				errs = append(errs, err)
			} else {
				states[i] = valueReadReady
			}
		case <-timer.C:
			timedOut = true
			errs = append(errs, fmt.Errorf("gpu: mapping callback delivery timed out after poll"))
		}
	}
	if len(errs) > 0 {
		for i := 0; i < n; i++ {
			if err := unmap(i); err != nil {
				errs = append(errs, err)
				states[i] = valueReadQuarantined
			} else {
				states[i] = valueReadIdle
			}
		}
	}
	return states, errors.Join(errs...)
}

// Destination refusal preserves a known mapping for retry. Native range/unmap
// refusal quarantines staging so a second read never accesses uncertain data.
func copyMappedValueBytes(state *valueReadMapState, size int, to []byte, read func() []byte, unmap func() error) error {
	if *state != valueReadReady {
		return fmt.Errorf("gpu: ReadSync must own a completed mapping")
	}
	if size < 1 || len(to) != size {
		return fmt.Errorf("gpu: read destination must match allocated size %d", size)
	}
	data := read()
	if len(data) != size {
		*state = valueReadQuarantined
		return fmt.Errorf("gpu: mapped range size differs from allocated value")
	}
	copy(to, data)
	if err := unmap(); err != nil {
		*state = valueReadQuarantined
		return err
	}
	*state = valueReadIdle
	return nil
}
