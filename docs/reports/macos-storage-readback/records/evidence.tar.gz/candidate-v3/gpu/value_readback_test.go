// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"errors"
	"github.com/oliverbestmann/webgpu/wgpu"
	"sync"
	"testing"
	"time"
)

type countedReadBuffer struct {
	valid    bool
	size     uint64
	usage    wgpu.BufferUsage
	released int
}

func (b *countedReadBuffer) IsValid() bool              { return b != nil && b.valid }
func (b *countedReadBuffer) GetSize() uint64            { return b.size }
func (b *countedReadBuffer) GetUsage() wgpu.BufferUsage { return b.usage }
func (b *countedReadBuffer) Release()                   { b.released++; b.valid = false }
func TestVellumStorageStagingReplacement(t *testing.T) {
	usage := wgpu.BufferUsageMapRead | wgpu.BufferUsageCopyDst
	for _, scenario := range []string{"reuse", "error", "partial_error", "nil", "invalid", "wrong_size", "wrong_usage", "replacement"} {
		t.Run(scenario, func(t *testing.T) {
			old := &countedReadBuffer{valid: true, size: 16, usage: usage}
			current := old
			candidate := &countedReadBuffer{valid: true, size: 8, usage: usage}
			called := 0
			size := uint64(8)
			if scenario == "reuse" {
				size = 16
			}
			err := replaceValueReadBuffer(&current, size, func() (*countedReadBuffer, error) {
				called++
				switch scenario {
				case "error":
					return nil, errors.New("allocation refused")
				case "partial_error":
					return candidate, errors.New("partial refusal")
				case "nil":
					return nil, nil
				case "invalid":
					candidate.valid = false
				case "wrong_size":
					candidate.size = 12
				case "wrong_usage":
					candidate.usage = wgpu.BufferUsageCopyDst
				}
				return candidate, nil
			})
			if scenario == "reuse" {
				if err != nil || called != 0 || current != old {
					t.Fatal("matching live staging not reused")
				}
				return
			}
			if scenario == "replacement" {
				if err != nil || current != candidate || old.released != 1 || candidate.released != 0 {
					t.Fatal("replacement ownership")
				}
				return
			}
			if err == nil || current != old || old.released != 0 || !old.valid {
				t.Fatal("refusal lost previous staging")
			}
			if scenario != "error" && scenario != "nil" && candidate.released != 1 {
				t.Fatal("candidate not retired")
			}
		})
	}
}
func TestVellumStorageReadShapeBounds(t *testing.T) {
	v := &Value{VarSize: 4, ArrayN: 4, role: Storage, vvar: &Var{}}
	if size, e := v.storageReadSize(); e != nil || size != 16 {
		t.Fatal(size, e)
	}
	for _, shape := range [][2]int{{0, 1}, {4, -1}, {3, 1}, {4, 0}, {int(^uint(0) >> 1), 2}} {
		v.VarSize, v.ArrayN = shape[0], shape[1]
		if _, e := v.storageReadSize(); e == nil {
			t.Fatal("invalid shape admitted", shape)
		}
	}
	v.VarSize, v.ArrayN = 4, 1
	v.vvar.ReadOnly = true
	if _, e := v.storageReadSize(); e == nil {
		t.Fatal("readonly mapped")
	}
	v.vvar.ReadOnly = false
	v.isDynamic = true
	v.AlignVarSize = 256
	v.dynamicN = 2
	if n, e := v.storageReadSize(); e != nil || n != 512 {
		t.Fatal(n, e)
	}
	v.dynamicN = -1
	if _, e := v.storageReadSize(); e == nil {
		t.Fatal("negative dynamic shape")
	}
}
func TestVellumStorageMapBatchForeignCallbacksAndRollback(t *testing.T) {
	for _, scenario := range []string{"success", "request_error", "callback_error", "unmap_error"} {
		t.Run(scenario, func(t *testing.T) {
			var callbacks [3]func(wgpu.MapAsyncStatus)
			unmapped := make([]int, 3)
			var wg sync.WaitGroup
			owned, err := mapReadBatch(3, func(i int, callback func(wgpu.MapAsyncStatus)) error {
				if i == 1 && scenario == "request_error" {
					return errors.New("request refused")
				}
				callbacks[i] = callback
				return nil
			}, func() {
				for i, cb := range callbacks {
					if cb != nil {
						wg.Add(1)
						go func(i int, cb func(wgpu.MapAsyncStatus)) {
							defer wg.Done()
							status := wgpu.MapAsyncStatusSuccess
							if i == 1 && (scenario == "callback_error" || scenario == "unmap_error") {
								status = wgpu.MapAsyncStatusError
							}
							cb(status)
						}(i, cb)
					}
				}
			}, func(i int) error {
				unmapped[i]++
				if i == 2 && scenario == "unmap_error" {
					return errors.New("unmap refused")
				}
				return nil
			}, time.Second)
			wg.Wait()
			if scenario == "success" {
				if err != nil || owned[0] != valueReadReady || owned[1] != valueReadReady || owned[2] != valueReadReady || unmapped[0]+unmapped[1]+unmapped[2] != 0 {
					t.Fatal("successful mapping lost")
				}
				return
			}
			if err == nil || owned[0] != valueReadIdle || owned[1] != valueReadIdle || unmapped[0] != 1 || unmapped[1] != 1 || unmapped[2] != 1 {
				t.Fatal("partial batch rollback", owned, unmapped, err)
			}
			if (owned[2] == valueReadQuarantined) != (scenario == "unmap_error") {
				t.Fatal("unmap refusal lost ownership", owned)
			}
		})
	}
}

func TestVellumStorageMissingCallbackRollbackAndLateDelivery(t *testing.T) {
	var late func(wgpu.MapAsyncStatus)
	cancelled := 0
	state, err := mapReadBatch(1, func(_ int, callback func(wgpu.MapAsyncStatus)) error { late = callback; return nil }, func() {}, func(int) error { cancelled++; return nil }, time.Millisecond)
	if err == nil || cancelled != 1 || state[0] != valueReadIdle {
		t.Fatal("pending request not cancelled", state, err)
	}
	done := make(chan struct{})
	go func() { late(wgpu.MapAsyncStatusSuccess); close(done) }()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("late callback blocked after rollback")
	}
	if state[0] != valueReadIdle {
		t.Fatal("late callback mutated owner state")
	}
}

func TestVellumStorageReadCopyRefusalAndQuarantine(t *testing.T) {
	state := valueReadReady
	reads, unmaps := 0, 0
	data := []byte{1, 2, 3, 4}
	read := func() []byte { reads++; return data }
	unmap := func() error { unmaps++; return errors.New("native unmap refused") }
	if e := copyMappedValueBytes(&state, 4, make([]byte, 3), read, unmap); e == nil || state != valueReadReady || reads != 0 || unmaps != 0 {
		t.Fatal("destination refusal touched mapping")
	}
	if e := copyMappedValueBytes(&state, 4, make([]byte, 4), read, unmap); e == nil || state != valueReadQuarantined || reads != 1 || unmaps != 1 {
		t.Fatal("unmap refusal not quarantined")
	}
	if e := copyMappedValueBytes(&state, 4, make([]byte, 4), read, unmap); e == nil || reads != 1 || unmaps != 1 {
		t.Fatal("quarantined mapping accessed twice")
	}
}
