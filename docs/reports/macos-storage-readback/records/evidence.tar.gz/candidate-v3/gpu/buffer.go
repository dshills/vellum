// Copyright (c) 2024, Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gpu

import (
	"fmt"

	"cogentcore.org/core/base/errors"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// note: WriteBuffer is the preferred method for writing, so we only need to manage Read

// BufferMapAsyncError returns an error message if the status is not success.
func BufferMapAsyncError(status wgpu.MapAsyncStatus) error {
	if status != wgpu.MapAsyncStatusSuccess {
		return errors.New("gpu BufferMapAsync was not successful")
	}
	return nil
}

// BufferReadSync does a MapAsync on given buffer, waiting on the device
// until the sync is complete, and returning error if any issues.
func BufferReadSync(device *Device, size int, buffer *wgpu.Buffer) error {
	if device == nil || !device.Device.IsValid() || !device.Queue.IsValid() || !buffer.IsValid() || size < 1 || size%4 != 0 {
		return fmt.Errorf("gpu: map requires live owner/buffer and positive aligned size")
	}
	if uint64(size) > buffer.GetSize() || buffer.GetUsage()&wgpu.BufferUsageMapRead == 0 {
		return fmt.Errorf("gpu: incompatible map range/usage")
	}
	_, err := mapReadBatch(1, func(_ int, callback func(wgpu.MapAsyncStatus)) error {
		return buffer.TryMapAsync(wgpu.MapModeRead, 0, uint64(size), callback)
	}, device.WaitDone, func(int) error { return buffer.TryUnmap() }, storageCallbackWait)
	return err
}

// ValueReadSync preflights the entire batch before the first mapping. Values
// share one serialized owner and device; duplicates/mixed devices are refused.
// Successful callbacks publish owned mappings together. Any batch error attempts
// to unmap every attempted exact buffer; refused unmaps quarantine its staging.
func ValueReadSync(device *Device, values ...*Value) error {
	if len(values) == 0 {
		return nil
	}
	if device == nil || !device.Device.IsValid() || !device.Queue.IsValid() {
		return fmt.Errorf("gpu: live mapping owner required")
	}
	seen := make(map[*wgpu.Buffer]bool, len(values))
	for _, value := range values {
		if err := value.readNilCheck(); err != nil {
			return err
		}
		if value.device.Device != device.Device || value.device.Queue != device.Queue || value.readState != valueReadIdle || seen[value.readBuffer] {
			return fmt.Errorf("gpu: duplicate, mapped or mixed-device value")
		}
		seen[value.readBuffer] = true
	}
	mapped, err := mapReadBatch(len(values), func(i int, callback func(wgpu.MapAsyncStatus)) error {
		value := values[i]
		return value.readBuffer.TryMapAsync(wgpu.MapModeRead, 0, uint64(value.AllocSize), callback)
	}, device.WaitDone, func(i int) error { return values[i].readBuffer.TryUnmap() }, storageCallbackWait)
	for i, owned := range mapped {
		values[i].readState = owned
	}
	return err
}

// ValueGroups provides named lists of value groups that can be
// used to simplify the calling of the multiple Read functions
// needed to read data back from the GPU.
type ValueGroups map[string][]*Value

func (vg *ValueGroups) init() {
	if vg == nil {
		*vg = make(map[string][]*Value)
	}
}

// Add Adds named group of values
func (vg *ValueGroups) Add(name string, vals ...*Value) {
	vg.init()
	(*vg)[name] = vals
}

func (vg ValueGroups) ValuesByName(name string) ([]*Value, error) {
	vls, ok := vg[name]
	if !ok {
		return nil, fmt.Errorf("gpu.ValueGroups: %q not found", name)
	}
	return vls, nil
}

// GPUToRead adds commands to given command encoder to read values
// from the GPU to its read buffer.  Next step is ReadSync after
// command has been submitted (EndComputePass).
func (vg ValueGroups) GPUToRead(name string, cmd *wgpu.CommandEncoder) error {
	vls, err := vg.ValuesByName(name)
	if errors.Log(err) != nil {
		return err
	}
	var errs []error
	for _, vl := range vls {
		err := vl.GPUToRead(cmd)
		if err != nil {
			errs = append(errs, err)
		}
	}
	return errors.Log(errors.Join(errs...))
}

// ReadSync does a MapAsync on values.
func (vg ValueGroups) ReadSync(name string) error {
	vls, err := vg.ValuesByName(name)
	if errors.Log(err) != nil {
		return err
	}
	if len(vls) == 0 {
		return nil
	}
	if vls[0] == nil {
		return fmt.Errorf("gpu: nil value in read group")
	}
	dev := &vls[0].device
	return ValueReadSync(dev, vls...)
}
