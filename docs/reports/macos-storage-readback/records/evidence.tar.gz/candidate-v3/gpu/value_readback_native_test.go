// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

//go:build !js

package gpu

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"github.com/oliverbestmann/webgpu/wgpu"
	"os"
	"testing"
)

// Original-compatible tiny native API checks. No surfaces/windows/input, shader
// performance, physical memory or actual device-fault injection is qualified.
func TestVellumStorageNativeReadback(t *testing.T) {
	if os.Getenv("VELLUM_STORAGE_GPU_TEST") != "1" {
		t.Skip("explicit tiny headless fixture required")
	}
	var gp *GPU
	var dev *Device
	defer func() {
		if dev != nil {
			dev.Release()
		}
		if gp != nil {
			gp.Release()
		}
		ReleaseInstance()
	}()
	var err error
	gp, dev, err = NoDisplayGPU()
	if err != nil || gp == nil || dev == nil {
		t.Fatal("headless admission", err)
	}
	record := func(fields map[string]any) {
		fields["windows_created"] = 0
		fields["surfaces_created"] = 0
		b, e := json.Marshal(fields)
		if e != nil {
			t.Fatal(e)
		}
		fmt.Printf("VELLUM_STORAGE_NATIVE %s\n", b)
	}
	makeValue := func(t *testing.T, device *Device) *Value {
		group := &VarGroup{Role: Storage, alignBytes: 1}
		variable := NewVar(group, "words", Uint32, 1, ComputeShader)
		value := NewValue(variable, device, 0)
		t.Cleanup(value.Release)
		if e := SetValueFrom(value, []uint32{7, 13, 23, 41}); e != nil {
			t.Fatal(e)
		}
		return value
	}
	copyValue := func(t *testing.T, value *Value) {
		command, e := value.device.Device.TryCreateCommandEncoder(nil)
		if e != nil {
			t.Fatal(e)
		}
		defer command.Release()
		if e := value.GPUToRead(command); e != nil {
			t.Fatal(e)
		}
		buffer, e := command.TryFinish(nil)
		if e != nil {
			t.Fatal(e)
		}
		defer buffer.Release()
		value.device.Queue.Submit(buffer)
	}
	readWords := func(t *testing.T, value *Value) {
		copyValue(t, value)
		if e := value.ReadSync(); e != nil {
			t.Fatal(e)
		}
		result := make([]uint32, 4)
		if e := ReadToBytes(value, result); e != nil {
			t.Fatal(e)
		}
		if !bytes.Equal(wgpu.ToBytes(result), wgpu.ToBytes([]uint32{7, 13, 23, 41})) {
			t.Fatal("native storage words", result)
		}
	}
	t.Run("staging_size_cycle", func(t *testing.T) {
		v := makeValue(t, dev)
		first := v.readBuffer
		v.ArrayN = 2
		if e := v.CreateReadBuffer(); e != nil {
			t.Fatal(e)
		}
		small := v.readBuffer
		if first.IsValid() || small.GetSize() != 8 {
			t.Fatal("first staging resize not retired")
		}
		if e := v.CreateReadBuffer(); e != nil {
			t.Fatal(e)
		}
		if small != v.readBuffer {
			t.Error("matching staging reallocated using unrelated GPU AllocSize")
		}
		v.ArrayN = 4
		if e := v.CreateReadBuffer(); e != nil {
			t.Fatal(e)
		}
		if v.readBuffer.GetSize() != 16 || small.IsValid() {
			t.Error("restored GPU size reused stale staging")
			return
		}
		readWords(t, v)
		record(map[string]any{"case": "staging_size_cycle", "sizes": []int{16, 8, 16}, "retired_refs": 2, "verified_words": 4})
	})
	for _, route := range []string{"CreateBuffer", "SetFromBytes", "WriteDynamicBuffer"} {
		t.Run("automatic_repair_"+route, func(t *testing.T) {
			if route == "WriteDynamicBuffer" {
				group := &VarGroup{Role: Storage, alignBytes: 256}
				variable := NewVar(group, "dynamic", Uint32, 1, ComputeShader)
				variable.DynamicOffset = true
				v := NewValue(variable, dev, 0)
				defer v.Release()
				v.SetDynamicN(2)
				if e := SetDynamicValueFrom(v, 0, []uint32{7}); e != nil {
					t.Fatal(e)
				}
				if e := SetDynamicValueFrom(v, 1, []uint32{19}); e != nil {
					t.Fatal(e)
				}
				if e := v.WriteDynamicBuffer(); e != nil {
					t.Fatal(e)
				}
				if !v.readBuffer.IsValid() {
					t.Error("initial dynamic upload did not establish automatic staging")
				}
				if e := v.CreateReadBuffer(); e != nil {
					t.Fatal(e)
				}
				source := v.buffer
				v.ReleaseRead()
				if e := v.WriteDynamicBuffer(); e != nil {
					t.Fatal(e)
				}
				if !v.readBuffer.IsValid() || v.readBuffer.GetSize() != 512 || v.buffer != source {
					t.Error("dynamic shortcut did not repair staging")
					return
				}
				copyValue(t, v)
				if e := v.ReadSync(); e != nil {
					t.Fatal(e)
				}
				got := make([]byte, 512)
				if e := v.ReadToBytes(got); e != nil {
					t.Fatal(e)
				}
				want := make([]byte, 512)
				binary.LittleEndian.PutUint32(want, 7)
				binary.LittleEndian.PutUint32(want[256:], 19)
				if !bytes.Equal(got, want) {
					t.Fatal("dynamic bytes/padding")
				}
				record(map[string]any{"case": "automatic_repair_" + route, "verified_bytes": 512, "source_reused": true})
				return
			}
			v := makeValue(t, dev)
			source := v.buffer
			v.ReleaseRead()
			var e error
			if route == "CreateBuffer" {
				e = v.CreateBuffer()
			} else {
				e = SetValueFrom(v, []uint32{7, 13, 23, 41})
			}
			if e != nil {
				t.Fatal(e)
			}
			if !v.readBuffer.IsValid() || v.readBuffer.GetSize() != 16 || v.buffer != source {
				t.Error("shortcut did not repair missing staging")
				return
			}
			readWords(t, v)
			record(map[string]any{"case": "automatic_repair_" + route, "verified_words": 4, "source_reused": true})
		})
	}
	t.Run("short_destination_retry", func(t *testing.T) {
		v := makeValue(t, dev)
		copyValue(t, v)
		if e := v.ReadSync(); e != nil {
			t.Fatal(e)
		}
		if e := v.ReadToBytes(make([]byte, 15)); e == nil {
			t.Error("short destination reported full-value success")
			return
		}
		if e := v.ReadSync(); e == nil {
			t.Fatal("owned mapping remapped")
		}
		if e := v.CreateReadBuffer(); e == nil {
			t.Fatal("owned mapping reconfigured")
		}
		result := make([]uint32, 4)
		if e := ReadToBytes(v, result); e != nil {
			t.Fatal("exact retry lost original mapping", e)
		}
		if !bytes.Equal(wgpu.ToBytes(result), wgpu.ToBytes([]uint32{7, 13, 23, 41})) {
			t.Fatal(result)
		}
		readWords(t, v)
		record(map[string]any{"case": "short_destination_retry", "verified_words": 8, "short_refused": true})
	})
	t.Run("unmapped_read_refused", func(t *testing.T) {
		v := makeValue(t, dev)
		if e := v.ReadToBytes(make([]byte, 16)); e == nil {
			t.Fatal("unmapped native range accessed")
		}
		record(map[string]any{"case": "unmapped_read_refused"})
	})
	for _, kind := range []string{"late_nil", "duplicate", "mixed_device"} {
		t.Run("batch_preflight_"+kind, func(t *testing.T) {
			first := makeValue(t, dev)
			copyValue(t, first)
			members := []*Value{first, nil}
			switch kind {
			case "duplicate":
				members[1] = first
			case "mixed_device":
				other, e := NewDevice(gp)
				if e != nil {
					t.Fatal(e)
				}
				defer other.Release()
				second := makeValue(t, other)
				defer second.Release()
				members[1] = second
				copyValue(t, second)
			}
			func() {
				defer func() {
					if value := recover(); value != nil {
						t.Errorf("late invalid member panicked after possible mapping: %v", value)
					}
				}()
				if e := ValueReadSync(dev, members...); e == nil {
					t.Error("invalid batch accepted")
				}
			}()
			if t.Failed() {
				return
			}
			if e := first.ReadSync(); e != nil {
				t.Fatal("preflight left first member mapped/pending", e)
			}
			result := make([]uint32, 4)
			if e := ReadToBytes(first, result); e != nil {
				t.Fatal(e)
			}
			if !bytes.Equal(wgpu.ToBytes(result), wgpu.ToBytes([]uint32{7, 13, 23, 41})) {
				t.Fatal(result)
			}
			record(map[string]any{"case": "batch_preflight_" + kind, "verified_words": 4, "first_member_reusable": true})
		})
	}
}
