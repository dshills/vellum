import difflib,hashlib,json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-storage-readback');driver=r/'drivers/cogent';stage=driver/'native/patches/storagereadback';stage.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={};outputs={};diff=[]
for f in sorted((p/'candidate/gpu').glob('*.go')):
 n='gpu/'+f.name;oldpath=driver/'build/upstream'/n;old=oldpath.read_bytes()if oldpath.is_file()else b'';new=f.read_bytes();inputs[n]=sha(old)if old else None;outputs[n]=sha(new)
 diff.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
name='0051-owned-storage-readback-and-layouts.patch';data=''.join(diff).encode();(stage/name).write_bytes(data)
for n,v in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (stage/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=driver/'native/dependencies.json';m=json.loads(manifest.read_text());prefix='native/patches/storagereadback';assert not any(s['inputs']==prefix+'/original-hashes.json'for s in m['dependencies'][0]['stages']);m['dependencies'][0]['stages'].append({'origin':'drivers/cogent/'+prefix,'inputs':prefix+'/original-hashes.json','outputs':prefix+'/output-hashes.json','patches':[{'file':prefix+'/'+name,'sha256':sha(data)}]});manifest.write_text(json.dumps(m,indent=2)+'\n')
f=driver/'prepare_test.py';s=f.read_text();assert s.count('list(range(1, 51))')==1;f.write_text(s.replace('list(range(1, 51))','list(range(1, 52))'))
(stage/'README.md').write_text("""# Storage readback and temporary layouts

Patch 0051 validates buffer-size operands before multiplication and slicing.
Storage readback requires positive four-byte-aligned bytes, live source/staging
size and usage, and the originating device/queue. Buffer-backed legacy
StorageTexture variables retain the existing buffer route; real texture-backed
values use the Texture layout/copy API instead. Staging reuse checks its own
actual size, independently of GPU AllocSize. Fresh replacement is published only
on success and retires the old reference; allocation refusal preserves it.
CreateBuffer, SetFromBytes and WriteDynamicBuffer return automatic staging errors
and repair missing staging on otherwise-reusable GPU-buffer paths. A valid GPU
upload may precede a staging refusal; this is not atomic content rollback.

Mapping preflights all members, known owner identities and duplicates before any
native map. Values and buffers have one serialized owner and enter unmapped;
external native maps and copied Value ownership are unsupported. Callback channels
capture only a per-attempt status channel. After synchronous Poll, callback delivery
has a separate 30-second wait; Poll itself has no new deadline. Failure cancels
all attempted exact buffers. Refused rollback quarantines staging until explicit
ReleaseRead. Late delivery cannot mutate owner state or a replacement buffer.

ReadToBytes requires this API's completed mapping and an exact full-byte target.
Short-target refusal preserves a ready map for retry; range/unmap refusal
quarantines it before another read. Upload/copy/reconfiguration refuse held or
quarantined mappings. Explicit zero/readonly retirement drops staging.
Vars.Config preserves native layout validation and immediately releases its
otherwise-discarded temporary layout references. Pipeline layouts remain distinct.

Fault kernels, original-compatible refusal and opt-in tiny native readback/shader
checks exercise the contract. Counted mapping/allocation failures are not physical
GPU faults. Wrapper retirement and source release loops do not prove native/GPU
heap reclamation, sustained performance, presentation or full Mac acceptance.
Modified upstream source retains BSD-style notices; new helpers/tests are MIT.
The module cache is not edited. Every stage input/output and patch is hash-pinned.
""")
f=r/'specs/gpu-frame-lifecycle.md';s=f.read_text();s+="""
## Storage-value readback and temporary layouts

The legacy Value buffer APIs validate nonnegative shape operands and multiplication
before native allocation or Go slicing. Storage readback uses positive four-byte
aligned ranges, live source/staging handles, exact read sizes and required usage.
Buffer-backed StorageTexture roles retain their prior buffer route; real texture
objects require Texture copy/layout methods. Automatic staging errors propagate
through CreateBuffer, SetFromBytes and WriteDynamicBuffer; matching GPU buffers
still repair absent staging. A staged upload is not rolled back on later refusal.
Staging replacement is transactional with respect to its owned reference and
checks staging size independently of the GPU AllocSize field.

Mapping has one serialized owner and initially unmapped buffers. Values/native
ownership are not copied, and caller-native maps are outside this contract. Every
batch member, known device/queue identity and duplicate is checked before any map.
Callbacks capture only per-attempt buffered channels. The owner waits for statuses
through channels after synchronous Poll; callback delivery then has a 30-second
bound. This does not bound Poll or qualify physical-loss recovery. Any batch error
cancels all attempted exact buffers; a refused rollback quarantines its staging.
Late callbacks cannot publish a map or change a replacement buffer's owner state.

ReadToBytes accepts only this API's completed mapping and exact allocated byte
length (including dynamic-offset padding). Short destinations preserve a ready
map for retry; range/unmap refusal quarantines staging until explicit ReleaseRead.
Held/quarantined maps refuse upload, copying and non-retiring reconfiguration.
Explicit zero/readonly configuration retires staging. Source bytes are detached
before unmapping; no partial copied output is successful when cleanup refuses.

Vars.Config keeps its native bind-layout validation and releases those temporary
owned handles immediately. Pipelines independently create their own layouts.
Source release calls, fault kernels and tiny native words/padding checks remain
separate from actual native/GPU memory, latency/endurance and Mac acceptance.
""";f.write_text(s)
f=r/'specs/macos-completion.md';s=f.read_text();s+="""
Storage-value readback now checks shape/usage/source/staging identity and performs
complete batch preflight, synchronized callback delivery and rollback/quarantine.
Automatic byte uploads repair staging; exact-length reads support short-target
retry. Vars.Config's temporary validation layouts retire explicitly. These
[GPU ownership contracts](gpu-frame-lifecycle.md) retain serialized, initially
unmapped ownership; physical memory, sustained performance and live-window
qualification remain open.
""";f.write_text(s)
(p/'stage-source.json').write_text(json.dumps({'inputs':inputs,'outputs':outputs,'patch_sha256':sha(data)},indent=2)+'\n')
print(json.dumps({'outputs':len(outputs),'expected_prepared_files':6195,'patch_sha256':sha(data)}))
