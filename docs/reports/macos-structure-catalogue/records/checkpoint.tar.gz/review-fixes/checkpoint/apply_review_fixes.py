from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
p=T/'drivers/cogent/controls.go';s=p.read_text();s=s.replace('type tabState struct {','type tabState struct {\n pending atomic.Pointer[tabSelectionIntent]',1)
s=s.replace('func postControl(r *record, fn func()) {\n\tif tree.IsNil(r.widget) {\n\t\treturn','func postControl(r *record, fn func()) bool {\n\tif tree.IsNil(r.widget) {\n\t\treturn false',1)
a=s.index('func postControl(');b=s.index('\nfunc dispatchControl',a);block=s[a:b].replace('\n\t\t\treturn\n','\n\t\t\treturn false\n').replace('\n\t\tr.control.a.Invalidate(r.control.window)\n\t}\n}', '\n\t\tr.control.a.Invalidate(r.control.window)\n  return false\n\t}\n return true\n}');s=s[:a]+block+s[b:]
s=s.replace('if r.control.tabs != nil {\n\t\t\tfor _, binding', 'if r.control.tabs != nil {\n   r.control.tabs.pending.Store(nil)\n\t\t\tfor _, binding',1);p.write_text(s)
p=T/'drivers/cogent/tab_navigation.go';s=p.read_text().replace('import (','import (\n "sync/atomic"',1)
a=s.index('// The binding');s=s[:a]+'''// One latest intent is retained per strip until originating reconciliation
// publishes authoritative state after owner delivery. It is never accepted state.
type tabSelectionIntent struct {
 originID, id string
 origin, target *tabBinding
 from, to *tabCloseEpoch
 delivered atomic.Bool
}
func tabSelectionIntentLive(r *record, intent *tabSelectionIntent) bool {
 return intent != nil && tabCloseEpochLive(intent.from) && tabCloseEpochLive(intent.to) && intent.origin.selectEpoch.Load() == intent.from && intent.target.selectEpoch.Load() == intent.to && tabSelectionEnabled(r,intent.originID,intent.origin) && tabSelectionEnabled(r,intent.id,intent.target) && r.node.Change != nil
}
// Runs only during originating reconciliation, under its native ownership.
func reconcileTabSelection(r *record) {
 tabs:=r.control.tabs
 if intent:=tabs.pending.Load();intent!=nil && (intent.delivered.Load() || !tabSelectionIntentLive(r,intent)) { tabs.pending.CompareAndSwap(intent,nil) }
 for id,binding:=range tabs.bindings {
  if !binding.button.ContainsFocus() || tabSelectionEnabled(r,id,binding) && tabCloseEpochLive(binding.selectEpoch.Load()) {continue}
  if tabs.visible && !r.control.disabled {
   if target,err:=focusWidget(r);err==nil {
    for targetID,targetBinding:=range tabs.bindings {
     if targetBinding.button==target && tabSelectionEnabled(r,targetID,targetBinding) && tabCloseEpochLive(targetBinding.selectEpoch.Load()) { target.AsWidget().SetFocus();return }
    }
   }
  }
  // No enabled header: yield to an enabled control outside the strip if one
  // exists. Otherwise this old focus stays inert until ordinary focus traversal.
  if manager:=binding.button.Events();manager!=nil {manager.FocusNextFrom(binding.button)}
  return
 }
}

'''+s[a:]
s=s.replace('// Freeze input-time intent: the rendered SelectedID can lag earlier owner proposals.\n\tpropose := r.node.Change != nil && (repeat || r.node.SelectedID != id)\n\tpostControl(r, func() {', '''// Freeze input intent against the latest live pending proposal. Focus-only
 // Tab traversal followed by activation can return to a still-rendered selection.
 tabs:=r.control.tabs
 previous:=tabs.pending.Load()
 if previous!=nil && !tabSelectionIntentLive(r,previous) {tabs.pending.CompareAndSwap(previous,nil);previous=nil}
 baseline:=r.node.SelectedID
 if previous!=nil {baseline=previous.id}
 propose:=r.node.Change!=nil && (repeat || baseline!=id)
 var intent *tabSelectionIntent
 if propose {intent=&tabSelectionIntent{originID:originID,id:id,origin:origin,target:target,from:from,to:to};tabs.pending.Store(intent)}
 admitted:=postControl(r, func() {
  if intent!=nil {defer intent.delivered.Store(true)}''',1)
needle='\n\t})\n}\nfunc tabNavigationKey';assert needle in s;s=s.replace(needle,'\n\t})\n if !admitted && intent!=nil {tabs.pending.CompareAndSwap(intent,previous)}\n}\nfunc tabNavigationKey',1);p.write_text(s)
p=T/'drivers/cogent/tab_close.go';s=p.read_text();marker='\n}\nfunc tabCloseID';assert marker in s;s=s.replace(marker,'\n reconcileTabSelection(r)\n}\nfunc tabCloseID',1);p.write_text(s)
print('Installed bounded pending intent and originating focus repair.')
