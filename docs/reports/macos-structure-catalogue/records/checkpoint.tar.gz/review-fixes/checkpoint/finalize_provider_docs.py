from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
disposition=read(W/'internal-prism-disposition.json');assert disposition['approved']and not disposition['unresolved_findings']and len(disposition['original_findings_resolved'])==2 and disposition['review_fixes_native_verified']is False
prism=read(W/'prism.json');assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1 and prism['coverage']['files']==20 and prism['coverage']['bytes']==107458 and not prism['coverage']['cacheHit']and len(prism['findings'])==2 and not prism['discarded']and not prism['suppressed']
name='docs/reports/macos-structure-catalogue/README.md';p=T/name;provider=read(W/'review-scope.json');assert sha(p)==provider['files'][name]==sha(W/'versions/provider-reviewed-README.md')
s=p.read_text();old='''Internal fix/pre-provider/final archive reviews and a second scoped Sonnet 5.5
review are required before commit. The bounded [archive](records/checkpoint.tar.gz)
and [manifest](records/manifest.json) retain both provider payloads, original source,
failed tests, final checks and raw native evidence without binaries or SDK copies.''';assert old in s
s=s.replace(old,'''Internal fix and pre-provider reviews approve the corrected source and software
evidence. The second complete uncached Sonnet 5.5 call covers all 20 corrected
files (107,458 bytes), with no excluded/skipped/truncated input or discarded/
suppressed findings. Its raw CLI exits 1 with two retained medium concerns.
Independent review refutes them: repair first checks actual focused membership
and runs within the originating scene, preserving valid/unrelated focus without
OS window activation; production control retirement clears pending intent and
epochs, while closed window lifetimes refuse subsequent input. Disposal and
pending/publication regressions pass. Both raw comments remain preserved; no
source change or third provider call is needed. This factual README-only delta
receives final internal archive/commit review. The bounded
[archive](records/checkpoint.tar.gz) and [manifest](records/manifest.json) retain
both provider payloads, original source, failed tests, final checks and raw native
evidence without binaries or SDK copies.''',1);p.write_text(s)
run_child(['git','add','--',name],cwd=T,timeout=30,check=True)
diff=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,check=True,capture_output=True).stdout
r={**provider,'files':{n:sha(T/n)for n in provider['paths']},'staged_diff_bytes':len(diff),'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'provider_staged_diff_sha256':provider['staged_diff_sha256'],'post_provider_changed_paths':[name]}
assert all(r['files'][n]==z for n,z in provider['files'].items()if n!=name)
(W/'final-scope.json').write_text(json.dumps(r,indent=2)+'\n');(W/'final-staged.diff').write_bytes(diff);print(json.dumps({'bytes':len(diff),'sha256':r['staged_diff_sha256']}))
