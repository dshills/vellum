from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
F=Path(__file__).resolve().parent;W=F.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks={}
for n in ['tabs-final','driver-final','gallery-final','vet-final','build-final']:
 d=read(F/(n+'.json'));assert d['exit_code']==0 and d['logs_complete']and d['pins_stable']and d['owned']['group_absent'];checks[n]={'receipt_sha256':sha(F/(n+'.json')),'exit_code':0,'seconds':d['seconds'],'logs_complete':True,'pins_stable':True,'owned_group_absent':True}
p=T/'docs/reports/macos-structure-catalogue/README.md';s=p.read_text();s=s.replace('The queue captures absolute movement intent before owner delivery: rapid A→B→A\nmust produce B,A even before reconciliation.', 'The queue captures absolute movement intent before owner delivery: rapid A→B→A\nmust produce B,A even before reconciliation. One bounded pending intent also\npreserves explicit Space/Enter after focus-only Shift-Tab returns to A. It stays\neffective through owner delivery until originating authoritative reconciliation,\nwith exact-pointer refusal rollback and lifetime retirement. A header that becomes\ndisabled yields focus to the selected/first enabled header without a selection\ncallback. With no eligible header, focus traversal skips the complete strip subtree\n(including private Parts and still-unsynchronized child widgets), choosing the\nnext enabled control or clearing focus when none exists.',1)
s=s.replace('The new runnable `gallery -structure-native-check` authors 50 inputs and 42','The new runnable `gallery -structure-native-check` authors 50 inputs and 42',1)
s=s.replace('post-failure check proves complete source/prepared/SDK/binary boundaries unchanged;','post-failure check proves complete source/prepared/SDK/binary boundaries unchanged\nbefore the later review fixes;',1)
a=s.index('Internal source/controller, exact-plan admission, failure/provider disposition');b=s.index('\nEvidence uses',a)
s=s[:a]+'''The first Prism Anthropic Claude Sonnet 5.5 review covers all 20 staged files
(89,210 bytes) in one complete uncached call. Its raw CLI exits 1 with two medium
findings. Both identify valid gaps despite partly overstated examples: arrow-only
A→B→A already worked, but actual Core Right/Shift-Tab/Space and Enter reproduce a
lost activation; disabled-header arrows stall although Tab can escape and read-
only focus movement is intentional. Both failures are preserved. The fixes above
pass those actual Core queue/manager routes, plus pending delivery/publication,
queue refusal and hidden/disposed cleanup regressions. An internal follow-up
also reproduces and fixes focus escape into still-enabled child descriptors when
the entire strip becomes disabled. The complete final driver and gallery race
suites, focused tab tests, root/gallery vet and native build pass after these fixes.

The original native executable/source, failed run, oracle and first review stay
immutable. The native prefix describes that original source, **not qualification
of the subsequent review fixes**. No new native run occurs. Full 50/42 qualification,
notes selection/close and complete independent geometry validation remain pending.
Internal fix/pre-provider/final archive reviews and a second scoped Sonnet 5.5
review are required before commit. The bounded [archive](records/checkpoint.tar.gz)
and [manifest](records/manifest.json) retain both provider payloads, original source,
failed tests, final checks and raw native evidence without binaries or SDK copies.
This is a tested keyboard product checkpoint. Full M2/M5 and M3–M7 remain open.
'''+s[b:];p.write_text(s)
p=T/'specs/controls.md';s=p.read_text();needle='Queued movement retains absolute input-time intent even before a redraw, and\ninput-time read-only authority cannot revive when a callback is later enabled.';assert needle in s;s=s.replace(needle,'''Queued movement retains absolute input-time intent even before a redraw.
Activation compares with the latest live pending intent, so focus-only traversal
back to a still-rendered selected header cannot lose an explicit activation.
One immutable intent per strip survives owner delivery until authoritative
originating reconciliation. Admission refusal restores only the exact previous
intent; rejection, lifecycle changes and reconciliation retire it. Input-time
read-only authority cannot revive when a callback is later enabled.
If the actually focused header becomes ineligible, originating reconciliation
moves focus to the selected/first enabled header without proposing selection.
If no header is eligible, traversal skips the complete strip subtree (including
Parts and child descriptors awaiting sync), focusing the next enabled control or
clearing focus when there is none. Existing valid focus is preserved.''',1);p.write_text(s)
for n in ['specs/control-acceptance.md','specs/macos-delivery.md','specs/macos-completion.md','specs/tab-close.md','docs/desktop-integration.md','drivers/cogent/cmd/gallery/README.md']:
 p=T/n;s=p.read_text();s+='''
The structural native prefix above predates the subsequent Prism tab activation
and disabled-focus fixes. Those fixes pass actual Core queue/manager routing and
complete driver/gallery race suites, but have not received a new native run.
They retain the failed scope and do not close the full structural/native gate.
''';p.write_text(s)
p=T/'docs/reports/macos-structure-catalogue/records/results.json';d=read(p);d['original_software_checks']=d.pop('checks');d['checks']=checks;d['native_source_predates_review_fixes']=True;d['review_fixes_native_verified']=False;d['original_provider_review']={'archive_prefix':'original/checkpoint/','provider':'anthropic','model':'claude-sonnet-5-5','calls':1,'files':20,'bytes':89210,'cli_exit_code':1,'retained_findings':2,'disposition':'BOTH_REPRODUCED_AND_FIXED; original rejection preserved'};d['review_regressions']=['Core Right/ShiftTab/Space before owner delivery','Core Right/ShiftTab/Enter before owner delivery','Focused option becomes disabled with unchanged FocusRequest','Whole strip disabled with focusable page descendants','Pending delivery versus authoritative publication','Admission refusal preserves previous pending intent','Hidden/disposed pending capabilities retire'];p.write_text(json.dumps(d,indent=2)+'\n')
(F/'review-paths.json').write_bytes((W/'review-paths.json').read_bytes());print(json.dumps({'paths':20,'native_qualified':False,'original_prism_findings_fixed':2}))
