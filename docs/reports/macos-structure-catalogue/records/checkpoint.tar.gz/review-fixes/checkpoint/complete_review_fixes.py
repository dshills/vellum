from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13');p=T/'drivers/cogent/tab_navigation.go';s=p.read_text().replace('"cogentcore.org/core/events"','"cogentcore.org/core/core"\n "cogentcore.org/core/events"',1)
a=s.index('\t\t// No enabled header:');b=s.index('\n\t\treturn',a)
s=s[:a]+'''  // Skip the whole owned subtree, including private Parts. Child descriptor
  // sync follows this boundary, so their old enabled flags cannot admit focus.
  last:=r.widget
  for {
   wb:=last.AsWidget()
   if wb.Parts!=nil && wb.Parts.HasChildren() {last=wb.Parts.Child(wb.Parts.NumChildren()-1).(core.Widget);continue}
   if wb.HasChildren() {last=wb.Child(wb.NumChildren()-1).(core.Widget);continue}
   break
  }
  if manager:=binding.button.Events();manager!=nil {manager.FocusNextFrom(last)}'''+s[b:];p.write_text(s)
p=T/'drivers/cogent/tab_navigation_test.go';s=p.read_text()+'''

func TestTabPendingSelectionDeliveryRefusalAndRetirement(t *testing.T) {
 a,_:=newAXTest(t,1)
 host:=core.NewFrame(core.NewBody("pending selection"))
 var proposals []string
 n:=ui.Node{ID:"tabs",Kind:ui.Tabs,SelectedID:"a",Options:[]ui.Option{{ID:"a"},{ID:"b"}},Children:[]ui.Node{{ID:"a",Kind:ui.Column},{ID:"b",Kind:ui.Column}},Change:func(e ui.ChangeEvent){proposals=append(proposals,e.SelectedID)}}
 r,err:=reconcile(host,nil,n,a,"ax");if err!=nil{t.Fatal(err)}
 defer disposeControlTree(r)
 origin,target:=r.control.tabs.bindings["a"],r.control.tabs.bindings["b"]
 queueTabSelection(r,"a",origin,"b",target,false)
 first:=r.control.tabs.pending.Load();if first==nil{t.Fatal("missing admitted intent")}
 queueTabSelection(r,"b",target,"a",origin,true) // full queue refuses this proposal
 if r.control.tabs.pending.Load()!=first{t.Fatal("refusal overwrote admitted intent")}
 a.Drain()
 if len(proposals)!=1||proposals[0]!="b"||r.control.tabs.pending.Load()!=first{t.Fatal("delivery prematurely retired input baseline",proposals)}
 // Acceptance/rejection has not yet been published to the native strip.
 queueTabSelection(r,"a",origin,"a",origin,false);a.Drain()
 if len(proposals)!=2||proposals[1]!="a"{t.Fatal("activation after delivery but before publication lost",proposals)}
 r,err=reconcile(host,r,n,a,"ax");if err!=nil{t.Fatal(err)}
 if r.control.tabs.pending.Load()!=nil{t.Fatal("authoritative reconciliation retained delivered intent")}
 if err:=a.Post(func(){});err!=nil{t.Fatal(err)}
 queueTabSelection(r,"a",origin,"b",target,false)
 if r.control.tabs.pending.Load()!=nil{t.Fatal("refused first input retained intent")};a.Drain()
 queueTabSelection(r,"a",origin,"b",target,false);syncTabVisibility(r,false,nil)
 if r.control.tabs.pending.Load()!=nil{t.Fatal("hidden strip retained intent")};a.Drain()
 if len(proposals)!=2{t.Fatal("hidden pending input acted",proposals)}
 syncTabVisibility(r,true,nil);queueTabSelection(r,"a",origin,"b",target,false)
 disposeControlTree(r)
 if r.control.tabs.pending.Load()!=nil{t.Fatal("disposal retained intent")};a.Drain()
 if len(proposals)!=2{t.Fatal("disposed pending input acted",proposals)}
}
''';p.write_text(s)
print('Completed subtree-safe focus repair and bounded intent retirement coverage.')
