from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
F=Path(__file__).resolve().parent;W=F.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes());digest=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=60,capture_output=True,check=True).stdout
def vec(root):return{p.relative_to(root).as_posix():sha(p)for p in root.rglob('*')if p.is_file()}
def prep(root):return{m+'/'+n:z for m in ['upstream','typesetting']for n,z in vec(root/'drivers/cogent/build'/m).items()}
plan=read(W/'plan.json');assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==plan['head']and not git(C,'status','--porcelain')
canonical={n:sha(C/n)for n in git(C,'ls-files','-z').decode().split('\0')if n};assert canonical==plan['canonical_source']
source={n:sha(T/n)for n in git(T,'ls-files','-z').decode().split('\0')if n and n.endswith('.go')};assert len(source)<2000
for n in ['tabs-final','driver-final','gallery-final','vet-final','build-final']:
 d=read(F/(n+'.json'));assert d['exit_code']==0 and d['logs_complete']and d['pins_stable']and d['owned']['group_absent'];assert all(sha(p)==z for p,z in d['source_pins'].items())
p=prep(C);assert prep(T)==p==plan['prepared']and len(p)==6268
sdk=vec(Path(plan['sdk']));assert sdk==plan['sdk_files']and len(sdk)==7880
r={'result':'REVIEW_FIXED_SOFTWARE_BOUNDARY_PASS','base_commit':plan['head'],'canonical_files':len(canonical),'canonical_source_sha256':digest(canonical),'go_files':len(source),'go_source_sha256':digest(source),'go_source':source,'prepared_files':len(p),'prepared_sha256':digest(p),'sdk_files':len(sdk),'sdk_sha256':digest(sdk),'sdk_unchanged':True,'native_executed_after_review_fixes':False};(F/'software-source.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='go_source'}))
