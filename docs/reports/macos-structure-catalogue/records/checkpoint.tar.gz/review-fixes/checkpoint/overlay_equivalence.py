from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
F=Path(__file__).resolve().parent;W=F.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=read(W/'plan.json');sdk=Path(p['sdk']);o=read(W/'overlay.json')['Replace'];go=read(F/'software-source.json')['go_source'];compared={}
for n,z in go.items():
 if n.startswith('prototypes/'):continue
 q=Path(o.get(str(sdk/n),str(sdk/n)));assert q.is_file()and sha(q)==z;compared[n]=z
assert len(compared)==650
for n,z in p['prepared'].items():
 relative='drivers/cogent/build/'+n;q=Path(o.get(str(sdk/relative),str(sdk/relative)));assert q.is_file()and sha(q)==z
support={}
for relative in p['candidate_source']:
 if not relative.startswith('drivers/cogent/') or relative.startswith('drivers/cogent/build/') or not (Path(relative).suffix in ['.c','.h','.m','.mm'] or relative=='drivers/cogent/go.sum'):continue
 q=T/relative;actual=Path(o.get(str(sdk/relative),str(sdk/relative)));assert actual.is_file()and sha(actual)==sha(q);support[relative]=sha(q)
r={'result':'ALL_CONSUMER_GO_AND_PREPARED_MATCH_EFFECTIVE_SDK_OVERLAY','consumer_go_files':650,'prepared_files':6268,'overlay_mappings':len(o),'unchanged_sdk_supplies_equal_unmapped_files':True,'consumer_go_sha256':hashlib.sha256(json.dumps(compared,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'native_support':support,'overlay_sha256':sha(W/'overlay.json'),'software_source_sha256':sha(F/'software-source.json'),'script_sha256':sha(Path(__file__))};(F/'overlay-equivalence.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
