from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
F=Path(__file__).resolve().parent;W=F.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-structure-catalogue/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
review=read(F/'internal-prism-disposition.json');assert review['approved']and not review['unresolved_findings']and review['original_findings_resolved']
files={}
def add(p,n):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in files and not n.startswith('/')and '..'not in Path(n).parts;files[n]=p
def checks(root,names,prefix):
 for name in names:
  add(root/(name+'.json'),prefix+'/'+name+'.json')
  for stream in ['stdout','stderr','owned.json']:
   q=root/name/stream
   if q.is_file():add(q,prefix+'/'+name+'/'+stream)
checks(W,['routing-v1','routing-v2','routing-v3','burst-negative','burst-negative-v2','tabs-fixed','routing-v4','readonly-negative','tabs-final','driver-final','gallery-final','vet-final','vet-root-final','build-final','validation-final'],'original/checks')
checks(F,['negative','fixed-v1','subtree-negative','fixed-v2','tabs-final','driver-final','gallery-final','vet-final','build-final'],'review-fixes/checks')
for root,prefix in [(W/'versions','original/versions'),(F/'versions','review-fixes/versions'),(F/'provider-source','original/provider-source')]:
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,prefix+'/'+p.relative_to(root).as_posix())
for n in ['run.py','check.py','root_vet.py','check_validation.py','validate.py','validation_controls.py','overlay.json','internal-source-review.json','plan.json','admission.json','result.json','stop-live','failed-post-boundary.json','internal-native-failure-review.json','internal-geometry-review.json','prefix.py','prefix-attempt.json','finish_docs.py','stage.py','review-paths.json','review-scope.json','staged.diff','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json']:add(W/n,'original/checkpoint/'+n)
for n in ['new-tests.fragment','apply_review_fixes.py','complete_review_fixes.py','check.py','software_boundary.py','software-source.json','overlay_equivalence.py','overlay-equivalence.json','internal-overlay-equivalence-review.json','internal-fix-source-review.json','document_review_fixes.py','stage.py','review-paths.json','review-scope.json','staged.diff','finalize_provider_docs.py','final-scope.json','final-staged.diff','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','archive.py','ready_commit.py','post_promotion.py']:add(F/n,'review-fixes/checkpoint/'+n)
for n in ['internal-native-failure-review.json','internal-geometry-review.json']:add(W/n,'checkpoint/'+n)
for n in ['stdout','stderr','owned.json']:add(W/'case'/n,'original/native/'+n)
for n in read(F/'final-scope.json')['paths']:add(T/n,'source/'+n)
origins={n:str(p)for n,p in sorted(files.items())};(F/'member-origins.json').write_text(json.dumps(origins,indent=2)+'\n');add(F/'member-origins.json','review-fixes/checkpoint/member-origins.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(x['bytes']for x in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(x['bytes']<=10<<20 for x in manifest.values())
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as out:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;out.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as check:
 for m in check:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=check.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
prism=read(F/'prism.json');command=read(F/'prism-command.json')
r={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'native_record':'FAILED41/35; full50/42 pending','native_source_predates_review_fixes':True,'review_fixes_native_verified':False,'independent_35_state_validation_complete':False,'physical_input_verified':False,'full_mac_complete':False,'provider_review':{'provider':'anthropic','model':'claude-sonnet-5-5','total_calls':2,'original_files':20,'original_bytes':89210,'original_exit_code':1,'original_retained_findings':2,'original_findings_reproduced_and_fixed':True,'final_calls':prism['coverage']['llmCalls'],'final_files':len(read(F/'review-scope.json')['paths']),'complete':prism['coverage']['complete'],'exit_code':command['exit_code'],'final_retained_findings':len(prism['findings']),'internal_disposition_approved':review['approved']}};(R/'archive.json').write_text(json.dumps(r,indent=2)+'\n');(F/'archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
