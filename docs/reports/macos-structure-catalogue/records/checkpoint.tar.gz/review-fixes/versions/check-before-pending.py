from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;A=W.parent.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'drivers/cogent'
s=importlib.util.spec_from_file_location('structure_guard',A/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);sdk=Path(json.loads((A/'macos-navigation-embedded-d9eb5ab/plan.json').read_bytes())['sdk'])
name,kind=sys.argv[1:];overlay=W.parent/'overlay.json'
if not overlay.exists():
 r=json.loads((A/'macos-navigation-catalogue-d9eb5ab/stage84-overlay.json').read_bytes())
 for original,replacement in list(r['Replace'].items()):
  relative=Path(original).relative_to(sdk)
  if relative.as_posix().startswith('examples/'):continue
  current=T/relative;assert current.is_file();r['Replace'][original]=str(current)
 for n in ['structure_controls.go','structure_catalogue.go','structure_catalogue_test.go','structure_catalogue_offscreen_test.go']:
  p='drivers/cogent/cmd/gallery/'+n;r['Replace'][str(sdk/p)]=str(T/p)
 overlay.write_text(json.dumps(r,indent=2)+'\n')
paths=[Path(p)for p in json.loads(overlay.read_bytes())['Replace'].values()if p]+[overlay,Path(__file__),Path(h.__file__),h.GUARD,h.GO];pins={str(p):h.sha(p)for p in paths}
base=['-p=1','-overlay='+str(overlay),'-tags=offscreen']
if kind=='review':args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^Test(TabActivationAfterPendingNavigation|TabFocusedOptionDisableRepairsNavigation)$','.']
elif kind=='routing':args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^TestStructureCatalogue','./cmd/gallery']
elif kind=='burst':args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^TestTabKeyboardBurstPreservesAbsoluteReturnProposal$','.']
elif kind=='readonly':args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^TestTabSelectionReadOnlyTransitionsNeverReviveInput$','.']
elif kind=='tabs':args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^Test(TabsActualControlledKeyboardNavigation|TabSelectionQueuedCapabilitiesAndLatestOwner|TabKeyboardBurstPreservesAbsoluteReturnProposal|TabSelectionReadOnlyTransitionsNeverReviveInput|TabActivationAfterPendingNavigation|TabFocusedOptionDisableRepairsNavigation)$','.']
elif kind=='driver':args=['test','-v','-race','-count=1',*base,'-timeout=8m','.']
elif kind=='gallery':args=['test','-v','-race','-count=1',*base,'-timeout=2m','./cmd/gallery']
elif kind=='vet':args=['vet',*base,'.','./cmd/gallery']
elif kind=='build':args=['build','-p=1','-overlay='+str(overlay),'-o',str(W/'native-gallery'),'./cmd/gallery']
else:raise ValueError(kind)
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args],sdk/'drivers/cogent',W/name,lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=540 if kind=='driver'else 240,limit=4<<20);r['source_pins']=pins;r['native_executed']=False
if kind=='build'and r['exit_code']==0:r['binary']={'path':str(W/'native-gallery'),'sha256':h.sha(W/'native-gallery')}
(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
