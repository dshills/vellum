# Controlled tab keyboard navigation

Managed Tabs now handle unmodified Left/Right, Home/End and Space/Enter through
public controlled selection callbacks. Arrows wrap and skip disabled options;
Home/End choose enabled endpoints. Native header focus changes at the originating
event boundary; owner delivery proposes stable IDs and preserves rejected state.
Read-only input moves focus without mutations, selected activation is a no-op,
and existing pointer repeats and Delete/Backspace close behavior remain supported.

The queue captures absolute movement intent before owner delivery: rapid A→B→A
must produce B,A even before reconciliation. Input-time write permission cannot
revive later. Origin/target binding epochs retire on hiding, disabling, removal,
closed dialog scope and nil/non-nil Change transitions. Owner delivery uses owner
values and atomic lifetimes, with no native traversal/focus from another window.

Final complete driver-root (`.`) and gallery race suites, focused tab/lifecycle
regressions, root/gallery vet and native build pass. The public Manual consumer
checks shared ordinary Disclosure/SplitPane/document constructors, retained child
incarnations, actual keys and pointer routing, exact divider geometry, scrolling
endpoints and controlled document close/stale refusal. The old burst implementation
reproduces B-only; both read-only transition cases reproduce an unwanted callback.
The fixed implementation passes. Initial absent-arrow, test-event cloning and
missing-overlay build failures remain explicit in the raw records and versions.
One positive and 34 negative synthetic oracle controls pass, separately from
native evidence. No new public API signature or catalogue kind is added.

The new runnable `gallery -structure-native-check` authors 50 inputs and 42
observations. Its **first native run FAILED** after 41 acknowledged inputs and
35 source-asserted observations ending at `page-documents`. Both subsequent
`document-notes` pointer packets are acknowledged, but the next Frame fails with
`composition did not submit a measured frame` before Snapshot/model observation.
No notes-selection result or failed snapshot is inferred. The planned original-
window close was not reached; failure cleanup closes the session after 194 issued
requests, with no pending
request/live window and confirms owned process group32943 absent. A separate
post-failure check proves complete source/prepared/SDK/binary boundaries unchanged;
it is not the controller's unexecuted post-validation boundary. The scope is sealed.

The measured GPU path starts Supported=true; a nil render pass with nil error
can leave Submitted=false and no specific failure, producing this generic trace
error. Actual acquisition status/attempt count is not retained. Occlusion,
timeout, exhausted lost/outdated recovery and null-handle cases cannot be
identified from this record. The next implementation action is a bounded measured
acquisition outcome/attempt diagnostic with injected unavailable/lost/null-handle
regressions. Preserve ordinary no-frame behavior, retry count and strict Frame
success criteria; do not convert this failure into a pass or retry the sealed case.

The pre-admitted independent oracle is also too strong about expanded disabled
geometry: section-after Y is250 normally,236 disabled and138 collapsed. A later
prefix validation stops at this original equality guard; no independent35-state
pass is claimed. Review confirms that disabled button shadow margins and text-
field borders change these metrics: the heading, draft and action heights shrink
by 6+2+6px, accounting for the 14px shift. This establishes a false cross-style
oracle assumption, with no new product layout defect. Keep that oracle unchanged
with this failed record. A future scope must compare restoration within the same
effective style or independently cover state-specific metrics. The compiled consumer's
accepted state, visibility/focus and divider guards are unchanged.

Internal source/controller, exact-plan admission, failure/provider disposition
and final archive/commit reviews are checkpoint requirements. One scoped Prism
Anthropic Claude Sonnet5.5 review is required before commit. The bounded
[archive](records/checkpoint.tar.gz) and [manifest](records/manifest.json) will
retain original checks, failures, versions and review payload without binaries
or SDK copies. This is a tested keyboard product fix, not structural native
acceptance closure. Full50/42, fullM2/M5 and M3–M7 remain open.

Evidence uses Go1.25.6 ARM64/GOMAXPROCS2 CPU-scene over retained source-built native
archive786a only. Both checkouts keep identical stage84 prepared files; all7880
retained SDK files are unchanged. The overlay matches all current non-prototype
Go source and prepared bytes. The SDK's native library module override is scoped
and is not qualification of the checkout's default cached library. No OS settings,
input sources, clipboard, SDK refresh or public release changes occur. Go FIFO
does not establish physical/OS input, native pixels, VoiceOver/IME, actual split
dragging, arbitrary resize/display transitions, presentation, performance or
native deallocation/endurance. Earlier full workspace records retain their pinned
sources; this tab-selection delta does not requalify that full record. Follow the
unchanged [Mac delivery plan](../../../specs/macos-delivery.md).
