//go:build offscreen

package cogent

import (
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/styles/states"
	"github.com/dshills/vellum/ui"
	"testing"
)

func TestTabsActualControlledKeyboardNavigation(t *testing.T) {
	selected := "a"
	calls := 0
	reject, readonly, disabled := false, false, false
	view := func() ui.Node {
		n := ui.Node{ID: "tabs", Kind: ui.Tabs, Grow: true, SelectedID: selected, Disabled: disabled, Focus: ui.FocusRequest{ID: "tabs", Sequence: 1}, Options: []ui.Option{{ID: "a", Label: "Same"}, {ID: "b", Label: "Blocked", Disabled: true}, {ID: "c", Label: "Same"}, {ID: "d", Label: "Last"}}, Children: []ui.Node{{ID: "a", Kind: ui.Column, Children: []ui.Node{{ID: "draft", Kind: ui.TextField, Text: "Retained"}}}, {ID: "b", Kind: ui.Column}, {ID: "c", Kind: ui.Column}, {ID: "d", Kind: ui.Column}}}
		if !readonly {
			n.Change = func(e ui.ChangeEvent) {
				calls++
				if !reject {
					selected = e.SelectedID
				}
			}
		}
		return n
	}
	m, a := simpleManual(t, manualConfig(t, 7), view)
	unitSettle(t, m)
	w := m.implementation.find("one")
	r := w.state.root
	draft := findRecord(r, "draft").widget
	send := func(code key.Codes) {
		t.Helper()
		if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Code: code}); err != nil {
			t.Fatal(err)
		}
		unitSettle(t, m)
	}
	focused := func(id string) {
		t.Helper()
		for current, b := range r.control.tabs.buttons {
			if b.ContainsFocus() != (current == id) {
				t.Fatal("actual tab focus", current, id)
			}
		}
	}
	send(key.CodeRightArrow)
	if selected != "c" || calls != 1 {
		t.Fatal("disabled skip", selected, calls)
	}
	focused("c")
	send(key.CodeRightArrow)
	send(key.CodeRightArrow)
	if selected != "a" || calls != 3 {
		t.Fatal("wrap", selected, calls)
	}
	focused("a")
	send(key.CodeEnd)
	if selected != "d" || calls != 4 {
		t.Fatal("End", selected, calls)
	}
	send(key.CodeHome)
	if selected != "a" || calls != 5 {
		t.Fatal("Home", selected, calls)
	}
	reject = true
	send(key.CodeRightArrow)
	if selected != "a" || calls != 6 {
		t.Fatal("rejection", selected, calls)
	}
	focused("c")
	if !r.control.tabs.buttons["a"].StateIs(states.Selected) || r.control.tabs.buttons["c"].StateIs(states.Selected) {
		t.Fatal("rejection left optimistic selection")
	}
	reject = false
	send(key.CodeSpacebar)
	if selected != "c" || calls != 7 {
		t.Fatal("focused activation", selected, calls)
	}
	send(key.CodeReturnEnter)
	if calls != 7 {
		t.Fatal("selected Enter duplicated callback")
	}
	if err := a.Do(func() { readonly = true; _ = a.Invalidate("one") }); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, m)
	send(key.CodeHome)
	focused("a")
	if selected != "c" || calls != 7 {
		t.Fatal("readonly mutated selection", selected, calls)
	}
	if err := a.Do(func() { readonly = false; _ = a.Invalidate("one") }); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, m)
	send(key.CodeReturnEnter)
	if selected != "a" || calls != 8 || findRecord(r, "draft").widget != draft {
		t.Fatal("retained page or controlled activation lost", selected, calls)
	}
	// A handled or modified chord belongs to the earlier command/native route.
	for _, modified := range []bool{false, true} {
		e := events.NewKey(events.KeyChord, 0, key.CodeRightArrow, 0)
		if modified {
			e.Mods = 1 << key.Meta
		} else {
			e.SetHandled()
		}
		tabNavigationKey(r, "a", r.control.tabs.bindings["a"], e)
		a.Drain()
		if calls != 8 {
			t.Fatal("command/modified chord was intercepted")
		}
	}
	if err := a.Do(func() { disabled = true; _ = a.Invalidate("one") }); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, m)
	if r.control.tabs.bindings["a"].selectEpoch.Load() != nil {
		t.Fatal("disabled navigation retained authority")
	}
}
