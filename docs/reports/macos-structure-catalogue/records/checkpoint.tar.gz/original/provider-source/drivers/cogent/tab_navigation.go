package cogent

import (
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/ui"
)

// The binding and its immutable visibility epoch belong to the originating
// strip. Owner delivery reads only owner values and atomic scope lifetimes.
func tabSelectionEnabled(r *record, id string, binding *tabBinding) bool {
	return binding != nil && r != nil && r.control != nil && !r.control.retired && !r.control.disabled && r.control.tabs != nil && r.control.tabs.visible && r.control.tabs.bindings[id] == binding && choiceOptionEnabled(r.node, id)
}
func queueTabSelection(r *record, originID string, origin *tabBinding, id string, target *tabBinding, repeat bool) {
	if origin == nil || target == nil {
		return
	}
	from, to := origin.selectEpoch.Load(), target.selectEpoch.Load()
	if !tabCloseEpochLive(from) || !tabCloseEpochLive(to) {
		return
	}
	// Freeze input-time intent: the rendered SelectedID can lag earlier owner proposals.
	propose := r.node.Change != nil && (repeat || r.node.SelectedID != id)
	postControl(r, func() {
		if !tabCloseEpochLive(from) || !tabCloseEpochLive(to) || origin.selectEpoch.Load() != from || target.selectEpoch.Load() != to || !tabSelectionEnabled(r, originID, origin) || !tabSelectionEnabled(r, id, target) || r.node.Change == nil {
			requestControlRestore(r)
			return
		}
		if propose {
			r.node.Change(ui.ChangeEvent{ID: r.node.ID, Kind: ui.Tabs, SelectedID: id})
			r.control.committed = true
		}
		requestControlRestore(r)
	})
}
func tabNavigationKey(r *record, id string, binding *tabBinding, e events.Event) {
	if e.IsHandled() || e.Modifiers() != 0 || !tabSelectionEnabled(r, id, binding) || !tabCloseEpochLive(binding.selectEpoch.Load()) {
		return
	}
	step := 0
	edge := false
	target := id
	switch e.KeyCode() {
	case key.CodeLeftArrow:
		step = -1
	case key.CodeRightArrow:
		step = 1
	case key.CodeHome:
		step = 1
		edge = true
	case key.CodeEnd:
		step = -1
		edge = true
	case key.CodeSpacebar, key.CodeReturnEnter:
	default:
		return
	}
	if step != 0 {
		index := -1
		if !edge {
			for i, o := range r.node.Options {
				if o.ID == id {
					index = i
					break
				}
			}
		}
		if index < 0 && step < 0 {
			index = 0
		}
		target = ""
		for range len(r.node.Options) {
			index = (index + step + len(r.node.Options)) % len(r.node.Options)
			o := r.node.Options[index]
			if tabSelectionEnabled(r, o.ID, r.control.tabs.bindings[o.ID]) {
				target = o.ID
				break
			}
		}
	}
	if target == "" {
		return
	}
	next := r.control.tabs.bindings[target]
	if next == nil {
		return
	}
	e.SetHandled()
	next.button.SetFocus() // originating native event boundary only
	queueTabSelection(r, id, binding, target, next, target != id)
}
