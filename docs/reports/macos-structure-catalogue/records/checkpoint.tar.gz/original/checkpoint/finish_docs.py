from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(W/'result.json');assert r['result']=='FAILED_OR_CANCELED'and (W/'stop-live').is_file()
raw=read(W/'case/stdout');assert raw['Result']=='FAILED_NATIVE_STRUCTURE'and len(raw['Inputs'])==41 and len(raw['Steps'])==35 and raw['Failed']is None
assert read(W/'failed-post-boundary.json')['result']=='UNCHANGED_AFTER_FAILED_NATIVE'
report=T/'docs/reports/macos-structure-catalogue';(report/'records').mkdir(parents=True,exist_ok=False)
(report/'README.md').write_text('''# Controlled tab keyboard navigation

Managed Tabs now handle unmodified Left/Right, Home/End and Space/Enter through
public controlled selection callbacks. Arrows wrap and skip disabled options;
Home/End choose enabled endpoints. Native header focus changes at the originating
event boundary; owner delivery proposes stable IDs and preserves rejected state.
Read-only input moves focus without mutations, selected activation is a no-op,
and existing pointer repeats and Delete/Backspace close behavior remain supported.

The queue captures absolute movement intent before owner delivery: rapid A→B→A
must produce B,A even before reconciliation. Input-time write permission cannot
revive later. Origin/target binding epochs retire on hiding, disabling, removal,
closed dialog scope and nil/non-nil Change transitions. Owner delivery uses owner
values and atomic lifetimes, with no native traversal/focus from another window.

Final complete driver-root (`.`) and gallery race suites, focused tab/lifecycle
regressions, root/gallery vet and native build pass. The public Manual consumer
checks shared ordinary Disclosure/SplitPane/document constructors, retained child
incarnations, actual keys and pointer routing, exact divider geometry, scrolling
endpoints and controlled document close/stale refusal. The old burst implementation
reproduces B-only; both read-only transition cases reproduce an unwanted callback.
The fixed implementation passes. Initial absent-arrow, test-event cloning and
missing-overlay build failures remain explicit in the raw records and versions.
One positive and 34 negative synthetic oracle controls pass, separately from
native evidence. No new public API signature or catalogue kind is added.

The new runnable `gallery -structure-native-check` authors 50 inputs and 42
observations. Its **first native run FAILED** after 41 acknowledged inputs and
35 source-asserted observations ending at `page-documents`. Both subsequent
`document-notes` pointer packets are acknowledged, but the next Frame fails with
`composition did not submit a measured frame` before Snapshot/model observation.
No notes-selection result or failed snapshot is inferred. The planned original-
window close was not reached; failure cleanup closes the session after 194 issued
requests, with no pending
request/live window and confirms owned process group32943 absent. A separate
post-failure check proves complete source/prepared/SDK/binary boundaries unchanged;
it is not the controller's unexecuted post-validation boundary. The scope is sealed.

The measured GPU path starts Supported=true; a nil render pass with nil error
can leave Submitted=false and no specific failure, producing this generic trace
error. Actual acquisition status/attempt count is not retained. Occlusion,
timeout, exhausted lost/outdated recovery and null-handle cases cannot be
identified from this record. The next implementation action is a bounded measured
acquisition outcome/attempt diagnostic with injected unavailable/lost/null-handle
regressions. Preserve ordinary no-frame behavior, retry count and strict Frame
success criteria; do not convert this failure into a pass or retry the sealed case.

The pre-admitted independent oracle is also too strong about expanded disabled
geometry: section-after Y is250 normally,236 disabled and138 collapsed. A later
prefix validation stops at this original equality guard; no independent35-state
pass is claimed. Review confirms that disabled button shadow margins and text-
field borders change these metrics: the heading, draft and action heights shrink
by 6+2+6px, accounting for the 14px shift. This establishes a false cross-style
oracle assumption, with no new product layout defect. Keep that oracle unchanged
with this failed record. A future scope must compare restoration within the same
effective style or independently cover state-specific metrics. The compiled consumer's
accepted state, visibility/focus and divider guards are unchanged.

Internal source/controller, exact-plan admission, failure/provider disposition
and final archive/commit reviews are checkpoint requirements. One scoped Prism
Anthropic Claude Sonnet5.5 review is required before commit. The bounded
[archive](records/checkpoint.tar.gz) and [manifest](records/manifest.json) will
retain original checks, failures, versions and review payload without binaries
or SDK copies. This is a tested keyboard product fix, not structural native
acceptance closure. Full50/42, fullM2/M5 and M3–M7 remain open.

Evidence uses Go1.25.6 ARM64/GOMAXPROCS2 CPU-scene over retained source-built native
archive786a only. Both checkouts keep identical stage84 prepared files; all7880
retained SDK files are unchanged. The overlay matches all current non-prototype
Go source and prepared bytes. The SDK's native library module override is scoped
and is not qualification of the checkout's default cached library. No OS settings,
input sources, clipboard, SDK refresh or public release changes occur. Go FIFO
does not establish physical/OS input, native pixels, VoiceOver/IME, actual split
dragging, arbitrary resize/display transitions, presentation, performance or
native deallocation/endurance. Earlier full workspace records retain their pinned
sources; this tab-selection delta does not requalify that full record. Follow the
unchanged [Mac delivery plan](../../../specs/macos-delivery.md).
''')
checks={}
for n in ['tabs-final','driver-final','gallery-final','vet-root-final','build-final','validation-final']:
 c=read(W/(n+'.json'));checks[n]={'receipt_sha256':sha(W/(n+'.json')),**{k:c[k]for k in ['exit_code','seconds','logs_complete','pins_stable']},'owned_group_absent':c['owned']['group_absent']}
(report/'records/results.json').write_text(json.dumps({'base_commit':'e9896d6bd8a940590f27dd08d971f79a8049cf7c','native':r,'native_inputs':41,'source_asserted_observations':35,'complete_native_record':False,'failed_post_boundary':read(W/'failed-post-boundary.json'),'native_failure_review':{'archive_member':'checkpoint/internal-native-failure-review.json','sha256':sha(W/'internal-native-failure-review.json'),'approved':True,'native_record_qualified':False},'geometry_review':{'archive_member':'checkpoint/internal-geometry-review.json','sha256':sha(W/'internal-geometry-review.json'),'approved':True,'independent_35_observation_pass_claim_permitted':False},'prefix_attempt':read(W/'prefix-attempt.json'),'oracle_prefix_result':'FAILED_ORIGINAL_DISABLED_LAYOUT_EQUALITY_GUARD; no independent35-state pass','checks':checks,'synthetic_positive_controls':1,'synthetic_negative_controls':34,'prepared_files':6268,'sdk_files':7880,'sdk_unchanged':True,'physical_input_verified':False,'native_pixels_verified':False,'closed_full_mac_gates':[],'goal_complete':False},indent=2)+'\n')
p=T/'specs/controls.md';s=p.read_text();marker='A Tabs control with no enabled options cannot receive focus.';assert marker in s;s=s.replace(marker,marker+'''

Focused tab headers handle unmodified Left/Right with enabled-option wrap and
Home/End with enabled endpoints; Space/Enter proposes the focused option.
Keyboard movement changes native header focus and queues one stable-ID proposal
through the latest owner callback. Rejected selection stays accepted as before.
Read-only headers can move focus without proposing selection. Activating an
already accepted focused option is a no-op; existing explicit pointer repeats
remain proposals. Modified/previously handled chords keep command priority.
Queued movement retains absolute input-time intent even before a redraw, and
input-time read-only authority cannot revive when a callback is later enabled.
Hiding/disabling/removing a strip, dialog scope closure and nil/non-nil Change
transitions revoke old selection capabilities. Owner callbacks never traverse
originating native widget trees or change their focus from another window.
''',1);p.write_text(s)
p=T/'specs/tab-close.md';p.write_text(p.read_text()+'''
The gallery's new `-structure-native-check` authors selected-document pointer/key
rejection, accepted keyboard close, unchanged selection callback count and
new-frame stale refusal within a 50-input/42-observation scenario, reusing the
ordinary document view. Its first native run stops at a measured-frame failure
before these close observations; they remain native-pending. Actual public
Manual routing and focused regressions pass. See the
[result](../docs/reports/macos-structure-catalogue/README.md). The separate Cocoa
selector/physical/human acceptance requirements above remain unchanged.
''')
p=T/'specs/control-acceptance.md';s=p.read_text();s=s.replace('record; OS/physical input', 'record. **N-partial** means source-asserted observations from a failed native\nrecord with independent validation incomplete; it does not qualify a native pass.\nOS/physical input',1);replacements={
'divider keys/drag, measured ratio and retained child editing | R |':'divider keys/drag, measured ratio and retained child editing; `gallery -structure-native-check`: native prefix through controlled keys/geometry/state; complete50/42 pending | R/N-partial |',
'collapse/reopen, layout release, focus and retained children | R |':'collapse/reopen, layout release, focus and retained children; `gallery -structure-native-check`: source-asserted native prefix through focus/state; disabled style metrics differ; independent oracle incomplete | R/N-partial |',
'page identity | R/A |':'page identity; `gallery -structure-native-check`: native prefix through root-page navigation; document-close native states pending | R/A/N-partial |',
'actual ancestor scroll clips and transformed content | R |':'actual ancestor scroll clips and transformed content; `gallery -structure-native-check`: source-asserted native prefix through scroll endpoints/boundary/restoration; complete record pending | R/N-partial |'}
for old,new in replacements.items():assert old in s;s=s.replace(old,new,1)
marker='The remaining native catalogue work is:';assert marker in s;s=s.replace(marker,'''The [structural catalogue checkpoint](../docs/reports/macos-structure-catalogue/README.md)
adds tested controlled Tabs keyboard navigation. The new 50-input/42-state
native scenario fails after41 inputs/35 source-asserted observations, before
document selection/close results. The measured-frame acquisition reason is
unknown. Review establishes that disabled styling changes metrics, invalidating
the original cross-style geometry equality guard. The failed scope remains sealed. Full structural qualification and
physical/pixels/M2/M5/M3–M7 remain open; N-partial means a failed record prefix.

'''+marker,1);p.write_text(s)
for n in ['macos-delivery.md','macos-completion.md']:
 p=T/'specs'/n;s=p.read_text();s+='''
### Structural controls checkpoint

The [native structural result](../docs/reports/macos-structure-catalogue/README.md)
adds controlled tab keyboard navigation with burst/read-only lifetime fixes.
The new 50-input/42-state native scenario fails after41 inputs/35 source-asserted
observations, before document selection/close results. Preserve the sealed failure;
next record measured acquisition status/attempts without relaxing Frame success
or ordinary retries, and resolve the original disabled-layout equality oracle
using same-style restoration or independently checked state-specific metrics
before a new scope. Full structural catalogue,
physical/pixels/M2/M5/M3–M7 remain open with unchanged thresholds.
''';p.write_text(s)
p=T/'drivers/cogent/cmd/gallery/README.md';p.write_text(p.read_text()+'''
## Native structural controls

```sh
go run ./cmd/gallery -structure-native-check
```

This separate bounded 900x700 requested view reuses ordinary Disclosure/SplitPane
constructors and the document-tab view. It authors 50 Go FIFO inputs/42 observations, emits one result and joins its
worker. The intended successful path closes the original window; failure cleanup
retires the session. The first native run remains failed at41 inputs/35 states. It uses the other
catalogue modes' 90-second deadline, 6-second join, exclusive flags and disabled
process-local geometry persistence. Tested state uses ordinary public callbacks;
owner-posted policies are setup only. The ordinary split page now includes enough
workspace rows to exercise actual scrolling. See the
[result and limitations](../../../../docs/reports/macos-structure-catalogue/README.md).
''')
p=T/'docs/desktop-integration.md';p.write_text(p.read_text()+'''

`gallery -structure-native-check` exercises tabs/disclosure/split/scroll and
controlled document closes through public DesktopSession Go FIFO, with an authored 50-input/42-state record. Its first native run fails at41/35
before document selection/close observations; full native qualification is pending.
The runnable consumer checks actual targets/focus, divider geometry, scrolling,
callbacks, stale refusal and terminal cleanup without substituting semantic actions. The [result](reports/macos-structure-catalogue/README.md)
keeps this evidence separate from physical input, native pixels and broader Mac
qualification. Ordinary tab keyboard navigation is documented in the
[controls contract](../specs/controls.md).
''')
paths=['drivers/cogent/cmd/gallery/'+n for n in ['main.go','documents.go','structure_controls.go','structure_catalogue.go','structure_catalogue_test.go','structure_catalogue_offscreen_test.go','README.md']]+['drivers/cogent/'+n for n in ['controls.go','tab_close.go','tab_navigation.go','tab_navigation_test.go','tab_navigation_offscreen_test.go']]+['specs/'+n for n in ['controls.md','tab-close.md','control-acceptance.md','macos-delivery.md','macos-completion.md']]+['docs/desktop-integration.md','docs/reports/macos-structure-catalogue/README.md','docs/reports/macos-structure-catalogue/records/results.json']
(W/'review-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'paths':len(paths),'native':'FAILED41/35; full50/42 pending'}))
