"""Validate the immutable completed prefix against the pre-admitted full oracle.
No missing observation is inferred; this cannot qualify a complete native pass.
"""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('sealed_structure_oracle',W/'validate.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();plan=json.loads((W/'plan.json').read_bytes());v.need(sha(W/'validate.py')==plan['pins'][str(W/'validate.py')],'unchanged pre-native oracle')
d=json.loads((W/'case/stdout').read_bytes());v.need(d['Result']=='FAILED_NATIVE_STRUCTURE'and d['Error']=='cogent: desktop composition: composition did not submit a measured frame'and d['Failed']is None,'original frame failure, no failed snapshot inferred')
v.need(len(d['Steps'])==35 and len(d['Inputs'])==41 and[x['Label']for x in d['Steps']]==v.LABELS[:35]and[x['Label']for x in d['Inputs']]==[p[0]for p in v.PACKETS[:41]],'exact incomplete prefix')
last=0;extent=None;baseY=None
for i,(step,w)in enumerate(zip(d['Steps'],v.VALUES)):
 actual=step['Model'];v.need(set(actual)==set(w),'prefix model schema')
 for k,z in w.items():v.need((type(actual[k])is type(z)and actual[k]==z)if k!='Fraction'else(type(actual[k])in[int,float]and abs(actual[k]-z)<=1e-5),'pre-admitted literal model '+step['Label']+'/'+k)
 els=v.publication(step['Snapshot'],w,i);frame=step['Snapshot']['Frame'];v.need(frame>last,'prefix observation ordering');last=frame
 current=(step['Snapshot']['Size'],step['Snapshot']['LogicalDPI'])
 if extent is None:extent=current;baseY=els[v.node('section-after')]['Bounds']['Min']['Y']
 v.need(extent==current,'prefix fixed scene')
 if w['Page']=='sections':y=els[v.node('section-after')]['Bounds']['Min']['Y'];v.need(y==baseY if w['Expanded']else y<baseY,'prefix released/restored section layout')
 floor=d['Steps'][i-1]['Snapshot']['Frame']if i else 0;v.need(all(floor<x['Before']['Frame']<frame for x in d['Inputs']if x['Label'].split('/')[0]==step['Label']),'prefix input interleaving')
last=0
for item,(label,target,typ,code,rune,delta,reject)in zip(d['Inputs'],v.PACKETS):
 snap=item['Before'];els=v.snapshot(snap);inp=item['Input'];v.need((snap['Size'],snap['LogicalDPI'])==extent and snap['Frame']>last,'prefix ordered current input');last=snap['Frame'];v.need(inp['Frame']==snap['Frame']and inp['Target']==target and inp['Type']==typ and inp['Code']==code and inp['Rune']==rune and inp['Delta']=={'X':0,'Y':delta}and inp['Modifiers']==''and item['Rejected']==reject,'prefix authored packet '+label);v.need(inp['Button']==('Left'if typ in['MouseDown','MouseUp']else'NoButton'),'prefix packet button');e=els.get(target);v.need(e is not None and e['Enabled']==(not reject),'prefix actual target')
 if typ=='KeyChord':v.need(inp['Position']=={'X':0,'Y':0}and(reject or e['Focused']),'prefix actual key focus')
 else:v.need(not v.empty(e['Bounds'])and inp['Position']=={k:(e['Bounds']['Min'][k]+e['Bounds']['Max'][k])//2 for k in ['X','Y']},'prefix actual measured pointer/scroll')
s=d['Session'];v.need(s['Started']and s['Closed']and not s['Pending']and s['LiveWindows']==0 and d['OriginalRefClosed']is False and d['PostCloseInputError']=='','failed path cleanup, no planned close claim')
r={'result':'INCOMPLETE_NATIVE_PREFIX_VALIDATED','complete_native_pass':False,'inputs':41,'observations':35,'last_observation':'page-documents','last_inputs':['document-notes/MouseDown','document-notes/MouseUp'],'unobserved_state_after_last_input':True,'original_frame_failure':d['Error'],'failed_snapshot_present':False,'session':s,'raw_stdout_sha256':sha(W/'case/stdout'),'oracle_sha256':sha(W/'validate.py'),'script_sha256':sha(Path(__file__))};(W/'prefix-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
