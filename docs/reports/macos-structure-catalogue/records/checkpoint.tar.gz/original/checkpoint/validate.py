"""Independent authored structural catalogue oracle; synthetic fixtures are not native evidence."""
import base64,json,math,re

def need(ok,msg):
 if not ok:raise ValueError(msg)
def id(kind,*parts):return kind+':'+':'.join(base64.urlsafe_b64encode(p.encode()).decode().rstrip('=')for p in parts)
def node(n):return id('node',n)
H=id('disclosure','details');S=id('split','panes');P=node('structure-pages');D=node('document-tabs')
LABELS='initial section-collapse section-tab-skips-hidden section-pointer-reopen section-tab-draft section-child-action section-owner-collapse section-right section-enter section-space section-rejected section-readonly section-disabled section-disabled-refusal section-reenabled page-disabled-refusal page-split-pointer page-home page-disabled-skip split-focus split-right split-left split-home split-end split-rejected split-readonly split-writable split-reset scroll-bottom scroll-boundary scroll-top split-disabled split-disabled-refusal split-reenabled page-documents document-notes document-pointer-rejected document-key-rejected document-key-accepted document-stale-close page-retained-section section-final-reopen'.split()
# Literal independent row table: page,expanded,fraction,details,split,pages,close,select,action,policy,doc,openDocs.
ROWS=[
 ('sections',True,.35,0,0,0,0,0,0,'','sketch','sketch,notes'),
 ('sections',False,.35,1,0,0,0,0,0,'','sketch','sketch,notes'),
 ('sections',False,.35,1,0,0,0,0,0,'','sketch','sketch,notes'),
 ('sections',True,.35,2,0,0,0,0,0,'','sketch','sketch,notes'),
 ('sections',True,.35,2,0,0,0,0,0,'','sketch','sketch,notes'),
 ('sections',True,.35,2,0,0,0,0,1,'','sketch','sketch,notes'),
 ('sections',False,.35,2,0,0,0,0,1,'','sketch','sketch,notes'),
 ('sections',True,.35,3,0,0,0,0,1,'','sketch','sketch,notes'),
 ('sections',False,.35,4,0,0,0,0,1,'','sketch','sketch,notes'),
 ('sections',True,.35,5,0,0,0,0,1,'','sketch','sketch,notes'),
 ('sections',True,.35,6,0,0,0,0,1,'DetailsReject','sketch','sketch,notes'),
 ('sections',True,.35,6,0,0,0,0,1,'DetailsReadOnly','sketch','sketch,notes'),
 ('sections',True,.35,6,0,0,0,0,1,'DetailsDisabled','sketch','sketch,notes'),
 ('sections',True,.35,6,0,0,0,0,1,'DetailsDisabled','sketch','sketch,notes'),
 ('sections',False,.35,7,0,0,0,0,1,'','sketch','sketch,notes'),
 ('sections',False,.35,7,0,0,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,0,1,0,0,1,'','sketch','sketch,notes'),
 ('sections',False,.35,7,0,2,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,0,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,0,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.36,7,1,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,2,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.05,7,3,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.95,7,4,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.95,7,5,3,0,0,1,'SplitReject','sketch','sketch,notes'),
 ('split-page',False,.95,7,5,3,0,0,1,'SplitReadOnly','sketch','sketch,notes'),
 ('split-page',False,.05,7,6,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'SplitDisabled','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'SplitDisabled','sketch','sketch,notes'),
 ('split-page',False,.35,7,6,3,0,0,1,'','sketch','sketch,notes'),
 ('documents',False,.35,7,6,4,0,0,1,'','sketch','sketch,notes'),
 ('documents',False,.35,7,6,4,0,1,1,'','notes','sketch,notes'),
 ('documents',False,.35,7,6,4,1,1,1,'CloseReject','notes','sketch,notes'),
 ('documents',False,.35,7,6,4,2,1,1,'CloseReject','notes','sketch,notes'),
 ('documents',False,.35,7,6,4,3,1,1,'','sketch','sketch'),
 ('documents',False,.35,7,6,4,3,1,1,'','sketch','sketch'),
 ('sections',False,.35,7,6,5,3,1,1,'','sketch','sketch'),
 ('sections',True,.35,8,6,5,3,1,1,'','sketch','sketch'),
]
POLICY='DetailsReject DetailsReadOnly DetailsDisabled SplitReject SplitReadOnly SplitDisabled CloseReject'.split()
COUNTS='DetailsRequests SplitRequests PageRequests DocumentRequests DocumentSelections SectionActions'.split()
def model(row):
 p,expanded,f,dr,sr,pr,cr,ds,ac,policy,doc,docs=row
 return dict(Page=p,Document=doc,Documents=docs,Text='Vellum',Expanded=expanded,Fraction=f,**dict(zip(COUNTS,[dr,sr,pr,cr,ds,ac])),**{k:k==policy for k in POLICY})
VALUES=[model(r)for r in ROWS]
FOCUS=[H,H,node('section-after'),H,node('section-draft'),node('section-action'),H,H,H,H,H,H,'','',H,H,P,P,P,S,S,S,S,S,S,S,S,node('split-reset'),'','','','','',S,P,D,D,D,'','',P,H]
PACKETS=[]
def key(label,target,code,rune=0,reject=False):PACKETS.append((label,target,'KeyChord',code,rune,0,reject))
def click(label,target):
 for typ in ['MouseDown','MouseUp']:PACKETS.append((label+'/'+typ,target,typ,'Unknown',0,0,False))
key('section-collapse',H,'LeftArrow');key('section-tab-skips-hidden',H,'Tab');click('section-pointer-reopen',H);key('section-tab-draft',H,'Tab');click('section-child-action',node('section-action'));key('section-right',H,'RightArrow');key('section-enter',H,'ReturnEnter');key('section-space',H,'Spacebar',32);key('section-rejected',H,'LeftArrow');key('section-readonly',H,'LeftArrow');key('section-disabled-refusal',H,'LeftArrow',reject=True);click('section-reenabled',H);key('page-disabled-refusal',id('option','structure-pages','unavailable'),'RightArrow',reject=True);click('page-split-pointer',id('option','structure-pages','split-page'));key('page-home',P,'Home');key('page-disabled-skip',P,'RightArrow');click('split-focus',S);key('split-right',S,'RightArrow');key('split-left',S,'LeftArrow');key('split-home',S,'Home');key('split-end',S,'End');key('split-rejected',S,'Home');key('split-readonly',S,'Home');key('split-writable',S,'Home');click('split-reset',node('split-reset'))
for label,delta in [('scroll-bottom',100000),('scroll-boundary',100000),('scroll-top',-100000)]:PACKETS.append((label,node('split-workspace'),'Scroll','Unknown',0,delta,False))
key('split-disabled-refusal',S,'Home',reject=True);click('split-reenabled',S);click('page-documents',id('option','structure-pages','documents'));click('document-notes',id('option','document-tabs','notes'));click('document-pointer-rejected',id('tab-close','document-tabs','notes'));key('document-key-rejected',D,'Delete');key('document-key-accepted',D,'Delete');PACKETS.append(('document-stale-close',id('tab-close','document-tabs','notes'),'MouseDown','Unknown',0,0,True));click('page-retained-section',id('option','structure-pages','sections'));click('section-final-reopen',H)
assert len(LABELS)==len(VALUES)==len(FOCUS)==42 and len(PACKETS)==50

def point(p):return isinstance(p,dict)and set(p)=={'X','Y'}and all(type(v)is int and abs(v)<2**31 for v in p.values())
def rect(r):return isinstance(r,dict)and set(r)=={'Min','Max'}and point(r['Min'])and point(r['Max'])
def empty(r):return r['Min']['X']>=r['Max']['X']or r['Min']['Y']>=r['Max']['Y']
def contains(r,p):return all(r['Min'][k]<=p[k]<r['Max'][k]for k in ['X','Y'])
def snapshot(s):
 need(type(s['Frame'])is int and s['Frame']>0 and point(s['Size'])and all(0<v<=8192 for v in s['Size'].values())and type(s['LogicalDPI'])in[int,float]and math.isfinite(s['LogicalDPI'])and 80<=s['LogicalDPI']<=960,'frame/scene schema')
 need(not s['Popups']and not s['Grids']and not s['Trees']and not s['Canvases']and 0<len(s['Elements'])<=256,'bounded structure publication')
 els={}
 for e in s['Elements']:
  need(all(isinstance(e[k],str)and len(e[k])<=4096 for k in ['ID','DomainID','Parent','Role','Name'])and e['ID']not in els,'unique bounded element identity');need(all(type(e[k])is bool for k in ['Enabled','Focused','Selected'])and rect(e['Bounds']),'element schema');r=e['Bounds']
  need(empty(r)or all(0<=r['Min'][k]<r['Max'][k]<=s['Size'][k]for k in ['X','Y']),'clipped scene bounds');els[e['ID']]=e
 return els

def publication(s,w,index):
 els=snapshot(s)
 def get(target,role=None,parent=None,visible=True):
  e=els.get(target);need(e is not None,'required current target '+target)
  need((role is None or e['Role']==role)and(parent is None or e['Parent']==parent)and(not visible or not empty(e['Bounds'])),'target role/parent/bounds '+target);return e
 get(node('structure-catalogue'),'column');get(node('structure-title'),'label');get(P,'tabs');st=get(node('structure-status'),'status-bar');need(st['Value']==f"Page {w['Page']} / expanded {str(w['Expanded']).lower()} / split {w['Fraction']:.2f} / documents {len(w['Documents'].split(','))}",'accepted status text')
 for opt in ['sections','unavailable','split-page','documents']:
  e=get(id('option','structure-pages',opt),'option',P);need(e['Enabled']==(opt!='unavailable')and e['Selected']==(opt==w['Page'])and e['Value']==(opt==w['Page']),'root tab projection')
 for page in ['sections','split-page','documents']:need((node(page)in els)==(page==w['Page']),'hidden page semantics')
 if w['Page']=='sections':
  h=get(H,'disclosure-heading',node('details'));need(h['Enabled']==(not w['DetailsDisabled'])and type(h['Value'])is bool and h['Value']==w['Expanded'],'disclosure state');get(node('section-after'),'button')
  for name,role in [('section-draft','text-field'),('section-action','button')]:
   need((node(name)in els)==w['Expanded'],'collapsed child semantics')
   if w['Expanded']:
    e=get(node(name),role,node('details'));need(e['Enabled']==(not w['DetailsDisabled']),'inherited disabled state')
    if name=='section-draft':need(e['Value']=='Vellum','retained section draft')
 elif w['Page']=='split-page':
  pane=get(node('panes'),'split-pane');h=get(S,'split-handle',node('panes'));r,b=pane['Bounds'],h['Bounds'];need(h['Enabled']==(not w['SplitDisabled'])and type(h['Value'])in[int,float]and abs(h['Value']-w['Fraction'])<=1e-5,'split accepted value/enablement');need(all(r['Min'][k]<=b['Min'][k]<b['Max'][k]<=r['Max'][k]for k in ['X','Y']),'divider inside split');expected=r['Min']['X']+w['Fraction']*(r['Max']['X']-r['Min']['X']-(b['Max']['X']-b['Min']['X']));need(abs(b['Min']['X']-expected)<=4,'divider fraction to measured geometry')
  if LABELS[index]in ['split-reset','scroll-bottom','scroll-boundary','scroll-top']:
   first=get(node('split-line-00'),'label',node('split-workspace'),False);last=get(node('split-line-23'),'label',node('split-workspace'),False);bottom=LABELS[index]in ['scroll-bottom','scroll-boundary'];need(empty(first['Bounds'])==bottom and empty(last['Bounds'])!=(bottom),'scroll endpoints/clip')
 elif w['Page']=='documents':
  for doc in ['sketch','notes']:
   opt,close=id('option','document-tabs',doc),id('tab-close','document-tabs',doc);present=doc in w['Documents'].split(',');need((opt in els)==present and(close in els)==present,'retired document targets')
   if present:
    e=get(opt,'option',D);c=get(close,'button',opt);need(e['Enabled']and c['Enabled']and e['Selected']==(doc==w['Document'])and e['Value']==(doc==w['Document']),'controlled document projection')
  e=get(node('document-content-'+w['Document']),'text-field',node(w['Document']));need(e['Value']=={'sketch':'Untitled sketch','notes':'Working notes'}[w['Document']],'retained active document draft')
 if FOCUS[index]:need(get(FOCUS[index])['Focused'],'actual focused target')
 return els

def validate(stdout,stderr):
 need(len(stdout)<=4<<20 and len(stderr)<=4<<20,'bounded console logs');reports=[];warnings=0
 for raw,out in [(stdout,True),(stderr,False)]:
  for line in raw.decode('utf-8','strict').splitlines():
   if not line.strip():continue
   if out and line.startswith('{'):reports.append(line);continue
   need(bool(re.fullmatch(r'\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ERROR lines\.Lines font style MUST be Monospace\. Setting that but should fix upstream \| cogentcore\.org/core/text/lines\.\(\*Lines\)\.SetFontStyle .*/text/lines/api\.go:145',line)),'unexpected console line');warnings+=1;need(warnings<=64,'font diagnostic bound')
 need(len(reports)==1,'one result record');d=json.loads(reports[0]);need(d['Event']=='vellum.structure-native.result'and d['Result']=='PASS_NATIVE_STRUCTURE'and d['Error']==''and d.get('Failed')is None,'complete successful native record')
 need([s['Label']for s in d['Steps']]==LABELS and[i['Label']for i in d['Inputs']]==[p[0]for p in PACKETS],'complete authored record');last=0
 for index,(step,w)in enumerate(zip(d['Steps'],VALUES)):
  actual=step['Model'];need(set(actual)==set(w),'exact model schema')
  for k,v in w.items():need((type(actual[k])is type(v)and actual[k]==v)if k!='Fraction'else(type(actual[k])in[int,float]and math.isfinite(actual[k])and abs(actual[k]-v)<=1e-5),'literal model '+step['Label']+'/'+k)
  publication(step['Snapshot'],w,index);need(step['Snapshot']['Frame']>last,'ordered observation frame');last=step['Snapshot']['Frame']
 first=d['Steps'][0]['Snapshot'];extent=(first['Size'],first['LogicalDPI']);baseAfter=publication(first,VALUES[0],0)[node('section-after')]['Bounds']['Min']['Y']
 for index,step in enumerate(d['Steps']):
  s=step['Snapshot'];need((s['Size'],s['LogicalDPI'])==extent,'fixed scene configuration')
  if VALUES[index]['Page']=='sections':
   y=snapshot(s)[node('section-after')]['Bounds']['Min']['Y'];need(y==baseAfter if VALUES[index]['Expanded']else y<baseAfter,'collapse releases actual layout/restore')
  frames=[x['Before']['Frame']for x in d['Inputs']if x['Label'].split('/')[0]==step['Label']];floor=d['Steps'][index-1]['Snapshot']['Frame']if index else 0;need(all(floor<f<s['Frame']for f in frames),'input/observation interleaving')
 last=0;stale=None
 for item,(label,target,typ,code,rune,delta,reject)in zip(d['Inputs'],PACKETS):
  s=item['Before'];els=snapshot(s);inp=item['Input'];need((s['Size'],s['LogicalDPI'])==extent and s['Frame']>last,'fixed current input snapshot');last=s['Frame']
  need(type(inp['Frame'])is int and inp['Frame']==s['Frame']and inp['Target']==target and inp['Type']==typ and inp['Code']==code and type(inp['Rune'])is int and inp['Rune']==rune and inp['Modifiers']==''and inp['Delta']=={'X':0,'Y':delta}and type(item['Rejected'])is bool and item['Rejected']==reject,'authored packet '+label)
  need(inp['Button']==('Left'if typ in['MouseDown','MouseUp']else'NoButton')and point(inp['Position']),'typed button/point')
  if label=='document-stale-close':need(stale is not None and target not in els and inp['Position']==stale['Position'],'removed close refused with new current frame');continue
  e=els.get(target);need(e is not None and e['Enabled']==(not reject),'current target enablement')
  if typ=='KeyChord':need(inp['Position']=={'X':0,'Y':0}and(reject or e['Focused']),'actual key focus')
  else:need(not empty(e['Bounds'])and inp['Position']=={k:(e['Bounds']['Min'][k]+e['Bounds']['Max'][k])//2 for k in ['X','Y']},'fresh measured pointer/scroll center')
  if label=='document-pointer-rejected/MouseUp':stale=inp.copy()
 need(d['OriginalRefClosed']is True and d['PostCloseInputError']=='closed','original window terminal refusal');s=d['Session'];need(s['Started']is True and s['Closed']is True and s['Pending']is False and type(s['LiveWindows'])is int and s['LiveWindows']==0 and type(s['Issued'])is int and s['Issued']>=50,'terminal session')
 return dict(result='PASS_NATIVE_STRUCTURE',observations=42,inputs=50,details_proposals=8,split_proposals=6,page_proposals=5,document_closes=3,document_selections=1,section_actions=1,session=s,known_font_diagnostics=warnings,physical_input_verified=False,native_pixels_verified=False)
