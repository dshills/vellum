from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def git(*args):return run_child(['git',*args],cwd=T,timeout=30,capture_output=True,check=True).stdout
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=['drivers/cogent/cmd/gallery/main.go', 'drivers/cogent/cmd/gallery/documents.go', 'drivers/cogent/cmd/gallery/structure_controls.go', 'drivers/cogent/cmd/gallery/structure_catalogue.go', 'drivers/cogent/cmd/gallery/structure_catalogue_test.go', 'drivers/cogent/cmd/gallery/structure_catalogue_offscreen_test.go', 'drivers/cogent/cmd/gallery/README.md', 'drivers/cogent/controls.go', 'drivers/cogent/tab_close.go', 'drivers/cogent/tab_navigation.go', 'drivers/cogent/tab_navigation_test.go', 'drivers/cogent/tab_navigation_offscreen_test.go', 'specs/controls.md', 'specs/tab-close.md', 'specs/control-acceptance.md', 'specs/macos-delivery.md', 'specs/macos-completion.md', 'docs/desktop-integration.md', 'docs/reports/macos-structure-catalogue/README.md', 'docs/reports/macos-structure-catalogue/records/results.json']
assert json.loads((W/'review-paths.json').read_bytes())==paths and not(W/'review-scope.json').exists()
assert json.loads((W/'result.json').read_bytes())['result']=='FAILED_OR_CANCELED'
git('add','--',*paths);git('diff','--cached','--check');assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)and not git('diff','--name-only')
diff=git('diff','--cached','--binary');assert 0<len(diff)<100000
r={'base_commit':git('rev-parse','HEAD').decode().strip(),'paths':paths,'files':{n:sha(T/n)for n in paths},'staged_diff_bytes':len(diff),'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'native_result':'FAILED41/35; complete50/42 pending'}
(W/'review-scope.json').write_text(json.dumps(r,indent=2)+'\n');(W/'staged.diff').write_bytes(diff);print(json.dumps({k:r[k]for k in ['staged_diff_bytes','staged_diff_sha256']}))
