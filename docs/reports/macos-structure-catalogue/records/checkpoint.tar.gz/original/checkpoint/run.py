"""One reviewed/admitted native structural record; never resets a terminal scope."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2');HEAD='e9896d6bd8a940590f27dd08d971f79a8049cf7c'
s=importlib.util.spec_from_file_location('structural_sdk_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g;sha=h.sha;need=h.need
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sys.path.insert(0,str(W));import validate as validator
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,capture_output=True,check=True,timeout=30).stdout
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'no vector symlinks')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def prepared(root):return{m+'/'+n:z for m in ['upstream','typesetting']for n,z in vector(root/'drivers/cogent/build'/m).items()}
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
CHANGED=['drivers/cogent/cmd/gallery/documents.go','drivers/cogent/cmd/gallery/main.go','drivers/cogent/controls.go','drivers/cogent/tab_close.go']
NEW=['drivers/cogent/cmd/gallery/'+n for n in ['structure_catalogue.go','structure_catalogue_offscreen_test.go','structure_catalogue_test.go','structure_controls.go']]+['drivers/cogent/'+n for n in ['tab_navigation.go','tab_navigation_offscreen_test.go','tab_navigation_test.go']]
def baseline():
 need(git(C,'rev-parse','HEAD').decode().strip()==HEAD and not git(C,'status','--porcelain'),'clean canonical e9896d6')
 names=git(C,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5400,'canonical source count');a={n:sha(C/n)for n in names}
 need(git(T,'rev-parse','HEAD').decode().strip()==HEAD and git(T,'diff','--name-only').decode().splitlines()==CHANGED and not git(T,'diff','--cached','--name-only'),'exact four changed tracked files')
 need(set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(NEW),'exact seven new source/test files');t={n:sha(T/n)for n in names+NEW};need(all(t[n]==z for n,z in a.items()if n not in CHANGED),'unchanged other tracked files')
 p=prepared(C);need(prepared(T)==p and len(p)==6268 and digest(p)=='914e42815dc2d77a8d3f99a7608f11e0ac829c46fb99f4c87e84d3c61c0ccb41','whole stage84 parity')
 sdk=vector(SDK);need(len(sdk)==7880 and digest(sdk)=='4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26','whole retained SDK unchanged')
 mapping=read(W/'overlay.json')['Replace']
 for original,replacement in mapping.items():
  rel=Path(original).relative_to(SDK)
  if replacement=='':need(not(T/rel).exists(),'declared obsolete overlay deletion '+str(rel))
  else:need(Path(replacement).read_bytes()==(T/rel).read_bytes(),'all current overlay replacements '+str(rel))
 for n in t:
  if n.endswith('.go')and not n.startswith('prototypes/'):
   q=SDK/n;need(sha(mapping.get(str(q),str(q)))==t[n],'whole current non-prototype Go correspondence '+n)
 for q in (T/'drivers/cogent').iterdir():
  if q.suffix in ['.m','.c','.h','.sum']:
   original=SDK/q.relative_to(T);need(sha(mapping.get(str(original),str(original)))==sha(q),'current native driver support '+q.name)
 for n,z in p.items():
  q=SDK/'drivers/cogent/build'/n;need(sha(mapping.get(str(q),str(q)))==z,'whole prepared overlay '+n)
 return a,t,p,sdk

def prepare():
 need(not(W/'plan.json').exists()and not(W/'case').exists(),'fresh structural scope');a,t,p,sdk=baseline();review=read(W/'internal-source-review.json');need(review['approved']and not review['unresolved_findings']and all(sha(k)==z for k,z in review['inputs'].items()),'exact source/controller review')
 pins={}
 for name in ['tabs-final','driver-final','gallery-final','vet-root-final','build-final','validation-final']:
  r=read(W/(name+'.json'));need(passing(r),'owned prerequisite '+name);need(all(sha(k)==z for k,z in r['source_pins'].items()),'current prerequisite '+name);pins.update(r['source_pins']);pins[str(W/(name+'.json'))]=sha(W/(name+'.json'))
  for stream,info in r['logs'].items():
   q=W/name/stream;need(q.stat().st_size==info['bytes']and sha(q)==info['sha256'],'raw prerequisite '+name);pins[str(q)]=sha(q)
 paths=[Path(__file__),W/'validate.py',W/'validation_controls.py',W/'internal-source-review.json',W/'check.py',W/'check_validation.py',Path(h.__file__),h.GUARD,h.GO,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(q):sha(q)for q in paths});binary=read(W/'build-final.json')['binary'];need(sha(binary['path'])==binary['sha256'],'exact fresh native binary');now=datetime.datetime.now(datetime.timezone.utc)
 p={'head':HEAD,'canonical_source':a,'candidate_source':t,'prepared':p,'sdk':str(SDK),'sdk_files':sdk,'pins':pins,'binary':binary,'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':120,'stream_limit_bytes':4<<20,'runtime_options':{k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']},'scope':'One fresh50-input42-observation native structural catalogue record. Public ordinary/shared constructors, rootTabs/disclosure/split/Scroll and controlled document closes; disabled skip/refusal, hide/focus/retained content, rejected/read-only acceptance, geometry under accepted split fractions, bounded endpoint scrolling/noop/restoration, duplicate-free callbacks, rejected/accepted selected close, removed-target refusal at new frame, original-window closure and joined worker/session/process retirement. Product tab keyboard Left/Right/Home/End/Space/Enter uses event-time absolute proposals and owner-only lifetime/mutability checks; original ordering/readonly negative tests preserved. Four modified/seven new Go source/test files atop e9896d6; every non-prototype tracked Go source and all6268prepared files correspond to the overlay. Full driver-root/gallery race, focused lifecycle, vet/build and independent literal oracle/synthetic controls. RetainedSDK7880/native786a controlledGOMAXPROCS2 CPU-scene. Automated Go FIFO only: no OS/physical input, IME/VoiceOver, native pixels/presentation, actual split drag, arbitrary resize/display changes, performance/resource/endurance/fullMac/SDK-release acceptance. Shared exclusive lease, network/SDK-write denial, whole C/T/source/prepared/SDK before-after pins,120s4MiB owned cleanup and one attempt then terminal seal. No prior sealed scope/operator use or reset, OSsettings/inputsource/clipboard changes, SDK refresh or public push/tag/sign/notarize.'}
 (W/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(W/'plan.json'),'native_executed':False}))
def run():
 raw=(W/'plan.json').read_bytes();araw=(W/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(araw);stop=W/'stop-live';need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact plan admission');need(not stop.exists()and not(W/'case').exists()and not(W/'result.json').exists(),'one fresh structural case')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==araw and all(sha(k)==z for k,z in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  need(not stop.exists()and stable(),'stable inputs/no stop');need(baseline()==(p['canonical_source'],p['candidate_source'],p['prepared'],p['sdk_files']),'whole source/prepared/SDK boundary');need({k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']}==p['runtime_options'],'runtime options')
 d={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_full_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('structural controller signal '+str(signum))
 previous=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline');profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(SDK))+'))'
   r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],'-structure-native-check'],SDK/'drivers/cogent',W/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);d['run']=r;d['native_executed']=r['created'];need(passing(r),'owned native result');d['summary']=validator.validate((W/'case/stdout').read_bytes(),(W/'case/stderr').read_bytes());boundary();need(lease.held(),'lease through cleanup');d['result']='PASS_NATIVE_STRUCTURE'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,previous);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error','summary']}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in[['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
