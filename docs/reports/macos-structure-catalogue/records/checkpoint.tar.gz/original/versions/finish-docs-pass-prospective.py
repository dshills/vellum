from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(W/'result.json');assert r['result']=='PASS_NATIVE_STRUCTURE'and r['summary']['inputs']==50 and r['summary']['observations']==42
report=T/'docs/reports/macos-structure-catalogue';(report/'records').mkdir(parents=True,exist_ok=False)
(report/'README.md').write_text('''# Controlled tab navigation and native structural controls

Managed Tabs now handle unmodified Left/Right, Home/End and Space/Enter through
the public controlled selection callback. Arrows wrap and skip disabled options;
Home/End choose enabled endpoints. Focus moves on the originating event thread,
while owner delivery proposes stable IDs. Accepted selection stays application
owned; rejected/read-only input does not leave an optimistic selection. Existing
pointer-repeat and Delete/Backspace close behavior remain supported.

The queue captures absolute movement intent before owner delivery: a rapid
A→B→A must produce B,A even before reconciliation. It also captures input-time
write permission. Hidden/disabled/removed bindings, closed dialog lifetimes and
read-only transitions revoke old selection epochs. Owner delivery uses owner
values and atomic scope tokens, with no native widget traversal or focus change.

The standard gallery's new `-structure-native-check` shares the ordinary
Disclosure and SplitPane constructors and document view. The split demonstration
now contains scrollable workspace rows. The complete native Go FIFO record
passes **50 inputs and 42 literal expected observations**, with 8 disclosure,
6 split, 5 page, 3 close, 1 document-selection and 1 section-action callback.
It checks collapse/reopen and released layout, hidden-child Tab skipping,
owner collapse returning child focus, rejection/read-only/disabled refusal,
root-tab disabled skipping, split endpoint/fraction geometry, actual scroll
clipping/bottom no-op/top restoration, rejected pointer/key document closes,
accepted close without unrelated selection and current-frame stale refusal.
Closing the original window refuses its last live target. Session/worker and
owned process cleanup pass. No new public API signature or catalogue kind is added.

The initial offscreen preflight failed at absent tab arrow navigation. Internal
review then found a rapid-key ordering failure and read-only transition revival;
focused old-source regressions reproduce both and the fixed source passes them.
The first burst fixture failed its own handled-event check because Core Send
clones events; the corrected fixture uses the actual HandleEvent path and
reproduces the B-only result. An intermediate build failure came from missing
SDK overlay entries, not a missing source field. All failures and versions are
retained; no native scope is reset or acceptance expectation regenerated.

Final complete driver-root (`.`) and gallery race suites, focused tab lifecycle
regressions, root/gallery vet and native build pass. An independent public Manual
consumer checks retained child incarnations, keys/selection, exact divider
geometry and scroll endpoints; it uses public targets or measured geometry.
The independent native validator checks all authored packets, literal models,
actual key focus, measured pointer/scroll centers, frame interleaving, accepted
semantics, geometry and terminal state. One positive and 34 negative synthetic
parser controls pass; these are separate from the native record.

Internal source/controller, exact-plan admission, provider disposition and final
archive/commit reviews are checkpoint requirements. One scoped Prism Anthropic
Claude Sonnet 5.5 review is required before commit. The bounded
[archive](records/checkpoint.tar.gz) and [manifest](records/manifest.json) will
retain raw checks, failures, versions and review payload without binaries or SDK
payload copies. The original provider payload remains distinct from any factual
post-review README addition.

This qualifies this controlled Go1.25.6 ARM64/GOMAXPROCS2 CPU-scene record over
retained native archive786a only. Both source checkouts retain identical stage84
prepared files; all 7,880 retained SDK files are unchanged. The overlay matches
all current non-prototype tracked Go source and prepared bytes. SDK module
locations remain intentionally relocated. No SDK refresh or public release is
performed. Go FIFO does not establish physical/OS input, native pixels,
VoiceOver/IME, actual split dragging, arbitrary resize/display transitions,
presentation, performance or native deallocation/endurance. Full M2/M5 and
M3–M7 remain open. Prior complete workspace records retain their pinned source
identities; this checkpoint does not rerun or requalify the full professional
record for this tab-selection delta. Continue the remaining image/composite/chrome/text/modal
catalogue workflows and the unchanged [Mac delivery plan](../../../specs/macos-delivery.md).
''')
checks={}
for n in ['tabs-final','driver-final','gallery-final','vet-root-final','build-final','validation-final']:
 c=read(W/(n+'.json'));checks[n]={'receipt_sha256':sha(W/(n+'.json')),**{k:c[k]for k in ['exit_code','seconds','logs_complete','pins_stable']},'owned_group_absent':c['owned']['group_absent']}
(report/'records/results.json').write_text(json.dumps({'base_commit':'e9896d6bd8a940590f27dd08d971f79a8049cf7c','native':r,'checks':checks,'synthetic_positive_controls':1,'synthetic_negative_controls':34,'prepared_files':6268,'sdk_files':7880,'sdk_unchanged':True,'physical_input_verified':False,'native_pixels_verified':False,'closed_full_mac_gates':[],'goal_complete':False},indent=2)+'\n')
p=T/'specs/controls.md';s=p.read_text();marker='A Tabs control with no enabled options cannot receive focus.';assert marker in s;s=s.replace(marker,marker+'''

Focused tab headers handle unmodified Left/Right with enabled-option wrap and
Home/End with enabled endpoints; Space/Enter proposes the focused option.
Keyboard movement changes native header focus and queues one stable-ID proposal
through the latest owner callback. Rejected selection stays accepted as before.
Read-only headers can move focus without proposing selection. Activating an
already accepted focused option is a no-op; existing explicit pointer repeats
remain proposals. Modified/previously handled chords keep command priority.
Queued movement retains absolute input-time intent even before a redraw, and
input-time read-only authority cannot revive when a callback is later enabled.
Hiding/disabling/removing a strip, dialog scope closure and nil/non-nil Change
transitions revoke old selection capabilities. Owner callbacks never traverse
originating native widget trees or change their focus from another window.
''',1);p.write_text(s)
p=T/'specs/tab-close.md';p.write_text(p.read_text()+'''
The [structural catalogue record](../docs/reports/macos-structure-catalogue/README.md)
adds native Go FIFO selected-document pointer/key rejection, accepted keyboard
close, unchanged selection callback count and new-frame stale close refusal,
within its 50-input/42-observation scenario. It reuses the ordinary document
view. This does not replace the separate Cocoa selector, physical input or human
accessibility acceptance requirements above.
''')
p=T/'specs/control-acceptance.md';s=p.read_text();replacements={
'divider keys/drag, measured ratio and retained child editing | R |':'divider keys/drag, measured ratio and retained child editing; `gallery -structure-native-check`: native controlled keys, exact divider geometry, read-only/rejected/disabled state | R/N |',
'collapse/reopen, layout release, focus and retained children | R |':'collapse/reopen, layout release, focus and retained children; `gallery -structure-native-check`: native focus/layout/rejection/read-only/disabled and retained section state | R/N |',
'page identity | R/A |':'page identity; `gallery -structure-native-check`: native keyboard disabled skip, pointer selection, controlled document closes and stale refusal | R/A/N |',
'actual ancestor scroll clips and transformed content | R |':'actual ancestor scroll clips and transformed content; `gallery -structure-native-check`: native scroll endpoint clipping, boundary no-op and top restoration | R/N |'}
for old,new in replacements.items():assert old in s;s=s.replace(old,new,1)
marker='The remaining native catalogue work is:';assert marker in s;s=s.replace(marker,'''The [structural catalogue checkpoint](../docs/reports/macos-structure-catalogue/README.md)
adds controlled Tabs keyboard navigation and a complete native 50-input/42-state
record for Tabs, Disclosure, SplitPane and Scroll. Shared ordinary constructors,
exact callbacks, focus, accepted/rejected/read-only/disabled state, geometry,
clipped scrolling, controlled document closure and terminal cleanup pass.
Physical input/pixels and full M2/M5/M3–M7 remain open.

'''+marker,1);p.write_text(s)
for n in ['macos-delivery.md','macos-completion.md']:
 p=T/'specs'/n;s=p.read_text();s+='''
### Structural controls checkpoint

The [native structural result](../docs/reports/macos-structure-catalogue/README.md)
adds controlled tab keyboard navigation with burst/read-only lifetime fixes.
Its 50 native FIFO inputs/42 expected states cover Tabs, Disclosure, SplitPane
and Scroll using ordinary public constructors. Callback counts, focus, geometry,
rejected/disabled/stale refusal and cleanup pass. This advances named catalogue
coverage only; physical/pixels, full M2/M5, performance/resources and M6/M7 remain
open with the original thresholds and required evidence.
''';p.write_text(s)
p=T/'drivers/cogent/cmd/gallery/README.md';p.write_text(p.read_text()+'''
## Native structural controls

```sh
go run ./cmd/gallery -structure-native-check
```

This separate bounded 900x700 requested view reuses ordinary Disclosure/SplitPane
constructors and the document-tab view. It emits one 50-input/42-observation Go
FIFO result, closes the original window and joins its worker. It uses the other
catalogue modes' 90-second deadline, 6-second join, exclusive flags and disabled
process-local geometry persistence. Tested state uses ordinary public callbacks;
owner-posted policies are setup only. The ordinary split page now includes enough
workspace rows to exercise actual scrolling. See the
[result and limitations](../../../../docs/reports/macos-structure-catalogue/README.md).
''')
p=T/'docs/desktop-integration.md';p.write_text(p.read_text()+'''

`gallery -structure-native-check` exercises tabs/disclosure/split/scroll and
controlled document closes through public DesktopSession Go FIFO, with 50 inputs
and 42 independent expected states. It checks actual published targets/focus,
measured divider geometry and scroll clipping, exact callbacks, stale refusal
and original-window cleanup. The [result](reports/macos-structure-catalogue/README.md)
keeps this evidence separate from physical input, native pixels and broader Mac
qualification. Ordinary tab keyboard navigation is documented in the
[controls contract](../specs/controls.md).
''')
paths=['drivers/cogent/cmd/gallery/'+n for n in ['main.go','documents.go','structure_controls.go','structure_catalogue.go','structure_catalogue_test.go','structure_catalogue_offscreen_test.go','README.md']]+['drivers/cogent/'+n for n in ['controls.go','tab_close.go','tab_navigation.go','tab_navigation_test.go','tab_navigation_offscreen_test.go']]+['specs/'+n for n in ['controls.md','tab-close.md','control-acceptance.md','macos-delivery.md','macos-completion.md']]+['docs/desktop-integration.md','docs/reports/macos-structure-catalogue/README.md','docs/reports/macos-structure-catalogue/records/results.json']
(W/'review-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'paths':len(paths),'native':r['summary']}))
