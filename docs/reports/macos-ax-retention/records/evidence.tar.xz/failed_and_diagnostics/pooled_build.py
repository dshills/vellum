import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-composed-1000')
sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
inputs=[phase/'pooled-clang',phase/'ax-diagnostic-pooled.m']
record={'argv':['go','build','-tags=vellum_native_checks','-o',str(phase/'window-cycle-ax-pooled'),'./cmd/window-cycle-smoke'],'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs},'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'mode':'diagnostic compiler wrapper; temporary source substitution; canonical/prepared files untouched'}
env={**child_environment(),'CC':str(phase/'pooled-clang'),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
start=time.monotonic()
with (phase/'ax-pooled-build.stdout').open('xb')as out,(phase/'ax-pooled-build.stderr').open('xb')as err:
 record['exit_code']=run_child(record['argv'],cwd=root/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=240).returncode
record['elapsed_seconds']=time.monotonic()-start
record['substitution_observed']='VELLUM_AX_DIAGNOSTIC_SOURCE_SUBSTITUTION'in(phase/'ax-pooled-build.stderr').read_text()
(phase/'ax-pooled-build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(0 if record['exit_code']==0 and record['substitution_observed'] else 1)
