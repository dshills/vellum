import hashlib,json,sys
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-composed-1000')
sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
name,source=sys.argv[1:];source=Path(source);fixture=phase/'ax-ownership-test.m';binary=phase/name
argv=['/usr/bin/clang','-fobjc-arc','-Wno-unused-parameter','-DVELLUM_AX_SOURCE="'+str(source)+'"',str(fixture),'-framework','Cocoa','-o',str(binary)]
compiled=run_child(argv,env=child_environment(),capture_output=True,timeout=30)
record={'argv':argv,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'compile_exit':compiled.returncode,'compile_stderr':compiled.stderr.decode()}
if compiled.returncode==0:
 ran=run_child([str(binary)],env=child_environment(),capture_output=True,timeout=20)
 record.update({'run_exit':ran.returncode,'stdout':ran.stdout.decode(),'stderr':ran.stderr.decode()})
(phase/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
sys.exit(record.get('run_exit',125))
