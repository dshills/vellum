import hashlib,json,re
from pathlib import Path
phase=Path('/private/tmp/vellum-macos-ax-retention');original=Path('/private/tmp/vellum-macos-composed-1000')
def events(path):
 result=[]
 for line in path.read_text().splitlines():
  try:result.append(json.loads(line))
  except ValueError:pass
 return result
before=events(original/'composed-1000-v1.stdout');after=events(phase/'composed-1000-fixed.stdout')
def campaign(rows):
 cycles=[r for r in rows if r.get('event')=='vellum.composed-cycle'];samples=[r['sample']for r in rows if r.get('event')=='vellum.window-cycle.sample'];terminal=[r for r in rows if r.get('event')=='vellum.window-cycle.result'];warm=[s for s in samples if s['Completed']>=25]
 return {'cycles':len(cycles),'sequential_cycles': [r['cycle']for r in cycles]==list(range(1,len(cycles)+1)), 'all_1000_labels_contained':all(r['dense_defined']==1000 and r['dense_fully_visible']==1000 and r['all_dense_labels_fully_visible']for r in cycles), 'editor_history':all(r['editor_history_replayed']for r in cycles),'native_text_accepted':all(r['native_text_accepted']for r in cycles),'grid_tree_completed':all(r['grid_tree_completed']for r in cycles),'modal_open_close':all(r['modal_open_close']for r in cycles),'full_p11_qualified':False,'sample_count':len(samples),'first':samples[0],'last':samples[-1],'warm_ranges':{key:[min(s[key]for s in warm),max(s[key]for s in warm)]for key in ['HeapAlloc','RSSBytes','GoSys','Goroutines']},'root_screen_point_sizes':sorted(set(tuple(r['root_screen_points'][2:])for r in cycles)),'terminal':terminal[-1] if terminal else None}
def counters(name):
 lines=(original/name).read_text().splitlines();last=lines[-1];match=re.search(r'created=(\d+) freed=(\d+) states_freed=(\d+) witnesses_freed=(\d+)',last);assert match
 return dict(zip(['created','freed','states_freed','witnesses_freed'],map(int,match.groups())))
result={'original':campaign(before),'fixed':campaign(after),'diagnostic25_original_before_survivor_close':counters('ax-diagnostic-v2-25.stderr'),'diagnostic25_pooled_before_survivor_close':counters('ax-pooled-25.stderr'),'note':'Diagnostic counts are pre-final-survivor teardown; source .m overlay was not effective in first build, corrected compiler substitution observed. Temporary diagnostic binaries are excluded from adopted-source qualification.'}
assert result['fixed']['terminal']is not None
(phase/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result['fixed'].items()if k!='terminal'},indent=2))
