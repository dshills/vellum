import hashlib,json,tarfile
from pathlib import Path
phase=Path('/private/tmp/vellum-macos-ax-retention');prior=Path('/private/tmp/vellum-macos-composed-1000');root=Path('/private/tmp/vellum-large-data');dest=root/'docs/reports/macos-ax-retention/records';dest.mkdir(exist_ok=False)
allowed={'.json','.stdout','.stderr','.txt','.py','.m','.heap','.log'}
extra={'diagnostic-clang','pooled-clang'}
inputs={}
for label,directory in [('failed_and_diagnostics',prior),('corrected',phase)]:
 for f in sorted(directory.rglob('*')):
  if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and(f.suffix in allowed or f.name in extra):
   relative=f.relative_to(directory).as_posix();inputs[label+'/'+relative]=f
sources=json.loads((phase/'checkpoint-source.json').read_text())['sources']
for name,sha in sources.items():
 f=root/name;assert hashlib.sha256(f.read_bytes()).hexdigest()==sha
 inputs['reviewed_source/'+name]=f
index={name:{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}for name,f in inputs.items()}
archive=dest/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for name,f in inputs.items():tar.add(f,arcname=name,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:
  assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha,'files':index,'note':'Native failed campaign preserved alongside corrected campaign. Temporary native diagnostic binaries are excluded; producer/source hashes and raw receipts remain. Invalid early fixture/ineffective-overlay attempts are historical diagnostics, not selected test passes.'},indent=2)+'\n')
(dest/'review-summary.json').write_bytes((phase/'summary.json').read_bytes())
print(json.dumps({'archive_sha256':sha,'files':len(index),'bytes':archive.stat().st_size}))
