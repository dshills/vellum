"""Independent native navigation oracle. Synthetic parser controls are not native proof."""
import base64,json,math,re
def need(ok,why):
 if not ok:raise ValueError(why)
def enc(s):return base64.urlsafe_b64encode(s.encode()).decode().rstrip('=')
def node(s):return 'node:'+enc(s)
def row(s):return 'option:'+enc('layers')+':'+enc(s)
def menu(g,s):return 'menu:'+enc(g)+':'+enc(s)
F=False;T=True
KEYS=['List','Action','ListRequests','ActionRequests','CheckRequests','OutsideActions','ReadOnly','Reject','Disabled','MenuDisabled','Checked','CheckReject']
LABELS='initial list-down list-disabled-skip list-pointer list-end list-boundary list-home list-initial-letter list-rejected list-readonly-end list-readonly-home list-readonly-activate list-disabled list-disabled-refusal list-reenabled-pointer list-tab-to-menu action-menu-open action-disabled-refusal action-second-pointer action-stale-refusal action-keyboard-open action-keyboard-next action-second-keyboard action-escape-open action-escape action-outside-open action-outside-consumed outside-normal action-before-disable action-disabled-close action-anchor-refused action-reenabled-open action-tab check-menu-open check-accepted check-menu-reopen check-rejected check-reset-open check-reset-next check-reset menu-before-close'.split()
VALUES=[
 ('layer-00','',0,0,0,0,F,F,F,F,F,F),
 ('layer-01','',1,0,0,0,F,F,F,F,F,F),
 ('layer-03','',2,0,0,0,F,F,F,F,F,F),
 ('layer-03','',3,0,0,0,F,F,F,F,F,F),
 ('layer-23','',4,0,0,0,F,F,F,F,F,F),
 ('layer-23','',4,0,0,0,F,F,F,F,F,F),
 ('layer-00','',5,0,0,0,F,F,F,F,F,F),
 ('layer-23','',6,0,0,0,F,F,F,F,F,F),
 ('layer-23','',7,0,0,0,F,T,F,F,F,F),
 ('layer-23','',7,0,0,0,T,F,F,F,F,F),
 ('layer-23','',7,0,0,0,T,F,F,F,F,F),
 ('layer-23','',7,0,0,0,T,F,F,F,F,F),
 ('layer-23','',7,0,0,0,F,F,T,F,F,F),
 ('layer-23','',7,0,0,0,F,F,T,F,F,F),
 ('layer-01','',8,0,0,0,F,F,F,F,F,F),
 ('layer-01','',8,0,0,0,F,F,F,F,F,F),
 ('layer-01','',8,0,0,0,F,F,F,F,F,F),
 ('layer-01','',8,0,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,1,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,1,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,1,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,1,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,0,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,T,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,T,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,F,F,F),
 ('layer-01','second',8,2,0,1,F,F,F,F,F,F),
 ('layer-01','second',8,2,1,1,F,F,F,F,T,F),
 ('layer-01','second',8,2,1,1,F,F,F,F,T,F),
 ('layer-01','second',8,2,2,1,F,F,F,F,T,T),
 ('layer-01','second',8,2,2,1,F,F,F,F,T,F),
 ('layer-01','second',8,2,2,1,F,F,F,F,T,F),
 ('layer-01','second',8,2,3,1,F,F,F,F,F,F),
 ('layer-01','second',8,2,3,1,F,F,F,F,F,F)]
FOCUS=['layer-00','layer-01','layer-03','layer-03','layer-23','layer-23','layer-00','layer-23','layer-00','layer-23','layer-00','layer-00','','','layer-01','menu-actions','first','first','menu-actions','menu-actions','first','second','menu-actions','first','menu-actions','first','','outside','first','','','first','view-menu','grid','view-menu','grid','view-menu','grid','reset','view-menu','first']
ACTION_OPEN={16,17,20,21,23,25,28,31,40};CHECK_OPEN={33,35,37,38}
def popup_group(i):return 'menu-actions'if i in ACTION_OPEN else 'view-menu'if i in CHECK_OPEN else ''
PACKETS=[]
def key(label,id,code,rune=0,reject=False):PACKETS.append((label,'node',id,'KeyChord',code,rune,reject))
def click(label,kind,id):
 for typ in ['MouseDown','MouseUp']:PACKETS.append((label+'/'+typ,kind,id,typ,'Unknown',0,False))
def popupkey(label,index,code):PACKETS.append((label,'popup',index,'KeyChord',code,0,False))
key('list-down','layers','DownArrow');key('list-disabled-skip','layers','DownArrow');click('list-pointer','row','layer-03');key('list-end','layers','End');key('list-boundary','layers','DownArrow');key('list-home','layers','Home');key('list-initial-letter','layers','A',97);key('list-rejected','layers','Home');key('list-readonly-end','layers','End');key('list-readonly-home','layers','Home');key('list-readonly-activate','layers','Spacebar',32);key('list-disabled-refusal','layers','DownArrow',reject=True);click('list-reenabled-pointer','row','layer-01');key('list-tab-to-menu','layers','Tab');key('action-menu-open','menu-actions','DownArrow')
PACKETS.append(('action-disabled-refusal','popup',0,'MouseDown','Unknown',0,True));click('action-second-pointer','popup',2);PACKETS.append(('action-stale-refusal','stale','','MouseDown','Unknown',0,True))
key('action-keyboard-open','menu-actions','ReturnEnter');popupkey('action-keyboard-next',1,'DownArrow');popupkey('action-second-keyboard',2,'ReturnEnter');key('action-escape-open','menu-actions','ReturnEnter');popupkey('action-escape',1,'Escape');key('action-outside-open','menu-actions','ReturnEnter');click('action-outside-consumed','outside','');click('outside-normal','node','outside');click('action-before-disable','node','menu-actions');key('action-anchor-refused','menu-actions','DownArrow',reject=True);click('action-reenabled-open','node','menu-actions');popupkey('action-tab',1,'Tab');key('check-menu-open','view-menu','DownArrow');click('check-accepted','popup',0);key('check-menu-reopen','view-menu','ReturnEnter');popupkey('check-rejected',0,'ReturnEnter');key('check-reset-open','view-menu','DownArrow');popupkey('check-reset-next',0,'DownArrow');popupkey('check-reset',1,'ReturnEnter');click('menu-before-close','node','menu-actions')
need(len(PACKETS)==47 and len(LABELS)==len(VALUES)==len(FOCUS)==41,'authored record sizes')
def numeric(v):return type(v)in[int,float]and math.isfinite(v)
def point(p):return set(p)=={'X','Y'}and all(type(v)is int for v in p.values())
def positive(b):return b['Max']['X']>b['Min']['X']and b['Max']['Y']>b['Min']['Y']
def inside(b,size):return point(b['Min'])and point(b['Max'])and 0<=b['Min']['X']<b['Max']['X']<=size['X']and 0<=b['Min']['Y']<b['Max']['Y']<=size['Y']
def contains(b,p):return point(p)and b['Min']['X']<=p['X']<b['Max']['X']and b['Min']['Y']<=p['Y']<b['Max']['Y']
def snapshot(s):
 need(type(s['Frame'])is int and s['Frame']>0 and point(s['Size'])and min(s['Size'].values())>0 and numeric(s['LogicalDPI'])and s['LogicalDPI']>0,'completed geometry')
 els={}
 for el in s['Elements']:
  need(el['ID']not in els and all(type(el[k])is bool for k in ['Enabled','Focused','Selected']),'unique semantic identity/types');els[el['ID']]=el
 popups=s.get('Popups')or[];need(len(popups)<=1,'one active popup')
 for p in popups:
  need(p['Kind']=='MenuStage'and p['Interactive']is True and re.fullmatch('popup:'+str(s['Frame'])+r':\d+',p['ID'])and inside(p['Bounds'],s['Size']),'actual interactive popup')
  seen=set()
  for item in p['Items']:
   need(item['Parent']==p['ID']and re.fullmatch(re.escape(p['ID'])+r':\d+',item['ID'])and item['ID']not in seen and inside(item['Bounds'],s['Size']),'actual popup item lifetime/geometry');seen.add(item['ID']);need(all(type(item[k])is bool for k in ['Enabled','Focused','Selected']),'popup state types')
 return els,popups
def list_label(i):return {0:'Background',1:'Guides',2:'Locked template',23:'Annotations'}.get(i,f'Layer {i+1:02d}')
def publication(s,w,index):
 els,popups=snapshot(s);group=popup_group(index);need(bool(popups)==bool(group),'expected menu lifetime '+LABELS[index])
 if not group:
  for id,role in [('layers','list-box'),('menu-actions','menu-button'),('view-menu','menu-button'),('outside','button'),('navigation-title','label'),('navigation-status','status-bar')]:
   el=els.get(node(id));need(el and el['DomainID']==id and el['Role']==role and inside(el['Bounds'],s['Size']),'ordinary publication '+id);need(el['Enabled']==(not w[8]if id=='layers'else not w[9]if id=='menu-actions'else True),'effective disabled '+id)
  need(els[node('layers')]['Value']==list_label(int(w[0][-2:])),'accepted list value')
  need(els[node('navigation-status')]['Value']==f'Layer {w[0]} / action {w[1]} / grid {str(w[10]).lower()}','controlled status')
  for i in range(24):
   id=f'layer-{i:02d}';el=els.get(row(id));need(el and el['DomainID']==id and el['Parent']==node('layers')and el['Role']=='list-option'and el['Name']==list_label(i),'qualified row')
   need(el['Enabled']==(not w[8]and i!=2)and el['Selected']==(id==w[0])and type(el['Value'])is bool and el['Value']==(id==w[0]),'controlled row state')
   if positive(el['Bounds']):need(inside(el['Bounds'],s['Size']),'clipped row geometry')
  if index in [4,5,7,9]:need(not positive(els[row('layer-00')]['Bounds'])and positive(els[row('layer-23')]['Bounds']),'actual End scrolling')
 else:
  ids,names=(['blocked','first','second'],['Unavailable','Run action','Run action'])if group=='menu-actions'else(['grid','reset'],['Show grid','Reset view'])
  p=popups[0];need(len(p['Items'])==len(ids),'actual separator omission/order')
  for i,(id,name)in enumerate(zip(ids,names)):
   actual=p['Items'][i];semantic=els.get(menu(group,id));need(actual['Name']==name and actual['Enabled']==(id!='blocked'),'actual menu action')
   need(semantic and semantic['DomainID']==id and semantic['Parent']==node(group)and semantic['Role']=='menu-item'and semantic['Name']==name and semantic['Enabled']==actual['Enabled'],'stable menu semantics')
   if id=='grid':need(type(semantic['Value'])is bool and semantic['Value']==w[10],'accepted check action')
  need(not any(e['DomainID']=='group-divider'for e in els.values()),'separator has no action')
 focus=FOCUS[index]
 if focus:
  fid=row(focus)if focus.startswith('layer-')else menu(group,focus)if group else node(focus)
  el=els.get(fid);need(el and el['Focused']and positive(el['Bounds']),'expected actual focus '+focus)
 return els,popups
def validate(raw,stderr=b''):
 need(len(raw)<=4<<20 and len(stderr)<=4<<20,'bounded streams');reports=[];warnings=0
 for line,out in[(x,True)for x in raw.decode().splitlines()]+[(x,False)for x in stderr.decode().splitlines()]:
  if out and line.startswith('{'):reports.append(line);continue
  need(bool(re.fullmatch(r'\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ERROR lines\.Lines font style MUST be Monospace\. Setting that but should fix upstream \| cogentcore\.org/core/text/lines\.\(\*Lines\)\.SetFontStyle .*/text/lines/api\.go:145',line)),'unexpected console output');warnings+=1;need(warnings<=64,'known font diagnostic bound')
 need(len(reports)==1,'one JSON report');d=json.loads(reports[0]);need(d.get('Failed')is None,'no failed observation in a passing record');need(d['Event']=='vellum.navigation-native.result'and d['Result']=='PASS_NATIVE_NAVIGATION'and d['Error']=='','successful complete record')
 need([s['Label']for s in d['Steps']]==LABELS and[i['Label']for i in d['Inputs']]==[p[0]for p in PACKETS],'complete ordered authored record')
 last=0
 for index,(step,w)in enumerate(zip(d['Steps'],VALUES)):
  m=step['Model'];need(set(m)==set(KEYS)and all(type(m[k])is str for k in KEYS[:2])and all(type(m[k])is int and m[k]>=0 for k in KEYS[2:6])and all(type(m[k])is bool for k in KEYS[6:]),'model schema');need(m==dict(zip(KEYS,w)),'independent model/callbacks '+step['Label'])
  publication(step['Snapshot'],w,index);need(step['Snapshot']['Frame']>last,'ordered observation frame');last=step['Snapshot']['Frame']
 for index,step in enumerate(d['Steps']):
  before=[x['Before']['Frame']for x in d['Inputs']if x['Label'].split('/')[0]==step['Label']]
  floor=d['Steps'][index-1]['Snapshot']['Frame']if index else 0
  need(all(type(f)is int and floor<f<step['Snapshot']['Frame']for f in before),'input/observation interleaving '+step['Label'])
 last=0;stale=None;outside=None
 for item,(label,kind,id,typ,code,rune,reject)in zip(d['Inputs'],PACKETS):
  s=item['Before'];els,popups=snapshot(s);inp=item['Input'];need(type(inp['Frame'])is int and inp['Frame']==s['Frame']and s['Frame']>=last,'current ordered input frame');last=s['Frame']
  need(type(item['Rejected'])is bool and item['Rejected']==reject and inp['Type']==typ and inp['Code']==code and type(inp['Rune'])is int and inp['Rune']==rune and inp['Modifiers']==''and inp['Delta']=={'X':0,'Y':0},'exact authored packet '+label)
  need(inp['Button']==('NoButton'if typ=='KeyChord'else'Left')and point(inp['Position']),'typed packet button/point')
  if kind=='node':target=node(id);el=els.get(target)
  elif kind=='row':target=row(id);el=els.get(target);need(el and el['Parent']==node('layers')and el['DomainID']==id,'actual qualified list pointer')
  elif kind=='popup':need(len(popups)==1,'current actual popup target');el=popups[0]['Items'][id];target=el['ID']
  elif kind=='stale':
   need(stale is not None and inp['Target']==stale['Target']and inp['Position']==stale['Position']and not any(e['ID']==inp['Target']for e in els.values())and not popups,'retired actual popup ID refused with new frame');continue
  else:
   need(kind=='outside'and inp['Target']==''and outside is not None and inp['Position']==outside,'measured outside dismissal');need(not popups or not contains(popups[0]['Bounds'],inp['Position']),'outside popup');continue
  need(el and inp['Target']==target and el['Enabled']==(not reject),'current target/refusal identity')
  if typ=='KeyChord':need(inp['Button']=='NoButton'and(reject or el['Focused']),'actual focused key')
  else:need(inp['Button']=='Left'and contains(el['Bounds'],inp['Position']),'actual pointer bounds')
  if label=='action-second-pointer/MouseUp':stale=inp.copy()
  if not popups:
   e=els.get(node('outside'))
   if e:outside={k:(e['Bounds']['Min'][k]+e['Bounds']['Max'][k])//2 for k in ['X','Y']}
 need(d['OriginalRefClosed']is True and d['PostCloseInputError']=='closed','original ref closure and last-popup refusal')
 s=d['Session'];need(s['Started']is True and s['Closed']is True and s['Pending']is False and type(s['LiveWindows'])is int and s['LiveWindows']==0 and type(s['Issued'])is int and s['Issued']>=47,'terminal session')
 return {'result':'PASS_NATIVE_NAVIGATION','observations':41,'inputs':47,'list_proposals':8,'action_proposals':2,'check_proposals':3,'outside_actions':1,'known_font_diagnostics':warnings,'session':s,'physical_input_verified':False,'native_pixels_verified':False}
