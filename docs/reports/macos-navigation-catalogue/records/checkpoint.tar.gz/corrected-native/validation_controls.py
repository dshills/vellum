"""Synthetic parser fixtures only: no native or physical acceptance evidence."""
import copy,json,unittest
import validate as v
def rect(x,y,w,h):return {'Min':{'X':x,'Y':y},'Max':{'X':x+w,'Y':y+h}}
def element(id,domain,parent,role,name,bounds,value=None,enabled=True,focused=False,selected=False):
 return {'ID':id,'DomainID':domain,'Parent':parent,'Role':role,'Name':name,'Bounds':bounds,'Value':value,'Enabled':enabled,'Focused':focused,'Selected':selected}
def snapshot(frame,w,index=0,group='',focus=''):
 els=[]
 for id,role,b in [('layers','list-box',rect(10,50,290,240)),('menu-actions','menu-button',rect(10,320,180,40)),('view-menu','menu-button',rect(250,320,180,40)),('outside','button',rect(10,500,180,40)),('navigation-title','label',rect(10,10,600,30)),('navigation-status','status-bar',rect(10,450,600,30))]:
  value=v.list_label(int(w[0][-2:]))if id=='layers'else f'Layer {w[0]} / action {w[1]} / grid {str(w[10]).lower()}'if id=='navigation-status'else None
  enabled=not w[8]if id=='layers'else not w[9]if id=='menu-actions'else True
  els.append(element(v.node(id),id,'',role,id,b,value,enabled,focus==id))
 for i in range(24):
  id=f'layer-{i:02d}';end=index in [4,5,7,9];visible=20<=i<=23 if end else i<=4
  b=rect(20,55+45*(i-20 if end else i),250,35)if visible else rect(0,0,0,0)
  els.append(element(v.row(id),id,v.node('layers'),'list-option',v.list_label(i),b,id==w[0],not w[8]and i!=2,focus==id,id==w[0]))
 s={'Frame':frame,'Size':{'X':900,'Y':700},'LogicalDPI':160,'Elements':els,'Popups':[]}
 if group:
  ids,names=(['blocked','first','second'],['Unavailable','Run action','Run action'])if group=='menu-actions'else(['grid','reset'],['Show grid','Reset view'])
  pid=f'popup:{frame}:1';x=10 if group=='menu-actions'else 250
  p={'ID':pid,'Kind':'MenuStage','Interactive':True,'Bounds':rect(x,365,185,4+32*len(ids)),'Items':[]}
  for i,(id,name)in enumerate(zip(ids,names)):
   b=rect(x+2,367+32*i,180,30);p['Items'].append(element(f'{pid}:{i+2}','',pid,'popup-item',name,b,enabled=id!='blocked',focused=focus==id))
   els.append(element(v.menu(group,id),id,v.node(group),'menu-item',name,b,w[10]if id=='grid'else None,id!='blocked',focus==id))
  s['Popups']=[p]
 return s
def fixture():
 d={'Event':'vellum.navigation-native.result','Result':'PASS_NATIVE_NAVIGATION','Error':'','Steps':[],'Inputs':[],'OriginalRefClosed':True,'PostCloseInputError':'closed','Session':{'Started':True,'Closed':True,'Pending':False,'LiveWindows':0,'Issued':300}}
 for i,(label,w)in enumerate(zip(v.LABELS,v.VALUES)):
  d['Steps'].append({'Label':label,'Model':dict(zip(v.KEYS,w)),'Snapshot':snapshot((i+1)*10,w,i,v.popup_group(i),v.FOCUS[i])})
 offsets={};stale=None
 for label,kind,id,typ,code,rune,reject in v.PACKETS:
  step=v.LABELS.index(label.split('/')[0]);offset=offsets.get(step,0);offsets[step]=offset+1;frame=(step+1)*10-3+offset
  group=('view-menu'if label.startswith(('check-','check-accepted'))else'menu-actions')if kind=='popup'or label=='action-outside-consumed/MouseDown'else ''
  focus=id if kind in ['node','row']else(['blocked','first','second'][id]if group=='menu-actions'else['grid','reset'][id])if kind=='popup'else ''
  s=snapshot(frame,v.VALUES[step],step,group,focus);by={e['ID']:e for e in s['Elements']}
  if kind=='node':target=v.node(id);el=by[target]
  elif kind=='row':target=v.row(id);el=by[target]
  elif kind=='popup':el=s['Popups'][0]['Items'][id];target=el['ID']
  elif kind=='stale':target=stale['Target'];el=None
  else:target='';el=None
  if el:
   el['Enabled']=not reject;pos={k:(el['Bounds']['Min'][k]+el['Bounds']['Max'][k])//2 for k in ['X','Y']}
  else:pos=stale['Position'].copy()if kind=='stale'else{'X':100,'Y':520}
  inp={'Frame':frame,'Target':target,'Type':typ,'Code':code,'Rune':rune,'Modifiers':'','Button':'NoButton'if typ=='KeyChord'else'Left','Position':pos,'Delta':{'X':0,'Y':0}}
  d['Inputs'].append({'Label':label,'Before':s,'Input':inp,'Rejected':reject})
  if label=='action-second-pointer/MouseUp':stale=inp.copy()
 return d
class Controls(unittest.TestCase):
 def bad(self,fn):
  d=fixture();fn(d)
  with self.assertRaises((ValueError,TypeError,KeyError)):v.validate(json.dumps(d).encode())
 def test_failed_snapshot_on_pass(self):self.bad(lambda d:d.update(Failed=copy.deepcopy(d['Steps'][0])))
 def test_positive(self):self.assertEqual(v.validate(json.dumps(fixture()).encode())['inputs'],47)
 def test_missing_step(self):self.bad(lambda d:d['Steps'].pop())
 def test_missing_packet(self):self.bad(lambda d:d['Inputs'].pop())
 def test_repeat_proposal_dropped(self):self.bad(lambda d:d['Steps'][3]['Model'].update(ListRequests=2))
 def test_boundary_proposal_added(self):self.bad(lambda d:d['Steps'][5]['Model'].update(ListRequests=5))
 def test_rejected_value_accepted(self):self.bad(lambda d:d['Steps'][8]['Model'].update(List='layer-00'))
 def test_readonly_changed_selection(self):self.bad(lambda d:d['Steps'][10]['Model'].update(List='layer-00'))
 def test_wrong_duplicate_label_action(self):self.bad(lambda d:d['Steps'][18]['Model'].update(Action='first'))
 def test_bool_counter(self):self.bad(lambda d:d['Steps'][0]['Model'].update(ActionRequests=False))
 def test_wrong_popup_pointer(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='action-second-pointer/MouseDown')['Input'].update(Target=next(x for x in d['Inputs']if x['Label']=='action-second-pointer/MouseDown')['Before']['Popups'][0]['Items'][1]['ID']))
 def test_semantic_substitute_for_popup(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='action-second-pointer/MouseDown')['Input'].update(Target=v.menu('menu-actions','second')))
 def test_stale_substituted_with_anchor(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='action-stale-refusal')['Input'].update(Target=v.node('menu-actions')))
 def test_wrong_row_parent(self):self.bad(lambda d:next(x for x in d['Steps'][0]['Snapshot']['Elements']if x['ID']==v.row('layer-01')).update(Parent=v.node('view-menu')))
 def test_duplicate_id(self):self.bad(lambda d:d['Steps'][0]['Snapshot']['Elements'].append(copy.deepcopy(d['Steps'][0]['Snapshot']['Elements'][0])))
 def test_disabled_admitted(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='list-disabled-refusal').update(Rejected=False))
 def test_stale_frame(self):self.bad(lambda d:d['Inputs'][0]['Input'].update(Frame=0))
 def test_wrong_interleaving(self):
  def edit(d):
   d['Inputs'][0]['Before']['Frame']=1;d['Inputs'][0]['Input']['Frame']=1
  self.bad(edit)
 def test_bool_frame(self):self.bad(lambda d:d['Inputs'][0]['Input'].update(Frame=True))
 def test_missing_space_rune(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='list-readonly-activate')['Input'].update(Rune=0))
 def test_missing_letter_rune(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='list-initial-letter')['Input'].update(Rune=0))
 def test_unfocused_key(self):self.bad(lambda d:next(x for x in d['Inputs'][0]['Before']['Elements']if x['ID']==v.node('layers')).update(Focused=False))
 def test_wrong_readonly_focus(self):self.bad(lambda d:next(x for x in d['Steps'][10]['Snapshot']['Elements']if x['ID']==v.row('layer-00')).update(Focused=False))
 def test_no_list_scroll(self):self.bad(lambda d:next(x for x in d['Steps'][4]['Snapshot']['Elements']if x['ID']==v.row('layer-00')).update(Bounds=rect(20,55,250,35)))
 def test_menu_survives_disable(self):self.bad(lambda d:d['Steps'][29]['Snapshot'].update(Popups=copy.deepcopy(d['Steps'][28]['Snapshot']['Popups'])))
 def test_separator_action_added(self):self.bad(lambda d:d['Steps'][33]['Snapshot']['Popups'][0]['Items'].append(copy.deepcopy(d['Steps'][33]['Snapshot']['Popups'][0]['Items'][1])))
 def test_wrong_check_value(self):self.bad(lambda d:next(x for x in d['Steps'][35]['Snapshot']['Elements']if x['ID']==v.menu('view-menu','grid')).update(Value=False))
 def test_rejected_check_accepted(self):self.bad(lambda d:d['Steps'][36]['Model'].update(Checked=False))
 def test_outside_release_activated(self):self.bad(lambda d:d['Steps'][26]['Model'].update(OutsideActions=1))
 def test_bad_outside_point(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='action-outside-consumed/MouseDown')['Input'].update(Position={'X':15,'Y':370}))
 def test_bad_stale_button(self):self.bad(lambda d:next(x for x in d['Inputs']if x['Label']=='action-stale-refusal')['Input'].update(Button='NoButton'))
 def test_session_leak(self):self.bad(lambda d:d['Session'].update(LiveWindows=1))
 def test_original_not_closed(self):self.bad(lambda d:d.update(OriginalRefClosed=False))
 def test_multiple_reports(self):
  b=json.dumps(fixture()).encode()
  with self.assertRaises(ValueError):v.validate(b+b'\n'+b)
 def test_unknown_stderr(self):
  with self.assertRaises(ValueError):v.validate(json.dumps(fixture()).encode(),b'unknown\n')
if __name__=='__main__':unittest.main(verbosity=2)
