"""One corrected native record with stage84; the original failed scope stays sealed."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;F=R.parent/'macos-navigation-catalogue-d9eb5ab'
s=importlib.util.spec_from_file_location('navigation_stage84_guard',F/'run.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
b=old.b;h=old.h;g=old.g;sha=old.sha;need=old.need;read=old.read;C=old.C;T=old.T;SDK=old.SDK;HEAD=old.HEAD
sys.path.insert(0,str(R))
# The parent module loaded its own validator, so explicitly load this scope's copy.
s=importlib.util.spec_from_file_location('corrected_navigation_validator',R/'validate.py');validator=importlib.util.module_from_spec(s);s.loader.exec_module(validator)
CHANGED=['drivers/cogent/cmd/gallery/list_box.go','drivers/cogent/cmd/gallery/main.go','drivers/cogent/native/README.md','drivers/cogent/native/dependencies.json','drivers/cogent/prepare_test.py','specs/desktop-integration.md']
NEW=old.NEW+['drivers/cogent/native/patches/popupbuttonembedders/'+n for n in ['0084-inspect-button-embedders.patch','README.md','original-hashes.json','output-hashes.json']]
def baseline():
 a=old.source();need(b.git(T,'rev-parse','HEAD').decode().strip()==HEAD and b.git(T,'diff','--name-only').decode().splitlines()==CHANGED,'exact corrected tracked delta')
 need(set(b.git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(NEW)and not b.git(T,'diff','--cached','--name-only'),'exact corrected additions')
 names=b.git(T,'ls-files','-z').decode().split('\0')[:-1]+NEW;t={n:sha(T/n)for n in names}
 need(set(t)==set(a)|set(NEW)and all(t[n]==z for n,z in a.items()if n not in CHANGED),'unchanged other source')
 p83=b.prepared(C);p84=b.prepared(T);original=read(F/'plan.json')
 need(p83==original['prepared']and len(p83)==6267 and len(p84)==6268,'separate complete prepared stages')
 changed=sorted(n for n in set(p83)|set(p84)if p83.get(n)!=p84.get(n));need(changed==['upstream/core/popup_button_embedder_offscreen_test.go','upstream/core/popup_inspection.go'],'exact stage84 prepared differences')
 outputs=read(T/'drivers/cogent/native/patches/popupbuttonembedders/output-hashes.json')
 need(all(p84['upstream/'+n]==z for n,z in outputs.items()),'declared stage84 outputs')
 sdk=original['sdk_files'];need(b.vector(SDK)==sdk,'retained SDK unchanged');mapping=read(F/'stage84-overlay.json')['Replace']
 for original,replacement in mapping.items():
  relative=Path(original).relative_to(SDK)
  if relative.as_posix().startswith('examples/'):continue
  need(Path(replacement).read_bytes()==(T/relative).read_bytes(),'current corrected overlay '+str(relative))
 for n,z in p84.items():
  q=SDK/'drivers/cogent/build'/n;need(sha(mapping.get(str(q),str(q)))==z,'whole stage84 overlay')
 return a,t,p83,p84,sdk
def prepare():
 need(not(R/'plan.json').exists()and not(R/'case').exists(),'fresh corrected scope');a,t,p83,p84,sdk=baseline();review=read(R/'internal-source-review.json');need(review['approved']and not review['unresolved_findings']and all(sha(k)==z for k,z in review['inputs'].items()),'exact corrected source review')
 need((F/'stop-live').is_file()and read(F/'result.json')['result']=='FAILED_OR_CANCELED'and read(F/'failed-post-boundary.json')['result']=='UNCHANGED_AFTER_FAILED_NATIVE','original failure sealed/preserved')
 pins={}
 for root,name in [(F,n)for n in ['prepare-stage84','python-stage84','core-stage84','driver-stage84','gallery-stage84','vet-stage84','build-stage84']]+[(R,'validation-final')]:
  r=read(root/(name+'.json'));need(b.passing(r),'owned corrected prerequisite '+name);need(all(sha(k)==z for k,z in r['source_pins'].items()),'current prerequisite sources '+name);pins.update(r['source_pins']);pins[str(root/(name+'.json'))]=sha(root/(name+'.json'))
  for stream,info in r['logs'].items():
   q=root/name/stream;need(q.stat().st_size==info['bytes']and sha(q)==info['sha256'],'raw prerequisite '+name);pins[str(q)]=sha(q)
 paths=[Path(__file__),R/'validate.py',R/'validation_controls.py',R/'internal-source-review.json',F/'run.py',F/'plan.json',F/'admission.json',F/'result.json',F/'stop-live',F/'failed-post-boundary.json',F/'stage84-preparation-proof.json',Path(b.__file__),Path(h.__file__),h.GUARD,h.GO,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(q):sha(q)for q in paths});binary=read(F/'build-stage84.json')['binary'];need(sha(binary['path'])==binary['sha256'],'fresh corrected binary');now=datetime.datetime.now(datetime.timezone.utc)
 p={'head':HEAD,'canonical_source':a,'candidate_source':t,'canonical_prepared':p83,'prepared':p84,'sdk':str(SDK),'sdk_files':sdk,'pins':pins,'binary':binary,'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':120,'stream_limit_bytes':4<<20,'runtime_options':{k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']},'scope':'One fresh corrected native47-input41-observation navigation record. Original failed17-input16-source-asserted-observation case remains failed/sealed; no reset/retry. Same authored inputs/expected values, now stage84 recognizes actual direct Button embeddings via initialized same-direct-child AsTree identity; all record/label/byte/visibility/clipping/lifetime rules unchanged. One bounded Failed snapshot added only to new consumer; prior missing failed snapshot not backfilled. Literal corrected validator adds rejecting claimed passes with Failed observation;35synthetic controls. C stage83 and T stage84 full prepared vectors are separately pinned; only declared two paths differ and candidate dependency chain was reproduced. CPU-scene GOMAXPROCS2/native786a/current Go plus exact6tracked/9new files. Same public list/menu contract and exactly-once/refusal/closure tests. Shared exclusive lease, whole C/T/prepared/SDK before-after checks, IP/SDK-write denial,120s/4MiB bounded owned cleanup, one attempt then terminal seal. No native pixels/physical OS input/IME/VoiceOver/display/performance/Cocoa deallocation/full catalogue/fullMac gate/SDK refresh/public release or OS setting/input/clipboard changes. No input operator or sealed placement scope use.'}
 (R/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(R/'plan.json'),'native_executed':False}))
def run():
 raw=(R/'plan.json').read_bytes();araw=(R/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(araw);stop=R/'stop-live';need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact corrected admission');need(not stop.exists()and not(R/'case').exists()and not(R/'result.json').exists(),'one fresh corrected case')
 def stable():return(R/'plan.json').read_bytes()==raw and(R/'admission.json').read_bytes()==araw and all(sha(k)==z for k,z in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  need(not stop.exists()and stable(),'stable inputs/no stop');need(baseline()==(p['canonical_source'],p['candidate_source'],p['canonical_prepared'],p['prepared'],p['sdk_files']),'whole corrected source/prepared/SDK boundary');need({k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']}==p['runtime_options'],'runtime options')
 d={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('corrected navigation signal '+str(signum))
 previous=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline');profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(SDK))+'))'
   r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],'-navigation-native-check'],SDK/'drivers/cogent',R/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);d['run']=r;d['native_executed']=r['created'];need(b.passing(r),'owned corrected native result');d['summary']=validator.validate((R/'case/stdout').read_bytes(),(R/'case/stderr').read_bytes());boundary();need(lease.held(),'lease through cleanup');d['result']='PASS_NATIVE_NAVIGATION'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,previous);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(R/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error','summary']}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in[['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
