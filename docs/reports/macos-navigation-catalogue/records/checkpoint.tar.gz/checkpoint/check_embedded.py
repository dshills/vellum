from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=W.parent/'macos-control-popup-a1f92bb';R=W.parent/'macos-control-refocus-4d0b5f7'
s=importlib.util.spec_from_file_location('choice_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);sdk=Path(json.loads((P/'scope.json').read_text())['sdk'])
name,kind=sys.argv[1:];overlay=W/('embedded-negative-overlay.json'if kind=='negative'else'embedded-positive-overlay.json')
assert overlay.is_file()
inputs=[Path(p)for p in json.loads(overlay.read_text())['Replace'].values()if p]+[overlay,Path(__file__),Path(h.__file__),h.GUARD,h.GO];pins={str(p):h.sha(p)for p in inputs}
base=['-p=1','-overlay='+str(overlay),'-tags=offscreen']
args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^TestPopupInspectionButtonEmbeddersAndPassiveSeparator$','./core']
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args],sdk/'drivers/cogent/build/upstream',W/name,lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=180,limit=4<<20);r['source_pins']=pins;r['native_executed']=False
if kind=='build'and r['exit_code']==0:r['binary']={'path':str(W/'native-gallery'),'sha256':h.sha(W/'native-gallery')}
(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
