from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-navigation-catalogue/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
review=read(W/'internal-prism-disposition.json');assert review['approved']and not review['unresolved_findings']
files={}
def add(p,n):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in files and not n.startswith('/')and '..'not in Path(n).parts;files[n]=p
# Whitelist regular receipts and text logs; no binaries or SDK payloads.
checks=['gallery-v1','vet-v1','build-v1','gallery-v2','gallery-final','driver-race-final','pointer-final','vet-final','build-final','validation-final','embedded-negative','embedded-negative-v2','embedded-positive','prepare-stage84','python-stage84','core-stage84','driver-stage84','gallery-stage84','vet-stage84','build-stage84']
for name in checks:
 add(W/(name+'.json'),'checks/'+name+'.json')
 for stream in ['stdout','stderr','owned.json']:add(W/name/stream,'checks/'+name+'/'+stream)
for directory in ['versions','failed-source']:
 for p in sorted((W/directory).rglob('*')):
  if p.is_file():add(p,directory+'/'+p.relative_to(W/directory).as_posix())
for n in ['run.py','check.py','check_validation.py','validate.py','validation_controls.py','overlay.json','machine.json','internal-source-review.json','plan.json','admission.json','result.json','stop-live','failed-post-boundary.json','stage83-popup_inspection.go','stage84-popup_inspection.go','popup_button_embedder_offscreen_test.go','check_embedded.py','check_embedded_v2.py','install_stage84.py','check_stage84.py','stage84-overlay.json','stage84-preparation-proof.json','embedded-negative-overlay.json','embedded-negative-v2-overlay.json','embedded-positive-overlay.json','finish_docs.py','revise_docs.py','stage.py','review-paths.json','review-scope.json','staged.diff','finalize_provider_docs.py','final-scope.json','final-staged.diff','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','archive.py','ready_commit.py','post_promotion.py']:
 add(W/n,'checkpoint/'+n)
for n in ['stdout','stderr','owned.json']:add(W/'case'/n,'failed-native/'+n)
N=W.parent/'macos-navigation-embedded-d9eb5ab'
for n in ['run.py','validate.py','validation_controls.py','check_validation.py','validation-final.json','internal-source-review.json','plan.json','admission.json','result.json','stop-live']:
 add(N/n,'corrected-native/'+n)
for directory in ['case','validation-final']:
 for n in ['stdout','stderr','owned.json']:add(N/directory/n,'corrected-native/'+directory+'/'+n)
for n in read(W/'final-scope.json')['paths']:add(T/n,'source/'+n)
origins={n:str(p)for n,p in sorted(files.items())};(W/'member-origins.json').write_text(json.dumps(origins,indent=2)+'\n');add(W/'member-origins.json','checkpoint/member-origins.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(x['bytes']for x in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(x['bytes']<=10<<20 for x in manifest.values())
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as out:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;out.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as check:
 for m in check:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=check.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
prism=read(W/'prism.json');command=read(W/'prism-command.json')
r={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'native_record':'PASS47/41','physical_input_verified':False,'full_mac_complete':False,'provider_review':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':prism['coverage']['llmCalls'],'files':len(read(W/'review-scope.json')['paths']),'complete':prism['coverage']['complete'],'exit_code':command['exit_code'],'retained_findings':len(prism['findings']),'internal_disposition_approved':review['approved']}};(R/'archive.json').write_text(json.dumps(r,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
