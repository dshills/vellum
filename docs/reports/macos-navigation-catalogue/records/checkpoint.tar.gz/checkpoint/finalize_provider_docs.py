from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
disposition=read(W/'internal-prism-disposition.json');assert disposition['approved']and not disposition['unresolved_findings']and all(sha(k)==z for k,z in disposition['inputs'].items())
prism=read(W/'prism.json');assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1 and prism['coverage']['files']==24 and prism['coverage']['bytes']==75829
assert {f['id']for f in prism['findings']}=={'5bf1a54263b743f7','28644b13228b9d53'}and not prism['discarded']and not prism['suppressed']
name='docs/reports/macos-navigation-catalogue/README.md';p=T/name;provider=read(W/'review-scope.json');assert sha(p)==provider['files'][name]==sha(W/'versions/provider-reviewed-README.md')
s=p.read_text();marker='## Scope and remaining work';assert marker in s
s=s.replace(marker,'''Prism reviewed all 24 staged files (75,829 bytes) in one Anthropic Claude Sonnet
5.5 call, with no excluded/skipped/truncated input or suppressed findings. The
raw CLI exits 1 with two retained medium comments and no discarded comments.
Both were independently reviewed against the unchanged source and raw record.
The outside-dismissal point comes from measured, fully visible bounds in this
fixed authored view; MouseDown checks it against the current popup, and the
independent validator checks both packets against any current popup. MouseUp
may correctly observe no popup after MouseDown dismisses it. This does not
qualify arbitrary resize/display transitions. The final indexes follow the
fixed nonempty script and successful final observation, which requires exactly
three items in that same detached snapshot before it is appended. Neither
comment identifies a reachable failure in this consumer. No source edit or
provider rerun is needed. This factual README-only addition receives final
internal review; the original provider payload and reviewed README are retained.

'''+marker,1);p.write_text(s)
run_child(['git','add','--',name],cwd=T,timeout=30,check=True)
diff=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,check=True,capture_output=True).stdout
r={**provider,'files':{n:sha(T/n)for n in provider['paths']},'staged_diff_bytes':len(diff),'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'provider_staged_diff_sha256':provider['staged_diff_sha256'],'post_provider_changed_paths':[name]}
assert all(r['files'][n]==z for n,z in provider['files'].items()if n!=name)
(W/'final-scope.json').write_text(json.dumps(r,indent=2)+'\n');(W/'final-staged.diff').write_bytes(diff);print(json.dumps({'bytes':len(diff),'sha256':r['staged_diff_sha256']}))
