from pathlib import Path
import hashlib,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=300,capture_output=True,check=True).stdout
review=read(W/'internal-commit-review.json');scope=read(W/'final-scope.json');provider_scope=read(W/'review-scope.json');R=T/'docs/reports/macos-navigation-catalogue/records'
assert review['approved']and review['commit_ready']and not review['unresolved_findings']
assert set(review['inputs'])>={str(R/n)for n in ['checkpoint.tar.gz','manifest.json','archive.json']}|{str(Path(__file__).resolve())}
assert all(sha(p)==z for p,z in review['inputs'].items())
base=scope['base_commit'];assert base=='d9eb5abe1d2945f1511dff535dad7d575f91821e'and git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==base and not git(C,'status','--porcelain')and not git(T,'diff','--name-only')
diff=git(T,'diff','--cached','--binary');assert hashlib.sha256(diff).hexdigest()==scope['staged_diff_sha256']==review['staged_diff_sha256']and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths'])
assert all(sha(T/n)==z for n,z in scope['files'].items())
assert not git(T,'ls-files','--others','--exclude-standard').decode().splitlines() or set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines())=={'docs/reports/macos-navigation-catalogue/records/'+n for n in ['checkpoint.tar.gz','archive.json','manifest.json']}
prism=read(W/'prism.json');coverage=prism['coverage'];assert coverage['complete']and coverage['llmCalls']==1 and not coverage['excluded']and not coverage['skipped']and not coverage['truncatedBytes']and not prism['suppressed']
assert read(W/'prism-command.json')['staged_diff_sha256']==provider_scope['staged_diff_sha256']==sha(W/'prism-staged.diff')
assert scope['paths']==provider_scope['paths']and scope['post_provider_changed_paths']==['docs/reports/macos-navigation-catalogue/README.md']
assert all(scope['files'][n]==z for n,z in provider_scope['files'].items()if n not in scope['post_provider_changed_paths'])
disposition=read(W/'internal-prism-disposition.json');assert disposition['approved']and not disposition['unresolved_findings']and all(sha(k)==z for k,z in disposition['inputs'].items())
assert {f['id']for f in prism['findings']}==set(disposition['retained_finding_ids'])and {x['finding']['id']for x in prism['discarded']}==set(disposition['discarded_finding_ids'])
assert read(W.parent/'macos-navigation-embedded-d9eb5ab/result.json')['result']=='PASS_NATIVE_NAVIGATION'and(W/'stop-live').is_file()and(W.parent/'macos-navigation-embedded-d9eb5ab/stop-live').is_file()
manifest=read(R/'manifest.json');seen=set();expanded=0
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as archive:
 for m in archive:
  assert m.isfile()and not m.name.startswith('/')and '..'not in Path(m.name).parts and m.name in manifest and m.name not in seen and m.size<=10<<20
  seen.add(m.name);expanded+=m.size;assert len(seen)<=256 and expanded<=32<<20
  data=archive.extractfile(m).read();assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
a=read(R/'archive.json');assert seen==set(manifest)and a['members']==len(seen)and a['expanded_bytes']==expanded and a['archive_bytes']==(R/'checkpoint.tar.gz').stat().st_size<=8<<20 and a['archive_sha256']==sha(R/'checkpoint.tar.gz')and a['manifest_sha256']==sha(R/'manifest.json')
plan=read(W.parent/'macos-navigation-embedded-d9eb5ab/plan.json')
# Verify complete prepared vectors before any promotion.
def prepared(root):
 return {m+'/'+p.relative_to(root/'drivers/cogent/build'/m).as_posix():sha(p) for m in ['upstream','typesetting'] for p in (root/'drivers/cogent/build'/m).rglob('*') if p.is_file()}
assert prepared(C)==plan['canonical_prepared']and prepared(T)==plan['prepared']
changes=sorted(n for n in set(plan['canonical_prepared'])|set(plan['prepared'])if plan['canonical_prepared'].get(n)!=plan['prepared'].get(n))
assert changes==['upstream/core/popup_button_embedder_offscreen_test.go','upstream/core/popup_inspection.go']
extra=['docs/reports/macos-navigation-catalogue/records/'+n for n in ['checkpoint.tar.gz','archive.json','manifest.json']];git(T,'add','--',*extra);git(T,'diff','--cached','--check');assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths']+extra)
print(git(T,'commit','-m','Fix embedded popup inspection and qualify native lists and menus').decode());head=git(T,'rev-parse','HEAD').decode().strip();assert not git(T,'status','--porcelain');print(git(C,'merge','--ff-only',head).decode());assert git(C,'rev-parse','HEAD').decode().strip()==head and not git(C,'status','--porcelain')
# Adopt precisely the declared stage84 prepared outputs only after source promotion.
for n in changes:
 dst=C/'drivers/cogent/build'/n;src=T/'drivers/cogent/build'/n
 assert sha(src)==plan['prepared'][n]
 if n in plan['canonical_prepared']:assert sha(dst)==plan['canonical_prepared'][n]
 else:assert not dst.exists()
 dst.write_bytes(src.read_bytes())
assert prepared(C)==prepared(T)==plan['prepared']
r={'commit':head,'canonical_clean':True,'candidate_clean':True,'native_record':'PASS47/41','sdk_refreshed':False,'full_mac_complete':False};(W/'commit-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
