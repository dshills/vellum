from pathlib import Path
import difflib,hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'drivers/cogent';patchdir=D/'native/patches/popupbuttonembedders'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not patchdir.exists();patchdir.mkdir()
before=(W/'stage83-popup_inspection.go').read_bytes();after=(W/'stage84-popup_inspection.go').read_bytes();test=(W/'popup_button_embedder_offscreen_test.go').read_bytes()
patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/core/popup_inspection.go',tofile='b/core/popup_inspection.go'))
patch+=''.join(difflib.unified_diff([],test.decode().splitlines(True),fromfile='/dev/null',tofile='b/core/popup_button_embedder_offscreen_test.go'))
name='0084-inspect-button-embedders.patch';(patchdir/name).write_text(patch)
(patchdir/'original-hashes.json').write_text(json.dumps({'core/popup_inspection.go':sha(before),'core/popup_button_embedder_offscreen_test.go':None},indent=2)+'\n')
(patchdir/'output-hashes.json').write_text(json.dumps({'core/popup_inspection.go':sha(after),'core/popup_button_embedder_offscreen_test.go':sha(test)},indent=2)+'\n')
(patchdir/'README.md').write_text('''# Direct Button embeddings in popup inspection (stage 84)

The bounded actual-popup inspector now uses Core's existing `AsButton` embedding
capability, as the menu implementation already does. Vellum MenuButton items
embed Button for lifecycle ownership; an exact `*Button` assertion omitted them.
The base must be initialized and share the direct child's AsTree identity.
Forwarding a different button or wrapping a nested button is not a direct
embedding and does not create an inspection target.

All existing ownership, stage precedence, record/label/byte budgets, detached
copies, clipping, visibility/read-only state and monotonic lifetime IDs remain
in force. Every visited child is charged before conversion; passive separators
remain absent. No recursive traversal, registry or new public API is added.

The focused software regression uses real embedded and standard buttons,
duplicate labels, a disabled embedding, a separator and a foreign-button wrapper.
It checks actual bounds, distinct/stable IDs, exactly-once measured pointer input,
retirement and new IDs after reopening. The old implementation fails by omitting
the two embedded items; the corrected source passes. These software results are
separate from native/physical qualification. The native navigation catalogue
supplies the actual MenuButton integration record and its explicit limitations.
''')
p=D/'native/dependencies.json';s=json.loads(p.read_bytes());core=s['dependencies'][0];assert core['stages'][-1]['patches'][0]['file'].endswith('0083-bounded-popup-inspection.patch')
core['stages'].append({'origin':'drivers/cogent/native/patches/popupbuttonembedders','inputs':'native/patches/popupbuttonembedders/original-hashes.json','outputs':'native/patches/popupbuttonembedders/output-hashes.json','patches':[{'file':'native/patches/popupbuttonembedders/'+name,'sha256':sha((patchdir/name).read_bytes())}]});p.write_text(json.dumps(s,indent=2)+'\n')
p=D/'prepare_test.py';s=p.read_text();assert 'list(range(1, 84))'in s;p.write_text(s.replace('list(range(1, 84))','list(range(1, 85))',1))
p=D/'native/README.md';s=p.read_text();s+='''
Stage84 (`patches/popupbuttonembedders`) includes direct Button embeddings such
as MenuButton items in bounded actual-popup inspection. It verifies initialized
base/direct-child ownership, retains budget/clipping/lifetime rules and excludes
passive or foreign/nested wrappers. See the [contract](patches/popupbuttonembedders/README.md).
''';p.write_text(s)
p=T/'specs/desktop-integration.md';s=p.read_text();s=s.replace("top event-accepting popup's visible enabled direct standard buttons are targeted.","top event-accepting popup's visible enabled direct Buttons and Button embeddings\nare targeted. An initialized base must share the direct child's tree identity;\na wrapper forwarding another or nested button is excluded.",1).replace('No historical widget registry is retained. Custom/nested menus retain existing','No historical widget registry is retained. Nested/non-Button menus retain existing',1);p.write_text(s)
p=D/'cmd/gallery/navigation_catalogue.go';s=p.read_text();s=s.replace('\tSteps                []navigationObservation','\tFailed               *navigationObservation\n\tSteps                []navigationObservation',1)
needle='\t\tif actual != step.Want {';assert needle in s;s=s.replace(needle,'\t\treport.Failed = &navigationObservation{step.Label, actual, snap}\n'+needle,1)
needle='\t\treport.Steps = append(report.Steps, navigationObservation{step.Label, actual, snap})';assert needle in s;s=s.replace(needle,needle+'\n\t\treport.Failed = nil',1);p.write_text(s)
print(json.dumps({'stage':84,'core_file_sha256':sha(after),'core_test_sha256':sha(test),'patch_sha256':sha((patchdir/name).read_bytes()),'native_executed':False}))
