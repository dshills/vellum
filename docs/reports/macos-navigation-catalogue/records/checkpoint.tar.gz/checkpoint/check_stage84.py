from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'drivers/cogent';name,kind=sys.argv[1:]
s=importlib.util.spec_from_file_location('stage84_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);sdk=Path(json.loads((W/'plan.json').read_bytes())['sdk'])
overlay=W/'stage84-overlay.json'
if kind=='prepare':
 paths=[D/'prepare.py',D/'native/dependencies.json',Path(__file__),Path(h.__file__),h.GUARD,h.GO]+[p for p in(D/'native/patches').rglob('*')if p.is_file()]
 args=['/usr/bin/python3','-B',str(D/'prepare.py')];cwd=D
else:
 paths=[Path(p)for p in json.loads(overlay.read_bytes())['Replace'].values()if p]+[overlay,Path(__file__),Path(h.__file__),h.GUARD,h.GO]
 base=['-p=1','-overlay='+str(overlay),'-tags=offscreen'];cwd=sdk/'drivers/cogent'
 if kind=='python':args=['/usr/bin/python3','-B',str(D/'prepare_test.py')];paths.extend([D/'prepare.py',D/'prepare_test.py',D/'native/dependencies.json']);paths.extend(p for p in(D/'native/patches').rglob('*')if p.is_file())
 elif kind=='core':args=[str(h.GO),'test','-v','-race','-count=1',*base,'-timeout=3m','-run','^TestPopupInspection','./core'];cwd=sdk/'drivers/cogent/build/upstream'
 elif kind=='driver':args=[str(h.GO),'test','-v','-race','-count=1',*base,'-timeout=8m','.']
 elif kind=='gallery':args=[str(h.GO),'test','-v','-race','-count=1',*base,'-timeout=2m','./cmd/gallery']
 elif kind=='vet':args=[str(h.GO),'vet',*base,'.','./cmd/gallery']
 elif kind=='build':args=[str(h.GO),'build','-p=1','-overlay='+str(overlay),'-o',str(W/'navigation-stage84'),'./cmd/gallery']
 else:raise ValueError(kind)
pins={str(p):h.sha(p)for p in paths};env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*args],cwd,W/name,lambda:False,lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=540 if kind=='driver'else 240,limit=4<<20);r['source_pins']=pins;r['native_executed']=False
if kind=='build'and r['exit_code']==0:r['binary']={'path':str(W/'navigation-stage84'),'sha256':h.sha(W/'navigation-stage84')}
(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
