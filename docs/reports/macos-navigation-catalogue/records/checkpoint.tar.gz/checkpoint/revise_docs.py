from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
name='docs/reports/macos-navigation-catalogue/README.md';p=T/name;s=p.read_text();s=s.replace('The complete driver-root and gallery race suites, gallery vet and native build','The complete driver-root package (`.`) and gallery race suites, gallery vet and native build').replace('Raw\nreview output, complete logs and original versions are retained without compiled','The archive will retain raw\nreview output, complete logs and original versions without compiled');p.write_text(s)
run_child(['git','add','--',name],cwd=T,timeout=30,check=True)
r=json.loads((W/'review-scope.json').read_bytes());r['files'][name]=hashlib.sha256(p.read_bytes()).hexdigest();d=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,check=True,capture_output=True).stdout;r.update(staged_diff_bytes=len(d),staged_diff_sha256=hashlib.sha256(d).hexdigest());assert len(d)<100000
(W/'review-scope.json').write_text(json.dumps(r,indent=2)+'\n');(W/'staged.diff').write_bytes(d);(W/'versions/provider-reviewed-README.md').write_bytes(p.read_bytes());print(json.dumps({'bytes':len(d),'sha256':r['staged_diff_sha256']}))
