from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
read=lambda p:json.loads(Path(p).read_bytes())
r=read(W/'result.json');assert r['result']=='PASS_NATIVE_NAVIGATION'and r['summary']['inputs']==47 and r['summary']['observations']==41
report=T/'docs/reports/macos-navigation-catalogue';(report/'records').mkdir(parents=True,exist_ok=False)
(report/'README.md').write_text('''# Native lists and action menus

The standard gallery's new `-navigation-native-check` passes **47 public Go FIFO
inputs and 41 independently expected observations**. It reuses the ordinary
ListBox and MenuButton public constructors, with application-owned accepted
state. No framework driver API or prepared dependency changes are introduced.
This is a named native catalogue record, not full M2/M5 or Mac completion.

The list record exercises Down and disabled skipping, explicit pointer repeat,
End/Home and initial-letter scrolling, end-boundary no-op, owner rejection,
read-only focus without selection changes, disable/refusal/re-enable, changed
pointer selection and one managed Tab stop. An accepted row pointer activation
still proposes that row once; it is intentionally different from the choice
controls' selected-Space no-op. Eight list callbacks include that explicit repeat
and one rejected navigation.

Menus exercise duplicate-label stable-ID actions through actual popup pointer
and focused keys; disabled and stale actual popup targets; Escape and outside
release consumption; a later ordinary button action; owner disable while modal;
and Tab traversal after the anchor. A separate check menu verifies acceptance,
rejection and reset with a passive separator omitted from action targets. Counts
finish at two ordinary menu proposals, three check/reset proposals and one
ordinary outside action. Closing the original window with a current popup open
refuses that popup item's later input. The session closes with no pending request
or live window, and the owned process group is confirmed absent.

## Verification

The complete driver-root and gallery race suites, gallery vet and native build
pass on final source. A measured-pointer driver regression passes three repeats,
proving accepted-row repeat and changed-row selection propose exactly once.
An independent consumer uses only public Manual APIs for list keys/repeat Space,
read-only/rejection behavior, duplicate-label popup targets, stale incarnations,
modal owner disable, Tab and check/separator behavior. Public Manual currently
publishes the list host rather than option-row target geometry, so the pointer
regression separately uses actual private native row bounds. No geometry is
guessed and no public inspection API is added just for the test.

The external validator binds all 47 authored packet identities/types/key runes,
actual popup incarnations, group-qualified list rows, focused key targets,
measured pointer bounds, refusals and input/observation frame interleaving. It
checks all 41 literal models/callback counts, accepted list/check/status semantics,
clipped list scrolling, focus distinct from selection and terminal closure.
Thirty-four synthetic positive/negative parser controls pass; synthetic fixtures
are not native evidence. No original acceptance record or expected outcome is
changed after native execution. Earlier passing software receipts are historical
to their pinned sources/overlays, which are retained separately.

This checkpoint requires internal source/controller, exact-plan admission,
provider-result and final archive/commit reviews, plus one scoped Prism
Anthropic Claude Sonnet 5.5 review. The [bounded archive](records/checkpoint.tar.gz)
and [member manifest](records/manifest.json) are required commit artifacts. Raw
review output, complete logs and original versions are retained without compiled
binaries, fonts or SDK payloads.

## Scope and remaining work

The configuration is Go1.25.6 Darwin/ARM64, controlled GOMAXPROCS=2 and CPU-scene
native routing over retained source-built archive `786aaad8...`. The full 6267
stage83 prepared files and all 7880 retained SDK files remain unchanged. This is
not a refreshed SDK or qualification of other archives/configurations. Go FIFO
does not establish physical/OS input, IME, VoiceOver, display transitions, native
pixels/presentation, performance, Cocoa deallocation or resource/endurance gates.
No OS settings/input sources/clipboard change, SDK refresh or public release is
performed. Full M2/M5 and M3–M7 remain open.

Continue remaining native tabs/disclosure/scroll/split, text/modal, image and
composite workflows in the [acceptance map](../../../specs/control-acceptance.md).
Performance and endurance retain the original [delivery plan](../../../specs/macos-delivery.md)
thresholds and prerequisite order. The [gallery instructions](../../../drivers/cogent/cmd/gallery/README.md)
show how to run this consumer independently through public APIs.
''')
checks={}
for n in ['gallery-final','driver-race-final','pointer-final','vet-final','build-final','validation-final']:
 q=W/(n+'.json');c=read(q);checks[n]={'receipt_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),**{k:c[k]for k in ['exit_code','seconds','logs_complete','pins_stable']},'owned_group_absent':c['owned']['group_absent']}
summary={'base_commit':'d9eb5abe1d2945f1511dff535dad7d575f91821e','native':r,'checks':checks,'prepared_files':6267,'sdk_files':7880,'sdk_unchanged':True,'physical_input_verified':False,'native_pixels_verified':False,'closed_full_mac_gates':[],'goal_complete':False}
(report/'records/results.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraph='''The [list/menu catalogue checkpoint](../docs/reports/macos-navigation-catalogue/README.md)
adds 47 native Go FIFO inputs and 41 independent observations. ListBox scrolling,
explicit repeat proposals, rejection/read-only/disabled behavior and Tab pass;
MenuButton duplicate-label actions, actual popup pointer/keys, disabled/stale
refusal, Escape/outside consumption, modal owner disable, check/separator/reset
and original-window closure pass. Callback totals are 8 list, 2 menu, 3 check/reset
and 1 outside action. This is controlled Go2/SDK786a CPU-scene routing. Remaining
catalogue, full M2/M5, physical/human input and M3–M7 stay open; no SDK refresh.

'''
for name,marker in [('macos-delivery.md','## Finish line'),('macos-completion.md','## M1 SDK command ownership'),('control-acceptance.md','The remaining native catalogue work is:')]:
 p=T/'specs'/name;s=p.read_text();assert marker in s;s=s.replace(marker,paragraph+marker,1);p.write_text(s)
p=T/'specs/macos-delivery.md';s=p.read_text();old='''   includes the new routed Selector/NumberField regressions. Native M2 integration
   remains queued; [actual results](../docs/reports/macos-workspace-acceptance/README.md)
   distinguish software routing from desktop acceptance.''';new='''   includes routed control regressions and named native records. The complete
   [native workspace record](../docs/reports/macos-native-workspace/README.md)
   passes at both row counts; native catalogue coverage remains partial. Physical/
   human workflows and full M2 acceptance remain open. Software and native
   evidence retain their distinct scopes.''';assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=T/'specs/control-acceptance.md';s=p.read_text();s=s.replace('**W** is the full public workspace replay.','**W** is the full public workspace replay. **N** is a named native Go FIFO\nrecord; OS/physical input and native pixels are separate evidence.',1)
s=s.replace('scrolling selection, focus scopes and retirement | R |','scrolling selection, focus scopes and retirement; `gallery -navigation-native-check`: native scroll/rejection/read-only/disabled/Tab and exactly-once proposals | R/N |',1).replace('duplicate labels, dismissal and stale popup refusal | R |','duplicate labels, dismissal and stale popup refusal; `gallery -navigation-native-check`: native duplicate/check/separator actions, dismissal, modal disable and closure | R/N |',1);p.write_text(s)
p=T/'specs/list-box.md';s=p.read_text();s+='''
The gallery also offers `-navigation-native-check`, a bounded native Go FIFO
consumer sharing the ordinary list constructor. Its named 47-input/41-observation
record includes actual list scrolling/pointer input, explicit accepted-row repeat,
rejection/read-only/disabled behavior and Tab. See the
[result](../docs/reports/macos-navigation-catalogue/README.md). Native routing is
separate from physical input, native pixels and human accessibility acceptance.
''';p.write_text(s)
p=T/'specs/menu-button.md';s=p.read_text();s+='''
The gallery's `-navigation-native-check` shares both ordinary menu constructors.
Its native Go FIFO record covers actual duplicate-label action selection by
pointer and keys, disabled/stale target refusal, Escape/outside release handling,
owner disable while modal, Tab traversal, controlled check rejection/reset,
separators and closing with a current popup. The
[result](../docs/reports/macos-navigation-catalogue/README.md) records 47 total
inputs/41 observations across the list/menu scenario. Accepted check semantics
do not verify native checkmark pixels, physical input or human VoiceOver.
''';p.write_text(s)
p=T/'drivers/cogent/cmd/gallery/README.md';s=p.read_text();s+='''
## Native lists and action menus

```sh
go run ./cmd/gallery -navigation-native-check
```

This separate 900x700 requested view reuses the ordinary public list and two
menu constructors. It records 47 native Go FIFO packets and 41 observations,
then closes the original window and emits one JSON result. Its 90-second
deadline, 6-second join, nonzero failures, disabled geometry persistence and
exclusive mode flags match the other catalogue modes. Policy changes are
owner-posted setup; tested values flow through ordinary public callbacks.

The complete native routing record passes list scroll/focus/rejection/read-only/
disabled behavior and menu duplicate-label/check/separator/dismissal/stale-target
cases with exactly-once callbacks and terminal cleanup. Native pixels, physical/
OS input and human accessibility remain separate. See the [result](../../../../docs/reports/macos-navigation-catalogue/README.md).
''';p.write_text(s)
p=T/'docs/desktop-integration.md';s=p.read_text();s+='''

Use `gallery -navigation-native-check` for the separate native ListBox/MenuButton
record: 47 packets/41 observations. It uses actual group-qualified row bounds and
actual current popup item IDs; repeated action labels are distinguished by item
order/identity and verified callback IDs. Reopening never revives an earlier
popup target, even with a new frame. Read-only list keys can change focus and
scroll while accepted selection stays fixed. See the
[native list/menu result](reports/macos-navigation-catalogue/README.md). It does
not establish native pixels or physical/OS/assistive-technology input.
''';p.write_text(s)
paths=['drivers/cogent/cmd/gallery/'+n for n in ['main.go','list_box.go','menu_controls.go','navigation_catalogue.go','navigation_catalogue_test.go','navigation_catalogue_offscreen_test.go','README.md']]+['drivers/cogent/list_box_repeat_offscreen_test.go']+['specs/'+n for n in ['macos-delivery.md','macos-completion.md','control-acceptance.md','list-box.md','menu-button.md']]+['docs/desktop-integration.md','docs/reports/macos-navigation-catalogue/README.md','docs/reports/macos-navigation-catalogue/records/results.json']
(W/'review-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'paths':len(paths),'native':r['summary']}))
