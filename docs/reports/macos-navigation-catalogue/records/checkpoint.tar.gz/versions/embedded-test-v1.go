// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
//go:build offscreen

package core

import (
	"cogentcore.org/core/events"
	"cogentcore.org/core/styles/states"
	"cogentcore.org/core/tree"
	"testing"
)

type popupInspectionEmbeddedButton struct{ Button }

// Managed MenuButton items embed Button to own their lifecycle. They must have
// the same actual popup geometry/capabilities as direct standard Buttons.
func TestPopupInspectionButtonEmbeddersAndPassiveSeparator(t *testing.T) {
	var anchor *Button
	m, body, _ := manualFixture(t, func(b *Body) { anchor = NewButton(b).SetText("Actions") })
	scene := NewScene("embedded-actions")
	calls := 0
	first := tree.New[popupInspectionEmbeddedButton](scene)
	first.SetText("Repeated label")
	first.OnClick(func(events.Event) { calls++ })
	blocked := tree.New[popupInspectionEmbeddedButton](scene)
	blocked.SetText("Unavailable").SetState(true, states.Disabled)
	NewSeparator(scene)
	NewButton(scene).SetText("Repeated label")
	NewMenuStage(scene, anchor, anchor.ContextMenuPos(nil)).Run()
	drainManual(t, m)
	before := inspectPopupOwned(t, m, body.Scene)
	if len(before) != 1 || len(before[0].Items) != 3 {
		t.Fatal("derived buttons omitted or separator admitted", before)
	}
	a, b, c := before[0].Items[0], before[0].Items[1], before[0].Items[2]
	if a.Name != "Repeated label" || b.Name != "Unavailable" || c.Name != "Repeated label" || !a.Enabled || b.Enabled || !c.Enabled || a.ID == b.ID || a.ID == c.ID || b.ID == c.ID {
		t.Fatal("derived button state/order/identity", before)
	}
	for _, item := range before[0].Items {
		if item.Bounds.Empty() || !item.Bounds.In(before[0].Bounds) {
			t.Fatal("actual clipped item bounds", item)
		}
	}
	want := first.Geom.TotalBBox.Add(scene.SceneGeom.Pos).Intersect(before[0].Bounds)
	if a.Bounds != want {
		t.Fatal("derived geometry does not belong to actual widget", a.Bounds, want)
	}
	second := inspectPopupOwned(t, m, body.Scene)
	if second[0].Items[0].ID != a.ID || second[0].Items[2].ID != c.ID || calls != 0 {
		t.Fatal("inspection changes identity or invokes callback")
	}
	clickManual(t, m, a.Bounds.Min.Add(a.Bounds.Size().Div(2)))
	if calls != 1 {
		t.Fatal("actual derived pointer lost or duplicated", calls)
	}
}
