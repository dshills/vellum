from pathlib import Path
import json,hashlib,os
q=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=load(q/'build-identity.json');assert sha(q/'bytecheck')==d['binary_sha256'] and os.access(q/'bytecheck',os.X_OK) and sha(Path(d['root'])/'libs-darwin/arm64/libwgpu_native.a')==d['archive_sha256']
for group in ['private_source_pins','tool_source_pins']:assert all(sha(Path(p))==h for p,h in d[group].items())
r=load(q/'go-build-guard-receipt.json')['run'];assert r['exit_code']==0 and r['error'] is None and r['pins_stable'] and r['logs_complete'] and r['owned']['terminal'] and r['owned']['group_absent']
for stream,e in r['logs'].items():assert sha(q/'go-build-guard'/stream)==e['sha256']
assert load(q.parent/'macos-staging-reuse/result.json')['cases'][0]['outcome']=='REJECT'
print('PASS fresh primary-name metadata fixture binary/source/native identities; originalrefusalretained; no new GPU execution')
