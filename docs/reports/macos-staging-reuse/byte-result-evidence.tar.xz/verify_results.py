from pathlib import Path
import json,hashlib,importlib.util,sys,datetime,tarfile
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-staging-reuse';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=load(q/'bound-plan.json');assert all(sha(Path(p))==h for p,h in plan['pins'].items())
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
v=module('staging_actual_bytes',t/'tools/macos-calibration/stagingreuse/check.py');a=module('staging_SDK_integrity',q.parent/'macos-release-default-assessment/assessment.py');assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
d=load(q/'result.json');assert d['outcome']=='VALID_PRIVATE_STAGING_BYTE_PAIR' and d['error'] is None and [c['kind'] for c in d['cases']]==['off','on'];groups=0
for c in d['cases']:
 root=q/('pair1-'+c['kind']);lines=v.base.load(root/'native/stdout');assert len(lines)==1;doc=lines[0];assert v.validate(doc,c['kind'])==c['validation']==load(root/'validation.json');assert doc['device']=='Apple M4 Pro'==doc['adapter_info']['Device'] and doc['device_name_source']=='wgpu.AdapterInfo.Device';assert c['geometry_before']==c['geometry_after'];assert all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,root/folder/k) for k,cmd in c[phase].items())
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['pins_stable'] and cmd['logs_complete'] and cmd['logs']['stderr']['bytes']==0
  for stream,e in cmd['logs'].items():assert sha(folder/stream)==e['sha256'] and (folder/stream).stat().st_size==e['bytes']
  groups+=1
assert groups==18;s=load(q/'summary.json');assert s==load(r/'byte-result-summary.json') and s['GPU_verified_bytes']==sum(c['validation']['GPU_verified_bytes'] for c in d['cases'])==97912700;assert s['elapsed_seconds']==(datetime.datetime.fromisoformat(d['finished_utc'])-datetime.datetime.fromisoformat(load(q/'started.json')['started_utc'])).total_seconds()<90
for row,c in zip(s['runs'],d['cases']):
 assert row['mode']==c['kind'] and row['metrics']==c['validation']
 doc=load(q/('pair1-'+c['kind'])/'native/stdout');resources={}
 for e in doc['reuse_trace']['records']:
  if e['kind']==2:resources[e['id']]={'id':e['id'],'owner':e['owner'],'bytes':e['bytes'],'fresh_sequence':e['sequence'],'acquisition_calls':[e['call']],'destroy_sequence':None}
  if e['kind']==3:resources[e['id']]['acquisition_calls'].append(e['call'])
  if e['kind']==7:assert resources[e['id']]['destroy_sequence'] is None;resources[e['id']]['destroy_sequence']=e['sequence']
 assert row['resource_lifetimes']==list(resources.values()) and len(resources)==c['validation']['lifecycle']['fresh'] and all(v['destroy_sequence'] is not None for v in resources.values())
for label in ['preparation','first-refusal','metadata-fix-preparation','byte-result']:
 index=r/(label+'-evidence-index.json');archive=r/(label+'-evidence.tar.xz')
 if not index.exists():continue
 e=load(index);assert sha(archive)==e['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(e['files'])
  for n,h in e['files'].items():b=tf.extractfile(n).read();assert len(b)==h['bytes'] and hashlib.sha256(b).hexdigest()==h['sha256']
print('PASS exactoff/on24writes22readbacks each;97912700 full GPU bytes;eligible ledger/device scopes closed;reuse6/eviction5/peak8/oversize/R8/queued3/unsent;18ownedgroups;SDK8321/config/geometry/source/native/binary/logpins;4.588s<90;no UI-latency/release acceptance')
