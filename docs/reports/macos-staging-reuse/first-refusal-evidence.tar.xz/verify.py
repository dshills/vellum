from pathlib import Path
import json,hashlib,os,sys,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=load(q/'build-identity.json');v=Path(d['root']);assert sha(q/'bytecheck')==d['binary_sha256'] and os.access(q/'bytecheck',os.X_OK) and sha(v/'libs-darwin/arm64/libwgpu_native.a')==d['archive_sha256']
for group in ['private_source_pins','tool_source_pins']:assert all(sha(Path(p))==h for p,h in d[group].items())
assert sha(q/'source-audit.json')==d['source_audit_sha256']
for n in ['build-v4','go-build-v4','policy-compile','policy-tests-run','ledger-tests-v3','trace-test-compile','trace-test-run']:
 r=load(q/(n+'-receipt.json'))['run'];assert r['exit_code']==0 and r['error'] is None and r['pins_stable'] and r['logs_complete'] and r['owned']['terminal'] and r['owned']['group_absent']
 for stream,e in r['logs'].items():assert sha(q/n/stream)==e['sha256'] and (q/n/stream).stat().st_size==e['bytes']
assert '5 passed' in (q/'policy-tests-run/stdout').read_text() and 'Ran 9 tests' in (q/'ledger-tests-v3/stderr').read_text()
s=importlib.util.spec_from_file_location('staging_SDK_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
assert '1 passed' in (q/'trace-test-run/stdout').read_text()
print('PASS exact recipe/source/native/binary/package locks; actual private policy5+ledger/protocol9+scalar concurrency1; immutableSDK8321; no GPU execution evidence claimed')
