from pathlib import Path
import json,hashlib,datetime
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());plan=load(q/'bound-plan.json');snapshot=q/'sealed-source-snapshots/main_darwin.go'
for p,h in plan['pins'].items():
 actual=snapshot if p==str(t/'tools/macos-calibration/stagingreuse/bytecheck/main_darwin.go') else Path(p)
 assert sha(actual)==h,p
r=load(q/'result.json');assert r['outcome']=='BLOCKED_BY_RETAINED_INVALID_CASE' and len(r['cases'])==1 and r['cases'][0]['kind']=='off' and r['cases'][0]['outcome']=='REJECT' and r['cases'][0]['error']['message']=='Metal/headless scope'
c=r['cases'][0];root=q/'pair1-off';commands=[(c['native'],root/'native')]
for phase,folder in [('configuration_before','before'),('configuration_after','after')]:commands.extend((cmd,root/folder/k) for k,cmd in c[phase].items())
assert len(commands)==9
for cmd,folder in commands:
 assert cmd['exit_code']==0 and cmd['error'] is None and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['pins_stable'] and cmd['logs_complete'] and cmd['logs']['stderr']['bytes']==0
 for stream,e in cmd['logs'].items():assert sha(folder/stream)==e['sha256'] and (folder/stream).stat().st_size==e['bytes']
assert c['geometry_before']==c['geometry_after'] and all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
d=load(root/'native/stdout');assert d['error']=='<nil>' and d['device']=='' and d['backend']==5 and len(d['writes'])==24
assert not (q/'pair1-on').exists();elapsed=(datetime.datetime.fromisoformat(r['finished_utc'])-datetime.datetime.fromisoformat(load(q/'started.json')['started_utc'])).total_seconds();assert elapsed<90
print('PASS retained metadata refusal, no enabled-pool case; exact original source snapshot/all pins/logs/config/geometry;9 owned groups retired;bounded<90;posthoc mutation not accepted')
