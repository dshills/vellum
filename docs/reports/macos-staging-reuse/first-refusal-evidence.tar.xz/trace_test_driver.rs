extern crate alloc;
#[path="/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/stagingreuse/trace.rs"] pub mod trace;
