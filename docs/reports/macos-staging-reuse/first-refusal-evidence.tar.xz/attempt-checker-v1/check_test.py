import copy, unittest
from check import graph, CAP

def event(kind, identity=0, size=0, submit=0, fence=0, call=0, count=0, cached=0, owner=1):
    return dict(kind=kind,owner=owner,id=identity,bytes=size,submit=submit,fence=fence,call=call,cached_count=count,cached_bytes=cached,complete=True)
def doc(rows, mode='on'):
    rows=copy.deepcopy(rows)
    for i,row in enumerate(rows):row.update(sequence=i,clock=1+i*.001)
    return dict(mode=1 if mode=='off' else 2,count=len(rows),pending=0,overflow=False,invalid=False,active_devices=0,records=rows)
def cycle(mode='on'):
    rows=[event(1),event(2,1,24,call=1),event(4,1,24,submit=1),event(5,1,24,submit=1,fence=1)]
    if mode=='on':
        rows += [event(6,1,24,submit=1,fence=1,count=1,cached=24),event(3,1,24,call=2),event(4,1,24,submit=2),event(5,1,24,submit=2,fence=2),event(6,1,24,submit=2,fence=2,count=1,cached=24),event(8),event(7,1,24),event(9)]
    else:rows += [event(7,1,24,submit=1),event(8),event(9)]
    return doc(rows,mode)

class Ledger(unittest.TestCase):
    def test_off_and_completed_reuse_with_exact_lease_history(self):
        off=graph(cycle('off'),'off');self.assertEqual((off['fresh'],off['takes'],off['peak_idle_count']),(1,0,0))
        on=graph(cycle(),'on');self.assertEqual((on['fresh'],on['takes'],on['peak_idle_bytes']),(1,1,24));self.assertEqual([r['submit'] for r in on['leases']],[1,2])

    def test_three_pending_leases_and_unsent_cleanup(self):
        rows=[event(1)]+[event(2,i,24,call=i) for i in (1,2,3)]
        rows += [event(4,i,24,submit=1) for i in (1,2,3)]
        rows += [event(5,i,24,submit=1,fence=1) for i in (1,2,3)]
        rows += [event(7,i,24,submit=1) for i in (1,2,3)]
        rows += [event(2,4,24,call=4),event(7,4,24),event(8),event(9)]
        r=graph(doc(rows,'off'),'off');self.assertEqual(r['fresh'],4);self.assertEqual(r['leases'][-1]['submit'],0)

    def test_evict_and_drain_are_distinct_from_checkout(self):
        rows=[event(1),event(2,1,24,call=1),event(4,1,24,submit=1),event(5,1,24,submit=1,fence=1),event(6,1,24,submit=1,fence=1,count=1,cached=24),event(10,1,24),event(7,1,24),event(8),event(9)]
        r=graph(doc(rows),'on');self.assertEqual((r['evictions'],r['takes']),(1,0))

    def test_reject_early_cache_fence_duplicate_or_wrong_device(self):
        changes=[(3,'fence',0),(4,'kind',3),(5,'owner',2),(5,'id',2),(6,'submit',1),(7,'fence',1),(8,'cached_bytes',25)]
        for index,key,value in changes:
            with self.subTest(index=index,key=key):
                d=cycle();d['records'][index][key]=value
                with self.assertRaises(ValueError):graph(d,'on')
        d=cycle();d['records'][3]['kind']=6
        with self.assertRaises(ValueError):graph(d,'on')

    def test_reject_missing_destroy_or_end_and_unsafe_destruction(self):
        for index in (9,10,11):
            d=cycle();d['records'].pop(index);d['count']-=1
            for i,r in enumerate(d['records']):r['sequence']=i
            with self.assertRaises(ValueError):graph(d,'on')
        d=cycle('off');d['records'].pop(3);d['count']-=1
        for i,r in enumerate(d['records']):r['sequence']=i
        with self.assertRaises(ValueError):graph(d,'off')

    def test_reject_recorder_partial_overflow_and_scalar_faults(self):
        for key,value in [('pending',1),('overflow',True),('invalid',True),('active_devices',1),('count',4097),('pending',False)]:
            with self.subTest(key=key):
                d=cycle();d[key]=value
                with self.assertRaises(ValueError):graph(d,'on')
        for key,value in [('complete',False),('sequence',99),('bytes',True),('clock',float('nan'))]:
            d=cycle();d['records'][2][key]=value
            with self.assertRaises(ValueError):graph(d,'on')

    def test_reject_capacity_breach_and_off_mode_cache(self):
        d=cycle()
        for r in d['records']:
            if r['id']==1:r['bytes']=CAP+1
            if r['kind']==6:r['cached_bytes']=CAP+1
        with self.assertRaises(ValueError):graph(d,'on')
        d=cycle();d['records'][4]['cached_count']=9
        with self.assertRaises(ValueError):graph(d,'on')
        d=cycle();d['mode']=1
        with self.assertRaises(ValueError):graph(d,'off')

if __name__=='__main__':unittest.main()
