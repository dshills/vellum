from pathlib import Path
P=Path(__file__).resolve().parent
assert "PASS" in (P/"flags-test.log").read_text()
assert "OK" in (P/"classifier-tests.log").read_text()
assert (P/"native-build.log").stat().st_size==0
print("PASS serialization repair and18strictclassifiercontrols;originalrefusalpreserved")
