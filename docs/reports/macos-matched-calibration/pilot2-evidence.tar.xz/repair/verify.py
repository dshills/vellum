from pathlib import Path
P=Path(__file__).resolve().parent
assert "PASS" in (P/"ready-test.log").read_text()
assert (P/"native-build.log").stat().st_size==0
print("PASS native foreground-readiness regression;reused unchanged SDK consumer")
