from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
for n in ["native-build-final.log","framework-build-final.log","offscreen-v5.log","classifier-tests-final.log"]:assert (P/n).exists()
assert "PASS" in (P/"offscreen-v5.log").read_text() and "OK" in (P/"classifier-tests-final.log").read_text()
assert (P/"native-build-final.log").stat().st_size==0
print("PASS preparation: native and optimized SDK consumer built; actual routed model/pixels;15 classifier controls; no native calibration started")
