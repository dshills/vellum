from pathlib import Path
import json,hashlib,sys,importlib.util,datetime,tarfile
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-matched-calibration'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
v=module('matching_validator',T/'tools/macos-calibration/check.py');a=module('matching_integrity',P.parent/'macos-release-default-assessment/assessment.py')
plan=load(P/'bound-plan.json');assert all(sha(Path(p))==h for p,h in plan['pins'].items());assert a.sdk_vector()==load(P.parent/'macos-release-default-assessment/plan.json')['sdk']
result=load(P/'result.json');assert result['outcome']=='FIVE_VALID_MATCHED_SMALL_FIXTURE_PAIRS' and len(result['cases'])==11
match=load(P/'match.json');assert sha(P/'match.json')==load(P/'matched-plan.json')['match_sha256']
start=datetime.datetime.fromisoformat(load(P/'started.json')['started_utc']);finish=datetime.datetime.fromisoformat(result['finished_utc']);assert (finish-start).total_seconds()<480
assert [(c['pair'],c['kind']) for c in result['cases'][1:]]==[(i,k) for i,order in enumerate(plan['pairs'],1) for k in order]
pairs={};commands=0
for c in result['cases']:
 root=P/('pilot' if c['pilot'] else f"pair{c['pair']}-{c['kind']}")
 lines=v.load(root/'native/stdout');doc=v.native_doc(lines) if c['kind']=='native' else lines[0];assert c['kind']=='native' or len(lines)==1
 actual=v.validate(doc,match,c['pilot']);assert actual==c['validation']==load(root/'validation.json')
 assert c['geometry_before']==c['geometry_after']
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,root/folder/key) for key,cmd in c[phase].items())
 for key in c['configuration_before']:assert c['configuration_before'][key]['logs']['stdout']['sha256']==c['configuration_after'][key]['logs']['stdout']['sha256']
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['pins_stable'] and cmd['logs_complete'] and cmd['owned']['terminal'] and cmd['owned']['group_absent']
  for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
  commands+=1
 if not c['pilot']:pairs.setdefault(c['pair'],{})[c['kind']]=actual
assert commands==99 and all(set(p)=={'native','framework'} for p in pairs.values())
summary=load(P/'summary.json');assert summary['native_commands']==11 and summary['probe_commands']==88 and summary['measured_states']==1200 and summary['warmup_states']==1280
for row in summary['runs']:assert row['metrics']==pairs[row['pair']][row['kind']]
for row in summary['differences_of_run_p95_values']:assert row['framework_minus_native_p95_ms']==pairs[row['pair']]['framework']['receipt_to_present_ms']['p95']-pairs[row['pair']]['native']['receipt_to_present_ms']['p95']
assert not summary['release_gate_changed'] and not summary['framework_qualified'] and not summary['cadence_qualified'] and not summary['OS_latency_floor_proven']
for name in ['preparation','pilot1','pilot2','result']:
 index=R/(name+'-evidence-index.json');archive=R/(name+'-evidence.tar.xz')
 if not index.exists():continue
 idx=load(index);assert sha(archive)==idx['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(idx['files'])
  for n,d in idx['files'].items():b=tf.extractfile(n).read();assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
print('PASS: exact five predeclared pairs;1280 warmups+1200 measured states;11 native+88 probe groups retired;all source/binary/SDK8321/match/log pins;strict actual-journal revalidation;exact per-run/paired-quantile arithmetic;configuration/geometry unchanged;within480s;archive integrity;no gate/qualification change')
