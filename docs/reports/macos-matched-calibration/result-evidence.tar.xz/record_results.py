from pathlib import Path
import json,hashlib,tarfile,io
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-matched-calibration')
for name in ['summary.json','phase-analysis.json']:(R/name).write_bytes((P/name).read_bytes())
files={p.relative_to(P).as_posix():p for p in P.rglob('*') if p.is_file() and p.name not in ['native','framework','ready-test'] and 'tmp' not in p.relative_to(P).parts};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(R/'result-evidence.tar.xz','w:xz') as tf:
 for n,p in sorted(files.items()):b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;i.mode=0o644;tf.addfile(i,io.BytesIO(b))
(R/'result-evidence-index.json').write_text(json.dumps({'files':{n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(files.items())},'archive_sha256':sha(R/'result-evidence.tar.xz'),'excluded':['executables','fullSDK','priorarchives'],'source':'committeddiagnostics;originalactualcommands/pins retained'},indent=2)+'\n')
print(json.dumps({'archive_bytes':(R/'result-evidence.tar.xz').stat().st_size,'files':len(files)}))
