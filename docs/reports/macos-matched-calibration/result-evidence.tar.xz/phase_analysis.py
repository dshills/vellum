from pathlib import Path
import json,math
P=Path(__file__).resolve().parent
out=[]
for pair in range(1,6):
 d=json.loads((P/f'pair{pair}-framework/native/stdout').read_text());s=d['before_close'];m=d['measurements']['Samples'][128:];receipts={(x['Scope'],x['Tag']):x['Received'] for x in s['Inputs']};counts=[];cpu=[]
 for row in m:
  f=row['Frame'];t=receipts[row['Scope'],f['Tag']];armed=next(x for x in s['Samples'] if x['Tag']==f['Tag'] and x['Generation']==f['Generation'] and x['Armed']);counts.append(sum(t<=x['Acquired']<armed['Acquired'] and not x['Armed'] for x in s['Samples']));cpu.append(f['TotalUIWorkNS']/1e6)
 cpu.sort();out.append({'pair':pair,'all_acquisitions':len(s['Samples']),'measured_intervening_unarmed_histogram':{str(n):counts.count(n) for n in sorted(set(counts))},'cpu_total_ui_work_ms':{'p50':cpu[59],'p95':cpu[113],'p99':cpu[118],'max':cpu[-1]}})
(P/'phase-analysis.json').write_text(json.dumps({'source':'same actual framework journals; not a new native run','runs':out,'inference_limit':'No intervening unarmed acquisition in 600 measured responses; does not isolate GPU/submit/present timing or observer overhead'},indent=2)+'\n')
