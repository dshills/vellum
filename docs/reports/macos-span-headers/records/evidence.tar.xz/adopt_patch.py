from pathlib import Path
import difflib,hashlib,json
R=Path('/private/tmp/vellum-render-costs');P=Path(__file__).parent;D=R/'drivers/cogent/native/patches/spanheaders';D.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
files={'paint/renderers/sceneplan/builder.go':(P/'original-builder.go',P/'candidate-builder.go'),'paint/renderers/sceneplan/span_headers_vellum_test.go':(None,P/'span_headers_vellum_test.go')}
inputs={};outputs={};patch=[]
for name,(old,new)in files.items():
 original=old.read_bytes()if old else b'';modified=new.read_bytes();inputs[name]=sha(original)if old else None;outputs[name]=sha(modified)
 patch.extend(difflib.unified_diff(original.decode().splitlines(keepends=True),modified.decode().splitlines(keepends=True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
patchfile=D/'0066-bounded-span-header-scratch.patch';patchfile.write_text(''.join(patch))
for name,value in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (D/name).write_text(json.dumps(value,indent=2)+'\n')
manifest=R/'drivers/cogent/native/dependencies.json';data=json.loads(manifest.read_text());data['dependencies'][0]['stages'].append({'origin':'drivers/cogent/native/patches/spanheaders','inputs':'native/patches/spanheaders/original-hashes.json','outputs':'native/patches/spanheaders/output-hashes.json','patches':[{'file':'native/patches/spanheaders/'+patchfile.name,'sha256':sha(patchfile.read_bytes())}]});manifest.write_text(json.dumps(data,indent=2)+'\n')
f=R/'drivers/cogent/prepare_test.py';s=f.read_text();assert s.count('list(range(1, 66))')==1;f.write_text(s.replace('list(range(1, 66))','list(range(1, 67))'))
(D/'README.md').write_text('''# Bounded span header scratch

Owned patch0066 reuses exact power-of-two construction header bands, one each
for sizes1..256, within one sceneplan Builder. The nine slots bound backing to
511 slice headers (12,264 bytes on64-bit); larger/clamped non-power bands bypass
reuse. Active stream operation storage is inline. These are construction costs,
separate from unchanged logical packet admission and exact retained payload.

Reservation remains before borrowing; growth copies row references before
clearing only the old header container. Flush detaches exact packet rows/span
storage before clearing and retaining construction headers. It then clears its
inline operation. Success/refusal Seal drops all scratch and stream references.
No global pool, font/model retention, packet alias or cross-renderer reuse exists.

The unchanged original builder oracles cover state/admission and original/GPU
encodings/pixels. Added tests check bounds, zeroed references, packet isolation,
clamped bands and budget-before-borrow. Software allocation comparisons and
native latency qualification are separate; this patch does not close P6.
''')
print(json.dumps({'patch_sha256':sha(patchfile.read_bytes()),'inputs':inputs,'outputs':outputs}))
