NEEDS_FIX_PROMOTION_PRODUCER. Ten-source checkpoint source/evidence approval is unchanged.

Before canonical mutation, reserve both exclusive preparation logs in one with statement. Current ordering can fail on an existing log only after fetch/merge. Record terminal exceptions as FAILED_CANONICAL_PROMOTION with the original error rather than retaining STARTED. The final sealed-stage audit should bind the corrected producer and verify archive members/index/qualification.

No producer was executed by reviewer. Exact producer hashes are in `producers-review-v1.json`.
