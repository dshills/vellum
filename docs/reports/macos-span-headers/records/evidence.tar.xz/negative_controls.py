from pathlib import Path
import json,subprocess,hashlib
R=Path('/private/tmp/vellum-render-costs');P=Path(__file__).parent;N=P/'negative';N.mkdir(exist_ok=False)
source=R/'drivers/cogent/build/upstream/paint/renderers/sceneplan/builder.go';candidate=source.read_text();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases={
 'header-clear':('clear(headers)','', '^TestVellumSpanHeadersReuseKeepsDetachedPackets$','cached header retained span reference'),
 'growth-transfer':('copy(grown[r.Min.Y-rowMin:], rows[r.Min.Y-b.streamRowMin:r.Max.Y-b.streamRowMin])','b.retainSpanHeaders(rows); copy(grown[r.Min.Y-rowMin:], rows[r.Min.Y-b.streamRowMin:r.Max.Y-b.streamRowMin])','^TestVellumSpanScratchPinnedAdmissionOrderAndPixels$','span state or admission differs'),
 'budget-before-borrow':('if !b.reserve(int(unsafe.Sizeof(span{})) + (size-len(rows))*int(unsafe.Sizeof([]span{}))) {','if grow { b.borrowSpanHeaders(size) }; if !b.reserve(int(unsafe.Sizeof(span{})) + (size-len(rows))*int(unsafe.Sizeof([]span{}))) {','^TestVellumSpanHeadersBudgetPrecedesBorrowAndRetirement$','budget refused after popping/allocating band'),
 'retirement':('b.spanHeaders = [9][][]span{}','','^TestVellumSpanHeadersBudgetPrecedesBorrowAndRetirement$','retired header cache retained ownership'),
 'inline-clear':('b.streamValue = operation{}','','^TestVellumSpanHeadersReuseKeepsDetachedPackets$','flushed inline operation retains references'),
}
manifest={};results={}
for name,(old,new,test,message)in cases.items():
 assert candidate.count(old)==(2 if name=='inline-clear'else 1),(name,candidate.count(old))
 fault=candidate.replace(old,new,1);f=N/(name+'.go');f.write_text(fault);overlay=N/(name+'.json');overlay.write_text(json.dumps({'Replace':{str(source):str(f)}}))
 argv=['python3',str(P/'code_run.py'),'negative-'+name,'drivers/cogent/build/upstream','go','test','-race','-tags','offscreen','-overlay='+str(overlay),'./paint/renderers/sceneplan','-run',test,'-count=1','-timeout=45s','-v']
 run=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);(P/('negative-'+name+'.wrapper.log')).write_bytes(run.stdout)
 receipt=json.loads((P/('negative-'+name+'.json')).read_text());out=(P/('negative-'+name+'.stdout')).read_text()
 intended=run.returncode==1 and receipt['exit_code']==1 and receipt['error']is None and receipt['source_delta_stable'] and receipt['prepared_before']==receipt['prepared_after'] and receipt['overlay_inputs_before']==receipt['overlay_inputs_after'] and message in out and '[build failed]'not in out
 row={'intended_failure':intended,'candidate_sha256':sha(source),'fault_sha256':sha(f),'overlay':str(overlay),'test':test,'expected_diagnostic':message,'receipt_sha256':sha(P/('negative-'+name+'.json'))};results[name]=row;print(name,intended,flush=True)
(P/'negative-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(v['intended_failure']for v in results.values())
