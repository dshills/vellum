The proposed per-Builder inline stream and exact-sized row-header scratch is a sound bounded target for an external prototype. No design blocker found. This is a design review, not implementation or performance approval.

The profile is `profile-top.stdout`: Builder.Span accounts for 24.49% cumulative samples and flush 9.52%; drawGlyphCoverage accounts for 47.62%. The profiling-active local capture reports 31,084 allocations and 5,524,759 B/op. Encoding occurs after the profiled callback, so this profile does not justify encoding changes. Runtime/GC helper samples are included.

Preserve original admission before scratch borrowing, row growth lengths/origins and spare-header refunds. Non-power-of-two target-height clamps must bypass exact power-of-two slots. Growth transfers row references before clearing the old header container; it must not recycle those span buffers. Flush must copy exact detached packet rows/spans before recycling construction backing. Zero the inline operation and all pooled references on retirement, including failed Seal.

Require the pinned original Builder oracle, exact/one-short warm admissions, gapped/descending/odd-height rows, held-packet and append isolation, bounded slot/retirement tests and meaningful faulty variants. Actual software capture pixels/payloads must remain exact. No native, whole-frame or P6 qualification is inferred; user-online live restrictions remain active.

Exact reviewed source and diagnostic hashes are recorded in `design-review.json`.
