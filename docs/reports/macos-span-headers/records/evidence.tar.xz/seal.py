from pathlib import Path
import hashlib,io,json,lzma,tarfile,subprocess
R=Path('/private/tmp/vellum-render-costs');P=Path(__file__).parent;D=R/'docs/reports/macos-span-headers/records';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
summary=json.loads((P/'summary.json').read_text());sources=summary['sources'];review=json.loads((P/'checkpoint-review.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());prism=json.loads((P/'prism-v1/prism.json').read_text());adjudication=json.loads((P/'prism-adjudication.json').read_text());coverage=prism['coverage']
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==sources and not review['unresolved_findings'];assert all(sha(R/n)==h for n,h in sources.items())
assert process['sources']==sources and process['source_index_stable']and process['exit_code']in [0,1]and process['error']is None
assert coverage['complete']and coverage['files']==len(sources)and not coverage['skipped']and coverage['truncatedBytes']==0 and coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert adjudication['sources']==sources and not adjudication['unresolved_findings']and {f['id']for f in prism['findings']}=={f['id']for f in adjudication['findings']}
D.mkdir(exist_ok=False)
omitted={n:{'sha256':sha(P/n),'bytes':(P/n).stat().st_size,'reason':'Private SDK or compiled Mac binary; no native binary launched.'}for n in ['vellum-workbench','vellum-sdk.tar.gz','vellum-sdk-clean.tar.gz']if(P/n).is_file()};(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
excluded={'renderer SDK with spaces','clean renderer SDK with spaces'};files=[f for f in sorted(P.rglob('*'))if f.is_file()and f.relative_to(P).parts[0]not in excluded and f.relative_to(P).as_posix()not in omitted and '__pycache__'not in f.parts];members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
archive=D/'evidence.tar.xz'
with archive.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted,'excluded_extractions':sorted(excluded)};(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**summary,'result':'PASS_SCOPED_SPAN_HEADER_SOFTWARE_CHECKPOINT','checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_process_sha256':sha(P/'prism-v1/process.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_llm_calls':coverage['llmCalls'],'prism_chunks':coverage['chunks'],'prism_raw_exit_code':process['exit_code'],'prism_findings':len(prism['findings']),'prism_unresolved_findings':0,'prism_adjudication_sha256':sha(P/'prism-adjudication.json'),'prism_coverage_complete':True,'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');subprocess.run(['git','add','docs/reports/macos-span-headers/records'],cwd=R,check=True);print(json.dumps({k:q[k]for k in ['result','archive_members','archive_bytes','archive_sha256','prism_findings']}))
