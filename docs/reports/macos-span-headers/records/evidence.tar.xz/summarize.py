from pathlib import Path
import json,hashlib,subprocess
R=Path('/private/tmp/vellum-render-costs');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert base=='dbf273459b8a62e7ecf12d5029123f9a568a96d7'
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines());sources={n:sha(R/n)for n in sorted(names)};assert len(sources)==10
prep=json.loads((P/'prepare-candidate.json').read_text());before=prep['prepared_before'];expected=prep['prepared_after'];assert prep['exit_code']==0 and prep['error']is None and prep['source_delta_stable'] and len(before)==6223 and len(expected)==6224
changed={n for n in before.keys()|expected.keys()if before.get(n)!=expected.get(n)};assert changed=={'upstream/paint/renderers/sceneplan/builder.go','upstream/paint/renderers/sceneplan/span_headers_vellum_test.go'}
allowed=json.loads((P/'renderer-test-outputs.json').read_text())['nonpinned_generated_test_outputs'];assert len(allowed)==17
actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in (R/'drivers/cogent/build'/m).rglob('*')if f.is_file()};assert actual==expected
canonical={f.relative_to(C/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in (C/'drivers/cogent/build'/m).rglob('*')if f.is_file()};assert canonical==before
assert json.loads((P/'test-output-cleanup.json').read_text())['deleted']==allowed
checks={}
def check(name, model, source_bound=True):
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_commit']==base and d['source_delta_stable'] and not d['live_tests'] and not d['headless_gpu_requested'],name
 outputs={}
 for endpoint in ['prepared_before','prepared_after']:
  observed=d[endpoint];assert all(observed.get(n)==h for n,h in model.items()),name
  extras={n:h for n,h in observed.items()if n not in model};assert set(extras)<=set(allowed)and all(allowed[n]==h for n,h in extras.items()),name;outputs[endpoint]=extras
 for channel in ['stdout','stderr']:assert sha(P/(name+'.'+channel))==d[channel+'_sha256']
 assert d['overlay_inputs_before']==d['overlay_inputs_after']
 mismatches={n for n,h in sources.items()if d['source_delta_after'].get(n)!=h}
 if source_bound:assert mismatches<={'docs/reports/macos-span-headers/README.md'},(name,mismatches)
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'pinned_source_exact':True,'generated_nonpinned_outputs':outputs,'current_source_matches':sorted(set(sources)-mismatches),'scope':'Current candidate check'if source_bound else'Historical base prepared source plus declared immutable prototype overlay'}
for name in ['renderer-race-v2','renderer-vet-v2','driver-race','driver-vet','prepare-tests','native-compile','sdk-archive-clean','sdk-relocation-clean','matrix-original','matrix-candidate']:check(name,expected)
pairs=json.loads((P/'paired-summary.json').read_text());assert pairs['pairs']==5 and pairs['packet_bytes_and_pixels_equal'] and not pairs['native_performance_qualified'] and not pairs['profiled']
for mode,rows in pairs['results'].items():
 for row in rows:check(f"pair-{row['pair']}-{mode}",before,False)
assert sha(P/'original-builder.go')==before['upstream/paint/renderers/sceneplan/builder.go'] and sha(P/'candidate-builder.go')==expected['upstream/paint/renderers/sceneplan/builder.go']
negative=json.loads((P/'negative-results.json').read_text());assert len(negative)==5
for name,n in negative.items():
 assert n['intended_failure'] and n['candidate_sha256']==expected['upstream/paint/renderers/sceneplan/builder.go']
 d=json.loads((P/('negative-'+name+'.json')).read_text());assert d['exit_code']==1 and d['error']is None and d['source_delta_stable'] and d['overlay_inputs_before']==d['overlay_inputs_after']
 for endpoint in ['prepared_before','prepared_after']:
  assert all(d[endpoint].get(k)==h for k,h in expected.items())and set(d[endpoint])-set(expected)<=set(allowed)
  assert all(allowed[k]==h for k,h in d[endpoint].items()if k not in expected)
 assert n['expected_diagnostic']in(P/('negative-'+name+'.stdout')).read_text() and sha(P/('negative-'+name+'.json'))==n['receipt_sha256']
matrix=json.loads((P/'matrix-summary.json').read_text());assert matrix['result']=='PASS_EXACT_SOFTWARE_CAPTURE_MATRIX' and matrix['records_per_arm']==24 and len(set(matrix['signatures'].values()))==1
for mode,h in matrix['signatures'].items():assert sha(P/('matrix-'+mode+'-packet.json'))==h
sdk=json.loads((P/'sdk-relocation-clean.stdout').read_text());digest=sha(P/'vellum-sdk-clean.tar.gz');assert sdk['archive_sha256']==digest and sdk['native_runtime']=='not executed' and sdk['digest_verified_against_expected']
reloc=json.loads((P/'relocated-renderer-clean.json').read_text());assert reloc['result']=='PASS_RELOCATED_RENDERER_CODE_CHECKS' and reloc['prepared']==expected and reloc['prepared_exact'] and not reloc['native_binary_executed'] and reloc['archive_sha256']==digest
assert reloc['producer_sha256']==sha(P/'relocated_renderer_clean.py') and set(reloc['generated_test_outputs'])<=set(allowed) and all(allowed[n]==h for n,h in reloc['generated_test_outputs'].items())
for d in reloc['checks']:
 assert d['exit_code']==0
 for channel in ['stdout','stderr']:assert sha(P/('relocated-renderer-clean-'+d['name']+'.'+channel))==d[channel+'_sha256']
summary={'result':'PASS_SCOPED_SPAN_HEADER_SOFTWARE_CHECKS','base_commit':base,'sources':sources,'checks':checks,'prepare_receipt_sha256':sha(P/'prepare-candidate.json'),'prepared_before':before,'prepared_after':expected,'prepared_changed':sorted(changed),'prepared_files':6224,'generated_test_output_manifest_sha256':sha(P/'renderer-test-outputs.json'),'cleanup_sha256':sha(P/'test-output-cleanup.json'),'negative_controls':negative,'allocation_observation':pairs,'matrix':matrix,'relocated_renderer_sha256':sha(P/'relocated-renderer-clean.json'),'sdk_archive_sha256':digest,'native_binary_sha256':sha(P/'vellum-workbench'),'human_online_live_stop_sha256':sha('/private/tmp/vellum-macos-quiet-current/stop-live'),'excluded_authoring_receipts':['renderer-race','renderer-vet','sdk-archive','sdk-relocation','relocated-renderer-v1-failure.txt'],'native_binary_executed':False,'physical_pointer_qualified':False,'gpu_qualified':False,'native_latency_qualified':False,'retained_memory_qualified':False,'public_distribution_qualified':False,'full_mac_qualified':False,'full_P4_qualified':False,'full_P6_qualified':False,'full_P11_qualified':False,'limits':['Fixed400-cell procedural softwarecapture allocation only; local wall times diagnostic on shared computer, not nativeframe acceptance.','Twentyfour original/candidate matrix observations match encodings/accounting/softwarepixels; no nativeGPU execution.','Pinned Go/code inputs remain exact; known upstream test-generated PNGs are separately recorded and absent from clean SDK inputs.','Original4ms p95/6ms p99 native targets remain failed at their historical endpoints; quietmatchednative comparison stillrequired.']}
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':base,'sources':sources},indent=2)+'\n');(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'sources':len(sources),'positive_checks':len(checks),'negative_controls':5,'prepared_files':6224}))
