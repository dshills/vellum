from pathlib import Path
import json,hashlib,importlib.util,sys,time
R=Path('/private/tmp/vellum-render-costs');P=Path(__file__).parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
spec=importlib.util.spec_from_file_location('sdkcheck',R/'scripts/check-sdk.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();archive=P/'vellum-sdk-clean.tar.gz';digest=json.loads((P/'sdk-archive-clean.stdout').read_text())['sha256'];verified=m.verify_archive(archive,digest);sdk=m.extract_verified(archive,P/'clean renderer SDK with spaces',verified)
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
a=prepared(R);b=prepared(sdk);assert len(a)==6224 and a==b
packages=['./paint/renderers/sceneplan','./paint/renderers/rasterx','./paint/renderers/gpuscene'];env={**child_environment(),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2'}
record={'archive_sha256':digest,'producer_sha256':sha(__file__),'prepared':a,'prepared_exact':True,'native_binary_executed':False,'checks':[]};start=time.monotonic()
try:
 for name,argv in [('race',['go','test','-race','-tags','offscreen',*packages,'-count=1','-timeout=180s']),('vet',['go','vet','-tags','offscreen',*packages])]:
  with(P/('relocated-renderer-clean-'+name+'.stdout')).open('xb')as so,(P/('relocated-renderer-clean-'+name+'.stderr')).open('xb')as se:d=run_child(argv,cwd=sdk/'drivers/cogent/build/upstream',env=env,stdout=so,stderr=se,timeout=240)
  record['checks'].append({'name':name,'argv':argv,'exit_code':d.returncode,'stdout_sha256':sha(P/('relocated-renderer-clean-'+name+'.stdout')),'stderr_sha256':sha(P/('relocated-renderer-clean-'+name+'.stderr'))});assert d.returncode==0
 post=prepared(sdk);generated={n:h for n,h in post.items()if n not in a};allowed=json.loads((P/'renderer-test-outputs.json').read_text())['nonpinned_generated_test_outputs'];assert set(generated)<=set(allowed) and all(post[n]==h for n,h in a.items());record['generated_test_outputs']=generated
 for n,h in generated.items():
  f=sdk/'drivers/cogent/build'/n;assert sha(f)==h;f.unlink()
 assert prepared(sdk)==a;record['result']='PASS_RELOCATED_RENDERER_CODE_CHECKS'
finally:
 record['elapsed_seconds']=time.monotonic()-start;(P/'relocated-renderer-clean.json').write_text(json.dumps(record,indent=2)+'\n');print(record.get('result','FAIL'))
