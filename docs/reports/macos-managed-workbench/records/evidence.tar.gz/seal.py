from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path('/private/tmp/vellum-managed-workbench');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-managed-workbench/records'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];review=json.loads((P/'checkpoint-review.json').read_text());summary=json.loads((P/'summary.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE' and review['sources']==sources and not review['unresolved_findings']
assert summary['sources']==sources and summary['result']=='PASS_SCOPED_MANAGED_WORKBENCH_CODE_CHECKS' and not summary['native_binary_executed'] and not summary['full_mac_qualified'] and not summary['full_P9_qualified'] and summary['prepared_files']==6221
assert all(sha(R/n)==h for n,h in sources.items())
prism=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());coverage=prism['coverage'];adjudication=json.loads((P/'prism-adjudication.json').read_text())
assert process['exit_code']==1 and process['error']is None and process['source_index_stable'] and process['sources']==adjudication['pre_provider_sources']
assert adjudication['sources']==sources and not adjudication['unresolved_findings']
assert len(prism['findings'])==2 and {f['id']for f in prism['findings']}=={f['id']for f in adjudication['adjudications']} and all(f['disposition']=='REJECTED_FALSE_POSITIVE'for f in adjudication['adjudications'])
assert coverage['complete'] and coverage['files']==len(sources) and not coverage['excluded'] and not coverage['skipped'] and coverage['truncatedBytes']==0
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert sha(P/'checkpoint-review-v1.json')==process['review_sha256']
D.mkdir(exist_ok=False)
omitted={'window-cycle-smoke':{'sha256':sha(P/'window-cycle-smoke'),'bytes':(P/'window-cycle-smoke').stat().st_size,'reason':'Compiled Mac native fixture; never executed. Binary omitted from source archive.'}}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[f for f in sorted(P.rglob('*'))if f.is_file() and f.relative_to(P).as_posix()not in omitted and '__pycache__'not in f.parts]
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
archive=D/'evidence.tar.gz'
with archive.open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted}
(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**summary,'result':'PASS_SCOPED_MANAGED_WORKBENCH_CHECKPOINT','checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_llm_calls':coverage['llmCalls'],'prism_chunks':coverage['chunks'],'prism_raw_exit_code':1,'prism_findings':2,'prism_false_positives':2,'prism_unresolved_findings':0,'prism_adjudication_sha256':sha(P/'prism-adjudication.json'),'prism_source_version':'pre-provider hashes in sealed adjudication; final guard clarification and shutdown regression reviewed internally','prism_coverage_complete':True,'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
subprocess.run(['git','add','docs/reports/macos-managed-workbench/records'],cwd=R,check=True)
print(json.dumps({'result':q['result'],'members':len(members),'archive_bytes':index['archive_bytes'],'archive_sha256':index['archive_sha256'],'prism_llm_calls':coverage['llmCalls']}))
