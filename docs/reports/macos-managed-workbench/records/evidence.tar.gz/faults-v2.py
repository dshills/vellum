from pathlib import Path
import hashlib,json
R=Path('/private/tmp/vellum-managed-workbench');P=Path('/private/tmp/vellum-macos-managed-workbench')
def emit(name,file,old,new,test):
 source=(R/file).read_text();assert source.count(old)==1,(name,source.count(old))
 target=P/('fault-v2-'+name+'.go');target.write_text(source.replace(old,new,1))
 overlay=P/('fault-v2-'+name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(R/file):str(target)}},indent=2)+'\n')
 return {'name':name,'file':file,'source_sha256':hashlib.sha256((R/file).read_bytes()).hexdigest(),'overlay':str(overlay),'test':test}
faults=[]
faults.append(emit('tab-owner','drivers/cogent/workbench.go','return w.Workspace.Activate(g.ID, id)','return nil','TestManualWorkbenchRoutedTabsAcrossBatches'))
faults.append(emit('scope-aba','drivers/cogent/workbench_scope.go','if !origin.allowed() || !w.inputScope.Load().allowed() {','if !w.inputScope.Load().allowed() {','TestManualWorkbenchQueuedInputScopeRevocation'))
faults.append(emit('double-close','drivers/cogent/manual_offscreen.go','if w.domain.Err() == nil {','if true {','TestManualWorkbenchGroupIndependentWindowsAndExplicitPolicies'))
faults.append(emit('duplicate-factory','drivers/cogent/workbench.go','n, ok = w.manualViews[p.ID]','n, ok = p.View(), true','TestManualWorkbenchRoutedTabsAcrossBatches'))
faults.append(emit('owner-closed','drivers/cogent/manual_offscreen.go','err != nil && !errors.Is(err, app.ErrClosed) {','err != nil {','TestManualWorkbenchOwnerClosedBeforeSceneClose'))
(P/'faults-v2.json').write_text(json.dumps(faults,indent=2)+'\n')
print(json.dumps(faults))
