Both Prism findings are REJECTED_FALSE_POSITIVE on the source. Raw exit 1, two findings and complete 19-file/seven-call review remain preserved.

2787d2b6dd38cb7f: the exact pre-provider file already filters app.ErrClosed in p.fail; reversing the explicit OnClose clarification reproduces its recorded SHA256. The new guard and regression add clarity/coverage, not a demonstrated behavioral fix.

a372e4cec4a46c83: every production row receives a nonempty TreeDisclosureID; leaves clear only disclosure bounds. Manual emits actual disclosure elements only when HasChildren and nonempty bounds permit it.

No unresolved source finding. Post-change gates/counterexample remain pending and need final evidence review. No provider rerun or GUI/native/test execution by reviewer.
