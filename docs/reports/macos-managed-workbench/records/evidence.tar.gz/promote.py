from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-managed-workbench');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-managed-workbench')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
q=json.loads((R/'docs/reports/macos-managed-workbench/records/qualification.json').read_text());final=json.loads((P/'final-review.json').read_text())
assert q['result']=='PASS_SCOPED_MANAGED_WORKBENCH_CHECKPOINT'and final['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not final['unresolved_findings']
assert q['prism_unresolved_findings']==0 and q['prism_false_positives']==2 and q['prism_raw_exit_code']==1 and q['prism_coverage_complete'] and not q['native_binary_executed'] and not q['full_mac_qualified'] and not q['full_P9_qualified']
base=q['base_commit'];commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
assert not git(R,'status','--porcelain')and not git(C,'status','--porcelain')and git(C,'rev-parse','HEAD')==base
changed=set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines());expected_changed=set(q['sources'])|{'docs/reports/macos-managed-workbench/records/'+n for n in ['qualification.json','evidence.tar.gz','archive-index.json']};assert changed==expected_changed and len(changed)==22
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,raw_name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/raw_name.decode();assert kind=='blob'and path.is_file()and not path.is_symlink();content=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==oid,raw_name.decode()
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert all(expected[n]==h for n,h in q['sources'].items())and final['sources']=={n:expected[n]for n in expected_changed}
wanted=prepared(R);assert len(wanted)==6221 and prepared(C)==wanted
O.mkdir(parents=True,exist_ok=True);start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'changed_files':sorted(changed),'scope':'Bounded built-in Workbench software replay and common dock input owner/lifetime fixes. No native launch, physical input, performance or full-P9/Mac qualification.'}
# Reserve a durable attempt record before canonical mutation.
reservation=O/'canonical-promotion.json';reservation.open('x').close()
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 actual=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_files':len(expected),'tracked_exact':set(actual)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_files':6221,'prepared_exact':prepared(C)==wanted,'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'archive_sha256':sha(C/'docs/reports/macos-managed-workbench/records/evidence.tar.gz'),'final_review_sha256':sha(P/'final-review.json')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean'])and record['archive_sha256']==q['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
except BaseException as error:
 record['result']='FAILED_CANONICAL_PROMOTION';record['error']={'type':type(error).__name__,'message':str(error)}
 raise
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');reservation.write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
