//go:build offscreen

package cogent

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"testing"

	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/workbench"
)

func manualDockFixture(t *testing.T, batch int) (*Manual, *app.Application, *Workbench, map[string]string) {
	t.Helper()
	a, err := app.New(app.Config{QueueCapacity: 16})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(a.Close)
	model, err := workbench.New(workbench.Layout{Version: workbench.Version, Root: &workbench.Group{ID: "documents", Tabs: []string{"left", "right"}, Active: "left"}}, []string{"left", "right"})
	if err != nil {
		t.Fatal(err)
	}
	dock := &Workbench{Owner: a, Window: "one", Workspace: model}
	values := map[string]string{"left": "Left", "right": "Right"}
	calls := map[string]int{}
	for _, panel := range []string{"left", "right"} {
		panel := panel
		dock.Panels = append(dock.Panels, Panel{ID: panel, Title: panel, View: func() ui.Node {
			calls[panel]++
			return ui.Node{ID: "page", Kind: ui.Column, Grow: true, Children: []ui.Node{{ID: "name", Kind: ui.TextField, Text: values[panel], Accessibility: ui.Accessibility{Name: panel + " name"}, Change: func(e ui.ChangeEvent) { values[panel] = e.Text; a.Invalidate("one") }}}}
		}})
	}
	if err = a.Open(app.Window{ID: "one", Title: "Dock replay", Width: 900, Height: 620, View: func() ui.Node { return ui.Node{ID: "dock", Kind: ui.Extension, Custom: dock, Grow: true} }}); err != nil {
		t.Fatal(err)
	}
	m, err := NewManual(testContext, a, manualConfig(t, batch))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := m.Close(testContext); err != nil {
			t.Error(err)
		}
	})
	if calls["left"] != 1 || calls["right"] != 1 {
		t.Fatalf("panel factory evaluated more than once during initial reconciliation: %v", calls)
	}
	if dock.manualViews != nil {
		t.Fatal("captured panel views retained")
	}
	manualDockSettle(t, m, batch)
	return m, a, dock, values
}

func manualDockSettle(t *testing.T, m *Manual, batch int) {
	t.Helper()
	for range 4096 {
		s, err := m.Snapshot(testContext)
		if err != nil {
			t.Fatal(err)
		}
		ready := s.Application.Ordinary+s.Application.ReadyCompletions > 0
		for _, w := range s.Windows {
			ready = ready || w.Events > 0 || w.ReadyPaint
			if !ready && w.LayoutPending {
				if err = m.RequestFrame(testContext, w.ID); err != nil {
					t.Fatal(err)
				}
				ready = true
			}
		}
		if !ready {
			return
		}
		work, err := m.Step(testContext, batch)
		if err != nil {
			t.Fatal(err)
		}
		if work.Events+work.OwnerCallbacks > batch {
			t.Fatal("dispatch budget exceeded", work)
		}
	}
	t.Fatal("dock did not settle within explicit dispatch budget")
}

func manualDockElement(t *testing.T, m *Manual, window, id string) (ManualWindowSnapshot, ManualElement) {
	t.Helper()
	s, err := m.Snapshot(testContext)
	if err != nil {
		t.Fatal(err)
	}
	for _, w := range s.Windows {
		if w.ID == window {
			for _, e := range w.Elements {
				if e.ID == id {
					return w, e
				}
			}
		}
	}
	t.Fatalf("missing dock target %q in %q", id, window)
	return ManualWindowSnapshot{}, ManualElement{}
}
func manualDockClick(t *testing.T, m *Manual, batch int, window, id string) {
	t.Helper()
	w, e := manualDockElement(t, m, window, id)
	if !e.Visible || e.Bounds.Empty() || e.Incarnation == 0 {
		t.Fatalf("invalid routed target: %+v", e)
	}
	for _, event := range []events.Types{events.MouseDown, events.MouseUp} {
		if err := m.Input(testContext, ManualInput{Window: window, WindowIncarnation: w.Incarnation, Target: id, TargetIncarnation: e.Incarnation, Type: event, Button: events.Left}); err != nil {
			t.Fatal(err)
		}
	}
	manualDockSettle(t, m, batch)
}

func TestManualWorkbenchRoutedTabsAcrossBatches(t *testing.T) {
	var oracle []byte
	for _, batch := range []int{1, 7, 64} {
		t.Run(fmt.Sprint(batch), func(t *testing.T) {
			m, _, dock, values := manualDockFixture(t, batch)
			leftID := accessibilityWorkbenchNamespace("dock", "left") + "name"
			rightID := accessibilityWorkbenchNamespace("dock", "right") + "name"
			w, left := manualDockElement(t, m, "one", leftID)
			_, right := manualDockElement(t, m, "one", rightID)
			if !left.Visible || right.Visible || left.Incarnation == 0 || right.Incarnation == 0 || left.ID == right.ID {
				t.Fatal("panel namespace/visibility missing", left, right)
			}
			if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.Incarnation, Target: rightID, TargetIncarnation: right.Incarnation, Type: events.MouseDown, Button: events.Left}); !errors.Is(err, ErrManualDisabled) {
				t.Fatal("inactive panel admitted", err)
			}
			manualDockClick(t, m, batch, "one", leftID)
			w, _ = manualDockElement(t, m, "one", leftID)
			for _, input := range []ManualInput{{Type: events.KeyChord, Code: key.CodeA, Modifiers: key.Meta}, {Type: events.KeyChord, Rune: 'Z', Code: key.CodeZ}, {Type: events.KeyChord, Code: key.CodeEnter}} {
				input.Window = "one"
				input.WindowIncarnation = w.Incarnation
				if err := m.Input(testContext, input); err != nil {
					t.Fatal(err)
				}
				manualDockSettle(t, m, batch)
			}
			if values["left"] != "Z" || values["right"] != "Right" {
				t.Fatal("actual field route did not edit only left", values)
			}
			manualDockClick(t, m, batch, "one", accessibilityDockOptionID("dock", "right"))
			if dock.Workspace.Layout().Root.Active != "right" {
				t.Fatal("native tab input bypassed or failed owner transition")
			}
			_, hidden := manualDockElement(t, m, "one", leftID)
			_, visible := manualDockElement(t, m, "one", rightID)
			if hidden.Visible || !visible.Visible || hidden.Incarnation != left.Incarnation || visible.Incarnation != right.Incarnation {
				t.Fatal("hidden records lost identity or visibility", hidden, visible)
			}
			image, err := m.Capture(testContext, "one")
			if err != nil {
				t.Fatal(err)
			}
			digest := sha256.Sum256(image.Pix)
			s, err := m.Snapshot(testContext)
			if err != nil {
				t.Fatal(err)
			}
			elements := s.Windows[0].Elements
			for i := range elements {
				elements[i].Incarnation = 0
			}
			state := struct {
				Values   map[string]string
				Elements []ManualElement
				Image    string
			}{values, elements, hex.EncodeToString(digest[:])}
			data, err := json.Marshal(state)
			if err != nil {
				t.Fatal(err)
			}
			if oracle == nil {
				oracle = data
			} else if !reflect.DeepEqual(oracle, data) {
				t.Fatal("dock model/geometry/semantics/image changed with batching")
			}
		})
	}
}

func TestManualWorkbenchRefusesWholeHostedGraphBeforeMount(t *testing.T) {
	for _, variant := range []string{"inactive-extension", "recursive", "budget", "foreign-owner"} {
		t.Run(variant, func(t *testing.T) {
			a, err := app.New(app.Config{})
			if err != nil {
				t.Fatal(err)
			}
			defer a.Close()
			model, err := workbench.New(workbench.Layout{Version: workbench.Version, Root: &workbench.Group{ID: "documents", Tabs: []string{"left", "right"}, Active: "left"}}, []string{"left", "right"})
			if err != nil {
				t.Fatal(err)
			}
			dock := &Workbench{Owner: a, Window: "one", Workspace: model}
			dock.Panels = []Panel{{ID: "left", Title: "Left", View: func() ui.Node { return ui.Node{ID: "name", Kind: ui.Label} }}, {ID: "right", Title: "Right", View: func() ui.Node { return ui.Node{ID: "name", Kind: ui.Label} }}}
			config := manualConfig(t, 7)
			switch variant {
			case "inactive-extension":
				dock.Panels[1].View = func() ui.Node { return ui.Node{ID: "unsafe", Kind: ui.Extension, Custom: struct{}{}} }
			case "recursive":
				dock.Panels[1].View = func() ui.Node { return ui.Node{ID: "recursive", Kind: ui.Extension, Custom: dock} }
			case "budget":
				config.MaxControls = 4
			case "foreign-owner":
				dock.Window = "other"
			}
			if err = a.Open(app.Window{ID: "one", Title: "refusal", Width: 500, Height: 400, View: func() ui.Node { return ui.Node{ID: "dock", Kind: ui.Extension, Custom: dock} }}); err != nil {
				t.Fatal(err)
			}
			m, err := NewManual(testContext, a, config)
			if m != nil || err == nil {
				if m != nil {
					m.Close(testContext)
				}
				t.Fatal("unsafe dock graph admitted")
			}
			if dock.host != nil || len(dock.records) != 0 || dock.manualViews != nil || a.Context().Err() != nil || len(a.Windows()) != 1 {
				t.Fatal("refusal mounted or damaged domain")
			}
		})
	}
}
