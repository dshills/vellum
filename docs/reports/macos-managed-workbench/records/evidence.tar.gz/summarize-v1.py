from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-managed-workbench');P=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
names=sorted(set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()))
assert len(names)==19,names
sources={n:sha(R/n) for n in names};production={n:h for n,h in sources.items() if n.endswith('.go') and not n.endswith('_test.go')}
checks={}
prepared=None
for name in ['adapter-race-v2','replay-race-v1','root-race-v1','adapter-vet-v1','native-build-v1','sdk-tests-v1']:
 d=json.loads((P/(name+'.json')).read_text())
 assert d['exit_code']==0 and d['error']is None and d['source_delta_stable'] and d['prepared_before']==d['prepared_after'] and d['mode']=='code' and not d['live_tests'] and not d['headless_gpu_requested'],name
 assert all(d['source_delta_after'].get(n)==h for n,h in production.items()),name
 assert all(sha(P/(name+'.'+s))==d[s+'_sha256'] for s in ['stdout','stderr']),name
 assert len(d['prepared_after'])==6221
 if prepared is None:prepared=d['prepared_after']
 assert prepared==d['prepared_after'],name
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'source_delta':d['source_delta_after'],'prepared_files':len(prepared)}
assert {n:h for n,h in json.loads((P/'adapter-race-v2.json').read_text())['source_delta_after'].items() if n!='docs/reports/macos-managed-workbench/README.md'}=={n:h for n,h in sources.items() if n!='docs/reports/macos-managed-workbench/README.md'}
faults=[]
markers={'tab-owner':'native tab input bypassed or failed owner transition','scope-aba':'old gesture survived scope revocation and reactivation','double-close':'vellum: unknown window','duplicate-factory':'panel factory evaluated more than once during initial reconciliation'}
for fault in json.loads((P/'faults.json').read_text()):
 name='fault-'+fault['name'];d=json.loads((P/(name+'.json')).read_text());out=(P/(name+'.stdout')).read_text()
 assert d['exit_code']==1 and d['error']is None and d['source_delta_stable'] and d['prepared_after']==prepared and d['prepared_before']==prepared and d['overlay_inputs_before']==d['overlay_inputs_after']
 assert markers[fault['name']]in out and '[build failed]'not in out and 'WARNING: DATA RACE'not in out
 assert all(sha(P/(name+'.'+s))==d[s+'_sha256'] for s in ['stdout','stderr'])
 assert sources[fault['file']]==fault['source_sha256']
 faults.append({**fault,'result':'REJECTED_EXPECTED_DEFECT','receipt_sha256':sha(P/(name+'.json')),'assertion':markers[fault['name']]})
actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*')) if f.is_file()};assert actual==prepared
prior={}
for f in sorted(P.glob('*.json')):
 try:d=json.loads(f.read_text())
 except:continue
 if isinstance(d,dict) and 'argv'in d and f.stem not in checks and not f.stem.startswith('fault-'):
  prior[f.name]={'sha256':sha(f),'exit_code':d['exit_code'],'error':d['error'],'not_final_qualification':True}
summary={'result':'PASS_SCOPED_MANAGED_WORKBENCH_CODE_CHECKS','base_commit':base,'sources':sources,'checks':checks,'fault_controls':faults,'diagnostic_attempts':prior,'prepared_files':len(prepared),'prepared_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True).encode()).hexdigest(),'native_binary_sha256':sha(P/'window-cycle-smoke'),'native_binary_executed':False,'live_tests':False,'full_mac_qualified':False,'full_P9_qualified':False,'limits':['Offscreen software routing and measured images only; no native GPU/GUI/OS tests or physical pointer evidence.','Control+A follows the explicit offscreen keymap, not physical Mac shortcut qualification.','Scope ABA tests isolate actual widget listeners while retaining distinct routed positives.','Group lifetime IDs are resolved by logical aliases; no independently versioned large workspace record.','Canvas/GPU, worker-built views/cancellation, professional P9/P11, native performance/memory/lifecycle, physical input/accessibility, idle/overnight and distribution remain open.'],'notes':['adapter-race-v1 found existing Control+Left fixture expected admission; updated fixture to require context-menu refusal with no queue/owner/state mutation.','All earlier diagnostic failures are retained; only selected final passing receipts qualify this checkpoint.']}
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':base,'sources':sources},indent=2)+'\n')
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
subprocess.run(['git','add','--',*names],cwd=R,check=True)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
print(json.dumps({'result':summary['result'],'files':len(sources),'checks':len(checks),'defects':len(faults),'prepared_files':len(prepared)}))
