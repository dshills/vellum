from pathlib import Path
import hashlib,subprocess
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def identity(root):
 names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if n]
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=root),'tracked':{n:sha(root/n)for n in names},'prepared':{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
