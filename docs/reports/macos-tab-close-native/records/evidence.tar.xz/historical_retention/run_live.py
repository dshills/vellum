"""Owned native fixture with stop-file cancellation and a recorded child handle."""
from pathlib import Path
import datetime,json,os,signal,subprocess,sys,time
from run import R,P,sha,baseline,identity
from sdk_environment import child_environment
name,relative,seconds=sys.argv[1:4];argv=sys.argv[4:];assert argv and Path(argv[0]).parent==P
before=baseline();timeout=float(seconds);assert 0<timeout<=11100
assert json.loads((P/'testing-authorization.json').read_text())['live_window_input_performance_tests_allowed']
d={'argv':argv,'mode':'live','cwd':str(R/relative),'source_commit':before['commit'],'baseline_sha256':sha(P/'baseline.json'),'producer_sha256':sha(__file__),'authorization_sha256':sha(P/'testing-authorization.json'),'executable_sha256':sha(argv[0]),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':timeout,'exit_code':None,'error':None};start=time.monotonic();child=None
try:
 assert not (P/'stop-live').exists(),'human returned; native campaign stopped'
 with(P/(name+'.stdout')).open('xb') as so,(P/(name+'.stderr')).open('xb') as se:
  child=subprocess.Popen(argv,cwd=R/relative,env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
  (P/(name+'.owned-process.json')).write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'argv':argv,'executable_sha256':d['executable_sha256'],'started_utc':d['started_utc'],'owner_pid':os.getpid()},indent=2)+'\n')
  while child.poll() is None:
   if (P/'stop-live').exists():raise InterruptedError('human returned; stop-live requested')
   if time.monotonic()-start>timeout:raise TimeoutError('owned native fixture watchdog expired')
   time.sleep(.25)
  d['exit_code']=child.returncode
except BaseException as e:
 d['error']={'type':type(e).__name__,'message':str(e)}
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
  d['exit_code']=child.returncode
finally:
 d['elapsed_seconds']=time.monotonic()-start;d['source_prepared_stable']=identity()==before
 for c in ['stdout','stderr']:
  f=P/(name+'.'+c);d[c+'_sha256']=sha(f) if f.exists() else None
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
sys.exit(0 if d['exit_code']==0 and not d['error'] and d['source_prepared_stable'] else 1)
