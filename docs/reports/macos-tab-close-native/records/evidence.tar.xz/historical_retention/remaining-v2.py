"""Continue after validated preflight; preserve the earlier metadata failure."""
from pathlib import Path
import datetime,json,subprocess
P=Path('/private/tmp/vellum-macos-quiet-current');q=json.loads((P/'preflight-summary.json').read_text());assert q['result']=='PASS_FIVE_INTERACTING_PREFLIGHT_CYCLES' and q['cycles']==5 and q['actions']==120
for stage,args in [
 ('endurance',['python3',str(P/'run_live.py'),'interacting-1000','drivers/cogent','11100',str(P/'window-cycle'),'-composed','-cycles=1000','-sample-every=25','-timeout=3h','-heap-profile='+str(P/'final.heap')]),
 ('endurance-validation',['python3',str(P/'validate_retention.py'),'full'])]:
 assert not (P/'stop-live').exists(),'native campaign stopped before '+stage
 (P/'queue-stage-v2.json').write_text(json.dumps({'stage':stage,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':args},indent=2)+'\n');print('Starting',stage,flush=True);subprocess.run(args,check=True)
(P/'queue-completed-v2.json').write_text(json.dumps({'result':'COMPLETED_CURRENT_NATIVE_CAMPAIGN','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
