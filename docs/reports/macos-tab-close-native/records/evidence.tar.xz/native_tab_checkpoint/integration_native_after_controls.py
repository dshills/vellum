"""Run current-renderer tab acceptance after the reviewed progress fixture reaps."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

R = Path('/private/tmp/vellum-tabs-integration')
P = Path('/private/tmp/vellum-macos-tab-close-native')
G = Path('/private/tmp/vellum-macos-progress-controls')
Q = Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0, str(R / 'scripts'))
from sdk_environment import child_environment

def sha(f):
    return hashlib.sha256(Path(f).read_bytes()).hexdigest()

def read(f):
    return json.loads(Path(f).read_text())

def identity():
    names = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=R).decode().split('\0'))
    names.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=R).decode().split('\0'))
    names.discard('')
    return {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip(), 'sources': {n: sha(R / n) for n in sorted(names)}, 'prepared': {f.relative_to(R / 'drivers/cogent/build').as_posix(): sha(f) for m in ['upstream', 'typesetting'] for f in sorted((R / 'drivers/cogent/build' / m).rglob('*')) if f.is_file()}}

def stopped():
    return (Q / 'stop-live').exists()

def clean(c):
    return c['MainThread'] and c['CleanupObserved'] and c['CallbacksStopped'] and c['PendingCallbacks'] == c['NativeOutstanding'] == c['AccessibilityWindows'] == 0 and not c['WindowTitles']

review = read(P / 'integration-queue-review.json')
assert review['result'] == 'APPROVED_INTEGRATION_QUEUE' and not review['unresolved_findings']
assert review['producer_sha256'] == sha(__file__)
source = read(P / 'integration-source.json')
assert review['sources'] == source['sources']
assert all(sha(R / n) == h for n, h in source['sources'].items())
before = identity()
assert before['commit'] == source['base_commit'] and before['prepared'] == source['prepared'] and len(before['prepared']) == 6211
build = read(P / 'integration-native-build.json')
binary = read(P / 'integration-native-binary.json')
exe = P / 'tab-close-smoke-integrated'
assert build['exit_code'] == 0 and build['error'] is None and build['source_delta_stable']
assert build['source_commit'] == before['commit'] and build['prepared_before'] == build['prepared_after'] == before['prepared']
assert all(build['source_delta_before'][n] == build['source_delta_after'][n] == h for n, h in source['sources'].items())
assert all(binary[k] == v for k, v in build.items())
assert binary['produced_file'] == str(exe) and binary['produced_file_sha256'] == sha(exe) and binary['produced_file_bytes'] == exe.stat().st_size
assert read(Q / 'testing-authorization.json')['live_window_input_performance_tests_allowed']
(P / 'integration-runtime-baseline.json').write_text(json.dumps(before, indent=2) + '\n')
deadline = time.monotonic() + 18000
while not (G / 'native-summary.json').exists():
    if stopped():
        raise InterruptedError('human returned; do not launch native tab integration')
    if time.monotonic() > deadline:
        raise TimeoutError('progress native summary missing')
    time.sleep(2)
prior = read(G / 'native-summary.json')
prior_run = read(G / 'native-progress.json')
assert prior['result'] == 'PASS_SCOPED_NATIVE_PROGRESS_SHAPES' and prior['native_cleanup_zero']
assert prior['receipt_sha256'] == sha(G / 'native-progress.json')
assert prior_run['exit_code'] == 0 and prior_run['error'] is None and prior_run['source_prepared_stable'] and prior_run['binary_stable']
tabs = read(P / 'native-summary.json')
assert tabs['result'] == 'PASS_SCOPED_NATIVE_TAB_CLOSE_WITH_TWO_DETECTED_FAULTS'
assert tabs['source_review_sha256'] == sha(P / 'source-review-v3.json')
assert tabs['runtime_baseline_sha256'] == sha(P / 'runtime-baseline.json')
assert set(tabs['checks']) == {'native-tabs', 'negative-checkbox', 'negative-selection'}
for name, check in tabs['checks'].items():
    assert check['native_cleanup_zero'] and check['receipt_sha256'] == sha(P / (name + '.json'))
assert identity() == before and not stopped()
assert binary['produced_file_sha256'] == sha(exe) and binary['produced_file_bytes'] == exe.stat().st_size
d = {'argv': [str(exe)], 'source_commit': before['commit'], 'runtime_baseline_sha256': sha(P / 'integration-runtime-baseline.json'), 'source_review_sha256': sha(P / 'source-review-v3.json'), 'queue_review_sha256': sha(P / 'integration-queue-review.json'), 'producer_sha256': sha(__file__), 'build_receipt_sha256': sha(P / 'integration-native-build.json'), 'binary_receipt_sha256': sha(P / 'integration-native-binary.json'), 'binary_sha256': sha(exe), 'predecessor_summary_sha256': sha(G / 'native-summary.json'), 'predecessor_receipt_sha256': sha(G / 'native-progress.json'), 'original_native_summary_sha256': sha(P / 'native-summary.json'), 'authorization_sha256': sha(Q / 'testing-authorization.json'), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': None, 'error': None}
child = None
start = time.monotonic()
try:
    with (P / 'integration-native.stdout').open('xb') as so, (P / 'integration-native.stderr').open('xb') as se:
        child = subprocess.Popen(d['argv'], cwd=R / 'drivers/cogent', env=child_environment(runtime=True), stdout=so, stderr=se, start_new_session=True)
        (P / 'integration-native.owned-process.json').write_text(json.dumps({'pid': child.pid, 'process_group': child.pid, 'owner_pid': os.getpid(), 'argv': d['argv'], 'binary_sha256': d['binary_sha256']}, indent=2) + '\n')
        while child.poll() is None:
            if stopped():
                raise InterruptedError('human returned; stop native tab integration')
            if time.monotonic() - start > 95:
                raise TimeoutError('native tab integration watchdog expired')
            time.sleep(.25)
        d['exit_code'] = child.returncode
except BaseException as error:
    d['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    if child is not None:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=5)
        d['exit_code'] = child.returncode
    d['elapsed_seconds'] = time.monotonic() - start
    d['source_prepared_stable'] = identity() == before
    d['binary_stable'] = binary['produced_file_sha256'] == sha(exe) and binary['produced_file_bytes'] == exe.stat().st_size
    for c in ['stdout', 'stderr']:
        f = P / ('integration-native.' + c)
        d[c + '_sha256'] = sha(f) if f.exists() else None
    (P / 'integration-native.json').write_text(json.dumps(d, indent=2) + '\n')
    print(json.dumps(d), flush=True)
assert d['exit_code'] == 0 and d['error'] is None and d['source_prepared_stable'] and d['binary_stable']
records = [json.loads(line) for line in (P / 'integration-native.stdout').read_text().splitlines() if line.startswith('{')]
results = [r for r in records if r.get('event') == 'vellum.tab-close.result']
assert len(results) == 1 and results[0]['result'] == 'PASS_NATIVE_TAB_CLOSE' and clean(results[0]['native_cleanup'])
complete = [r for r in records if r.get('event') == 'vellum.tab-close.completed']
assert len(complete) == 1 and complete[0]['close_requests'] == 6 and complete[0]['native_text_edits'] == complete[0]['native_decision_changes'] == 1 and complete[0]['selection_callbacks'] == 0
steps = [r for r in records if r.get('event') == 'vellum.tab-close.step']
assert len(steps) == 8 and all(r['passed'] for r in steps)
assert [r['stage'] for r in steps] == ['native-draft', 'reject-b', 'reject-a', 'acceptance-enabled', 'accept-nonselected', 'accept-last', 'accept-selected', 'accept-final-reopened']
(P / 'integration-native-summary.json').write_text(json.dumps({'result': 'PASS_CURRENT_RENDERER_NATIVE_TAB_ACCEPTANCE', 'source_commit': before['commit'], 'prepared_files': 6211, 'receipt_sha256': sha(P / 'integration-native.json'), 'runtime_baseline_sha256': sha(P / 'integration-runtime-baseline.json'), 'steps': 8, 'close_requests': 6, 'native_cleanup_zero': True, 'prior_fault_controls_scope': 'Exact same fixture source on 4cf9e36 with6209prepared leaves; not rerun on current renderer.', 'physical_input_qualified': False, 'human_voiceover_qualified': False, 'full_p6_qualified': False, 'full_p11_qualified': False}, indent=2) + '\n')
print('Completed current-renderer native tab integration', flush=True)
