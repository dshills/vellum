from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-tabs-integration');P=Path('/private/tmp/vellum-macos-tab-close-native')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
out=P/'prism-v1';out.mkdir(exist_ok=False)
internal=json.loads((P/'combined-internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not internal['unresolved_findings']
sources=json.loads((P/'combined-checkpoint-source.json').read_text())['sources'];assert internal['sources']==sources;assert len(sources)==10 and all(sha(R/n)==h for n,h in sources.items())
diff=subprocess.check_output(['git','diff','--cached','--binary','--',*sources],cwd=R);assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).decode().splitlines())==set(sources)
(out/'staged.diff.txt').write_bytes(diff);(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Native tab acceptance fixture on current4c0df93 with6214 pinned leaves. Eight real Cocoa stages, six owner close requests, one draft edit/checkbox decision, zero unintended selection; cleanupzero. Model race/vet/nativebuild pass. Same executable source earlier4cf positive+two detected faults separately scoped;68c/3a positives retained. Actual action selectors do not qualify physicalinput/humanVoiceOver/performance/retention/fullMac. Ten source/spec/report files only, no bulk evidence/binaries.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary','--',*sources],cwd=R)
receipt={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'before':sources,'after':after,'source_index_stable':sources==after and diff==afterdiff,'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None,'producer_sha256':sha(__file__)};(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PRISM',code,'stable',receipt['source_index_stable'],'seconds',round(receipt['elapsed_seconds'],1),flush=True)
sys.exit(code if error is None and receipt['source_index_stable']else 125)
