"""Run reviewed Cocoa tab fixtures sequentially after the owned endurance child exits."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
R=Path('/private/tmp/vellum-tabs-native');P=Path('/private/tmp/vellum-macos-tab-close-native');Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment

def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def identity():
 names={n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0') if n}|{n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().split('\0') if n}
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':{n:sha(R/n) for n in sorted(names)},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting'] for f in sorted((R/'drivers/cogent/build'/m).rglob('*')) if f.is_file()}}
def clean(c):return c['MainThread'] and c['CleanupObserved'] and c['CallbacksStopped'] and c['PendingCallbacks']==c['NativeOutstanding']==c['AccessibilityWindows']==0 and not c['WindowTitles']
def canceled():return (Q/'stop-live').exists()
review=json.loads((P/'source-review-v2.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'];assert all(sha(R/n)==h for n,h in review['sources'].items());before=identity();assert len(before['prepared'])==6209
assert json.loads((Q/'testing-authorization.json').read_text())['live_window_input_performance_tests_allowed']
(P/'runtime-baseline.json').write_text(json.dumps(before,indent=2)+'\n')
# The terminal receipt is emitted only after run_live has reaped its owned child.
predecessor=Q/'interacting-1000.json';deadline=time.monotonic()+11200
while not predecessor.exists():
 if canceled():raise InterruptedError('human returned; do not launch further native fixtures')
 if time.monotonic()>=deadline:raise TimeoutError('endurance terminal receipt missing')
 time.sleep(2)
prior=json.loads(predecessor.read_text());assert prior['exit_code'] is not None and not prior['error'] and prior['source_prepared_stable']
records=[json.loads(l) for l in (Q/'interacting-1000.stdout').read_text().splitlines() if l.startswith('{')];ends=[r for r in records if r.get('event')=='vellum.window-cycle.result'];assert len(ends)==1 and clean(ends[0]['native_cleanup']),'predecessor native teardown unconfirmed'
checks={}
for name,binary,build_name,expected_stage,expected_message in [
 ('native-tabs','tab-close-smoke','candidate-native-build',None,None),
 ('negative-checkbox','tab-close-fault-checkbox','fault-checkbox-build','acceptance-enabled','context deadline exceeded'),
 ('negative-selection','tab-close-fault-selection','fault-selection-build','reject-b','unexpected callback counts')]:
 assert not canceled(),'native testing canceled'
 assert identity()==before,'source changed after review/build'
 build=json.loads((P/(build_name+'.json')).read_text());exe=P/binary;assert build['exit_code']==0 and not build['error'] and build['source_delta_stable'] and build['executable_sha256']==sha(exe) and build['prepared_before']==build['prepared_after']==before['prepared'];assert build['overlay_inputs_before']==build['overlay_inputs_after']
 d={'argv':[str(exe)],'source_commit':before['commit'],'runtime_baseline_sha256':sha(P/'runtime-baseline.json'),'build_receipt_sha256':sha(P/(build_name+'.json')),'source_review_sha256':sha(P/'source-review-v2.json'),'producer_sha256':sha(__file__),'authorization_sha256':sha(Q/'testing-authorization.json'),'predecessor_receipt_sha256':sha(predecessor),'binary_sha256':sha(exe),'expected_negative':expected_stage is not None,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':None,'error':None};start=time.monotonic();child=None
 print('Starting',name,flush=True)
 try:
  with(P/(name+'.stdout')).open('xb') as so,(P/(name+'.stderr')).open('xb') as se:
   child=subprocess.Popen([str(exe)],cwd=R/'drivers/cogent',env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
   (P/(name+'.owned-process.json')).write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'owner_pid':os.getpid(),'argv':[str(exe)],'binary_sha256':sha(exe),'started_utc':d['started_utc']},indent=2)+'\n')
   while child.poll() is None:
    if canceled():raise InterruptedError('human returned; stop native fixture')
    if time.monotonic()-start>90:raise TimeoutError('native tab fixture watchdog expired')
    time.sleep(.25)
   d['exit_code']=child.returncode
 except BaseException as e:
  d['error']={'type':type(e).__name__,'message':str(e)}
  if child is not None and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
   d['exit_code']=child.returncode
 finally:
  d['elapsed_seconds']=time.monotonic()-start;d['source_prepared_stable']=identity()==before
  for c in ['stdout','stderr']:
   f=P/(name+'.'+c);d[c+'_sha256']=sha(f) if f.exists() else None
  (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 assert not d['error'] and d['source_prepared_stable']
 raw=[json.loads(l) for l in (P/(name+'.stdout')).read_text().splitlines() if l.startswith('{')];results=[r for r in raw if r.get('event')=='vellum.tab-close.result'];assert len(results)==1 and clean(results[0]['native_cleanup'])
 if expected_stage:
  assert d['exit_code']==1 and results[0]['result']=='FAILED_NATIVE_TAB_CLOSE' and expected_message in (P/(name+'.stderr')).read_text()
  failed=[r for r in raw if r.get('event')=='vellum.tab-close.step' and not r['passed']];assert len(failed)==1 and failed[0]['stage']==expected_stage
 else:
  assert d['exit_code']==0 and results[0]['result']=='PASS_NATIVE_TAB_CLOSE';complete=[r for r in raw if r.get('event')=='vellum.tab-close.completed'];assert len(complete)==1 and complete[0]['close_requests']==6 and complete[0]['native_text_edits']==complete[0]['native_decision_changes']==1 and complete[0]['selection_callbacks']==0
  assert [r['stage'] for r in raw if r.get('event')=='vellum.tab-close.step']==['native-draft','reject-b','reject-a','acceptance-enabled','accept-nonselected','accept-last','accept-selected','accept-final-reopened']
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':d['exit_code'],'expected_failure_stage':expected_stage,'native_cleanup_zero':True}
(P/'native-summary.json').write_text(json.dumps({'result':'PASS_SCOPED_NATIVE_TAB_CLOSE_WITH_TWO_DETECTED_FAULTS','source_commit':before['commit'],'source_review_sha256':sha(P/'source-review-v2.json'),'runtime_baseline_sha256':sha(P/'runtime-baseline.json'),'checks':checks,'physical_input_qualified':False,'human_voiceover_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False},indent=2)+'\n');print('Completed reviewed native tab sequence and two detected faults',flush=True)
