"""Bind completed native-tab evidence and final report on current renderer base."""
from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/private/tmp/vellum-tabs-integration')
P = Path('/private/tmp/vellum-macos-tab-close-native')

def sha(f):
    return hashlib.sha256(Path(f).read_bytes()).hexdigest()

def read(name):
    return json.loads((P / name).read_text())

source = read('integration-source.json')
review = read('source-review-v3.json')
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
assert source['sources'] == review['sources'] and len(source['sources']) == 6
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == source['base_commit']
assert all(sha(R / n) == h for n, h in source['sources'].items())
baseline = read('integration-runtime-baseline.json')
assert baseline['commit'] == source['base_commit'] and baseline['prepared'] == source['prepared'] and len(baseline['prepared']) == 6211
assert all(sha(R / n) == h for n, h in baseline['sources'].items())
assert all(sha(R / 'drivers/cogent/build' / n) == h for n, h in baseline['prepared'].items())
native = read('integration-native-summary.json')
receipt = read('integration-native.json')
assert native['result'] == 'PASS_CURRENT_RENDERER_NATIVE_TAB_ACCEPTANCE'
assert native['steps'] == 8 and native['close_requests'] == 6 and native['native_cleanup_zero']
assert receipt['exit_code'] == 0 and receipt['error'] is None and receipt['source_prepared_stable'] and receipt['binary_stable']
assert native['receipt_sha256'] == sha(P / 'integration-native.json')
assert native['runtime_baseline_sha256'] == receipt['runtime_baseline_sha256'] == sha(P / 'integration-runtime-baseline.json')
assert receipt['binary_sha256'] == sha(P / 'tab-close-smoke-integrated')
for stream in ['stdout', 'stderr']:
    assert receipt[stream + '_sha256'] == sha(P / ('integration-native.' + stream))
queue = read('integration-queue-review.json')
assert queue['result'] == 'APPROVED_INTEGRATION_QUEUE' and not queue['unresolved_findings']
assert queue['sources'] == source['sources'] and queue['producer_sha256'] == sha(P / 'integration_native_after_controls.py')
assert receipt['queue_review_sha256'] == sha(P / 'integration-queue-review.json')
checks = {}
for name in ['integration-model-race', 'integration-vet', 'integration-native-build']:
    d = read(name + '.json')
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable']
    assert d['source_commit'] == source['base_commit'] and d['prepared_before'] == d['prepared_after'] == baseline['prepared']
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    assert all(d['source_delta_before'][n] == d['source_delta_after'][n] == h for n, h in source['sources'].items())
    for stream in ['stdout', 'stderr']:
        assert d[stream + '_sha256'] == sha(P / (name + '.' + stream))
    checks[name] = {'receipt_sha256': sha(P / (name + '.json')), 'argv': d['argv'], 'elapsed_seconds': d['elapsed_seconds']}
old = read('native-summary.json')
assert old['result'] == 'PASS_SCOPED_NATIVE_TAB_CLOSE_WITH_TWO_DETECTED_FAULTS'
assert old['source_review_sha256'] == sha(P / 'source-review-v3.json')
assert old['runtime_baseline_sha256'] == sha(P / 'runtime-baseline.json')
old_baseline = read('runtime-baseline.json')
assert old_baseline['commit'] == source['native_test_base_commit'] and len(old_baseline['prepared']) == 6209
assert all(old_baseline['sources'][n] == h for n, h in source['sources'].items())
assert set(old['checks']) == {'native-tabs', 'negative-checkbox', 'negative-selection'}
for name, check in old['checks'].items():
    d = read(name + '.json')
    assert check['receipt_sha256'] == sha(P / (name + '.json')) and check['native_cleanup_zero']
    assert d['error'] is None and d['source_prepared_stable']
    assert d['exit_code'] == (0 if name == 'native-tabs' else 1)
    for stream in ['stdout', 'stderr']:
        assert d[stream + '_sha256'] == sha(P / (name + '.' + stream))

report = R / 'docs/reports/macos-tab-close-native/README.md'
text = report.read_text()
old_text = '''Implementation is prepared in an isolated worktree while the source-bound
1,000-window endurance run remains active. Native build, live sequence and cleanup,
internal review and Prism Anthropic Claude Sonnet 5.5 review are still required.
This report does not yet qualify native tab closing, physical input, human
VoiceOver, performance, retention or the full Mac milestone.'''
new_text = '''The eight-stage sequence passes in a real Cocoa window on the current stage-60
renderer base, with 6,211 exact prepared dependency leaves. The model race test,
vet and native build pass. Six close proposals, one native draft edit, one native
checkbox decision change and zero unintended selection callbacks are observed.
Actual main-thread native cleanup reports stopped callbacks and zero pending,
native, accessibility and window resources.

The exact same fixture source also passes on the earlier stage-58 base with
6,209 prepared leaves. Two faulty native builds on that earlier base fail at
their intended stages: omitted checkbox owner change cannot enable acceptance;
an injected tab-selection callback is detected during rejected closing. Both
faults clean up native resources. These fault controls were not rerun against the
stage-60 renderer. V1/V2 source-review repairs and original evidence are retained.

The final source/evidence review and one Prism Anthropic Claude Sonnet 5.5 review
precede commit. This qualifies bounded native action-selector tab acceptance,
with separate current-renderer positive and earlier-base fault evidence. Physical
input, human VoiceOver, performance, retention and the full Mac milestone remain
open.'''
assert old_text in text
report.write_text(text.replace(old_text, new_text))
sources = {n: sha(R / n) for n in source['sources']}
manifest = {'base_commit': source['base_commit'], 'sources': sources}
(P / 'checkpoint-source.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = {**manifest, 'result': 'PASS_SCOPED_NATIVE_TAB_ACCEPTANCE_CURRENT_RENDERER', 'checks': checks, 'current_renderer_prepared_files': 6211, 'current_renderer_native_steps': 8, 'current_renderer_native_cleanup_zero': True, 'prior_base_commit': old_baseline['commit'], 'prior_prepared_files': 6209, 'prior_native_faults_detected': 2, 'current_native_summary_sha256': sha(P / 'integration-native-summary.json'), 'prior_native_summary_sha256': sha(P / 'native-summary.json'), 'physical_input_qualified': False, 'human_voiceover_qualified': False, 'performance_qualified': False, 'retention_qualified': False, 'full_p6_qualified': False, 'full_p11_qualified': False, 'mac_distribution_qualified': False}
(P / 'final-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS current-renderer native tabs, three code/build gates and earlier two fault controls; six files bound')
