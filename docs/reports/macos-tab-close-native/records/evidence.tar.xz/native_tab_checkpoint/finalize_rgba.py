"""Bind completed native-tab evidence and final report on current renderer base."""
from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/private/tmp/vellum-tabs-integration')
P = Path('/private/tmp/vellum-macos-tab-close-native')

def sha(f):
    return hashlib.sha256(Path(f).read_bytes()).hexdigest()

def read(name):
    return json.loads((P / name).read_text())

source = read('rgba-source.json')
review = read('source-review-v3.json')
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
assert len(source['sources']) == 6 and all(source['sources'][n] == h for n,h in review['sources'].items() if n.startswith('drivers/') or n.startswith('specs/'))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == source['base_commit']
assert all(sha(R / n) == h for n, h in source['sources'].items())
baseline = read('rgba-runtime-baseline.json')
assert baseline['commit'] == source['base_commit'] and baseline['prepared'] == json.loads((P/'prepared-rgba.json').read_text()) and len(baseline['prepared']) == 6214
assert all(sha(R / n) == h for n, h in baseline['sources'].items())
assert all(sha(R / 'drivers/cogent/build' / n) == h for n, h in baseline['prepared'].items())
native = read('rgba-native-summary.json')
receipt = read('rgba-native.json')
assert native['result'] == 'PASS_CURRENT_SOURCE_NATIVE_TAB_ACCEPTANCE'
assert native['steps'] == 8 and native['close_requests'] == 6 and native['native_cleanup_zero']
assert receipt['exit_code'] == 0 and receipt['error'] is None and receipt['source_prepared_stable'] and receipt['binary_stable']
assert native['receipt_sha256'] == sha(P / 'rgba-native.json')
assert native['runtime_baseline_sha256'] == receipt['runtime_baseline_sha256'] == sha(P / 'rgba-runtime-baseline.json')
assert receipt['binary_sha256'] == sha(P / 'tab-close-smoke-rgba')
for stream in ['stdout', 'stderr']:
    assert receipt[stream + '_sha256'] == sha(P / ('rgba-native.' + stream))
assert receipt['producer_sha256'] == sha(P/'rgba_native.py')
checks = {}
for name in ['rgba-model-race', 'rgba-vet', 'rgba-native-build']:
    d = read(name + '.json')
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable']
    assert d['source_commit'] == source['base_commit'] and d['prepared_before'] == d['prepared_after'] == baseline['prepared']
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    assert all(d['source_delta_before'][n] == d['source_delta_after'][n] == h for n, h in source['sources'].items())
    for stream in ['stdout', 'stderr']:
        assert d[stream + '_sha256'] == sha(P / (name + '.' + stream))
    checks[name] = {'receipt_sha256': sha(P / (name + '.json')), 'argv': d['argv'], 'elapsed_seconds': d['elapsed_seconds']}
old = read('native-summary.json')
assert old['result'] == 'PASS_SCOPED_NATIVE_TAB_CLOSE_WITH_TWO_DETECTED_FAULTS'
assert old['source_review_sha256'] == sha(P / 'source-review-v3.json')
assert old['runtime_baseline_sha256'] == sha(P / 'runtime-baseline.json')
old_baseline = read('runtime-baseline.json')
assert old_baseline['commit'] == '4cf9e3654206600885a86581b958bc388043e8af' and len(old_baseline['prepared']) == 6209
assert all(old_baseline['sources'][n] == h for n,h in source['sources'].items() if n.startswith('drivers/') or n.startswith('specs/'))
assert set(old['checks']) == {'native-tabs', 'negative-checkbox', 'negative-selection'}
for name, check in old['checks'].items():
    d = read(name + '.json')
    assert check['receipt_sha256'] == sha(P / (name + '.json')) and check['native_cleanup_zero']
    assert d['error'] is None and d['source_prepared_stable']
    assert d['exit_code'] == (0 if name == 'native-tabs' else 1)
    for stream in ['stdout', 'stderr']:
        assert d[stream + '_sha256'] == sha(P / (name + '.' + stream))

sources = {n: sha(R / n) for n in source['sources']}
manifest = {'base_commit': source['base_commit'], 'sources': sources}
(P / 'rgba-checkpoint-source.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = {**manifest, 'result': 'PASS_SCOPED_NATIVE_TAB_ACCEPTANCE_CURRENT_FRAMEWORK', 'checks': checks, 'current_framework_prepared_files': 6214, 'current_framework_native_steps': 8, 'current_framework_native_cleanup_zero': True, 'prior_base_commit': old_baseline['commit'], 'prior_prepared_files': 6209, 'prior_native_faults_detected': 2, 'current_native_summary_sha256': sha(P / 'rgba-native-summary.json'), 'prior_native_summary_sha256': sha(P / 'native-summary.json'), 'physical_input_qualified': False, 'human_voiceover_qualified': False, 'performance_qualified': False, 'retention_qualified': False, 'full_p6_qualified': False, 'full_p11_qualified': False, 'mac_distribution_qualified': False}
(P / 'rgba-final-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS current-renderer native tabs, three code/build gates and earlier two fault controls; six files bound')
