# Native document-tab acceptance

The bounded `tab-close-smoke` command targets actual Cocoa action selectors for
managed document closing. It creates one disposable window with geometry
persistence disabled. Owner FIFO acknowledgements distinguish proposal admission
from accepted callbacks and native publication. Each stage has a five-second
deadline; the process has a sixty-second deadline and checks final native cleanup.

The required sequence edits a draft natively, rejects selected and nonselected
closes while retaining draft identity, accepts nonselected removal, refuses the
now-absent target and a disabled target, accepts final removal, reopens documents
with new native object identities, then accepts selected and final removal.
It checks exact callback counts and rejects unintended tab selection. Object
identity checks do not claim that an old native object was invoked after remount;
the public selector API resolves IDs against the current snapshot.

Run `go build -tags=vellum_native_checks -o <new-path> ./cmd/tab-close-smoke`
from the prepared Mac driver module, then launch that executable in an authorized
quiet-machine test window. Other builds explicitly refuse native qualification.

Implementation is prepared in an isolated worktree while the source-bound
1,000-window endurance run remains active. Native build, live sequence and cleanup,
internal review and Prism Anthropic Claude Sonnet 5.5 review are still required.
This report does not yet qualify native tab closing, physical input, human
VoiceOver, performance, retention or the full Mac milestone.
