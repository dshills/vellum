from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-tabs-integration');P=Path('/private/tmp/vellum-macos-tab-close-native');D=R/'docs/reports/macos-tab-close-native/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==1 and process['error']is None and process['source_index_stable']
assert review['coverage']['complete'] and review['coverage']['files']==10 and len(review['findings'])==1 and review['findings'][0]['id']=='7a1f0a07fe0be6cb';assert review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
sources=json.loads((P/'combined-checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'combined-internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==json.loads((P/'prism-reviewed-source.json').read_text())['sources']
summary=json.loads((P/'combined-final-summary.json').read_text());assert summary['result']=='PASS_SCOPED_NATIVE_TAB_ACCEPTANCE_CURRENT_FRAMEWORK' and summary['sources']==sources
correction=json.loads((P/'combined-correction-review.json').read_text())
assert correction['result'].startswith('APPROVED') and not correction['unresolved_findings'] and correction['sources']==sources
assert process['before']==process['after']==internal['sources']
allowed_changes=json.loads((P/'prism-correction.json').read_text())['changes']
assert set(allowed_changes)=={'docs/reports/macos-glyph-lookup/README.md','docs/reports/macos-span-storage/README.md','docs/reports/macos-native-followups/README.md'}
for n,h in sources.items():
 old=internal['sources'][n]
 assert sha(P/'prism-v1/source'/n)==old
 if n in allowed_changes:assert allowed_changes[n]=={'before':old,'after':h}
 else:assert old==h

inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.cpu','.png','.heap'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['native_tab_checkpoint/'+f.relative_to(P).as_posix()]=f
# Preserve complete raw source-bound historical campaign evidence; binaries are hash-bound and excluded.
quiet=Path('/private/tmp/vellum-macos-quiet-current')
retention=json.loads((quiet/'internal-retention-review.json').read_text())
for group in ['reviewed_producer_sha256','reviewed_source_sha256','evidence_bindings']:
 for raw,h in retention[group].items():
  f=Path(raw);assert f.is_file() and sha(f)==h
  if f.is_relative_to(quiet):key='historical_retention/'+f.relative_to(quiet).as_posix()
  else:key='historical_retention_source/'+f.relative_to('/private/tmp/vellum-large-data').as_posix()
  inputs[key]=f
for name in ['internal-retention-review.json','internal-retention-review.md']:
 inputs['historical_retention/'+name]=quiet/name
for stage,name in [(59,'glyph-lookup'),(60,'span-storage')]:
 root=Path('/private/tmp/vellum-macos-'+name)
 for f in sorted(root.rglob('*')):
  if not f.is_file() or f.is_symlink() or '__pycache__' in f.parts:continue
  rel=f.relative_to(root)
  if (len(rel.parts)==1 and (f.name.startswith('native') or f.name.startswith('stage'+str(stage)+'-native') or f.name.startswith('launch_native') or (stage==60 and f.name.startswith('original-native-build')))) or rel.parts[0]=='native-comparison':
   if f.suffix in allowed:inputs['historical_stage'+str(stage)+'/'+rel.as_posix()]=f
for stage,root in [(59,Path('/private/tmp/vellum-glyph-lookup')),(60,Path('/private/tmp/vellum-span-storage'))]:
 for n in ['scripts/benchmark-grid.py','scripts/child_process.py','scripts/sdk_environment.py','drivers/cogent/cmd/loadedgrid/main.go']:
  f=root/n
  if f.is_file():inputs['historical_stage'+str(stage)+'_source/'+n]=f
for f in sorted(Path('/private/tmp/vellum-macos-native-followups').rglob('*')):
 if f.is_file() and not f.is_symlink() and f.suffix in allowed:inputs['followup_documentation/'+f.relative_to('/private/tmp/vellum-macos-native-followups').as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Source-bound native tab-close positive on4c0df93/6214 with three passing code/build gates and eight actual stages/cleanupzero. Originalpositive and two detected faults remain4cf/6209; prior68c/3a positives preserve exact endpoints. Ten finalsources plus source-bound historical1000window retention and stage59/60 frame datasets, original/source repairs/raw/producers retained; executablebinaries excluded with exact bound hashes. Doesnot qualify current-source composedretention, latencytargets, physicalinput/humanVoiceOver/nativeGPUbudgets/fullP6/P11/distribution.'},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':10,'prism_findings':1,'prism_unresolved_findings':0,'prism_raw_exit_code':1,'prism_disposition':'FIXED_DOCUMENTATION','internal_correction_review':correction['result'],'internal_correction_review_sha256':sha(P/'combined-correction-review.json'),'prism_calls':review['coverage']['llmCalls'],'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','prism_files','prism_findings','prism_unresolved_findings','prism_disposition','archive_sha256','archive_members','archive_bytes']}))
