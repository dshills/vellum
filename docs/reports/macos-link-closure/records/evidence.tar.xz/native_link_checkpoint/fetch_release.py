from pathlib import Path
import hashlib,json,urllib.request,zipfile
P=Path('/private/tmp/vellum-macos-link-closure')
def fetch(url,out,bound):
 assert not out.exists();request=urllib.request.Request(url,headers={'User-Agent':'Vellum-native-provenance-investigation','Accept':'application/vnd.github+json'if 'api.github.com'in url else 'application/octet-stream'})
 size=0
 with urllib.request.urlopen(request,timeout=60)as source,out.open('xb')as destination:
  while data:=source.read(65536):
   size+=len(data)
   if size>bound:raise ValueError('download exceeds investigation bound')
   destination.write(data)
 return hashlib.sha256(out.read_bytes()).hexdigest()
url='https://api.github.com/repos/gfx-rs/wgpu-native/releases/tags/v29.0.1.1';meta=P/'upstream-release.json';fetch(url,meta,1024*1024);j=json.loads(meta.read_text());assets=[v for v in j['assets']if v['name']=='wgpu-macos-aarch64-release.zip'];assert len(assets)==1;asset=assets[0];assert asset['size']<128*1024*1024
out=P/asset['name'];digest=fetch(asset['browser_download_url'],out,128*1024*1024);assert digest==asset['digest'].removeprefix('sha256:')
with zipfile.ZipFile(out)as z:
 names=z.namelist();libs=[v for v in z.infolist()if v.filename.endswith('/libwgpu_native.a')];assert len(libs)==1 and libs[0].file_size<64*1024*1024
 actual=hashlib.sha256(z.read(libs[0])).hexdigest();cached=Path('/tmp/vellum-p0-cache/mod/github.com/oliverbestmann/webgpu/libs-darwin@v0.0.0-20260628152755-66a5dfa57f8d/arm64/libwgpu_native.a');expected=hashlib.sha256(cached.read_bytes()).hexdigest()
 proof={'release_api':url,'release_id':j['id'],'tag':j['tag_name'],'asset_id':asset['id'],'asset_url':asset['browser_download_url'],'asset_bytes':asset['size'],'asset_sha256':digest,'github_asset_digest_matches':True,'zip_members':names,'archive_member':libs[0].filename,'archive_sha256':actual,'cached_archive_sha256':expected,'cached_archive_matches_upstream':actual==expected,'source_build_provenance_qualified':False,'rights_approved':False,'runtime_executed':False}
 (P/'upstream-comparison.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
