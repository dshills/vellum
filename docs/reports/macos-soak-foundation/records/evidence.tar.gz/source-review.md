APPROVED_SOURCE — no unresolved findings.

All nine current source hashes are bound in source-review.json. SOAK-FOUNDATION-01 is fixed: phase setup copies WinSize under desktop.Window.Mu and releases the mutex before native dispatch. The new native-free regression exercises shared-mutex writes/reads and checks the helper releases the lock. The exact production/test/spec deltas reproduce the preserved v1 hashes when reversed.

Other reviewed lifecycle/measurement/diagnostic boundaries remain approved. Source-only decision; no tests/builds/native/GUI execution performed or runtime acceptance inferred. Live launches remain disabled while the human is online; idle/wake/present/native-memory/P6/P11 qualification remains open.
