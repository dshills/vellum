NEEDS_FIX — SOAK-FOUNDATION-01.

soak.go:141 reads the desktop window size from the worker without the geometry mutex. The inherited WinSize getter reads WnSize without locking; asynchronous desktop geometry callbacks write it under Mu. Copy the size under the known desktop.Window Mu, then unlock before native dispatch.

The other reviewed measurement, worker/owner lifecycle and diagnostic boundaries have no identified blocker. All nine source hashes and context are bound in source-review.json. No runtime/native qualification; live launches remain disabled.
