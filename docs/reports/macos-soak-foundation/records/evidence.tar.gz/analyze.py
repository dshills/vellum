from pathlib import Path
import hashlib,json
R=Path('/private/tmp/vellum-soak-foundation');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((P/'source.json').read_text());sources=source['sources'];assert len(sources)==9 and all(sha(R/n)==h for n,h in sources.items())
checks={};prepared=None
for name,expected in [('command-race-v2',0),('command-vet-v2',0),('native-build-v2',0),('ordinary-build-v2',0),('app-tasks-race-v2',0),('phase-fit-fault-v2',1),('finite-frame-fault-v2',1),('interval-eligibility-fault-v2',1),('geometry-lock-fault-v2',1)]:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==expected and d['error']is None and not d['live_tests']and not d['headless_gpu_requested']
 assert d['source_commit']==source['base_commit']and d['source_delta_stable']and d['source_delta_before']==d['source_delta_after']==sources
 assert d['prepared_before']==d['prepared_after']and len(d['prepared_before'])==6217
 if prepared is None:prepared=d['prepared_before']
 assert prepared==d['prepared_before']and d['overlay_inputs_before']==d['overlay_inputs_after']
 for suffix in ['stdout','stderr']:assert sha(P/(name+'.'+suffix))==d[suffix+'_sha256']
 checks[name]={'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'receipt_sha256':sha(P/(name+'.json')),'stdout_sha256':d['stdout_sha256'],'stderr_sha256':d['stderr_sha256']}
assert 'phase equal to settle plus quiet admits no actual sample' in (P/'phase-fit-fault-v2.stdout').read_text()
assert 'nonfinite coordinate' in (P/'finite-frame-fault-v2.stdout').read_text()
assert 'FAIL: TestSoakIntervalSeparatesCPUFromMeasurementEligibility' in (P/'interval-eligibility-fault-v2.stdout').read_text()
assert 'WARNING: DATA RACE' in (P/'geometry-lock-fault-v2.stdout').read_text()and 'race detected during execution of test' in (P/'geometry-lock-fault-v2.stdout').read_text()
historical=json.loads((P/'historical-campaign/status.json').read_text());assert historical['cause_observed']is False and historical['completed_cycles']==123 and not historical['full1000_cycle_qualified']
assert sha(P/'historical-campaign/failed-campaign-evidence.tar.gz')==historical['archive_sha256']
review=json.loads((P/'source-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and review['sources']==sources and not review['unresolved_findings']
summary={'result':'PASS_SCOPED_SOAK_SOURCE_CHECKS','base_commit':source['base_commit'],'sources':sources,'checks':checks,'prepared_files':6217,'prepared_stable':True,'source_review_sha256':sha(P/'source-review.json'),'native_binary_sha256':sha(P/'window-cycle-smoke-v2'),'native_binary_executed':False,'new_live_tests':False,'soak_runtime_qualified':False,'static_idle_qualified':False,'full_mac_qualified':False,'historical_campaign':historical,'limits':['Native command tests exercise pure Go models, bounded waits, helpers and zero native-window records, never Run/main/NSWindow creation.','Both native-check and ordinary builds pass; Cocoa window arrangement/census and background/soak integration remain unexecuted.','v1 checks preceded geometry-lock fix and are historical, not final-source evidence. Original isolated WIP and its prepared6216/live harness have no current qualification.','Measurement eligibility is distinct from CPU values. App-wide wakes/presents/continuous occlusion/native/GPU memory unavailable; safety guards are not professional budgets.','Historical2c87/6216 campaign failed123/1000 with3201 completed actions+1 failed and unobserved cause. New diagnostics cannot establish that missing historical cause.','A fresh source-bound native runner, native preflight, complete1000 campaign and overnight soak require renewed quiet-host authorization. Live stop remains in force.']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'checks':checks,'native_binary_executed':False,'soak_runtime_qualified':False}))
