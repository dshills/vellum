from pathlib import Path
import json,hashlib,sys,importlib.util,subprocess
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');code=t/'tools/macos-calibration/copycontrol'
sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'))
s=importlib.util.spec_from_file_location('copy_build_owned',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in code.iterdir() if p.is_file()}
commands=[('tests',['/usr/bin/python3','-B','-m','unittest','discover','-s',str(code),'-p','*_test.py']),('compile',['/usr/bin/clang','-fobjc-arc','-O2','-Wall','-Wextra','-Werror','-framework','Foundation','-framework','Metal','-framework','QuartzCore',str(code/'main.m'),'-o',str(q/'native')])]
for name,argv in commands:
 r=g.execute(argv,t,q/(name+'-v2'),lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=60,limit=2<<20)
 (q/(name+'-v2-receipt.json')).write_text(json.dumps({'argv':argv,'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({name:{k:r[k] for k in ['exit_code','error','seconds']}}),flush=True)
 assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent']
identity={'binary_sha256':sha(q/'native'),'source_pins':pins,'compiler':subprocess.check_output(['/usr/bin/clang','--version'],text=True),'source_audit_sha256':sha(q/'source-audit.json'),'shipping_SDK_unchanged':True,'standalone_not_framework':True}
(q/'build-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
