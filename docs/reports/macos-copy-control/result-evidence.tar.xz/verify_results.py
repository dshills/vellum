from pathlib import Path
import json,hashlib,importlib.util,sys,datetime,tarfile
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-copy-control';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=load(q/'bound-plan.json')
assert all(sha(Path(p))==h for p,h in plan['pins'].items())
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
v=module('copy_control_results',t/'tools/macos-calibration/copycontrol/check.py');a=module('copy_control_integrity',q.parent/'macos-release-default-assessment/assessment.py');assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
result=load(q/'result.json');assert result['outcome']=='VALID_OFFSCREEN_METAL_COPY_CONTROL' and result['error'] is None
assert [(c['pair'],c['kind']) for c in result['cases']]==[(1,'writecombined'),(1,'default'),(2,'default'),(2,'writecombined'),(3,'writecombined'),(3,'default')]
count=0
for c in result['cases']:
 root=q/('pair'+str(c['pair'])+'-'+c['kind']);lines=v.base.load(root/'native/stdout');assert len(lines)==1;actual=v.validate(lines[0],c['kind']);assert actual==c['validation']==load(root/'validation.json');assert c['geometry_before']==c['geometry_after'];assert all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,root/folder/k) for k,cmd in c[phase].items())
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['pins_stable'] and cmd['logs_complete'] and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['logs']['stderr']['bytes']==0
  for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
  count+=1
assert count==54;s=load(q/'summary.json');assert s==load(r/'summary.json');assert s['elapsed_seconds']==(datetime.datetime.fromisoformat(result['finished_utc'])-datetime.datetime.fromisoformat(load(q/'started.json')['started_utc'])).total_seconds()<120
assert s['total_GPU_verified_transfers']==sum(c['validation']['GPU_verified_transfers'] for c in result['cases'])==2976
assert s['total_GPU_verified_bytes']==sum(c['validation']['GPU_verified_bytes'] for c in result['cases'])
for row,c in zip(s['cases'],result['cases']):assert row['pair']==c['pair'] and row['mode']==c['kind'] and row['metrics']==c['validation']
for name in ['preparation','result']:
 index=r/(name+'-evidence-index.json');archive=r/(name+'-evidence.tar.xz')
 if not index.exists():continue
 d=load(index);assert sha(archive)==d['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(d['files'])
  for n,e in d['files'].items():b=tf.extractfile(n).read();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
print('PASS six exact ordered cases;768 warmup+720 measured;2976 full GPU transfers;54 owned groups retired;source/binary/config/geometry/log pins;SDK8321;10.801s<120;no shipping or UI-latency acceptance')
