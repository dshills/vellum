from pathlib import Path
import json,hashlib,os,importlib.util,sys
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());d=load(q/'build-identity.json')
assert sha(q/'native')==d['binary_sha256'] and os.access(q/'native',os.X_OK)
assert all(sha(Path(p))==h for p,h in d['source_pins'].items()) and sha(q/'source-audit.json')==d['source_audit_sha256']
for n in ['tests','compile']:
 r=load(q/(n+'-v2-receipt.json'))['run'];assert r['exit_code']==0 and r['error'] is None and r['pins_stable'] and r['logs_complete'] and r['owned']['terminal'] and r['owned']['group_absent']
 for stream,v in r['logs'].items():assert sha(q/(n+'-v2')/stream)==v['sha256'] and (q/(n+'-v2')/stream).stat().st_size==v['bytes']
s=importlib.util.spec_from_file_location('copy_control_SDK_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a)
assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS source, compiler/binary, exact source audit, five focused test methods, owned build groups, unchanged SDK 8321-file inventory; no native run yet')
