"""Read completed native profiles with a verified local pprof, without execution."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent/'macos-grid-alloc-cpu-238b3b6';P=Path('/private/tmp/vellum-grid-alloc-cpu-238b3b6');O=Path('/private/tmp/vellum-grid-profile-analysis-238b3b6');TOOL=Path('/private/tmp/vellum-profile-pprof-tool-1ba954c')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
 need(not O.exists(),'fresh offline outputs');r=module('completed_grid_profile_source_guard',N/'run.py');d=read(P/'receipt.json');need(d['result']=='PASS_SEPARATE_NATIVE_CPU_ALLOCATION_DIAGNOSTICS'and d['local_stop_present']and(P/'stop-live').exists()and read(P/'tools-complete.json')['all_tools_terminal'],'sealed terminal native diagnostics')
 source=read(P/'source.json');need(r.identity(r.T)==r.identity(r.C)==source,'current source');provenance=read(N/'provenance.json');r.g.sdk_valid(provenance)
 tool=read(TOOL/'receipt.json');need(tool['success']and tool['exit_code']==0 and tool['binary']['path']==str(TOOL/'pprof')and sha(TOOL/'pprof')==tool['binary']['sha256'],'local pprof executable');need(all(sha(p)==h for p,h in tool['bundled_main_pprof_objfile_source'].items()),'local tool bundled sources')
 profiles={}
 for case in d['cases']:
  need(case['error']is None and case['run']['owned']['terminal']and case['run']['owned']['group_absent'],'case terminal');r.g.absent(case['run']['pid'])
  for name,value in case['validation']['profiles'].items():need(sha(value['path'])==value['sha256']and Path(value['path']).stat().st_size==value['bytes'],'profile integrity');profiles[name]=value
 need(set(profiles)=={'cpu.pprof','alloc.before.pprof','alloc.after.pprof'},'three separate native profiles')
 O.mkdir(mode=0o700);(O/'runs').mkdir();binary=provenance['binary']['path'];cpu=profiles['cpu.pprof']['path'];before=profiles['alloc.before.pprof']['path'];after=profiles['alloc.after.pprof']['path'];common=['-symbolize=none','-nodecount=80'];base=['-base='+before]
 jobs=[('cpu-flat',['-top','-sample_index=cpu'],cpu),('cpu-cumulative',['-top','-cum','-sample_index=cpu'],cpu),('cpu-reconcile',['-peek=reconcileScoped','-sample_index=cpu'],cpu),('cpu-reconcile-traces',['-traces','-focus=reconcileScoped','-sample_index=cpu'],cpu),('alloc-space-flat',['-top','-sample_index=alloc_space',*base],after),('alloc-space-cumulative',['-top','-cum','-sample_index=alloc_space',*base],after),('alloc-objects-flat',['-top','-sample_index=alloc_objects',*base],after),('alloc-objects-cumulative',['-top','-cum','-sample_index=alloc_objects',*base],after),('alloc-space-reconcile',['-peek=reconcileScoped','-sample_index=alloc_space',*base],after)]
 paths=[Path(__file__),N/'run.py',N/'readiness.json',N/'provenance.json',P/'source.json',P/'receipt.json',P/'tools-complete.json',TOOL/'receipt.json',TOOL/'pprof',Path(binary),Path(provenance['sdk_root'])/'SDK_MANIFEST.json']+[Path(v['path'])for v in profiles.values()];pins={str(p.resolve()):sha(p)for p in paths};stable=lambda:all(sha(p)==h for p,h in pins.items());(W/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
 result=dict(result='INCOMPLETE',source_commit=d['source_commit'],current_checkout_commit=d['current_checkout_commit'],producer_sha256=sha(__file__),native_receipt_sha256=sha(P/'receipt.json'),tool=tool['binary'],profiles=profiles,commands=[],native_processes_launched=0,native_application_binary_executed=False,physical_input_generated=False,network_requested=False,performance_qualified=False,causal_bottleneck_proven=False,full_macos_qualified=False,error=None)
 try:
  for name,opts,profile in jobs:
   argv=[str(TOOL/'pprof'),*common,*opts,binary,profile];run=r.g.execute(argv,O,O/'runs'/name,lambda:False,stable,timeout=45,limit=4<<20);result['commands'].append(dict(name=name,run=run))
   need(run['created']and run['error']is None and not run['observation_errors']and run['exit_code']==0 and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and run['logs_complete']and run['pins_stable'],'pprof command failed '+name)
   print(json.dumps(dict(command=name,result='OFFLINE_PPROF_COMPLETE',stdout_bytes=run['logs']['stdout']['bytes'])),flush=True)
  need(r.identity(r.T)==r.identity(r.C)==source and stable(),'unchanged source/inputs');r.g.sdk_valid(provenance);result.update(result='PASS_OFFLINE_PPROF_COMMANDS',source_stable=True,sdk_stable=True,pins_stable=True)
 except BaseException as e:result['error']=dict(type=type(e).__name__,message=str(e))
 finally:
  with(W/'analysis.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
  print(json.dumps({k:v for k,v in result.items()if k not in['commands','profiles']}),flush=True)
 need(result['result']=='PASS_OFFLINE_PPROF_COMMANDS','offline analysis failed')
if __name__=='__main__':main()
