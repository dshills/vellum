"""Extract labeled profile rows without converting samples into frame savings."""
from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent;O=Path('/private/tmp/vellum-grid-profile-analysis-238b3b6');C=Path('/Users/dshills/Development/projects/Vellum');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
def row(command,function,peek=False):
 p=O/'runs'/command/'stdout';found=[]
 for line in p.read_text().splitlines():
  if peek:
   if '|'not in line:continue
   before,after=line.split('|',1)
   if after.strip()!=function:continue
   fields=before.split()
  else:
   fields=line.split()
   if len(fields)<6 or' '.join(fields[5:])!=function:continue
   fields=fields[:5]
  if len(fields)!=5 or not all(fields[n].endswith('%')for n in[1,2,4]):continue
  found.append(dict(flat=fields[0],flat_percent=float(fields[1][:-1]),cumulative=fields[3],cumulative_percent=float(fields[4][:-1])))
 need(len(found)==1,'unique profile row '+command+' '+function);return dict(command=command,function=function,output_sha256=sha(p),**found[0])
observations=[row('cpu-flat','runtime.cgocall'),row('cpu-cumulative','github.com/dshills/vellum/drivers/cogent.syncAccessibility'),row('cpu-reconcile','github.com/dshills/vellum/drivers/cogent.reconcileScoped',True),row('alloc-space-cumulative','github.com/dshills/vellum/drivers/cogent.syncAccessibility'),row('alloc-space-reconcile','github.com/dshills/vellum/drivers/cogent.reconcileScoped',True),row('alloc-space-cumulative','github.com/dshills/vellum/drivers/cogent.(*gridWidget).LayoutLocal'),row('alloc-objects-cumulative','github.com/dshills/vellum/drivers/cogent.(*gridWidget).LayoutLocal')]
result=dict(status='EXPLORATORY_PROFILE_ATTRIBUTION_NOT_CAUSAL_PROOF',producer_sha256=sha(__file__),observations=observations,sources={n:dict(sha256=sha(C/n))for n in['drivers/cogent/driver.go','drivers/cogent/frame_metrics.go','drivers/cogent/grid_retained.go','drivers/cogent/accessibility.go','drivers/cogent/accessibility_grid_publication.go']},source_scope='Driver refresh starts the Reconcile timer before View/reconcileScoped and calls syncAccessibility before the deferred timer end. gridWidget.LayoutLocal calls SizeUp/SizeDown/SizeFinal for dirty text, under native layout. Verify these source boundaries independently; function samples are not durations of those whole regions.',interpretation='The initial idea that reconcileScoped itself dominates the Reconcile region is unsupported. The profile directs investigation toward accessibility publication and repeated dirty-cell text sizing. Cumulative rows overlap and must not be summed. Go CPU samples dominated by cgocall do not identify native work or explain the main-loop label; no busy-wait, idle defect or causal frame bottleneck is established.',next_work='Investigate bounded reuse for repeated grid text layout and accessibility snapshot preparation separately. Preserve arbitrary Unicode/styles/scaling, detached ownership, pending/completed accessibility transactions, action admission and lifecycle. Require differential correctness and native matched ordinary measurements before adoption or any gain claim.',ordinary_performance_qualified=False,native_gpu_memory_qualified=False,gpu_execution_verified=False,physical_input_verified=False,full_macos_qualified=False)
with(W/'interpretation.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],observations=observations)))
