"""Two separate owned grid diagnostics, using the unchanged packaged SDK binary."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-grid-alloc-cpu-238b3b6');BASE=Path('/private/tmp/vellum-current-sdk-238b3b6');HEAD='cbc25c270345f1d668e18722050910d7e0374eee';SDK_SOURCE='238b3b619e5ef274c218cb62d0b348e44e3fcaf8';STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
guard_path=W.parent/'macos-sdk-native-238b3b6/run.py';need(sha(guard_path)=='e76238012be63f58cbc5923e27f6fc227a3aca8443d85d64f466c0675382c7ac','reviewed owned-child helper');g=module('grid_profile_owned_guard',guard_path);benchmark=module('grid_profile_validator',T/'scripts/benchmark-grid.py')
from child_process import run_child
def identity(root):
 def git(*args):return run_child(['git',*args],cwd=root,capture_output=True,check=True,timeout=20).stdout
 need(git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-z'),'clean exact current source');files={};prepared={}
 for n in git('ls-files','-z').decode().split('\0')[:-1]:
  p=root/n;need(p.is_file()and not p.is_symlink(),'tracked regular file');files[n]=sha(p)
 for name in['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/name).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 need(len(files)==4664 and len(prepared)==6246,'current source counts');return dict(commit=HEAD,files=files,prepared=prepared)
def prepare():
 P.mkdir(mode=0o700);(P/'profiles').mkdir();analysis=read(W.parent/'macos-current-sdk-238b3b6/analysis.json');built=read(BASE/'demos/receipt.json');sdk=Path(built['sdk_root']);binary=analysis['demos']['loadedgrid']['binary']
 need(analysis['source_commit']==SDK_SOURCE and built['examples']['loadedgrid']['complete']and all(c['exit_code']==0 for c in built['examples']['loadedgrid']['commands']),'verified packaged binary chain')
 need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'binary bytes')
 a=dict(source_commit=SDK_SOURCE,current_checkout_commit=HEAD,sdk_root=str(sdk),manifest_sha256=sha(sdk/'SDK_MANIFEST.json'),binary=binary,archive=dict(path=str(BASE/'sdk.tar.gz'),sha256=analysis['archive']['sha256']),build_receipt_sha256=sha(BASE/'demos/receipt.json'))
 need(sha(BASE/'sdk.tar.gz')==a['archive']['sha256'],'SDK archive');g.sdk_valid(a);source=identity(T);need(identity(C)==source,'current parity')
 (P/'source.json').write_text(json.dumps(source,indent=2)+'\n');(W/'provenance.json').write_text(json.dumps(a,indent=2)+'\n')
 print(json.dumps(dict(prepared=True,source_commit=SDK_SOURCE,current_checkout_commit=HEAD,binary=binary,native_runtime_executed=False)))
def fresh(root):need(not(root/'receipt.json').exists()and not(root/'runs').exists()and not(root/'stop-live').exists(),'fresh unsealed campaign only')
def finalize(root,d):
 d['finalization_errors']=[];d['local_stop_present']=False
 try:(root/'stop-live').touch();d['local_stop_present']=True
 except BaseException as e:d['finalization_errors'].append(dict(stage='seal-stop',type=type(e).__name__,message=str(e)))
 d['result']='PASS_SEPARATE_NATIVE_CPU_ALLOCATION_DIAGNOSTICS'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_NATIVE_PROFILE_DIAGNOSTICS'
 try:
  with(root/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 except BaseException as e:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(e).__name__,message=str(e)));d['result']='FAILED_OR_CANCELED_NATIVE_PROFILE_DIAGNOSTICS'
 return d
def validate(out,case):
 records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];samples=benchmark.validate_records(records,1000000,False,512,False,allow_profile=case=='cpu',allow_alloc_profile=case=='allocation',gpu_scene_rendering=True)
 need(records[0].get('cpu_profile',False)is(case=='cpu')and records[0].get('alloc_profile',False)is(case=='allocation'),'exact diagnostic mode');need(records[1]['warmup']==128 and records[1]['warm_callbacks']==128 and records[0]['window_geometry_guard']==1 and records[0]['warmup_guard']==1,'current geometry/warm guard')
 names=['cpu.pprof']if case=='cpu'else['alloc.before.pprof','alloc.after.pprof'];profiles={}
 for n in names:
  p=P/'profiles'/n;need(p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=64<<20,'bounded profile '+n)
  with p.open('rb')as f:need(f.read(2)==b'\x1f\x8b','gzip pprof '+n)
  profiles[n]=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
 return dict(samples=len(samples),warmup=128,completed_callbacks=records[-1]['callbacks'],native_window=records[1]['native_window'],geometry_sha256=hashlib.sha256(json.dumps([s['geometry']for s in samples],sort_keys=True,separators=(',',':')).encode()).hexdigest(),profiles=profiles,ordinary_target_qualified=False,gpu_execution_verified=False,physical_input_verified=False),samples
def main():
 need(sys.argv[1:]in[['prepare'],['run']],'fixed phase only')
 if sys.argv[1]=='prepare':prepare();return
 fresh(P);review=read(W/'readiness.json');need(review['execution_ready']is True and not review['unresolved_findings'],'internal native execution review');pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(P/'stop-live').exists();need(not stopping()and stable(),'initial admission')
 a=read(W/'provenance.json');source=read(P/'source.json');d=dict(result='INCOMPLETE',source_commit=SDK_SOURCE,current_checkout_commit=HEAD,producer_sha256=sha(__file__),review_sha256=sha(W/'readiness.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False,physical_input_generated=False,settings_changes=False,performance_qualified=False,native_gpu_memory_qualified=False,full_macos_qualified=False,error=None,cases=[])
 try:
  with g.LiveLease()as lease:
   need(lease.held()and not stopping()and stable(),'lease admission');need(identity(T)==identity(C)==source,'source parity');g.sdk_valid(a);(P/'runs').mkdir();previous=None
   for case in['cpu','allocation']:
    need(lease.held()and not stopping()and stable(),'case admission')
    paths=[P/'profiles'/'cpu.pprof']if case=='cpu'else[P/'profiles'/'alloc.before.pprof',P/'profiles'/'alloc.after.pprof'];need(all(not p.exists()for p in paths),'new profile destinations')
    flag='-perf-cpu-profile='+str(paths[0])if case=='cpu'else'-perf-alloc-profile='+str(P/'profiles'/'alloc')
    argv=[a['binary']['path'],'-perf','-rows=1000000','-gpu-scene','-perf-samples=512','-perf-warmup=128',flag];out=P/'runs'/case
    run=g.execute(argv,Path(a['sdk_root'])/'examples/loadedgrid',out,stopping,stable,timeout=180,limit=8<<20);record=dict(case=case,run=run,error=None);d['cases'].append(record);d['native_runtime_executed']=d['native_runtime_executed']or run['created']
    try:
     need(run['created']and run['error']is None and not run['observation_errors']and run['exit_code']==0 and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit'],'native diagnostic failed or canceled')
     record['validation'],samples=validate(out,case)
     if previous is not None:
      prior=d['cases'][0];g.absent(prior['run']['pid']);benchmark.compare_geometry(previous,samples);need(prior['validation']['native_window']==record['validation']['native_window']and all(x['geometry']==y['geometry']for x,y in zip(previous,samples)),'complete diagnostic geometry equality')
     previous=samples
    except BaseException as e:record['error']=dict(type=type(e).__name__,message=str(e));raise
    finally:
     with(out/'receipt.json').open('x')as f:f.write(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(case=case,result='NATIVE_DIAGNOSTIC_COMPLETED',seconds=run['seconds'],profiles=record['validation']['profiles'])),flush=True)
   need(len(d['cases'])==2 and identity(T)==identity(C)==source,'final source parity');g.sdk_valid(a);d.update(source_stable=True,sdk_stable=True,pins_stable=stable(),lease_held_through_cleanup=lease.held());need(stable()and not stopping(),'final pins/stop')
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 finally:finalize(P,d);print(json.dumps(d),flush=True)
 need(d['error']is None and not d['finalization_errors'],'native profiling failed')
if __name__=='__main__':main()
