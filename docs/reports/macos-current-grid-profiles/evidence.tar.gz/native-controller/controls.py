"""No native launch: preserve terminal receipts when sealing fails or output exists."""
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
import run as m
root=m.P/'controller-controls';root.mkdir(mode=0o700);results=[]
for n in['normal','seal-failure','existing-receipt','existing-runs','sealed']:(root/n).mkdir()
d=m.finalize(root/'normal',dict(error=None,native_runtime_executed=False));m.need(d['result']=='PASS_SEPARATE_NATIVE_CPU_ALLOCATION_DIAGNOSTICS'and not d['finalization_errors'],'normal finalization');results.append(dict(case='normal',receipt=d))
touch=Path.touch
try:
 def bad(self,*args,**kw):
  if self==root/'seal-failure/stop-live':raise OSError('injected seal failure')
  return touch(self,*args,**kw)
 Path.touch=bad;d=m.finalize(root/'seal-failure',dict(error=None,native_runtime_executed=False));m.need(d['result']=='FAILED_OR_CANCELED_NATIVE_PROFILE_DIAGNOSTICS'and m.read(root/'seal-failure/receipt.json')==d and d['finalization_errors'][0]['stage']=='seal-stop','receipt attempted despite sealing failure');results.append(dict(case='seal-failure',receipt=d))
finally:Path.touch=touch
p=root/'existing-receipt/receipt.json';p.write_text('prior immutable terminal\n');d=m.finalize(root/'existing-receipt',dict(error=None,native_runtime_executed=False));m.need(p.read_text()=='prior immutable terminal\n'and d['finalization_errors'][0]['stage']=='exclusive-receipt','prior receipt preserved');results.append(dict(case='existing-receipt',receipt=d))
(root/'existing-runs/runs').mkdir();(root/'sealed/stop-live').touch();refused=0
for n in ['existing-receipt','existing-runs','sealed']:
 try:m.fresh(root/n)
 except ValueError:refused+=1
m.need(refused==3,'stale output and sealed campaign refused')
result=dict(result='PASS_NON_NATIVE_PROFILE_CONTROLLER_CONTROLS',runner_sha256=m.sha(m.W/'run.py'),producer_sha256=m.sha(__file__),native_runtime_executed=False,finalization_cases=3,admission_refusals=3,results=results)
(m.W/'controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='results'}))
