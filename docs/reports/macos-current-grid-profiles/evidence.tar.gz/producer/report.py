"""Retain separate CPU/allocation diagnostics and conservative source attribution."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;N=W.parent/'macos-grid-alloc-cpu-238b3b6';A=W.parent/'macos-grid-profile-analysis';P=Path('/private/tmp/vellum-grid-alloc-cpu-238b3b6');O=Path('/private/tmp/vellum-grid-profile-analysis-238b3b6');T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'docs/reports/macos-current-grid-profiles';TOOL=Path('/private/tmp/vellum-profile-pprof-tool-1ba954c')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']and r['report_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'reviewed results/producer')
d=read(P/'receipt.json');a=read(A/'analysis.json');interpretation=read(A/'interpretation.json');provenance=read(N/'provenance.json');sdk=Path(provenance['sdk_root']);need(d['result']=='PASS_SEPARATE_NATIVE_CPU_ALLOCATION_DIAGNOSTICS'and a['result']=='PASS_OFFLINE_PPROF_COMMANDS'and(P/'stop-live').exists()and read(P/'tools-complete.json')['all_tools_terminal']and read(A/'tools-complete.json')['all_tools_terminal'],'terminal sealed diagnostics')
members={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'evidence symlink')
  if p.is_file()and'__pycache__'not in p.parts:members[label+p.relative_to(root).as_posix()]=p
add('native-controller/',N);add('offline-controller/',A);add('native-checks/',P);add('offline-checks/',O)
members['review/result-review.json']=W/'result-review.json';members['producer/report.py']=Path(__file__)
for n in ['child_process.py','sdk_environment.py','benchmark-grid.py']:members['helpers/'+n]=T/'scripts'/n
members['helpers/owned-runner.py']=W.parent/'macos-sdk-native-238b3b6/run.py';members['helpers/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
for n in ['receipt.json','metadata.stdout','metadata.stderr','help.stdout','help.stderr','build.stdout','build.stderr']:members['pprof-tool/'+n]=TOOL/n
members['pprof-tool/build-producer.py']=W.parent/'macos-grid-profile/build-pprof.py'
members['sdk/SDK_MANIFEST.json']=sdk/'SDK_MANIFEST.json';BASE=Path('/private/tmp/vellum-current-sdk-238b3b6');members['sdk/build-receipt.json']=BASE/'demos/receipt.json';add('sdk/loadedgrid-build/',BASE/'demos/loadedgrid')
for n in ['drivers/cogent/driver.go','drivers/cogent/frame_metrics.go','drivers/cogent/grid_retained.go','drivers/cogent/accessibility.go','drivers/cogent/accessibility_grid_publication.go','examples/loadedgrid/main.go','examples/loadedgrid/perf.go','examples/loadedgrid/perf_runtime.go','examples/loadedgrid/perf_profile.go']:members['source/'+n]=sdk/n
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<180 and expanded<16<<20,'bounded evidence');D.mkdir()
tool=read(TOOL/'receipt.json');manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},count=len(members),expanded_bytes=expanded,excluded_artifacts=dict(sdk_archive=provenance['archive'],native_binary=provenance['binary'],pprof_binary=tool['binary'],extracted_sdk=dict(path=str(sdk),manifest_sha256=provenance['manifest_sha256'],files=7411)))
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,p in members.items():
    data=p.read_bytes();need(hashlib.sha256(data).hexdigest()==manifest['files'][n]['sha256'],'archive input drift');entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive member integrity')
result=dict(status='REVIEWED_SEPARATE_NATIVE_GRID_PROFILES',native=d,offline=a,interpretation=interpretation,provenance=provenance,result_review_sha256=sha(W/'result-review.json'),evidence=dict(sha256=sha(D/'evidence.tar.gz'),bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded),provider_calls=0,production_source_changed=False,ordinary_performance_qualified=False,native_gpu_memory_qualified=False,physical_input_verified=False,public_distribution=False,full_macos_qualified=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(D/'README.md').write_text('''# Current native grid CPU and allocation profiles

Two separate native diagnostics complete on the unchanged packaged SDK from
`238b3b619e5ef274c218cb62d0b348e44e3fcaf8`. Both request the GPU scene route for
a fixed-height million-row stored table, with 128 warmup events and 512 measured
scroll events. CPU and allocation profiling are mutually exclusive fixture
modes; no combined-mode native run is made. These profiled/differential runs do
not qualify ordinary frame latency, a speedup or memory budgets.

## Execution and identity

The native executable is the already compiled private SDK loaded-grid consumer,
SHA256 `ccc37ade4a6c25a7bcb7f4f054c4b1ec1a6a3c1f3c9bfbb2d03209e2af34ece7`.
Runtime source remains SDK `238b3b6`; `cbc25c2` is the separate documentation
endpoint present in both clean checkouts during the runs. Their 4,664 tracked
and 6,246 prepared files, all 7,411 SDK leaves, private archive and binary remain
unchanged. No source change or rebuild is needed for these existing diagnostics.

The first native process records CPU samples only. The second records cumulative
Go allocation profiles before and after its measured events. Profilers start
after warmup. CPU collection runs in its own process without allocation-profile
snapshots. The separate allocation process forces two GC cycles for each before/
after snapshot outside the recorded events, with CPU profiling disabled. The
native writer caps each new exclusive profile file at
64 MiB and reports write/close failures.

Both processes exit with status zero, complete all 512 callbacks with no missing,
dropped or pending tickets, reach EOF on both streams and have their owned groups
observed absent. All 512 paired full grid geometries and native endpoints match.
The client/render extent is 1519×1266 pixels on the recorded DPI162/DPR1 display;
the measured logical grid is 767×624 and satisfies the 400-cell/50-row/eight-
column minimum. These endpoint checks do not prove continuous absence of a
transient display/resize change or physical display behavior.

The reviewed controller uses the shared native lease, universal/local stop
markers, a 180-second per-process watchdog, bounded raw streams and independent
cleanup/finalization attempts. The campaign is sealed after completion. It does
not generate desktop pointer/key events or change input-source, VoiceOver,
clipboard or OS preference settings. Geometry persistence is fixture-disabled.

## What the profiles suggest

Nine bounded offline commands read the three exact profiles with the retained,
source-bound local Go `cmd/pprof` tool. `-symbolize=none` avoids remote/native
symbol lookup. The native application is not executed by this analysis.
The Go installation lacks a `go tool pprof` executable, so the previously built
and verified local tool is reused. An initial restricted analysis attempt fails
at read-only process observation before output creation or pprof dispatch; the
unchanged analyzer succeeds with process-observation permission. This is not a
native rerun or a requalification of the failed observation.

| Function/path | Profile observation |
|---|---|
| `runtime.cgocall` | 75.42% flat CPU samples; native work remains unresolved |
| `syncAccessibility` | 11.46% cumulative CPU samples; 33.47% cumulative allocation-space estimate |
| `reconcileScoped` | 0.33% cumulative CPU samples; 4.60% cumulative allocation-space estimate |
| `gridWidget.LayoutLocal` | 10.84% cumulative allocation-space estimate; 35.60% cumulative object estimate |

These are process-wide sampled profiles and differential allocation estimates,
including frame observers and other goroutines. Cumulative rows overlap and
must not be added. Main-loop/`cgocall` labels do not establish a busy wait, an
idle defect, exact native CPU work or a causal frame bottleneck. Go allocation
estimates do not measure retained UI bytes or native/GPU/private memory.

The source refresh's Reconcile timer includes `syncAccessibility` after
`reconcileScoped`; the latter function alone is not the whole region. The local
grid layout explicitly sizes dirty text with SizeUp/SizeDown/SizeFinal. These
boundaries plus the profiles direct the next investigation toward accessibility
snapshot preparation and repeated grid text sizing, rather than assuming keyed
node reconciliation dominates. No optimization or expected saving is asserted.
Candidate changes require bounded lifecycle/ownership, arbitrary text/style/DPI
correctness, pending/completed accessibility transaction and action-admission
regressions, then matched ordinary native measurements before adoption claims.

## Remaining qualification

The existing 4 ms p95 / 6 ms p99 failures remain failed. Profiling does not close
P6/P11, prove actual GPU execution for ordinary grid frames, physical input,
presentation, native/GPU memory, human accessibility or Mac release acceptance.
Internal prelaunch/result/documentation reviews cover this evidence-only phase;
the implementation's stage 0075 Prism review remains its last provider review.
No additional provider call, public release, signing or notarization occurs.

See [structured result](result.json), [evidence manifest](evidence.manifest.json)
and [raw evidence](evidence.tar.gz). The [ordinary tile-binning comparison](../macos-adaptive-tile-binning/README.md)
and [SDK consumption](../macos-current-sdk/README.md) retain their separate scope.
''')
for n in ['docs/implementation.md','specs/macos-completion.md']:
 p=T/n;text=p.read_text();link='reports/macos-current-grid-profiles/README.md'if n.startswith('docs/')else'../docs/reports/macos-current-grid-profiles/README.md';text+='''

## Current native grid profile attribution

The [separate CPU/allocation diagnostics]('''+link+''') complete two native
million-row GPU-requested cases, 1,024 samples and 512 full geometry pairs on
unchanged SDK `238b3b6` source. Offline profiles suggest accessibility publication
and repeated dirty-cell text sizing as investigation targets. They do not prove
a causal bottleneck or savings; the Reconcile region includes accessibility
work beyond `reconcileScoped`. Existing ordinary 4/6 ms failures and full Mac,
P6/P11, physical/human, native/GPU memory and release gates remain open.
''';p.write_text(text)
p=T/'docs/reports/README.md';text=p.read_text();text+='\n- [Current native grid CPU/allocation profiles](macos-current-grid-profiles/README.md): separate bounded diagnostics and conservative attribution; ordinary latency targets remain unqualified.\n';p.write_text(text)
print(json.dumps(dict(result='CURRENT_NATIVE_GRID_PROFILE_REPORT_GENERATED',files=7,members=len(members),expanded_bytes=expanded,archive_bytes=(D/'evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'evidence.tar.gz'))))
