from pathlib import Path
import json,shutil
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-display-scheduling';summary=json.loads((q/'result-summary.json').read_text());assert summary['outcome']=='VALID_DISPLAY_CLOCK_OFF_ON_CONTROL';off,on=summary['cases']
text=f'''# Existing-backend display scheduling: off/on result

Both cases of the single approved control pass complete accounting. The existing
Cogent/WebGPU renderer, allocation/cache policy, FIFO/vsync, two drawables and
nontransactional presentation stay unchanged. No production fix is adopted.

| Display-clock observer | Receipt-to-shown p50 | p95 | p99 | Maximum | Above 33.3 ms |
| --- | ---: | ---: | ---: | ---: | ---: |
| Off | {off['receipt_to_shown_ms']['p50']:.3f} ms | {off['receipt_to_shown_ms']['p95']:.3f} ms | {off['receipt_to_shown_ms']['p99']:.3f} ms | {off['receipt_to_shown_ms']['max']:.3f} ms | {off['over33_3ms']}/120 |
| On | {on['receipt_to_shown_ms']['p50']:.3f} ms | {on['receipt_to_shown_ms']['p95']:.3f} ms | {on['receipt_to_shown_ms']['p99']:.3f} ms | {on['receipt_to_shown_ms']['max']:.3f} ms | {on['over33_3ms']}/120 |

The on-minus-off difference of run p95 values is
**{summary['difference_of_run_p95_on_minus_off_ms']:.3f} ms**, approximately one refresh period.
This is one ordered off/on pair, not a distribution of paired input differences,
a repeated estimate or proof of causation. Process/order and temporal variation
remain possible explanations. Earlier captures already showed more than one
latency band. **The display-clock observer cannot be assumed neutral.** Its
registration/wake behavior is now a concrete scheduling hypothesis to control,
not an accepted repair. Both cases still fail the unchanged 33.3 ms p95 number.

## Joined display-clock observations

The on case retains all {on['callback_count']:,} callbacks, including startup and the common
held tail. All {on['callback_timestamp_intervals_ms']['count']:,} adjacent reported timestamp intervals are approximately
16.667 ms; none is discarded for lateness or a gap. Across all callbacks, host
observation minus reported timestamp has p95
{on['callback_observation_minus_timestamp_ms']['p95']:.3f} ms, while target minus timestamp is approximately
16.667 ms. Callback observation is not GPU completion, latch time or scanout.

The 120 measured actual presentations lie within
{on['nearest_reported_timestamp_absolute_error_ms']['max']*1000:.3f} microseconds of the nearest reported display timestamp.
There are 107 measured responses with one reported timestamp strictly between
final-present GPU end and shown, and 13 with none. These are retrospective
reported-event counts, not missed-vsync counts or guaranteed latch opportunities.
No timestamp lattice is fitted to presentation feedback.

Each process has its own p95-ranked input. Off selects accepted revision
{off['p95_rank_ticket']['accepted_revision']}, scope 1, opaque tag {off['p95_rank_ticket']['opaque_tag']}, generation
{off['p95_rank_ticket']['generation']}, drawable {off['p95_rank_ticket']['drawable_id']}; its final-present GPU end to shown is
{off['p95_rank_ticket']['present_gpu_end_to_shown_ms']:.3f} ms. On selects revision {on['p95_rank_ticket']['accepted_revision']}, scope 1, tag
{on['p95_rank_ticket']['opaque_tag']}, generation {on['p95_rank_ticket']['generation']}, drawable {on['p95_rank_ticket']['drawable_id']}; that interval is
{on['p95_rank_ticket']['present_gpu_end_to_shown_ms']:.3f} ms. These are actual individual inputs, not a phase-percentile sum
or a decomposition of the difference between run p95 values. No compositor-only,
driver-only, fixed-frame or WebGPU-specific cause is established.

## Checks and scope

Execution takes **{summary['elapsed_seconds']:.3f} seconds** overall, within the 100-second bound.
Native cases take {off['native_seconds']:.3f} and {on['native_seconds']:.3f} seconds, below their 40-second bounds.
All 18 owned native/probe groups retire; native stderr is empty. Each case retains
128 warmup and 120 measured accepted inputs with complete source/raster/upload/
GPU/drawable joins. Each also retains 50 startup commands and ten startup presents.
Off records zero display callbacks; on drains/invalidate/releases cleanly. Both
cases use the same binary/archive and identical 50 ms held tails outside the cohort.
Configuration, persistent geometry, all source/binary/module/overlay/native pins,
raw logs and all 8,321 SDK files verify unchanged within and across cases.

Preparation passed eight focused classifier methods with 20 negative cases,
exact timestamp-boundary and late-callback/gap controls, the original routed
complete-pixel fixture, native recorder/ownership tests and fresh consumer builds.
The native JSON Boolean issue was fixed before desktop use; a counterfactual
with the original implementation is refused by the final native fixture with an
ordinary exit and no window or crash. The exact reviewed native archive/Core and
source-detail overlays are reused; no Rust or SDK rebuild occurs.

Prism using Anthropic Claude Sonnet 5.5 reviewed all 15 preparation files and ten
focused follow-up files. Boundary semantics are tested; source-backed dispositions
retain strict focus identity, unconditional pre-start cleanup and the fixed-on
CPU/GPU observer CLI. Complete review records and the unused initial revision
remain in indexed preparation evidence. Source checkpoint is
`{summary['prepared_commit'][:7]}`. The [protocol](../../../tools/macos-calibration/displayclock/PLAN.md),
[source audit](source-audit.json), [preparation checks](preparation-checks.json) and
[result summary](result-summary.json) retain the basis.

The next focused control should reverse observer order and test whether the
latency band follows observer presence before proposing any scheduling change.
Do not adopt a permanent display link or treat these instrumented results as
shipping performance. This sparse routed fixture does not establish sustained
60 Hz cadence, resize/workflow acceptance, physical input, displayed pixels or
whole-GPU allocation balance. Features, SDK/app, defaults and the release gate
are unchanged; M3–M7 remain open. The approved desktop scope is consumed, the
desktop is free and no native job remains active.
'''
(d/'README.md').write_text(text);shutil.copy2(q/'result-summary.json',d/'result-summary.json');shutil.copy2(x/'verify_results.py',d/'execution-sources/verify_results.py.txt')
spec_path=r/'specs/macos-release-assessment.md';spec_path.write_text(spec_path.read_text()+f'''\nThe [display-clock off/on result](../docs/reports/macos-display-scheduling/README.md)
passes both cases in {summary['elapsed_seconds']:.3f} seconds, with 18 owned groups retired and 248
joined inputs per case. Same-binary p95 is {off['receipt_to_shown_ms']['p95']:.3f} ms off versus
{on['receipt_to_shown_ms']['p95']:.3f} ms on; both miss 33.3 ms. The difference of run p95 values is
{summary['difference_of_run_p95_on_minus_off_ms']:.3f} ms, about one refresh period, without a repeated or causal claim.
All {on['callback_count']:,} callbacks and full startup/held tails remain retained; actual shown
feedback is within {on['nearest_reported_timestamp_absolute_error_ms']['max']*1000:.3f} microseconds of the nearest reported timestamp.
These are reported clocks, not optical scanout or guaranteed latch opportunities.
Observer neutrality is unsupported; reverse order before proposing a scheduling
change. No permanent link, backend/default/SDK/app/feature or release-gate change.
No release qualification; M3–M7 open. Approved live scope consumed.\n''')
(q/'result-internal-review.json').write_text(json.dumps({'result':'PASS','checks':['Both raw journals independently reclassified through complete inherited and display-clock validators; stored validations match','All18ownedgroups/logs/pins/SDK8321/geometry/configuration remain valid, samebinary+archive','Off0callbacks;on1789records allretained; no filtering of callbacks/lateobservations/gaps','One ordered pair, not causal or repeated performance repair; differenceofrunp95 not paired-difference percentile','Nearest timestamp residual is reported-clock relation, not physical scanout/latch/missedvsync proof','Each p95 ticket separately identified; no phase quantile sum or cross-process timestamp joining','No production/default/gate change; both p95 values still miss33.3; live scopefinished'],'next':'Predeclare reversed observer order to distinguish band/order/observer association; no unchanged retry within sealed scope','unresolved_findings':[]},indent=2)+'\n')
