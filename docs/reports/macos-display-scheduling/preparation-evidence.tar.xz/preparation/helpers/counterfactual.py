from pathlib import Path
import json,hashlib,sys,importlib.util
sys.dont_write_bytecode=True
x=Path(__file__).resolve().parent.parent;q=Path(__file__).resolve().parent/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');code=r/'tools/macos-calibration/displayclock';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(r/'scripts'));sys.path.insert(0,str(x/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('counter_owned',x/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
original=q/'pre-review/testdata/display_clock_impl.m';pins={str(p):sha(p) for p in [original,q/'pre-review/testdata/display_clock.h',code/'testdata/native_fixture.m']};base=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']
for name,argv,expected in [('counter-build',base+['/usr/bin/clang','-fno-objc-arc','-mmacosx-version-min=14.0','-Wall','-Wextra','-Werror','-framework','Cocoa','-framework','QuartzCore','-DDC_IMPL="'+str(original)+'"',str(code/'testdata/native_fixture.m'),'-o',str(q/'counter-fixture')],0),('counter-run',base+[str(q/'counter-fixture')],2)]:
 if name=='counter-run':pins[str(q/'counter-fixture')]=sha(q/'counter-fixture')
 run=g.execute(argv,q,q/name,lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=30,limit=1<<20);(q/(name+'-receipt.json')).write_text(json.dumps({'pins':pins,'run':run,'expected_exit':expected},indent=2)+'\n');assert run['exit_code']==expected and run['error'] is None and run['owned']['group_absent']
assert (q/'counter-run/stderr').read_text()=='numeric boolean detected in native JSON\n';print('PASS original native encoding is refused by the new JSON-type test (ordinary exit2, no crash/window)')
