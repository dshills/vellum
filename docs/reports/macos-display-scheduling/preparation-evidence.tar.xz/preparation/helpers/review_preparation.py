from pathlib import Path
import os,sys,json,hashlib,importlib.util,subprocess
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-grid-capture-repair/preflight-v2')
base=Path(__file__).resolve().parent/'prepared'/'preparation-review';base.mkdir(exist_ok=True)
repo=Path('/Users/dshills/Development/projects/Vellum')
sys.path.insert(0,str(repo/'scripts'))
spec=importlib.util.spec_from_file_location('owned','/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sys.path.insert(0,str(repo/'scripts'))
key=os.environ.get('ANTHROPIC_API_KEY');assert key,'existing Anthropic credential missing'
original=g.child_environment
def env(*args,**kwargs):
 e=original(*args,**kwargs)
 if args and args[0] is True:e['ANTHROPIC_API_KEY']=key
 return e
g.child_environment=env
files=['tools/macos-calibration/displayclock/PLAN.md', 'tools/macos-calibration/displayclock/prepare.py', 'tools/macos-calibration/displayclock/run.py', 'tools/macos-calibration/displayclock/check.py', 'tools/macos-calibration/displayclock/check_test.py', 'tools/macos-calibration/displayclock/testdata/display_clock.h', 'tools/macos-calibration/displayclock/testdata/display_clock_impl.m', 'tools/macos-calibration/displayclock/testdata/display_clock_darwin.go', 'tools/macos-calibration/displayclock/testdata/native_fixture.m', 'docs/reports/macos-display-scheduling/README.md', 'docs/reports/macos-display-scheduling/source-audit.json', 'docs/reports/macos-display-scheduling/preparation-checks.json', 'docs/reports/macos-display-scheduling/execution-sources/build.py.txt', 'docs/reports/macos-display-scheduling/execution-sources/verify_preparation.py.txt', 'specs/macos-release-assessment.md'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(repo/n):sha(repo/n) for n in files};pins[str(Path(__file__).with_name('verify_preparation.py'))]=sha(Path(__file__).with_name('verify_preparation.py'))
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--paths',','.join(files),'--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--chunk-bytes','240000','--max-diff-bytes','240000','--rules',str(base/'rules.json'),'--format','json','--out',str(base/'prism.json')]
r=g.execute(argv,repo,base/'run',lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=180,limit=2<<20)
(base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exit_code':r['exit_code'],'error':r['error'],'seconds':r['seconds'],'files':files}))
assert r['error'] is None and r['exit_code'] in [0,1] and r['owned']['terminal'] and r['owned']['group_absent']
