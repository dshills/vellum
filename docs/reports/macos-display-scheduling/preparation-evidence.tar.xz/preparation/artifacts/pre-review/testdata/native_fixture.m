// Copyright (c) 2026 Davin Hills. SPDX-License-Identifier: MIT.
#define DC_TEST 1
#import "display_clock_impl.m"
#include <assert.h>
static int made,freed,invalidated;static long testWindow=42;static unsigned int testDisplay=7;
@interface FakeDCLink : NSObject {
 id _target;
}
- (instancetype)initWithTarget:(id)target;
- (void)addToRunLoop:(NSRunLoop*)loop forMode:(NSRunLoopMode)mode;
- (void)invalidate;
@end
@implementation FakeDCLink
- (instancetype)initWithTarget:(id)target {if((self=[super init])){_target=[target retain];made++;}return self;}
- (void)addToRunLoop:(NSRunLoop*)loop forMode:(NSRunLoopMode)mode {(void)loop;(void)mode;}
- (void)invalidate {invalidated++;[_target release];_target=nil;}
- (void)dealloc {assert(!_target);freed++;[super dealloc];}
@end
static CADisplayLink *dc_make_link(id target){return (CADisplayLink*)[[[FakeDCLink alloc]initWithTarget:target]autorelease];}
static void dc_identity(long *window,unsigned int *display){*window=testWindow;*display=testDisplay;}
static void reset(void){assert(!dc_link && !dc_target);memset(&dc,0,sizeof(dc));}
int main(void){@autoreleasepool {
 assert(dc_configure(0)==1 && dc_configure(1)==0);assert(dc_start()==1 && dc_start()==0);assert(!dc_link && !dc_target);assert(dc_stop()==1 && dc_stop()==0);assert(dc.count==0);reset();
 assert(dc_configure(1)==1);assert(dc_start()==1);for(int i=0;i<DC_CAP;i++)dc_append(10+i*.02,9+i*.02,9.01+i*.02,.02);assert(dc.count==DC_CAP && !dc.overflow && !dc.invalid);dc_append(10000,10000,10000.01,.02);assert(dc.overflow && dc.count==DC_CAP);assert(dc_stop()==1);assert(!dc_link && !dc_target);reset();
 assert(dc_configure(1)==1 && dc_start()==1);dc_append(1,NAN,2,.01);assert(dc.invalid && dc.count==0);assert(dc_stop()==1);reset();
 assert(dc_configure(1)==1 && dc_start()==1);dc_append(2,1,1.01,.01);dc_append(3,1,1.01,.01);assert(dc.invalid && dc.count==1);assert(dc_stop()==1);reset();
 assert(dc_configure(1)==1 && dc_start()==1);testWindow++;[(DCObserver*)dc_target tick:nil];assert(dc.invalid && dc.count==0);assert(dc_stop()==1);reset();
 assert(dc_configure(1)==1 && dc_start()==1);assert(dc_stop()==1);char *s=dc_snapshot();assert(s && strlen(s)<(2u<<20));free(s);reset();
 }assert(made==freed && made==invalidated);puts("PASS off/on, single-use, capacity/no-eviction, invalid clocks/order, identity drift, snapshot bound, invalidate/release ownership; no NSApplication or window created");return 0;}
