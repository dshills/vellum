//go:build offscreen

package cogent

import (
	"bytes"
	"testing"

	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/ui"
)

func TestChoiceManualKeyboardPointerAndFocus(t *testing.T) {
	for _, kind := range []ui.Kind{ui.RadioGroup, ui.SegmentedControl} {
		t.Run(string(kind), func(t *testing.T) {
			selected := "a"
			edits := 0
			view := func() ui.Node {
				return ui.Node{ID: "root", Kind: ui.Column, Focus: ui.FocusRequest{ID: "choice", Sequence: 1}, Children: []ui.Node{{ID: "choice", Kind: kind, SelectedID: selected, Options: []ui.Option{{ID: "a", Label: "Alpha"}, {ID: "b", Label: "Unavailable", Disabled: true}, {ID: "c", Label: "Charlie"}}, Change: func(e ui.ChangeEvent) { selected = e.SelectedID; edits++ }}, {ID: "after", Kind: ui.Button, Text: "After choices"}}}
			}
			m, _ := simpleManual(t, manualConfig(t, 7), view)
			unitSettle(t, m)
			snapshot, err := m.Snapshot(testContext)
			if err != nil {
				t.Fatal(err)
			}
			if snapshot.Windows[0].FocusedID != "choice" {
				t.Fatal("group initial focus missing", snapshot.Windows[0].FocusedID)
			}
			before, err := m.Capture(testContext, "one")
			if err != nil {
				t.Fatal(err)
			}
			w := m.implementation.find("one")
			send := func(code key.Codes) {
				t.Helper()
				if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Code: code}); err != nil {
					t.Fatal(err)
				}
				unitSettle(t, m)
			}
			send(key.CodeRightArrow)
			if selected != "c" || edits != 1 {
				t.Fatal("arrow did not skip disabled option", selected, edits)
			}
			send(key.CodeRightArrow)
			if selected != "a" || edits != 2 {
				t.Fatal("arrow did not wrap", selected, edits)
			}
			send(key.CodeEnd)
			if selected != "c" {
				t.Fatal("End did not choose last enabled")
			}
			send(key.CodeHome)
			if selected != "a" {
				t.Fatal("Home did not choose first enabled")
			}
			send(key.CodeSpacebar)
			if selected != "a" || edits != 4 {
				t.Fatal("Space cleared selected option or emitted redundant change", selected, edits)
			}
			r := findRecord(w.state.root, "choice")
			box := r.control.choice.buttons["c"].Geom.TotalBBox
			if box.Empty() {
				t.Fatal("option geometry missing")
			}
			for _, typ := range []events.Types{events.MouseDown, events.MouseUp} {
				if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: typ, Button: events.Left, Position: box.Min.Add(box.Size().Div(2))}); err != nil {
					t.Fatal(err)
				}
			}
			unitSettle(t, m)
			if selected != "c" || edits != 5 {
				t.Fatal("measured pointer selection failed", selected, edits)
			}
			after, err := m.Capture(testContext, "one")
			if err != nil {
				t.Fatal(err)
			}
			if bytes.Equal(before.Pix, after.Pix) {
				t.Fatal("selection produced no completed raster change")
			}
			send(key.CodeTab)
			snapshot, err = m.Snapshot(testContext)
			if err != nil {
				t.Fatal(err)
			}
			if snapshot.Windows[0].FocusedID != "after" {
				t.Fatal("group added multiple managed Tab stops", snapshot.Windows[0].FocusedID)
			}
			targets := map[string]accessibilityFocusTarget{}
			accessibilityNativeFocusTargets(w.state.root, "", targets)
			optionID := accessibilityOptionID("choice", "a")
			if !accessibilityApplyFocus(w.state.root, optionID) {
				t.Fatal("visible option focus refused")
			}
			n := r.node
			n.Disabled = true
			if err := syncRecord(r, n); err != nil {
				t.Fatal(err)
			}
			if accessibilityApplyFocus(w.state.root, optionID) {
				t.Fatal("disabled group option focus accepted")
			}
		})
	}
}
