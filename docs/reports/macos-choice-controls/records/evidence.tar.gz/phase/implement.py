from pathlib import Path
import json,hashlib,subprocess
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-choice-controls')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r).strip()
names=['ui/controls.go','ui/node.go','drivers/cogent/controls.go','drivers/cogent/accessibility.go','drivers/cogent/accessibility_workbench.go','drivers/cogent/accessibility_darwin.m','drivers/cogent/cmd/gallery/main.go','drivers/cogent/cmd/gallery/main_test.go','specs/controls.md','specs/macos-completion.md','docs/controls.md']
for n in names:
 f=p/'original'/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((r/n).read_bytes())
def edit(n,fn):
 f=r/n;f.write_text(fn(f.read_text()))
edit('ui/controls.go',lambda s:s.replace('Selector      Kind = "selector"','''Selector      Kind = "selector"
	RadioGroup    Kind = "radio-group"
	SegmentedControl Kind = "segmented-control"''').replace('// Orientation sets a progress bar or separator\'s direction. The zero value\n// selects horizontal; these display controls never join keyboard focus order.','''// Orientation sets display/choice direction. Empty means horizontal except for
// RadioGroup, which defaults to vertical. Progress/separators are not focusable.''').replace('for Selector/Tabs.', 'for Selector/Tabs/RadioGroup/SegmentedControl.').replace('ToggleButton, Selector, Slider','ToggleButton, Selector, RadioGroup, SegmentedControl, Slider').replace('n.Kind != ProgressBar && n.Kind != Separator','n.Kind != ProgressBar && n.Kind != Separator && n.Kind != RadioGroup && n.Kind != SegmentedControl').replace('Orientation belongs only on progress bars and separators','Orientation belongs only on progress, separator and choice controls').replace('if n.Kind == Selector || n.Kind == Tabs {','''if n.Kind == RadioGroup || n.Kind == SegmentedControl {
		if len(n.Options) == 0 || len(n.Options) > MaxChoiceOptions || n.SelectedID == "" {
			return fmt.Errorf("ui: choice group requires 1..%d options and one selected ID", MaxChoiceOptions)
		}
	}
	if n.Kind == Selector || n.Kind == Tabs || n.Kind == RadioGroup || n.Kind == SegmentedControl {''').replace('if n.Kind == Tabs {\n\t\t\t\tfor _, option','if n.Kind == Tabs || n.Kind == RadioGroup || n.Kind == SegmentedControl {\n\t\t\t\tfor _, option'))
edit('ui/node.go',lambda s:s.replace('// Orientation applies to ProgressBar and Separator; empty means horizontal.','// Orientation applies to display/choice controls; RadioGroup defaults vertical.').replace('ProgressBar, Separator, Selector, Slider','ProgressBar, Separator, Selector, RadioGroup, SegmentedControl, Slider'))
edit('drivers/cogent/controls.go',lambda s:s.replace('tabs              *tabState','tabs              *tabState\n\tchoice            *choiceState').replace('case ui.Switch:\n','''case ui.RadioGroup, ui.SegmentedControl:
		widget = core.NewFrame(parent)
		c.choice = &choiceState{buttons: make(map[string]*core.Switch)}
		widget.AsWidget().Styler(func(s *styles.Style) {
			s.Direction = styles.Row
			if choiceVertical(r.node) { s.Direction = styles.Column }
			if r.node.Kind == ui.SegmentedControl { s.Gap.Zero() }
		})
	case ui.Switch:
''',1).replace('''	switch w := r.widget.(type) {
	case *core.Switch:
		// Resetting Checked''','''	if r.control.choice != nil {
		return syncChoice(r, previous)
	}
	switch w := r.widget.(type) {
	case *core.Switch:
		// Resetting Checked''',1).replace('''	if r.control == nil || r.control.tabs == nil {
		return nil
	}''','''	if r.control != nil && r.control.choice != nil { return prepareChoice(r, n) }
	if r.control == nil || r.control.tabs == nil {
		return nil
	}''',1).replace('''func finishControl(r *record, n ui.Node) {
''','''func finishControl(r *record, n ui.Node) {
	if r.control != nil && r.control.choice != nil { finishChoice(r, n) }
''',1).replace('''	if r.node.Kind != ui.Tabs {
		return r.widget, nil
	}''','''	if r.control != nil && r.control.choice != nil {
		return choiceFocusWidget(r)
	}
	if r.node.Kind != ui.Tabs {
		return r.widget, nil
	}''',1))
edit('drivers/cogent/accessibility.go',lambda s:s.replace('''	if _, ok := ui.FocusTarget(ui.FocusScope(accessibilityFocusProjection(root, "")), id); !ok {
''','''	scopeID := id
	if target, ok := targets[id]; ok && target.scopeID != "" { scopeID = target.scopeID }
	if _, ok := ui.FocusTarget(ui.FocusScope(accessibilityFocusProjection(root, "")), scopeID); !ok {
''',1).replace('''		case ui.Selector, ui.Tabs:
''','''		case ui.RadioGroup, ui.SegmentedControl:
			x.Role = "radio-group"
			x.Value = n.SelectedID
			_, x.Focusable = ui.FocusTarget(n, n.ID)
			if r.control != nil && r.control.choice != nil {
				for _, button := range r.control.choice.buttons { x.Focused = x.Focused || button.StateIs(states.Focused) }
			}
		case ui.Selector, ui.Tabs:
''',1).replace('(n.Kind == ui.Selector || n.Kind == ui.Tabs) && n.Change != nil','(n.Kind == ui.Selector || n.Kind == ui.Tabs || n.Kind == ui.RadioGroup || n.Kind == ui.SegmentedControl) && n.Change != nil').replace('''		if n.Kind == ui.Tabs || n.Kind == ui.Selector {
''','''		if r.control != nil && r.control.choice != nil {
			extra, actions := choiceAccessibility(r, x.ID, b, disabled)
			nodes = append(nodes, extra...)
			for id, handler := range actions { handlers[id] = handler }
		}
		if n.Kind == ui.Tabs || n.Kind == ui.Selector {
''',1).replace('''	case ui.Selector, ui.Tabs:
		if action.Kind''','''	case ui.RadioGroup, ui.SegmentedControl:
		if action.Kind != "set" || !choiceOptionEnabled(n, action.Value) { return false }
		if n.SelectedID == action.Value { return true }
		change.SelectedID = action.Value
	case ui.Selector, ui.Tabs:
		if action.Kind''',1).replace('''		if r.node.Kind == ui.Selector {
''','''		if r.control != nil && r.control.choice != nil {
			for _, option := range r.node.Options { bounds(accessibilityOptionID(r.node.ID, option.ID), r.control.choice.buttons[option.ID]) }
		}
		if r.node.Kind == ui.Selector {
''',1))
edit('drivers/cogent/accessibility_workbench.go',lambda s:s.replace('''	focused bool
}''','''	focused bool
	scopeID string // Option targets validate visibility through their managed group.
}''',1).replace('accessibilityFocusTarget{widget, focused}','accessibilityFocusTarget{widget: widget, focused: focused}').replace('accessibilityFocusTarget{button, focused}','accessibilityFocusTarget{widget: button, focused: focused}').replace('''			out[prefix+accessibilityManagedID(root.node.ID)]''','''			if root.control != nil && root.control.choice != nil {
				for _, button := range root.control.choice.buttons { focused = focused || button.StateIs(states.Focused) }
				for _, option := range root.node.Options {
					if option.Disabled { continue }
					if button := root.control.choice.buttons[option.ID]; button != nil {
						out[prefix+accessibilityOptionID(root.node.ID, option.ID)] = accessibilityFocusTarget{widget: button, focused: button.StateIs(states.Focused), scopeID: prefix+accessibilityManagedID(root.node.ID)}
					}
				}
			}
			out[prefix+accessibilityManagedID(root.node.ID)]''',1))
edit('drivers/cogent/accessibility_darwin.m',lambda s:s.replace('if([role isEqual:@"option"])return NSAccessibilityRadioButtonRole;','''if([role isEqual:@"option"])return NSAccessibilityRadioButtonRole;
 if([role isEqual:@"radio-group"])return NSAccessibilityRadioGroupRole;'''))
