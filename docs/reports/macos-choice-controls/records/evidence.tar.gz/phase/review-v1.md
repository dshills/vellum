The initial 18-file choice-controls snapshot needs correction. Quiet pointer focus was lost during managed Tab traversal. Two further capture issues were identified: a local option ID could shadow an ordinary Checkbox semantic value, and ordinary quiet pointer focus was omitted from Manual captures. The author preserved actual offscreen failures for these cases.

Current code uses actual focus ownership for managed traversal, full qualified semantic IDs for capture, and focusable native target ownership without marking ancestor containers focused. The source-stable capture-fixed-v3 author receipt passed. A final source certificate is still required against the producer's final scoped map.

Semantic focus is intentionally a current-ID intent after exact-binding admission. Removal or hiding refuses application; readding the same ID can satisfy the previously admitted focus intent with the current visible, enabled binding. Queued Change and stale action handlers retain exact binding identity and refuse replacements. The current specification and regression make that distinction explicit.

This is a read-only source review. The reviewer did not run tests, builds, native input, a provider, or Git. It does not close physical Mac, VoiceOver, memory, or performance acceptance.
