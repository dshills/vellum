"""Seal choice-control sources and bounded offscreen evidence without qualification of live Mac gates."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-choice-controls');report=r/'docs/reports/macos-choice-controls';records=report/'records'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((p/'source-final-v2.json').read_text());assert len(source['sources'])==19 and all(h(r/n)==v for n,v in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
assert len(prepared)==6198 and prepared==json.loads(Path('/private/tmp/vellum-macos-controls-expansion/qualification.json').read_text())['prepared']
required=['portable-race-final-v2','adapter-race-final-v2','choices-race-final-v2','vet-final-v2','gallery-build-final-v2'];receipts={}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv' not in d:continue
 name=f.stem
 assert d['source_commit']==source['base_commit'] and d['error'] is None and d['source_delta_stable'] and d['prepared_before']==prepared==d['prepared_after'],name
 for channel in ['stdout','stderr']:assert h(p/(name+'.'+channel))==d[channel+'_sha256'],name
 if name in required:assert d['exit_code']==0 and d['source_delta_before']==source['sources']==d['source_delta_after'],name
 receipts[name]={'sha256':h(f),'exit_code':d['exit_code'],'final_source_qualified':name in required}
assert all(name in receipts for name in required)
assert 'group added multiple managed Tab stops' in (p/'controls-v4.stdout').read_text()
assert 'ordinary checkbox captured option value' in (p/'capture-original-v1.stdout').read_text()
assert 'quiet pointer focus omitted' in (p/'capture-original-v1.stdout').read_text()
original=json.loads((p/'capture-original-v1.json').read_text())['source_delta_before']
assert h(p/'manual-before-qualified-index.go.txt')==original['drivers/cogent/manual_offscreen.go']
assert h(p/'choices-capture-original-fixture.go.txt')==original['drivers/cogent/choices_offscreen_test.go']
review=json.loads((p/'review-final-v2.json').read_text());assert review.get('status',review.get('result'))=='APPROVED_SOURCE' and {Path(n).relative_to(r).as_posix():v for n,v in review['reviewed_file_sha256'].items()}==source['sources'] and not review['findings']
initial=json.loads((p/'prism-v1/prism.json').read_text());first=json.loads((p/'prism-v1/process.json').read_text());first_source=json.loads((p/'source-final.json').read_text())['sources']
assert first['exit_code']==1 and first['source_index_stable'] and first['before']==first_source
assert initial['coverage']['complete'] and initial['coverage']['files']==19 and len(initial['findings'])==1 and initial['findings'][0]['id']=='055e6e83e33d43d2'
prism=json.loads((p/'prism-v2/prism.json').read_text());process=json.loads((p/'prism-v2/process.json').read_text());delta={'drivers/cogent/choices.go','drivers/cogent/choices_test.go'}
assert {n for n,v in source['sources'].items()if first_source[n]!=v}==delta
assert process['exit_code']==0 and process['source_index_stable'] and process['before']=={n:source['sources'][n]for n in delta}
assert prism['coverage']['complete'] and prism['coverage']['files']==2 and not prism['findings'] and prism['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert 'late event mutated retired choice during restoration' in (p/'retired-original-v1.stdout').read_text()
assert h(p/'choices-before-retirement-guard.go.txt')==json.loads((p/'retired-original-v1.json').read_text())['source_delta_before']['drivers/cogent/choices.go']
assert json.loads((p/'retired-original-v1.json').read_text())['source_delta_before']['drivers/cogent/choices_test.go']==source['sources']['drivers/cogent/choices_test.go']
# Historical endpoint maps and available source payloads are preserved; only the final
# candidate is claimed as a complete snapshot of every changed repository leaf.
pool={}
for f in sorted(p.rglob('*')):
 if f.is_file() and f.suffix in ['.go','.txt','.md','.m']:pool.setdefault(h(f),[]).append(f.relative_to(p).as_posix())
variants={}
for name in receipts:
 d=json.loads((p/(name+'.json')).read_text())
 variants[name]={n:{'sha256':v,'available_phase_payloads':pool.get(v,[])}for n,v in d['source_delta_before'].items()}
(p/'historical-source-payloads.json').write_text(json.dumps(variants,indent=2)+'\n')
q={'result':'PASS_UI_CHOICE_CONTROLS','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'receipts':receipts,'source_review_sha256':h(p/'review-final-v2.json'),'prism_sha256':h(p/'prism-v2/prism.json'),'prism_initial_sha256':h(p/'prism-v1/prism.json'),'prism_coverage':{'initial':initial['coverage'],'delta':prism['coverage'],'composite_files':19,'resolved_findings':1},'limits':['Nineteen changed source leaves and unchanged6198 prepared hashes are endpoint identities, not a full compiler/SDK/native-binary closure','Five final checks bind all nineteen source leaves; other raw receipts retain their historical source maps and available payloads with explicit missing-payload entries','Native Cocoa role fixtures use inert retained objects without an OS window or attachment','Manual input/raster tests use explicit fonts, colors, workers and clock; they do not establish physical display, OS input, VoiceOver or performance','Gallery compiled only and was not launched; no desktop windows, OS input/settings or general clipboard writes','Pending semantic focus intentionally resolves current visible/enabled same-ID targets; queued Change captures binding identity and refuses replacements','Physical Mac input/VoiceOver, native/GPU heap, sustained performance/endurance and full Mac qualification remain open']}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');records.mkdir(parents=True,exist_ok=True);t=prism['coverage']['tokens'][0];t1=initial['coverage']['tokens'][0]
failures=[n for n,v in receipts.items()if v['exit_code']!=0]
(report/'README.md').write_text(f'''# Radio groups and segmented controls

The public framework adds `ui.RadioGroup` and `ui.SegmentedControl` with 1..64
keyed options and one required accepted SelectedID. Labels may repeat; domain
IDs remain unique within the group. Disabled selected values remain readable.
The retained private native options survive label changes and reordering;
removal retires their binding. Native requests capture ID and binding identity,
recheck enabled ancestry and the latest callback on bounded owner delivery,
and cannot change a new same-ID binding after removal. Pending requests preserve
exclusive accepted selection, including application rejection and mailbox refusal.

Each group contributes one managed Tab stop. Arrows wrap through enabled choices,
Home/End choose the first/last, and Enter/Space request the focused option.
Radio groups default vertical and segmented controls horizontal; both support
explicit Orientation. Native semantic groups publish selected labels; option
radio-button records have generated IDs, boolean selection, measured frames and
focus/press actions. Set uses domain IDs. Focus admission validates a live binding;
pending semantic focus intentionally targets the current visible/enabled same-ID
binding at application time. Disappearance, disabled scope and hidden tabs/modals
refuse focus. Docked/modal namespaces retain this policy.

The gallery shares controlled state among its selector, radio group and segments.
See [the public catalog](../../controls.md) and [contract](../../../specs/controls.md).

## Verification and fixes

The final portable and complete offscreen adapter race suites pass. The focused
choice, capture and gallery regressions pass three repetitions under race;
adapter vet and the native gallery build also pass. The gallery was compiled,
not launched. These five checks bind the same nineteen changed source leaves
and unchanged 6,198 prepared dependency identities.

Actual Manual software input routes arrows, Home/End, Space, measured pointer
selection and Tab after each group, with completed pixel changes. Tests exercise
keyed retention/reorder, current callbacks, disabled/retired requests, owner
mailbox refusal, strict domain semantic actions and stale handlers. Separate
inert Cocoa fixtures verify AXRadioGroup and AXRadioButton roles. Additional
fixtures cover current-ID replacement focus, removed/hidden/disabled refusal,
and qualified option focus in docked modal content.

Internal review found quiet pointer focus was omitted by visual focus-state
flags, breaking subsequent managed Tab navigation. Native focus ownership now
identifies the correct managed group or ordinary control. Manual captures use
focusable native proxies, avoiding ancestor-container focus; active inline-grid
editor reporting retains its separate identity. Another finding showed a local
option ID could shadow an unrelated checkbox in Manual's DomainID index. Full
AX identity and qualified managed lookup now keep captures distinct. The same
collision fixture fails both kinds before the fix (unchecked checkbox falsely
captured as selected true), and the ordinary quiet-pointer fixture fails before
focus capture is corrected. Both pass on final sources. Raw pre-fix failures and
the exact inspected Manual/fixture payloads are retained.

{len(receipts)} raw command receipts and {len(receipts)*2} logs are archived. The
{len(failures)} exit-1 attempts include constructor-type/unused-import compilation
errors, the genuine initial group Tab regression and diagnostic run, the capture
collision/quiet-focus regressions, and an early focus-policy fixture that omitted
explicit invalidation and used the old index lookup, and the genuine retired
native mutation regression. None is a passing result.
Only the five final-source checks qualify this checkpoint. Historical receipts
preserve changed-source hashes and available payloads; a payload index explicitly
marks missing historical leaves. The initial and both final review snapshots remain
immutable. Neither the historical archive nor changed-leaf manifests claim full
compiler, native binary or SDK closure.

## Reviews and remaining gates

The internal source review approved the final nineteen leaves after its findings
were fixed. Prism using Anthropic Claude Sonnet 5.5 first covered nineteen files
in {initial['coverage']['chunks']} chunks, {t1['input']} input/{t1['output']} output
tokens and raw exit 1, with one lifecycle-guard finding. Normal retirement does
not clear the choice state, so its claimed normal-path nil panic was not established.
A narrower direct late-event regression did reproduce native mutation after
retirement. The guard fixes that boundary; the same fixture passes afterward.
The two changed source leaves were then reviewed in a single chunk, {t['input']} input/{t['output']} output tokens, raw exit 0 and no findings.
The seventeen other files retain their reviewed identities, giving complete
nineteen-file composite coverage with the sole finding resolved. A separate internal evidence review binds
this report, final source map, reviews, raw receipts/producers and sealed archive
before commit. The [checkpoint](records/checkpoint.json) binds that review and the
[archive](records/evidence.tar.gz) with its [member index](records/evidence-index.json).
Binaries and caches are excluded. No desktop UI/input/settings or general
clipboard writes occurred. Physical Mac input, human VoiceOver, native/GPU memory,
sustained performance/endurance and full Mac qualification remain open.
''')
(records/'source-review.json').write_bytes((p/'review-final-v2.json').read_bytes())
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in ['.go','.m','.json','.md','.py','.stdout','.stderr','.txt','.log']:continue
 if f.name.startswith('evidence-review') or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in source['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size}for n,f in inputs.items()};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
e={'source_manifest_sha256':h(p/'source-final-v2.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.gz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'review-final-v2.json'),'prism_sha256':h(p/'prism-v2/prism.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e,indent=2))
