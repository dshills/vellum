"""Seal the reviewed polling checkpoint and every retained campaign observation."""
import hashlib, io, json, tarfile
from candidate_run import ROOT, PHASE, identity, sha

records = ROOT/'docs/reports/macos-disclosure/records'
base = json.loads((PHASE/'baseline.json').read_text())
candidate = json.loads((PHASE/'candidate-baseline-v1.json').read_text())
actual = identity()
assert actual['commit'] == base['commit'] == candidate['commit']
assert actual['selected_source'] == candidate['selected_source']
assert actual['prepared'] == base['prepared'] == candidate['prepared']
sources = json.loads((PHASE/'checkpoint-source.json').read_text())['sources']
assert len(sources) == 24 and all(sha(ROOT/n) == h for n,h in sources.items())
reviews = {}
for name, result in [('source-review','APPROVED_SOURCE')]:
    d = json.loads((PHASE/(name+'.json')).read_text())
    assert d.get('result',d.get('status')) == result and not d['findings']
    for key in ['reviewed_artifact_sha256','reviewed_file_sha256']:
        for f,h in d.get(key,{}).items(): assert sha(f) == h, f
    reviews[name] = sha(PHASE/(name+'.json'))
receipts = {}
for name in ['disclosure-race-v5','portable-race-v2','sdk-race-v3','adapter-race-v2','adapter-vet-v2','gallery-build-v2']:
    d = json.loads((PHASE/(name+'.json')).read_text())
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable']
    assert d['prepared_before'] == d['prepared_after'] == base['prepared']
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    assert all(sha(PHASE/(name+'.'+c)) == d[c+'_sha256'] for c in ['stdout','stderr'])
    receipts[name] = sha(PHASE/(name+'.json'))
for name in ['native-v1']:
    d = json.loads((PHASE/(name+'.json')).read_text())
    assert d['exit_code'] == 0 and d['error'] is None and d['source_prepared_stable']
    assert all(sha(PHASE/(name+'.'+c)) == d[c+'_sha256'] for c in ['stdout','stderr'])
    receipts[name] = sha(PHASE/(name+'.json'))
native = json.loads((PHASE/'native-qualification.json').read_text())
assert native['result'] == 'PASS_NATIVE_DISCLOSURE_SELECTORS'
assert native['cycles'] == 20 and native['actions'] == native['samples'] == 40
assert native['stable_heading_identity'] and native['all_heading_hit_tests_match']
assert native['native_receipt_sha256'] == sha(PHASE/'native-v1.json')
assert native['native_stdout_sha256'] == sha(PHASE/'native-v1.stdout')
negative = json.loads((PHASE/'grid-hidden-counterfactual-v1.json').read_text())
assert negative['exit_code'] == 1 and negative['error'] is None and negative['source_delta_stable']
assert negative['prepared_before'] == negative['prepared_after'] == base['prepared']
assert negative['overlay_inputs_before'] == negative['overlay_inputs_after']
assert 'unit settle bound exhausted' in (PHASE/'grid-hidden-counterfactual-v1.stdout').read_text()
assert '--- FAIL: TestDisclosureManagedGridTreeScopesRetainBindings' in (PHASE/'grid-hidden-counterfactual-v1.stdout').read_text()
old=(PHASE/'counterfactual-grid-capture.go').read_text()
assert old.replace('if r.control != nil && r.control.grid != nil {','if r.control != nil && r.control.grid != nil && visible {') == (ROOT/'drivers/cogent/manual_offscreen.go').read_text()
prism = json.loads((PHASE/'prism-v1/prism.json').read_text())
process = json.loads((PHASE/'prism-v1/process.json').read_text())
assert process['exit_code'] == 0 and process['error'] is None and process['source_index_stable']
assert process['before'] == process['after'] == sources
assert prism['coverage']['complete'] and prism['coverage']['files'] == 24 and not prism['findings']
q = {'result':'REVIEWED_MAC_DISCLOSURE','base_commit':base['commit'],'source':sources,
     'baseline_selected_source_files':len(base['selected_source']), 'candidate_selected_source_files':len(candidate['selected_source']),
     'prepared_files':len(base['prepared']), 'native_cycles':20,'native_actions':40,'native_snapshots':40,
     'ordinary_samples':0,'ordinary_latency_targets_met':False,'required_receipts':receipts,'reviews':reviews,
     'native_qualification_sha256':sha(PHASE/'native-qualification.json'),
     'counterfactual_receipt_sha256':sha(PHASE/'grid-hidden-counterfactual-v1.json'),
     'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':0,
     'prism_sha256':sha(PHASE/'prism-v1/prism.json'),
     'limits':['Scoped deterministic controls and actualCocoa selectors, notphysicalinput orhumanVoiceOver.',
               'No newlatency/nativeCPU/memory/GPU/endurance orfullP6/P11/Mac/releasequalification; previous4/6ms targetsfailed.',
               'Selectedsource/prepared receipts are notcompletecompiler/SDK/cacheclosure.']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(exist_ok=False)
for n in reviews: (records/(n+'.json')).write_bytes((PHASE/(n+'.json')).read_bytes())
suffixes = {'.go','.py','.md','.txt','.json','.stdout','.stderr','.log'}
excluded = {'endpoints.json'}
members = {'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes() for p in sorted(PHASE.rglob('*'))
           if p.is_file() and p.suffix in suffixes and p.name not in excluded}
members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
index = {n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
    for n,b in members.items():
        info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz') as archive:
    assert archive.getnames() == list(index)
    for item in archive:
        b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes']
        assert hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
endpoints = {'qualification_sha256':sha(PHASE/'qualification.json'),'source_manifest_sha256':sha(PHASE/'checkpoint-source.json'),
             'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),
             'archive_members':len(members),'source':sources,'reviews':reviews,'prism_sha256':q['prism_sha256']}
(PHASE/'endpoints.json').write_text(json.dumps(endpoints,indent=2)+'\n')
checkpoint = {**q, **endpoints, 'prism_coverage_complete':True,'prism_findings_resolved':True,
              'seal_producer_sha256':sha(__file__),'promotion_producer_sha256':sha(PHASE/'promote.py'),
              'archive_index_verified':True}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
print(json.dumps(endpoints,indent=2))
