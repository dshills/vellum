from pathlib import Path
import json,hashlib,importlib.util,sys,collections
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-raster-commands';p=Path('/private/tmp/vellum-raster-command-core');sdk=Path('/private/tmp/vellum-doclinks-sdk-bd3cbc9/retained SDK/vellum-v0.1.0-alpha.2/drivers/cogent/build/upstream');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=load(q/'commands.json');summary=load(q/'summary.json');assert summary==load(r/'summary.json') and len(d['Frames'])==4 and not d['Overflow'] and sum(len(f['Items']) for f in d['Frames'])==80
stdout=(q/'offscreen/stdout').read_text();assert [json.loads(v.split('RASTER_COMMANDS_JSON=',1)[1]) for v in stdout.splitlines() if 'RASTER_COMMANDS_JSON=' in v]==[d]
for f,row in zip(d['Frames'],summary['frames']):
 assert f['Target']==row['target']=={'Min':{'X':0,'Y':0},'Max':{'X':1500,'Y':1250}} and len(f['Items'])==20 and [v['Index'] for v in f['Items']]==list(range(20))
 assert dict(collections.Counter(v['Type'] for v in f['Items']))==row['command_types'] and row['patch_recorded_rgba']==f['Items'][14]['UniformRGBA']
 assert all(v['Command']==0 and not v['Mask'] and v['HasUniformRGBA'] for v in f['Items'] if v['Type']=='*pimage.Params')
 assert all(v['PathLength']==20 and not v['HasFill'] and not v['HasStroke'] for v in f['Items'] if v['Type']=='*render.Path')
for name,folder,expected in [('offscreen','offscreen',0),('bounds-tests','bounds-tests',1),('bounds-tests-v2','bounds-tests-v2',0)]:
 receipt=load(q/(name+'-receipt.json'));run=receipt['run'];assert run['exit_code']==expected and run['error'] is None and run['owned']['terminal'] and run['owned']['group_absent'] and run['logs_complete'] and run['pins_stable']
 for file,h in receipt['inputs'].items():assert sha(Path(file))==h
 for stream,h in run['logs'].items():assert sha(q/folder/stream)==h['sha256']
original=(sdk/'paint/renderers/rasterx/renderer.go').read_text();hook='func (rs *Renderer) Render(r render.Render) render.Renderer {';assert (p/'paint/renderers/rasterx/renderer.go').read_text()==original.replace(hook,hook+'\n\trs.vellumCaptureCommands(r)');assert (p/'paint/renderers/rasterx/vellum_commands.go').read_bytes()==(t/'tools/macos-calibration/rastercommands/testdata/commands.go').read_bytes();assert (p/'paint/pimage/pimage.go').read_bytes()==(sdk/'paint/pimage/pimage.go').read_bytes() and not (p/'paint/pimage/uniform_fill.go').exists()
s=importlib.util.spec_from_file_location('commands_sdk_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS4offscreenframes80scalarrecords,originalroutedfullpixeloracle;2recorderbounds/callback/snapshotmethods;2success+1retainedsetupfailure ownedgroups;source/log/SDK8321pins. No executedfillcount/nativecost/gate/adoptionclaim.')
