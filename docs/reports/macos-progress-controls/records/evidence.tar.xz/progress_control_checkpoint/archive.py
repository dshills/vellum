from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-progress-controls');P=Path('/private/tmp/vellum-macos-progress-controls');D=R/'docs/reports/macos-progress-controls/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());disposition=json.loads((P/'prism-disposition.json').read_text());assert disposition['result']=='RESOLVED_NO_SOURCE_CHANGE'and not disposition['remaining_unresolved'];assert process['exit_code']==1 and process['error']is None and process['source_index_stable']
assert disposition['prism_sha256']==sha(P/'prism-v1/prism.json')and disposition['prism_process_sha256']==sha(P/'prism-v1/process.json')and disposition['finding_id']=='0ca3d660b04e4bb3'
assert review['coverage']['complete'] and review['coverage']['files']==18 and len(review['findings'])==1 and review['findings'][0]['id']=='0ca3d660b04e4bb3';assert review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())and disposition['sources']==sources
internal=json.loads((P/'internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==sources
summary=json.loads((P/'final-summary.json').read_text());assert summary['result']=='PASS_SCOPED_PROGRESS_SHAPES' and summary['sources']==sources
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.cpu','.png'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['progress_control_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Reviewed18progress-control sources;10 passing code/build gates, four actual Cocoa stages for two readonly progress shapes, stable identities/geometry and actual zero mainthread native cleanup;6211 prepared leaves unchanged. SourceV1/nativeV1 review failures preserved; affectedGallery/nativebuild V2 gates reconcileunchangedearlier packages. One complete Anthropic55Prism CLI review produced2LLMchunks and one conditionaloutside-hunk orientation falsepositive; rawexit1/finding preserved and internally rejected against existing full-source guard plus matching passedtests. No provider rerun. Native/binary predecessor receipts bound; no physical/human/fullP6/P11/distribution qualification.'},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':18,'prism_findings':1,'prism_resolved_false_positives':1,'prism_unresolved_findings':0,'prism_cli_invocations':1,'prism_calls':review['coverage']['llmCalls'],'prism_disposition_sha256':sha(P/'prism-disposition.json'),'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in['sources','checks']}))
