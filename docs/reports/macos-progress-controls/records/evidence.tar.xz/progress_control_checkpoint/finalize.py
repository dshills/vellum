"""Finalize completed progress-control evidence without widening native scope."""
from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/private/tmp/vellum-progress-controls')
P = Path('/private/tmp/vellum-macos-progress-controls')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(name):
    return json.loads((P / name).read_text())

candidate = read('candidate-source.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == candidate['base_commit']
assert len(candidate['sources']) == 18
assert all(sha(R / name) == digest for name, digest in candidate['sources'].items())
review = read('source-review.json')
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
assert review['sources'] == candidate['sources']
native = read('native-summary.json')
assert native['result'] == 'PASS_SCOPED_NATIVE_PROGRESS_SHAPES'
receipt = read('native-progress.json')
assert receipt['exit_code'] == 0 and receipt['error'] is None
assert receipt['source_prepared_stable'] and receipt['binary_stable']
assert native['receipt_sha256'] == sha(P / 'native-progress.json')
assert native['source_review_sha256'] == receipt['source_review_sha256'] == sha(P / 'source-review.json')
assert native['runtime_baseline_sha256'] == receipt['runtime_baseline_sha256'] == sha(P / 'runtime-baseline.json')
assert receipt['binary_sha256'] == sha(P / 'gallery-v2')
baseline = read('runtime-baseline.json')
assert len(baseline['prepared']) == 6211
for name, digest in baseline['sources'].items():
    assert sha(R / name) == digest
for name, digest in baseline['prepared'].items():
    assert sha(R / 'drivers/cogent/build' / name) == digest

# Earlier unchanged package tests remain relevant; V2 reruns the only changed
# package after source-review repairs. Full build binds all current code files.
gates = {
    'progress-ui-race': ['ui/'],
    'progress-dpi-race': ['drivers/cogent/controls.go', 'drivers/cogent/accessibility.go', 'drivers/cogent/progress_shapes_test.go', 'drivers/cogent/progress_shapes_offscreen_test.go'],
    'progress-native-roles': ['drivers/cogent/progress_shapes_darwin_test.go'],
    'progress-portable-race-v2': ['ui/'],
    'progress-portable-vet': ['ui/'],
    'progress-sdk': ['scripts/release-sdk_test.py', 'ui/'],
    'progress-adapter-full-race': ['drivers/cogent/controls.go', 'drivers/cogent/accessibility.go', 'drivers/cogent/internal/acceptance/'],
    'progress-adapter-vet': ['drivers/cogent/controls.go', 'drivers/cogent/accessibility.go', 'drivers/cogent/internal/acceptance/'],
    'progress-gallery-v2': ['drivers/cogent/cmd/gallery/'],
    'progress-native-build-v2': ['drivers/', 'ui/', 'scripts/'],
}
checks = {}
for name, prefixes in gates.items():
    d = read(name + '.json')
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable']
    assert d['prepared_before'] == d['prepared_after'] == baseline['prepared']
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    required = {n: h for n, h in candidate['sources'].items() if any(n.startswith(prefix) for prefix in prefixes)}
    assert required
    assert all(d['source_delta_before'][n] == d['source_delta_after'][n] == h for n, h in required.items()), name
    for stream in ['stdout', 'stderr']:
        assert sha(P / (name + '.' + stream)) == d[stream + '_sha256']
    checks[name] = {'receipt_sha256': sha(P / (name + '.json')), 'argv': d['argv'], 'elapsed_seconds': d['elapsed_seconds'], 'source_files_bound': required}

failure = read('progress-portable-race.json')
assert failure['exit_code'] == 1
assert 'operation not permitted' in (P / 'progress-portable-race.stdout').read_text()
report = R / 'docs/reports/macos-progress-controls/README.md'
text = report.read_text()
old = '''uses the exported kinds. Full suites, final reviews and native acceptance are
pending. The dedicated progress-smoke mode isolates a four-value Cocoa sequence,
read-only setter refusal, retained identity/geometry and zero-resource cleanup.
Its build and live run are pending the earlier native campaigns.'''
new = '''uses the exported kinds. Ten code/build gates pass, including the full
portable and adapter race suites, vet, relocated SDK fixture, affected Gallery
V2 race tests and final native build. The initial portable race run could not
bind its test Unix socket under the sandbox; the permitted rerun passes and both
receipts are retained. Internal review repaired native readiness and preservation
of driver errors joined with cancellation, with a regression test.

The dedicated progress-smoke mode completed four ordered values in a real Cocoa
window. Both named progress indicators retain native identity and positive
geometry, publish accepted values, refuse read-only setters, and report actual
main-thread cleanup with stopped callbacks and zero pending/native/AX/window
resources. It runs only after the rendering benchmark process group is reaped.
Native geometry/value observations are separate from software pixel tests;
physical interaction and human VoiceOver were not exercised. Internal final
review and one Anthropic Claude Sonnet 5.5 Prism review precede commit.'''
assert old in text
report.write_text(text.replace(old, new))
sources = {n: sha(R / n) for n in candidate['sources']}
manifest = {'base_commit': candidate['base_commit'], 'sources': sources}
(P / 'checkpoint-source.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = {**manifest, 'result': 'PASS_SCOPED_PROGRESS_SHAPES', 'checks': checks, 'prepared_files': 6211, 'native_samples': 4, 'native_shapes': 2, 'native_cleanup_zero': True, 'native_summary_sha256': sha(P / 'native-summary.json'), 'source_review_sha256': sha(P / 'source-review.json'), 'build_binary_sha256': sha(P / 'gallery-v2'), 'prior_fixture_findings_resolved': ['PROGRESS-01', 'PROGRESS-02'], 'physical_input_qualified': False, 'human_voiceover_qualified': False, 'full_p6_qualified': False, 'full_p11_qualified': False, 'mac_distribution_qualified': False}
(P / 'final-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS ten code/build gates and four native progress stages; eighteen files bound')
