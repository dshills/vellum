"""Reviewed progress UI acceptance after reaped rendering benchmark campaign."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
R=Path('/private/tmp/vellum-progress-controls');P=Path('/private/tmp/vellum-macos-progress-controls');S=Path('/private/tmp/vellum-macos-span-storage');Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment

def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def identity():
 names={n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n}|{n for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().split('\0')if n}
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':{n:sha(R/n)for n in sorted(names)},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
def canceled():return(Q/'stop-live').exists()
review=json.loads((P/'source-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and not review['unresolved_findings']
assert all(sha(R/n)==h for n,h in review['sources'].items())
before=identity();assert len(before['prepared'])==6211
build=json.loads((P/'progress-native-build-v2.json').read_text());derived=json.loads((P/'native-binary-v2.json').read_text());exe=P/'gallery-v2'
assert build['exit_code']==0 and not build['error']and build['source_delta_stable']and build['source_commit']==before['commit']and build['prepared_before']==build['prepared_after']==before['prepared']
assert all(derived[k]==v for k,v in build.items())and derived['produced_file_sha256']==sha(exe)and derived['produced_file_bytes']==exe.stat().st_size
assert all(build['source_delta_before'][n]==build['source_delta_after'][n]==h for n,h in review['sources'].items())
assert json.loads((Q/'testing-authorization.json').read_text())['live_window_input_performance_tests_allowed']
(P/'runtime-baseline.json').write_text(json.dumps(before,indent=2)+'\n')
predecessor=S/'native-queue.json';deadline=time.monotonic()+17000
while not predecessor.exists():
 if canceled():raise InterruptedError('human returned; do not launch native UI fixture')
 if time.monotonic()>deadline:raise TimeoutError('rendering terminal receipt missing')
 time.sleep(2)
prior=json.loads(predecessor.read_text());assert prior['exit_code']==0 and prior['error']is None
summary=json.loads((S/'native-summary.json').read_text());assert summary['result']=='MEASURED_PAIRED_STAGE60_NATIVE_GPU_FRAMES'and summary['processes']==40 and summary['ordinary_samples']==4800
assert summary['summary_sha256']==sha(S/'native-comparison/summary.json')
assert identity()==before and not canceled(),'source changed or native tests canceled'
assert derived['produced_file']==str(exe) and derived['produced_file_sha256']==sha(exe) and derived['produced_file_bytes']==exe.stat().st_size,'native binary changed before launch'
argv=[str(exe),'-progress-smoke'];d={'argv':argv,'source_commit':before['commit'],'runtime_baseline_sha256':sha(P/'runtime-baseline.json'),'source_review_sha256':sha(P/'source-review.json'),'producer_sha256':sha(__file__),'build_receipt_sha256':sha(P/'progress-native-build-v2.json'),'derived_binary_receipt_sha256':sha(P/'native-binary-v2.json'),'binary_sha256':sha(exe),'predecessor_receipt_sha256':sha(predecessor),'predecessor_summary_sha256':sha(S/'native-summary.json'),'authorization_sha256':sha(Q/'testing-authorization.json'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':None,'error':None};child=None;start=time.monotonic()
try:
 with(P/'native-progress.stdout').open('xb')as so,(P/'native-progress.stderr').open('xb')as se:
  child=subprocess.Popen(argv,cwd=R,env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
  (P/'native-progress.owned-process.json').write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'owner_pid':os.getpid(),'argv':argv,'binary_sha256':d['binary_sha256'],'started_utc':d['started_utc']},indent=2)+'\n')
  while child.poll()is None:
   if canceled():raise InterruptedError('human returned; stop native progress UI')
   if time.monotonic()-start>65:raise TimeoutError('native progress watchdog expired')
   time.sleep(.25)
  d['exit_code']=child.returncode
except BaseException as error:d['error']={'type':type(error).__name__,'message':str(error)}
finally:
 if child is not None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait(timeout=5);d['exit_code']=child.returncode
 d['elapsed_seconds']=time.monotonic()-start;d['source_prepared_stable']=identity()==before
 d['binary_stable']=derived['produced_file_sha256']==sha(exe) and derived['produced_file_bytes']==exe.stat().st_size
 for c in ['stdout','stderr']:
  f=P/('native-progress.'+c);d[c+'_sha256']=sha(f)if f.exists()else None
 (P/'native-progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
assert d['exit_code']==0 and d['error']is None and d['source_prepared_stable'] and d['binary_stable']
records=[json.loads(l)for l in(P/'native-progress.stdout').read_text().splitlines()if l.startswith('{')]
samples=[r for r in records if r.get('event')=='vellum.progress.sample'];completed=[r for r in records if r.get('event')=='vellum.progress.completed'];cleanup=[r for r in records if r.get('event')=='vellum.progress.cleanup']
assert len(samples)==4 and [r['stage']for r in samples]==[0,1,2,3]and [r['fraction']for r in samples]==[0,.25,.75,1]
assert all(r['readonly_setters_refused']and len(r['elements'])==2 for r in samples)
assert len(completed)==1 and completed[0]['stages']==4 and completed[0]['retained_shapes']==2
assert len(cleanup)==1 and cleanup[0]['observed'];c=cleanup[0]['native_cleanup'];assert c['MainThread']and c['CleanupObserved']and c['CallbacksStopped']and c['PendingCallbacks']==c['NativeOutstanding']==c['AccessibilityWindows']==0 and not c['WindowTitles']
(P/'native-summary.json').write_text(json.dumps({'result':'PASS_SCOPED_NATIVE_PROGRESS_SHAPES','samples':4,'shapes':2,'native_cleanup_zero':True,'receipt_sha256':sha(P/'native-progress.json'),'runtime_baseline_sha256':sha(P/'runtime-baseline.json'),'source_review_sha256':sha(P/'source-review.json'),'physical_input_qualified':False,'human_voiceover_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False},indent=2)+'\n');print('Completed scoped native progress shapes and zero cleanup',flush=True)
