NEEDS_FIX — two bounded native-smoke issues.

1. Require snapshot.Reachable and NativeWindow before accepting the two progress elements; current matching element predicates can pass an incomplete native AX tree.
2. The progress main branch clears every error matching context.Canceled, including joined real driver failures. Normalize only exact expected cancellation and preserve other failures. A pure joined-error regression is sufficient.

The public passive-control contract, early meter type, literal text, managed style override/restore, readonly semantics and source tests otherwise look sound. Reusing the existing acknowledged/cancelable owner helper for staged model posts is a useful strengthening. No tests/native/provider/source mutation occurred and no pending qualification is inferred.
