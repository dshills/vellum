# Frame polling evidence review

APPROVED_EVIDENCE; no material findings.

Current six source/spec/report leaves match the checkpoint manifest. The four candidate Go hashes match the independent source and protocol approvals, code checks and candidate build. Nine raw command receipts are hash-bound: eight successful endpoints and the preserved first fixture failure. The five selected prelaunch checks and both builds completed before the native comparison; recorded 710-source and 6,198-prepared vectors are stable.

Independently reparsed all 40 native logs and matched their result records and progress order. Each process has 128 guarded warmups, 120 unique completed tickets, one callback per measured event and terminal zero dropped/pending counts. All 4,800 samples are retained. The 2,400 paired observations match complete geometry and callback dictionaries exactly; cardinalities include 400/50/8 and variable-row 408/51/8. No profiling or detail mode is enabled, and external process observations occur only after end.

All 11 timing metrics equal their raw native fields and same-ticket UI-work sums. Independently recomputed nearest-rank pooled/per-run percentiles, mean, sample SD, CV and per-run-p95 variation, plus process allocation/malloc distributions. Every distribution matches the stored summary. Reported allocation p50 reductions round to 13.3%, 19.3%, 18.0% and 17.2%; UI timing is mixed. All 40 individual processes fail the unchanged 4 ms p95 / 6 ms p99 targets.

The local observer benchmark reparses to five observations per method/history size. Its medians and allocation counts match the report. Already-collected synthetic ordinary records exclude collection and detail-copy cost and native windows. The initial failed test assumed failure was collectible before terminal; corrected v2 tests pending then retirement, preserving the refusal.

The report/spec accurately distinguish reduced diagnostic pressure from isolated shipping-runtime performance or framework-only allocation savings. No native/GPU memory, physical presentation, sustained P6/P11 or full Mac qualification follows. The captured maps are not full compiler/SDK/cache closure or continuous host-isolation proof. Archive/index/checkpoint links and the planned provider review are outside this pre-sealing certificate.

Only stdlib read/hash/JSON/statistics processing was performed; no producer, test/build/prepare, native/UI/provider or Git execution. Absolute artifact identities are in evidence-review.json.
