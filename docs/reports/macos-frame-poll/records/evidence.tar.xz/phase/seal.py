"""Seal the reviewed polling checkpoint and every retained campaign observation."""
import hashlib, io, json, tarfile
from candidate_run import ROOT, PHASE, identity, sha

records = ROOT/'docs/reports/macos-frame-poll/records'
base = json.loads((PHASE/'baseline.json').read_text())
candidate = json.loads((PHASE/'candidate-baseline-v1.json').read_text())
actual = identity()
assert actual['commit'] == base['commit'] == candidate['commit']
assert actual['selected_source'] == candidate['selected_source']
assert actual['prepared'] == base['prepared'] == candidate['prepared']
sources = json.loads((PHASE/'checkpoint-source.json').read_text())['sources']
assert len(sources) == 6 and all(sha(ROOT/n) == h for n,h in sources.items())
reviews = {}
for name, result in [('source-review','APPROVED_SOURCE'), ('protocol-review','APPROVED_PROTOCOL'), ('evidence-review','APPROVED_EVIDENCE')]:
    d = json.loads((PHASE/(name+'.json')).read_text())
    assert d.get('result',d.get('status')) == result and not d['findings']
    for key in ['reviewed_artifact_sha256','reviewed_file_sha256']:
        for f,h in d.get(key,{}).items(): assert sha(f) == h, f
    reviews[name] = sha(PHASE/(name+'.json'))
receipts = {}
for name in ['poll-race-v2','adapter-race-v1','adapter-vet-v1','loadedgrid-race-v1','observer-benchmark-v1']:
    d = json.loads((PHASE/(name+'.json')).read_text())
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable']
    assert d['prepared_before'] == d['prepared_after'] == base['prepared']
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    assert all(sha(PHASE/(name+'.'+c)) == d[c+'_sha256'] for c in ['stdout','stderr'])
    receipts[name] = sha(PHASE/(name+'.json'))
for name in ['build-grid-baseline-v1','build-grid-candidate-v1','comparison-v1']:
    d = json.loads((PHASE/(name+'.json')).read_text())
    assert d['exit_code'] == 0 and d['error'] is None and d['source_prepared_stable']
    assert all(sha(PHASE/(name+'.'+c)) == d[c+'_sha256'] for c in ['stdout','stderr'])
    receipts[name] = sha(PHASE/(name+'.json'))
comparison = json.loads((PHASE/'comparison/qualification.json').read_text())
assert comparison['result'] == 'PASS_MATCHED_COMPARISON'
assert comparison['processes'] == 40 and comparison['ordinary_samples'] == 4800
assert comparison['warm_target_met'] == {'baseline':False,'candidate':False}
assert comparison['summary_sha256'] == sha(PHASE/'comparison/summary.json')
prism = json.loads((PHASE/'prism-v1/prism.json').read_text())
process = json.loads((PHASE/'prism-v1/process.json').read_text())
assert process['exit_code'] == 0 and process['error'] is None and process['source_index_stable']
assert process['before'] == process['after'] == sources
assert prism['coverage']['complete'] and prism['coverage']['files'] == 6 and not prism['findings']
q = {'result':'REVIEWED_FRAME_POLL_MAC_COMPARISON','base_commit':base['commit'],'source':sources,
     'selected_source_files':len(base['selected_source']),'prepared_files':len(base['prepared']),
     'processes':40,'ordinary_samples':4800,'ordinary_latency_targets_met':False,
     'required_receipts':receipts,'reviews':reviews,
     'comparison_qualification_sha256':sha(PHASE/'comparison/qualification.json'),
     'observer_qualification_sha256':sha(PHASE/'observer-qualification.json'),
     'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':0,
     'prism_sha256':sha(PHASE/'prism-v1/prism.json'),
     'limits':['Observer pressure changes across variants; timing mixed, unchanged4/6ms targets fail.',
               'Process allocation includes helpers/runtime; no exact native/GPU memory or shipping-runtime speedup attribution.',
               'Scoped ordinary grid campaign is not fullP6/P11/Mac/human/physical/release qualification or completecompiler/SDK/cache closure.']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(exist_ok=False)
for n in reviews: (records/(n+'.json')).write_bytes((PHASE/(n+'.json')).read_bytes())
suffixes = {'.go','.py','.md','.txt','.json','.stdout','.stderr','.log'}
excluded = {'endpoints.json'}
members = {'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes() for p in sorted(PHASE.rglob('*'))
           if p.is_file() and p.suffix in suffixes and p.name not in excluded}
members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
index = {n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
    for n,b in members.items():
        info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz') as archive:
    assert archive.getnames() == list(index)
    for item in archive:
        b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes']
        assert hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
endpoints = {'qualification_sha256':sha(PHASE/'qualification.json'),'source_manifest_sha256':sha(PHASE/'checkpoint-source.json'),
             'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),
             'archive_members':len(members),'source':sources,'reviews':reviews,'prism_sha256':q['prism_sha256']}
(PHASE/'endpoints.json').write_text(json.dumps(endpoints,indent=2)+'\n')
checkpoint = {**q, **endpoints, 'prism_coverage_complete':True,'prism_findings_resolved':True,
              'seal_producer_sha256':sha(__file__),'promotion_producer_sha256':sha(PHASE/'promote.py'),
              'archive_index_verified':True}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
print(json.dumps(endpoints,indent=2))
