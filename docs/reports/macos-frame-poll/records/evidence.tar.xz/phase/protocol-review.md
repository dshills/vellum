# Quiet-host frame-poll comparison protocol

APPROVED_PROTOCOL for the exact producers, common helpers, build/source/authorization and frozen prelaunch artifacts in the JSON map. Native/observer children stay in the outer owned group. The protocol binds exactly4approved leaves,128closed guard1 warmups,120events/process,40interleaved processes and exact paired geometry with unchanged4/6ms targets.

The selected5code receipts require explicit drift/prepared/overlay predicates, not exit0alone; the parent records those before admission and freezes stable builds/binary identities. The code-run expired-host wording is stale narrative, while live authority is the explicit fresh availability receipt.

Observer changes alter diagnostic pressure, so this is an instrumented-fixture comparison and not isolated shipping-runtime speedup. No campaign outcome, test/native/provider execution or seal is supplied by this review.
