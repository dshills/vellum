from pathlib import Path
import json,sys
def restore(value,lookup):
 if isinstance(value,dict)and set(value)=={'$input_map'}:
  name=value['$input_map'];assert name.startswith('input-maps/')and '..'not in name and not name.startswith('/')
  m=json.loads(lookup(name));base=json.loads(lookup('shared-input-base.json'));keys=list(base);out={}
  for ref in m['order']:
   key=keys[ref]if type(ref)is int else ref
   out[key]=m['changes'][key]if key in m['changes']else base[key]
  return out
 if isinstance(value,dict):return{k:restore(v,lookup)for k,v in value.items()}
 if isinstance(value,list):return[restore(v,lookup)for v in value]
 return value
if __name__=='__main__':
 root=Path(sys.argv[1]);name=sys.argv[2];assert not Path(name).is_absolute()and '..'not in Path(name).parts
 value=restore(json.loads((root/name).read_bytes()),lambda n:(root/n).read_bytes())
 sys.stdout.buffer.write((json.dumps(value,indent=2)+'\n').encode())
