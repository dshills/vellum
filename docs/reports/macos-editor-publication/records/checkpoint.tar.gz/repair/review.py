from pathlib import Path
import hashlib,json,sys,time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
review=read(R/'internal-checkpoint-review.json');scope=read(R/'review-scope.json')
assert review['approved']and review['checkpoint_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items())
assert review['staged_diff_sha256']==scope['staged_diff_sha256']
diff=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,capture_output=True,check=True).stdout
assert hashlib.sha256(diff).hexdigest()==scope['staged_diff_sha256']and len(diff)==scope['bytes']and len(diff)<160000
assert not(R/'prism.json').exists()and not(R/'prism-command.json').exists()
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','160000','--max-diff-bytes','160000','--rules',str(R/'prism-rules.json'),'--format','json','--out',str(R/'prism.json')]
start=time.monotonic();r=run_child(argv,cwd=T,timeout=180,capture_output=True,check=False)
(R/'prism.stdout').write_bytes(r.stdout);(R/'prism.stderr').write_bytes(r.stderr)
out={'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'staged_diff_sha256':scope['staged_diff_sha256'],'staged_diff_bytes':len(diff)}
(R/'prism-command.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
