# Quiescent disabled multiline editor publication

The new d1232b5 native structural catalogue independently passes50inputs42states,
including repaired rejected close focus, subsequent Delete and accepted removal.
Its text/modal sibling fails at editor-disabled after35inputs19source-asserted
states and91.385seconds. It records48 startup refusals,952 completed Frame calls
and one final context-deadline failure, Unavailable=false, no disabled snapshot
or modal acceptance. The campaign stays failed/sealed; both processes retire and
whole source/prepared/SDK post-boundaries pass. Do not replay either case.

Source diagnosis: native publication falls back to the previous active editor
when it loses focus on disable. publishClient calls syncEditorFromWidget even
for this inactive client. Disabled alone always requests restoration, dirties
the owner, and schedules another publication after refresh. This can continuously
invalidate completed-frame snapshot eligibility. The native trace directly proves
completed Frames and the timeout; source plus the actual publication-path
counterfactual supplies the causal loop proof, not a logged Snapshot error code.

Fix the disabled no-op: if disabled and the binding revision, visible epoch,
selection epoch, visible bytes, anchor and focus exactly match the authoritative
model, return without model mutation or invalidation. Native publication still
runs with active=false. A second regression exposes that syncEditor did not
restore private selection when model epochs/text were unchanged. Disabled-only
selection restoration now compares actual anchor/focus in both committed and
composing paths. Core's input edit seam refuses disabled widgets, so composing
restoration uses an owner-only model setter that temporarily clears the private
widget's Disabled flag and restores it on return, following the existing grid
adapter precedent. The control admission flag remains disabled throughout;
native backend publication remains inactive. Enabled caret behavior is unchanged. Every disabled
text/selection mismatch and stale binding epoch retains restoration. Enabled
editor/IME/history admission and lifecycle guards remain. No cache, public API or readiness/retry
change is introduced.

The regression calls actual textWindow.publish through a fake native backend,
without an NSApplication/window or protocol/IME claim. After disabling a retained
client, repeat publication8times and require zero owner dirt/restore plus inactive
backend publication and unchanged model/history. Separate legacy widget-text,
selection and owner model-epoch changes must still request restoration once,
then quiesce after reconciliation, including composing selection. The unchanged
source fails the initial four subcases; the first candidate passes three but
still fails selection restoration; the second candidate fixes ordinary selection
but still fails composing selection. Final counterfactuals cover six cases,
including an interior combining-grapheme preedit caret and owner unmark while
disabled, with the widget still disabled after every reconciliation/publication.
The first fixture fails compilation on an unused import and is preserved
separately. Model Install is correctly performed inside Journal.Replace.

Internal source/checkpoint reviews, full affected software checks, one bounded
Prism Anthropic Claude Sonnet5.5 review and local commit precede a fresh separately
reviewed text/modal native scope. Keep the independent structural pass and failed
text record distinct. Full Mac/M3–M7, physical input/human accessibility/display,
native pixels/presentation/resources and final SDK/rights stay open.
