"""Unchanged independent catalogue oracles plus bounded frame correlation."""
from pathlib import Path
import hashlib,importlib.util,json
Q=Path(__file__).resolve().parent
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
oracles={kind:module(kind+'_oracle',Q/(kind+'_oracle.py'))for kind in ['structure','text']}
def need(ok,message):
 if not ok:raise ValueError(message)
def integer(v):return type(v)is int and 0<=v<1<<63
def validate(kind,stdout,stderr):
 need(kind in oracles,'fixed catalogue kind')
 pins=json.loads((Q/'oracles.json').read_bytes())
 for name,p in pins.items():need(hashlib.sha256((Q/name).read_bytes()).hexdigest()==p['sha256']==hashlib.sha256(Path(p['original']).read_bytes()).hexdigest(),'unchanged independent authored oracle')
 result=oracles[kind].validate(stdout,stderr)
 records=[json.loads(line)for line in stdout.splitlines()if line.startswith(b'{')];need(len(records)==1,'one catalogue record');d=records[0]
 entries=d['Availability'];need(type(entries)is list and 1<=len(entries)<=1024,'bounded complete visibility correlation')
 last_tag=0;last_sequence=0;last_visible=None;completed=set();refusals=0
 for index,e in enumerate(entries,1):
  need(set(e)=={'Index','Before','BeforeIssued','FrameIssued','Outcome','VisibilityError','FrameError'},'exact correlation schema')
  need(type(e['Index'])is int and e['Index']==index and integer(e['BeforeIssued'])and integer(e['FrameIssued']),'correlation order/scalars')
  need(type(e['VisibilityError'])is str and type(e['FrameError'])is str,'copied errors')
  v=e['Before'];need(set(v)=={'Known','Visible','Sequence'}and type(v['Known'])is bool and type(v['Visible'])is bool and integer(v['Sequence']),'copied visibility schema')
  need(e['BeforeIssued']>=last_tag,'session request order')
  if e['Outcome']=='refused':
   need(not completed and e['FrameError']and e['FrameIssued']==e['BeforeIssued'],'startup admission refusal without frame request');refusals+=1
  else:
   need(e['Outcome']=='completed'and not e['FrameError']and not e['VisibilityError'],'all admitted frames complete, no unavailable retry or hidden error')
   need(v['Known']is True and v['Sequence']>0,'actual Mac attachment observation')
   need(e['FrameIssued']==e['BeforeIssued']+1 and e['FrameIssued']>last_tag,'one original explicit frame request')
   need(v['Sequence']>=last_sequence and(v['Sequence']!=last_sequence or v['Visible']==last_visible),'attachment-local sequence consistency')
   last_sequence=v['Sequence'];last_visible=v['Visible'];completed.add(e['FrameIssued'])
  last_tag=e['FrameIssued']
 used=[s['Snapshot']['Frame']for s in d['Steps']]+[i['Before']['Frame']for i in d['Inputs']]
 need(set(used)<=completed,'every observed/input frame has a completed correlated request')
 need(d['Session']['Issued']>last_tag,'final snapshot and closure follow the last frame')
 result.update(visibility_correlations=len(entries),completed_frame_requests=len(completed),startup_refusals=refusals,visibility_does_not_prove_readiness=True)
 return result
