# Native catalogue after controlled-close focus repair

Run the full unchanged structural50-input42-state and text/modal68-input33-state
records against clean committed d1232b5. This runtime repairs actual tab-header
focus after a rejected close. It has internal reviews, one complete Anthropic
Claude Sonnet5.5 Prism review with zero findings, full driver/gallery race checks,
vet/build and final actual-source focused routing. Source, prepared dependencies
and SDK are frozen for this new scope. No product or OS setting changes here.

The earlier90fc432 native scope stays FAILED/sealed:43 inputs/36 source-asserted
completed states, then a rejected-close focus failure. Its130 correlations were
50 startup admission refusals and80 completed Frames; no unavailable Frame. The
text process was never dispatched. Earlier structural/text/visibility failures
and the separate passing clean/popup visibility scenario also remain immutable.

Reuse the same private Go-only correlation from that scope, byte-for-byte. Before
each existing explicit Frame, retain copied native Visibility and actual request
IDs/outcomes in fixed1024 storage, copied only after joining the one worker.
Visibility is not a readiness gate. Actual Frame unavailable remains terminal;
no failed acquisition retry, hidden error, modified action, oracle or golden is
allowed. A completed Frame after a refused initial Visibility request can cause
a conservative instrumentation/startup failure; retain/seal it as such rather
than infer a rendering defect. The original consumer lifetime/close/join bounds
and every authored model/focus/geometry/input/history/refusal assertion remain.

Recheck the affected gallery race, vet and build using actual checkout native
units (Objective-C is not replaced by Go overlays), Go1.25.6/GOMAXPROCS2, stage86,
external dependency manifest and retained source-built786a SDK native module.
Reuse the full driver-root race only by explicit compiled-input correspondence:
runtime promotion is byte-identical, test promotion is gofmt-only and separately
passes actual-source focused race; all other735-set compiled inputs are unchanged.
Independent unchanged oracles and4 synthetic positives/32 malformed refusals
remain required. Synthetic controls are not native evidence.

After internal source/controller review, prepare a fresh immutable exact plan
and obtain separate admission. Hold the shared live lease, run structure then
text serially in separate owned children,120seconds/4MiB each,30-minute launch
deadline rechecked after boundary hashing immediately before each launch. Check
whole clean source/prepared/SDK/compiler/binary/runtime boundaries and raw
ownership/absence. Stop at the first child or full oracle/correlation failure;
seal each launched case and the campaign permanently. No old-case reset or retry.

This acceptance-only continuation makes no product/SDK/prepared/OS-input or
preference change and needs no repeated provider call. Any significant product
fix gets its own software/internal/Prism checkpoint. Native Go FIFO routing does
not prove physical/OS input, IME, human VoiceOver, pixels/presentation, native
deallocation/resource/endurance, distribution rights/final SDK or full Mac.
