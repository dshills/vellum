"""Fabricated validator controls, never native evidence."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent
sys.path.insert(0,str(Q));import validate as v
def load(kind):
 root=Q.parent/('macos-acquisition-diagnostics-4ce6ba4'if kind=='structure'else'macos-text-modal-9854e5d')
 previous=sys.modules['validate'];sys.modules['validate']=v.oracles[kind]
 try:m=v.module(kind+'_controls',root/'validation_controls.py')
 finally:sys.modules['validate']=previous
 return m
def fixture(kind):
 d=load(kind).fixture()
 def shift(obj):
  if type(obj)is dict:
   for k,x in obj.items():
    if k=='Frame'and type(x)is int:obj[k]=x*4+2
    else:shift(x)
  elif type(obj)is list:
   for x in obj:shift(x)
 shift(d)
 frames=sorted(set([s['Snapshot']['Frame']for s in d['Steps']]+[p['Before']['Frame']for p in d['Inputs']]))
 d['Availability']=[dict(Index=i,Before=dict(Known=True,Visible=True,Sequence=1),BeforeIssued=f-1,FrameIssued=f,Outcome='completed',VisibilityError='',FrameError='')for i,f in enumerate(frames,1)]
 d['Session']['Issued']=frames[-1]+1
 return d
def encode(d):return(json.dumps(d)+'\n').encode()
def main():
 out={'synthetic_only':True,'native_executed':False,'cases':{}}
 for kind in ['structure','text']:
  d=fixture(kind);positive=v.validate(kind,encode(d),b'')
  # A sampled false bit cannot override a genuine completed-frame oracle.
  false=copy.deepcopy(d)
  for e in false['Availability']:e['Before']['Visible']=False
  v.validate(kind,encode(false),b'')
  changes={
   'missing-correlations':lambda r:r.pop('Availability'),
   'missing-frame-origin':lambda r:r['Availability'].pop(),
   'wrong-index':lambda r:r['Availability'][0].update(Index=2),
   'unknown-native-state':lambda r:r['Availability'][0]['Before'].update(Known=False),
   'wrapped-sequence':lambda r:r['Availability'][-1]['Before'].update(Sequence=0),
   'state-changed-without-sequence':lambda r:r['Availability'][-1]['Before'].update(Visible=False),
   'two-frame-requests':lambda r:r['Availability'][0].update(BeforeIssued=0),
   'unavailable-retry':lambda r:r['Availability'][0].update(Outcome='unavailable',FrameError='occluded'),
   'hidden-frame-error':lambda r:r['Availability'][0].update(FrameError='failed'),
   'hidden-visibility-error':lambda r:r['Availability'][0].update(VisibilityError='closed'),
   'made-up-frame':lambda r:r['Steps'][0]['Snapshot'].update(Frame=r['Steps'][0]['Snapshot']['Frame']+1),
   'refusal-after-frames':lambda r:r['Availability'][-1].update(Outcome='refused',FrameError='pending',BeforeIssued=r['Availability'][-1]['FrameIssued']),
   'closed-before-final-frame':lambda r:r['Session'].update(Issued=1),
   'wrong-model':lambda r:r['Steps'][0]['Model'].update(Unknown=1),
   'missing-original-step':lambda r:r['Steps'].pop(),
   'missing-original-input':lambda r:r['Inputs'].pop(),
  }
  refused={}
  for name,change in changes.items():
   r=copy.deepcopy(d);change(r)
   try:v.validate(kind,encode(r),b'')
   except(ValueError,KeyError,TypeError,IndexError)as e:refused[name]=str(e)
   else:raise AssertionError(kind+' admitted '+name)
  out['cases'][kind]={'positive':positive,'sampled_false_bit_does_not_override_completed_frame':True,'refusals':refused}
 paths=[Path(__file__),Q/'validate.py',Q/'oracles.json',Q/'structure_oracle.py',Q/'text_oracle.py',Q.parent/'macos-acquisition-diagnostics-4ce6ba4/validate.py',Q.parent/'macos-acquisition-diagnostics-4ce6ba4/validation_controls.py',Q.parent/'macos-text-modal-9854e5d/validate.py',Q.parent/'macos-text-modal-9854e5d/validation_controls.py']
 out['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
 p=Q/'validation-controls.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'synthetic_only':True,'positive_cases':4,'negative_cases':32}))
if __name__=='__main__':main()
