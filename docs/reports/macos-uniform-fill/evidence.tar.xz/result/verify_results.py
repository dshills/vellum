from pathlib import Path
import json,hashlib,sys,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-uniform-fill';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=load(q/'summary.json');assert d==load(r/'summary.json') and d['outcome']=='REJECT_PRIVATE_FILL_CANDIDATE_NO_USEFUL_GAIN' and d['native_attempts']==0 and not d['adopted'] and not d['gate_changed']
for group in ['candidate_pins','source_fact_pin']:assert all(sha(Path(p))==h for p,h in d[group].items())
for name in ['pixel-tests','fill-bench']:
 receipt=load(q/(name+'-receipt.json'));run=receipt['run'];assert run['exit_code']==0 and run['error'] is None and run['owned']['terminal'] and run['owned']['group_absent'] and run['logs_complete'] and run['pins_stable']
 for p,h in receipt['inputs'].items():assert sha(Path(p))==h
 for stream,h in run['logs'].items():assert sha(q/name/stream)==h['sha256']
rows=d['benchmark_rows'];assert len(rows)==6 and {v['reported_GOMAXPROCS'] for v in rows}=={14} and all(v['allocs_per_op']==v['bytes_per_op']==0 for v in rows)
for mode,want in [('stdlib',[151044,162019,142556]),('rowcopy',[147623,142023,146508])]:assert [v['ns_per_op'] for v in rows if v['variant']==mode]==want
s=importlib.util.spec_from_file_location('fill_sdk_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS rejectedprivatecandidate,3pixelmethods/1200seededcases;6rawCPUbenchrows/0alloc/observed14suffix;2ownedgroups/log/source/SDK8321pins;no native attempt/adoption/gatechange.')
