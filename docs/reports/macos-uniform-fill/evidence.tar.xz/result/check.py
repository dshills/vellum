from pathlib import Path
import sys,importlib.util,json,hashlib
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;p=Path('/private/tmp/vellum-uniform-fill-core');code=Path('/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/uniformfill');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(x):sha(x) for folder in [p/'paint/pimage',code] for x in folder.rglob('*') if x.is_file()};pins[str(p/'go.mod')]=sha(p/'go.mod');pins[str(p/'go.sum')]=sha(p/'go.sum')
sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('fill_owned',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
for name,tail in [('pixel-tests',['test','-run','^TestOpaqueUniform','-count=1','./paint/pimage']),('fill-bench',['test','-run','^$','-bench','^BenchmarkOpaqueUniform$','-benchtime=200ms','-count=3','./paint/pimage'])]:
 argv=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/bin/sh',str(q.parent/'macos-app-examples/go-check')]+tail
 r=g.execute(argv,p,q/name,lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=120,limit=2<<20);(q/(name+'-receipt.json')).write_text(json.dumps({'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({name:{k:r[k] for k in ['exit_code','error','seconds']}}),flush=True)
 assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent']
 print((q/name/'stdout').read_text()[-3000:],flush=True)
