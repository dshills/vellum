from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def git(*args):return run_child(['git',*args],cwd=T,timeout=30,capture_output=True,check=True).stdout
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
provider=json.loads((W/'review-scope.json').read_bytes());docs=json.loads((W/'post-provider-docs.json').read_bytes())['paths']
assert {str(T/n)for n in docs}=={k for k,v in provider['source_hashes'].items()if sha(k)!=v}
assert all(sha(W/'provider-source'/n)==provider['source_hashes'][str(T/n)]for n in docs)
paths=provider['paths']+['docs/reports/macos-frame-unavailable/records/'+n for n in ['results.json','checkpoint.tar.gz','manifest.json','archive.json']]
git('add','--',*paths);git('diff','--cached','--check');assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)and not git('diff','--name-only')
assert not git('ls-files','--others','--exclude-standard')
diff=git('diff','--cached','--binary');(W/'final-staged.diff').write_bytes(diff)
d={'paths':paths,'files':{n:sha(T/n)for n in paths},'base_commit':git('rev-parse','HEAD').decode().strip(),'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'provider_runtime_source_unchanged':True,'post_provider_changed_paths':docs,'raw_evidence_added_for_internal_review':paths[16:]}
(W/'final-scope.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'files':len(paths),'bytes':len(diff),'sha256':d['staged_diff_sha256']}))
