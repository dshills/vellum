from audit import *
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD and not git(C,'status','--porcelain')and not git(T,'diff','--cached','--name-only')
checks=['focused-v2','driver-v2','gallery-v2','vet-v2','build-v2','prepare-unit-final','prepare-candidate-final','prepare-candidate-repeat']
for n in checks:
 r=read(Q/(n+'.json'));assert passing(r)and all(sha(k)==v for k,v in r['source_pins'].items()),n
 for stream,info in r['logs'].items():
  p=Q/n/stream;assert p.stat().st_size==info['bytes']and sha(p)==info['sha256'],(n,stream)
c=source(C);s=source(T);pc=prepared(C);pt=prepared(T);sdk=Path(read(P/'plan.json')['sdk']);sv=vector(sdk)
assert len(c)==5421 and len(s)==5428
assert len(pc)==6274 and digest(pc)=='1021da5dbcf15218a54212bc62ec0d465dea168c148753c6c52281133482dc56'
assert len(pt)==6276 and pt==read(Q/'prepare-candidate-final-prepared.json')==read(Q/'prepare-candidate-repeat-prepared.json')and digest(pt)=='1cf2dfa8fd75d4c78cfe7e347ac81bf6e66d7c4072e9134e682897de4835d1ed'
assert len(sv)==7880 and digest(sv)=='4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26'
assert all(c[n]==v for n,v in s.items()if n.startswith('prototypes/')and n.endswith('.go'))
overlay_matches(s,pt,sdk)
binary=read(Q/'build-v2.json')['binary'];assert sha(binary['path'])==binary['sha256']
r={'result':'FRAME_UNAVAILABLE_SOFTWARE_BOUNDARY_PASS','base_commit':HEAD,'canonical_source':c,'candidate_source':s,'go_source':{n:v for n,v in s.items()if n.endswith('.go')},'canonical_prepared':pc,'prepared':pt,'sdk':str(sdk),'sdk_files':sv,'binary':binary,'native_executed':False,'all_current_overlay_replacements_equal_candidate':True,'physical_input_verified':False,'closed_full_mac_gates':[]}
(Q/'software-source.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'result':r['result'],'canonical_source':len(c),'candidate_source':len(s),'go_files':len(r['go_source']),'prepared':len(pt),'prepared_sha256':digest(pt),'sdk_files':len(sv)}))
