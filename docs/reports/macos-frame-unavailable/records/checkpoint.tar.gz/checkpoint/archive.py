from audit import *
import gzip,io,tarfile
R=T/'docs/reports/macos-frame-unavailable/records';review=read(Q/'internal-prism-disposition.json');assert review['approved']and not review['unresolved_findings']
files={}
def add(p,n):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in files and not n.startswith('/')and '..'not in Path(n).parts;files[n]=p
for name in read(R/'results.json')['checks']:
 add(Q/(name+'.json'),'checks/'+name+'.json')
 for stream in ['stdout','stderr','owned.json']:
  p=Q/name/stream
  if p.is_file():add(p,'checks/'+name+'/'+stream)
for directory in ['candidate','candidate-v1','original','original-source','versions','provider-source']:
 for p in sorted((Q/directory).rglob('*')):
  if p.is_file():add(p,directory+'/'+p.relative_to(Q/directory).as_posix())
for n in ['design.md','implement.py','write_tests.py','fix_source_details.py','files.json','stage86.py','stage86.json','check.py','source_check.py','cancel-negative.go','source-negative-core.go','source-negative-composer.go','check-syntax-failure.json','negative-overlay.json','fixed-overlay.json','source-negative-overlay.json','source-fixed-overlay.json','overlay.json','vet-core-equivalence.json','vet-core-equivalence-final.json','internal-candidate-review.json','internal-candidate-review-v2.json','prepare_owned.py','prepare-candidate-final-prepared.json','prepare-candidate-repeat-prepared.json','audit.py','software_boundary.py','software-source.json','document.py','post-provider-docs.json','stage.py','review-scope.json','staged.diff','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','archive.py','final_stage.py','ready_commit.py','post_promotion.py']:
 add(Q/n,'checkpoint/'+n)
for n in ['vet-core-baseline.json','vet-core-equivalence.json']:add(P/n,'retained-core-baseline/'+n)
for n in ['stdout','stderr','owned.json']:add(P/'vet-core-baseline'/n,'retained-core-baseline/'+n)
for n in read(Q/'review-scope.json')['paths']:add(T/n,'source/'+n)
add(R/'results.json','source/docs/reports/macos-frame-unavailable/records/results.json')
origins={n:str(p)for n,p in sorted(files.items())};(Q/'member-origins.json').write_text(json.dumps(origins,indent=2)+'\n');add(Q/'member-origins.json','checkpoint/member-origins.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(v['bytes']for v in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(v['bytes']<=10<<20 for v in manifest.values())
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as tar:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=tar.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=read(Q/'prism.json');cmd=read(Q/'prism-command.json')
a={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'native_executed':False,'synthetic_measured_manual_output':True,'automatic_resumption_implemented':False,'full_mac_complete':False,'provider':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':p['coverage']['llmCalls'],'complete':p['coverage']['complete'],'cli_exit_code':cmd['exit_code'],'retained_findings':len(p['findings']),'discarded_comments':len(p['discarded']),'internal_disposition_approved':True,'dispositions_sha256':sha(Q/'internal-prism-disposition.json'),'post_review_docs':read(Q/'post-provider-docs.json')['paths']}}
(R/'archive.json').write_text(json.dumps(a,indent=2)+'\n');(Q/'archive-result.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a))
