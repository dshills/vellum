from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
read=lambda p:json.loads(Path(p).read_bytes())
def base(n):return run_child(['git','show','HEAD:'+n],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode()
checks={}
for name in ['cancel-negative','cancel-fixed','focused-v1','focused-final','driver-final','gallery-final','vet-final','vet-core-final','build-final','source-negative','source-fixed','focused-v2','driver-v2','gallery-v2','vet-v2','vet-core-v2','build-v2','prepare-unit-final','prepare-candidate-final','prepare-candidate-repeat']:
 d=read(Q/(name+'.json'));checks[name]={k:d.get(k)for k in ['exit_code','seconds','error','logs_complete','pins_stable','owned','logs','prepared_files','prepared_sha256']}
for name in ['cancel-fixed','source-fixed','focused-v2','driver-v2','gallery-v2','vet-v2','build-v2','prepare-unit-final','prepare-candidate-final','prepare-candidate-repeat']:assert checks[name]['exit_code']==0 and checks[name]['owned']['group_absent']
assert checks['cancel-negative']['exit_code']==checks['source-negative']['exit_code']==checks['vet-core-v2']['exit_code']==1
R=T/'docs/reports/macos-frame-unavailable';(R/'records').mkdir(parents=True,exist_ok=True)
(R/'records/results.json').write_text(json.dumps({'checks':checks,'core_vet':read(Q/'vet-core-equivalence-final.json'),'stage86':read(Q/'stage86.json'),'native_executed':False,'synthetic_measured_manual_output':True,'automatic_resumption_implemented':False,'closed_full_mac_gates':[]},indent=2)+'\n')
(R/'README.md').write_text('''# Typed unavailable Frame results

`DesktopSession.Frame` now returns a detached `DesktopCompositionError` for failed
composition. `errors.Is(err, cogent.ErrDesktopFrameUnavailable)` identifies a
checked known surface yield; `errors.As` exposes its original `Failure` text and
`Unavailable` flag. Existing error text is preserved. Context cancellation and
window/session closure keep their own identities. Native errors already reduced
to trace strings are not reconstructed.

Frame keeps its existing first-composition contract. An unavailable or failed
composition terminal publishes no frame capability. Each request consumes one
actual terminal and releases capacity exactly once. No automatic retry or requeue
is added; existing bounded acquisition and trace
polling remain unchanged.
An application can explicitly request a later frame after a meaningful lifecycle
or application event; neither shown/focused state nor this sentinel proves a
drawable is ready. Architecture review found no authoritative availability event
supporting safe automatic pending/resumption. That feature remains deferred.

Stage86 classifies only coherent existing acquisition sequences: one identical
first/last Occluded or Timeout status, or two attempts starting Lost/Outdated and
ending Occluded/Timeout/Lost/Outdated. Unknown, backend/view/encoder/pass errors,
success-null, offscreen and legacy outcomes remain generic failures. The scalar
propagates through measured composer, Core and `FrameSample`; false values are
omitted from JSON. Ordinary acquisition/release/ownership and measured timing
regions are unchanged. Metadata work remains charged as UI work. Contradictory
submitted/unavailable metadata fails closed.

An actual pre-change Manual FIFO regression reproduces lost `context.Canceled`
identity. The fix checks cancellation after taking the actual terminal trace,
before returning composition status or publishing a token. Queued cancellation
keeps capacity busy through input/owner terminals. The same regression then passes.
Cancellation does not retract dispatched or committed work. A late cancellation
can race an already-committed reply; publication is prevented when cancellation
is observed before terminal collection, rather than promised for every canceled wait.
Labelled synthetic measured-drawer Manual fixtures cover unavailable/no token,
no automatic requeue, stale tokens, a separately requested successful frame,
fatal errors, cancellation before/after composition, retirement, and detached
metrics copying. These exercise real software FIFO/composition paths with
synthetic measured results; they do not establish native GPU acceptance.

Initial internal review found source-detail failures could manufacture or retain
the availability flag. Exact counterfactual tests reproduce seven failing
negative subcases with three passing controls. The fix captures eligibility from
original terminal metadata and clears it on Core/composer diagnostic failure,
preserving existing first-error text and draw/end order. Those controls and final
formatted focused race checks pass. The unapproved first review, first candidate,
negative/fixed receipts and controller syntax failure before child creation are
retained; no failure is relabelled as a pass. Direct Surface.TryCreateView factory
failure injection remains a coverage gap; renderer-reported view errors are tested.

Complete driver-root package (`.`) and gallery race suites, focused GPU/composer/
Core/protocol regressions, affected-package default vet, native gallery build,
prepare unit tests and two deterministic offline stage86 preparations pass.
Prepared output has6276 files. Default broader Core vet still fails with the same
12 retained baseline diagnostics (10 unkeyed composites,2 unreachable code); no
new diagnostic appears. No unfiltered Core test suite is run. See [results](records/results.json).

No new native case runs at this checkpoint. The [older diagnostic run](../macos-acquisition-diagnostics/README.md)
failed16/15 with actual Occluded196609 before these typed changes. It does not
qualify the new public error mapping, full50/42 structural flow, physical input,
native pixels, presentation, IME/VoiceOver, display, performance, memory or soak.
Old failed native scopes stay sealed. Full M2/M5 and M3–M7 remain open.

Evidence uses Go1.25.6 ARM64/GOMAXPROCS2 offscreen checks and the controlled
source-built native archive786a for the build only. Current non-prototype Go,
native support and prepared bytes match the checked immutable-SDK overlay; the
SDK's native-library override does not qualify the checkout default cached library.
The7880-file retained SDK stays unchanged. No SDK refresh or public release occurs.
Prism Anthropic Claude Sonnet5.5 review, independent dispositions and final bounded
archive/commit review are required before commit. The [archive](records/checkpoint.tar.gz)
and [manifest](records/manifest.json) will retain source, checks and reviews without
executables or SDK copies. Follow the [Mac delivery plan](../../../specs/macos-delivery.md).
''')
note='''

### Typed unavailable Frame checkpoint

The [typed terminal result](../docs/reports/macos-frame-unavailable/README.md)
preserves the first-composition contract and classifies checked known surface
yields through `DesktopCompositionError`/`ErrDesktopFrameUnavailable`. No failed
frame token, automatic acquisition/requeue or readiness inference is introduced.
Cancellation identity is checked only after the actual trace terminal; capacity
and lifetime rules remain bounded. Late cancellation may race a committed reply
and does not retract prior work. Contradictory metadata and source-detail
faults fail closed. Full driver-root/gallery race, focused controls, affected vet,
build and deterministic stage86 preparation pass; default Core vet retains12
baseline diagnostics. Synthetic measured Manual results are software evidence.
No new native case runs; the earlier16/15 and41/35 failures stay sealed. Automatic
pending/resumption needs an authoritative drawable-availability event that is
not established. Continue remaining native catalogue/typed-error acceptance with
explicit availability admission and no retry loop. M2/M5/M3–M7 and all unchanged
performance/release gates remain open.
'''
for n in ['specs/macos-delivery.md','specs/macos-completion.md','specs/control-acceptance.md']:
 s=base(n).replace('Next implement bounded visibility-aware\nFrame scheduling and deterministic hidden/occluded/visible/cancel coverage before\na distinct native admission. Do not fabricate completion or spin on acquisition.','That checkpoint proposed visibility-aware\nFrame scheduling. The typed-terminal decision below preserves the existing\ncontract while an authoritative drawable-ready event remains unestablished.')
 (T/n).write_text(s+note)
n='docs/desktop-integration.md';(T/n).write_text(base(n)+'''

### Typed unavailable results

`errors.Is(err, cogent.ErrDesktopFrameUnavailable)` identifies checked known
surface unavailability from `DesktopSession.Frame`. `errors.As` can extract a
`*cogent.DesktopCompositionError` with detached `Failure` text and `Unavailable`
metadata. The existing error string is preserved; no string parsing is used for
classification. Generic/legacy failures do not acquire this identity. Context
cancellation and closed-window/session errors retain their standard identities.

An unavailable or failed composition terminal publishes no frame capability and
releases capacity after its actual input/owner/composition terminal. Cancellation
does not retract dispatched or committed work, and its return may race an already-
committed reply. Publication is blocked when cancellation is observed before
terminal collection; a late canceled wait does not erase a committed capability.
Frame does not retry or wait automatically.
An application can explicitly request another Frame following a meaningful
lifecycle/application event; shown/focused state and this error do not prove
drawable readiness. The new scalar is also available on `FrameSample`, omitted
from JSON whenfalse. Contradictory submission flags and source-diagnostic faults
stay failed generic terminals. Timing/ownership/first-composition contracts remain
unchanged. See the [checkpoint and verification limits](reports/macos-frame-unavailable/README.md).
''')
print(json.dumps({'documents_written':True,'native_executed':False,'prepared_files':6276}))
