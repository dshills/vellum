from pathlib import Path
import difflib,hashlib,json,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'drivers/cogent';U=D/'build/upstream';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((Z/'internal-candidate-review.json').read_bytes());assert review['approved']and not review['unresolved_findings'];assert all(sha(p)==v for p,v in review['inputs'].items())
files=json.loads((Z/'files.json').read_bytes());original={};output={};parts=[]
for n in files:
 old=Z/'original'/n;new=Z/'candidate'/n;before=old.read_text()if old.is_file()else'';after=new.read_text()
 assert (sha(U/n)if(U/n).is_file()else None)==(sha(old)if old.is_file()else None)
 original[n]=sha(old)if old.is_file()else None;output[n]=sha(new)
 parts.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+n if old.is_file()else'/dev/null',tofile='b/'+n))
p=D/'native/patches/frameunavailable';p.mkdir(exist_ok=False)
patch=p/'0086-typed-unavailable-composition.patch';patch.write_text(''.join(parts));(p/'original-hashes.json').write_text(json.dumps(original,indent=2)+'\n');(p/'output-hashes.json').write_text(json.dumps(output,indent=2)+'\n')
(p/'README.md').write_text('''# Typed unavailable composition terminals (stage 86)

A detached scalar marks a checked known surface yield through measured gpudraw,
composer and Core tracing. AcquisitionOutcome.IsUnavailable conservatively
validates the existing one/two-attempt protocol; it is not a retry promise.
Unknown/backend/view/encoder/pass/success-null/offscreen/legacy failures are not
classified. Ordinary acquisition, timing regions and native ownership are unchanged.
No automatic acquisition, timer, polling, presentation, request or history is added.

Submitted/unavailable contradictions fail closed. Source-details validation cannot
manufacture or retain availability classification: eligibility is captured from
original measured terminal metadata, and composer/Core diagnostic failures clear
it. Existing first-failure text precedence and actual draw/end order are retained.
Intermediate failed composition stays terminal under the existing trace contract.
New tickets and overriding cancel/fatal/retirement terminals cannot inherit the flag.

The public Go adapter returns DesktopCompositionError matching
ErrDesktopFrameUnavailable, without a completed frame token. It consumes the actual
trace terminal before honoring an already-canceled context, preserving identity
and request ownership. FrameSample copies the scalar; false values are omitted
from JSON. No backend error identity already reduced to strings is restored.

Applications may explicitly request another Frame after a meaningful lifecycle or
application event. Shown/focused state and this result do not prove a drawable is
ready. Automatic pending/resumption requires an authoritative availability event
that is not established here. Synthetic measured Manual fixtures are software
protocol evidence; old native failed scopes remain immutable and unqualified.
''')
manifest=D/'native/dependencies.json';data=json.loads(manifest.read_bytes());dependency=next(d for d in data['dependencies']if d['name']=='upstream');assert dependency['stages'][-1]['patches'][0]['file'].endswith('0085-measured-acquisition-outcomes.patch')
relative=p.relative_to(D).as_posix();dependency['stages'].append({'origin':'drivers/cogent/'+relative,'inputs':relative+'/original-hashes.json','outputs':relative+'/output-hashes.json','patches':[{'file':relative+'/'+patch.name,'sha256':sha(patch)}]});manifest.write_text(json.dumps(data,indent=2)+'\n')
r={'stage':86,'files':files,'input_hashes':original,'output_hashes':output,'patch_sha256':sha(patch),'candidate_review_sha256':sha(Z/'internal-candidate-review.json')};(Z/'stage86.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'stage':86,'patch_bytes':patch.stat().st_size,'files':len(files)}))

test=D/'prepare_test.py';text=test.read_text();assert 'list(range(1, 86))'in text;test.write_text(text.replace('list(range(1, 86))','list(range(1, 87))'))
