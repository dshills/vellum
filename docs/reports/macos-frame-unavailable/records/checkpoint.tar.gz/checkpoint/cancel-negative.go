//go:build offscreen

package cogent

import (
 "context"
 "errors"
 "testing"
)

func TestDesktopFrameCancellationContextIdentityNegative(t *testing.T) {
 s,m,_,w,_:=desktopFixture(t)
 ctx,cancel:=context.WithCancel(context.Background());defer cancel()
 r,err:=s.submit(ctx,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
 if _,err=m.implementation.find("one").core.Step(testContext,1);err!=nil{t.Fatal(err)}
 cancel();s.cancel(r)
 out:=desktopPump(t,s,m,r)
 if !errors.Is(out.err,context.Canceled){t.Fatalf("canceled Frame lost context identity: %v",out.err)}
}
