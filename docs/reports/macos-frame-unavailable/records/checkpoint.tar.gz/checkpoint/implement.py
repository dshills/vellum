from pathlib import Path
import sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
def edit(n,old,new,source=False):
 p=(T if source else Q/'candidate')/n;s=p.read_text();assert old in s,(n,old);p.write_text(s.replace(old,new))
p=Q/'candidate/gpu/surface_acquisition.go';p.write_text(p.read_text()+'''
// IsUnavailable identifies a coherent known surface-acquisition yield. It does
// not promise that a later attempt will succeed or authorize automatic retry.
// Unknown, backend/view errors, missing textures and offscreen/legacy outcomes
// are not classified as unavailable. The existing bounded retry is unchanged.
func (o AcquisitionOutcome) IsUnavailable() bool {
 if o.Source != AcquisitionSurface || o.Stage != AcquisitionUnavailable { return false }
 switch o.Attempts {
 case 1:
  return o.FirstStatus == o.LastStatus && (o.LastStatus == wgpu.SurfaceGetCurrentTextureStatusOccluded || o.LastStatus == wgpu.SurfaceGetCurrentTextureStatusTimeout)
 case 2:
  if o.FirstStatus != wgpu.SurfaceGetCurrentTextureStatusLost && o.FirstStatus != wgpu.SurfaceGetCurrentTextureStatusOutdated { return false }
  switch o.LastStatus {
  case wgpu.SurfaceGetCurrentTextureStatusOccluded, wgpu.SurfaceGetCurrentTextureStatusTimeout, wgpu.SurfaceGetCurrentTextureStatusLost, wgpu.SurfaceGetCurrentTextureStatusOutdated:
   return true
  }
 }
 return false
}
''')
edit('gpu/gpudraw/acquisition.go','timing.AcquireNS = elapsed','timing.AcquireNS = elapsed\n timing.Unavailable = false')
edit('gpu/gpudraw/acquisition.go','if pass == nil {','if pass == nil {\n timing.Unavailable = outcome.IsUnavailable()')
edit('system/composer/timing.go','Failure                                                  string','// Unavailable is a checked acquisition yield, never a submitted frame or a retry guarantee.\n Unavailable bool `json:",omitempty"`\n Failure                                                  string')
edit('core/frame_trace.go','Failure                                                 string','// Unavailable carries checked acquisition evidence only for a failed composition.\n Unavailable bool `json:",omitempty"`\n Failure                                                 string')
edit('core/frame_trace.go','submitted := timing.Supported && timing.Submitted && timing.Failure == ""','submitted := timing.Supported && timing.Submitted && timing.Failure == "" && !timing.Unavailable\n p.Unavailable = timing.Unavailable && timing.Supported && !timing.Submitted && timing.Failure != ""')
edit('core/frame_trace.go','p.Failure = message','p.Failure = message\n p.Unavailable = false')
edit('core/frame_trace.go','p.Failure = "armed frame did not reach composition"','p.Failure = "armed frame did not reach composition"\n p.Unavailable = false')
edit('core/frame_trace.go','p.Failure = "traced input did not post owner work"','p.Failure = "traced input did not post owner work"\n p.Unavailable = false')
edit('drivers/cogent/desktop_session.go','''if !sample.Completed || sample.Failure != "" {
		reply.err = errors.New("cogent: desktop composition: " + sample.Failure)
	} else if err := r.ctx.Err(); err != nil {
		reply.err = err''','''if err := r.ctx.Err(); err != nil {
  reply.err = err
 } else if !sample.Completed || sample.Failure != "" || sample.Unavailable {
  reply.err = &DesktopCompositionError{Failure: sample.Failure, Unavailable: sample.Unavailable && !sample.Completed && sample.Failure != ""}''',True)
edit('drivers/cogent/desktop_session.go','// waits for its completed native composition. It is not an OS presentation fence.','''// waits for its completed native composition. It is not an OS presentation fence.
// A checked drawable-acquisition yield returns a DesktopCompositionError matching
// ErrDesktopFrameUnavailable. It publishes no frame capability and does not retry.
// A caller may make a new request after a meaningful lifecycle/application event;
// neither a shown/focused window nor this error proves drawable readiness.''',True)
edit('drivers/cogent/frame_metrics.go','Failure                                                 string','Unavailable bool `json:",omitempty"`\n Failure                                                 string',True)
edit('drivers/cogent/frame_metrics.go','Completed: sample.Completed, Failure: sample.Failure,','Completed: sample.Completed, Failure: sample.Failure, Unavailable: sample.Unavailable,',True)
p=T/'drivers/cogent/desktop_frame_error.go';assert not p.exists();p.write_text('''package cogent

import "errors"

// ErrDesktopFrameUnavailable identifies a checked surface-acquisition yield.
// It is not a completed frame, a drawable-ready notification or a retry promise.
var ErrDesktopFrameUnavailable = errors.New("cogent: desktop drawable unavailable")

// DesktopCompositionError is a detached failed composition result. Failure keeps
// the existing backend diagnostic text; native error identities already reduced
// to FrameTrace strings are not restored. Unavailable is checked metadata, never
// inferred from Failure text. A failed request publishes no frame capability.
type DesktopCompositionError struct {
 Failure string
 Unavailable bool `json:",omitempty"`
}

func (e *DesktopCompositionError) Error() string {
 if e == nil { return "cogent: desktop composition failed" }
 return "cogent: desktop composition: " + e.Failure
}

func (e *DesktopCompositionError) Is(target error) bool {
 return e != nil && e.Unavailable && target == ErrDesktopFrameUnavailable
}
''')
print('implementation written; not yet prepared or tested')
