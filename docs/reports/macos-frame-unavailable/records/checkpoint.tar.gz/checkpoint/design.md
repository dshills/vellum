# Typed unavailable composition terminal

Current3d64869 has actual measured acquisition evidence for a surface Occluded
yield. FrameTrace observes the first composition after owner reconciliation;
DesktopSession retains one request and requires actual supported, submitted,
error-free composition before publishing a frame capability. Current shown,
focus and regular paint events do not prove drawable availability. A hidden
automatic wait/retry would change this contract and could monopolize capacity.

Stage86 preserves the terminal contract. Classify only coherent known surface
unavailability: oneattempt equal first/last Occluded or Timeout; twoattempts
firstLost/Outdated and lastOccluded/Timeout/Lost/Outdated. All unknown, backend,
view, encoder/pass, success-null, offscreen and legacy cases remain generic
failures. This is availability information, never a promise of retry success.

Carry a scalar Unavailable flag through measured composition, FrameTrace and
FrameSample, omitted from JSON whenfalse. Set it only on nilpass/nilerror with a
validated acquisition outcome; contradictory submitted/unavailable metadata
must failclosed. Public DesktopCompositionError preserves existing error text
and supports errors.Is(ErrDesktopFrameUnavailable), without string parsing or
new native handles, timers, requests, acquisition/presentation calls or history.
It cannot recover native error identities already reduced to trace strings.

Check context cancellation only after the actual terminal trace is taken, before
returning its composition result or publishing a token. Keep queued/in-flight
ownership until input/owner/render terminals. New explicit Frame after a real
lifecycle/application reason is allowed; neither shown/focused state nor this
sentinel establishes drawable readiness. No harness retry loop is added.

Software coverage: conservative acquisition protocol table; gpudraw checked
propagation; composer ordinary/source-details propagation; Core armed/intermediate
failure and contradictory flags/reset/cancel/retire; actual public Manual FIFO
with clearly synthetic measured-drawer output for terminal capacity, stale token,
no automatic requeue, separately requested recovery, fatal/cancel/closed results;
FrameMetrics copying and omitted zero metadata. Preserve old native failures and
all gates. No native rerun is implied by these fixtures.
