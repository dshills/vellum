from pathlib import Path
import sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
def append(n,s):
 p=Q/'candidate'/n;p.write_text(p.read_text()+s)
append('gpu/surface_acquisition_test.go',r'''
func TestVellumAcquisitionUnavailableClassification(t *testing.T) {
 occluded:=wgpu.SurfaceGetCurrentTextureStatusOccluded
 timeout:=wgpu.SurfaceGetCurrentTextureStatusTimeout
 lost:=wgpu.SurfaceGetCurrentTextureStatusLost
 outdated:=wgpu.SurfaceGetCurrentTextureStatusOutdated
 good:=AcquisitionOutcome{Source:AcquisitionSurface,Stage:AcquisitionUnavailable,Attempts:1,FirstStatus:occluded,LastStatus:occluded}
 valid:=[]AcquisitionOutcome{good,{Source:AcquisitionSurface,Stage:AcquisitionUnavailable,Attempts:1,FirstStatus:timeout,LastStatus:timeout}}
 for _,first:=range []wgpu.SurfaceGetCurrentTextureStatus{lost,outdated}{
  for _,last:=range []wgpu.SurfaceGetCurrentTextureStatus{occluded,timeout,lost,outdated}{valid=append(valid,AcquisitionOutcome{Source:AcquisitionSurface,Stage:AcquisitionUnavailable,Attempts:2,FirstStatus:first,LastStatus:last})}
 }
 for _,o:=range valid{if !o.IsUnavailable(){t.Fatal("known coherent yield lost",o)}}
 invalid:=[]AcquisitionOutcome{{},good,good,good,good,good,good,good,good,good,good,good,good,good}
 invalid[1].Source=AcquisitionUnknown;invalid[2].Source=AcquisitionRenderTexture
 invalid[3].Stage=AcquisitionBackendError;invalid[4].Stage=AcquisitionViewError
 invalid[5].Stage=AcquisitionMissingTexture;invalid[6].Stage=AcquisitionViewReady
 invalid[7].Attempts=0;invalid[8].Attempts=3
 invalid[9].FirstStatus=timeout
 invalid[10].FirstStatus=lost;invalid[10].LastStatus=lost
 invalid[11].FirstStatus=outdated;invalid[11].LastStatus=outdated
 invalid[12].Attempts=2 // first occluded cannot initiate the existing retry
 invalid[13].FirstStatus=wgpu.SurfaceGetCurrentTextureStatusError;invalid[13].LastStatus=wgpu.SurfaceGetCurrentTextureStatusError
 for _,last:=range []wgpu.SurfaceGetCurrentTextureStatus{wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal,wgpu.SurfaceGetCurrentTextureStatusSuccessSuboptimal,wgpu.SurfaceGetCurrentTextureStatus(0xffffffff),wgpu.SurfaceGetCurrentTextureStatusError}{
  invalid=append(invalid,AcquisitionOutcome{Source:AcquisitionSurface,Stage:AcquisitionUnavailable,Attempts:2,FirstStatus:lost,LastStatus:last})
 }
 for _,o:=range invalid{if o.IsUnavailable(){t.Fatal("unrecorded/fatal/incoherent outcome became availability",o)}}
}
''')
append('gpu/gpudraw/acquisition_test.go',r'''
func TestVellumMeasuredPassUnavailableIsCheckedAndNeverSticky(t *testing.T) {
 occluded:=wgpu.SurfaceGetCurrentTextureStatusOccluded
 cases:=[]struct{name string;out gpu.AcquisitionOutcome;failure bool;want bool}{
  {"occluded",gpu.AcquisitionOutcome{Source:gpu.AcquisitionSurface,Stage:gpu.AcquisitionUnavailable,Attempts:1,FirstStatus:occluded,LastStatus:occluded},false,true},
  {"recovery-exhausted",gpu.AcquisitionOutcome{Source:gpu.AcquisitionSurface,Stage:gpu.AcquisitionUnavailable,Attempts:2,FirstStatus:wgpu.SurfaceGetCurrentTextureStatusLost,LastStatus:wgpu.SurfaceGetCurrentTextureStatusOutdated},false,true},
  {"backend-error",gpu.AcquisitionOutcome{Source:gpu.AcquisitionSurface,Stage:gpu.AcquisitionUnavailable,Attempts:1,FirstStatus:occluded,LastStatus:occluded},true,false},
  {"view-error",gpu.AcquisitionOutcome{Source:gpu.AcquisitionSurface,Stage:gpu.AcquisitionViewError,Attempts:1,FirstStatus:wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal,LastStatus:wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal},true,false},
  {"missing-texture",gpu.AcquisitionOutcome{Source:gpu.AcquisitionSurface,Stage:gpu.AcquisitionMissingTexture,Attempts:1},false,false},
  {"unknown",gpu.AcquisitionOutcome{Source:gpu.AcquisitionSurface,Stage:gpu.AcquisitionUnavailable,Attempts:1,FirstStatus:wgpu.SurfaceGetCurrentTextureStatus(0xffffffff),LastStatus:wgpu.SurfaceGetCurrentTextureStatus(0xffffffff)},false,false},
  {"offscreen",gpu.AcquisitionOutcome{Source:gpu.AcquisitionRenderTexture,Stage:gpu.AcquisitionUnavailable},false,false},
  {"legacy",gpu.AcquisitionOutcome{},false,false},
 }
 for _,c:=range cases{t.Run(c.name,func(t *testing.T){
  sentinel:=errors.New("injected view/backend error")
  r:=&unavailableMeasuredRenderer{outcome:c.out};if c.failure{r.failure=sentinel}
  timing:=composer.ComposeTiming{Supported:true,Unavailable:true}
  pass,err:=beginMeasuredPass(&gpu.GraphicsSystem{Renderer:r},&timing)
  if pass!=nil||r.calls!=1||timing.Submitted||timing.Unavailable!=c.want{t.Fatal("incorrect checked classification/calls",timing,err,r.calls)}
  if c.failure{if !errors.Is(err,sentinel){t.Fatal("underlying failure lost",err)}}else if err!=nil||timing.Failure==""{t.Fatal("yield qualified or lost diagnostic",timing,err)}
 })}
}
''')
append('system/composer/timing_test.go',r'''
func TestVellumUnavailableCompositionPreservesCheckedTerminal(t *testing.T) {
 for _,details:=range []bool{false,true}{
  var order []string
  d:=&measuredTimingDrawer{timingDrawer:timingDrawer{order:&order},result:ComposeTiming{Supported:true,Unavailable:true,Failure:"scripted surface yield",AcquireNS:31}}
  cd:=&ComposerDrawer{Drawer:d,Sources:[]Source{timingSource{"source",&order}}}
  var result ComposeTiming
  if details{result=cd.ComposeMeasuredWithSourceDetails()}else{result=cd.ComposeMeasured()}
  if !result.Unavailable||result.Submitted||!result.Supported||result.Failure!=d.result.Failure||result.AcquireNS!=31||!reflect.DeepEqual(order,[]string{"start","source","measured-end"}){t.Fatal("availability changed order/result",details,result,order)}
 }
}
''')
append('core/frame_acquisition_test.go',r'''
func vellumUnavailableTrace(t *testing.T,armed bool)(*FrameTrace,uint64){
 t.Helper();trace:=&FrameTrace{};event:=traceScroll();if err:=trace.Begin(91,event);err!=nil{t.Fatal(err)}
 tag,start:=trace.startEvent(event);trace.ExpectOwner(tag);trace.endEvent(tag,start);trace.Transition(tag,17);trace.OwnerWork(tag,3)
 if armed{trace.Reconciled(tag,5)}
 if trace.startFrame()!=tag{t.Fatal("trace segment not started")};return trace,tag
}
func TestVellumFrameTraceUnavailableStrictContradictionsAndLegacy(t *testing.T){
 cases:=[]struct{name string;timing composer.ComposeTiming;complete,unavailable bool}{
  {"checked-yield",composer.ComposeTiming{Supported:true,Unavailable:true,Failure:"yield"},false,true},
  {"legacy-identical-text",composer.ComposeTiming{Supported:true,Failure:"yield"},false,false},
  {"submitted-with-yield",composer.ComposeTiming{Supported:true,Submitted:true,Unavailable:true,Failure:"yield"},false,false},
  {"contradictory-success",composer.ComposeTiming{Supported:true,Submitted:true,Unavailable:true},false,false},
  {"unsupported-yield",composer.ComposeTiming{Unavailable:true,Failure:"yield"},false,false},
  {"missing-failure",composer.ComposeTiming{Supported:true,Unavailable:true},false,false},
  {"healthy",composer.ComposeTiming{Supported:true,Submitted:true},true,false},
 }
 for _,c:=range cases{t.Run(c.name,func(t *testing.T){
  trace,tag:=vellumUnavailableTrace(t,true);trace.finishFrame(tag,c.timing);sample,ok:=trace.Take()
  if !ok||sample.Completed!=c.complete||sample.Unavailable!=c.unavailable||!sample.Completed&&sample.Failure==""{t.Fatal("wrong terminal",sample,ok)}
  if _,again:=trace.Take();again||trace.Pending(){t.Fatal("terminal retained")}
 })}
}
func TestVellumFrameTraceUnavailableIntermediateAndFatalRetirement(t *testing.T){
 yield:=composer.ComposeTiming{Supported:true,Unavailable:true,Failure:"yield"}
 trace,tag:=vellumUnavailableTrace(t,false);trace.finishFrame(tag,yield)
 sample,ok:=trace.Take();if !ok||sample.Completed||!sample.Unavailable{t.Fatal("pre-armed failure contract changed",sample,ok)}
 // A new ticket starts with zero classification and independently qualifies.
 event:=traceScroll();if err:=trace.Begin(92,event);err!=nil{t.Fatal(err)}
 next,start:=trace.startEvent(event);trace.ExpectOwner(next);trace.endEvent(next,start);trace.Transition(next,18);trace.OwnerWork(next,0);trace.Reconciled(next,0)
 trace.finishFrame(trace.startFrame(),composer.ComposeTiming{Supported:true,Submitted:true})
 sample,ok=trace.Take();if !ok||!sample.Completed||sample.Unavailable{t.Fatal("classification leaked across tickets",sample,ok)}
 for _,retire:=range []bool{false,true}{
  trace,tag=vellumUnavailableTrace(t,true)
  if retire{trace.Retire(tag,"closed")}else{trace.Fail(tag,"canceled")}
  trace.finishFrame(tag,yield) // late acquisition result must not replace terminal
  sample,ok=trace.Take();if !ok||sample.Completed||sample.Unavailable||sample.Failure=="yield"{t.Fatal("late availability replaced fatal/cancel/retire",sample,ok)}
 }
}
''')
p=T/'drivers/cogent/desktop_frame_error_test.go';assert not p.exists();p.write_text(r'''package cogent

import (
 "encoding/json"
 "errors"
 "fmt"
 "strings"
 "testing"
)

func TestDesktopCompositionErrorIdentityAndLegacyText(t *testing.T){
 for _,unavailable:=range []bool{false,true}{
  original:=&DesktopCompositionError{Failure:"occluded-like text",Unavailable:unavailable}
  if original.Error()!="cogent: desktop composition: occluded-like text"{t.Fatal("existing error text changed",original)}
  wrapped:=fmt.Errorf("consumer: %w",original)
  var result *DesktopCompositionError
  if !errors.As(wrapped,&result)||result!=original||errors.Is(wrapped,ErrDesktopFrameUnavailable)!=unavailable||errors.Is(wrapped,ErrDesktopClosed){t.Fatal("typed error lost/guessed identity",wrapped)}
 }
 var empty *DesktopCompositionError
 if empty.Is(ErrDesktopFrameUnavailable)||empty.Error()==""{t.Fatal("nil error method contract")}
 // The added false scalar preserves existing JSON payload shape.
 wire,err:=json.Marshal(FrameSample{});if err!=nil||strings.Contains(string(wire),"Unavailable"){t.Fatal("zero metadata changed legacy wire",string(wire),err)}
}
''')
p=T/'drivers/cogent/desktop_frame_unavailable_offscreen_test.go';assert not p.exists();p.write_text(r'''//go:build offscreen

package cogent

import (
 "context"
 "encoding/json"
 "errors"
 "strings"
 "testing"

 "cogentcore.org/core/system/composer"
)

// Actual Manual FIFO/reconciliation/composition uses clearly synthetic measured
// drawer output. These tests prove protocol behavior, never native GPU success.
type desktopMeasuredFixture struct{composer.Drawer;result composer.ComposeTiming;calls int}
func(d *desktopMeasuredFixture)EndMeasured()composer.ComposeTiming{d.calls++;d.Drawer.End();return d.result}
func installDesktopMeasuredFixture(t *testing.T,w *nativeWindow)*desktopMeasuredFixture{
 t.Helper();cd:=w.body.Scene.RenderWindow().SystemWindow.Composer().(*composer.ComposerDrawer)
 original:=cd.Drawer;d:=&desktopMeasuredFixture{Drawer:original};cd.Drawer=d;t.Cleanup(func(){cd.Drawer=original});return d
}
func desktopPaintWithoutReap(t *testing.T,m *Manual,d *desktopMeasuredFixture){
 t.Helper();before:=d.calls
 for range256{if _,err:=m.Step(testContext,1);err!=nil{t.Fatal(err)};if d.calls!=before{return}}
 t.Fatal("scripted measured composition not reached")
}
func TestDesktopFrameUnavailableTerminalAndExplicitRecovery(t *testing.T){
 s,m,_,w,_:=desktopFixture(t);desktopFrame(t,s,m,w);old:=s.windows[w.window.Ref()].frame
 d:=installDesktopMeasuredFixture(t,w);d.result=composer.ComposeTiming{Supported:true,Unavailable:true,Failure:"scripted occluded"}
 r,err:=s.submit(testContext,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
 out:=desktopPump(t,s,m,r);var classified *DesktopCompositionError
 if !errors.Is(out.err,ErrDesktopFrameUnavailable)||!errors.As(out.err,&classified)||classified.Failure!="scripted occluded"||!classified.Unavailable{t.Fatal("checked terminal lost",out.err)}
 if s.pending!=nil||r.binding.trace.Pending()||r.binding.frame!=0||d.calls!=1{t.Fatal("failed frame retained capacity/token",s.State(),d.calls)}
 issued:=s.State().Issued
 if _,err:=m.Step(testContext,128);err!=nil{t.Fatal(err)}
 if d.calls!=1||s.State().Issued!=issued||s.State().Pending{t.Fatal("unavailable auto-requeued",s.State(),d.calls)}
 // Explicit application decision only; no availability notification is inferred.
 d.result=composer.ComposeTiming{Supported:true,Submitted:true}
 r,err=s.submit(testContext,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
 if out=desktopPump(t,s,m,r);out.err!=nil||r.binding.frame!=r.tag||r.binding.frame==old||d.calls!=2{t.Fatal("new explicit request failed/reset incorrectly",out.err,d.calls)}
 in,err:=s.submit(testContext,w.window.Ref(),1,DesktopInput{Frame:old});if err!=nil{t.Fatal(err)}
 if out=desktopPump(t,s,m,in);!errors.Is(out.err,ErrDesktopPending){t.Fatal("stale frame revived",out.err)}
 d.result=composer.ComposeTiming{Supported:true,Failure:"scripted backend error"}
 r,err=s.submit(testContext,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
 if out=desktopPump(t,s,m,r);out.err==nil||errors.Is(out.err,ErrDesktopFrameUnavailable)||r.binding.frame!=0||s.pending!=nil||d.calls!=3{t.Fatal("fatal error became unavailable/success",out.err)}
}
func TestDesktopFrameCancellationPreservesContextIdentity(t *testing.T){
 s,m,_,w,_:=desktopFixture(t);ctx,cancel:=context.WithCancel(context.Background());defer cancel()
 r,err:=s.submit(ctx,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
 cancel();s.cancel(r)
 if s.pending!=r||!r.binding.trace.Pending(){t.Fatal("queued input/owner terminal released prematurely")}
 if _,err=s.submit(testContext,w.window.Ref(),2,DesktopInput{});!errors.Is(err,ErrDesktopBusy){t.Fatal("pending cancellation lost capacity",err)}
 if out:=desktopPump(t,s,m,r);!errors.Is(out.err,context.Canceled)||errors.Is(out.err,ErrDesktopFrameUnavailable){t.Fatal("canceled Frame lost context identity",out.err)}
 if s.pending!=nil||r.binding.trace.Pending()||r.binding.frame!=0{t.Fatal("canceled terminal leaked")}
}
func TestDesktopFrameCancellationWinsOnlyAfterCompositionTerminal(t *testing.T){
 for _,result:=range []composer.ComposeTiming{{Supported:true,Unavailable:true,Failure:"yield"},{Supported:true,Failure:"fatal"},{Supported:true,Submitted:true}}{t.Run(result.Failure,func(t *testing.T){
  s,m,_,w,_:=desktopFixture(t);ctx,cancel:=context.WithCancel(context.Background());defer cancel();d:=installDesktopMeasuredFixture(t,w);d.result=result
  r,err:=s.submit(ctx,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
  desktopPaintWithoutReap(t,m,d);cancel();s.mu.Lock();s.reapLocked();s.mu.Unlock()
  out:=<-r.reply
  if !errors.Is(out.err,context.Canceled)||errors.Is(out.err,ErrDesktopFrameUnavailable)||s.pending!=nil||r.binding.trace.Pending()||r.binding.frame!=0||d.calls!=1{t.Fatal("canceled terminal published/retained/misclassified",out.err,s.State(),d.calls)}
 })}
}
func TestDesktopFrameUnavailableRetirementAndMetricsCopy(t *testing.T){
 t.Run("close-pending",func(t *testing.T){
  s,_,_,w,_:=desktopFixture(t);d:=installDesktopMeasuredFixture(t,w)
  r,err:=s.submit(testContext,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)}
  s.retire(w);out:=<-r.reply
  if !errors.Is(out.err,ErrDesktopClosed)||errors.Is(out.err,ErrDesktopFrameUnavailable)||s.pending!=nil||r.binding.trace.Pending()||d.calls!=0{t.Fatal("retirement retained/misclassified pending request",out.err,s.State())}
 })
 t.Run("metrics-copy",func(t *testing.T){
  s,m,_,w,_:=desktopFixture(t);d:=installDesktopMeasuredFixture(t,w);d.result=composer.ComposeTiming{Supported:true,Unavailable:true,Failure:"scripted yield"}
  r,err:=s.submit(testContext,w.window.Ref(),2,DesktopInput{});if err!=nil{t.Fatal(err)};desktopPaintWithoutReap(t,m,d)
  // At this actual trace terminal, hand the value to the recorder solely to
  // exercise production copying. This is not simultaneous observer binding;
  // retire the session without granting it a completed frame afterward.
  metrics,_:=NewFrameMetrics(1);metrics.windows=[]*frameWindowMetrics{{trace:r.binding.trace,key:frameWindowKey{window:"one"}}};metrics.tags[r.tag]=0
  got:=metrics.Snapshot();if len(got.Samples)!=1||!got.Samples[0].Unavailable||got.Samples[0].Completed||got.Samples[0].Failure!="scripted yield"||got.Pending!=0{t.Fatal("metrics lost/misqualified terminal",got)}
  wire,err:=json.Marshal(got);if err!=nil||!strings.Contains(string(wire),`"Unavailable":true`){t.Fatal("availability missing from failure wire",string(wire),err)}
  got.Samples[0].Unavailable=false
  if !metrics.Poll(r.tag).Sample.Unavailable{t.Fatal("caller mutated retained availability")}
  s.retire(w);if out:=<-r.reply;!errors.Is(out.err,ErrDesktopClosed){t.Fatal(out.err)}
 })
}
'''.replace('range256','range 256'))
print('regressions written; synthetic composition outcomes are software evidence only')
