from pathlib import Path
import sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent
p=Q/'candidate/core/frame_trace.go';s=p.read_text()
old='''		if trace.sourceDetails {
			if failure := appendFrameSourceDetails(p.SourceDetails, timing.SourceDetails); failure != "" && timing.Failure == "" {
				timing.Failure = failure
			}
		}'''
new='''		// Eligibility belongs to the original composition terminal. Diagnostic
		// validation must neither manufacture nor retain an unavailable result.
		unavailable := timing.Unavailable && timing.Supported && !timing.Submitted && timing.Failure != ""
		if trace.sourceDetails {
			if failure := appendFrameSourceDetails(p.SourceDetails, timing.SourceDetails); failure != "" {
				unavailable = false
				if timing.Failure == "" {
					timing.Failure = failure
				}
			}
		}'''
assert old in s;s=s.replace(old,new).replace('p.Unavailable = timing.Unavailable && timing.Supported && !timing.Submitted && timing.Failure != ""','p.Unavailable = unavailable');p.write_text(s)
p=Q/'candidate/system/composer/source_timing.go';s=p.read_text();old='''		end.SourceDetails = details
		if end.Failure == "" {''';new='''		end.SourceDetails = details
		if failure != "" {
			end.Unavailable = false
		}
		if end.Failure == "" {''';assert old in s;p.write_text(s.replace(old,new))
print('source-details eligibility defect fixed; original first-failure text precedence preserved')
