from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;A=Q.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('source_guard',A/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sdk=Path(json.loads((A/'macos-acquisition-diagnostics-4ce6ba4/plan.json').read_bytes())['sdk']);name,kind=sys.argv[1:];assert kind in ['negative','fixed']and not(Q/name).exists()
d=json.loads((Q/'overlay.json').read_bytes());root=Q/('candidate-v1'if kind=='negative'else'candidate')
for n in json.loads((Q/'files.json').read_bytes()):d['Replace'][str(sdk/'drivers/cogent/build/upstream'/n)]=str(root/n)
overlay=Q/(name+'-overlay.json');assert not overlay.exists();overlay.write_text(json.dumps(d,indent=2)+'\n')
paths=[Path(p)for p in d['Replace'].values()if p]+[overlay,Path(__file__),Path(h.__file__),h.GUARD,h.GO];pins={str(p):h.sha(p)for p in paths}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','PYTHONDONTWRITEBYTECODE':'1'}
args=[str(h.GO),'test','-v','-race','-count=1','-p=1','-overlay='+str(overlay),'-tags=offscreen','-timeout=2m','-run','^TestVellumUnavailableSource','cogentcore.org/core/system/composer','cogentcore.org/core/core']
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
def interrupted(signum,frame):raise InterruptedError('source diagnostic check signal '+str(signum))
previous=signal.signal(signal.SIGTERM,interrupted)
try:r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*args],sdk/'drivers/cogent',Q/name,lambda:False,lambda:all(h.sha(p)==v for p,v in pins.items()),timeout=180,limit=4<<20)
finally:signal.signal(signal.SIGTERM,previous)
r['source_pins']=pins;r['native_executed']=False
(Q/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(r['exit_code']if r['exit_code']is not None else 1)
