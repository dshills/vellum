// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package core

import (
	"cogentcore.org/core/system/composer"
	"testing"
)

func TestVellumUnavailableSourceDetailsDoNotPromoteOrMaskFailure(t *testing.T) {
	valid := &composer.SourceDetails{Compositions: 1, Records: []composer.SourceTiming{{Composition: 1, Source: 0, Kind: composer.SourceScene}}}
	invalid := &composer.SourceDetails{Compositions: 1, Records: []composer.SourceTiming{{Composition: 2, Source: 0, Kind: composer.SourceScene}}}
	for _, c := range []struct {
		name    string
		details *composer.SourceDetails
		failure string
		want    bool
	}{
		{"missing-failure-and-details", nil, "", false},
		{"missing-failure-valid-details", valid, "", false},
		{"checked-yield-missing-details", nil, "yield", false},
		{"checked-yield-invalid-order", invalid, "yield", false},
		{"checked-yield-valid-details", valid, "yield", true},
	} {
		t.Run(c.name, func(t *testing.T) {
			trace := NewFrameTraceWithSourceDetails()
			event := traceScroll()
			if err := trace.Begin(101, event); err != nil {
				t.Fatal(err)
			}
			tag, start := trace.startEvent(event)
			trace.ExpectOwner(tag)
			trace.endEvent(tag, start)
			trace.Transition(tag, 9)
			trace.OwnerWork(tag, 0)
			trace.Reconciled(tag, 0)
			trace.finishFrame(trace.startFrame(), composer.ComposeTiming{Supported: true, Unavailable: true, Failure: c.failure, SourceDetails: c.details})
			sample, ok := trace.Take()
			if !ok || sample.Completed || sample.Unavailable != c.want || sample.Failure == "" {
				t.Fatal("diagnostic failure promoted/retained unavailable", sample, ok)
			}
		})
	}
}
