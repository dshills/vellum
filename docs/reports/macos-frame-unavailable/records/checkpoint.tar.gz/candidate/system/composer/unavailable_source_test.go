// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package composer

import "testing"

func TestVellumUnavailableSourceDiagnosticsStayFatal(t *testing.T) {
	for _, name := range []string{"healthy", "empty", "overflow", "already-active", "invalid-counter"} {
		t.Run(name, func(t *testing.T) {
			var order []string
			d := newSourceTimingDrawer(&order)
			d.result = ComposeTiming{Supported: true, Unavailable: true, Failure: "yield"}
			source := &measuredSource{}
			sources := []Source{source}
			switch name {
			case "empty":
				sources = nil
			case "overflow":
				sources = make([]Source, 33)
				for i := range sources {
					sources[i] = source
				}
			case "already-active":
				d.active = true
			case "invalid-counter":
				source.action = func() { d.stats.Invalid = true }
			}
			result := (&ComposerDrawer{Drawer: d, Sources: sources}).ComposeMeasuredWithSourceDetails()
			if result.Unavailable != (name == "healthy") || result.Submitted || result.Failure == "" {
				t.Fatal("source diagnostic fault became availability", result)
			}
			if len(order) != 2 || order[0] != "start" || order[1] != "measured-end" || source.measured != len(sources) {
				t.Fatal("fault changed draw/end count", order, source.measured)
			}
			if d.active != (name == "already-active") {
				t.Fatal("measurement ownership changed", d.active)
			}
		})
	}
}
