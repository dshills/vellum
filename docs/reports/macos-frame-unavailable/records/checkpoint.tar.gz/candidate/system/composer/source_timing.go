// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package composer

import "time"

// Source observations are diagnostic only. All intervals are nested within
// RasterUploadNS; they never add to UI-work accounting. Kinds are value metadata,
// not references to a source, widget, scene, image, or user text.
const MaxSourceTimingRecords = 32

const (
	SourceOther uint8 = iota
	SourceScene
	SourceSprites
	SourceScrim
	SourceInsets
)

// SceneHostTiming describes elapsed host work in the opt-in GPU scene route.
// Capture, Encode and Lease are disjoint subsets of SourceTiming.DrawNS.
// Resources is nested in Lease; Input is nested in Resources. Input includes
// buffer retirement/admission/allocation and checked input-buffer write calls.
// It excludes seed-image writes, which remain inside Resources. Do not add
// nested intervals or interpret these as GPU execution or presentation time.
// LogicalInputBytes counts bytes passed to checked queue write attempts,
// including refused writes; errors report only those API return values.
// QueueSubmitAttempts is an API call count, never GPU completion evidence.
// Each value belongs to one synchronous source draw; it retains no references.
type SceneHostTiming struct {
	Available                                               bool
	CaptureAttempted, EncodeAttempted, LeaseAttempted       bool
	ResourcesEntered, InputAttempted                        bool
	CaptureNS, EncodeNS, LeaseNS, ResourcesNS, InputNS      int64
	InputWriteAttempts, InputWriteErrors, LogicalInputBytes uint64
	QueueSubmitAttempts                                     uint64
	DrawAccepted, Reused, Fallback                          bool
}

type SourceTiming struct {
	Composition, Source                    uint32
	Kind                                   uint8
	DrawNS, RasterNS, CopyNS               int64
	RasterAvailable, CopyAvailable         bool
	ImageWidth, ImageHeight                int
	ImageChanged                           bool
	ImageUploadTimingAvailable             bool
	SetFromGoImageNS                       int64
	SetFromGoImageAttempts, ImageCacheHits uint64
	LogicalUploadRGBABytes                 uint64
	SceneHost                              SceneHostTiming
}

type SourceDetails struct {
	Compositions uint32
	Records      []SourceTiming
}

// ImageTiming counts API attempts, not successful transfers. The existing
// Value API logs errors without returning them. Logical bytes are checked 4WH
// input bytes, not physical GPU traffic or bytes confirmed queued.
type ImageTiming struct {
	SetFromGoImageNS                       int64
	SetFromGoImageAttempts, ImageCacheHits uint64
	LogicalUploadRGBABytes                 uint64
	Invalid                                bool
}

type sourceImageTimer interface {
	BeginSourceImageTiming() bool
	ReadSourceImageTiming() ImageTiming
	EndSourceImageTiming()
}

// ComposeMeasuredWithSourceDetails draws every source exactly once, even when
// bounded diagnostic storage overflows. Drawer locks are acquired only by its
// counter methods; no drawer lock is held across Draw/DrawMeasured.
func (cd *ComposerDrawer) ComposeMeasuredWithSourceDetails() ComposeTiming {
	start := time.Now()
	cd.Drawer.Start()
	details := &SourceDetails{Compositions: 1, Records: make([]SourceTiming, 0, min(len(cd.Sources), MaxSourceTimingRecords))}
	failure := ""
	if len(cd.Sources) == 0 {
		failure = "source diagnostic composition has no sources"
	}
	if len(cd.Sources) > MaxSourceTimingRecords {
		failure = "source diagnostic record capacity exceeded"
	}
	timer, hasTimer := cd.Drawer.(sourceImageTimer)
	if hasTimer {
		hasTimer = timer.BeginSourceImageTiming()
		if hasTimer {
			defer timer.EndSourceImageTiming() // including panic and Goexit
		} else {
			failure = "source diagnostic image timing already active"
		}
	}
	for i, source := range cd.Sources {
		var before ImageTiming
		if hasTimer {
			before = timer.ReadSourceImageTiming()
		}
		drawStart := time.Now()
		var record SourceTiming
		if measured, ok := source.(interface{ DrawMeasured(Composer) SourceTiming }); ok {
			record = measured.DrawMeasured(cd)
		} else {
			source.Draw(cd)
		}
		record.DrawNS = time.Since(drawStart).Nanoseconds()
		record.Composition, record.Source = 1, uint32(i)
		record.ImageUploadTimingAvailable = hasTimer
		if hasTimer {
			after := timer.ReadSourceImageTiming()
			if before.Invalid || after.Invalid || after.SetFromGoImageNS < before.SetFromGoImageNS ||
				after.SetFromGoImageAttempts < before.SetFromGoImageAttempts || after.ImageCacheHits < before.ImageCacheHits || after.LogicalUploadRGBABytes < before.LogicalUploadRGBABytes {
				failure = "source diagnostic image counter overflow"
			} else {
				record.SetFromGoImageNS = after.SetFromGoImageNS - before.SetFromGoImageNS
				record.SetFromGoImageAttempts = after.SetFromGoImageAttempts - before.SetFromGoImageAttempts
				record.ImageCacheHits = after.ImageCacheHits - before.ImageCacheHits
				record.LogicalUploadRGBABytes = after.LogicalUploadRGBABytes - before.LogicalUploadRGBABytes
			}
		}
		if len(details.Records) < MaxSourceTimingRecords {
			details.Records = append(details.Records, record)
		}
	}
	timing := ComposeTiming{RasterUploadNS: time.Since(start).Nanoseconds(), SourceDetails: details}
	if drawer, ok := cd.Drawer.(interface{ EndMeasured() ComposeTiming }); ok {
		end := drawer.EndMeasured()
		end.RasterUploadNS += timing.RasterUploadNS
		end.SourceDetails = details
		if failure != "" {
			end.Unavailable = false
		}
		if end.Failure == "" {
			end.Failure = failure
		}
		return end
	}
	cd.Drawer.End()
	timing.Failure = "composition drawer does not support encoding timing"
	return timing
}
