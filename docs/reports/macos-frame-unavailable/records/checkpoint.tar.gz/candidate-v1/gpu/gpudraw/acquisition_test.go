// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpudraw

import (
	"cogentcore.org/core/gpu"
	"cogentcore.org/core/system/composer"
	"errors"
	"github.com/oliverbestmann/webgpu/wgpu"
	"strings"
	"testing"
)

type unavailableMeasuredRenderer struct {
	gpu.Renderer
	outcome gpu.AcquisitionOutcome
	failure error
	calls   int
}

func (r *unavailableMeasuredRenderer) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	panic("detailed renderer silently fell back")
}
func (r *unavailableMeasuredRenderer) GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, gpu.AcquisitionOutcome, error) {
	r.calls++
	return nil, 23, r.outcome, r.failure
}
func (r *unavailableMeasuredRenderer) PresentMeasured() int64 { panic("unsubmitted frame presented") }
func TestVellumMeasuredPassFailureCarriesAcquisitionThroughComposition(t *testing.T) {
	sentinel := errors.New("injected backend failure")
	for _, c := range []struct {
		stage    gpu.AcquisitionStage
		status   wgpu.SurfaceGetCurrentTextureStatus
		attempts uint8
		fail     bool
	}{
		{gpu.AcquisitionUnavailable, wgpu.SurfaceGetCurrentTextureStatusOccluded, 1, false},
		{gpu.AcquisitionUnavailable, wgpu.SurfaceGetCurrentTextureStatusLost, 2, false},
		{gpu.AcquisitionMissingTexture, wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal, 1, false},
		{gpu.AcquisitionBackendError, wgpu.SurfaceGetCurrentTextureStatusError, 2, true},
	} {
		r := &unavailableMeasuredRenderer{outcome: gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: c.stage, Attempts: c.attempts, FirstStatus: c.status, LastStatus: c.status}}
		if c.fail {
			r.failure = sentinel
		}
		timing := composer.ComposeTiming{Supported: true}
		pass, err := beginMeasuredPass(&gpu.GraphicsSystem{Renderer: r}, &timing)
		if pass != nil || r.calls != 1 || timing.AcquireNS != 23 || timing.Submitted || !timing.Supported {
			t.Fatal("no-frame became submission or extra acquisition", timing, err)
		}
		if c.fail {
			if !errors.Is(err, sentinel) || !strings.Contains(err.Error(), r.outcome.Description()) {
				t.Fatal("error context or identity lost", err)
			}
		} else if err != nil || !strings.Contains(timing.Failure, r.outcome.Description()) || !strings.Contains(timing.Failure, "render pass unavailable") {
			t.Fatal("composition lost actual acquisition", timing, err)
		}
	}
}

func TestVellumMeasuredPassUnavailableIsCheckedAndNeverSticky(t *testing.T) {
	occluded := wgpu.SurfaceGetCurrentTextureStatusOccluded
	cases := []struct {
		name    string
		out     gpu.AcquisitionOutcome
		failure bool
		want    bool
	}{
		{"occluded", gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionUnavailable, Attempts: 1, FirstStatus: occluded, LastStatus: occluded}, false, true},
		{"recovery-exhausted", gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionUnavailable, Attempts: 2, FirstStatus: wgpu.SurfaceGetCurrentTextureStatusLost, LastStatus: wgpu.SurfaceGetCurrentTextureStatusOutdated}, false, true},
		{"backend-error", gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionUnavailable, Attempts: 1, FirstStatus: occluded, LastStatus: occluded}, true, false},
		{"view-error", gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionViewError, Attempts: 1, FirstStatus: wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal, LastStatus: wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal}, true, false},
		{"missing-texture", gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionMissingTexture, Attempts: 1}, false, false},
		{"unknown", gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionUnavailable, Attempts: 1, FirstStatus: wgpu.SurfaceGetCurrentTextureStatus(0xffffffff), LastStatus: wgpu.SurfaceGetCurrentTextureStatus(0xffffffff)}, false, false},
		{"offscreen", gpu.AcquisitionOutcome{Source: gpu.AcquisitionRenderTexture, Stage: gpu.AcquisitionUnavailable}, false, false},
		{"legacy", gpu.AcquisitionOutcome{}, false, false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			sentinel := errors.New("injected view/backend error")
			r := &unavailableMeasuredRenderer{outcome: c.out}
			if c.failure {
				r.failure = sentinel
			}
			timing := composer.ComposeTiming{Supported: true, Unavailable: true}
			pass, err := beginMeasuredPass(&gpu.GraphicsSystem{Renderer: r}, &timing)
			if pass != nil || r.calls != 1 || timing.Submitted || timing.Unavailable != c.want {
				t.Fatal("incorrect checked classification/calls", timing, err, r.calls)
			}
			if c.failure {
				if !errors.Is(err, sentinel) {
					t.Fatal("underlying failure lost", err)
				}
			} else if err != nil || timing.Failure == "" {
				t.Fatal("yield qualified or lost diagnostic", timing, err)
			}
		})
	}
}
