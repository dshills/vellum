// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/gpu"
	"cogentcore.org/core/system/composer"
	"github.com/oliverbestmann/webgpu/wgpu"
	"testing"
)

func TestVellumFrameTraceAcquisitionFailurePreservesStrictCompletion(t *testing.T) {
	for _, submitted := range []bool{false, true} {
		trace := &FrameTrace{}
		event := traceScroll()
		if err := trace.Begin(5, event); err != nil {
			t.Fatal(err)
		}
		tag, start := trace.startEvent(event)
		trace.ExpectOwner(tag)
		trace.endEvent(tag, start)
		trace.Transition(tag, 11)
		trace.OwnerWork(tag, 7)
		trace.Reconciled(tag, 13)
		if trace.startFrame() != tag {
			t.Fatal("armed frame not started")
		}
		outcome := gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionUnavailable, Attempts: 2, FirstStatus: wgpu.SurfaceGetCurrentTextureStatusLost, LastStatus: wgpu.SurfaceGetCurrentTextureStatusTimeout}
		failure := "gpu: measured render pass unavailable (" + outcome.Description() + ")"
		trace.finishFrame(tag, composer.ComposeTiming{Supported: true, Submitted: submitted, Failure: failure, AcquireNS: 29})
		sample, ready := trace.Take()
		if !ready || sample.Completed || sample.Failure != failure || sample.AcquireNS != 29 {
			t.Fatal("failed acquisition was hidden or qualified", sample, ready)
		}
		if _, again := trace.Take(); again {
			t.Fatal("failure sample retained after take")
		}
	}
}

func vellumUnavailableTrace(t *testing.T, armed bool) (*FrameTrace, uint64) {
	t.Helper()
	trace := &FrameTrace{}
	event := traceScroll()
	if err := trace.Begin(91, event); err != nil {
		t.Fatal(err)
	}
	tag, start := trace.startEvent(event)
	trace.ExpectOwner(tag)
	trace.endEvent(tag, start)
	trace.Transition(tag, 17)
	trace.OwnerWork(tag, 3)
	if armed {
		trace.Reconciled(tag, 5)
	}
	if trace.startFrame() != tag {
		t.Fatal("trace segment not started")
	}
	return trace, tag
}
func TestVellumFrameTraceUnavailableStrictContradictionsAndLegacy(t *testing.T) {
	cases := []struct {
		name                  string
		timing                composer.ComposeTiming
		complete, unavailable bool
	}{
		{"checked-yield", composer.ComposeTiming{Supported: true, Unavailable: true, Failure: "yield"}, false, true},
		{"legacy-identical-text", composer.ComposeTiming{Supported: true, Failure: "yield"}, false, false},
		{"submitted-with-yield", composer.ComposeTiming{Supported: true, Submitted: true, Unavailable: true, Failure: "yield"}, false, false},
		{"contradictory-success", composer.ComposeTiming{Supported: true, Submitted: true, Unavailable: true}, false, false},
		{"unsupported-yield", composer.ComposeTiming{Unavailable: true, Failure: "yield"}, false, false},
		{"missing-failure", composer.ComposeTiming{Supported: true, Unavailable: true}, false, false},
		{"healthy", composer.ComposeTiming{Supported: true, Submitted: true}, true, false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			trace, tag := vellumUnavailableTrace(t, true)
			trace.finishFrame(tag, c.timing)
			sample, ok := trace.Take()
			if !ok || sample.Completed != c.complete || sample.Unavailable != c.unavailable || !sample.Completed && sample.Failure == "" {
				t.Fatal("wrong terminal", sample, ok)
			}
			if _, again := trace.Take(); again || trace.Pending() {
				t.Fatal("terminal retained")
			}
		})
	}
}
func TestVellumFrameTraceUnavailableIntermediateAndFatalRetirement(t *testing.T) {
	yield := composer.ComposeTiming{Supported: true, Unavailable: true, Failure: "yield"}
	trace, tag := vellumUnavailableTrace(t, false)
	trace.finishFrame(tag, yield)
	sample, ok := trace.Take()
	if !ok || sample.Completed || !sample.Unavailable {
		t.Fatal("pre-armed failure contract changed", sample, ok)
	}
	// A new ticket starts with zero classification and independently qualifies.
	event := traceScroll()
	if err := trace.Begin(92, event); err != nil {
		t.Fatal(err)
	}
	next, start := trace.startEvent(event)
	trace.ExpectOwner(next)
	trace.endEvent(next, start)
	trace.Transition(next, 18)
	trace.OwnerWork(next, 0)
	trace.Reconciled(next, 0)
	trace.finishFrame(trace.startFrame(), composer.ComposeTiming{Supported: true, Submitted: true})
	sample, ok = trace.Take()
	if !ok || !sample.Completed || sample.Unavailable {
		t.Fatal("classification leaked across tickets", sample, ok)
	}
	for _, retire := range []bool{false, true} {
		trace, tag = vellumUnavailableTrace(t, true)
		if retire {
			trace.Retire(tag, "closed")
		} else {
			trace.Fail(tag, "canceled")
		}
		trace.finishFrame(tag, yield) // late acquisition result must not replace terminal
		sample, ok = trace.Take()
		if !ok || sample.Completed || sample.Unavailable || sample.Failure == "yield" {
			t.Fatal("late availability replaced fatal/cancel/retire", sample, ok)
		}
	}
}
