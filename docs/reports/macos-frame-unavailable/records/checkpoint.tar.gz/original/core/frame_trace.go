package core

import (
	"errors"
	"reflect"
	"sync"
	"sync/atomic"
	"time"

	"cogentcore.org/core/events"
	"cogentcore.org/core/system/composer"
)

var ErrFrameTraceBusy = errors.New("core: traced interaction pending")

// FrameTraceSample is one tagged input and the first composition armed after
// its owner transition/reconciliation. These are elapsed work intervals, not
// OS thread CPU counters or compositor presentation timestamps.
type FrameTraceSample struct {
	Tag, Generation                                         uint64
	QueuedNS, InputNS, OwnerNS, ReconcileNS                 int64
	LayoutPaintNS, GatherNS, RasterUploadNS, EncodeSubmitNS int64
	AcquireNS, PresentCallNS, TotalUIWorkNS                 int64
	Completed                                               bool
	Failure                                                 string
	SourceDetails                                           *composer.SourceDetails
}

type frameTracePending struct {
	FrameTraceSample
	event                                                                                         events.Event
	queued                                                                                        time.Time
	inputDone, ownerExpected, transition, ownerDone, reconciled, armed, rendering, ready, retired bool
	frameArmed                                                                                    bool // captured at composition start, never inferred at finish
}

// FrameTrace retains at most one interaction and owns no callback. Install it
// explicitly; the ordinary event/render path does no timing when absent.
type FrameTrace struct {
	mu            sync.Mutex
	pending       *frameTracePending
	active        atomic.Uint64
	sourceDetails bool // immutable; the zero value preserves ordinary tracing
}

// NewFrameTraceWithSourceDetails opts into bounded per-source diagnostics.
func NewFrameTraceWithSourceDetails() *FrameTrace { return &FrameTrace{sourceDetails: true} }

func (sc *Scene) SetFrameTrace(trace *FrameTrace) { sc.frameTrace.Store(trace) }
func (sc *Scene) FrameTrace() *FrameTrace         { return sc.frameTrace.Load() }

// A reserved diagnostic FIFO node unwraps only at actual dispatch. The deque
// still sees a DeferredEvent, preserving identity against ordinary compression.
func unwrapFrameTraceEvent(event events.Event) events.Event {
	if reserved, ok := event.(interface{ FrameTraceEvent() events.Event }); ok {
		return reserved.FrameTraceEvent()
	}
	return event
}

func (trace *FrameTrace) Begin(tag uint64, event events.Event) error {
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if tag == 0 || event == nil || reflect.ValueOf(event).Kind() != reflect.Pointer || reflect.ValueOf(event).IsNil() {
		return errors.New("core: invalid traced input")
	}
	if trace.pending != nil {
		return ErrFrameTraceBusy
	}
	trace.pending = &frameTracePending{FrameTraceSample: FrameTraceSample{Tag: tag}, event: event, queued: time.Now()}
	if trace.sourceDetails {
		trace.pending.SourceDetails = &composer.SourceDetails{}
	}
	return nil
}
func (trace *FrameTrace) CurrentTag() uint64 {
	if trace == nil {
		return 0
	}
	return trace.active.Load()
}
func (trace *FrameTrace) startEvent(event events.Event) (uint64, time.Time) {
	if trace == nil {
		return 0, time.Time{}
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	p := trace.pending
	if p == nil || p.event != event {
		return 0, time.Time{}
	}
	start := time.Now()
	p.QueuedNS = start.Sub(p.queued).Nanoseconds()
	trace.active.Store(p.Tag)
	return p.Tag, start
}
func (trace *FrameTrace) endEvent(tag uint64, start time.Time) {
	if tag == 0 {
		return
	}
	trace.active.Store(0)
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.InputNS = time.Since(start).Nanoseconds()
		p.inputDone = true
		if !p.ownerExpected {
			p.ownerDone = true
			if !p.ready {
				p.Failure = "traced input did not post owner work"
				p.ready = true
			}
		}
	}
}

// ExpectOwner records a handler's checked asynchronous owner-post handshake.
// The caller explicitly closes the owner terminal if posting is refused.
func (trace *FrameTrace) ExpectOwner(tag uint64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.ownerExpected = true
	}
}

// OwnerTag identifies a received input awaiting its posted owner work.
func (trace *FrameTrace) OwnerTag() uint64 {
	if trace == nil {
		return 0
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.inputDone && !p.ownerDone {
		return p.Tag
	}
	return 0
}
func (trace *FrameTrace) Transition(tag, generation uint64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.Generation = generation
		p.transition = true
	}
}
func (trace *FrameTrace) OwnerWork(tag uint64, duration int64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.OwnerNS += duration
		if p.transition {
			p.ownerDone = true
		}
	}
}
func (trace *FrameTrace) ReconcileTag() uint64 {
	if trace == nil {
		return 0
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.ownerDone && !p.reconciled && !p.ready {
		return p.Tag
	}
	return 0
}
func (trace *FrameTrace) Reconciled(tag uint64, duration int64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.ownerDone && !p.ready {
		p.ReconcileNS += duration
		p.reconciled = true
		p.armed = true
	}
}
func (trace *FrameTrace) startFrame() uint64 {
	if trace == nil {
		return 0
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.inputDone && !p.rendering && !p.ready {
		p.rendering = true
		p.frameArmed = p.armed
		return p.Tag
	}
	return 0
}
func (trace *FrameTrace) frameWork(tag uint64, layout, gather int64) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && !p.ready {
		p.LayoutPaintNS += layout
		p.GatherNS += gather
	}
}
func (trace *FrameTrace) finishFrame(tag uint64, timing composer.ComposeTiming) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.rendering {
		p.rendering = false
		if p.ready {
			return
		}
		p.RasterUploadNS += timing.RasterUploadNS
		p.EncodeSubmitNS += timing.EncodeSubmitNS
		p.AcquireNS += timing.AcquireNS
		p.PresentCallNS += timing.PresentCallNS
		if trace.sourceDetails {
			if failure := appendFrameSourceDetails(p.SourceDetails, timing.SourceDetails); failure != "" && timing.Failure == "" {
				timing.Failure = failure
			}
		}
		submitted := timing.Supported && timing.Submitted && timing.Failure == ""
		p.Completed = p.frameArmed && submitted
		p.Failure = timing.Failure
		if !submitted && p.Failure == "" {
			p.Failure = "composition did not submit a measured frame"
		}
		p.TotalUIWorkNS = p.InputNS + p.OwnerNS + p.ReconcileNS + p.LayoutPaintNS + p.GatherNS + p.RasterUploadNS + p.EncodeSubmitNS
		p.ready = p.frameArmed || !submitted
	}
}

// noComposition accounts for an intermediate native update without GPU work.
// A final armed update must compose; an earlier unchanged paint may simply end.
func (trace *FrameTrace) noComposition(tag uint64, layout, gather int64) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.rendering {
		p.rendering = false
		if p.ready {
			return
		}
		p.LayoutPaintNS += layout
		p.GatherNS += gather
		if p.frameArmed {
			p.Failure = "armed frame did not reach composition"
			p.ready = true
		}
	}
}

func (trace *FrameTrace) frameFailed(tag uint64, message string) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.rendering = false
		if !p.ready {
			p.Failure = message
			p.ready = true
		}
	}
}
func (trace *FrameTrace) Fail(tag uint64, message string) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && !p.ready {
		p.Failure = message
		p.ready = true
	}
}
func (trace *FrameTrace) Take() (FrameTraceSample, bool) {
	if trace == nil {
		return FrameTraceSample{}, false
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.ready && (p.retired || p.inputDone && p.ownerDone && !p.rendering) {
		out := p.FrameTraceSample
		trace.pending = nil
		return out, true
	}
	return FrameTraceSample{}, false
}

// Retire ends diagnostic ownership after the native window lifetime stops.
// Ordinary cancellation retains the pending ticket through input/owner terminals.
func (trace *FrameTrace) Retire(tag uint64, message string) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		if !p.ready {
			p.Failure = message
			p.ready = true
		}
		p.retired = true
	}
}
func (trace *FrameTrace) Pending() bool {
	if trace == nil {
		return false
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	return trace.pending != nil
}

func (w *renderWindow) frameTrace() *FrameTrace {
	if stage := w.mains.windowStage(); stage != nil && stage.Scene != nil {
		return stage.Scene.FrameTrace()
	}
	return nil
}
