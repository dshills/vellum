package composer

import (
	"reflect"
	"testing"
)

type timingDrawer struct {
	DrawerBase
	order *[]string
}

func (d *timingDrawer) Start()  { *d.order = append(*d.order, "start") }
func (d *timingDrawer) End()    { *d.order = append(*d.order, "end") }
func (d *timingDrawer) Redraw() {}

type measuredTimingDrawer struct {
	timingDrawer
	result ComposeTiming
}

func (d *measuredTimingDrawer) EndMeasured() ComposeTiming {
	*d.order = append(*d.order, "measured-end")
	return d.result
}

type timingSource struct {
	label string
	order *[]string
}

func (s timingSource) Draw(Composer) { *s.order = append(*s.order, s.label) }

func TestVellumMeasuredCompositionKeepsOrderAndSingleEnd(t *testing.T) {
	for _, supported := range []bool{false, true} {
		var order []string
		base := timingDrawer{order: &order}
		var drawer Drawer = &base
		last := "end"
		if supported {
			drawer = &measuredTimingDrawer{timingDrawer: base, result: ComposeTiming{Supported: true, Submitted: true, EncodeSubmitNS: 31, AcquireNS: 1000, PresentCallNS: 2000}}
			last = "measured-end"
		}
		cd := &ComposerDrawer{Drawer: drawer, Sources: []Source{timingSource{"first", &order}, timingSource{"second", &order}}}
		result := cd.ComposeMeasured()
		if !reflect.DeepEqual(order, []string{"start", "first", "second", last}) {
			t.Fatalf("changed rendering: %v", order)
		}
		if supported && (!result.Supported || !result.Submitted || result.EncodeSubmitNS != 31 || result.AcquireNS != 1000 || result.PresentCallNS != 2000) {
			t.Fatalf("lost drawer result: %+v", result)
		}
		if !supported && (result.Supported || result.Submitted || result.Failure == "") {
			t.Fatal("qualified unknown drawer")
		}
	}
}

func TestVellumMeasuredCompositionPropagatesSubmissionFailure(t *testing.T) {
	var order []string
	d := &measuredTimingDrawer{timingDrawer: timingDrawer{order: &order}, result: ComposeTiming{Supported: true, Failure: "submit failed"}}
	result := (&ComposerDrawer{Drawer: d}).ComposeMeasured()
	if result.Submitted || result.Failure != "submit failed" || len(order) != 2 {
		t.Fatalf("masked failed submission: %+v %v", result, order)
	}
}
