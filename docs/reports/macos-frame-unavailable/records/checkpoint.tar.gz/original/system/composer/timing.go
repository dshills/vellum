package composer

import "time"

// ComposeTiming describes wall time in CPU-side composition work. Acquisition
// and the present call are separate; no GPU execution/presentation time is implied.
type ComposeTiming struct {
	RasterUploadNS, EncodeSubmitNS, AcquireNS, PresentCallNS int64
	Supported, Submitted                                     bool
	Failure                                                  string
	SourceDetails                                            *SourceDetails
}

// ComposeMeasured preserves the ordinary draw order and opts into a drawer's
// checked timing path. Unknown drawers cannot qualify an encoding measurement.
func (cd *ComposerDrawer) ComposeMeasured() ComposeTiming {
	start := time.Now()
	cd.Drawer.Start()
	for _, source := range cd.Sources {
		source.Draw(cd)
	}
	timing := ComposeTiming{RasterUploadNS: time.Since(start).Nanoseconds()}
	if drawer, ok := cd.Drawer.(interface{ EndMeasured() ComposeTiming }); ok {
		end := drawer.EndMeasured()
		end.RasterUploadNS += timing.RasterUploadNS
		return end
	}
	cd.Drawer.End()
	timing.Failure = "composition drawer does not support encoding timing"
	return timing
}
