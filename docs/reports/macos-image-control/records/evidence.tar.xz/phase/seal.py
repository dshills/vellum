"""Seal scoped managed-image evidence without executing a native app."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-image-control')
report=r/'docs/reports/macos-image-control';records=report/'records'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((p/'source-final-v2.json').read_text())
assert len(source['sources'])==16 and all(h(r/n)==d for n,d in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
assert len(prepared)==6198 and prepared==json.loads(Path('/private/tmp/vellum-macos-icon-controls/qualification.json').read_text())['prepared']
producers={h(p/'code_run.py'),h(p/'code_run-v1.py.txt')};receipts={}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv'not in d or 'source_delta_before'not in d:continue
 assert d['exit_code']in[0,1] and d['error']is None and d['source_delta_stable'] and d['producer_sha256']in producers
 assert d['prepared_before']==d['prepared_after']==prepared and d['overlay_inputs_before']==d['overlay_inputs_after']
 for channel in ['stdout','stderr']:assert h(p/(f.stem+'.'+channel))==d[channel+'_sha256']
 receipts[f.stem]={'receipt_sha256':h(f),'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'source':d['source_delta_before'],'stdout_sha256':d['stdout_sha256'],'stderr_sha256':d['stderr_sha256']}
required=['portable-final-v2','adapter-final-v2','image-final-v2','vet-final-v2','gallery-final-v2']
for name in required:
 d=json.loads((p/(name+'.json')).read_text());assert d['exit_code']==0 and d['source_delta_before']==source['sources']
negative={'unclipped-v2':'cover paint escaped image content','reanchored-v2':'clipped source was reanchored instead of scrolling','decode-preflight-v2':'oversized header entered decode'}
for name,message in negative.items():
 d=json.loads((p/(name+'.json')).read_text());output=(p/(name+'.stdout')).read_text()
 assert d['exit_code']==1 and d['source_delta_before']==source['sources'] and message in output and '=== RUN'in output and '--- FAIL:'in output and '[build failed]'not in output
 for filename,digest in d['overlay_inputs_before'].items():assert h(Path(filename))==digest
assert json.loads((p/'unclipped-v1.json').read_text())['exit_code']==0
review=json.loads((p/'review-final-v2.json').read_text());assert review.get('result',review.get('status'))=='APPROVED_SOURCE'
assert review['reviewed_file_sha256']=={str(r/n):d for n,d in source['sources'].items()}
provider=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and process['source_index_stable'] and process['before']==process['after']==source['sources']
assert provider['coverage']['complete'] and provider['coverage']['files']==16 and not provider['findings']
assert provider['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}] and process['prism_sha256']==h(p/'prism-v1/prism.json')
capture=json.loads((p/'capture-final-v2.json').read_text());qa=json.loads((p/'visual-qa.json').read_text())
assert capture['exit_code']==0 and capture['source_delta_before']==source['sources'] and qa['image_sha256']==h(p/'cover-frame.png') and qa['capture_receipt_sha256']==h(p/'capture-final-v2.json') and qa['source_manifest_sha256']==h(p/'source-final-v2.json')
families=[]
for manifest,directory in [('original-source.json','original'),('source-candidate-v1.json','candidate-v1'),('source-candidate-v2.json','candidate-v2'),('source-candidate-v3.json','candidate-v3')]:
 m=json.loads((p/manifest).read_text())
 for name,digest in m['sources'].items():
  assert h(p/directory/name)==digest;families.append((name,digest))
gaps={name:[n for n,d in receipt['source'].items()if(n,d)not in families]for name,receipt in receipts.items()}
(p/'historical-source-payloads.json').write_text(json.dumps({'available_manifests':['original-source.json','source-candidate-v1.json','source-candidate-v2.json','source-candidate-v3.json'],'receipt_payload_gaps':gaps,'scope':'Exact selected original/candidate/final root leaves and mutation payloads; intermediate fixture gaps are historical, not full compiler/SDK/dependency closure.'},indent=2)+'\n')
limits=['Physical Mac display/input/VoiceOver, native/GPU memory, sustained performance/endurance, distribution/release and full Mac completion remain open.',
 'Exact final16 root leaves and unchanged prepared6198 identities are scoped endpoints, not complete compiler/SDK/native binary closure.',
 'Ordinary source transforms/custom masks are safely refused by scene packet preflight. No direct GPU image/tile-upload claim.',
 'Retained pixel bounds do not bound decoder/conversion temporary memory or reader elapsed time; caller-owned cancellation and worker construction apply.',
 'Localized new-code mutations are not complete original-production builds. Earlier unmasked scroll mutation passed a weak image-owned-clipping oracle.',
 'Software DPI320/two-window frames, direct fixtures, inert Cocoa selectors and one inspected capture differ from physical Mac/native heap evidence.',
 'Initial Name/filter-boundary fixture mistakes, intermediate payload gaps and the first capture without forwarded environment are preserved. Gallery is BUILD ONLY.']
q={'result':'PASS_IMAGE_CONTROL','base_commit':source['base_commit'],'source':source['sources'],'required_receipts':required,'negative_receipts':negative,'prepared':prepared,'receipts':receipts,'source_review_sha256':h(p/'review-final-v2.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'prism_coverage':provider['coverage'],'prism_raw_exit_code':0,'prism_findings':0,'prism_findings_resolved':True,'provider_disposition':'One complete final16 provider run, raw0/no findings; exact source internally approved.','visual_qa_sha256':h(p/'visual-qa.json'),'limits':limits}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');records.mkdir(parents=True,exist_ok=True)
failed=sum(d['exit_code']==1 for d in receipts.values());tokens=provider['coverage']['tokens'][0]
(report/'README.md').write_text(f'''# Managed image previews

`ui.Image` reuses immutable `canvas.TiledImage` pixels as a passive retained
control. Contain centers all pixels, cover centers and crops, stretch fills both
axes. Fit changes painting, not the layout box. Preferred size caps the long edge
at 256 device-independent pixels, one minimum derives its partner, and max/style/
grow determine the box. Source/fit/style updates retain the widget. A named image
exposes AXImage/alternate text; an unnamed image is decorative. Neither adds an
action or Tab stop. See [catalog](../../controls.md), [contract](../../../specs/controls.md)
and [source-image contract](../../../specs/images.md).

The leaf scales immutable source through the ordinary scene painter using full
content coordinates and a composed visible-content/ancestor/opacity mask. It owns
no resized bitmap or cover-sized intermediate. Scene packet preflight safely
refuses this transform/custom-mask route; MeshCanvas direct GPU texture/tile
uploads have a separate contract. Removal drops the widget source reference while
caller-owned data remains usable.

`ui.DecodeImage` reads caller-owned PNG/JPEG data, bounded to 32 MiB plus one
refusal byte. Direct format configuration validates 1..8192 axes before decode,
then normalizes/copies immutable straight-alpha pixels. Retained pixel bounds
differ from temporary decode/conversion memory and reader time. Large decoding
belongs on an application worker with caller-owned reader cancellation. No path,
URL or chooser lookup occurs.

## Verification and review

Full portable/offscreen adapter race, image/gallery race3, vet and native gallery
BUILD ONLY pass on all sixteen final root leaves and unchanged 6,198 prepared
identities. The final full adapter execution takes
{receipts['adapter-final-v2']['elapsed_seconds']:.2f} seconds. Actual Manual frames check
independent centered-fit colors, cover overflow, straight-alpha blend, immutable
replacement/incarnation, real wheel mapping and viewport clipping. Two windows
share a source at logical DPI320; retiring one preserves the other. Direct fixtures
cover size/max/restoration, source release, alternate-text/decorative semantics
and mask composition. Inert Cocoa checks AXImage from an actual managed descriptor.
Decode fixtures check PNG/JPEG normalization, ownership, bytes, direct dimension
refusal, unsupported/corrupt data and reader errors. One inspected cover PNG is
archived with capture/source hashes; it is software visual evidence.

Three localized mutation overlays compile and assertion-fail: removing the image
mask paints outside the cover box; reanchoring to the clip loses scrolling;
bypassing dimension preflight enters decode. The same final fixtures pass race3.
Earlier unmasked scroll mutation returns raw0: its parent integration did not
expose image-owned clipping, so that oracle cannot prove the property. Independent
cover overflow now tests the image-owned mask. These are new-code fault seams,
not full original-production builds.

Internal source review approves exact final16. Prism runs once using Anthropic
Claude Sonnet 5.5, complete sixteen-file coverage, {provider['coverage']['chunks']} chunks,
{tokens['input']:,} input/{tokens['output']:,} output tokens, raw0/no findings.
Production bytes remain unchanged throughout later fixture corrections; source
review and execution scopes remain distinct. No repeated provider run or broad
Mac completion is inferred.

Two initial native attempts fail on a wrong Manual explicit-Name assumption and
a bilinear stripe-boundary sample. Final fixtures use the declared Manual name
and interior colors; semantic Text fallback has separate direct/native checks.
A first raw0 capture omits its file because child environment filters the supplied
variable. The preserved original runner and corrected explicit destination produce
the inspected PNG on a new count1 run. These remain historical attempts.
{len(receipts)} receipts/{len(receipts)*2} logs preserve {failed} raw exit1 attempts.
Exact selected source families and mutation inputs are archived; the historical
map lists intermediate fixture gaps. Binaries/caches and full compiler/SDK/native
dependency closure are excluded.

Separate evidence review binds the [checkpoint](records/checkpoint.json),
[archive](records/evidence.tar.xz) and [member index](records/evidence-index.json).
Physical Mac display/input/VoiceOver, native/GPU memory, sustained performance,
endurance, distribution rights/signing/release and full Mac completion remain
open. Native gallery compilation does not launch it.
''')
(records/'source-review.json').write_bytes((p/'review-final-v2.json').read_bytes())
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file()or f.suffix not in ['.go','.m','.json','.md','.py','.stdout','.stderr','.txt','.log','.png']:continue
 if f.name.startswith('evidence-review')or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in source['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size}for n,f in inputs.items()}
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','w:xz')as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
e={'source_manifest_sha256':h(p/'source-final-v2.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.xz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'review-final-v2.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e,indent=2))
