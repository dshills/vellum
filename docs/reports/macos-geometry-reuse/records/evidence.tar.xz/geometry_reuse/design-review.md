Approved source and corrected native harness; no unresolved findings.

The bridge-owned last-payload cache preserves shared-host overwrite behavior. Ordinary membership retirement and scope transitions invalidate reuse; unknown IDs, oversized payloads and token changes bypass it. Encoding/enqueue/cache commit and changed semantic publication serialize under the bridge mutex. The inspected C producers copy and asynchronously enqueue without an owner callback or synchronous main-thread wait. Close releases the retained metadata. Text and scoped Grid/Tree publication remain unchanged.

The live wrapper now rechecks source, inputs and binary after acquiring the shared lock. Its two declared builds, exact three changed source files and 6216 prepared inputs reconcile with the captured binary paths/hashes. Bounded stop/watchdog and owned-group cleanup are present.

This certifies source and harness only. The 64-KiB cap covers retained payload, not all metadata or process memory; cache commit is enqueue-level rather than native completion acknowledgement. Ordinary capture-time ordering and post-compile binary capture limitations remain. No native/performance/full-Mac acceptance is inferred.
