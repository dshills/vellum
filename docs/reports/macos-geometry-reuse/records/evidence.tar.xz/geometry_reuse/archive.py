from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-geometry-reuse');P=Path('/private/tmp/vellum-macos-geometry-reuse');D=R/'docs/reports/macos-geometry-reuse/records';D.mkdir(parents=True,exist_ok=True)
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
summary=json.loads((P/'final-summary.json').read_text());sources=summary['sources'];assert len(sources)==6 and all(sha(R/n)==v for n,v in sources.items())
internal=json.loads((P/'final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==sources
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==1 and not process['error'] and process['source_index_stable'] and process['before']==process['after']==sources
assert review['coverage']['complete'] and review['coverage']['files']==6 and len(review['findings'])==1 and review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
disposition=json.loads((P/'prism-disposition.json').read_text())
assert disposition['result']=='RESOLVED_NO_SOURCE_CHANGE'and disposition['disposition']=='REJECTED_FALSE_POSITIVE'and not disposition['unresolved_findings']and disposition['sources']==sources
assert disposition['finding_id']==review['findings'][0]['id']and disposition['prism_sha256']==sha(P/'prism-v1/prism.json')and disposition['process_sha256']==sha(P/'prism-v1/process.json')
assert all(sha(f)==h for f,h in disposition['reviewed_context_sha256'].items())and all(sha(f)==h for f,h in disposition['reviewed_artifact_sha256'].items())
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.cpu','.png'}
for folder,prefix in [(P,'geometry_reuse'),(Path('/private/tmp/vellum-macos-native-frame-profile'),'native_cpu_diagnostic')]:
 for f in sorted(folder.rglob('*')):
  if f.is_file() and not f.is_symlink() and '__pycache__'not in f.parts and f.suffix in allowed:inputs[prefix+'/'+f.relative_to(folder).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile() and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Native ordinary geometry cache/source/sender-oracle correctness and two existing Cocoa consumer workflows. Processwide stage62CPU diagnostics guide change and retain separate source scope. Native binaries excluded with recorded hashes; no ordinarylatencygain/nativeGPUmemory/presentation/physicalinput/humanVoiceOver/fullMac/P6/P11 qualification.'},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','internal_review_sha256':sha(P/'final-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':6,'prism_findings':1,'prism_unresolved_findings':0,'prism_raw_exit_code':1,'prism_disposition':'REJECTED_FALSE_POSITIVE','prism_disposition_sha256':sha(P/'prism-disposition.json'),'prism_calls':review['coverage']['llmCalls'],'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','prism_files','prism_findings','archive_sha256','archive_members','archive_bytes']}))
