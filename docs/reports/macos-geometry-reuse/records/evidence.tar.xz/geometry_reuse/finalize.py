from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-geometry-reuse');P=Path('/private/tmp/vellum-macos-geometry-reuse');D=Path('/private/tmp/vellum-macos-native-frame-profile')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
assert len(names)==6
sources={n:sha(R/n)for n in sorted(names)};code={n:h for n,h in sources.items()if n.startswith('drivers/')};assert len(code)==3
inputs=json.loads((P/'native-inputs.json').read_text());prepared=inputs['source']['prepared'];assert len(prepared)==6216 and inputs['source']['delta']==code
review=json.loads((P/'design-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and review['harness_result']=='APPROVED_HARNESS'and not review['unresolved_findings']and review['sources']==code and review['inputs_sha256']==sha(P/'native-inputs.json')and review['producer_sha256']==sha(P/'live.py')
checks={}
for name in ['prepare','geometry-race','adapter-race','adapter-vet','native-candidate-build','native-original-build','native-ax-build','fault-always-send','fault-stale-membership']:
 d=json.loads((P/(name+'.json')).read_text());expected=1 if name.startswith('fault-')else 0
 assert d['exit_code']==expected and not d['error']and d['source_delta_stable']and d['overlay_inputs_before']==d['overlay_inputs_after']
 assert d['prepared_after']==prepared
 if name!='prepare':assert d['source_delta_before']==d['source_delta_after']==code and d['prepared_before']==prepared
 for ch in ['stdout','stderr']:assert sha(P/(name+'.'+ch))==d[ch+'_sha256']
 checks[name]={'exit_code':d['exit_code'],'receipt_sha256':sha(P/(name+'.json')),'elapsed_seconds':d['elapsed_seconds'],'argv':d['argv'],'assertion_fault_expected':name.startswith('fault-')}
assert 'unchanged ordinary frame was republished'in(P/'fault-always-send.stdout').read_text()
assert 'semantic remove/readd did not invalidate geometry'in(P/'fault-stale-membership.stdout').read_text()
native={}
for name,binary in [('cocoa-stored-grid','loadedgrid'),('cocoa-general-accessibility','accessibility-smoke')]:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and not d['error']and d['source_stable']and d['owned_group_retired']
 assert d['source_before']==d['source_after']==inputs['source']and d['executable_sha256']==sha(P/binary)==inputs['binaries'][binary]['sha256']and d['inputs_sha256']==sha(P/'native-inputs.json')and d['producer_sha256']==sha(P/'live.py')
 for ch in ['stdout','stderr']:assert sha(P/(name+'.'+ch))==d[ch+'_sha256']
 events=[json.loads(x)for x in(P/(name+'.stdout')).read_text().splitlines()if x.startswith('{')]
 if name=='cocoa-stored-grid':
  assert len(events)==2 and events[0]['event']=='grid.accessibility.pass'and events[0]['visible_minimum']==400 and events[0]['rows']==1000000 and events[0]['native_press_admitted']and events[0]['overlap_objects_reused']==2268 and events[0]['replacement_objects_retired']==459 and events[1]['attachment_query_refused']
 else:assert len(events)==1 and events[0]['result']=='PASS'and events[0]['reachable_elements']==27 and not events[0]['voiceover_tested']and not events[0]['preferences_changed']
 native[name]={'exit_code':0,'receipt_sha256':sha(P/(name+'.json')),'binary_sha256':d['executable_sha256'],'elapsed_seconds':d['elapsed_seconds'],'observations':events,'stderr_present':bool((P/(name+'.stderr')).stat().st_size)}
post=json.loads((P/'post-terminal-groups.json').read_text());assert all(not x['members']and x['receipt_sha256']==sha(P/(x['run']+'.json'))for x in post['checks'])
diagnostic=json.loads((D/'evidence-review.json').read_text());assert diagnostic['result']=='APPROVED_SCOPED_DIAGNOSTIC_EVIDENCE'and not diagnostic['unresolved_findings']
source={'base_commit':inputs['source']['commit'],'sources':sources};(P/'checkpoint-source.json').write_text(json.dumps(source,indent=2)+'\n')
q={'result':'PASS_SCOPED_NATIVE_ORDINARY_GEOMETRY_REUSE',**source,'prepared_count':6216,'prepared_map_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True).encode()).hexdigest(),'checks':checks,'native':native,'design_review_sha256':sha(P/'design-review.json'),'diagnostic_evidence_review_sha256':sha(D/'evidence-review.json'),'diagnostic_profile_source_commit':'87e7de154b96732cad5dcb67703087115909c6f2','post_terminal_groups_sha256':sha(P/'post-terminal-groups.json'),'cache_payload_limit_bytes':65536,'membership_metadata_bound':'current ordinary identifier set, not a total memory bound','native_acknowledgement':False,'ordinary_frame_comparison_complete':False,'latency_gain_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,'scope':'Bounded last-payload reuse/sender oracles and existing Cocoa geometry/focus consumers; diagnostics guide work, no ordinary latency/nativeGPUbudget/presentation/fullMac qualification.'}
(P/'final-summary.json').write_text(json.dumps(q,indent=2)+'\n');print('PASS final six source/spec/report identities; seven code gates, two faults and both Cocoa consumers bound')
