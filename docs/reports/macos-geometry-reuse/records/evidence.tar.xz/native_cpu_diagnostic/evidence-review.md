Approved scoped native CPU diagnostic evidence; no unresolved findings.

Both raw streams reproduce their 515 result records, including 128 warm callbacks and 512 completed ordinary samples. Every geometry record matches across modes: 400 visible cells, with retained pools ranging from 468 to 540 (477 initially). Controller exit is zero, and a separate post-terminal process-group observation found no live members.

Saved profiles attribute an overlapping geometry-publication chain to 0.58 of 8.15 sampled CPU seconds in CPU mode and 0.83 of 7.94 seconds in GPU mode. These are process-wide inclusive samples. Cgo/event-loop stacks and focused subsets cannot establish exact native AX phase time or a latency gain. Concurrent endurance, earlier embedded build metadata, profiler/helper overhead, and unavailable presentation/GPU-memory observations remain explicit. No P6/P11 or full Mac acceptance is certified.

The JSON binds raw profiles, streams, results, analysis text/recipes, reviewed harness and selected relevant source bytes. No tests, native calls, provider calls, or frozen-worktree writes were performed.
