"""Process-wide native CPU diagnostics, distinct from warm latency qualification."""
from pathlib import Path
import fcntl,importlib.util,json,os,subprocess,sys,time
R=Path('/private/tmp/vellum-span-scratch');P=Path('/private/tmp/vellum-macos-native-frame-profile');Q=Path('/private/tmp/vellum-macos-quiet-current')
from native_identity import identity,sha
inputs_digest=sha(P/'inputs.json');producer_digest=sha(__file__);inputs=json.loads((P/'inputs.json').read_text());endpoint=inputs['endpoint'];binary=Path(inputs['binary']['path'])
assert len(endpoint['prepared'])==6216 and endpoint['clean']and endpoint['commit']==inputs['source_checkpoint']
assert sha(P/'native_identity.py')==inputs['identity_helper_sha256']and sha(R/'scripts/benchmark-grid.py')==inputs['benchmark_sha256']
def stop():
 if(Q/'stop-live').exists()or(P/'stop-live').exists():raise InterruptedError('human returned; stop diagnostic native profiles')
def stable():
 assert sha(P/'inputs.json')==inputs_digest and sha(__file__)==producer_digest
 assert identity(R)==endpoint and sha(binary)==inputs['binary']['sha256']and binary.stat().st_size==inputs['binary']['bytes']
stop();stable();lock=(Q/'native-live.lock').open('a+');locked=False;start=time.monotonic()
try:
 while not locked:
  stop()
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);locked=True
  except BlockingIOError:
   if time.monotonic()-start>90:raise TimeoutError('shared native diagnostic lock expired')
   time.sleep(.25)
 spec=importlib.util.spec_from_file_location('benchmark',R/'scripts/benchmark-grid.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
 # All benchmark children inherit the outer owner's group. The supervisor
 # unconditionally kills and reaps this group on success/error/stop/watchdog.
 class OwnedSubprocess:
  def __getattr__(self,n):return getattr(subprocess,n)
  def Popen(self,*args,**options):
   assert options.pop('start_new_session')is True
   child=subprocess.Popen(*args,**options)
   try:assert os.getpgid(child.pid)==os.getpgrp()
   except BaseException:
    if child.poll()is None:child.kill()
    child.wait(timeout=5);raise
   return child
 def kill_direct(child):
  if child.poll()is None:child.kill()
 b.subprocess=OwnedSubprocess();b.terminate_owned_group=kill_direct
 factory=b.selectors.DefaultSelector
 class StopAwareSelector:
  def __init__(self):self.inner=factory()
  def register(self,*args,**kwargs):return self.inner.register(*args,**kwargs)
  def select(self,*args,**kwargs):stop();return self.inner.select(*args,**kwargs)
  def close(self):return self.inner.close()
 b.selectors.DefaultSelector=StopAwareSelector
 results={}
 for mode in ['cpu','gpu']:
  stop();stable();profile=P/(mode+'.cpu')
  samples,process=b.run_case(binary,P/mode,10000,False,512,128,False,180,cpu_profile=profile,gpu_scene_rendering=mode=='gpu')
  assert process['result']=='PASS'and process['exit_code']==0 and len(samples)==512
  assert process['records'][0]['cpu_profile']is True and process['records'][1]['warmup']==process['records'][1]['warm_callbacks']==128
  assert all(r['warmup_guard']==1 for r in process['records'])and 0<profile.stat().st_size<=64<<20
  stable();results[mode]={'profile_sha256':sha(profile),'profile_bytes':profile.stat().st_size,'run_result_sha256':sha(P/mode/'result.json'),'native_log_sha256':sha(P/mode/'native.log'),'samples':512,'warm_callbacks':128,'geometry':samples[0]['geometry'],'cpu_profiling_active':True,'native_frame_budget_qualified':False}
  print(mode,'PASS_DIAGNOSTIC_PROFILE',profile.stat().st_size,flush=True)
 q={'result':'PASS_CURRENT_NATIVE_CPU_DIAGNOSTIC_PROFILES','source_commit':endpoint['commit'],'binary_sha256':inputs['binary']['sha256'],'inputs_sha256':inputs_digest,'producer_sha256':producer_digest,'results':results,'ordinary_comparison':False,'endurance_concurrent':True,'native_frame_budget_qualified':False,'physical_gpu_memory_qualified':False,'full_mac_qualified':False,'scope':inputs['scope']}
 (P/'summary.json').write_text(json.dumps(q,indent=2)+'\n')
finally:
 if locked:fcntl.flock(lock,fcntl.LOCK_UN)
 lock.close()
