from pathlib import Path
import importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent;A=Z.parent;s=importlib.util.spec_from_file_location('vet_guard',A/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);sdk=Path(json.loads((A/'macos-structure-catalogue-e9896d6/plan.json').read_bytes())['sdk'])
kind=sys.argv[1];assert kind in ['scope','baseline','core-analyzers'];name={'scope':'vet-scope-final','baseline':'vet-core-baseline','core-analyzers':'vet-core-analyzers'}[kind]
overlay=Z/'overlay.json'
if kind=='baseline':
 r=json.loads(overlay.read_bytes())
 for n in json.loads((Z/'files.json').read_bytes()):
  key=str(sdk/'drivers/cogent/build/upstream'/n);p=Z/'original'/n
  if p.is_file():r['Replace'][key]=str(p)
  else:r['Replace'].pop(key,None)
 overlay=Z/'baseline-overlay.json';assert not overlay.exists();overlay.write_text(json.dumps(r,indent=2)+'\n')
paths=[Path(p)for p in json.loads(overlay.read_bytes())['Replace'].values()if p]+[overlay,Path(__file__),Path(h.__file__),h.GUARD,h.GO];pins={str(p):h.sha(p)for p in paths}
args=['vet','-p=1','-overlay='+str(overlay),'-tags=offscreen']
if kind=='scope':args+=['.','./cmd/gallery','cogentcore.org/core/gpu','cogentcore.org/core/gpu/gpudraw']
else:
 if kind=='core-analyzers':args+=['-composites=false','-unreachable=false']
 args+=['cogentcore.org/core/core']
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args],sdk/'drivers/cogent',Z/name,lambda:False,lambda:all(h.sha(p)==v for p,v in pins.items()),timeout=240,limit=4<<20);r['source_pins']=pins;r['native_executed']=False
(Z/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');assert r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']
if kind=='baseline':
 assert r['exit_code']==1
 def diagnostics(p):return re.findall(r'^build/upstream/core/[^\n]+:\d+:\d+: [^\n]+$',p.read_text(),re.M)
 baseline=diagnostics(Z/name/'stderr');candidate=diagnostics(Z/'vet-final/stderr');assert len(baseline)==12 and baseline==candidate
 v={'result':'DEFAULT_CORE_VET_IDENTICAL_TO_PRE_STAGE85_BASELINE','baseline_exit_code':1,'candidate_exit_code':1,'diagnostics':baseline,'all_core_vet_passed':False,'baseline_overlay_sha256':h.sha(overlay),'candidate_vet_receipt_sha256':h.sha(Z/'vet-final.json'),'baseline_vet_receipt_sha256':h.sha(Z/(name+'.json'))};(Z/'vet-core-equivalence.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
else:
 assert r['exit_code']==0;print(json.dumps({'result':'PASS','kind':kind,'exit_code':0,'seconds':r['seconds'],'logs_complete':True,'pins_stable':True,'group_absent':True,'excluded_core_analyzers':['composites','unreachable']if kind=='core-analyzers'else[]}))
