"""Install an interrupting SIGTERM handler around the pinned prepare launcher.

The launcher runs in this process, so its owned-executor finally blocks retire
the child's new process group before this wrapper restores the previous handler.
This adds no retry and does not change the immutable earlier prepare receipts.
"""
from pathlib import Path
import datetime,hashlib,json,runpy,signal,sys
sys.dont_write_bytecode=True
assert len(sys.argv)==1
W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt=W/'canonical-prepare-guard.json';assert not receipt.exists()
pins={str(p):sha(p)for p in [Path(__file__).resolve(),W/'prepare_owned.py']}
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pins':pins,'exit_code':None,'error':None}
def interrupted(signum,frame):raise InterruptedError('canonical prepare signal '+str(signum))
previous=signal.signal(signal.SIGTERM,interrupted)
try:
 sys.argv=[str(W/'prepare_owned.py'),'prepare-canonical-final','canonical','prepare']
 runpy.run_path(str(W/'prepare_owned.py'),run_name='__main__')
except SystemExit as e:
 record['exit_code']=e.code
 raise
except BaseException as e:
 record['error']={'type':type(e).__name__,'message':str(e)}
 raise
finally:
 signal.signal(signal.SIGTERM,previous)
 record['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record['pins_stable']=all(sha(k)==v for k,v in pins.items())
 inner=W/'prepare-canonical-final.json'
 record['inner_receipt_sha256']=sha(inner)if inner.exists()else None
 receipt.write_text(json.dumps(record,indent=2)+'\n')
