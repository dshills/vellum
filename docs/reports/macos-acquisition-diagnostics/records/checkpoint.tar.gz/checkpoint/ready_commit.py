from pathlib import Path
import hashlib,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');R=T/'docs/reports/macos-acquisition-diagnostics/records'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=300,capture_output=True,check=True).stdout
review=read(W/'internal-commit-review.json');scope=read(W/'final-scope.json');provider=read(W/'review-scope.json');plan=read(W/'plan.json')
assert review['approved']and review['commit_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items())
assert set(review['inputs'])>={str(R/n)for n in ['checkpoint.tar.gz','manifest.json','archive.json']}|{str(Path(__file__).resolve()),str(W/'post_promotion.py'),str(W/'prepare_canonical_owned.py')}
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==plan['head']and not git(C,'status','--porcelain')and not git(T,'diff','--name-only')
assert sha(W/'final-staged.diff')==scope['staged_diff_sha256']==review['staged_diff_sha256']==hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()
assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths'])and all(sha(T/n)==v for n,v in scope['files'].items())
assert all(sha(k)==v for k,v in provider['source_hashes'].items())
assert all(sha(T/n)==v for n,v in plan['candidate_source'].items()if n.endswith('.go'))
p=read(W/'prism.json');cov=p['coverage'];assert cov['files']==len(provider['paths'])and cov['bytes']==provider['bytes']and cov['complete']and cov['llmCalls']==1 and not cov['excluded']and not cov['skipped']and not cov['truncatedBytes']and not p['suppressed']
assert read(W/'prism-command.json')['staged_diff_sha256']==provider['staged_diff_sha256']==sha(W/'prism-staged.diff')
d=read(W/'internal-prism-disposition.json');assert d['approved']and not d['unresolved_findings']and all(sha(k)==v for k,v in d['inputs'].items())
assert {f['id']for f in p['findings']}==set(d['retained_finding_ids'])and {f['finding']['id']for f in p['discarded']}==set(d['discarded_finding_ids'])
n=read(W/'case/stdout');assert n['Result']=='FAILED_NATIVE_STRUCTURE'and len(n['Inputs'])==16 and len(n['Steps'])==15 and n['Failed']is None and(W/'stop-live').is_file()
assert read(W/'failed-post-boundary.json')['all_vectors_match_admitted_plan']
manifest=read(R/'manifest.json');seen=set();expanded=0
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in manifest and m.name not in seen and not m.name.startswith('/')and '..'not in Path(m.name).parts
  seen.add(m.name);expanded+=m.size;assert len(seen)<=256 and expanded<=32<<20 and m.size<=10<<20
  data=tar.extractfile(m).read();assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
a=read(R/'archive.json');assert seen==set(manifest)and a['members']==len(seen)and a['expanded_bytes']==expanded and a['archive_sha256']==sha(R/'checkpoint.tar.gz')and a['manifest_sha256']==sha(R/'manifest.json')and a['archive_bytes']==(R/'checkpoint.tar.gz').stat().st_size<=8<<20
git(T,'diff','--cached','--check');print(git(T,'commit','-m','Record measured GPU acquisition outcomes and occlusion failure').decode());head=git(T,'rev-parse','HEAD').decode().strip();assert not git(T,'status','--porcelain')
print(git(C,'merge','--ff-only',head).decode());assert git(C,'rev-parse','HEAD').decode().strip()==head and not git(C,'status','--porcelain')
result={'commit':head,'canonical_clean':True,'candidate_clean':True,'canonical_prepare85_pending':True,'native_result':'FAILED16/15 actualoccluded','sdk_refreshed':False,'goal_complete':False}
(W/'commit-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
