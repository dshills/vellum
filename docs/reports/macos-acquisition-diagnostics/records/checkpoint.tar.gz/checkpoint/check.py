from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');A=Z.parent
s=importlib.util.spec_from_file_location('acquisition_guard',A/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);sdk=Path(json.loads((A/'macos-structure-catalogue-e9896d6/plan.json').read_bytes())['sdk'])
name,kind=sys.argv[1:];overlay=Z/'overlay.json'
if not overlay.exists():
 r=json.loads((A/'macos-structure-catalogue-e9896d6/overlay.json').read_bytes())
 for relative in json.loads((Z/'files.json').read_bytes()):r['Replace'][str(sdk/'drivers/cogent/build/upstream'/relative)]=str(Z/'candidate'/relative)
 overlay.write_text(json.dumps(r,indent=2)+'\n')
paths=[Path(p)for p in json.loads(overlay.read_bytes())['Replace'].values()if p]+[overlay,Path(__file__),Path(h.__file__),h.GUARD,h.GO];pins={str(p):h.sha(p)for p in paths}
base=['-p=1','-overlay='+str(overlay),'-tags=offscreen']
pattern='^Test(SurfaceAcquisitionYieldsAndBoundedRecovery|Vellum(MeasuredAcquisition|AcquisitionDescription|MeasuredPassPreserves|MeasuredPassFailure|FrameTrace|SurfaceAcquisition|PrepareOwnedFrame|OrdinaryAndMeasuredEnd|SurfaceFrame|SurfaceRetirement))'
if kind=='focused':args=['test','-v','-race','-count=1',*base,'-timeout=3m','-run',pattern,'cogentcore.org/core/gpu','cogentcore.org/core/gpu/gpudraw','cogentcore.org/core/core']
elif kind=='structure':args=['test','-v','-race','-count=1',*base,'-timeout=2m','-run','^TestStructureCataloguePublicManual$','./cmd/gallery']
elif kind=='driver':args=['test','-v','-race','-count=1',*base,'-timeout=8m','.']
elif kind=='gallery':args=['test','-v','-race','-count=1',*base,'-timeout=2m','./cmd/gallery']
elif kind=='vet':args=['vet',*base,'.','./cmd/gallery','cogentcore.org/core/gpu','cogentcore.org/core/gpu/gpudraw','cogentcore.org/core/core']
elif kind=='build':args=['build','-p=1','-overlay='+str(overlay),'-o',str(Z/'native-gallery'),'./cmd/gallery']
else:raise ValueError(kind)
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args],sdk/'drivers/cogent',Z/name,lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=540 if kind=='driver'else 300,limit=4<<20);r['source_pins']=pins;r['native_executed']=False
if kind=='build'and r['exit_code']==0:r['binary']={'path':str(Z/'native-gallery'),'sha256':h.sha(Z/'native-gallery')}
(Z/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
