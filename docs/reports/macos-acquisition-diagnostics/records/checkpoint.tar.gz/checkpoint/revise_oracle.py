from pathlib import Path
Z=Path(__file__).resolve().parent;old=Z.parent/'macos-structure-catalogue-e9896d6'
for name in ['validate.py','validation_controls.py']:(Z/name).write_bytes((old/name).read_bytes())
p=Z/'validate.py';s=p.read_text();marker='def validate(stdout,stderr):';assert marker in s
s=s.replace(marker,'''def section_layout(s,w,base_after,base_heights):
 if w['Page']!='sections':return
 els=snapshot(s);y=els[node('section-after')]['Bounds']['Min']['Y']
 if not w['Expanded']:
  need(y<base_after,'collapse releases actual layout');return
 # Independently exercised through public Manual at160/162DPI. Core removes
 # disabled button shadow margins (6px each) and reserved field border (2px).
 # Compare restoration within one effective style, not across styles.
 shrink=[6,2,6]if w['DetailsDisabled']else[0,0,0]
 need(y==base_after-sum(shrink),'style-specific section layout/restore')
 for target,normal,delta in zip([H,node('section-draft'),node('section-action')],base_heights,shrink):
  b=els[target]['Bounds'];need(b['Max']['Y']-b['Min']['Y']==normal-delta,'style-specific child metrics/restore')

'''+marker,1)
needle="first=d['Steps'][0]['Snapshot'];extent=(first['Size'],first['LogicalDPI']);baseAfter=publication(first,VALUES[0],0)[node('section-after')]['Bounds']['Min']['Y']";assert needle in s
s=s.replace(needle,needle+"\n need(first['LogicalDPI']in[160,162],'qualified style DPI');baseEls=snapshot(first);baseHeights=[baseEls[target]['Bounds']['Max']['Y']-baseEls[target]['Bounds']['Min']['Y']for target in[H,node('section-draft'),node('section-action')]]",1)
needle="  if VALUES[index]['Page']=='sections':\n   y=snapshot(s)[node('section-after')]['Bounds']['Min']['Y'];need(y==baseAfter if VALUES[index]['Expanded']else y<baseAfter,'collapse releases actual layout/restore')";assert needle in s;s=s.replace(needle,"  section_layout(s,VALUES[index],baseAfter,baseHeights)",1);p.write_text(s)
p=Z/'validation_controls.py';s=p.read_text().replace("box(20,95,850,25),m['Expanded']", "box(20,95,850,19 if m['DetailsDisabled']else 25),m['Expanded']",1).replace("box(20,250 if m['Expanded']else 140,180,30)", "box(20,(236 if m['DetailsDisabled']else 250)if m['Expanded']else 140,180,30)",1)
s=s.replace("box(30,130,470,30),'Vellum'", "box(30,130,470,28 if m['DetailsDisabled']else 30),'Vellum'",1).replace("box(30,170,180,30),enabled=not m['DetailsDisabled']", "box(30,170,180,24 if m['DetailsDisabled']else 30),enabled=not m['DetailsDisabled']",1)
marker="  mutations=[";assert marker in s
s=s.replace(marker,"""  def set_height(d,index,target,delta):
   e=next(e for e in d['Steps'][index]['Snapshot']['Elements']if e['ID']==target);e['Bounds']['Max']['Y']+=delta
  def unsupported_dpi(d):
   for s in [x['Snapshot']for x in d['Steps']]+[x['Before']for x in d['Inputs']]:s['LogicalDPI']=161
  mutations=[
   ('disabled-layout',lambda d:next(e for e in d['Steps'][12]['Snapshot']['Elements']if e['ID']==v.node('section-after'))['Bounds']['Min'].__setitem__('Y',250)),
   ('disabled-heading-height',lambda d:set_height(d,12,v.H,1)),
   ('disabled-field-height',lambda d:set_height(d,12,v.node('section-draft'),1)),
   ('disabled-action-height',lambda d:set_height(d,12,v.node('section-action'),1)),
   ('enabled-style-restoration',lambda d:set_height(d,41,v.H,1)),
   ('unsupported-style-dpi',unsupported_dpi),""",1);p.write_text(s)
print('Created distinct style-aware oracle and six added negative controls; sealed original untouched.')
