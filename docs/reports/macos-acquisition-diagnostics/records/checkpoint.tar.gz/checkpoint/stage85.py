from pathlib import Path
import difflib,hashlib,json,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'drivers/cogent';U=D/'build/upstream';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((Z/'internal-candidate-review.json').read_bytes());assert review['approved']and not review['unresolved_findings'];assert all(sha(p)==v for p,v in review['inputs'].items())
files=json.loads((Z/'files.json').read_bytes());original={};output={};parts=[]
for n in files:
 old=Z/'original'/n;new=Z/'candidate'/n;before=old.read_text()if old.is_file()else'';after=new.read_text()
 assert (sha(U/n)if(U/n).is_file()else None)==(sha(old)if old.is_file()else None)
 original[n]=sha(old)if old.is_file()else None;output[n]=sha(new)
 parts.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+n if old.is_file()else'/dev/null',tofile='b/'+n))
p=D/'native/patches/acquisitionoutcomes';p.mkdir(exist_ok=False)
patch=p/'0085-measured-acquisition-outcomes.patch';patch.write_text(''.join(parts));(p/'original-hashes.json').write_text(json.dumps(original,indent=2)+'\n');(p/'output-hashes.json').write_text(json.dumps(output,indent=2)+'\n')
(p/'README.md').write_text('''# Measured acquisition outcomes (stage 85)

An opt-in measured render pass carries a detached value containing source,
acquisition stage, actual attempt count and first/last backend statuses. The
existing acquisition protocol still yields on unavailability and retries a
lost/outdated surface at most once, preserving failed-handle release order.
Ordinary acquisition is unchanged. No polling, extra acquire/present, readback,
queue wait, retained history or native handles are added by the observation.

The existing measured APIs preserve their return and ownership conventions;
new optional outcome methods extend them. Legacy measured renderers report
unrecorded detail, and offscreen textures do not invent surface attempts or
statuses. Surface ownership/configuration/view work remains in the same timing
boundaries. Metadata work is charged as measured UI work.

Measured composition includes the outcome in an unavailable-pass failure or
wraps an existing failure with outcome context and errors.Is identity. A precise
acquisition result does not identify a later encoder/pass error as its cause.
Outcome descriptions are bounded by scalar enums/counts/statuses; arbitrary
existing backend error text is not newly bounded. Strict supported/submitted/
error-free frame completion is unchanged. The old failed structural scope is
immutable and cannot be diagnosed retrospectively from these new fields.

Injected regressions compare ordinary and observed acquisition/release/retry
protocols, unavailable/recovered/null/error/unknown outcomes, legacy compatibility,
actual GraphicsSystem no-frame routing, composition error propagation and strict
FrameTrace failure. These are separate from native device and physical acceptance.
''')
manifest=D/'native/dependencies.json';data=json.loads(manifest.read_bytes());dependency=next(d for d in data['dependencies']if d['name']=='upstream');assert dependency['stages'][-1]['patches'][0]['file'].endswith('0084-inspect-button-embedders.patch')
relative=p.relative_to(D).as_posix();dependency['stages'].append({'origin':'drivers/cogent/'+relative,'inputs':relative+'/original-hashes.json','outputs':relative+'/output-hashes.json','patches':[{'file':relative+'/'+patch.name,'sha256':sha(patch)}]});manifest.write_text(json.dumps(data,indent=2)+'\n')
r={'stage':85,'files':files,'input_hashes':original,'output_hashes':output,'patch_sha256':sha(patch),'candidate_review_sha256':sha(Z/'internal-candidate-review.json')};(Z/'stage85.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'stage':85,'patch_bytes':patch.stat().st_size,'files':len(files)}))
