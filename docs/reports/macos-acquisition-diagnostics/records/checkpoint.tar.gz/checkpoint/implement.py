from pathlib import Path
import json
Z=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');U=T/'drivers/cogent/build/upstream';O=Z/'original';N=Z/'candidate'
files=['gpu/surface_acquisition.go','gpu/surface_acquisition_test.go','gpu/surface_timing.go','gpu/gsystem_timing.go','gpu/gsystem_acquisition_test.go','gpu/gpudraw/system.go','gpu/gpudraw/acquisition.go','gpu/gpudraw/acquisition_test.go','core/frame_acquisition_test.go']
for n in files:
 for root in [O,N]:(root/n).parent.mkdir(parents=True,exist_ok=True)
 if(U/n).is_file():(O/n).write_bytes((U/n).read_bytes());(N/n).write_bytes((U/n).read_bytes())
def put(n,s):(N/n).write_text(s)
put('gpu/surface_acquisition.go','''// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
 "fmt"
 "github.com/oliverbestmann/webgpu/wgpu"
)

type AcquisitionSource uint8
const (
 AcquisitionUnknown AcquisitionSource = iota
 AcquisitionSurface
 AcquisitionRenderTexture
)
type AcquisitionStage uint8
const (
 AcquisitionUnrecorded AcquisitionStage = iota
 AcquisitionBackendError
 AcquisitionUnavailable
 AcquisitionMissingTexture
 AcquisitionTextureReady
 AcquisitionViewError
 AcquisitionViewReady
)
// AcquisitionOutcome is a detached value for one measured acquisition. It owns
// no native handles, callbacks, strings, history or persistent per-surface state.
// Surface acquisition makes at most two attempts; first/last preserve both.
type AcquisitionOutcome struct {
 Source AcquisitionSource
 Stage AcquisitionStage
 Attempts uint8
 FirstStatus, LastStatus wgpu.SurfaceGetCurrentTextureStatus
}
func (o AcquisitionOutcome) Description() string {
 source:="unknown"
 switch o.Source {case AcquisitionSurface:source="surface";case AcquisitionRenderTexture:source="render-texture"}
 stage:="unrecorded"
 switch o.Stage {case AcquisitionBackendError:stage="backend-error";case AcquisitionUnavailable:stage="unavailable";case AcquisitionMissingTexture:stage="missing-texture";case AcquisitionTextureReady:stage="texture-ready";case AcquisitionViewError:stage="view-error";case AcquisitionViewReady:stage="view-ready"}
 if o.Attempts==0 {return fmt.Sprintf("source=%s stage=%s attempts=0 statuses=unrecorded",source,stage)}
 status:=func(s wgpu.SurfaceGetCurrentTextureStatus)string{name:=s.String();if name==""{name="unknown"};return fmt.Sprintf("%s(%d)",name,uint32(s))}
 return fmt.Sprintf("source=%s stage=%s attempts=%d first=%s last=%s",source,stage,o.Attempts,status(o.FirstStatus),status(o.LastStatus))
}
// This observes the existing acquisition implementation, without changing its
// yield, retry, configure or failed-handle release decisions. Only the measured
// caller uses it; the ordinary acquisition path remains unchanged.
func acquireSurfaceFrameOutcomeOwned(acquire func()(wgpu.SurfaceTexture,error),configure func(),release func(*wgpu.Texture))(wgpu.SurfaceTexture,AcquisitionOutcome,error){
 outcome:=AcquisitionOutcome{Source:AcquisitionSurface}
 frame,err:=acquireSurfaceFrameOwned(func()(wgpu.SurfaceTexture,error){
  frame,err:=acquire();outcome.Attempts++;outcome.LastStatus=frame.Status
  if outcome.Attempts==1{outcome.FirstStatus=frame.Status}
  return frame,err
 },configure,release)
 switch {case err!=nil:outcome.Stage=AcquisitionBackendError;case !frame.IsStatusSuccess():outcome.Stage=AcquisitionUnavailable;case frame.Texture==nil:outcome.Stage=AcquisitionMissingTexture;default:outcome.Stage=AcquisitionTextureReady}
 return frame,outcome,err
}
''')
p=N/'gpu/surface_timing.go';s=p.read_text();needle='func (sf *Surface) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {';assert needle in s;s=s.replace(needle,'''func (sf *Surface) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
 view,elapsed,_,err:=sf.GetCurrentTextureMeasuredWithOutcome()
 return view,elapsed,err
}
// GetCurrentTextureMeasuredWithOutcome adds detached acquisition evidence without
// changing the legacy measured method's return or lock ownership conventions.
func (sf *Surface) GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, AcquisitionOutcome, error) {''',1)
s=s.replace('stexture, err := acquireSurfaceFrame(', 'stexture, outcome, err := acquireSurfaceFrameOutcomeOwned(',1).replace('}, sf.Config)', '}, sf.Config,func(texture *wgpu.Texture){texture.Release()})',1)
s=s.replace('return nil, acquireNS, err','return nil, acquireNS, outcome, err').replace('return nil, acquireNS, nil','return nil, acquireNS, outcome, nil').replace('return view, acquireNS, nil','outcome.Stage=AcquisitionViewReady\n return view, acquireNS, outcome, nil')
s=s.replace('if err != nil || view == nil {','if err != nil || view == nil {\n outcome.Stage=AcquisitionViewError',1)
s+='''
// Offscreen textures have no surface attempts/statuses; never invent them.
func(rt *RenderTexture)GetCurrentTextureMeasuredWithOutcome()(*wgpu.TextureView,int64,AcquisitionOutcome,error){
 view,err:=rt.GetCurrentTexture()
 outcome:=AcquisitionOutcome{Source:AcquisitionRenderTexture,Stage:AcquisitionViewReady}
 if err!=nil{outcome.Stage=AcquisitionViewError}else if view==nil{outcome.Stage=AcquisitionUnavailable}
 return view,0,outcome,err
}
''';p.write_text(s)
p=N/'gpu/gsystem_timing.go';s=p.read_text();needle='func (sy *GraphicsSystem) BeginRenderPassMeasured() (*wgpu.RenderPassEncoder, int64, error) {';assert needle in s;s=s.replace(needle,'''func (sy *GraphicsSystem) BeginRenderPassMeasured() (*wgpu.RenderPassEncoder, int64, error) {
 pass,elapsed,_,err:=sy.BeginRenderPassMeasuredWithOutcome()
 return pass,elapsed,err
}
// BeginRenderPassMeasuredWithOutcome preserves the existing measured renderer
// contract and optionally carries a detached outcome from its actual call.
// Legacy measured renderers report unrecorded detail, never guessed statuses.
func(sy *GraphicsSystem)BeginRenderPassMeasuredWithOutcome()(*wgpu.RenderPassEncoder,int64,AcquisitionOutcome,error){''',1)
s=s.replace('return nil, 0, errors.New(', 'return nil, 0, AcquisitionOutcome{}, errors.New(',1)
s=s.replace('var acquire int64','var acquire int64\n var outcome AcquisitionOutcome',1)
s=s.replace('view, elapsed, err := measured.GetCurrentTextureMeasured()','''var view *wgpu.TextureView
  var elapsed int64
  var err error
  if detailed,ok:=sy.Renderer.(interface{GetCurrentTextureMeasuredWithOutcome()(*wgpu.TextureView,int64,AcquisitionOutcome,error)});ok{
   view,elapsed,outcome,err=detailed.GetCurrentTextureMeasuredWithOutcome()
  }else{view,elapsed,err=measured.GetCurrentTextureMeasured()}''',1).replace('return pass, acquire, err','return pass, acquire, outcome, err',1);p.write_text(s)
p=N/'gpu/gpudraw/system.go';s=p.read_text();s=s.replace('rp, timing.AcquireNS, err = sy.BeginRenderPassMeasured()', 'rp, err = beginMeasuredPass(sy,timing)',1);p.write_text(s)
put('gpu/gpudraw/acquisition.go','''// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpudraw
import (
 "fmt"
 "cogentcore.org/core/gpu"
 "cogentcore.org/core/system/composer"
 "github.com/oliverbestmann/webgpu/wgpu"
)
// Called only by the measured path. No extra acquire, retry, polling, readback,
// wait or presentation is added. A missing pass remains an unsuccessful frame.
func beginMeasuredPass(sy *gpu.GraphicsSystem,timing *composer.ComposeTiming)(*wgpu.RenderPassEncoder,error){
 pass,elapsed,outcome,err:=sy.BeginRenderPassMeasuredWithOutcome()
 timing.AcquireNS=elapsed
 if err!=nil{return pass,fmt.Errorf("gpu: measured render pass failed (%s): %w",outcome.Description(),err)}
 if pass==nil{timing.Failure="gpu: measured render pass unavailable ("+outcome.Description()+")"}
 return pass,nil
}
''')
(Z/'files.json').write_text(json.dumps(files,indent=2)+'\n')
print('Wrote measured-only acquisition outcome candidate; prepared checkouts remain unchanged.')
