from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
read=lambda p:json.loads(Path(p).read_bytes())
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def base(n):
 s=run_child(['git','show','HEAD:'+n],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode()
 return s.replace('complete driver/gallery race suites, but have not received a new native run.\nThey retain the failed scope and do not close the full structural/native gate.', 'complete driver-root/gallery race suites. At that prior checkpoint they had not\nreceived a new native run. The failed diagnostic attempt below now exercises\nthose fixes but does not complete structural qualification. Both failed scopes\nremain sealed and the full structural/native gate stays open.')
r=read(W/'result.json');n=read(W/'case/stdout');b=read(W/'failed-post-boundary.json')
assert r['result']=='FAILED_OR_CANCELED' and r['run']['exit_code']==1 and r['run']['owned']['group_absent']
assert len(n['Inputs'])==16 and len(n['Steps'])==15 and n['Failed']is None
assert 'first=occluded(196609) last=occluded(196609)'in n['Error'] and b['all_vectors_match_admitted_plan']
R=T/'docs/reports/macos-acquisition-diagnostics';(R/'records').mkdir(parents=True,exist_ok=True)
(R/'README.md').write_text('''# Measured GPU acquisition diagnostics

Stage85 records a detached acquisition outcome on the measured composition path:
source, stage, actual attempt count and first/last backend statuses. An unavailable
render pass now produces a specific failure instead of the generic missing-frame
message. Existing acquisition/release/configuration decisions, the single allowed
lost/outdated retry, ownership, timing boundaries and strict completed-frame
criteria are unchanged. Ordinary drawing adds no observation. Existing measured
methods retain their return conventions; optional detail methods support legacy
renderers with unrecorded status and offscreen textures with no invented surface
attempts. Metadata has bounded scalar descriptions and retains no handles/history.
Existing arbitrary backend error strings are not newly bounded.

The fresh, separately admitted native structural case **FAILED** after16 acknowledged
Go FIFO inputs and15 source-asserted observations, last `section-reenabled`.
The refused `page-disabled-refusal` input is acknowledged at Frame76; the following
Frame fails before a Snapshot/model observation. The actual acquisition reports
`source=surface stage=unavailable attempts=1 first=occluded(196609)
last=occluded(196609)`. No failed snapshot, disabled-page observation, later split/
document result or full50-input/42-state pass is inferred. The raw producer exits1
in3.581s. Session cleanup reports Closed=true, Pending=false, LiveWindows=0 after79
issued requests; original-window close was not reached. Owned process group72988
is absent. Raw logs are complete and pinned inputs unchanged. A separate complete
post-failure source/prepared/SDK/binary boundary check passes; the controller's
post-validation boundary did not execute. This scope is permanently sealed.

This identifies the unavailable surface in this run only. It does not establish
why the backend reported it occluded, nor diagnose the older41/35 failure, which has no
acquisition detail. The next product action is to define and implement bounded
visibility-aware scheduling of explicit Frame requests: preserve strict completion,
never spin/present a fabricated frame, keep cancellation/closure responsive, and
design a supported signal to resume eligible pending work when drawable availability
returns. Current shown/nonminimized state alone supplies no drawable-availability
notification. Exercise hidden/
occluded-to-visible and cancellation paths with deterministic injected outcomes
before admitting a distinct native scope. Do not repeatedly retry sealed cases.

The original geometry oracle and failure stay immutable. A separate strengthened
oracle covers only160/162DPI: disabled heading/draft/action heights shrink6/2/6px,
and their restored enabled metrics equal the original enabled metrics. Actual
public Manual consumer tests pass at both DPIs, including retained children,
keys, pointers, split/scroll/document behavior. One positive and40 negative
synthetic oracle controls pass. These software fixtures are not native evidence;
the new native case has no complete independent oracle pass.

The complete driver-root package (`.`) and gallery race suites, focused acquisition/composition/
FrameTrace regressions, native gallery build,11 prepare tests and two identical
offline preparations pass. Prepared output has6274 files. Injected acquisition
cases assert exact ordinary versus measured calls and independently expected
release/configure order for occluded/timeout/error/lost/outdated/recovery/null/
suboptimal/unknown outcomes. GraphicsSystem, gpudraw and Core tests preserve error
identity and reject failed frames even with Submitted=true.

Default driver/gallery/GPU vet passes. Default broader Core vet **fails** with12
diagnostics reproduced exactly on pre-stage85 source:10 unkeyed composites and2
unreachable-code diagnostics. Both failures are retained; remaining Core analyzers
pass with just those two inherited analyzer classes excluded. The initial prepare
test also failed because its patch-number endpoint excluded85; the corrected
endpoint and all11 tests pass. No unrelated Core source is changed to hide these
failures, and no unfiltered Core test suite is run.

Internal source/controller and exact-plan reviews precede native execution.
Prism provider review, independent dispositions and final archive/commit review
are required before commit. The bounded [archive](records/checkpoint.tar.gz) and
[manifest](records/manifest.json) will retain raw checks, failures, source,
controllers, plan/admission and review payloads without executables or SDK copies.
See [results](records/results.json).

Evidence uses Go1.25.6 ARM64/GOMAXPROCS2 CPU-scene, retained source-built native
archive786a and the immutable7880-file SDK. All current non-prototype Go, native
support and prepared bytes match the effective SDK overlay. The SDK native-library
override is scoped; the checkout default cached library is not qualified by this
run. No SDK refresh or public release occurs. Go FIFO establishes no physical/OS
input, native pixels, presentation, IME/VoiceOver, split dragging, arbitrary display
transitions, performance or native/GPU memory/endurance. Full structural M2,
physical M5 and M3–M7 stay open. Follow the [Mac delivery plan](../../../specs/macos-delivery.md).
''')
checks={}
for name in ['focused-v1','style-v1','focused-final','driver-final','gallery-final','build-final','validation-final','prepare-unit','prepare-unit-final','prepare-candidate','prepare-candidate-final','vet-final','vet-core-baseline','vet-scope-final','vet-core-analyzers']:
 d=read(W/(name+'.json'));checks[name]={k:d.get(k)for k in ['exit_code','seconds','error','logs_complete','pins_stable','owned','logs']}
results={'native':n,'owned_run':r,'post_failure_boundary':b,'checks':checks,'core_vet_equivalence':read(W/'vet-core-equivalence.json'),'stage85':read(W/'stage85.json'),'native_independent_validation_complete':False,'physical_input_verified':False,'closed_full_mac_gates':[],'sdk_refresh':False}
(R/'records/results.json').write_text(json.dumps(results,indent=2)+'\n')
note='''

### Measured acquisition checkpoint

The [acquisition diagnostics result](../docs/reports/macos-acquisition-diagnostics/README.md)
adds measured-only actual source/stage/status/attempt detail without changing
ordinary retry/release behavior or strict completed-frame criteria. A distinct
native50/42 scope fails after16 inputs/15 source-asserted observations with
actual `occluded(196609)` on one acquisition attempt. Cleanup and separate whole
post-failure boundaries pass; full native validation remains open. This result
does not identify the older failure's cause. Both scopes remain sealed.
The new style-aware oracle has separate public Manual160/162DPI and41 synthetic
controls, with no complete native oracle pass. Complete driver-root (`.`)/gallery race, focused
GPU/Core regressions, build, prepare and affected-package vet pass; default Core
vet retains12 exact baseline diagnostics. Next implement bounded visibility-aware
Frame scheduling and deterministic hidden/occluded/visible/cancel coverage before
a distinct native admission. Do not fabricate completion or spin on acquisition.
Full M2/M5 and M3–M7 remain open; performance targets and release gates are unchanged.
'''
for name in ['specs/macos-delivery.md','specs/macos-completion.md','specs/control-acceptance.md']:
 p=T/name;p.write_text(base(name)+note)
p=T/'docs/desktop-integration.md';p.write_text(base('docs/desktop-integration.md')+'''

### Measured acquisition failures

With the prepared stage85 backend, a measured render-pass failure includes a
detached acquisition description: source, stage, actual attempt count and first/
last backend statuses. A surface unavailable due to occlusion may yield an error
such as `gpu: measured render pass unavailable (source=surface stage=unavailable
attempts=1 first=occluded(196609) last=occluded(196609))`. A successful acquisition
does not identify the cause of any later encoder/pass failure. Backend errors
retain their existing error identity and text with additional acquisition context.
Legacy measured implementations may report unrecorded detail; offscreen render
textures have no surface status/attempts. No extra acquire, poll, present, wait or
readback is performed, and acquisition timing boundaries are unchanged. Metadata
work counts as UI work. Supported=true, Submitted=true and no failure are still
required for a completed Frame. Native occlusion-to-visible scheduling acceptance
is open; see the [diagnostic checkpoint](reports/macos-acquisition-diagnostics/README.md).
''')
print(json.dumps({'documentation_written':True,'native_result':n['Result'],'inputs':16,'source_asserted_observations':15}))
