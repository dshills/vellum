from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');A=Z.parent
s=importlib.util.spec_from_file_location('prepare_guard',A/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
name,target,kind=sys.argv[1:];root={'candidate':T,'canonical':C}[target];D=root/'drivers/cogent';manifest=D/'native/dependencies.json';dependencies=json.loads(manifest.read_bytes())['dependencies'];sdk=Path(json.loads((A/'macos-structure-catalogue-e9896d6/plan.json').read_bytes())['sdk'])
paths=[D/'prepare.py',D/'prepare_test.py',manifest,Path(__file__),Path(h.__file__),h.GUARD,h.GO]
for dependency in dependencies:
 for stage in dependency['stages']:
  paths.extend(D/stage[n]for n in ['inputs','outputs']if n in stage);paths.extend(D/p['file']for p in stage['patches'])
pins={str(p):h.sha(p)for p in paths}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','PYTHONDONTWRITEBYTECODE':'1'}
args=['/usr/bin/python3','-B',str(D/'prepare.py')]if kind=='prepare'else['/usr/bin/python3','-B','-m','unittest','-v','prepare_test']
assert kind in ['prepare','unit']and name not in ['case']and not(Z/name).exists()
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*args],D,Z/name,lambda:False,lambda:all(h.sha(p)==v for p,v in pins.items()),timeout=300,limit=4<<20);r['source_pins']=pins;r['native_executed']=False
if r['exit_code']==0 and kind=='prepare':
 expected=json.loads((Z/'stage85.json').read_bytes())['output_hashes'];assert all(h.sha(D/'build/upstream'/n)==v for n,v in expected.items())
 prepared={m+'/'+p.relative_to(D/'build'/m).as_posix():h.sha(p)for m in ['upstream','typesetting']for p in(D/'build'/m).rglob('*')if p.is_file()};assert len(prepared)==6274
 (Z/(name+'-prepared.json')).write_text(json.dumps(prepared,indent=2)+'\n');r['prepared_files']=len(prepared);r['prepared_sha256']=hashlib.sha256(json.dumps(prepared,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(Z/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned','prepared_files','prepared_sha256']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
