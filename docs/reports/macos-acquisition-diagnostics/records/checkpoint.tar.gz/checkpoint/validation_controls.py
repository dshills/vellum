"""Synthetic oracle controls only. Does not run a native window."""
import copy,json,unittest
import validate as v

def box(x=0,y=0,w=0,h=0):return {'Min':{'X':x,'Y':y},'Max':{'X':x+w,'Y':y+h}}
def fixture_snapshot(index,frame):
 m=v.VALUES[index];els=[]
 def add(target,role,parent='',bounds=None,value=None,enabled=True,selected=False):
  e=dict(ID=target,DomainID='',Parent=parent,Role=role,Name=target,Value=value,Bounds=bounds or box(),Enabled=enabled,Focused=target==v.FOCUS[index],Selected=selected);els.append(e);return e
 root=v.node('structure-catalogue');add(root,'column',bounds=box(0,0,900,700));add(v.node('structure-title'),'label',root,box(10,10,600,25));add(v.P,'tabs',root,box(10,45,880,610));add(v.node('structure-status'),'status-bar',root,box(10,665,850,25),f"Page {m['Page']} / expanded {str(m['Expanded']).lower()} / split {m['Fraction']:.2f} / documents {len(m['Documents'].split(','))}")
 for i,opt in enumerate(['sections','unavailable','split-page','documents']):add(v.id('option','structure-pages',opt),'option',v.P,box(10+i*180,45,170,30),opt==m['Page'],opt!='unavailable',opt==m['Page'])
 page=v.node(m['Page']);add(page,'column',v.P,box(10,85,880,565))
 if m['Page']=='sections':
  parent=v.node('details');add(parent,'disclosure',page,box(15,90,865,145 if m['Expanded']else 35));add(v.H,'disclosure-heading',parent,box(20,95,850,19 if m['DetailsDisabled']else 25),m['Expanded'],not m['DetailsDisabled']);add(v.node('section-after'),'button',page,box(20,(236 if m['DetailsDisabled']else 250)if m['Expanded']else 140,180,30))
  if m['Expanded']:
   add(v.node('section-draft'),'text-field',parent,box(30,130,470,28 if m['DetailsDisabled']else 30),'Vellum',not m['DetailsDisabled']);add(v.node('section-action'),'button',parent,box(30,170,180,24 if m['DetailsDisabled']else 30),enabled=not m['DetailsDisabled'])
 elif m['Page']=='split-page':
  pane=v.node('panes');x=15+round(m['Fraction']*860);add(pane,'split-pane',page,box(15,90,870,560));add(v.S,'split-handle',pane,box(x,90,10,560),m['Fraction'],not m['SplitDisabled']);scroll=v.node('split-workspace');add(scroll,'scroll',pane,box(x+10,90,885-x-10,560),enabled=not m['SplitDisabled'])
  add(v.node('split-reset'),'button',scroll,box(x+12,125,max(1,880-x-12),25),enabled=not m['SplitDisabled']);bottom=v.LABELS[index]in['scroll-bottom','scroll-boundary'];add(v.node('split-line-00'),'label',scroll,box()if bottom else box(x+12,170,max(1,880-x-12),25));add(v.node('split-line-23'),'label',scroll,box(x+12,600,max(1,880-x-12),25)if bottom else box())
 else:
  add(v.D,'tabs',page,box(15,190,865,460))
  for i,doc in enumerate(m['Documents'].split(',')):
   opt=v.id('option','document-tabs',doc);add(opt,'option',v.D,box(20+i*180,195,170,35),doc==m['Document'],selected=doc==m['Document']);add(v.id('tab-close','document-tabs',doc),'button',opt,box(155+i*180,200,25,25))
  content=v.node(m['Document']);add(content,'column',v.D,box(20,240,850,390));add(v.node('document-content-'+m['Document']),'text-field',content,box(30,250,470,30),{'sketch':'Untitled sketch','notes':'Working notes'}[m['Document']])
 return dict(Frame=frame,Size={'X':900,'Y':700},LogicalDPI=160,Elements=els,Grids=[],Trees=[],Canvases=[],Popups=[])

def fixture():
 steps=[dict(Label=l,Model=copy.deepcopy(v.VALUES[i]),Snapshot=fixture_snapshot(i,i*10+9))for i,l in enumerate(v.LABELS)];inputs=[];per={};stale=None
 for label,target,typ,code,rune,delta,reject in v.PACKETS:
  main=label.split('/')[0];i=v.LABELS.index(main);per[main]=per.get(main,0)+1;s=fixture_snapshot(i,i*10+per[main]);els={e['ID']:e for e in s['Elements']};point={'X':0,'Y':0}
  if typ=='KeyChord'and not reject:els[target]['Focused']=True
  if typ!='KeyChord':
   if main=='document-stale-close':point=stale.copy()
   else:
    b=els[target]['Bounds'];point={k:(b['Min'][k]+b['Max'][k])//2 for k in ['X','Y']}
  if label=='document-pointer-rejected/MouseUp':stale=point.copy()
  inp=dict(Frame=s['Frame'],Target=target,Type=typ,Code=code,Rune=rune,Modifiers='',Button='Left'if typ in['MouseDown','MouseUp']else'NoButton',Position=point,Delta={'X':0,'Y':delta});inputs.append(dict(Label=label,Before=s,Input=inp,Rejected=reject))
 return dict(Event='vellum.structure-native.result',Result='PASS_NATIVE_STRUCTURE',Error='',Steps=steps,Inputs=inputs,Failed=None,Session=dict(Started=True,Closed=True,Pending=False,LiveWindows=0,Issued=300),OriginalRefClosed=True,PostCloseInputError='closed')

def encode(d):return(json.dumps(d,separators=(',',':'))+'\n').encode()
class Controls(unittest.TestCase):
 def test_positive(self):self.assertEqual(v.validate(encode(fixture()),b'')['inputs'],50)
 def test_negative(self):
  def set_height(d,index,target,delta):
   e=next(e for e in d['Steps'][index]['Snapshot']['Elements']if e['ID']==target);e['Bounds']['Max']['Y']+=delta
  def unsupported_dpi(d):
   for s in [x['Snapshot']for x in d['Steps']]+[x['Before']for x in d['Inputs']]:s['LogicalDPI']=161
  mutations=[
   ('disabled-layout',lambda d:next(e for e in d['Steps'][12]['Snapshot']['Elements']if e['ID']==v.node('section-after'))['Bounds']['Min'].__setitem__('Y',250)),
   ('disabled-heading-height',lambda d:set_height(d,12,v.H,1)),
   ('disabled-field-height',lambda d:set_height(d,12,v.node('section-draft'),1)),
   ('disabled-action-height',lambda d:set_height(d,12,v.node('section-action'),1)),
   ('enabled-style-restoration',lambda d:set_height(d,41,v.H,1)),
   ('unsupported-style-dpi',unsupported_dpi),
   ('missing-step',lambda d:d['Steps'].pop()),('extra-step',lambda d:d['Steps'].append(d['Steps'][-1])),('missing-input',lambda d:d['Inputs'].pop()),('reordered-step',lambda d:d['Steps'].reverse()),('bad-model',lambda d:d['Steps'][20]['Model'].__setitem__('SplitRequests',2)),('fraction',lambda d:d['Steps'][20]['Model'].__setitem__('Fraction',.5)),('bool-as-count',lambda d:d['Steps'][0]['Model'].__setitem__('DetailsRequests',False)),('failed-snapshot',lambda d:d.__setitem__('Failed',d['Steps'][0])),('error',lambda d:d.__setitem__('Error','failed')),('wrong-result',lambda d:d.__setitem__('Result','FAILED_NATIVE_STRUCTURE')),('pending',lambda d:d['Session'].__setitem__('Pending',True)),('live-window',lambda d:d['Session'].__setitem__('LiveWindows',1)),('open-session',lambda d:d['Session'].__setitem__('Closed',False)),('original-ref',lambda d:d.__setitem__('OriginalRefClosed',False)),('postclose',lambda d:d.__setitem__('PostCloseInputError','')),('key-code',lambda d:d['Inputs'][0]['Input'].__setitem__('Code','RightArrow')),('key-rune',lambda d:d['Inputs'][0]['Input'].__setitem__('Rune',97)),('modifier',lambda d:d['Inputs'][0]['Input'].__setitem__('Modifiers','Meta')),('target',lambda d:d['Inputs'][0]['Input'].__setitem__('Target',v.node('section-after'))),('frame',lambda d:d['Inputs'][0]['Input'].__setitem__('Frame',1)),('interleaving',lambda d:d['Inputs'][0]['Before'].__setitem__('Frame',1)),('refusal',lambda d:d['Inputs'][0].__setitem__('Rejected',True)),('scroll-delta',lambda d:next(x for x in d['Inputs']if x['Label']=='scroll-bottom')['Input']['Delta'].__setitem__('Y',1)),('position',lambda d:d['Inputs'][2]['Input']['Position'].__setitem__('X',899)),('key-focus',lambda d:next(e for e in d['Inputs'][0]['Before']['Elements']if e['ID']==v.H).__setitem__('Focused',False)),
   ('status',lambda d:next(e for e in d['Steps'][0]['Snapshot']['Elements']if e['ID']==v.node('structure-status')).__setitem__('Value','wrong')),('divider-geometry',lambda d:next(e for e in d['Steps'][20]['Snapshot']['Elements']if e['ID']==v.S).__setitem__('Bounds',box(700,90,10,560))),('scroll-endpoint',lambda d:next(e for e in d['Steps'][28]['Snapshot']['Elements']if e['ID']==v.node('split-line-00')).__setitem__('Bounds',box(500,200,100,25))),('closed-target-reappeared',lambda d:next(x for x in d['Inputs']if x['Label']=='document-stale-close')['Before']['Elements'].append(copy.deepcopy(next(e for e in d['Steps'][36]['Snapshot']['Elements']if e['ID']==v.id('tab-close','document-tabs','notes'))))),('changed-scene',lambda d:d['Steps'][-1]['Snapshot']['Size'].__setitem__('X',901)),('duplicate-id',lambda d:d['Steps'][0]['Snapshot']['Elements'].append(d['Steps'][0]['Snapshot']['Elements'][0])),('console-garbage',None),('multiple-reports',None),('invalid-utf8',None)]
  for name,mutate in mutations:
   with self.subTest(name=name):
    d=fixture()
    if mutate:mutate(d)
    raw=encode(d)
    if name=='console-garbage':raw+=b'garbage\n'
    if name=='multiple-reports':raw+=raw
    if name=='invalid-utf8':raw+=b'\xff'
    with self.assertRaises((ValueError,UnicodeError,KeyError)):v.validate(raw,b'')
if __name__=='__main__':unittest.main(verbosity=2)
