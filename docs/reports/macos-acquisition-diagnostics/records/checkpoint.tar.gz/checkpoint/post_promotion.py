from pathlib import Path
import datetime,hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=300,capture_output=True,check=True).stdout
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def vector(root):
 out={}
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 assert not git(root,'status','--porcelain');names=git(root,'ls-files','-z').decode().split('\0')[:-1];return{n:sha(root/n)for n in names}
def prepared(root):return{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
head=read(W/'commit-result.json')['commit'];plan=read(W/'plan.json');assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==head
s=source(C);assert source(T)==s and all(plan['candidate_source'].get(n)==v for n,v in s.items()if n.endswith('.go'))
p=prepared(C);assert prepared(T)==p==plan['prepared']and len(p)==6274 and digest(p)=='1021da5dbcf15218a54212bc62ec0d465dea168c148753c6c52281133482dc56'
prep=read(W/'prepare-canonical-final.json');assert prep['exit_code']==0 and prep['owned']['group_absent']and prep['pins_stable']and prep['logs_complete']and prep['error']is None
guard=read(W/'canonical-prepare-guard.json');assert guard['exit_code']==0 and guard['error']is None and guard['pins_stable']and all(sha(k)==v for k,v in guard['source_pins'].items())and guard['inner_receipt_sha256']==sha(W/'prepare-canonical-final.json')
sdk=vector(Path(plan['sdk']));assert sdk==plan['sdk_files']and len(sdk)==7880
n=read(W/'case/stdout');prism=read(W/'prism.json');cmd=read(W/'prism-command.json')
r={'commit':head,'canonical_clean':True,'candidate_clean':True,'source_files':len(s),'source_sha256':digest(s),'all_Go_source_matches_executed_candidate':True,'prepared_files':len(p),'prepared_sha256':digest(p),'canonical_offline_prepare85_pass':True,'canonical_prepare_guard_sha256':sha(W/'canonical-prepare-guard.json'),'canonical_prepare_launcher_sha256':sha(W/'prepare_owned.py'),'canonical_prepare_receipt_sha256':sha(W/'prepare-canonical-final.json'),'sdk_unchanged':True,'sdk_files':len(sdk),'sdk_sha256':digest(sdk),'native_record':{'result':n['Result'],'inputs':16,'source_asserted_observations':15,'independent_validation_complete':False,'full50_42_pending':True,'actual_acquisition':'surface unavailable attempts1 occluded196609','error':n['Error']},'physical_input_verified':False,'closed_full_mac_gates':[],'goal_complete':False,'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(W/'post-promotion.json').write_text(json.dumps(r,indent=2)+'\n')
state=W.parent/'vellum-resume-state.json';prior=state.read_bytes();(W/'previous-resume-state-final.json').write_bytes(prior);z=json.loads(prior)
nextwork='Implement bounded visibility-aware explicit Frame scheduling: preserve strict completion, no fabricated submitted frame or spin; cancellation/closure responsive, resume eligible pending work on drawable availability. Deterministic hidden/occluded-to-visible/cancel tests, internal review, then distinct native admission; never reset/retry sealed acquisition/structure/originalplacement scopes. Close remaining M2 catalogue then material M3 architecture decision. M2/M5/M3-M7 open. No retiredmicrotuning/longsoakbeforeprereqs/SDKrefreshbeforestable/OSsettings/inputsource/clipboard/publicpush/tag/sign/notarize.'
z.update(canonical_head=head,canonical_current_source=head,candidate_head=head,current_canonical_commit=head,latest_checkpoint_commit=head,status='ACQUISITION_OUTCOMES_CHECKPOINT_COMMITTED',source_files=len(s),prepared_files=len(p),candidate_source_files=len(s),candidate_prepared_files=len(p),tracked_paths=len(s),staged_source_files=[],active_tool_sessions=[],active_case=None,active_process_group=None,prism_invocations=1,prism_files=12,prism_complete=prism['coverage']['complete'],prism_retained_findings=len(prism['findings']),prism_cli_exit_code=cmd['exit_code'],checkpoint=head+': stage85 actual measured acquisition outcomes, injected propagation/ownership tests and160/162DPIManual geometry committed; freshnative FAILED16/15 actualoccluded196609 oneattempt; cleanup andwholepostfailureboundariespass; prior41/35causeunknown; allfullMacgatesopen.',next=nextwork,next_work=nextwork,next_action=nextwork,updated_utc=r['updated_utc'],latest_checkpoint_completed_utc=r['updated_utc'],last_goal_turn_classification='progress: measuredacquisitiondiagnostics implemented/tested/reviewed/committed; freshnative actualocclusion failurepreserved; nofullgateclosed')
z['prism_dispositions']='One scoped complete Anthropic Claude Sonnet5.5 call for12files; raw all retained/discarded comments dispositioned in '+str(W/'internal-prism-disposition.json')
z.update(binding=str(W/'plan.json'),execution_review_sha256=sha(W/'admission.json'),native_result_review_pending=False,preflight_result_review_sha256=sha(W/'internal-native-result-review.json'))
z['acquisition_outcomes_checkpoint']={**r,'artifacts':str(W),'report':str(C/'docs/reports/macos-acquisition-diagnostics/README.md'),'previous_turn_classification':'progress'}
z['acquisition_outcomes_work'].update(source_controller_review_pending=False,native_plan_created=True,native_executed=True,committed=True,commit=head,canonical_prepared_files=6274)
state.write_text(json.dumps(z,indent=2)+'\n');print(json.dumps(r))
