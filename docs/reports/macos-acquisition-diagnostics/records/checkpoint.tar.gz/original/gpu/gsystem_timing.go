package gpu

import (
	"errors"

	"github.com/oliverbestmann/webgpu/wgpu"
)

// BeginRenderPassMeasured is the normal clear pass with surface acquisition
// separated from encoder creation. Only the renderer's acquisition wait and
// acquisition lock wait are excluded; reconfiguration and view work are charged.
func (sy *GraphicsSystem) BeginRenderPassMeasured() (*wgpu.RenderPassEncoder, int64, error) {
	measured, ok := sy.Renderer.(interface {
		GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error)
		PresentMeasured() int64
	})
	if !ok {
		return nil, 0, errors.New("renderer does not support measured acquisition")
	}
	var acquire int64
	pass, err := sy.beginOwnedRenderPass(true, func() (*wgpu.TextureView, error) {
		view, elapsed, err := measured.GetCurrentTextureMeasured()
		acquire = elapsed
		return view, err
	})
	return pass, acquire, err
}

// EndRenderPassMeasured separates the renderer present call from encoding and
// queue submission. It reports submission failure rather than qualifying a frame.
func (sy *GraphicsSystem) EndRenderPassMeasured(rp *wgpu.RenderPassEncoder) (int64, error) {
	if err := sy.SubmitRender(rp); err != nil {
		return 0, err
	}
	if measured, ok := sy.Renderer.(interface{ PresentMeasured() int64 }); ok {
		return measured.PresentMeasured(), nil
	}
	sy.Renderer.AbortCurrentTexture()
	return 0, errors.New("renderer lost measured presentation support")
}
