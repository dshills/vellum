from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-acquisition-diagnostics/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
d=read(W/'internal-prism-disposition.json');assert d['approved']and not d['unresolved_findings']
files={}
def add(p,n):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in files and not n.startswith('/')and '..'not in Path(n).parts;files[n]=p
# Only explicit software/native receipt directories; never executables or SDKs.
checks=['focused-v1','style-v1','focused-final','driver-final','gallery-final','build-final','validation-final','prepare-unit','prepare-unit-final','prepare-candidate','prepare-candidate-final','vet-final','vet-core-baseline','vet-scope-final','vet-core-analyzers']
for name in checks:
 add(W/(name+'.json'),'checks/'+name+'.json')
 for stream in ['stdout','stderr','owned.json']:
  q=W/name/stream
  if q.is_file():add(q,'checks/'+name+'/'+stream)
for dirname in ['candidate','original','versions','case']:
 for q in sorted((W/dirname).rglob('*')):
  if q.is_file():add(q,dirname+'/'+q.relative_to(W/dirname).as_posix())
for n in ['implement.py','write_tests.py','stage85.py','stage85.json','files.json','check.py','check_validation.py','prepare_owned.py','vet_checks.py','vet-core-equivalence.json','revise_oracle.py','validate.py','validation_controls.py','overlay.json','baseline-overlay.json','original-gallery-test.go','pre-review-boundary.json','internal-candidate-review.json','internal-source-review.json','run.py','plan.json','admission.json','result.json','stop-live','failed-post-boundary.json','internal-native-result-review.json','prepare-candidate-prepared.json','prepare-candidate-final-prepared.json','document.py','stage.py','review-scope.json','staged.diff','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','archive.py','final_stage.py','ready_commit.py','post_promotion.py']:
 add(W/n,'checkpoint/'+n)
for n in read(W/'review-scope.json')['paths']:add(T/n,'source/'+n)
add(R/'results.json','source/docs/reports/macos-acquisition-diagnostics/records/results.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(v['bytes']for v in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(v['bytes']<=10<<20 for v in manifest.values())
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as tar:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=tar.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=read(W/'prism.json');cmd=read(W/'prism-command.json')
a={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'native_result':'FAILED16/15 occluded196609; full50/42 open','native_independent_validation_complete':False,'physical_input_verified':False,'full_mac_complete':False,'provider':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':p['coverage']['llmCalls'],'complete':p['coverage']['complete'],'cli_exit_code':cmd['exit_code'],'retained_findings':len(p['findings']),'discarded_comments':len(p['discarded']),'internal_disposition_approved':True,'disposition':'Retained repeated-acquire/later-failure claim refuted by exact single-callback/nonnil-error paths; discarded swallowed-view-error claim refuted. Direct Surface.TryCreateView failure/nil-view injection remains a limited test-coverage gap.'}}
(R/'archive.json').write_text(json.dumps(a,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a))
