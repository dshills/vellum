// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpudraw

import (
	"cogentcore.org/core/gpu"
	"cogentcore.org/core/system/composer"
	"errors"
	"github.com/oliverbestmann/webgpu/wgpu"
	"strings"
	"testing"
)

type unavailableMeasuredRenderer struct {
	gpu.Renderer
	outcome gpu.AcquisitionOutcome
	failure error
	calls   int
}

func (r *unavailableMeasuredRenderer) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	panic("detailed renderer silently fell back")
}
func (r *unavailableMeasuredRenderer) GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, gpu.AcquisitionOutcome, error) {
	r.calls++
	return nil, 23, r.outcome, r.failure
}
func (r *unavailableMeasuredRenderer) PresentMeasured() int64 { panic("unsubmitted frame presented") }
func TestVellumMeasuredPassFailureCarriesAcquisitionThroughComposition(t *testing.T) {
	sentinel := errors.New("injected backend failure")
	for _, c := range []struct {
		stage    gpu.AcquisitionStage
		status   wgpu.SurfaceGetCurrentTextureStatus
		attempts uint8
		fail     bool
	}{
		{gpu.AcquisitionUnavailable, wgpu.SurfaceGetCurrentTextureStatusOccluded, 1, false},
		{gpu.AcquisitionUnavailable, wgpu.SurfaceGetCurrentTextureStatusLost, 2, false},
		{gpu.AcquisitionMissingTexture, wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal, 1, false},
		{gpu.AcquisitionBackendError, wgpu.SurfaceGetCurrentTextureStatusError, 2, true},
	} {
		r := &unavailableMeasuredRenderer{outcome: gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: c.stage, Attempts: c.attempts, FirstStatus: c.status, LastStatus: c.status}}
		if c.fail {
			r.failure = sentinel
		}
		timing := composer.ComposeTiming{Supported: true}
		pass, err := beginMeasuredPass(&gpu.GraphicsSystem{Renderer: r}, &timing)
		if pass != nil || r.calls != 1 || timing.AcquireNS != 23 || timing.Submitted || !timing.Supported {
			t.Fatal("no-frame became submission or extra acquisition", timing, err)
		}
		if c.fail {
			if !errors.Is(err, sentinel) || !strings.Contains(err.Error(), r.outcome.Description()) {
				t.Fatal("error context or identity lost", err)
			}
		} else if err != nil || !strings.Contains(timing.Failure, r.outcome.Description()) || !strings.Contains(timing.Failure, "render pass unavailable") {
			t.Fatal("composition lost actual acquisition", timing, err)
		}
	}
}
