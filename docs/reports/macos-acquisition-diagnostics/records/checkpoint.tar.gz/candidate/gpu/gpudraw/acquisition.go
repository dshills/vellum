// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpudraw

import (
	"cogentcore.org/core/gpu"
	"cogentcore.org/core/system/composer"
	"fmt"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// Called only by the measured path. No extra acquire, retry, polling, readback,
// wait or presentation is added. A missing pass remains an unsuccessful frame.
func beginMeasuredPass(sy *gpu.GraphicsSystem, timing *composer.ComposeTiming) (*wgpu.RenderPassEncoder, error) {
	pass, elapsed, outcome, err := sy.BeginRenderPassMeasuredWithOutcome()
	timing.AcquireNS = elapsed
	if err != nil {
		return pass, fmt.Errorf("gpu: measured render pass failed (%s): %w", outcome.Description(), err)
	}
	if pass == nil {
		timing.Failure = "gpu: measured render pass unavailable (" + outcome.Description() + ")"
	}
	return pass, nil
}
