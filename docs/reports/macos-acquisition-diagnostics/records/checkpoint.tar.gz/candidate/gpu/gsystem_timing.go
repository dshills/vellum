package gpu

import (
	"errors"

	"github.com/oliverbestmann/webgpu/wgpu"
)

// BeginRenderPassMeasured is the normal clear pass with surface acquisition
// separated from encoder creation. Only the renderer's acquisition wait and
// acquisition lock wait are excluded; reconfiguration and view work are charged.
func (sy *GraphicsSystem) BeginRenderPassMeasured() (*wgpu.RenderPassEncoder, int64, error) {
	pass, elapsed, _, err := sy.BeginRenderPassMeasuredWithOutcome()
	return pass, elapsed, err
}

// BeginRenderPassMeasuredWithOutcome preserves the existing measured renderer
// contract and optionally carries a detached outcome from its actual call.
// Legacy measured renderers report unrecorded detail, never guessed statuses.
func (sy *GraphicsSystem) BeginRenderPassMeasuredWithOutcome() (*wgpu.RenderPassEncoder, int64, AcquisitionOutcome, error) {
	measured, ok := sy.Renderer.(interface {
		GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error)
		PresentMeasured() int64
	})
	if !ok {
		return nil, 0, AcquisitionOutcome{}, errors.New("renderer does not support measured acquisition")
	}
	var acquire int64
	var outcome AcquisitionOutcome
	pass, err := sy.beginOwnedRenderPass(true, func() (*wgpu.TextureView, error) {
		var view *wgpu.TextureView
		var elapsed int64
		var err error
		if detailed, ok := sy.Renderer.(interface {
			GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, AcquisitionOutcome, error)
		}); ok {
			view, elapsed, outcome, err = detailed.GetCurrentTextureMeasuredWithOutcome()
		} else {
			view, elapsed, err = measured.GetCurrentTextureMeasured()
		}
		acquire = elapsed
		return view, err
	})
	return pass, acquire, outcome, err
}

// EndRenderPassMeasured separates the renderer present call from encoding and
// queue submission. It reports submission failure rather than qualifying a frame.
func (sy *GraphicsSystem) EndRenderPassMeasured(rp *wgpu.RenderPassEncoder) (int64, error) {
	if err := sy.SubmitRender(rp); err != nil {
		return 0, err
	}
	if measured, ok := sy.Renderer.(interface{ PresentMeasured() int64 }); ok {
		return measured.PresentMeasured(), nil
	}
	sy.Renderer.AbortCurrentTexture()
	return 0, errors.New("renderer lost measured presentation support")
}
