// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
	"errors"
	"fmt"
	"github.com/oliverbestmann/webgpu/wgpu"
	"reflect"
	"strings"
	"testing"
)

func TestVellumMeasuredAcquisitionMatchesOrdinaryYieldRecoveryAndRelease(t *testing.T) {
	type step struct {
		status        wgpu.SurfaceGetCurrentTextureStatus
		texture, fail bool
	}
	lost, outdated, optimal := wgpu.SurfaceGetCurrentTextureStatusLost, wgpu.SurfaceGetCurrentTextureStatusOutdated, wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal
	for _, c := range []struct {
		name  string
		steps []step
		stage AcquisitionStage
	}{
		{"occluded", []step{{status: wgpu.SurfaceGetCurrentTextureStatusOccluded, texture: true}}, AcquisitionUnavailable},
		{"timeout", []step{{status: wgpu.SurfaceGetCurrentTextureStatusTimeout}}, AcquisitionUnavailable},
		{"status-error", []step{{status: wgpu.SurfaceGetCurrentTextureStatusError}}, AcquisitionUnavailable},
		{"unknown", []step{{status: wgpu.SurfaceGetCurrentTextureStatus(0xffffffff)}}, AcquisitionUnavailable},
		{"lost-exhausted", []step{{status: lost, texture: true}, {status: lost, texture: true}}, AcquisitionUnavailable},
		{"outdated-lost", []step{{status: outdated}, {status: lost}}, AcquisitionUnavailable},
		{"lost-timeout", []step{{status: lost}, {status: wgpu.SurfaceGetCurrentTextureStatusTimeout}}, AcquisitionUnavailable},
		{"recovered", []step{{status: outdated, texture: true}, {status: optimal, texture: true}}, AcquisitionTextureReady},
		{"recovered-null", []step{{status: lost}, {status: optimal}}, AcquisitionMissingTexture},
		{"success-null", []step{{status: optimal}}, AcquisitionMissingTexture},
		{"suboptimal", []step{{status: wgpu.SurfaceGetCurrentTextureStatusSuccessSuboptimal, texture: true}}, AcquisitionTextureReady},
		{"backend-partial", []step{{status: optimal, texture: true, fail: true}}, AcquisitionBackendError},
		{"retry-backend-partial", []step{{status: lost, texture: true}, {status: optimal, texture: true, fail: true}}, AcquisitionBackendError},
	} {
		t.Run(c.name, func(t *testing.T) {
			failure := errors.New("injected acquisition error")
			var ordinaryEvents []string
			var ordinaryStatus wgpu.SurfaceGetCurrentTextureStatus
			var ordinaryTexture, ordinaryError bool
			for _, measured := range []bool{false, true} {
				calls := 0
				var events []string
				acquire := func() (wgpu.SurfaceTexture, error) {
					if calls >= len(c.steps) {
						t.Fatal("extra/polling acquisition")
					}
					v := c.steps[calls]
					calls++
					events = append(events, fmt.Sprint("acquire:", uint32(v.status)))
					f := wgpu.SurfaceTexture{Status: v.status}
					if v.texture {
						f.Texture = &wgpu.Texture{}
					}
					if v.fail {
						return f, failure
					}
					return f, nil
				}
				configure := func() { events = append(events, "configure") }
				release := func(texture *wgpu.Texture) {
					if texture == nil {
						t.Fatal("nil release")
					}
					events = append(events, "release")
				}
				var f wgpu.SurfaceTexture
				var err error
				if measured {
					var outcome AcquisitionOutcome
					f, outcome, err = acquireSurfaceFrameOutcomeOwned(acquire, configure, release)
					if outcome.Source != AcquisitionSurface || outcome.Stage != c.stage || int(outcome.Attempts) != len(c.steps) || outcome.FirstStatus != c.steps[0].status || outcome.LastStatus != c.steps[len(c.steps)-1].status {
						t.Fatalf("incorrect detached actual outcome: %+v", outcome)
					}
					if !reflect.DeepEqual(events, ordinaryEvents) || f.Status != ordinaryStatus || (f.Texture != nil) != ordinaryTexture || (err != nil) != ordinaryError {
						t.Fatal("measurement changed ordinary behavior", events, ordinaryEvents, err)
					}
				} else {
					f, err = acquireSurfaceFrameOwned(acquire, configure, release)
					ordinaryEvents = append([]string(nil), events...)
					ordinaryStatus = f.Status
					ordinaryTexture = f.Texture != nil
					ordinaryError = err != nil
				}
				if calls != len(c.steps) || err != nil && !errors.Is(err, failure) {
					t.Fatal("attempt bound/error identity", calls, err)
				}
				// Explicit release/configuration order, independent of the comparison above.
				var want []string
				for i, v := range c.steps {
					want = append(want, fmt.Sprint("acquire:", uint32(v.status)))
					success := v.status == optimal || v.status == wgpu.SurfaceGetCurrentTextureStatusSuccessSuboptimal
					if v.texture && (v.fail || !success) {
						want = append(want, "release")
					}
					if i == 0 && !v.fail && (v.status == lost || v.status == outdated) {
						want = append(want, "configure")
					}
				}
				if !reflect.DeepEqual(events, want) {
					t.Fatal("wrong release/configuration protocol", events, want)
				}
			}
		})
	}
}
func TestVellumAcquisitionDescriptionIsBoundedAndDoesNotInventStatus(t *testing.T) {
	unknown := (AcquisitionOutcome{}).Description()
	if !strings.Contains(unknown, "attempts=0 statuses=unrecorded") || strings.Contains(unknown, "first=") {
		t.Fatal("invented legacy status", unknown)
	}
	o := AcquisitionOutcome{Source: AcquisitionSource(255), Stage: AcquisitionStage(255), Attempts: 255, FirstStatus: wgpu.SurfaceGetCurrentTextureStatus(0xffffffff), LastStatus: wgpu.SurfaceGetCurrentTextureStatus(0xfffffffe)}
	s := o.Description()
	if len(s) > 256 || !strings.Contains(s, "unknown(4294967295)") || !strings.Contains(s, "unknown(4294967294)") {
		t.Fatal("unbounded/lost unknown status", s)
	}
}
