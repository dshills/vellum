package gpu

import (
	"fmt"
	"time"

	"cogentcore.org/core/base/errors"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// GetCurrentTextureMeasured preserves the ordinary acquisition/retry order.
// Only waiting for ownership and the backend acquisition calls are excluded.
// Reconfiguration, status checks and texture view creation remain UI work.
func (sf *Surface) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	view, elapsed, _, err := sf.GetCurrentTextureMeasuredWithOutcome()
	return view, elapsed, err
}

// GetCurrentTextureMeasuredWithOutcome adds detached acquisition evidence without
// changing the legacy measured method's return or lock ownership conventions.
func (sf *Surface) GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, AcquisitionOutcome, error) {
	start := time.Now()
	sf.Lock()
	acquireNS := time.Since(start).Nanoseconds()
	stexture, outcome, err := acquireSurfaceFrameOutcomeOwned(func() (wgpu.SurfaceTexture, error) {
		start := time.Now()
		frame, err := sf.surface.TryGetCurrentTexture()
		acquireNS += time.Since(start).Nanoseconds()
		return frame, err
	}, sf.Config, func(texture *wgpu.Texture) { texture.Release() })
	if errors.Log(err) != nil {
		sf.Unlock()
		return nil, acquireNS, outcome, err
	}
	texture, ok := stexture.Get()
	if !ok || texture == nil {
		sf.Unlock()
		return nil, acquireNS, outcome, nil
	}
	view, err := texture.TryCreateView(&wgpu.TextureViewDescriptor{
		MipLevelCount: texture.GetMipLevelCount(), ArrayLayerCount: texture.GetDepthOrArrayLayers(), Format: sf.Format.Format,
	})
	if err != nil || view == nil {
		outcome.Stage = AcquisitionViewError
		if view != nil {
			view.Release()
		}
		texture.Release()
		sf.Unlock()
		if err == nil {
			err = fmt.Errorf("gpu: texture view factory returned nil without error")
		}
		return nil, acquireNS, outcome, err
	}
	sf.frame = surfaceFrame{view: view, texture: texture}
	outcome.Stage = AcquisitionViewReady
	return view, acquireNS, outcome, nil
}

// A render texture has no surface acquisition or presentation wait.
func (rt *RenderTexture) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	view, err := rt.GetCurrentTexture()
	return view, 0, err
}
func (rt *RenderTexture) AbortCurrentTexture()   {}
func (rt *RenderTexture) PresentMeasured() int64 { return 0 }

// Offscreen textures have no surface attempts/statuses; never invent them.
func (rt *RenderTexture) GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, AcquisitionOutcome, error) {
	view, err := rt.GetCurrentTexture()
	outcome := AcquisitionOutcome{Source: AcquisitionRenderTexture, Stage: AcquisitionViewReady}
	if err != nil {
		outcome.Stage = AcquisitionViewError
	} else if view == nil {
		outcome.Stage = AcquisitionUnavailable
	}
	return view, 0, outcome, err
}
