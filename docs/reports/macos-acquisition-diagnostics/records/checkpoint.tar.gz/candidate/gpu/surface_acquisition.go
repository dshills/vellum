// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
	"fmt"
	"github.com/oliverbestmann/webgpu/wgpu"
)

type AcquisitionSource uint8

const (
	AcquisitionUnknown AcquisitionSource = iota
	AcquisitionSurface
	AcquisitionRenderTexture
)

type AcquisitionStage uint8

const (
	AcquisitionUnrecorded AcquisitionStage = iota
	AcquisitionBackendError
	AcquisitionUnavailable
	AcquisitionMissingTexture
	AcquisitionTextureReady
	AcquisitionViewError
	AcquisitionViewReady
)

// AcquisitionOutcome is a detached value for one measured acquisition. It owns
// no native handles, callbacks, strings, history or persistent per-surface state.
// Surface acquisition makes at most two attempts; first/last preserve both.
type AcquisitionOutcome struct {
	Source                  AcquisitionSource
	Stage                   AcquisitionStage
	Attempts                uint8
	FirstStatus, LastStatus wgpu.SurfaceGetCurrentTextureStatus
}

func (o AcquisitionOutcome) Description() string {
	source := "unknown"
	switch o.Source {
	case AcquisitionSurface:
		source = "surface"
	case AcquisitionRenderTexture:
		source = "render-texture"
	}
	stage := "unrecorded"
	switch o.Stage {
	case AcquisitionBackendError:
		stage = "backend-error"
	case AcquisitionUnavailable:
		stage = "unavailable"
	case AcquisitionMissingTexture:
		stage = "missing-texture"
	case AcquisitionTextureReady:
		stage = "texture-ready"
	case AcquisitionViewError:
		stage = "view-error"
	case AcquisitionViewReady:
		stage = "view-ready"
	}
	if o.Attempts == 0 {
		return fmt.Sprintf("source=%s stage=%s attempts=0 statuses=unrecorded", source, stage)
	}
	status := func(s wgpu.SurfaceGetCurrentTextureStatus) string {
		name := s.String()
		if name == "" {
			name = "unknown"
		}
		return fmt.Sprintf("%s(%d)", name, uint32(s))
	}
	return fmt.Sprintf("source=%s stage=%s attempts=%d first=%s last=%s", source, stage, o.Attempts, status(o.FirstStatus), status(o.LastStatus))
}

// This observes the existing acquisition implementation, without changing its
// yield, retry, configure or failed-handle release decisions. Only the measured
// caller uses it; the ordinary acquisition path remains unchanged.
func acquireSurfaceFrameOutcomeOwned(acquire func() (wgpu.SurfaceTexture, error), configure func(), release func(*wgpu.Texture)) (wgpu.SurfaceTexture, AcquisitionOutcome, error) {
	outcome := AcquisitionOutcome{Source: AcquisitionSurface}
	frame, err := acquireSurfaceFrameOwned(func() (wgpu.SurfaceTexture, error) {
		frame, err := acquire()
		outcome.Attempts++
		outcome.LastStatus = frame.Status
		if outcome.Attempts == 1 {
			outcome.FirstStatus = frame.Status
		}
		return frame, err
	}, configure, release)
	switch {
	case err != nil:
		outcome.Stage = AcquisitionBackendError
	case !frame.IsStatusSuccess():
		outcome.Stage = AcquisitionUnavailable
	case frame.Texture == nil:
		outcome.Stage = AcquisitionMissingTexture
	default:
		outcome.Stage = AcquisitionTextureReady
	}
	return frame, outcome, err
}
