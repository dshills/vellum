// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
	"errors"
	"github.com/oliverbestmann/webgpu/wgpu"
	"testing"
)

type legacyAcquisitionRenderer struct {
	Renderer
	normal, measured, aborted int
	failure                   error
}

func (r *legacyAcquisitionRenderer) GetCurrentTexture() (*wgpu.TextureView, error) {
	r.normal++
	return nil, nil
}
func (r *legacyAcquisitionRenderer) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	r.measured++
	return nil, 17, r.failure
}
func (r *legacyAcquisitionRenderer) PresentMeasured() int64 { panic("unsubmitted frame presented") }
func (r *legacyAcquisitionRenderer) AbortCurrentTexture()   { r.aborted++ }

type detailedAcquisitionRenderer struct {
	*legacyAcquisitionRenderer
	calls   int
	outcome AcquisitionOutcome
}

func (r *detailedAcquisitionRenderer) GetCurrentTextureMeasuredWithOutcome() (*wgpu.TextureView, int64, AcquisitionOutcome, error) {
	r.calls++
	return nil, 19, r.outcome, r.failure
}
func TestVellumMeasuredPassPreservesActualOutcomeAndLegacyContract(t *testing.T) {
	failure := errors.New("injected acquisition error")
	for _, failed := range []bool{false, true} {
		r := &detailedAcquisitionRenderer{legacyAcquisitionRenderer: &legacyAcquisitionRenderer{}, outcome: AcquisitionOutcome{Source: AcquisitionSurface, Stage: AcquisitionUnavailable, Attempts: 2, FirstStatus: wgpu.SurfaceGetCurrentTextureStatusLost, LastStatus: wgpu.SurfaceGetCurrentTextureStatusOccluded}}
		if failed {
			r.failure = failure
			r.outcome.Stage = AcquisitionBackendError
		}
		sy := &GraphicsSystem{Renderer: r}
		pass, elapsed, outcome, err := sy.BeginRenderPassMeasuredWithOutcome()
		if pass != nil || elapsed != 19 || outcome != r.outcome || failed && !errors.Is(err, failure) || !failed && err != nil || r.calls != 1 || r.measured != 0 || r.normal != 0 || r.aborted != 0 || sy.CommandEncoder != nil {
			t.Fatal("measured no-frame contract changed", pass, elapsed, outcome, err, r)
		}
		// The existing method still returns nil/no-error on unavailable acquisition.
		pass, elapsed, err = sy.BeginRenderPassMeasured()
		if pass != nil || elapsed != 19 || failed && !errors.Is(err, failure) || !failed && err != nil || r.calls != 2 {
			t.Fatal("legacy measured wrapper changed", err)
		}
	}
	legacy := &legacyAcquisitionRenderer{}
	sy := &GraphicsSystem{Renderer: legacy}
	pass, elapsed, outcome, err := sy.BeginRenderPassMeasuredWithOutcome()
	if pass != nil || elapsed != 17 || err != nil || outcome != (AcquisitionOutcome{}) || legacy.measured != 1 {
		t.Fatal("invented legacy outcome", outcome, err)
	}
	pass, err = sy.BeginRenderPass()
	if pass != nil || err != nil || legacy.normal != 1 || legacy.measured != 1 || legacy.aborted != 0 {
		t.Fatal("ordinary path changed", err)
	}
	unsupported := &GraphicsSystem{Renderer: &observedFrameRenderer{}}
	if pass, _, outcome, err := unsupported.BeginRenderPassMeasuredWithOutcome(); pass != nil || outcome != (AcquisitionOutcome{}) || err == nil {
		t.Fatal("unsupported measured renderer admitted")
	}
}
