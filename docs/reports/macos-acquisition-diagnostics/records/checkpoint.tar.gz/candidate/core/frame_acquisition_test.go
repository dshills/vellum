// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/gpu"
	"cogentcore.org/core/system/composer"
	"github.com/oliverbestmann/webgpu/wgpu"
	"testing"
)

func TestVellumFrameTraceAcquisitionFailurePreservesStrictCompletion(t *testing.T) {
	for _, submitted := range []bool{false, true} {
		trace := &FrameTrace{}
		event := traceScroll()
		if err := trace.Begin(5, event); err != nil {
			t.Fatal(err)
		}
		tag, start := trace.startEvent(event)
		trace.ExpectOwner(tag)
		trace.endEvent(tag, start)
		trace.Transition(tag, 11)
		trace.OwnerWork(tag, 7)
		trace.Reconciled(tag, 13)
		if trace.startFrame() != tag {
			t.Fatal("armed frame not started")
		}
		outcome := gpu.AcquisitionOutcome{Source: gpu.AcquisitionSurface, Stage: gpu.AcquisitionUnavailable, Attempts: 2, FirstStatus: wgpu.SurfaceGetCurrentTextureStatusLost, LastStatus: wgpu.SurfaceGetCurrentTextureStatusTimeout}
		failure := "gpu: measured render pass unavailable (" + outcome.Description() + ")"
		trace.finishFrame(tag, composer.ComposeTiming{Supported: true, Submitted: submitted, Failure: failure, AcquireNS: 29})
		sample, ready := trace.Take()
		if !ready || sample.Completed || sample.Failure != failure || sample.AcquireNS != 29 {
			t.Fatal("failed acquisition was hidden or qualified", sample, ready)
		}
		if _, again := trace.Take(); again {
			t.Fatal("failure sample retained after take")
		}
	}
}
