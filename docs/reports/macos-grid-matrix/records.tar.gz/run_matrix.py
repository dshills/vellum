"""Run the existing complete table matrix under a fresh shared desktop lease."""
from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,threading
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');W=Path(__file__).resolve().parent;STOP=W/'stop-native';B=Path('/private/tmp/vellum-ready-native-5482f9b/bin/ax-semantic');HEAD='bd672a618ca9e2b8c03b8f8eb9586eccf63994db'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sys.path.insert(0,str(T/'scripts'));b=load('table_matrix_runner',T/'scripts/benchmark-grid.py');l=load('live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
receipt=json.loads((W.parent/'macos-ax-semantic-02f8dbe/binary-receipt.json').read_text());binary_sha=receipt['sha256'];finished=threading.Event()
def require(ok,message):
 if not ok:raise ValueError(message)
def boundary():
 require(not STOP.exists(),'stop requested')
 for root in [C,T]:require(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean committed source changed')
 require(sha(B)==binary_sha,'executable changed')
 require(all(sha(T/'drivers/cogent'/n)==h for n,h in receipt['compiled_leaves'].items()),'compiled leaf changed')
def watch():
 while not finished.wait(.2):
  if STOP.exists():_thread.interrupt_main();return
original=b.run_case
current_mode=None
runs=[]
def run_case(*args,**kwargs):
 boundary();data,outcome=original(*args,**kwargs);stats=b.distribution([s['metrics']['ui_work_ns'] for s in data]);entry={'mode':current_mode,'directory':str(args[1]),'rows':args[2],'variable':args[3],'p95_ms':stats['p95']/1e6,'p99_ms':stats['p99']/1e6,'exit_code':outcome['exit_code']};runs.append(entry);print(json.dumps(entry),flush=True);return data,outcome
b.run_case=run_case
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('matrix terminated')))
d={'source_commit':HEAD,'binary':str(B),'binary_sha256':binary_sha,'prepared_stage':79,'prepared_files':6260,'prepared_sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba','scope':'Full existing fixed/variable10k/1M table matrix, CPU and GPU-requested, five120-event runs128warm. Ordinary timings separate from later route diagnostics; no physical/presentation qualification.','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'INCOMPLETE','error':None}
try:
 require(not STOP.exists() and not (W/'result.json').exists(),'fresh matrix');require(all(os.environ.get(k) is None for k in ['GOMAXPROCS','GOMEMLIMIT','GOFLAGS']),'ordinary runtime');boundary()
 with l.LiveLease():
  threading.Thread(target=watch,daemon=True).start()
  for current_mode in ['gpu','cpu']:
   sys.argv=[str(T/'scripts/benchmark-grid.py'),'--run','--binary',str(B),'--output',str(W/current_mode),'--runs','5','--samples','120','--warmup','128','--timeout','180']+(['--gpu-scene'] if current_mode=='gpu' else [])
   b.main();boundary()
  d['result']='MEASURED'
except BaseException as e:d['result']='FAILED_OR_CANCELED';d['error']={'type':type(e).__name__,'message':str(e)}
finally:
 finished.set();STOP.touch();d['runs']=runs;d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'error':d['error'],'completed_runs':len(runs)}),flush=True)
if d['error']:sys.exit(1)
