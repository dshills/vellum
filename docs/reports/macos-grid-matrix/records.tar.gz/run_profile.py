"""Run the existing complete table matrix under a fresh shared desktop lease."""
from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,threading
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');W=Path(__file__).resolve().parent;STOP=W/'stop-profile';B=Path('/private/tmp/vellum-ready-native-5482f9b/bin/ax-semantic');HEAD='bd672a618ca9e2b8c03b8f8eb9586eccf63994db'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sys.path.insert(0,str(T/'scripts'));b=load('table_matrix_runner',T/'scripts/benchmark-grid.py');l=load('live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
receipt=json.loads((W.parent/'macos-ax-semantic-02f8dbe/binary-receipt.json').read_text());binary_sha=receipt['sha256'];finished=threading.Event()
def require(ok,message):
 if not ok:raise ValueError(message)
def boundary():
 require(not STOP.exists(),'stop requested')
 for root in [C,T]:require(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean committed source changed')
 require(sha(B)==binary_sha,'executable changed')
 require(all(sha(T/'drivers/cogent'/n)==h for n,h in receipt['compiled_leaves'].items()),'compiled leaf changed')
def watch():
 while not finished.wait(.2):
  if STOP.exists():_thread.interrupt_main();return
original=b.run_case
current_mode=None
runs=[]
def run_case(*args,**kwargs):
 boundary();data,outcome=original(*args,**kwargs);stats=b.distribution([s['metrics']['ui_work_ns'] for s in data]);entry={'mode':current_mode,'directory':str(args[1]),'rows':args[2],'variable':args[3],'p95_ms':stats['p95']/1e6,'p99_ms':stats['p99']/1e6,'exit_code':outcome['exit_code']};runs.append(entry);print(json.dumps(entry),flush=True);return data,outcome
b.run_case=run_case
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('matrix terminated')))
d={'source_commit':HEAD,'binary':str(B),'binary_sha256':binary_sha,'prepared_stage':79,'prepared_files':6260,'prepared_sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba','scope':'Full existing fixed/variable10k/1M table matrix, CPU and GPU-requested, five120-event runs128warm. Ordinary timings separate from later route diagnostics; no physical/presentation qualification.','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'INCOMPLETE','error':None}
from child_process import run_child
sample_threads=[];sample_results=[];original_popen=subprocess.Popen
def observe(process):
 result={'native_pid':process.pid,'scope':'Diagnostic native wall-stack sample, not additive CPU critical-path or ordinary frame timing'}
 try:
  if finished.wait(6) or process.poll() is not None:raise RuntimeError('owned benchmark ended before sample')
  args=['/usr/bin/sample',str(process.pid),'8','1','-mayDie','-file',str(W/'native-wall.sample.txt')]
  with (W/'sample.stdout').open('xb')as out,(W/'sample.stderr').open('xb')as err:
   r=run_child(args,timeout=25,stdout=out,stderr=err,log_limit_bytes=2<<20)
  result.update(argv=args,exit_code=r.returncode)
  report=W/'native-wall.sample.txt';require(report.is_file() and report.stat().st_size<=8<<20,'sample file budget');text=report.read_text();require(str(B) in text and f'[{process.pid}]' in text[:2048],'sample target identity');result['sha256']=sha(report);result['bytes']=report.stat().st_size
 except BaseException as e:result['error']={'type':type(e).__name__,'message':str(e)}
 sample_results.append(result)
def popen(arguments,*args,**kwargs):
 process=original_popen(arguments,*args,**kwargs)
 if isinstance(arguments,list) and arguments and arguments[0]==str(B):
  thread=threading.Thread(target=observe,args=(process,));sample_threads.append(thread);thread.start()
 return process
subprocess.Popen=popen
try:
 require(not STOP.exists() and not (W/'profile-result.json').exists(),'fresh profile');boundary();d['scope']='Separate Go CPU profile plus native wall-stack sampling, 600events128warm; never ordinary timing qualification';current_mode='gpu-profile'
 with l.LiveLease():
  threading.Thread(target=watch,daemon=True).start();data,outcome=run_case(B,W/'profile',10000,False,600,128,False,180,cpu_profile=W/'current-cpu.pprof',gpu_scene_rendering=True);boundary()
  for thread in sample_threads:thread.join(30);require(not thread.is_alive(),'sample child observer still active')
  d['result']='PROFILED'
except BaseException as e:d['result']='FAILED_OR_CANCELED';d['error']={'type':type(e).__name__,'message':str(e)}
finally:
 finished.set()
 for thread in sample_threads:thread.join(30)
 STOP.touch();subprocess.Popen=original_popen;d['sample_results']=sample_results;d['runs']=runs;d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'profile-result.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'error':d['error'],'native_sample':sample_results}),flush=True)
if d['error']:sys.exit(1)
