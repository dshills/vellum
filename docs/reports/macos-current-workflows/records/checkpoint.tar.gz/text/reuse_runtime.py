"""Qualify full driver-root race by exact effective runtime/prepared promotion."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;G=H.parent/'macos-editor-gutter-font-5e30a6c';T=Path('/private/tmp/vellum-macos-native-results-97aee13');E=H.parent/'macos-text-publication-native-v1'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def passed(d):return d['created']and d['exit_code']==0 and d['error']is None and d['logs_complete']and d['pins_stable']and not d['observation_errors']and d['owned']['group_absent']and not d['owned']['errors']
assert not(H/'runtime-reuse.json').exists()
r=read(G/'driver-v1.json');assert passed(r)
for name in ['focused-actual','core-actual','adopted-prepare']:assert passed(read(G/(name+'.json')))
commit=read(G/'commit-result.json');assert commit['canonical_clean']and commit['candidate_clean']and commit['sdk_unchanged']and commit['prepared_files']==6277
assert read(G/'internal-commit-review.json')['approved']
mapping=read(G/'overlay.json')['Replace'];inputs={};correspondence={}
names=run_child(['git','ls-files','-z'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode().split('\0')[:-1]
paths=[T/n for n in names if Path(n).suffix in ['.go','.c','.h','.m','.mm','.wgsl','.ttf','.otf']]
paths += [p for directory in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/directory).rglob('*')if p.is_file()]
for p in paths:
 tested=Path(mapping.get(str(p),str(p)));assert sha(p)==r['source_pins'][str(tested)]==sha(tested)
 inputs[str(p)]=sha(p);inputs[str(tested)]=sha(tested)
 if tested!=p:correspondence[str(p)]={'tested':str(tested),'sha256':sha(p)}
assert len(correspondence)==7
# SDK native libraries, manifests and build helpers remain exact; exclude earlier
# tracked documentation that the reviewed final evidence checkpoint necessarily changed.
for p,v in r['source_pins'].items():
 if not Path(p).is_relative_to(T):assert sha(p)==v;inputs[p]=v
assert(H/'checked.mod').read_bytes()==(G/'checked.mod').read_bytes()and(H/'checked.sum').read_bytes()==(G/'checked.sum').read_bytes()
for name in ['driver-v1','focused-actual','core-actual','adopted-prepare']:
 d=read(G/(name+'.json'))
 for stream in ['stdout','stderr','owned.json']:
  p=G/name/stream;inputs[str(p)]=sha(p)
  if stream!='owned.json':assert sha(p)==d['logs'][stream]['sha256']and p.stat().st_size==d['logs'][stream]['bytes']
for name in ['control_catalogue.go','structure_catalogue.go','text_catalogue.go']:assert(H/'consumer'/name).read_bytes()==(E/'consumer'/name).read_bytes()
for p in [Path(__file__),G/'driver-v1.json',G/'focused-actual.json',G/'core-actual.json',G/'adopted-prepare.json',G/'final-scope.json',G/'internal-commit-review.json',G/'internal-prism-disposition.json',G/'commit-result.json',G/'overlay.json',H/'checked.mod',H/'checked.sum']:inputs[str(p)]=sha(p)
out={'qualified_reuse':True,'scope':'Full root race by exact effective tracked Go/native/assets and complete6277prepared inputs, including7 byte-identical Go promotions. Actual-source focused/Core and actualpreparation pass. Documentation/evidence changes do not alter compiled inputs. Fresh gallery instrumentation/race/vet/build checked separately. No historical native pass is relabeled current.','current_head':commit['commit'],'compiled_and_prepared_paths':len(paths),'promotion_correspondence':correspondence,'driver_seconds':r['seconds'],'inputs':inputs,'native_executed_here':False}
(H/'runtime-reuse.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['inputs','promotion_correspondence']}))
