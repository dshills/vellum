# Native text/modal qualification on stage87

One fresh full68-input/33-observation native Go FIFO text/modal record after
committed stage87 body/gutter repair. All public actions and independent oracles,
private fixed1024 visibility correlation, original consumer copies and native
unavailable terminal behavior remain byte-identical to E. Stage87 repairs body
font admission and themed gutter without changing the frozen workspace goldens;
all six software records now pass. This case must independently qualify the full
native record including disabled editor, modal, original close and stale refs.

E failed21/3 at name-rejected with actual visibilityfalse/typed occlusion before
the disabled/modal phase; all eight older scopes remain sealed. No failed scope
is replayed or relabeled. No source/SDK/prepared/settings mutation, OS-input
operator, keyboard-source/VoiceOver/clipboard/prefs changes. Controlled native
Go routing does not prove physical/human/IME/pixels/presentation acceptance.

Current source/controller review and passing gallery race/vet/build plus exact
runtime reuse precede plan creation. Separate exact plan admission is required.
One case, shared LiveLease, owned process,120s watchdog,4MiB complete streams,
30-minute launch deadline, immutable whole source/prepared/SDK boundaries.
Unavailable or any failure seals permanently. A pass proceeds to M2 audit; no
full Mac gate closes automatically. No native launch is authorized by this draft.
