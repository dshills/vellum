"""Verify byte-identical private consumer copies from sealed S; no source mutation."""
from pathlib import Path
import hashlib,json
E=Path(__file__).resolve().parent;S=E.parent/'macos-catalogue-focus-d1232b5'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in ['control_catalogue.go','structure_catalogue.go','text_catalogue.go']:assert sha(E/'consumer'/n)==sha(S/'consumer'/n)
assert(E/'consumer-originals.json').read_bytes()==(S/'consumer-originals.json').read_bytes()
print('Three exact private Go consumer copies; only text native case will be admitted')
