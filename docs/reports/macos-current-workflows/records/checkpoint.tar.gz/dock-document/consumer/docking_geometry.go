// Private native acceptance configuration; no production source modification.
package main

import "cogentcore.org/core/core"

func init() {
	// NewBody otherwise lazily reloads persisted DebugSettings after this init.
	if err := core.LoadAllSettings(); err != nil {
		panic(err)
	}
	if core.AppearanceSettings.Zoom <= 0 {
		panic("native fixture requires initialized positive Core zoom")
	}
	core.DebugSettings.DisableWindowGeometrySaver = true
}
