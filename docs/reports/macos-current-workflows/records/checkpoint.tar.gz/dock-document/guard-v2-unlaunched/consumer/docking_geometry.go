// Private native acceptance configuration; no production source modification.
package main

import "cogentcore.org/core/core"

func init() { core.DebugSettings.DisableWindowGeometrySaver = true }
