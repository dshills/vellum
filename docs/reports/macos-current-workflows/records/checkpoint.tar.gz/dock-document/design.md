# Current M2 docking/document native fixtures — draft

No native plan/admission/launch yet. Current9013a73/stage87/Go1.25.6/Go2 with
SDK786a native archive, actual source plus two private Go init additions disabling Core window geometry
saving before native windows. Explicit WorkbenchGroup session persistence stays
under the owned fixture root. The sandbox also denies writes under the actual
user Library/Cogent Core directory; TMPDIR alone does not isolate that path. The existing
cmd/docking-smoke noninteractive fixture exercises real float/redock, shared
document state, native close return/focus transfer and complete session file
restoration; commands are owner-posted, not physical pointer/menu gestures.
The existing cmd/workbench -document-smoke fixture exercises native close and
in-process accessibility dialog actions, dirty Cancel/Discard/Open, temporary
atomic persistence/failure and save acknowledgment, with injected chooser/store.
It does not select real file panels or operate the OS keyboard/clipboard/prefs.

Build both current fixtures, run package race/vet tests, review exact source,
expected outputs, temporary-file ownership and shutdown. Use fresh reviewed
bounded native controller+exactplan admission, sharedlease, owned serial groups,
whole source/prepared/SDK guards and permanentseals. No new OS-input operator,
external app interaction, settings/VoiceOver/input-source change or oldscope
replay. M5 physical/tab-menu/realpanels and fullMac remain separate. Do not
infer broad resource/deallocation closure from process exit or PASS strings.

Source review stopped the initial draft before native launch because Core
geometry persistence uses the real account Library path even when TMPDIR changes.
Original unguarded builds/receipts remain historical only; v3 rebuilds and race/
vet must use the exact guard bytes. No original binary was executed. This private
configuration does not qualify default global geometry persistence or native
deallocation. No product source, prepared dependency or retained SDK is changed.

The controller also snapshots only hashes/lengths of the three Core geometry
files (.json/.lst/.lck) and directory existence before/after; their contents are
not copied. Symlink redirection is refused. All must remain unchanged.

The v2 init-only flag was also refused before any native launch: NewBody can
lazily load persisted DebugSettings after init. The v3 fixture loads normal Core
settings first, checks positive initialized zoom, then disables geometry saving.
Core loadSettings reads/defaults/applies but does not save. The private guard
also rejects dangling geometry-file symlinks before checking existence.
