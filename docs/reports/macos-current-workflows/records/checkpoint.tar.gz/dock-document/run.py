"""Two fresh current-source native docking/document fixtures, bounded and sealed."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD=json.loads((Q.parent/'macos-editor-gutter-font-5e30a6c/commit-result.json').read_bytes())['commit'];SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
s=importlib.util.spec_from_file_location('trusted_catalogue_guard',Q.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g;sha=h.sha;need=h.need
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sys.path.insert(0,str(Q));import validate as validator
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'no vector symlink')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean committed stage87 candidate')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5517,'current tracked source count')
 return{n:sha(root/n)for n in sorted(names)}
def geometry_state():
 root=Path('/Users/dshills/Library/Cogent Core')
 need(all(not p.is_symlink()for p in [root,*root.parents]),'real Core data path, no symlink redirection')
 entries={}
 for name in ['window-geometry-0.3.6.json','window-geometry-0.3.6.lst','window-geometry-0.3.6.lck']:
  p=root/name
  need(not p.is_symlink(),'no geometry-file symlink redirection')
  if p.exists():
   need(p.is_file()and p.stat().st_size<=16<<20,'bounded regular existing geometry data');entries[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return {'directory_exists':root.exists(),'files':entries}
def baseline():
 a=source(C);need(source(T)==a,'whole C/T source identity')
 prepared=lambda root:{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
 p=prepared(C);need(prepared(T)==p and len(p)==6277 and digest(p)=='eea8467deea571109daf815ab16508385baeb5e117dc51910e436146a26a41bf','reviewed stage87')
 sdk=vector(SDK);need(len(sdk)==7880 and digest(sdk)=='4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26','whole SDK unchanged')
 mapping=read(Q/'overlay.json')['Replace']
 expected={str(T/'drivers/cogent/cmd'/target/'geometry_isolated_vellum.go'):str(Q/'consumer'/name)for target,name in [('docking-smoke','docking_geometry.go'),('workbench','document_geometry.go')]}
 need(mapping==expected and all(not Path(k).exists()for k in expected),'two private geometry-guard Go additions only')
 return{'source':a,'prepared':p,'sdk':sdk,'unchanged_core_geometry':geometry_state()}
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def runtime_options():
 env={**g.child_environment(True),'GOMAXPROCS':'2'}
 return{k:env.get(k)for k in ['GOMAXPROCS','GOMEMLIMIT','GORACE']}
def prepare():
 need(not(Q/'plan.json').exists()and not(Q/'stop-live').exists()and all(not(Q/k).exists()for k in ['docking','document']),'fresh two-case workspace scope')
 b=baseline();review=read(Q/'internal-source-review.json');need(review['approved']and review['source_controller_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items()),'exact source/controller review')
 reuse=read(Q/'runtime-reuse.json');need(reuse['qualified_reuse']and all(sha(k)==v for k,v in reuse['inputs'].items()),'exact unchanged runtime reuse')
 pins=dict(reuse['inputs']);pins[str(Q/'runtime-reuse.json')]=sha(Q/'runtime-reuse.json')
 for name in ['dock-build-v3','document-build-v3','test-v3','vet-v3']:
  p=Q/(name+'.json');r=read(p);need(passing(r)and all(sha(k)==v for k,v in r['source_pins'].items()),'current owned prerequisite '+name);pins.update(r['source_pins']);pins[str(p)]=sha(p)
  for stream,info in r['logs'].items():
   p=Q/name/stream;need(p.stat().st_size==info['bytes']and sha(p)==info['sha256'],'raw prerequisite streams');pins[str(p)]=sha(p)
 controls=read(Q/'validation-controls.json');need(controls['synthetic_only']and not controls['native_executed']and len(controls['cases'])==27 and all(v['expected_accept']==v['observed_accept']for v in controls['cases'])and all(sha(k)==v for k,v in controls['inputs'].items()),'current27synthetic controls');pins.update(controls['inputs'])
 for name in ['macos-text-gutter-native-v1','macos-native-workspace-9013a73']:
  reviewed=read(Q.parent/name/'internal-native-result-review.json');need(reviewed['approved']and reviewed['native_case_passed']and not reviewed['unresolved_findings']and all(sha(k)==v for k,v in reviewed['inputs'].items()),'reviewed current native prerequisite '+name)
 files=[Path(__file__),Q/'check.py',Q/'design.md',Q/'internal-source-review.json',Q/'validate.py',Q/'validation_controls.py',Q/'validation-controls.json',Q/'overlay.json',Q/'consumer/docking_geometry.go',Q/'consumer/document_geometry.go',Q/'harness-isolation-v3.json',Q/'reuse_runtime.py',Q.parent/'macos-text-gutter-native-v1/internal-native-result-review.json',Q.parent/'macos-text-gutter-native-v1/result.json',Q.parent/'macos-native-workspace-9013a73/internal-native-result-review.json',Q.parent/'macos-native-workspace-9013a73/result.json',Path(h.__file__),h.GUARD,h.GO,h.PROV,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(p):sha(p)for p in files});binaries={name:read(Q/(receipt+'.json'))['binary']for name,receipt in [('docking','dock-build-v3'),('document','document-build-v3')]}
 need(all(sha(v['path'])==v['sha256']for v in binaries.values())and sha(h.GO)==h.GOSHA and sha(SDK/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')==h.LIBSHA,'exact native binaries/compiler/archive')
 oldpaths=[Q.parent/'macos-structure-catalogue-e9896d6',Q.parent/'macos-acquisition-diagnostics-4ce6ba4',Q.parent/'macos-text-modal-9854e5d',Q.parent/'macos-native-visibility-2aca9b6',Q.parent/'macos-native-visibility-corrected-2aca9b6',Q.parent/'macos-catalogue-visibility-90fc432',Q.parent/'macos-catalogue-focus-d1232b5',Q.parent/'macos-text-publication-native-v1',Q.parent/'macos-text-gutter-native-v1',Q.parent/'macos-native-workspace-594bd37/native-v2',Q.parent/'macos-native-workspace-594bd37/native-v4',Q.parent/'macos-native-workspace-594bd37/native-v5',Q.parent/'macos-native-workspace-9013a73']
 seals={str(p/'stop-live'):sha(p/'stop-live')for p in oldpaths if(p/'stop-live').exists()};need(len(seals)==13,'all thirteen prior catalogue/workspace scopes sealed');pins.update(seals)
 now=datetime.datetime.now(datetime.timezone.utc);plan={'head':HEAD,'boundary':b,'pins':pins,'binaries':binaries,'runtime_options':runtime_options(),'old_seals':seals,'cases':[{'id':'docking','arguments':['-timeout=20s','-session='+str(Q/'docking/fixture/session.json')]},{'id':'document','arguments':['-document-smoke','-rows=1000000','-tree-rows=1000']}],'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':150,'stream_limit_bytes':16<<20,'scope':'Two current9013/stage87 existing noninteractive native fixtures, docking then document. Actual T Go/Objective-C plus2private Go init additions disabling Core window geometry persistence, Go1.25.6/Go2 SDK786a. Dock commands owner-posted with independent external persisted-layout check; document uses in-process owned AX dialog actions and injected temporary chooser/store with four internal domain/persistence assertions and terminal scale/status checks. Not OS-input operator, physical pointer/tabmenu/realfilepanel/humanIME/VoiceOver/presentation/performance/resource or fullMac qualification. Only owned fixture outputs under freshcase roots; document TMPDIR scoped percase. Sharedlease/serialownedgroups/150s16MiB/freshdeadline/currentwholeC/TpreparedSDKguards/permanentseals. Any failure sealscampaign and skipslatercase; all13priorseals preserved. No source/SDK/prepared/OSpreferences change.'}
 (Q/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(Q/'plan.json'),'native_executed':False}))
def run():
 raw=(Q/'plan.json').read_bytes();adraw=(Q/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(adraw);stop=Q/'stop-live'
 need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact plan admission');need(not stop.exists()and not(Q/'result.json').exists()and all(not(Q/c['id']).exists()for c in p['cases']),'fresh serial scope')
 def stable():return(Q/'plan.json').read_bytes()==raw and(Q/'admission.json').read_bytes()==adraw and all(sha(k)==v for k,v in p['pins'].items())and all(sha(v['path'])==v['sha256']for v in p['binaries'].values())
 def boundary():need(not stop.exists()and stable(),'stable/no stop');need(baseline()==p['boundary']and runtime_options()==p['runtime_options'],'whole source/prepared/SDK/runtime boundary')
 d={'result':'INCOMPLETE','native_executed':False,'cases':{},'error':None,'closed_full_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('workspace controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary()
   for case in p['cases']:
    kind=case['id'];root=Q/kind;need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline per case')
    boundary();root.mkdir();fixture=root/'fixture';fixture.mkdir();temporary=fixture/'tmp';temporary.mkdir();entry={'result':'INCOMPLETE','error':None};d['cases'][kind]=entry
    try:
     profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(q))+'))'for q in [C,T,SDK,Path('/Users/dshills/Library/Cogent Core')])
     need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline immediately before launch')
     r=g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','TMPDIR='+str(temporary),p['binaries'][kind]['path'],*case['arguments']],T/'drivers/cogent',root/'run',lambda:stop.exists()or(root/'stop-live').exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);entry['run']=r;d['native_executed']|=r['created']
     boundary();need(lease.held(),'lease through retirement');entry['post_boundary_pass']=True;need(passing(r),'owned native '+kind)
     session=None
     if kind=='docking':
      saved=fixture/'session.json';need(saved.is_file()and not saved.is_symlink()and saved.stat().st_size<=262144,'bounded owned session file');session=saved.read_bytes()
     need(temporary.is_dir()and not temporary.is_symlink()and not list(temporary.iterdir()),'fixture removed its generated temporary outputs')
     entry['summary']=validator.validate(kind,(root/'run/stdout').read_bytes(),(root/'run/stderr').read_bytes(),session,str(temporary));entry['result']='PASS_NATIVE_'+kind.upper()
    except BaseException as e:entry.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
    finally:(root/'stop-live').touch();(root/'result.json').write_text(json.dumps(entry,indent=2)+'\n')
   d['result']='PASS_NATIVE_DOCK_DOCUMENT_CURRENT'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(Q/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error']}));print(json.dumps({k:v.get('summary')for k,v in d['cases'].items()}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
