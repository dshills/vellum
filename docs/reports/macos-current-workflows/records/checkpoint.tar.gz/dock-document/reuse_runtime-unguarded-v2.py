"""Qualify unchanged current software prerequisites; no native launch."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
J=Path(__file__).resolve().parent;A=J.parent;I=A/'macos-native-workspace-9013a73';H=A/'macos-text-gutter-native-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert not(J/'runtime-reuse.json').exists()
r=read(I/'runtime-reuse.json');assert r['qualified_reuse']and all(sha(p)==v for p,v in r['inputs'].items())
assert(J/'checked.mod').read_bytes()==(H/'checked.mod').read_bytes()and(J/'checked.sum').read_bytes()==(H/'checked.sum').read_bytes()
for name in ['dock-build-v1','document-build-v1','test-v1','vet-v1']:
 d=read(J/(name+'.json'));assert d['created']and d['exit_code']==0 and d['error']is None and not d['observation_errors']and d['logs_complete']and d['pins_stable']and d['owned']['terminal']and d['owned']['group_absent']and not d['owned']['errors']and all(sha(k)==v for k,v in d['source_pins'].items())
 for stream,info in d['logs'].items():
  p=J/name/stream;assert sha(p)==info['sha256']and p.stat().st_size==info['bytes']
paths=[I/'runtime-reuse.json',J/'checked.mod',J/'checked.sum',Path(__file__)]
r['inputs'].update({str(p):sha(p)for p in paths});r['scope']+=' New docking/workbench package race/vet and two native builds are checked separately. This proof launches no application.'
(J/'runtime-reuse.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'qualified_reuse':True,'effective_inputs':r['effective_inputs'],'producer_recorded':True,'native_executed_here':False}))
