"""Positive/negative synthetic controls; no native process or filesystem mutation."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q));import validate as v
root='/private/tmp/vellum-doc-control';dest=root+'/vellum-document-native-unique/fixture.vellum'
layout={'version':2,'windows':[{'id':'main','title':'Vellum Docking Workbench','bounds':{'width':900,'height':640},'root':{'id':'root','axis':'horizontal','ratio':0.7,'first':{'id':'documents','tabs':['board','notes'],'active':'notes'},'second':{'id':'inspector','tabs':['inspector'],'active':'inspector'}}}],'focus':{'window':'main','panel':'notes','serial':3}}
dock=(v.DOCK+'\n').encode();doc=('\n'.join([*v.DOCUMENT,'workbench actions=0 status=save complete: '+dest+' rows=1000000 pooled=24 tree_nodes=1000 selected=component:1','canvas objects=96 zoom=0.6000 selected=component:1'])+'\n').encode();encode=lambda d:json.dumps(d).encode()
cases=[]
def check(name,kind,stdout,stderr=b'',session=None,accept=False):
 error=None
 try:v.validate(kind,stdout,stderr,session,root);actual=True
 except (ValueError,KeyError,TypeError,UnicodeDecodeError)as e:actual=False;error=str(e)
 assert actual==accept,(name,actual,error);cases.append({'name':name,'expected_accept':accept,'observed_accept':actual,'error':error})
check('docking-positive','docking',dock,session=encode(layout),accept=True)
check('document-positive','document',doc,accept=True)
check('missing-docking-assertion','docking',b'',session=encode(layout))
check('duplicate-docking-assertion','docking',dock+dock,session=encode(layout))
check('unknown-docking-log','docking',b'noise\n'+dock,session=encode(layout))
check('docking-stderr','docking',dock,b'error\n',encode(layout))
check('missing-layout','docking',dock)
for name,mutate in [('wrong-focus',lambda d:d['focus'].__setitem__('panel','board')),('missing-returned-panel',lambda d:d['windows'][0]['root']['first'].__setitem__('tabs',['board'])),('stale-floating-window',lambda d:d['windows'].append(copy.deepcopy(d['windows'][0]))),('zero-focus-serial',lambda d:d['focus'].__setitem__('serial',0)),('invalid-client-size',lambda d:d['windows'][0]['bounds'].__setitem__('width',0))]:
 d=copy.deepcopy(layout);mutate(d);check(name,'docking',dock,session=encode(d))
check('duplicate-session-field','docking',dock,session=encode(layout).replace(b'"version": 2',b'"version": 2, "version": 2'))
check('oversized-layout','docking',dock,session=b'x'*262145)
for name,actual in [('missing-document-phase',doc.replace((v.DOCUMENT[2]+'\n').encode(),b'')),('wrong-document-rows',doc.replace(b'rows=1000000',b'rows=10000')),('wrong-tree-count',doc.replace(b'tree_nodes=1000',b'tree_nodes=10')),('wrong-selected-row',doc.replace(b'component:1',b'component:2')),('external-save-path',doc.replace(dest.encode(),b'/private/tmp/unowned/fixture.vellum')),('escaped-save-path',doc.replace(dest.encode(),(root+'/../unowned/fixture.vellum').encode())),('zero-zoom',doc.replace(b'zoom=0.6000',b'zoom=0.0000')),('wrong-canvas-count',doc.replace(b'objects=96',b'objects=95')),('unknown-document-log',b'noise\n'+doc),('legacy-font-warning',b'ERROR lines.Lines font style MUST be Monospace\n'+doc),('missing-terminal-statistics',doc[:doc.rfind(b'canvas objects=')])]:check(name,'document',actual)
check('document-stderr','document',doc,b'error\n')
check('unknown-fixture','other',doc)
paths=[Path(__file__),Q/'validate.py'];pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
out={'synthetic_only':True,'native_executed':False,'cases':cases,'inputs':pins};p=Q/'validation-controls.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'synthetic_cases':len(cases),'all_expected':True,'native_executed':False}))
