"""Map named catalogue tests to actual retained PASS lines; no native claim."""
from pathlib import Path
import hashlib,json,re,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');G=Q.parent/'macos-editor-gutter-font-5e30a6c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
logs={name:path for name,path in [('driver',G/'driver-v1/stdout'),('gallery',G/'gallery-v1/stdout'),('workspace',G/'workspace-v1/stdout'),('portable',Q/'portable-test-v1/stdout')]}
rows=[];source=Q/'control-map-9013a73.md'
for line in source.read_text().splitlines():
 if not line.startswith(('| `','| Breadcrumb composite','| ColorPicker composite')):continue
 cells=line.split('|')[1:-1];hits=[]
 for name in re.findall(r'`(Test[A-Za-z0-9_]+)`',cells[1]):
  matches=[]
  for scope,path in logs.items():
   lines=[v for v in path.read_text().splitlines()if ('PASS: '+name+' (')in v]
   if lines:matches.append({'scope':scope,'log':str(path),'pass_lines':lines})
  hits.append({'test':name,'executed_matches':matches})
 rows.append({'control':cells[0].strip().strip('`'),'methods':cells[2].strip(),'test_assertions':hits,'all_named_tests_have_executed_pass':all(v['executed_matches']for v in hits)})
assert len(rows)==36
inputs=[source,Path(__file__),*logs.values()]
for name in ['driver-v1','gallery-v1','workspace-v1']:inputs.append(G/(name+'.json'))
inputs.append(Q/'portable-test-v1.json')
out={'source':'9013a7395317c12698270bfd69d193e49725e742','original_source_map':str(T/'specs/control-acceptance.md'),'source_map':str(source),'source_map_sha256':sha(source),'method':'Exact named PASS lines in preserved current Gdriver/gallery/workspace and Mportable raw logs. Name execution is coverage, not a claim that every dedicated contract or physical/native method is satisfied.','rows':rows,'missing_named_execution':[{'control':r['control'],'test':v['test']}for r in rows for v in r['test_assertions']if not v['executed_matches']],'inputs':{str(p):sha(p)for p in inputs},'native_reuse_qualified_here':False,'closed_full_mac_gates':[]}
(Q/'catalogue-test-map.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'rows':len(rows),'missing':out['missing_named_execution']}))
