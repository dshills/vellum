# M2 qualification audit draft — 9013a73

This is an audit worklist for the existing M2 row in specs/macos-delivery.md,
not a replacement acceptance scope or declaration of completion. Source is
9013a7395317c12698270bfd69d193e49725e742, prepared stage87. All candidate evidence
must bind that source/configuration or justify reuse of exact affected bytes.

| Required area | Current direct evidence | Next decision or missing evidence |
| --- | --- | --- |
| Full professional workspace | Six original frozen software216-operation27-capture records at10k/1M, batches1/7/64 pass in G. Goldens unchanged. | Current I two native10k/1M records pass432/54 on stage87; independently reviewed result0181ddc2. Historical cases remain sealed. |
| Catalogue vocabulary | Existing map names a test for34 kinds plus Breadcrumb/ColorPicker composites. Native Selector/Number57/21, choices30/23, navigation47/41, media71/42, structure50/42 each have scoped passes at earlier source identities. | Audit each row against its dedicated contract, source identity and actual assertions; preserve progress-pixel, Slider-drag and other explicit scope limits. A named or historical test alone is not broad qualification. |
| Text/modal workflow | G body/gutter regression and publication/geometry/manual checks pass. Older failed scopes stay sealed. | Current H full68-input33-state native record passes and is independently reviewed17151686: accepted/rejected/disabled edits, Unicode/history, modal priority, original close and retired refs. E21/3 occlusion remains failed and does not identify its own cause. |
| Commands/history/tasks/documents | Full workspace includes command/history, worker and document domain validations; dedicated native document/chooser evidence exists. | Map individual M2 save/open/dirty-close, cancellation and stale-ref requirements to exact raw assertions; renew any affected runtime path. No claim about arbitrary external services follows. |
| Docking and independent windows | Public professional record includes tab reorder, palette placement, modal precedence and surviving-window state. | Verify dock/float/redock and real independent-window requirements against dedicated workbench/dock scenarios; list any unexercised path instead of inferring coverage from tab reorder. |
| Large data | Six software records cover10k/1M; dedicated grid/tree routing tests exist. | Audit large-data edit/selection/scroll semantics and native coverage separately from M3 latency. Passing data model/geometry does not meet frame budgets. |
| Human/display workflows | M5 has an explicit separate matrix and frozen failed OS-input operator attempts. | Physical palette gesture, OS IME, human VoiceOver, external drops/services and hardware display transitions require their actual methods. Do not silently use automated routing as that evidence. |

After J docking/document qualification, produce a requirement-to-evidence
matrix with pass/fail/open, exact tested input identities and explicit reuse
reasoning. A missing or failing required path stays open. Only that complete
audit can decide M2 closure; M3–M7 and full Mac completion remain separate.

Current portable root Go1.25.6/GOMAXPROCS2 root-module race suite passes25.228s
and default vet passes1.496s, complete raw streams/stable11803pins/owned groups
84534 and84555 retired/absent. These checks independently cover root Go APIs
including command/history/document/task/workbench contracts. They do not qualify
native driver routing or close a complete Mac milestone.
