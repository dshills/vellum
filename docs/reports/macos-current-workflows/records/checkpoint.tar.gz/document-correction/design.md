# Retained document-output checker correction — no native rerun

J remains sealed FAILED_OR_CANCELED. Its docking case passes, and its document
process exits0 with four source assertions, complete/stable raw streams, unchanged
whole post-boundary and absent owned process group. The original external checker
incorrectly expects tree_nodes=1000 for -tree-rows=1000. Source buildOutline adds
one project root, ceil(count/1000) group nodes and count component nodes:1002.
main prints treeModel.Len, and decodeDocument rebuilds the same outline.

This new external validator changes only the exact total node count1000→1002
and labels1000 component_tree_rows separately. It must retain all other assertions,
strict diagnostics/path/geometry/output rules and reject1000. Independent review
must decide whether retained output establishes the corrected expectation; no
native process, source/SDK/golden mutation or reset of the failed scope is permitted.
The original failed result and original validator/control proof stay verbatim.
