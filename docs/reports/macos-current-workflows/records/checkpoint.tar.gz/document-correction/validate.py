"""Bounded external fixture-output/layout oracle. Synthetic fixtures are not UI evidence."""
from pathlib import PurePosixPath
import json,math,re
DOCK='PASS native float, cross-window redock, native close return, shared document state, focus transfer and complete session persistence'
DOCUMENT=['PASS native CloseReq refusal, modal Cancel and intact workbench','PASS asynchronous 1000000-component save/load with exact geometry and ordered references','PASS failed Save keeps unsaved native window open','PASS native Save confirmation closes only after successful current-revision acknowledgment']
def need(ok,msg):
 if not ok:raise ValueError(msg)
def integer(v):return type(v)is int

def validate(kind,stdout,stderr,session=None,temporary_root=None):
 need(kind in ['docking','document'],'known fixture');need(len(stdout)<=16<<20 and len(stderr)<=16<<20,'bounded streams');need(not stderr,'no stderr diagnostics')
 text=stdout.decode('utf8');need('\0'not in text,'literal text');lines=text.splitlines()
 if kind=='docking':
  need(lines==[DOCK],'exact single docking result, no extra output')
  need(type(session)is bytes and 0<len(session)<=262144,'owned complete session file')
  def pairs(items):
   out={}
   for k,v in items:need(k not in out,'no duplicate session field');out[k]=v
   return out
  d=json.loads(session,object_pairs_hook=pairs);need(set(d)=={'version','windows','focus'}and d['version']==2,'complete v2 layout')
  w=d['windows'];need(type(w)is list and len(w)==1 and set(w[0])=={'id','title','bounds','root'},'one complete surviving layout');w=w[0]
  need(w['id']=='main'and w['title']=='Vellum Docking Workbench','surviving main identity')
  b=w['bounds'];need(set(b)<={'x','y','width','height','positioned'}and integer(b['width'])and integer(b['height'])and 160<=b['width']<=16384 and 96<=b['height']<=16384,'valid saved client bounds')
  for dim in ['x','y']:
   if dim in b:need(integer(b[dim])and abs(b[dim])<=1000000,'bounded saved position')
  if 'positioned'in b:need(type(b['positioned'])is bool,'position flag')
  root=w['root'];need(set(root)=={'id','axis','ratio','first','second'}and root['id']=='root'and root['axis']=='horizontal'and type(root['ratio'])in [float,int]and math.isfinite(root['ratio'])and 0<root['ratio']<1,'split topology preserved')
  need(root['first']=={'id':'documents','tabs':['board','notes'],'active':'notes'},'returned notes appended to documents and active')
  need(root['second']=={'id':'inspector','tabs':['inspector'],'active':'inspector'},'inspector preserved')
  f=d['focus'];need(set(f)=={'window','panel','serial'}and f['window']=='main'and f['panel']=='notes'and integer(f['serial'])and 0<f['serial']<(1<<64),'focus transferred to surviving notes')
  return {'result':'PASS_SOURCE_ASSERTED_NATIVE_DOCKING','session_version':2,'windows':1,'panels':['board','notes','inspector'],'focus':'main/notes','external_layout_verified':True,'physical_input_verified':False,'resource_deallocation_verified':False}
 need(lines[:4]==DOCUMENT and len(lines)==6,'four ordered complete document assertions and two terminal statistics')
 m=re.fullmatch(r'workbench actions=0 status=save complete: (.+) rows=1000000 pooled=(\d+) tree_nodes=1002 selected=component:1',lines[4]);need(m is not None,'exact document fixture scale and accepted save status')
 path=PurePosixPath(m[1]);base=PurePosixPath(temporary_root or '')
 need(base.is_absolute()and path.is_absolute()and '..'not in path.parts and path.is_relative_to(base),'save path under owned temporary root')
 rel=path.relative_to(base);need(len(rel.parts)==2 and rel.parts[0].startswith('vellum-document-native-')and len(rel.parts[0])>len('vellum-document-native-')and rel.parts[1]=='fixture.vellum','owned generated fixture destination')
 need(0<int(m[2])<=1000000,'nonempty visible table')
 c=re.fullmatch(r'canvas objects=96 zoom=([0-9]+\.[0-9]{4}) selected=component:1',lines[5]);need(c is not None and math.isfinite(float(c[1]))and float(c[1])>0,'complete retained canvas statistics')
 return {'result':'PASS_SOURCE_ASSERTED_NATIVE_DOCUMENT','component_rows':1000000,'tree_nodes':1002,'component_tree_rows':1000,'objects':96,'temporary_path':str(path),'source_assertions':4,'injected_chooser':True,'physical_input_verified':False,'real_file_panel_verified':False,'resource_deallocation_verified':False}
