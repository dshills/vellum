"""Independent bounded result validation; synthetic controls are not native evidence."""
import json,math,re
from pathlib import Path
from functools import lru_cache
W=Path(__file__).resolve().parent
C=Path('/Users/dshills/Development/projects/Vellum')
def need(ok,msg):
 if not ok:raise ValueError(msg)
@lru_cache(maxsize=6)
def reference_order(count,loaded,sorted_rows,filtered):
 if not loaded:return ()
 order=[r for r in range(count)if not filtered or '7'in str((r*97+20)%10007)]
 if sorted_rows:order.sort(key=lambda r:(-((r*97+7)%10007),r))
 return tuple(order)
def replace_anchor(old,new,y):
 if not old:return y
 key=old[min(y//24,len(old)-1)]
 try:return new.index(key)*24+y%24
 except ValueError:return y
class GridReference:
 def __init__(self):self.sequence=0;self.key=None;self.order=();self.software=0;self.native=0;self.x=0
 def offsets(self,sequence,m,view):
  need(sequence>self.sequence and m['Grid']['Config']['RowHeight']==24 and m['Grid']['Config']['HeaderHeight']==28,'reference sequence/configuration')
  key=(m['StoredRows'],m['Loaded'],m['Sorted'],m['Filtered']);order=reference_order(*key)
  if key!=self.key:
   self.software=replace_anchor(self.order,order,self.software);self.native=replace_anchor(self.order,order,self.native)
  if self.sequence<63<=sequence:self.x+=76;self.software-=288;self.native-=288
  def clamp(y,height):return max(0,min(y,max(0,len(order)*24-max(0,height-28))))
  self.software=clamp(self.software,m['Grid']['Viewport']['Height']);self.native=clamp(self.native,view['Height'])
  need(len(order)==m['Grid']['Stamp']['Rows']and m['Grid']['TotalHeight']==len(order)*24 and self.software==m['Grid']['Viewport']['ScrollY']and self.x==m['Grid']['Viewport']['ScrollX'],'immutable source/anchor/wheel reference')
  self.sequence=sequence;self.key=key;self.order=order
  return self.x,self.native
def validate(raw,rows,stderr=b''):
 need(len(raw)<=16<<20 and len(stderr)<=16<<20,'bounded JSON result/diagnostics')
 lines=raw.decode('utf-8').splitlines();reports=[];warnings=0
 for line,is_stdout in [(line,True)for line in lines]+[(line,False)for line in stderr.decode('utf-8').splitlines()]:
  if is_stdout and line.startswith('{'):reports.append(line);continue
  need(False,'unexpected non-JSON native output; stage87 must emit no font warnings')
 need(len(reports)==1,'exactly one result frame')
 d=json.loads(reports[0]);need(d['Event']=='vellum.workspace-native.result'and d['Result']=='PASS_NATIVE_WORKSPACE_RECORD'and not d['Error'],'native report success')
 need(d['ScenarioJoined']and d['WorkerJoined'],'joined scenario/workers')
 s=d['Session'];need(s['Started']and s['Closed']and not s['Pending']and s['LiveWindows']==0 and s['Issued']>0,'session retired')
 ex=d['Executor'];need(ex['Closed']and ex['Pending']==ex['Running']==ex['Failed']==0 and ex['Accepted']==ex['Completed']==7,'seven authored workers, terminal ledger')
 c=d['Cleanup'];need(c['MainThread']and c['CleanupObserved']and c['CallbacksStopped']and c['PendingCallbacks']==c['NativeOutstanding']==c['AccessibilityWindows']==0 and not c['WindowTitles']and c['FilePanels']['Tracked']==0 and not c['Menu']['Owned']and not c['Tray']['Present'],'native inventory retired')
 root=C/'examples/replay/workspace/records';record=json.loads((root/(str(rows)+'.json')).read_bytes());expected=json.loads((root/(str(rows)+'.golden.json')).read_bytes())
 w=d['Workflow'];need(w['Event']=='vellum.workspace-native-record.result'and w['Result']=='PASS_NATIVE_RECORD_DOMAIN_AND_ROUTING'and not w.get('Error')and w['Rows']==rows and w['Applied']==len(record['operations'])==216,'entire authored record')
 need(len(w['Operations'])==216 and len(w['Captures'])==len(expected)==27,'bounded complete routing/capture receipts')
 for o,r in zip(record['operations'],w['Operations']):
  need(r['Sequence']==o['sequence']and r['Kind']==o['kind']and r['Window']==o.get('window',''),'ordered operation identity')
  if o['sequence']in[17,122]:need(r.get('NativeChord')=='Meta+A'and r.get('TransportNote')=='mac-select-all','declared Mac Select All transport')
  else:need(not r.get('TransportNote'),'no unreviewed shortcut adaptation')
  retirement=r['Result']=='EXPECTED_WINDOW_RETIREMENT';need(r['Result']=='APPLIED'or(retirement and o['sequence']==214 and o['kind']=='pointer-up'),'exactly admitted operation result')
 reference=GridReference()
 for g,c in zip(expected,w['Captures']):
  need(c['Sequence']==g['Sequence']and c['Label']==g['Label'],'capture identity')
  actual=json.loads(json.dumps(c['Model']));want=json.loads(json.dumps(g['Data']['Model']))
  x,y=reference.offsets(c['Sequence'],want,actual['Grid']['Viewport']);want['Grid']['Viewport']['ScrollX']=x;want['Grid']['Viewport']['ScrollY']=y
  for path in [('Grid','Viewport'),('Tree','Viewport'),('Canvas','View')]:
   a=actual[path[0]][path[1]];e=want[path[0]][path[1]]
   for dim in ['Width','Height']:need(isinstance(a[dim],(int,float))and math.isfinite(a[dim])and a[dim]>0,'positive recorded native dimensions');a[dim]=e[dim]
  for dim in ['X','Y']:
   v=actual['Canvas']['View']['Center'][dim];e=want['Canvas']['View']['Center'][dim];need(math.isfinite(v)and abs(v-e)<=1,'frozen camera bar');actual['Canvas']['View']['Center'][dim]=e
  need(actual==want,'immutable domain assertions '+g['Label'])
  need(sorted(v['ID']for v in c['Windows'])==sorted(v['ID']for v in g['Data']['Windows']),'exact surviving window set')
  for win in c['Windows']:
   snap=win['Snapshot'];need(snap['Frame']>0 and snap['Size']['X']>0 and snap['Size']['Y']>0 and math.isfinite(snap['LogicalDPI'])and snap['LogicalDPI']>0,'native frame/geometry capability')
 return {'rows':rows,'known_fixture_font_diagnostics':warnings,'operations':216,'captures':27,'native_scheduling':'autonomous','physical_input':False,'full_mac_qualified':False}
