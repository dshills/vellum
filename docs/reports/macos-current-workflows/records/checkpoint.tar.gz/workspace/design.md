# Current composed native workspace qualification

Draft only: no plan/admission/native launch. Use current9013a73/stage87 source,
actual checkout native units and pinned SDK786a library with Go1.25.6/Go2.
Build the existing public tagged workspace-native consumer without Go overlays.
Two newly admitted CPU-scene cases must each complete the original216 operations
and27 captures at10k/1M rows. Stop and permanently seal after any failure; skip
later cases. Preserve all older workspace/catalogue scope seals.

The historical independent domain/order/viewport/worker/session/cleanup oracle
is unchanged except the diagnostics contract is now strictly stronger: reject
all non-JSON output, including the original known Monospace warnings repaired by
stage87. Retain original records/goldens and the frozen viewport/camera rules.
Regenerate its synthetic controls, changing only the old warning-accepted cases
to warning-refused cases. No silent output suppression or golden changes.

G's exact current fullroot/gallery/workspace software proof and H68/33 native
pass are prerequisites, not substitutes for this composed record. Recheck the
actual native consumer build/vet and any native-oracle test not already covered.
Before launch, complete source/controller review, exact bounded plan admission,
shared lease/owned children/240s watchdog16MiB streams/fresh deadline and whole
source/prepared/SDK boundary guards. No OS operator/input/prefs/VoiceOver changes.
Physical/human/presented-window pixels, presentation, performance, rights and
full Mac acceptance remain separate. The consumer's existing painted placement/
preview readback assertions stay required.
