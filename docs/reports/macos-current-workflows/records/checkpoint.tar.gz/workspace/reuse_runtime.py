"""Qualify current full driver/workspace software evidence; no native execution."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
I=Path(__file__).resolve().parent;A=I.parent;G=A/'macos-editor-gutter-font-5e30a6c';H=A/'macos-text-gutter-native-v1';F=A/'macos-current-workspace-m2-v1';T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert not(I/'runtime-reuse.json').exists()
proof=read(H/'runtime-reuse.json');assert proof['qualified_reuse']and all(sha(p)==v for p,v in proof['inputs'].items())
inputs=dict(proof['inputs']);r=read(G/'workspace-v1.json');assert r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
mapping=read(G/'overlay.json')['Replace'];count=0
for p in inputs:
 if Path(p).is_relative_to(T)and (Path(p).suffix in ['.go','.c','.h','.m','.mm','.wgsl','.ttf','.otf']or Path(p).is_relative_to(T/'drivers/cogent/build')):
  tested=mapping.get(p,p);assert sha(p)==r['source_pins'][tested];count+=1
assert count==7049
for n in ['checked.mod','checked.sum']:assert(I/n).read_bytes()==(F/n).read_bytes()
for stream,info in r['logs'].items():
 p=G/'workspace-v1'/stream;assert sha(p)==info['sha256']and p.stat().st_size==info['bytes'];inputs[str(p)]=sha(p)
for p in [G/'workspace-v1/owned.json',G/'workspace-v1.json',G/'overlay.json',H/'runtime-reuse.json',Path(__file__),I/'checked.mod',I/'checked.sum']:inputs[str(p)]=sha(p)
text=(G/'workspace-v1/stdout').read_text()
names=['TestNativeMacSelectAllIntentIsNarrowAndExplicit','TestNativeRecordOracleRetainsAllAuthoredCaptures','TestNativeRecordDomainFocusAndGeometryFailures','TestNativeTargetNamespaceAndWorkflowRefusals','TestNativeAnchorsUseCurrentCompositeAllocation','TestNativeCanvasPublicationAndPreviewAreRequired','TestNativeSequentialGridAnchorReference']
assert all('--- PASS: '+n+' 'in text for n in names)
out={'qualified_reuse':True,'scope':'Exact7049 effective tracked runtime/prepared inputs match both full driver and full workspace race. Private7Go overlay outputs were promoted byte-identically and actualsource focused/Core/preparation passed. Full workspace root/smoke/all6original frozen records unchanged; all7native-oracle methods passed in that same package selection. Current tagged native consumer build/vet are checked separately. This proves software prerequisites only.','current_head':proof['current_head'],'effective_inputs':count,'driver_seconds':proof['driver_seconds'],'workspace_seconds':r['seconds'],'native_oracle_tests':names,'inputs':inputs,'native_executed_here':False}
(I/'runtime-reuse.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='inputs'}))
