from pathlib import Path
import json,hashlib,sys,importlib.util,os
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=load(q/'build-identity.json');assert os.access(q/'framework',os.X_OK) and sha(q/'framework')==d['binary_sha256'];assert sha(Path(d['native_root'])/'libs-darwin/arm64/libwgpu_native.a')==d['archive_sha256']==load(q.parent/'macos-staging-cache/build-identity.json')['archive_sha256']
for group in ['private_source_pins','overlay_pins','tool_source_pins']:assert all(sha(Path(p))==h for p,h in d[group].items())
b=load(q/'go-build-receipt.json');r=b['run'];assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent'] and r['pins_stable'] and r['logs_complete']
for p,h in b['inputs'].items():assert sha(Path(p))==h
for name,h in r['logs'].items():assert sha(q/'go-build'/name)==h['sha256']
for p,h in load(q/'focused-test-summary.json')['test_pins'].items():assert sha(Path(p))==h
proof=load(q.parent/'macos-staging-cache/summary.json');assert proof['outcome']=='VALID_PRIVATE_STAGING_BYTE_PAIR' and proof['GPU_verified_readbacks']==44 and proof['GPU_verified_bytes']==97912700
s=importlib.util.spec_from_file_location('cachetiming_sdk',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS exactbyteverifiednative archive/private/Go/source/overlay/modfile/test/log/SDK8321pins;2newwrappermethods/7refusals. No newnativeexecution/qualification.')
