from pathlib import Path
import os,sys,importlib.util,hashlib,json,time
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');W=Path('/private/tmp/vellum-v1-distribution-audit-20261027-v2');os.environ.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath')
sys.path.insert(0,str(R/'scripts'));s=importlib.util.spec_from_file_location('release',R/'scripts/release-sdk.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
sdk=Path(json.loads((W/'locations.json').read_text())['sdk']);result={'source':'4b42fb89948b8abf0f2f65970fb5980987c1af0c','distribution_audit':'pending','public_sdk_produced':False,'scope':'Fresh checksum-verified dependency preparation comparison only; public packaging gates not bypassed.','dependencies':{}}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with m.public_dependencies(R) as deps:
 for name,root in deps.items():
  target=sdk/'drivers/cogent/build'/name
  a={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};b={str(p.relative_to(target)):sha(p) for p in target.rglob('*') if p.is_file()}
  result['dependencies'][name]={'prepared_files':len(a),'candidate_files':len(b),'only_fresh':sorted(a.keys()-b.keys()),'only_candidate':sorted(b.keys()-a.keys()),'changed':[n for n in sorted(a.keys()&b.keys()) if a[n]!=b[n]]}
(W/'public-preparation-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
