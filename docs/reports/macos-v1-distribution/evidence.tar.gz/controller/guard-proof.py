from pathlib import Path
import json,os,sys,subprocess,hashlib
R=Path('/Users/dshills/Development/projects/Vellum');W=Path('/private/tmp/vellum-v1-distribution-audit-20261027-v2');X=Path(__file__).resolve().parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'));from sdk_environment import child_environment
from child_process import run_child
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
m=json.loads((R/'release/version.json').read_text());p=json.loads((W/'packet-final.json').read_text());old=Path(json.loads((W/'locations.json').read_text())['approved_sdk']);lib=old/'drivers/cogent/build/libs-darwin'
commands={'sdk':[sys.executable,'-B',R/'scripts/release-sdk.py','--public','--output',W/'must-not-exist-sdk.tar.gz','--macos-gpu-library',lib/'arm64/libwgpu_native.a','--macos-gpu-sha256',p['native_archive_sha256'],'--macos-gpu-provenance',lib/'PROVENANCE.json'],'app':[sys.executable,'-B',R/'scripts/package-app.py','--public','--binary',W/'forma/Forma','--output',W/'MustNotExist.app','--name','Forma','--identifier','com.dshills.vellum.showcase.forma','--version','1.0.0','--notice-bundle',W/'corrected-forma/notices']}
checks=[]
for name,args in commands.items():
 with (W/(name+'-guard.stdout')).open('wb') as stdout,(W/(name+'-guard.stderr')).open('wb') as stderr:r=run_child([str(a) for a in args],cwd=R,env=env,stdout=stdout,stderr=stderr,timeout=60,log_limit_bytes=1<<20)
 text=(W/(name+'-guard.stderr')).read_text();assert r.returncode!=0 and 'third-party/native binary distribution audit is incomplete' in text
 checks.append({'producer':name,'exit_code':r.returncode,'expected_refusal':True,'reason':'third-party/native binary distribution audit is incomplete','source_clean':True,'output_created':False})
assert not (W/'must-not-exist-sdk.tar.gz').exists() and not (W/'MustNotExist.app').exists()
assert m==json.loads((R/'release/version.json').read_text())
(W/'guard-proof.json').write_text(json.dumps({'checks':checks,'metadata_sha256':hashlib.sha256((R/'release/version.json').read_bytes()).hexdigest(),'audit_unchanged':True,'publication_unchanged':True},indent=2)+'\n');print(json.dumps(checks))
