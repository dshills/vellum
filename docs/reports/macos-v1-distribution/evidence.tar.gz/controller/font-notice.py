from pathlib import Path
import json,hashlib,sys,importlib.util,os,shutil,time
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');W=Path('/private/tmp/vellum-v1-distribution-audit-20261027-v2');X=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'));from child_process import run_child
from sdk_environment import child_environment
import app_notices
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath')
sdk=Path(json.loads((W/'locations.json').read_text())['sdk']);p=json.loads((W/'packet.json').read_text());out=W/'final';out.mkdir();proofdir=W/'font-proof';proofdir.mkdir();checks=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,cwd=R):
 start=time.monotonic()
 with (proofdir/(name+'.stdout')).open('wb') as stdout,(proofdir/(name+'.stderr')).open('wb') as stderr:r=run_child([str(a) for a in args],cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=180,log_limit_bytes=4<<20)
 checks.append({'name':name,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3)});assert r.returncode==0,name
 return (proofdir/(name+'.stdout')).read_text()
f=proofdir/'font-proof.go';f.write_text('''package main
import("crypto/sha256";"encoding/json";"fmt";"golang.org/x/image/font/gofont/goregular";"golang.org/x/image/font/gofont/gobold")
func main(){ b,_:=json.Marshal(map[string]string{"Go-Regular.ttf":fmt.Sprintf("%x",sha256.Sum256(goregular.TTF)),"Go-Bold.ttf":fmt.Sprintf("%x",sha256.Sum256(gobold.TTF))});fmt.Println(string(b)) }
''')
fontHashes=json.loads(run('font-byte-proof',['go','run','-mod=readonly',f],sdk/'examples/showcase'));root=Path('/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/x/image@v0.44.0');notice=root/'font/gofont/ttfs/README';h=sha(notice)
for name,expected in fontHashes.items():assert sha(root/'font/gofont/ttfs'/name)==expected
(proofdir/'README.Go-fonts').write_bytes(notice.read_bytes())
shutil.copyfile(W/p['sdk_archive'],out/p['sdk_archive'])
for a in p['apps']:
 if a['id'] not in {'forma','luma','pulse'}:
  shutil.copyfile(W/a['archive'],out/a['archive']);continue
 slug=a['id'];ad=W/slug;corrected=W/('corrected-'+slug);corrected.mkdir();nb=corrected/'notices';shutil.copytree(ad/'notices',nb);n=json.loads((nb/'INVENTORY.json').read_text());name='NOTICES/'+h+'-Go-fonts-README';assert h not in {f['sha256'] for f in n['files'].values()}
 (nb/name).write_bytes(notice.read_bytes());n['files'][name]={'bytes':notice.stat().st_size,'sha256':h};n['components'].append({'id':'font:Go Regular and Go Bold / Bigelow and Holmes','notice_files':[name]});n['scope']+=' Includes original Go-font family notice for compiled Regular/Bold TTF byte arrays.';(nb/'INVENTORY.json').write_text(json.dumps(n,indent=2,sort_keys=True)+'\n');app_notices.load(nb,a['source_binary_sha256'])
 app=corrected/(a['name']+'.app');run(slug+'-package',[sys.executable,'-B',R/'scripts/package-app.py','--binary',ad/a['name'],'--output',app,'--name',a['name'],'--identifier',a['identifier'],'--version','1.0.0','--build-version','10','--notice-bundle',nb,'--icon',W/'icons'/(slug+'.png'),'--sign-identity','-'])
 archive=out/a['archive'];run(slug+'-zip',['ditto','-c','-k','--norsrc','--noextattr','--keepParent',app,archive]);extract=corrected/'exact';extract.mkdir();run(slug+'-extract',['ditto','-x','-k',archive,extract]);run(slug+'-signature',['codesign','--verify','--deep','--strict',extract/app.name]);assert sha(ad/a['name'])==a['source_binary_sha256']
 a.update(archive_sha256=sha(archive),packaged_binary_sha256=sha(extract/app.name/'Contents/MacOS'/a['name']),notice_inventory_sha256=sha(nb/'INVENTORY.json'),notice_files=len(n['files']),notice_components=len(n['components']),added_notice_files=[{'file':name,'sha256':h,'component':'Go font family'}],compiled_font_hashes=fontHashes)
p.update(asset_directory='final',font_notice={'module':'golang.org/x/image','version':'v0.44.0','file':'font/gofont/ttfs/README','sha256':h,'compiled_fonts':fontHashes,'scope':'Original font-specific notice absent from alpha.3 bundle; now included in the three showcase apps. Module root Go Authors notice alone did not carry this font-specific copyright.'});p['checks'].extend(checks)
(W/'packet-final.json').write_text(json.dumps(p,indent=2)+'\n');(out/'SHA256SUMS').write_text(p['sdk_sha256']+'  '+p['sdk_archive']+'\n'+''.join(a['archive_sha256']+'  '+a['archive']+'\n' for a in p['apps']))
print(json.dumps({'complete':True,'candidate_assets':str(out),'font_notice_sha256':h,'apps':len(p['apps'])}))
