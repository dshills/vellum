from pathlib import Path
import os,sys,json,hashlib,importlib.util,subprocess,time,shutil,re,tarfile
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum'); X=Path(__file__).resolve().parent
W=Path('/private/tmp/vellum-v1-distribution-audit-20261027'); W.mkdir()
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
from child_process import run_child
import app_notices

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
checker=module('checker',R/'scripts/check-sdk.py'); collector=module('collector',R/'scripts/distribution-inventory.py')
env=child_environment();env.update(PATH='/private/tmp/vellum-preview-cache/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOTOOLCHAIN='local',GOCACHE='/private/tmp/vellum-preview-cache/build',GOMODCACHE='/private/tmp/vellum-preview-cache/mod',GOPATH='/private/tmp/vellum-preview-cache/gopath',VELLUM_CACHE_DIR='/private/tmp/vellum-preview-cache',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
checks=[]; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
head=git('rev-parse','HEAD');assert head=='4b42fb89948b8abf0f2f65970fb5980987c1af0c' and not git('status','--porcelain')
def run(name,argv,cwd=R):
 start=time.monotonic()
 with (W/(name+'.stdout')).open('wb') as out,(W/(name+'.stderr')).open('wb') as err:
  p=run_child([str(a) for a in argv],cwd=cwd,env=env,stdout=out,stderr=err,timeout=600,log_limit_bytes=64<<20)
 record={'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)};checks.append(record);print(json.dumps(record),flush=True)
 if p.returncode:raise RuntimeError(name+': '+(W/(name+'.stderr')).read_text(errors='replace')[-1800:])
 return (W/(name+'.stdout')).read_text()
oldarchive=X.parent/'macos-preview-release/vellum-v0.1.0-alpha.3-darwin-arm64-sdk.tar.gz';oldhash='28a95b5c2354673d97161df30e828008a5aa18465ce18545a42e8caf0a82f269'
oldv=checker.verify_archive(oldarchive,oldhash);old=checker.extract_verified(oldarchive,W/'approved',oldv)
audit=json.loads((R/'release/macos-preview-audit.json').read_text()); native=old/'drivers/cogent/build/libs-darwin';assert sha(native/'arm64/libwgpu_native.a')==audit['native_archive_sha256']
sdkarchive=W/'vellum-v1.0.0-audit-sdk.tar.gz'
run('sdk-export',[sys.executable,'-B',R/'scripts/release-sdk.py','--output',sdkarchive,'--macos-gpu-library',native/'arm64/libwgpu_native.a','--macos-gpu-sha256',audit['native_archive_sha256'],'--macos-gpu-provenance',native/'PROVENANCE.json'])
v=checker.verify_archive(sdkarchive,sha(sdkarchive)); sdk=checker.extract_verified(sdkarchive,W/'candidate',v); assert v['manifest']['source']['commit']==head
(W/'locations.json').write_text(json.dumps({'sdk':str(sdk),'approved_sdk':str(old),'source':head},indent=2)+'\n')
oldinv=json.loads((old/'THIRD_PARTY_INVENTORY.json').read_text()); newinv=json.loads((sdk/'THIRD_PARTY_INVENTORY.json').read_text())
def modident(i):return {m['module']:{'version':m.get('version'),'sum':m.get('sum'),'status':m.get('status'),'licenses':sorted((f['file'],f['sha256']) for f in m['license_files'])} for m in i['modules']}
a,b=modident(oldinv),modident(newinv)
filesold=oldv['manifest']['files'];filesnew=v['manifest']['files']
# SDK manifests contain SHA256 values, and do not include themselves in this map.
(W/'sdk-delta.json').write_text(json.dumps({'baseline_sdk_sha256':oldhash,'candidate_sdk_sha256':sha(sdkarchive),'baseline_source':oldv['manifest']['source'],'candidate_source':v['manifest']['source'],'module_counts':[len(a),len(b)],'modules_added':sorted(b.keys()-a.keys()),'modules_removed':sorted(a.keys()-b.keys()),'modules_changed':{n:{'before':a[n],'after':b[n]} for n in a.keys()&b.keys() if a[n]!=b[n]},'source_files_added':sorted(filesnew.keys()-filesold.keys()),'source_files_removed':sorted(filesold.keys()-filesnew.keys()),'source_files_changed':sorted(n for n in filesold.keys()&filesnew.keys() if filesold[n]!=filesnew[n]),'native_archive_unchanged':True,'native_notice_tree_unchanged':all(filesold.get(n)==h for n,h in filesnew.items() if n.startswith('release/native-components/wgpu-darwin-arm64/'))},indent=2,sort_keys=True)+'\n')
oldnotices=X.parent/'macos-preview-release/alpha3-final-notices';assert sha(oldnotices/'INVENTORY.json')==audit['notice_inventory_sha256'];approved_notices=json.loads((oldnotices/'INVENTORY.json').read_text());app_notices.load(oldnotices,audit['app_source_binary_sha256'])
run('icons',['go','run','-mod=readonly','./cmd/artwork','-output',W/'icons'],sdk/'examples/showcase')
GOROOT=Path(run('go-root',['go','env','GOROOT'],sdk).strip())
appconfigs=[('notes','Vellum Notes','com.dshills.vellum.notes.personal','examples/macapps','./cmd/notes'),('widgets','Vellum Mac Widgets','com.dshills.vellum.widgets.v1','drivers/cogent','./cmd/gallery'),('shell','Vellum Mac Shell','com.dshills.vellum.macshell.v1','examples/macapps','./cmd/macshell'),('forma','Forma','com.dshills.vellum.showcase.forma','examples/showcase','./cmd/forma'),('luma','Luma','com.dshills.vellum.showcase.luma','examples/showcase','./cmd/luma'),('pulse','Pulse','com.dshills.vellum.showcase.pulse','examples/showcase','./cmd/pulse')]
apps=[]; baseline_assets={}
for slug,name,bundle,rel,target in appconfigs:
 ad=W/slug;ad.mkdir();cwd=sdk/rel
 graph=checker.decode_objects(run(slug+'-graph',['go','list','-mod=readonly','-deps','-json',target],cwd))
 mods=checker.decode_objects(run(slug+'-origins',['go','list','-mod=readonly','-m','-json','all'],cwd));origins=checker.check_origin(mods,sdk,v['manifest']['release']['module'],v['manifest']['native_gpu'])
 roots={p['Module']['Path']:Path(p['Module'].get('Replace',p['Module'])['Dir']).resolve() for p in graph if not p.get('Standard')}
 notice_by={m['module']:m for m in newinv['modules']}; build=collector.package_inventory(graph,roots,notice_by); std=collector.standard_library_inventory(graph,GOROOT)
 (ad/'build-inputs.json').write_text(json.dumps({'modules':sorted(roots),'standard':std,**build},indent=2)+'\n')
 baserel=old/rel
 if baserel.is_dir():
  oldgraph=checker.decode_objects(run(slug+'-baseline-graph',['go','list','-mod=readonly','-deps','-json',target],baserel))
 else:oldgraph=checker.decode_objects(run(slug+'-baseline-graph',['go','list','-mod=readonly','-deps','-json','.'],old/'examples/placement'))
 oldassets={ (p['Module']['Path'],str(Path(p['Dir']).relative_to(Path(p['Module'].get('Replace',p['Module'])['Dir']))/f)):sha(Path(p['Dir'])/f) for p in oldgraph if not p.get('Standard') for f in p.get('EmbedFiles',[])}
 assets={(a['module'],a['file']):a['sha256'] for a in build['embedded_assets']}
 delta={'comparison':'same example target' if baserel.is_dir() else 'new app; approved Placement reference only','selected_embeds':len(assets),'reference_embeds':len(oldassets),'added':[{'module':k[0],'file':k[1],'sha256':assets[k]} for k in sorted(assets.keys()-oldassets.keys())],'changed':[{'module':k[0],'file':k[1],'before':oldassets[k],'after':assets[k]} for k in sorted(assets.keys()&oldassets.keys()) if assets[k]!=oldassets[k]],'not_selected_from_reference':len(oldassets.keys()-assets.keys())}
 binary=ad/name;linkmap=ad/'native.map';run(slug+'-build',['go','build','-mod=readonly','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',binary,target],cwd)
 observation=collector.native_link_observation(binary,linkmap,roots,build);(ad/'link-observation.json').write_text(json.dumps(observation,indent=2)+'\n');assert str(sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a').encode() in linkmap.read_bytes()
 notices=ad/'notices';shutil.copytree(oldnotices,notices);ni=json.loads((notices/'INVENTORY.json').read_text());byhash={q['sha256']:n for n,q in ni['files'].items()}; additions=[]
 def declare(cid,entries):
  names=[]
  for path in entries:
   body=path.read_bytes();h=hashlib.sha256(body).hexdigest()
   if h not in byhash:
    nn='NOTICES/'+h+'-'+path.name;app_notices.notice_name(nn);(notices/nn).write_bytes(body);ni['files'][nn]={'bytes':len(body),'sha256':h};byhash[h]=nn;additions.append({'file':nn,'sha256':h,'component':cid})
   names.append(byhash[h])
  if names and not any(c['id']==cid for c in ni['components']):ni['components'].append({'id':cid,'notice_files':sorted(set(names))})
 for m in newinv['modules']:
  declare('current-go:'+m['module'],[sdk/(f['sdk_file'] if 'sdk_file' in f else 'THIRD_PARTY_NOTICES/'+f['notice']) for f in m['license_files']])
 for mn,root in roots.items():
  if root.is_relative_to(sdk) and (root/'LICENSE').is_file():declare('current-owned:'+mn,[root/'LICENSE'])
 declare('current-go-standard:go1.25.6',[GOROOT/f['file'] for f in std['declaration_candidates']])
 ni['artifact_sha256']=sha(binary);ni['scope']='Private delta-audit candidate: conservative original alpha.3 notice superset plus current effective Go graph, owned module and selected standard-library declarations. New executable binding; no distribution or rights approval implied.'
 (notices/'INVENTORY.json').write_text(json.dumps(ni,indent=2,sort_keys=True)+'\n');nr,_=app_notices.load(notices,sha(binary))
 bundlepath=ad/(name+'.app');args=[sys.executable,'-B',R/'scripts/package-app.py','--binary',binary,'--output',bundlepath,'--name',name,'--identifier',bundle,'--version','1.0.0','--build-version','10','--notice-bundle',notices,'--sign-identity','-']
 if slug in {'forma','luma','pulse'}:args.extend(['--icon',W/'icons'/(slug+'.png')])
 run(slug+'-package',args)
 archive=W/(name+'.zip');run(slug+'-zip',['ditto','-c','-k','--norsrc','--noextattr','--keepParent',bundlepath,archive]);ex=ad/'exact';ex.mkdir();run(slug+'-extract',['ditto','-x','-k',archive,ex]);run(slug+'-signature',['codesign','--verify','--deep','--strict',ex/bundlepath.name])
 apps.append({'id':slug,'name':name,'identifier':bundle,'archive':archive.name,'archive_sha256':sha(archive),'source_binary_sha256':sha(binary),'packaged_binary_sha256':sha(ex/bundlepath.name/'Contents/MacOS'/name),'notice_inventory_sha256':sha(notices/'INVENTORY.json'),'notice_files':len(ni['files']),'notice_components':len(ni['components']),'added_notice_files':additions,'selected_assets_delta':delta,'module_origins':origins,'native_archive_sha256':audit['native_archive_sha256'],'link_observation_sha256':sha(ad/'link-observation.json'),'build_inputs_sha256':sha(ad/'build-inputs.json'),'extracted_signature':'pass','runtime_executed':False})
 (W/'apps.json').write_text(json.dumps(apps,indent=2)+'\n')
# Independent generated consumer; no window is launched.
run('starter-generate',[sys.executable,'-B',sdk/'scripts/new-app.py',W/'starter','--module','example.com/vellum-distribution-audit'])
run('starter-test',['go','test','-race','./...'],W/'starter');run('starter-build',['go','build','-mod=readonly','-o',W/'starter-binary','.'],W/'starter')
for n,h in filesnew.items():assert sha(sdk/n)==h,n
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
result={'source_commit':head,'sdk_archive':sdkarchive.name,'sdk_sha256':sha(sdkarchive),'baseline_sdk_sha256':oldhash,'baseline_audit_record_sha256':sha(R/'release/macos-preview-audit.json'),'native_archive_sha256':audit['native_archive_sha256'],'private':True,'distribution_audit':'pending','publication_authorized':False,'runtime_executed':False,'apps':apps,'checks':checks}
(W/'packet.json').write_text(json.dumps(result,indent=2)+'\n');(W/'SHA256SUMS').write_text(sha(sdkarchive)+'  '+sdkarchive.name+'\n'+''.join(a['archive_sha256']+'  '+a['archive']+'\n' for a in apps))
print(json.dumps({'complete':True,'work':str(W),'apps':len(apps),'source':head}),flush=True)
