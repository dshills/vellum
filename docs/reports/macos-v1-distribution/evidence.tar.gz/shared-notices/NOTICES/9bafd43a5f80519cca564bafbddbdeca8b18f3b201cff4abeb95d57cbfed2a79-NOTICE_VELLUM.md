# Core icon provenance and Vellum changes

The bundled 4105 embedded SVGs are mapped individually in NOTICE.origins (JSON). Source URLs, exact revisions, prepared SHA256s, alias filenames and modification records make the mapping independently checkable against the shipped SVGs. The ledger is supplemental provenance, not a module-license replacement or legal approval.

4085 Material SVGs match exact bytes in the indicated marella/material-symbols revisions; 5 retain the following existing Core artwork changes and now carry prominent per-file XML modification notices. Material Symbols are attributed to Google through the upstream Material Symbols distribution, under Apache 2.0. The full existing LICENSE_APACHE remains unchanged. Upstream Apache declaration blob d645695673349e3947e8e5ae42332d0ac3164cd7 differs from Core's full text only by trailing newline count.

Existing artwork modifications (stage 0099 adds only per-file XML change notices to these five SVGs):
- check_box_outline_blank.svg: Core added one trailing LF byte.
- toggle_off-fill.svg: Core changed viewBox from `0 -960 960 960` to `0 -790 960 620`.
- toggle_off.svg: same viewBox change.
- toggle_on-fill.svg: same viewBox change.
- toggle_on.svg: same viewBox change.

Vellum prepends a modification comment to each of the five files. Removing that exact prefix restores the byte-identical preceding Core SVG, including all viewBox, path data and trailing LF bytes. The ledger records original/prepared SHA256s, the notice prefix hash, and the separate Core/Vellum transformation steps. These five drawings remain Apache-2.0; the MIT declaration below applies only to the 13 new neutral drawings.

The viewBox changes are recorded in Core revisions 21b2d0cf0badd9334e01a306347fe683bfe5e084 and 1519a946f55240ae11b0009f5cc87d1aeb8d308b. The ledger binds each to its exact upstream path/blob and current file hash.

blank.svg is Core's pre-import empty placeholder (00ab66221bf1ab445860f4b4bbeaa9fff32a0e16); cogent-core.svg is its own project logo (9b0a943c5b89f482ccebe261e7932f9ee292e330). These retain the Core project BSD declaration in the unchanged root LICENSE. This does not grant trademark permission.

Vellum stage 0099 replaces 13 unresolved source-chain assets with original neutral geometric pictograms: file-exe.svg, file-markdown.svg, git-hub.svg, git.svg, go.svg, json.svg, latex.svg, make.svg, makefile.svg, radio_button_partial.svg, tex.svg, toggle_mid.svg, toml.svg. Copyright (c) 2026 Davin Hills. These new drawings only are MIT licensed; see LICENSE_VELLUM.txt. No upstream SVG path data, protected wordmarks, logos, fonts or external resources were copied into the replacements. Git/GitHub/Go filenames now denote generic branch/repository/concurrency pictograms, not vendor brand appearance. RadioButtonPartial remains half selected, ToggleMid centered, and the two historical file aliases remain identical. Public exports and file identities are retained; visual identity intentionally changes.

The unresolved old artwork is replaced, not relicensed. No supplier MIT declaration is used to infer permission for the old Git logo. Neither this notice nor the ledger approves all distribution rights, unrelated assets, native runtime behavior, physical UI appearance, or full Mac/M6 completion.
