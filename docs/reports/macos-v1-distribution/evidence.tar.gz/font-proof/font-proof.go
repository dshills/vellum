package main
import("crypto/sha256";"encoding/json";"fmt";"golang.org/x/image/font/gofont/goregular";"golang.org/x/image/font/gofont/gobold")
func main(){ b,_:=json.Marshal(map[string]string{"Go-Regular.ttf":fmt.Sprintf("%x",sha256.Sum256(goregular.TTF)),"Go-Bold.ttf":fmt.Sprintf("%x",sha256.Sum256(gobold.TTF))});fmt.Println(string(b)) }
