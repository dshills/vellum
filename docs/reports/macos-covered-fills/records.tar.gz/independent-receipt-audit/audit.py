"""Independent receipt/statistics audit; stdlib only, no repository imports.
Only reads frozen records/source/prepared bytes and writes review artifacts.
Never executes a producer, test, build, Git, provider, or native/UI program.
"""
import hashlib
import json
import math
import re
import statistics
from pathlib import Path

ROOT = Path('/private/tmp/vellum-large-data')
Q = Path('/private/tmp/vellum-raster-coverage')
OUT = Path(__file__).parent
REPORT = ROOT / 'docs/reports/macos-covered-fills/README.md'
METRICS = {'ui_work_ns': 'TotalUIWorkNS', 'input_ns': 'InputNS',
           'owner_ns': 'OwnerNS', 'reconcile_ns': 'ReconcileNS',
           'layout_paint_ns': 'LayoutPaintNS', 'gather_ns': 'GatherNS',
           'raster_upload_ns': 'RasterUploadNS', 'encode_submit_ns': 'EncodeSubmitNS',
           'queued_ns': 'QueuedNS', 'acquire_ns': 'AcquireNS',
           'present_call_ns': 'PresentCallNS'}
WORK = ('input_ns', 'owner_ns', 'reconcile_ns', 'layout_paint_ns',
        'gather_ns', 'raster_upload_ns', 'encode_submit_ns')
FILES = {}


def data(path):
    path = Path(path)
    value = path.read_bytes()
    FILES[str(path)] = hashlib.sha256(value).hexdigest()
    return value


def text(path):
    return data(path).decode()


def record(path):
    return json.loads(data(path))


def sha(path):
    return hashlib.sha256(data(path)).hexdigest()


def map_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def distribution(values):
    ordered = sorted(values)
    assert ordered and all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in ordered)
    mean = statistics.mean(ordered)
    sd = statistics.stdev(ordered) if len(ordered) > 1 else 0.0
    return {'count': len(ordered), 'p50': ordered[math.ceil(.5 * len(ordered)) - 1],
            'p95': ordered[math.ceil(.95 * len(ordered)) - 1],
            'p99': ordered[math.ceil(.99 * len(ordered)) - 1],
            'max': ordered[-1], 'min': ordered[0], 'mean': mean,
            'sample_stddev': sd, 'coefficient_of_variation': sd / mean if mean else 0.0}


def summarize(runs):
    all_metrics = {}
    for metric in METRICS:
        per_run = [distribution([s['metrics'][metric] for s in samples]) for samples in runs]
        all_metrics[metric] = {
            'pooled': distribution([s['metrics'][metric] for samples in runs for s in samples]),
            'per_run': per_run,
            'run_p95_variation': distribution([v['p95'] for v in per_run]),
        }
    return all_metrics


def raw_records(path):
    records = []
    for line in text(path).splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict) and str(value.get('event', '')).startswith('grid.perf.'):
            records.append(value)
    return records


def validate_run(result, rows, variable):
    records = result['records']
    assert len(records) == 123 and [r['event'] for r in records[:2]] == ['grid.perf.setup', 'grid.perf.ready']
    assert records[-1]['event'] == 'grid.perf.end'
    setup, ready, end = records[0], records[1], records[-1]
    for r in records:
        assert r['warmup_guard'] == 1 and type(r['warmup_guard']) is int
        assert r['input_details'] is False and r['source_details'] is False
        if 'cpu_profile' in r:
            assert r['cpu_profile'] is False
    for r in (setup, ready, end):
        assert r['rows'] == rows and r['variable'] is variable and r['novel'] is False
    assert setup['release'] is True and setup['stored_value_bytes'] == rows * 20 * 8 and setup['seed'] == 7
    assert setup['requested_font_family'] == 'Noto Sans'
    assert setup['projection_stats']['InputRows'] == setup['projection_stats']['Rows'] == rows
    assert len(setup['embedded_regular_font_sha256']) == 64
    assert ready['warmup'] == ready['warm_callbacks'] == 128
    assert ready['warm_start_viewport'] == ready['warm_end_viewport']
    assert ready['warm_start_viewport']['ScrollX'] == ready['warm_start_viewport']['ScrollY'] == 0
    assert ready['warm_end_generation'] == ready['warm_start_generation'] + 128
    assert ready['warm_start_generation'] == 2
    assert end['samples'] == end['callbacks'] == 120 and end['pending'] == end['dropped'] == 0
    assert end['presentation_timestamps'] == end['native_gpu_memory'] == 'unavailable'
    assert result['process_observation_scope']['stages'] == ['grid.perf.end']
    for k in ('baseline_rss', 'warm_rss', 'cpu_delta'):
        assert result['process_observation_scope'][k] == 'unavailable'
    assert all(v['event'] == 'grid.perf.end' for v in result['process_observations'])
    samples = records[2:-1]
    last_frame = 0
    for index, sample in enumerate(samples):
        assert sample['event'] == 'grid.perf.sample'
        assert sample['index'] == index and sample['tag'] == index + 1
        assert sample['callbacks'] == 1 and sample['generation'] == ready['warm_end_generation'] + index + 1
        assert type(sample['frame']) is int and sample['frame'] > last_frame
        last_frame = sample['frame']
        geo = sample['geometry']
        assert geo['cells'] >= 400 and geo['rows'] >= 50 and geo['columns'] >= 8
        assert geo['cells'] <= geo['materialized_cells'] <= geo['retained_cells'] <= 4096
        assert 0 <= geo['retained_headers'] <= 64
        assert geo['scale'] == 1.6875
        assert re.fullmatch('[0-9a-f]{64}', geo['layout_sha256'])
        assert geo['bounds'] == ready['initial_geometry']
        assert geo['viewport']['Width'] == ready['warm_end_viewport']['Width']
        assert geo['viewport']['Height'] == ready['warm_end_viewport']['Height']
        # The declared closed 64-step pattern: 32 positive then32 negativeY, Xchanges every8steps.
        phase = index % 64
        expected_y = 12 * (phase + 1) if phase < 32 else 12 * (63 - phase)
        expected_x = 96 * ((phase + 1) // 8) if phase < 32 else 96 * (4 - ((phase - 31) // 8))
        assert (geo['viewport']['ScrollX'], geo['viewport']['ScrollY']) == (expected_x, expected_y)
        native = sample['native_sample']
        assert native['Tag'] == sample['tag'] and native['Generation'] == sample['generation']
        assert native['Window'] == 'perf' and native['Completed'] is True and native['Failure'] == ''
        assert native.get('SourceDetails') is None
        for metric, key in METRICS.items():
            value = sample['metrics'][metric]
            assert type(value) is int and 0 <= value <= (1 << 63) - 1 and native[key] == value
        assert sample['metrics']['ui_work_ns'] == sum(sample['metrics'][k] for k in WORK)
        assert all(type(v) is int and v >= 0 for v in sample['source_callbacks'].values())
        assert sample['source_callbacks']['Cells'] <= 4096
    return samples


def main():
    phases = ('checks-v3', 'negative', 'microbenchmark', 'widget-pixels', 'native-v2', 'performance')
    proofs = {phase: record(Q / phase / 'qualification.json') for phase in phases}
    state = proofs['checks-v3']['before']
    assert len(state['source']) == 651 and len(state['prepared']) == 6140
    for phase, proof in proofs.items():
        assert proof['before'] == proof['after'] == state, phase
        assert proof['producer_sha256'] == sha(Q / phase / 'producer.py.txt'), phase
        if 'helper_sha256' in proof:
            assert proof['helper_sha256'] == sha('/private/tmp/vellum-grid-publication-qualify.py')
    assert proofs['widget-pixels']['result'] == 'PASS_EXACT_WIDGET_RGBA_PARITY'
    assert proofs['performance']['result'] == 'PASS_MATCHED_COMPARISON'
    assert all(proofs[p]['result'] == 'PASS' for p in ('checks-v3', 'negative', 'microbenchmark', 'native-v2'))

    # Verify current selected-source and complete prepared byte maps without using Git/prepare.
    for path, expected in state['source'].items():
        assert sha(ROOT / path) == expected, path
    actual_prepared = {str(p.relative_to(ROOT)): sha(p)
                       for name in ('upstream', 'typesetting')
                       for p in sorted((ROOT / 'drivers/cogent/build' / name).rglob('*')) if p.is_file()}
    assert actual_prepared == state['prepared']
    # Keep large maps in the existing proof rather than duplicating every unchanged file in this review.
    for path in list(FILES):
        if path.startswith(str(ROOT / 'drivers/cogent/build') + '/') or path in {str(ROOT / p) for p in state['source']}:
            del FILES[path]
    prior = record('/private/tmp/vellum-grid-input-final/performance/qualification.json')['after']['prepared']
    difference = {p: ('ADDED' if p not in prior else 'REMOVED' if p not in actual_prepared else 'CHANGED')
                  for p in prior.keys() | actual_prepared.keys() if prior.get(p) != actual_prepared.get(p)}
    assert difference == {
        'drivers/cogent/build/upstream/paint/renderers/rasterx/renderer.go': 'CHANGED',
        'drivers/cogent/build/upstream/paint/renderers/rasterx/covered_draw_test.go': 'ADDED'}

    checks = proofs['checks-v3']['checks']
    assert len(checks) == 12
    for phase in ('checks-v3', 'negative', 'microbenchmark', 'widget-pixels', 'native-v2'):
        for check in proofs[phase]['checks']:
            assert check['error'] is None
            assert check['exit_code'] == (1 if phase == 'negative' else 0)
            assert check['log_sha256'] == sha(Q / phase / (check['name'] + '.log'))
    note = record(Q / 'checks-v3/producer-provenance-note.json')
    assert 'end-state copy' in note['scope'] and 'not a byte-identity claim' in note['scope']
    coverage = text(Q / 'checks-v3/coverage.out')
    assert re.search(r'renderer\.go:74\.6,74\.14 1 1254$', coverage, re.M)
    declared = re.findall(r'^func (TestCoveredUniformDraw\w+)\(', text(ROOT / 'drivers/cogent/build/upstream/paint/renderers/rasterx/covered_draw_test.go'), re.M)
    newlog = text(Q / 'checks-v3/covered-race3.log')
    assert declared and all(len(re.findall(r'^--- PASS: ' + re.escape(name) + r' ', newlog, re.M)) == 3 for name in declared)
    generated = next(r for r in checks if r['name'] == 'raster-scan-race')['generated_images']
    assert len(generated) == 17
    for path, expected in generated.items():
        assert not (ROOT / path).exists()
        assert sha(Q / 'checks-v3/generated-pixels' / Path(path).name) == expected

    baseline = Q / 'baseline-source/renderer.go.txt'
    original_hashes = record(ROOT / 'drivers/cogent/native/patches/coveredfills/original-hashes.json')
    stage37 = record(ROOT / 'drivers/cogent/native/patches/rowtracking/output-hashes.json')
    assert sha(baseline) == stage37['paint/renderers/rasterx/renderer.go'] == original_hashes['paint/renderers/rasterx/renderer.go']
    native = proofs['native-v2']
    for phase in ('native-v2', 'widget-pixels'):
        identity = proofs[phase]['baseline_identity']
        overlay = Q / phase / 'baseline-overlay.json'
        assert identity == {'renderer_sha256': sha(baseline), 'overlay_sha256': sha(overlay)}
        assert record(overlay) == {'Replace': {str(ROOT / 'drivers/cogent/build/upstream/paint/renderers/rasterx/renderer.go'): str(baseline)}}
    assert record(Q / 'native-v2/baseline-identity-before.json') == native['baseline_identity']
    for check in proofs['negative']['checks']:
        assert check['meaningful_pixel_or_call_assertion_failure'] is True
        log = text(Q / 'negative' / (check['name'] + '.log'))
        assert '--- FAIL: TestCoveredUniformDraw' in log and '[build failed]' not in log and 'panic:' not in log
        assert 'optimized replay differs from original pixels' in log or 'custom clear color original calls lost' in log
        overlay = record(Q / 'negative' / (check['name'] + '-overlay.json'))
        assert list(overlay['Replace']) == [str(ROOT / 'drivers/cogent/build/upstream/paint/renderers/rasterx/renderer.go')]
        sha(Path(next(iter(overlay['Replace'].values()))))

    bench = re.findall(r'^BenchmarkCoveredUniformDraw/(false|true)-\d+\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',
                       text(Q / 'microbenchmark/draw-bench.log'), re.M)
    assert len(bench) == 10 and all(int(bytes_) == int(allocs) == 0 for _, _, bytes_, allocs in bench)
    bench_values = {name: [int(ns) for kind, ns, _, _ in bench if kind == name] for name in ('false', 'true')}
    assert all(len(v) == 5 for v in bench_values.values())
    medians = {name: statistics.median(v) for name, v in bench_values.items()}
    assert medians == {'false': 129916, 'true': 73617}
    cpu_reduction = 100 * (1 - medians['true'] / medians['false'])
    pixels = {name: re.findall(r'GRID_UPDATE_RGBA .*', text(Q / 'widget-pixels' / (name + '.log'))) for name in ('baseline', 'candidate')}
    assert len(pixels['baseline']) == 8 and pixels['baseline'] == pixels['candidate'] == proofs['widget-pixels']['frames']

    assert len(native['checks']) == 4
    for name, rows in (('fixed-10k-ax', 10000), ('variable-million-ax', 1000000)):
        events = [json.loads(line) for line in text(Q / 'native-v2' / (name + '.log')).splitlines() if line.startswith('{')]
        assert [r['event'] for r in events] == ['grid.accessibility.pass', 'grid.accessibility.closed']
        accepted, closed = events
        assert accepted['rows'] == rows and accepted['visible_minimum'] == 400 and accepted['native_press_admitted'] is True
        assert accepted['overlap_objects_reused'] > 0 and accepted['replacement_objects_retired'] > 0
        assert closed['attachment_query_refused'] is True
    historical = record(Q / 'native/owned-sandbox-smoke-retirement.json')
    progress = record(Q / 'native/progress.json')
    assert historical['pid'] == 8581 and historical['signal'] == 'SIGTERM'
    assert historical['observed_argv'] == '/private/tmp/vellum-covered-fill-candidate -accessibility-smoke -rows=10000'
    assert progress[-1]['name'] == 'fixed-10k-ax' and progress[-1]['exit_code'] == -15
    assert not (Q / 'native/qualification.json').exists()
    for child in progress:
        assert child['log_sha256'] == sha(Q / 'native' / (child['name'] + '.log'))

    perf = proofs['performance']
    assert perf['baseline_identity'] == native['baseline_identity']
    assert perf['samples'] == 4800 and perf['builds'] == 2 and perf['runs_per_case_build'] == 5
    assert perf['samples_per_run'] == 120 and perf['warmup'] == 128
    assert perf['warm_targets_ns'] == {'p95': 4000000, 'p99': 6000000}
    assert perf['benchmark_sha256'] == sha(ROOT / 'scripts/benchmark-grid.py')
    for build in ('baseline', 'candidate'):
        assert perf['binaries'][build] == native['binaries']['vellum-covered-fill-' + build] == sha(Path('/private/tmp/vellum-covered-fill-' + build))
    expected_order = []
    cases = ['fixed-10000', 'fixed-1000000', 'variable-10000', 'variable-1000000']
    for case in cases:
        for repetition in range(1, 6):
            for build in (('baseline', 'candidate') if repetition % 2 else ('candidate', 'baseline')):
                expected_order.append((build, case, repetition))
    assert [(r['build'], r['case'], r['repetition']) for r in perf['runs']] == expected_order
    summary = record(Q / 'performance/summary.json')
    assert sha(Q / 'performance/summary.json') == perf['summary_sha256']
    all_runs = {build: {case: [] for case in cases} for build in ('baseline', 'candidate')}
    settings = fonts = None
    targets_failed = 0
    for declared_run in perf['runs']:
        build, case, repetition = declared_run['build'], declared_run['case'], declared_run['repetition']
        folder = Q / 'performance' / build / case / ('run-' + str(repetition))
        result = record(folder / 'result.json')
        assert sha(folder / 'result.json') == declared_run['outcome_sha256']
        assert result['result'] == 'PASS' and result['error'] is None and result['exit_code'] == 0
        assert result['log_sha256'] == sha(folder / 'native.log')
        assert raw_records(folder / 'native.log') == result['records']
        variable = case.startswith('variable')
        rows = int(case.split('-')[1])
        assert result['argv'] == [str(Path('/private/tmp/vellum-covered-fill-' + build)), '-perf',
                                  '-rows=' + str(rows), '-perf-samples=120', '-perf-warmup=128'] + (['-variable-rows'] if variable else [])
        samples = validate_run(result, rows, variable)
        if settings is None:
            settings, fonts = result['records'][0]['build_settings'], result['records'][0]['embedded_regular_font_sha256']
        assert settings == result['records'][0]['build_settings'] and fonts == result['records'][0]['embedded_regular_font_sha256']
        all_runs[build][case].append(samples)
        stats = distribution([s['metrics']['ui_work_ns'] for s in samples])
        assert stats['p95'] > 4000000 and stats['p99'] > 6000000
        targets_failed += 1
    recalculated = {build: {case: {'timings_ns': summarize(runs)} for case, runs in cases_.items()}
                    for build, cases_ in all_runs.items()}
    assert recalculated == summary
    assert perf['warm_target_met'] == {'baseline': False, 'candidate': False}
    assert targets_failed == 40
    geometry_pairs = 0
    for case in cases:
        for before, after in zip(all_runs['baseline'][case], all_runs['candidate'][case]):
            for a, b in zip(before, after):
                assert a['geometry'] == b['geometry']
                geometry_pairs += 1
    for build in ('baseline', 'candidate'):
        for height in ('fixed', 'variable'):
            for small, large in zip(all_runs[build][height + '-10000'], all_runs[build][height + '-1000000']):
                for a, b in zip(small, large):
                    assert a['geometry'] == b['geometry']
                    geometry_pairs += 1
    assert geometry_pairs == 4800

    report = text(REPORT)
    implementation = text(ROOT / 'docs/implementation.md')
    rows = re.findall(r'^\| (fixed-\d+|variable-\d+) \| (baseline|candidate) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|$', report, re.M)
    assert len(rows) == 8
    for case, build, *displayed in rows:
        pooled = recalculated[build][case]['timings_ns']['ui_work_ns']['pooled']
        assert displayed == [format(pooled[key] / 1e6, '.3f') for key in ('p50', 'p95', 'p99', 'max')]
    reductions = {case: 100 * (1 - recalculated['candidate'][case]['timings_ns']['ui_work_ns']['pooled']['p95'] /
                                 recalculated['baseline'][case]['timings_ns']['ui_work_ns']['pooled']['p95']) for case in cases}
    assert format(min(reductions.values()), '.1f') == '6.0' and format(max(reductions.values()), '.1f') == '6.7'
    assert format(cpu_reduction, '.1f') == '43.3'
    assert '129.916 to 73.617' in report and '1,254' in report and 'zero allocations' in report
    assert '40 of 40' in report and '6.0–6.7%' in report and '4,800 samples' in report
    assert '40 of 40' in implementation and '6.0–6.7%' in implementation and '43.3%' in implementation
    assert 'do not establish a complete' in report and 'Mac/P6 completion remains open' in report
    for build in ('baseline', 'candidate'):
        assert perf['binaries'][build] in report
    correction_root = Q / 'post-prism-correction'
    correction = record(correction_root / 'correction.json')
    assert correction['old_text'] == '5.9–6.7%' and correction['new_text'] == '6.0–6.7%'
    assert set(correction['files']) == {'docs/implementation.md', 'docs/reports/macos-covered-fills/README.md'}
    for path, change in correction['files'].items():
        before_copy, after_copy = correction_root / change['before_copy'], correction_root / change['after_copy']
        old, new = text(before_copy), text(after_copy)
        assert sha(before_copy) == change['before_sha256']
        assert sha(after_copy) == sha(ROOT / path) == change['after_sha256']
        assert old.count(correction['old_text']) == 1
        assert old.replace(correction['old_text'], correction['new_text'], 1) == new
    for path, value in list(FILES.items()):
        assert sha(path) == value, path
    final_recipe_sha = sha(Path(__file__))
    proof_sha = {p: FILES[str(Q / p / 'qualification.json')] for p in phases}
    # Review records and binaries may be large; maps are recorded by hash/count, not duplicated as closure.
    binary_hashes = dict(perf['binaries'])
    for p in ('/private/tmp/vellum-covered-fill-baseline', '/private/tmp/vellum-covered-fill-candidate'):
        del FILES[p]
    certificate = {
        'schema': 1, 'decision': 'APPROVED_RECEIPTS', 'findings': [],
        'reviewed_file_sha256': FILES,
        'qualification_sha256': proof_sha,
        'source_prepared_linkage': {'selected_source_count': 651, 'prepared_file_count': 6140,
                                   'all_phase_endpoint_maps_equal': True,
                                   'current_sources_and_complete_prepared_set_rehashed': True,
                                   'source_map_sha256': map_sha(state['source']),
                                   'prepared_map_sha256': map_sha(state['prepared']),
                                   'stage37_to_stage38_prepared_difference': difference},
        'baseline_identity': native['baseline_identity'], 'binary_sha256': binary_hashes,
        'checks': {'passing_children': 12, 'new_top_level_groups': len(declared), 'repetitions': 3,
                   'covered_elision_branch_executions': 1254, 'generated_pngs_retained_then_removed': 17,
                   'negative_actual_assertion_failures': 3, 'native_passing_children': 4,
                   'native_cocoa_400cell_pass_and_closed_processes': 2,
                   'matched_software_rgba_frames': 8},
        'microbenchmark': {'raw_ns_per_op': bench_values, 'medians_ns': medians,
                           'elapsed_work_reduction_percent': cpu_reduction,
                           'allocations_all_observations': 0},
        'performance': {'processes': 40, 'samples': 4800, 'samples_per_run': 120,
                        'warmup_callbacks': 128, 'all_diagnostic_modes_off': True,
                        'closed_warmups_all': True, 'full_geometry_equal_pairs': geometry_pairs,
                        'all_11_metric_distributions_recomputed': True,
                        'per_run_and_pooled_statistics_exact': True,
                        'pooled_ui_work_ns': {build: {case: value['timings_ns']['ui_work_ns']['pooled']
                                                   for case, value in cases_.items()} for build, cases_ in recalculated.items()},
                        'pooled_p95_reduction_percent': reductions,
                        'warm_targets_ns': perf['warm_targets_ns'], 'processes_failing_both_targets': 40,
                        'target_met': {'baseline': False, 'candidate': False}},
        'historical_attempt': {'scope': 'Initial sandbox native attempt remains unqualified; preserved exit -15 and PID/argv guarded SIGTERM record. No native qualification exists for that directory.',
                               'pid': historical['pid'], 'exit_code': progress[-1]['exit_code']},
        'resolved_findings': [{'id': 'pooled-p95-reduction-range-rounding',
                               'resolution': 'Exact minimum 5.950755792986239% rounds to 6.0% at one decimal. Both prose leaves contain the one-replacement correction; timing tables and all runtime/tests/measurements are unchanged.',
                               'post_provider_correction_sha256': FILES[str(correction_root / 'correction.json')],
                               'corrected_documents_reviewed_internally': True}],
        'scope': 'Independent read-only receipt/log/result/statistics/geometry and current byte linkage audit. Report numeric statements agree with retained raw measurements. No source/report modifications or workload reruns.',
        'limits': [
            'Provider review is a separate gate; its raw result is not evaluated or certified here. This review internally covers the two post-provider numerical prose replacements and exact retained pre/post bytes.',
            'checks-v3 producer.py.txt is explicitly an end-state copy after inactive native-branch edits, not byte-exact loaded Python identity; the recorded 12 command/cwd/exit/log and selected/prepared endpoints remain authoritative.',
            'Selected source and complete prepared byte sets are not the full compiler/module-cache/system SDK/ambient runtime closure.',
            'Native measurements are elapsed same-ticket UI work, not OS thread CPU or physical GPU/compositor presentation; process observations are end-only and do not attribute native/GPU memory.',
            'Both targets remain unmet in all 40 processes. Isolated CPU gain and host/workload p95 comparison do not qualify complete P6/Mac acceptance, endurance, professional human workflows, or native/GPU memory.',
            'Future final archive/audit/report-link closure is outside this receipt approval.',
        ],
        'recipe_sha256': final_recipe_sha,
    }
    (OUT / 'recomputed-statistics.json').write_text(json.dumps(recalculated, indent=2, sort_keys=True) + '\n')
    target = Q / 'internal-receipt-review.json'
    target.write_text(json.dumps(certificate, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'decision': certificate['decision'], 'certificate': str(target),
                      'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'files': len(FILES), 'processes': 40, 'samples': 4800,
                      'reduction_percent': reductions}, sort_keys=True))


if __name__ == '__main__':
    main()
