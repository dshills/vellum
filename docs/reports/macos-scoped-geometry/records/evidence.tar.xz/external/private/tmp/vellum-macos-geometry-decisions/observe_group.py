from pathlib import Path
import datetime,hashlib,json,subprocess
P=Path('/private/tmp/vellum-macos-geometry-decisions');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
t=json.loads((P/'profile-controller.json').read_text());o=json.loads((P/'profile-controller.owned-process.json').read_text());assert t['exit_code']==0 and t['error']is None and o['pid']==o['process_group']and o['argv']==t['argv']and o['started_utc']==t['started_utc']and o['queue_producer_sha256']==t['queue_producer_sha256']==sha(P/'profile.py')and t['producer_sha256']==sha(P/'launch.py')
r=subprocess.run(['ps','-axo','pid=,pgid=,comm='],capture_output=True,text=True,check=True,timeout=5)
members=[]
for line in r.stdout.splitlines():
 fields=line.split(None,2)
 if len(fields)>=2 and int(fields[1])==o['process_group']:members.append(line.strip())
q={'result':'PASS_RECORDED_GROUP_ABSENT'if not members else'FAIL_RECORDED_GROUP_PRESENT','group':o['process_group'],'members':members,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_sha256':sha(P/'profile-controller.json'),'owned_sha256':sha(P/'profile-controller.owned-process.json'),'producer_sha256':sha(__file__),'scope':'Exact recorded process-group absence at this observation; not native/GPU-resource inventory or broader descendant proof.'};(P/'post-terminal-group.json').write_text(json.dumps(q,indent=2)+'\n');print(q['result']);assert not members
