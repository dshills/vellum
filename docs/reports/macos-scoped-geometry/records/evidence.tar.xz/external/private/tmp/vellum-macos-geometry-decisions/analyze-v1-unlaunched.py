from pathlib import Path
import collections,hashlib,json
P=Path('/private/tmp/vellum-macos-geometry-decisions');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
terminal=json.loads((P/'profile-controller.json').read_text());assert terminal['exit_code']==0 and terminal['error']is None
results={}
for mode in ['cpu','gpu']:
 log=P/mode/'native.log';decisions=[];sends=[]
 for line in log.read_text().splitlines():
  try:r=json.loads(line)
  except json.JSONDecodeError:continue
  if not isinstance(r,dict):continue
  if r.get('event')=='vellum.geometry.decision':decisions.append(r)
  elif r.get('event')=='vellum.geometry.native_send':sends.append(r)
 for records in [decisions,sends]:
  assert records and len(records)<4096 and sorted(r['index']for r in records)==list(range(1,len(records)+1)),'Missing/truncated diagnostic sequence'
 for r in decisions:
  assert not r['unknown_ids'] or not r['version_valid'], 'Unknown bounds must bypass reuse'
  assert r['would_reuse']==(r['version_valid']and r['payload_bytes']<=65536 and r['same_token']and r['same_version']and r['same_payload'])
 expected=collections.Counter((r['token'],r['payload_bytes'])for r in decisions if not r['would_reuse']);actual=collections.Counter((r['token'],r['payload_bytes'])for r in sends);assert expected==actual,'Decision/native sender counts differ'
 results[mode]={'decisions':len(decisions),'native_sender_entries':len(sends),'reuses':sum(r['would_reuse']for r in decisions),'unknown_id_decisions':sum(bool(r['unknown_ids'])for r in decisions),'unknown_ids':sorted({n for r in decisions for n in r['unknown_ids']}),'invalid_versions':sum(not r['version_valid']for r in decisions),'oversize':sum(r['payload_bytes']>65536 for r in decisions),'payload_bytes':sorted({r['payload_bytes']for r in decisions}),'bounds_counts':sorted({r['bounds_count']for r in decisions}),'membership_counts':sorted({r['members_count']for r in decisions}),'changed_payload_decisions':sum(not r['same_payload']for r in decisions),'changed_version_decisions':sum(not r['same_version']for r in decisions),'log_sha256':sha(log),'run_result_sha256':sha(P/mode/'result.json')}
q={'result':'PASS_SOURCE_BOUND_GEOMETRY_DECISION_DIAGNOSTIC','results':results,'terminal_sha256':sha(P/'profile-controller.json'),'inputs_sha256':sha(P/'inputs.json'),'producer_sha256':sha(__file__),'runtime_source_changed':False,'ordinary_latency_gain_qualified':False,'scope':'Local overlays add processwide capped stderr diagnostics and CPU profiling. Counts diagnose exact source8c/6216 ordinary geometry sender behavior only; no elapsed/nativeGPUmemory/fullMac qualification.'};(P/'decision-summary.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(results))
