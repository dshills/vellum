from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-scoped-geometry');P=Path('/private/tmp/vellum-macos-scoped-geometry');G=Path('/private/tmp/vellum-macos-geometry-decisions');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines());sources={n:sha(R/n)for n in sorted(names)};assert len(sources)==8
review=json.loads((P/'source-review.json').read_text());assert review['result']=='APPROVED_SOURCE_AND_HARNESS'and not review['unresolved_findings']and review['sources']==sources and review['inputs_sha256']==sha(P/'native-inputs.json')
for n,h in review['files'].items():assert sha(P/n)==h
inputs=json.loads((P/'native-inputs.json').read_text());assert inputs['source']['delta']==sources
code={}
for n in ['prepare','focused-v2','full-adapter','vet','build-cycles-v3']:
 f=P/(n+'.json');d=json.loads(f.read_text());assert d['exit_code']==0 and d['error']is None and d['source_delta_stable']and len(d['prepared_after'])==6216
 if n=='prepare':assert len(d['prepared_before'])==0
 else:assert d['prepared_before']==d['prepared_after']
 if n!='prepare':
  for name,h in d['source_delta_after'].items():assert sources[name]==h
 for c in ['stdout','stderr']:assert d[c+'_sha256']==sha(P/(n+'.'+c))
 code[n]={'receipt_sha256':sha(f),'elapsed_seconds':d['elapsed_seconds']}
fault=json.loads((P/'fault-original-projection.json').read_text());assert fault['exit_code']==1 and fault['error']is None and fault['source_delta_stable']and fault['prepared_before']==fault['prepared_after']==inputs['source']['prepared']
for c in ['stdout','stderr']:assert fault[c+'_sha256']==sha(P/('fault-original-projection.'+c))
assert (P/'fault-original-projection.stdout').read_text().count('native geometry differs from full projection minus scoped IDs')==4
reconstructed=P/'fault-original-projection.reconstructed-overlay.json';assert sha(reconstructed)==fault['overlay_inputs_before'][str(P/'fault-original-projection.json')]==fault['overlay_inputs_after'][str(P/'fault-original-projection.json')]
assert sha(P/'fault-original-projection.go')==fault['overlay_inputs_before'][str(P/'fault-original-projection.go')]==fault['overlay_inputs_after'][str(P/'fault-original-projection.go')]
prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert prepared==inputs['source']['prepared']and len(prepared)==6216
native=json.loads((P/'native-summary.json').read_text());assert native['result']=='PASS_FIVE_CURRENT_COMPOSED_NATIVE_CYCLES'and native['sources']==sources and native['cycles']==5 and native['activity_steps']==120 and native['prepared_count']==6216 and native['producer_sha256']==sha(P/'validate_composed.py')
diag=json.loads((G/'decision-summary.json').read_text());diagr=json.loads((G/'evidence-review.json').read_text());assert diagr['result']=='APPROVED_SCOPED_DIAGNOSTIC_EVIDENCE'and not diagr['unresolved_findings']and diag['result']=='PASS_SOURCE_BOUND_GEOMETRY_DECISION_DIAGNOSTIC'
for mode in ['cpu','gpu']:assert diag['results'][mode]['decisions']==644 and diag['results'][mode]['reuses']==641 and diag['results'][mode]['native_sender_entries']==3
q={'result':'PASS_SCOPED_MANAGED_OUTLINE_GEOMETRY_PROJECTION','base_commit':inputs['source']['commit'],'sources':sources,'prepared_count':6216,'code_gates':code,'old_behavior_fault_receipt_sha256':sha(P/'fault-original-projection.json'),'reconstructed_original_overlay_sha256':sha(reconstructed),'source_review_sha256':sha(P/'source-review.json'),'native_summary_sha256':sha(P/'native-summary.json'),'native_cycles':5,'native_activity_steps':120,'native_scope':native['scope'],'native_retry_steps':native['retry_steps'],'retry_cause_observed':False,'prior_frozen_diagnostic_source':'8c1709e3ecc7a1a787cc5530df966155203f0053','prior_diagnostic_summary_sha256':sha(G/'decision-summary.json'),'prior_diagnostic_review_sha256':sha(G/'evidence-review.json'),'latency_gain_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'native_gpu_memory_budget_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,'scope':'Bound managed table/outline ordinary projection excludes existing atomic scoped frames. Full inspector/text/legacy tree/namespaces preserved. FourDPI oracle,originalbehaviorfault andfivecurrentCocoacomposedcycles qualifycorrectness only. Prior8c instrumentedgrid diagnostic retains separateendpoint and noordinarylatency/nativeconsumption proof.'};(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':q['base_commit'],'sources':sources},indent=2)+'\n');(P/'final-summary.json').write_text(json.dumps(q,indent=2)+'\n');print(q['result'],len(sources),'sources',native['retry_steps'],'retry steps')
