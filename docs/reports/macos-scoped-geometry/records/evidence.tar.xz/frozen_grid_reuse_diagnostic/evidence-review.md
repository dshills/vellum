APPROVED_SCOPED_DIAGNOSTIC_EVIDENCE. No unresolved findings.

Each CPU/GPU process records644 decisions:641 reuse branches and3 sender-wrapper entries. All payload lengths are59 bytes for2 bounds. Decisions1–2 have zero known membership and invalid versions; decision3 admits the first known-membership payload; decisions4–644 reuse it. This describes observed order, without attributing a startup cause or proving native consumption.

Every raw diagnostic record and summary count reconciles. Each process has512 completed measured samples after128 guarded warm callbacks, matching full geometry sequences and6216 recorded prepared leaves at frozen8c. Retained cells vary468–540;400 visible cells remain exact. CPU profiling is active in both modes. The controller exits0 in46.034372s, and a separately bound observation finds the exact owned group absent.

Instrumentation can affect allocations and scheduling. Counts include startup/warmup; sender entries precede CString/native invocation and are not acknowledgements. No ordinary latency gain, physicalGPU/native memory, presentation, human accessibility, fullMac/P6/P11 or compiler-closure qualification is inferred. Selected hashes and all scope bindings are in evidence-review.json.
