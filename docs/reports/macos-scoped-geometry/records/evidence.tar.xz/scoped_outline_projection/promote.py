from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-scoped-geometry');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-macos-scoped-geometry');O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-scoped-geometry')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
q=json.loads((R/'docs/reports/macos-scoped-geometry/records/qualification.json').read_text());assert q['result']=='PASS_SCOPED_MANAGED_OUTLINE_GEOMETRY_PROJECTION'and q['prism_coverage_complete']and q['prism_unresolved_findings']==0 and q['internal_review']=='APPROVED_SOURCE_AND_EVIDENCE'and not q['latency_gain_qualified'];base=q['base_commit']
assert not git(R,'status','--porcelain')and not git(C,'status','--porcelain')and git(C,'rev-parse','HEAD')==base
commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,raw_name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/raw_name.decode();assert kind=='blob'and path.is_file()and not path.is_symlink();content=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==oid,'Canonical tracked bytes differ: '+raw_name.decode()
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert all(expected.get(n)==h for n,h in q['sources'].items())
before=json.loads((P/'native-inputs.json').read_text())['source']['prepared'];after=before;assert len(before)==6216 and len(after)==6216 and prepared(C)==before and prepared(R)==after
O.mkdir(exist_ok=True,parents=True);start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'tracked_files':len(expected),'scope':'Scoped managed outline ordinary projection correctness; fourDPI oracle/originalbehaviorfault andfiveactualCocoa composedcycles120steps.6216prepared unchanged; broadMac/performance gates remainopen.'}
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
 with(O/'prepare.stdout').open('xb')as so,(O/'prepare.stderr').open('xb')as se:result=run_child(['python3','prepare.py'],cwd=C/'drivers/cogent',env=env,stdout=so,stderr=se,timeout=120)
 record['prepare_exit_code']=result.returncode;assert result.returncode==0
 canonical_names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_exact':set(canonical_names)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_exact':prepared(C)==after,'prepared_files':len(prepared(C)),'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'archive_sha256':sha(C/'docs/reports/macos-scoped-geometry/records/evidence.tar.xz')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean'])and record['archive_sha256']==q['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');(O/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
