from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-scoped-geometry');P=Path('/private/tmp/vellum-macos-scoped-geometry');G=Path('/private/tmp/vellum-macos-geometry-decisions');D=R/'docs/reports/macos-scoped-geometry/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
summary=json.loads((P/'final-summary.json').read_text());sources=summary['sources'];assert len(sources)==8 and all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not internal['unresolved_findings']and internal['sources']==sources
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==0 and not process['error']and process['source_index_stable']and process['before']==process['after']==sources
assert review['coverage']['complete']and review['coverage']['files']==8 and not review['findings']and review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.m','.h','.log','.md','.patch','.cpu'};excluded={}
for root,prefix in [(P,'scoped_outline_projection'),(G,'frozen_grid_reuse_diagnostic')]:
 for f in sorted(root.rglob('*')):
  if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs[prefix+'/'+f.relative_to(root).as_posix()]=f
for root,certname in [(P,'source-review.json'),(P,'final-review.json'),(G,'harness-review.json'),(G,'evidence-review.json')]:
 cert=json.loads((root/certname).read_text())
 for key in ['reviewed_artifact_sha256','reviewed_context_sha256','reviewed_source_sha256']:
  for path,h in cert.get(key,{}).items():
   f=Path(path);assert f.is_file()and sha(f)==h,path
   if f.suffix in allowed:inputs['external/'+f.as_posix().lstrip('/')]=f
   else:excluded[path]={'sha256':h,'bytes':f.stat().st_size,'reason':'Executable omitted; certificate retains its digest.'}
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in sorted(inputs.items())};D.mkdir(parents=True,exist_ok=True);archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as t:
 for n,f in sorted(inputs.items()):t.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as t:
 assert set(t.getnames())==set(index)
 for item in t:assert item.isfile()and hashlib.sha256(t.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'excluded_executables':excluded,'scope':summary['scope']},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','internal_review_sha256':sha(P/'final-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':8,'prism_findings':0,'prism_unresolved_findings':0,'prism_raw_exit_code':0,'prism_calls':review['coverage']['llmCalls'],'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False};(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','prism_files','prism_findings','archive_sha256','archive_members','archive_bytes']}))
