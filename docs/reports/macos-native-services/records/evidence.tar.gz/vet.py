import sys
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
for directory,tags in [('.',None),('drivers/cogent',None),('drivers/cogent','offscreen'),('drivers/cogent','vellum_native_checks')]:
 argv=['go','vet']+(['-tags='+tags]if tags else [])+['./...']
 result=run_child(argv,cwd=root/directory,timeout=120);assert result.returncode==0,(directory,tags,result.returncode)
 print('PASS_VET',directory,tags,flush=True)
