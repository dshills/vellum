"""Pure historical-shape/synthetic-observer controls; no native evidence."""
from pathlib import Path
import copy,hashlib,importlib.util,json
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('surface_validate_controls',W/'validate.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
sdk=Path(json.loads((W/'implementation-scope.json').read_text())['sdk']);fixture=W.parent/'macos-row-fragments-b0534e9/diagnostic/cpu/native.log'
events=[]
for line in fixture.read_text().splitlines():
 try:x=json.loads(line)
 except ValueError:continue
 if str(x.get('event','')).startswith('grid.perf.'):events.append(x)
events[0]['go_version']='go1.25.6'
ordinary=copy.deepcopy(events)
for e in ordinary:
 e['source_details']=False
 if 'native_sample'in e:e['native_sample'].pop('SourceDetails',None)
render=lambda e:'\n'.join(json.dumps(x)for x in e)
v.validate(render(ordinary),{'diagnostic':False,'gpu':False},sdk)
diag=[]
for e in events:
 if e['event']=='grid.perf.sample':
  count=e['geometry']['materialized_cells'];diag.append({'event':'grid.surface.diagnostic','generation':e['generation'],'frame':e['frame'],'native_children':0,'native_body_cells':0,'value_layouts':count,'shapes':count,'complete':True})
 diag.append(e)
v.validate(render(diag),{'diagnostic':True,'gpu':False},sdk)
results={}
for name in ['missing-observer','duplicate-observer','body-widget-remains','incomplete-surface','shape-missing','stale-frame','wrong-generation','small-workload','duplicate-callback','missing-terminal','work-sum-drift','diagnostic-in-ordinary','cpu-source-unavailable','cpu-source-no-op']:
 a=copy.deepcopy(diag if name not in ['diagnostic-in-ordinary']else ordinary);case={'diagnostic':name!='diagnostic-in-ordinary','gpu':False};oi=next((i for i,x in enumerate(a)if x['event']=='grid.surface.diagnostic'),None);si=next(i for i,x in enumerate(a)if x['event']=='grid.perf.sample')
 if name=='cpu-source-unavailable':a[si]['native_sample']['SourceDetails']['Records'][0]['RasterAvailable']=False
 elif name=='cpu-source-no-op':a[si]['native_sample']['SourceDetails']['Records'][0]['ImageChanged']=False
 elif name=='missing-observer':a.pop(oi)
 elif name=='duplicate-observer':a.insert(oi,copy.deepcopy(a[oi]))
 elif name=='body-widget-remains':a[oi]['native_children']=1
 elif name=='incomplete-surface':a[oi]['complete']=False
 elif name=='shape-missing':a[oi]['shapes']-=1
 elif name=='stale-frame':a[oi]['frame']-=1
 elif name=='wrong-generation':a[oi]['generation']+=1
 elif name=='small-workload':a[si]['geometry']['cells']=399
 elif name=='duplicate-callback':a[si]['callbacks']=2
 elif name=='missing-terminal':a.pop()
 elif name=='work-sum-drift':a[si]['metrics']['ui_work_ns']+=1
 elif name=='diagnostic-in-ordinary':a.insert(si,copy.deepcopy(diag[2]))
 try:v.validate(render(a),case,sdk)
 except Exception as e:results[name]={'rejected':True,'type':type(e).__name__,'message':str(e)}
 else:raise AssertionError('accepted '+name)
d={'result':'PASS_PURE_VALIDATOR_CONTROLS','native_executed':False,'historical_fixture':str(fixture),'historical_fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'scope':'HistoricalCPUsource-details grid shape copied onlyinmemory; metadata go_version adapted and synthetic value counters inserted for parser controls. Ordinarycopy removes details. No currentnative/routing/performancequalification. Raw native fixture unchanged.','positive_controls':2,'negative_controls':results}
(W/'validator-controls.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'positive':2,'negative':len(results)}))
