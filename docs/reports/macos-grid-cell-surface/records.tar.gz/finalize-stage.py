from pathlib import Path
import difflib,hashlib,json,shutil
W=Path(__file__).resolve().parent;I=W/'integration';C=Path('/Users/dshills/Development/projects/Vellum');sdk=Path(json.loads((W/'implementation-scope.json').read_text())['sdk']);D=I/'drivers/cogent/native/patches/cellsurface';D.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
changes={'core/passive_text_batch.go':((sdk/'drivers/cogent/build/upstream/core/passive_text_batch.go').read_text(),(I/'prepared/core/passive_text_batch.go').read_text()),'core/passive_text_surface_test.go':('',(I/'prepared/core/passive_text_surface_test.go').read_text())}
patch=''
for name,(old,new)in changes.items():patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
p=D/'0080-passive-text-surface-admission.patch';p.write_text(patch)
(D/'original-hashes.json').write_text(json.dumps({name:sha(old.encode())if old else None for name,(old,new)in changes.items()},indent=2)+'\n')
(D/'output-hashes.json').write_text(json.dumps({name:sha(new.encode())for name,(old,new)in changes.items()},indent=2)+'\n')
(D/'README.md').write_text('''# Managed passive cell surface admission

Stage 0080 adds `Scene.PassiveTextSurfaceAllowed` for the managed grid value
surface. It checks the renderer's explicit text-batch capability and declines
custom widget initialization, render tracing and both private Inspector modes.
The original widget route remains authoritative for these configurations.
The helper does not change painting, the renderer, source publication or resource
ownership. Its test checks positive rasterx and each refusal without a window.

The driver owns only the current projection's body-cell values and shapes;
headers, panes, scrollbars, host input/AX and inline editing remain native.
Unsupported or late-invalidated values revoke completed measurement and request
owner reconstruction of ordinary cells. Rendering never publishes stale styles.
A late paint-only refusal can omit body values in that invalidated paint before
the owner rebuilds them; the complete original frame restores normal content.

See `specs/grid-performance.md` and `docs/reports/macos-grid-cell-surface/README.md`
from the repository root for evidence, reference routing and scope limits.
''')
p=I/'drivers/cogent/native/dependencies.json';d=json.loads((C/'drivers/cogent/native/dependencies.json').read_text());core=d['dependencies'][0];assert core['stages'][-1]['patches'][0]['file'].endswith('0079-passive-text-batch-and-mask-resources.patch');core['stages'].append({'origin':'drivers/cogent/native/patches/cellsurface','inputs':'native/patches/cellsurface/original-hashes.json','outputs':'native/patches/cellsurface/output-hashes.json','patches':[{'file':'native/patches/cellsurface/'+(D/'0080-passive-text-surface-admission.patch').name,'sha256':sha(patch.encode())}]});p.write_text(json.dumps(d,indent=2)+'\n')
p=I/'drivers/cogent/prepare_test.py';p.write_text((C/'drivers/cogent/prepare_test.py').read_text().replace('list(range(1, 80))','list(range(1, 81))'))
over={'Replace':{}}
for p in(I/'drivers/cogent').glob('*.go'):over['Replace'][str(sdk/'drivers/cogent'/p.name)]=str(p)
for p in(I/'prepared').rglob('*.go'):over['Replace'][str(sdk/'drivers/cogent/build/upstream'/p.relative_to(I/'prepared'))]=str(p)
(I/'overlay.json').write_text(json.dumps(over,indent=2)+'\n')
print(json.dumps({'integration':str(I),'overlay_files':len(over['Replace']),'stage':80,'patch_sha256':sha(patch.encode()),'sdk_prepared_changed':False}))
