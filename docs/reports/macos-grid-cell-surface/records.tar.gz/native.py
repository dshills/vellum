"""Fixed private cell-surface diagnostics followed by separate ordinary pairs."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
B=W.parent/'macos-tree-boundary-d47e166'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('surface_boundary',B/'run.py');h=b.h;g=b.g;v=load('surface_validator',W/'validate.py')
HEAD='410a98cf5939618d11f6d326836a245782e54c46'
PREREQUISITES=['driver-all-v2','vet-v2','example-tests-v2','native-build-v2','native-diag-v2']
def clean():
 for root in [h.C,h.T]:h.need(h.git(root,'rev-parse','HEAD').decode().strip()==HEAD and not h.git(root,'status','--porcelain'),'clean exact checkout')
def cases():
 out={}
 for mode in ['cpu','gpu']:out[mode+'-diagnostic']={'gpu':mode=='gpu','diagnostic':True,'candidate':True}
 for mode in ['cpu','gpu']:
  for pair in range(1,6):
   for candidate in ([False,True] if pair%2 else [True,False]):out[f'{mode}-pair{pair}-'+('candidate'if candidate else'original')]={'gpu':mode=='gpu','diagnostic':False,'candidate':candidate,'pair':pair}
 return out
CASES=cases()
def prepare():
 h.need(not(W/'native-plan.json').exists(),'fresh plan');clean();q=json.loads((W/'implementation-scope.json').read_text());sdk=Path(q['sdk'])
 consumer=json.loads((W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/consume-plan.json').read_text());sdkmanifest=json.loads((sdk/'SDK_MANIFEST.json').read_text());h.need(sdkmanifest['source']=={'commit':h.HEAD,'clean':True} and h.sha(sdk/'SDK_MANIFEST.json')==consumer['manifest_sha256'],'exact retained clean SDK manifest');expected={**sdkmanifest['files'],'SDK_MANIFEST.json':consumer['manifest_sha256']};h.need(b.vector(sdk)==expected,'unchanged SDK')
 for name in PREREQUISITES:
  r=json.loads((W/(name+'.json')).read_text());h.need(r['exit_code']==0 and r['error']is None and r['logs_complete'] and r['pins_stable'] and r['owned']['group_absent'] and not r['owned']['errors'],'terminal prerequisite '+name)
  h.need(all(r['source_pins'].get(str(f))==h.sha(f)for f in(W/'candidate').rglob('*.go')),'checked exact candidate '+name)
 old=json.loads((W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/consume-v2-result.json').read_text())['modules']['examples/loadedgrid']['binaries'][0]
 h.need(old['go_version']=='go1.25.6' and h.sha(old['path'])==old['sha256'],'baseline SDK release binary')
 files=list((W/'candidate').rglob('*.go'))+[W/n for n in ['overlay.json','diagnostic-overlay.json','diagnostic-grid-geometry.go','native.py','validate.py','assess.py','check.py','headless.py','implementation-scope.json','internal-source-review-v7.json','validator-controls.py','validator-controls.json']]+[W/(n+'.json')for n in PREREQUISITES]+[B/'run.py',B/'validate.py',B/'owned-executor.py',B.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/consume-plan.json',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/consume-v2-result.json',h.GUARD,h.T/'scripts/child_process.py',h.T/'scripts/sdk_environment.py',sdk/'scripts/benchmark-grid.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 p={'calling_head':HEAD,'reassess_by_utc':q['reassess_by_utc'],'sdk':str(sdk),'sdk_source':h.HEAD,'sdk_files':expected,'pins':{str(f):h.sha(f)for f in files},'cases':CASES,'binaries':{'original':old,'candidate':{'path':str(W/'grid-candidate'),'sha256':h.sha(W/'grid-candidate')},'diagnostic':{'path':str(W/'grid-diagnostic'),'sha256':h.sha(W/'grid-diagnostic')}},'scope':'Exactly2separate CPU/GPU diagnostics, positive completed current layouts/zero body native children and actual CPU/GPU pipeline required on120measured frames; then20ordinary serial interleaved120sample/128warm runs,10kfixed400+clippedcells50rows8cols1519x1266DPI162. Same normal Go1.25.6 optimized consumer/API/eventFIFO. No physical input, operator replay, OSsettings, SDK/prepared mutation. Fresh stop scope/sharedlease/owned PGID retirement+8MiBperstream330swatchdog. Failed or interrupted run seals whole scope; no rerun.','adoption_bar':{'median_run_p95_reduction_ns':400000,'improved_pairs_each_mode':4,'pairs_each_mode':5,'both_modes_required':True,'median_run_p99_nonincreasing':True,'count_p99_over6ms_nonincreasing':True,'median_terminal_heap_allowance_bytes':1048576,'exact_geometry_pairwise':True},'completion':'Prototype adoption only; full4ms/6ms matrix and allM1-M7 remain. Deadline admission checked before every launch; any remaining runs after deadline are not executed.'}
 (W/'native-plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(W/'native-plan.json'),'cases':len(CASES),'pins':len(p['pins']),'native_executed':False}))
def run(name):
 stop=W/('stop-'+name);global_stop=W/'stop-native';raw=(W/'native-plan.json').read_bytes();araw=(W/'native-admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw)
 h.need(a['approved'] and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact reviewed native plan');h.need(name in CASES and not stop.exists()and not global_stop.exists()and not(W/(name+'-result.json')).exists(),'fresh scope')
 sdk=Path(p['sdk']);case=CASES[name];exe=p['binaries']['diagnostic'if case['diagnostic']else('candidate'if case['candidate']else'original')]
 def stable():return(W/'native-plan.json').read_bytes()==raw and(W/'native-admission.json').read_bytes()==araw and all(h.sha(k)==z for k,z in p['pins'].items())and all(h.sha(x['path'])==x['sha256']for x in p['binaries'].values())
 def interrupt(signum,frame):raise InterruptedError('native scope signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupt);d={'case':name,'result':'INCOMPLETE','error':None,'physical_input_generated':False,'full_mac_qualified':False}
 try:
  clean();h.need(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['reassess_by_utc']),'within reassessment timebox');h.need(stable()and b.vector(sdk)==p['sdk_files'],'native exact inputs')
  for prior in list(CASES)[:list(CASES).index(name)]:
   r=json.loads((W/(prior+'-result.json')).read_text());h.need(r['result']=='PASS_SCOPED_GRID_OBSERVATION'and r['run']['owned']['group_absent']and(W/('stop-'+prior)).exists(),'sealed successful predecessor')
  args=['-perf','-rows=10000','-perf-warmup=128','-perf-samples=120']+(['-gpu-scene']if case['gpu']else[])+(['-perf-source-details']if case['diagnostic']else[])
  with g.LiveLease()as lease:
   h.need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['reassess_by_utc']),'shared lease and immediate launch deadline');r=g.execute([exe['path'],*args],sdk/'examples/loadedgrid',W/name,lambda:stop.exists()or global_stop.exists(),stable,timeout=330,limit=8<<20);d['run']=r
   h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned terminal native run');h.need(not(W/name/'stderr').read_bytes(),'empty native stderr')
   summary=v.validate((W/name/'stdout').read_text(),case,sdk)
   clean();h.need(lease.held()and stable()and b.vector(sdk)==p['sdk_files']and not stop.exists()and not global_stop.exists(),'terminal stable native inputs');d.update(result='PASS_SCOPED_GRID_OBSERVATION',summary=summary,lease_held_through_cleanup=True)
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});global_stop.touch()
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/(name+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'case':name,'result':d['result'],'error':d['error'],'p95_ns':d.get('summary',{}).get('ui_work_ns',{}).get('p95'),'diagnostic_frames':d.get('summary',{}).get('diagnostic_surface_frames')}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':
 h.need(sys.argv[1:]in[['prepare']]+[['run',n]for n in CASES],'known stage');prepare()if sys.argv[1]=='prepare'else run(sys.argv[2])
