from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');s=importlib.util.spec_from_file_location('surface_prepare_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
name,kind=sys.argv[1:];h.need(kind in ['prepare','tests'],'known preparation stage');files=[p for p in(W/'integration/drivers').rglob('*')if p.is_file()];pins={str(T/p.relative_to(W/'integration')):h.sha(p)for p in files};pins.update({str(Path(__file__)):h.sha(__file__),str(T/'drivers/cogent/prepare.py'):h.sha(T/'drivers/cogent/prepare.py'),str(h.GO):h.sha(h.GO),str(Path(h.__file__)):h.sha(h.__file__),str(h.GUARD):h.sha(h.GUARD)})
env={'PATH':str(h.GO.parent)+':'+str(h.PY.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off'}
args=[str(h.PY),'-B','prepare.py']if kind=='prepare'else[str(h.PY),'-B','-m','unittest','-v','prepare_test']
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*args]
def interrupt(signum,frame):raise InterruptedError('integration preparation signal '+str(signum))
old=signal.signal(signal.SIGTERM,interrupt)
try:
 r=h.g.execute(av,T/'drivers/cogent',W/name,lambda:(W/'stop-integration').exists(),lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=600,limit=8<<20);r['source_pins']=pins;r['native_ui_executed']=False;(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and r['owned']['errors']==[]else 1)
finally:signal.signal(signal.SIGTERM,old)
