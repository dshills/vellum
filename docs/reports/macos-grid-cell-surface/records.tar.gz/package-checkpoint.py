"""Snapshot completed raw evidence and stage its reviewed checkpoint index."""
from pathlib import Path
import hashlib,json,runpy,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
report=T/'docs/reports/macos-grid-cell-surface'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((W/'internal-final-review.json').read_text())
assert review['approved'] and not review['unresolved_findings']
assert len(review['files'])==19
for name,z in review['files'].items():assert sha(T/name)==z,(name,'reviewed file drift')
assert not(report/'records.tar.gz').exists() and not(report/'checkpoint.json').exists()
runpy.run_path(str(W/'archive-records.py'),run_name='__main__')
index=json.loads((W/'archive-index.json').read_text())
assert index['validated_every_member']
shutil.copyfile(W/'checkpoint-records.tar.gz',report/'records.tar.gz')
assert sha(report/'records.tar.gz')==index['sha256']
review_names={'prototype_source':'internal-source-review-v7.json','prototype_results':'internal-results-review.json','integration_source':'internal-integration-source-review-v2.json','pre_prism':'internal-pre-prism-review.json','final':'internal-final-review.json'}
checks=['integrated-driver-v3','integrated-example-v3','integrated-vet-v3','integrated-build-v3','integrated-diag-build-v2','integrated-core-v1','integrated-prepare-v1','integrated-prepare-tests-v1','integrated-focused-v6']
assert all((W/(n+'.json')).is_file()for n in checks)
receipts={}
for n in checks:
 p=W/(n+'.json');d=json.loads(p.read_text())
 assert d['exit_code']==0 and d['error']is None and d['logs_complete']and d['pins_stable']and d['owned']['group_absent']and not d['owned']['errors'],n
 receipts[n]={'record':p.name,'sha256':sha(p),'exit_code':0,'group_absent':True}
prism=json.loads((W/'prism.json').read_text())
cp={'schema':1,'source_base':'410a98cf5939618d11f6d326836a245782e54c46','implementation':'Current-projection pane-owned grid body layouts; existing public API and original native-widget fallback. Stage0080 internal Core admission helper.','files':review['files'],'archive':{k:v for k,v in index.items()if k!='path'},'reviews':{k:{'record':n,'sha256':sha(W/n)}for k,n in review_names.items()},'checks':receipts,'prism':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':1,'files':19,'bytes':68290,'complete':prism['coverage']['complete'],'raw_exit_code':1,'raw_counts':prism['summary']['counts'],'finding_id':'83b8ecc7c1fee708','disposition':'Refuted existing complete-style invalidation; new race regression passes, comparison-disabled control rejects all three context changes.','record':'prism.json','sha256':sha(W/'prism.json'),'disposition_record':'prism-disposition.json','disposition_sha256':sha(W/'prism-disposition.json'),'production_delta_after_provider':False,'post_provider_test_delta':'TestGridCellSurfaceResolvedContextInvalidatesWithoutDirtyFlag only; initial enum-fixture compile error preserved, corrected focused-v6 passes.','discarded':0,'suppressed':0},'prepared':json.loads((W/'integrated-prepared-correspondence.json').read_text()),'identity':{'retained_sdk_commit':'abe67c625a498d27b78f9719e6038cc1d6c23e88','retained_sdk_stage':79,'retained_sdk_payload_files':7879,'minimum_go':'1.25.6','sdk_changed':False,'installed_source_manifest':'integration-installed-v4.json','installed_source_manifest_sha256':sha(W/'integration-installed-v4.json'),'native_final_source_manifest':'integration-installed-v3.json','native_final_source_manifest_sha256':sha(W/'integration-installed-v3.json'),'only_source_delta_after_native':'Existing test file; production unchanged.'},'qualification':{'prototype_ordinary_samples':2400,'pairs_each_cpu_gpu':5,'cpu_median_run_p95_ms':[5.929751,4.811373],'gpu_median_run_p95_ms':[5.022791,4.249374],'improved_pairs_each':5,'prototype_adoption_pass':True,'all20_p95_fail_4ms':True,'process_allocation_p50_increase_percent':{'cpu':15.21,'gpu':10.17},'corrected_native_functional_frames':{'cpu':120,'gpu':120},'integrated_ordinary_timing_adopted':False,'physical_display_transition_proved':False,'closed_mac_gates':[],'next':'Full current-source table/tree/general-UI matrix and allocation attribution; original performance/resource/physical-input/distribution targets unchanged.'},'scope':'No public push, release, tag, signing, notarization, OS settings or physical-input operation. Native scopes are sealed and every owned group is absent. Archive is the completed evidence snapshot before package/commit/canonical-prepare transaction receipts.'}
cp['archive']['file']='records.tar.gz'
(report/'checkpoint.json').write_text(json.dumps(cp,indent=2)+'\n')
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
run_child(['git','add','docs/reports/macos-grid-cell-surface/records.tar.gz','docs/reports/macos-grid-cell-surface/checkpoint.json'],cwd=T,timeout=30,check=True,capture_output=True)
print(json.dumps({'checkpoint_sha256':sha(report/'checkpoint.json'),'archive_sha256':index['sha256'],'members':index['members'],'bytes':index['bytes'],'staged_only_records':True}))
