//go:build offscreen

package cogent

import (
	"bytes"
	"fmt"
	"image"
	"reflect"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/renderers/rasterx"
	"github.com/dshills/vellum/ui"
)

func TestGridCellSurfaceOriginalPixelGeometryAndActiveCell(t *testing.T) {
	for _, dpi := range []float32{162} {
		t.Run(fmt.Sprint(dpi), func(t *testing.T) {
			model, _ := testNativeGrid(t, 10000)
			cfg := manualConfig(t, 7)
			cfg.LogicalDPI = dpi
			m, a := gridManual(t, cfg, func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: model, Grow: true} })
			gridFrame(t, m)
			before := gridInspection(t, a, model)
			var original *image.RGBA
			var g *gridBinding
			var oldWidgets int
			if err := a.Do(func() {
				window := m.implementation.find("one").state
				g = window.root.control.grid
				original, _ = gridPaintPixels(window.body.Scene, false)
				window.body.WidgetWalkDown(func(_ core.Widget, _ *core.WidgetBase) bool { oldWidgets++; return true })
				snap, err := model.Snapshot()
				if err != nil {
					t.Fatal(err)
				}
				window.body.Scene.SetProperty(gridCellSurfaceProperty, false)
				if !g.wantsCellSurface(snap) {
					t.Fatalf("surface not eligible layout=%+v projection=%v global=%v", g.layout, g.projectionReady, g.host.Scene.GlobalLayoutPending())
				}
				if err := g.syncCellSurface(snap, true); err != nil {
					t.Fatal(err)
				}
			}); err != nil {
				t.Fatal(err)
			}
			gridFrame(t, m)
			after := gridInspection(t, a, model)
			before.Frames, after.Frames = 0, 0
			if !reflect.DeepEqual(before, after) {
				t.Fatalf("surface geometry differs\nbefore=%+v\nafter=%+v", before, after)
			}
			if err := a.Do(func() {
				window := m.implementation.find("one").state
				if g.cellSurface == nil || len(g.cells) != 0 || len(g.cellSurface.cells) != len(g.projection.Cells) {
					t.Fatal("body widgets were not replaced with projection values")
				}
				widgets := 0
				window.body.WidgetWalkDown(func(_ core.Widget, _ *core.WidgetBase) bool { widgets++; return true })
				if oldWidgets-widgets != len(g.cellSurface.cells) {
					t.Fatalf("removed widgets %d, want %d", oldWidgets-widgets, len(g.cellSurface.cells))
				}
				actual, _ := gridPaintPixels(window.body.Scene, false)
				if !bytes.Equal(original.Pix, actual.Pix) {
					for i := range actual.Pix {
						if original.Pix[i] != actual.Pix[i] {
							t.Fatalf("surface pixels differ offset=%d xy=%d,%d old=%d new=%d", i, (i/4)%actual.Stride/4, (i / actual.Stride), original.Pix[i], actual.Pix[i])
						}
					}
				}
				window.body.Scene.RenderWidget()
				commands := window.body.Scene.Painter.RenderDone()
				r := rasterx.New(math32.FromPoint(window.body.Scene.SceneGeom.Size)).(*rasterx.Renderer)
				packet := r.ScenePacket(commands)
				pixels := image.NewRGBA(actual.Bounds())
				if packet == nil || !packet.Replay(pixels) || !bytes.Equal(pixels.Pix, original.Pix) {
					t.Fatal("packet replay differs from original widget pixels")
				}
				t.Log("native body widgets removed", oldWidgets-widgets, "retained value layouts", len(g.cellSurface.cells))
			}); err != nil {
				t.Fatal(err)
			}
		})
	}
}
