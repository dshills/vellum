//go:build offscreen

package cogent

import (
	"bytes"
	"fmt"
	"image"
	"reflect"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/renderers/rasterx"
	"cogentcore.org/core/text/shaped"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
)

func TestGridCellSurfaceOriginalPixelGeometryAndActiveCell(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 162, 192} {
		t.Run(fmt.Sprint(dpi), func(t *testing.T) {
			model, _ := testNativeGrid(t, 10000)
			cfg := manualConfig(t, 7)
			cfg.LogicalDPI = dpi
			m, a := gridManual(t, cfg, func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: model, Grow: true} })
			gridFrame(t, m)
			before := gridInspection(t, a, model)
			var original *image.RGBA
			var g *gridBinding
			var oldWidgets int
			if err := a.Do(func() {
				window := m.implementation.find("one").state
				g = window.root.control.grid
				original, _ = gridPaintPixels(window.body.Scene, false)
				window.body.WidgetWalkDown(func(_ core.Widget, _ *core.WidgetBase) bool { oldWidgets++; return true })
				snap, err := model.Snapshot()
				if err != nil {
					t.Fatal(err)
				}
				window.body.Scene.SetProperty(gridCellSurfaceProperty, false)
				if !g.wantsCellSurface(snap) {
					t.Fatalf("surface not eligible layout=%+v projection=%v global=%v", g.layout, g.projectionReady, g.host.Scene.GlobalLayoutPending())
				}
				if err := g.syncCellSurface(snap, true); err != nil {
					t.Fatal(err)
				}
			}); err != nil {
				t.Fatal(err)
			}
			gridFrame(t, m)
			after := gridInspection(t, a, model)
			before.Frames, after.Frames = 0, 0
			if !reflect.DeepEqual(before, after) {
				t.Fatalf("surface geometry differs\nbefore=%+v\nafter=%+v", before, after)
			}
			if err := a.Do(func() {
				window := m.implementation.find("one").state
				if g.cellSurface == nil || len(g.cells) != 0 || len(g.cellSurface.cells) != len(g.projection.Cells) {
					t.Fatal("body widgets were not replaced with projection values")
				}
				widgets := 0
				window.body.WidgetWalkDown(func(_ core.Widget, _ *core.WidgetBase) bool { widgets++; return true })
				if oldWidgets-widgets != len(g.cellSurface.cells) {
					t.Fatalf("removed widgets %d, want %d", oldWidgets-widgets, len(g.cellSurface.cells))
				}
				actual, _ := gridPaintPixels(window.body.Scene, false)
				if !bytes.Equal(original.Pix, actual.Pix) {
					for i := range actual.Pix {
						if original.Pix[i] != actual.Pix[i] {
							t.Fatalf("surface pixels differ offset=%d xy=%d,%d old=%d new=%d", i, (i%actual.Stride)/4, (i / actual.Stride), original.Pix[i], actual.Pix[i])
						}
					}
				}
				window.body.Scene.RenderWidget()
				commands := window.body.Scene.Painter.RenderDone()
				r := rasterx.New(math32.FromPoint(window.body.Scene.SceneGeom.Size)).(*rasterx.Renderer)
				packet := r.ScenePacket(commands)
				pixels := image.NewRGBA(actual.Bounds())
				if packet == nil || !packet.Replay(pixels) || !bytes.Equal(pixels.Pix, original.Pix) {
					t.Fatal("packet replay differs from original widget pixels")
				}
				t.Log("native body widgets removed", oldWidgets-widgets, "retained value layouts", len(g.cellSurface.cells))
			}); err != nil {
				t.Fatal(err)
			}
		})
	}
}

func surfaceBinding(t *testing.T, m *Manual, a *app.Application) *gridBinding {
	t.Helper()
	var g *gridBinding
	if err := a.Do(func() { g = m.implementation.find("one").state.root.control.grid }); err != nil {
		t.Fatal(err)
	}
	return g
}

func surfaceEnable(t *testing.T, m *Manual, a *app.Application, g *gridBinding) {
	t.Helper()
	if err := a.Do(func() {
		g.host.Scene.SetProperty(gridCellSurfaceProperty, false)
		snap, e := g.model.Snapshot()
		if e != nil {
			t.Fatal(e)
		}
		if !g.wantsCellSurface(snap) {
			t.Fatal("surface not eligible")
		}
		if e = g.syncCellSurface(snap, true); e != nil {
			t.Fatal(e)
		}
	}); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
}

func surfaceCompareWithOriginal(t *testing.T, m *Manual, a *app.Application, g *gridBinding) {
	t.Helper()
	actualInspection := gridInspection(t, a, g.model)
	var actual *image.RGBA
	if err := a.Do(func() {
		if g.cellSurface == nil || len(g.cells) != 0 {
			t.Fatal("value route missing")
		}
		actual, _ = gridPaintPixels(g.host.Scene, false)
		g.host.Scene.SetProperty(gridCellSurfaceProperty, true)
		if e := g.owner.Invalidate(g.window); e != nil {
			t.Fatal(e)
		}
	}); err != nil {
		t.Fatal(err)
	}
	gridFrame(t, m)
	reference := gridInspection(t, a, g.model)
	actualInspection.Frames, reference.Frames = 0, 0
	if !reflect.DeepEqual(actualInspection, reference) {
		t.Fatal("value/original geometry differs after transition")
	}
	if err := a.Do(func() {
		if g.cellSurface != nil || len(g.cells) != len(g.projection.Cells) {
			t.Fatal("ordinary fallback did not restore native cells")
		}
		pixels, _ := gridPaintPixels(g.host.Scene, false)
		if !bytes.Equal(pixels.Pix, actual.Pix) {
			for i := range actual.Pix {
				if actual.Pix[i] != pixels.Pix[i] {
					t.Fatalf("value/original pixels differ offset=%d xy=%d,%d value=%d original=%d", i, (i%actual.Stride)/4, i/actual.Stride, actual.Pix[i], pixels.Pix[i])
				}
			}
		}
	}); err != nil {
		t.Fatal(err)
	}
}

func TestGridCellSurfaceScrollRetentionAndDisableFallback(t *testing.T) {
	model, _ := testNativeGrid(t, 10000)
	disabled := false
	cfg := manualConfig(t, 7)
	cfg.LogicalDPI = 162
	m, a := gridManual(t, cfg, func() ui.Node {
		return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: model, Grow: true, Disabled: disabled}
	})
	gridFrame(t, m)
	g := surfaceBinding(t, m, a)
	for _, delta := range []image.Point{{0, 12}, {90, 12}, {-30, -5}, {0, 24}} {
		surfaceEnable(t, m, a, g)
		old := map[gridCellKey]*shaped.Lines{}
		if e := a.Do(func() {
			for _, entry := range g.cellSurface.cells {
				old[entry.key] = entry.shape
			}
			if e := model.Scroll(delta.X, delta.Y); e != nil {
				t.Fatal(e)
			}
			_ = a.Invalidate("one")
		}); e != nil {
			t.Fatal(e)
		}
		gridFrame(t, m)
		if e := a.Do(func() {
			if g.cellSurface == nil || len(g.cells) != 0 {
				t.Fatal("ordinary scroll fell back")
			}
			hits := 0
			for _, entry := range g.cellSurface.cells {
				if old[entry.key] != nil && old[entry.key] == entry.shape {
					hits++
				}
			}
			if hits == 0 {
				t.Fatal("unchanged current-projection shapes were not retained")
			}
		}); e != nil {
			t.Fatal(e)
		}
		surfaceCompareWithOriginal(t, m, a, g)
	}
	surfaceEnable(t, m, a, g)
	if e := a.Do(func() { disabled = true; _ = a.Invalidate("one") }); e != nil {
		t.Fatal(e)
	}
	gridFrame(t, m)
	if g.cellSurface != nil || len(g.cells) == 0 {
		t.Fatal("disabled transition failed ordinary fallback")
	}
	if e := a.Do(func() { disabled = false; _ = a.Invalidate("one") }); e != nil {
		t.Fatal(e)
	}
	gridFrame(t, m)
	surfaceEnable(t, m, a, g)
	owned := g.cellSurface
	if e := m.Close(testContext); e != nil {
		t.Fatal(e)
	}
	if g.cellSurface != nil || len(owned.cells) != 0 {
		t.Fatal("retired layout/font/text references retained")
	}
}

type surfaceEditableSource struct {
	selectionNativeSource
	value string
}

func (s *surfaceEditableSource) Cell(row, col string) (string, error) {
	if row == "selection-0" && col == "c1" {
		return s.value, nil
	}
	return s.selectionNativeSource.Cell(row, col)
}
func (s *surfaceEditableSource) EditCell(row, col string) (virtual.GridEditValue, error) {
	value, err := s.Cell(row, col)
	return virtual.GridEditValue{Text: value, Version: 1, Editable: true}, err
}

func TestGridCellSurfaceRowSelectionCursorAndEditFallback(t *testing.T) {
	source := &surfaceEditableSource{selectionNativeSource: selectionNativeSource{selectionNativeIndex: selectionNativeIndex{total: 10000, revision: 1}}, value: "A😀é <b>\tאבג\nsecond"}
	model, e := virtual.NewGrid(source, []virtual.GridColumn{{ID: "c0", Width: 121}, {ID: "c1", Width: 121}, {ID: "c2", Width: 121}}, virtual.GridConfig{RowHeight: 23, HeaderHeight: 27, FrozenColumns: 1, RowSelection: true, CellEditing: true, MaxEditBytes: 128}, virtual.GridViewport{Width: 300, Height: 180})
	if e != nil {
		t.Fatal(e)
	}
	cfg := manualConfig(t, 7)
	cfg.LogicalDPI = 162
	m, a := gridManual(t, cfg, func() ui.Node { return ui.Node{ID: "g", Kind: ui.DataGrid, Grid: model, Grow: true} })
	gridFrame(t, m)
	g := surfaceBinding(t, m, a)
	if e = a.Do(func() {
		if e := model.SelectToKey("selection-0", "c1", virtual.GridSelectReplace); e != nil {
			t.Fatal(e)
		}
		_ = a.Invalidate("one")
	}); e != nil {
		t.Fatal(e)
	}
	gridFrame(t, m)
	surfaceEnable(t, m, a, g)
	surfaceCompareWithOriginal(t, m, a, g)
	surfaceEnable(t, m, a, g)
	if e = a.Do(func() {
		if e := model.BeginActiveEdit(); e != nil {
			t.Fatal(e)
		}
		_ = a.Invalidate("one")
	}); e != nil {
		t.Fatal(e)
	}
	gridFrame(t, m)
	if g.cellSurface != nil || g.editing == nil || len(g.cells) == 0 {
		t.Fatal("editor did not take original native route")
	}
	if e = a.Do(func() {
		if e := model.CancelEdit(); e != nil {
			t.Fatal(e)
		}
		_ = a.Invalidate("one")
	}); e != nil {
		t.Fatal(e)
	}
	gridFrame(t, m)
	surfaceEnable(t, m, a, g)
	surfaceCompareWithOriginal(t, m, a, g)
}
