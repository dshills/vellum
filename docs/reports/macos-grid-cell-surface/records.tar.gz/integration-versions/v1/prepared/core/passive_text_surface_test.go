// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"testing"
)

type surfaceRendererWithoutBatch struct{ render.Renderer }

func TestPassiveTextSurfaceAdmission(t *testing.T) {
	var absent *Scene
	if absent.PassiveTextSurfaceAllowed() {
		t.Fatal("nil scene admitted")
	}
	sc := &Scene{Renderer: rasterx.New(math32.Vec2(20, 20))}
	if !sc.PassiveTextSurfaceAllowed() {
		t.Fatal("ordinary rasterx declined")
	}
	original := sc.Renderer
	sc.Renderer = surfaceRendererWithoutBatch{original}
	if sc.PassiveTextSurfaceAllowed() {
		t.Fatal("renderer without capability admitted")
	}
	sc.Renderer = original
	sc.WidgetInit = func(Widget) {}
	if sc.PassiveTextSurfaceAllowed() {
		t.Fatal("custom initialization admitted")
	}
	sc.WidgetInit = nil
	sc.renderBBoxes = true
	if sc.PassiveTextSurfaceAllowed() {
		t.Fatal("bounding-box inspector admitted")
	}
	sc.renderBBoxes = false
	sc.selectedWidget = &Text{}
	if sc.PassiveTextSurfaceAllowed() {
		t.Fatal("selected inspector widget admitted")
	}
	sc.selectedWidget = nil
	before := DebugSettings.RenderTrace
	DebugSettings.RenderTrace = true
	defer func() { DebugSettings.RenderTrace = before }()
	if sc.PassiveTextSurfaceAllowed() {
		t.Fatal("debug render tracing admitted")
	}
}
