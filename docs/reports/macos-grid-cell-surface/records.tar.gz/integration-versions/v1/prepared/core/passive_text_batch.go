// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/sides"
	"cogentcore.org/core/tree"
)

// RenderPassiveTextBatch performs an ordinary custom-frame traversal while
// batching contiguous undecorated passive Text leaves whose box was already
// suppressed by a full-background proof. False has no effects. Renderers without
// the explicit capability, debug painting and stacked frames retain the normal
// traversal. Pending shaping and interactive/highlighted text retain RenderWidget.
func (fr *Frame) RenderPassiveTextBatch() bool {
	sc := fr.Scene
	if sc == nil || sc.Painter.State == nil || fr.Styles.Display != styles.Custom || DebugSettings.RenderTrace || sc.renderBBoxes || sc.selectedWidget != nil {
		return false
	}
	capability, ok := sc.Renderer.(render.TextBatchRenderer)
	if !ok || !capability.SupportsTextBatch() {
		return false
	}
	if !fr.StartRender() {
		return true
	}
	fr.This.(Widget).Render()
	var batch *render.TextBatch
	flush := func() {
		if batch != nil && batch.Len() != 0 {
			sc.Painter.Render.Add(batch)
		}
		batch = nil
	}
	fr.ForWidgetChildren(func(_ int, child Widget, wb *WidgetBase) bool {
		tx, ok := child.(*Text)
		if !ok || tx.This != tx || tx.Styles.RenderBox || tx.Parts != nil || len(tx.Children) != 0 || tx.Styles.Abilities != 0 || tx.localTextPending || tx.paintText == nil || tx.selectRange.Len() != 0 || len(tx.highlights) != 0 || !sides.AreZero(tx.Styles.Border.Radius.Dots().Sides) {
			flush()
			child.RenderWidget()
			return tree.Continue
		}
		tx.setFlag(false, widgetNeedsRender)
		if !tx.IsVisible() {
			return tree.Continue
		}
		tx.Styles.ComputeActualBackground(tx.parentActualBackground())
		tx.paintText.SelectReset()
		tx.paintText.HighlightReset()
		sc.Painter.Paint.Defaults()
		if batch == nil {
			batch = render.NewTextBatch(sc.Painter.Context())
		}
		batch.Add(tx.paintText, tx.Geom.Pos.Content, tx.Geom.TotalBBox)
		return tree.Continue
	})
	flush()
	fr.renderParts()
	fr.RenderScrolls()
	fr.EndRender()
	return true
}

// PassiveTextSurfaceAllowed reports whether a managed passive text surface can
// replace native leaf traversal without losing renderer or Inspector behavior.
func (sc *Scene) PassiveTextSurfaceAllowed() bool {
	if sc == nil || sc.WidgetInit != nil || DebugSettings.RenderTrace || sc.renderBBoxes || sc.selectedWidget != nil {
		return false
	}
	capability, ok := sc.Renderer.(render.TextBatchRenderer)
	return ok && capability.SupportsTextBatch()
}
