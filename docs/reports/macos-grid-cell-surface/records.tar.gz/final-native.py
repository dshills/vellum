"""Two corrected-source native functional route checks, never timing adoption."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;I=W/'integration';F=W/'final-native';F.mkdir(exist_ok=True)
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
n=load('surface_final_base',W/'native.py');h=n.h;g=n.g;v=n.v
PREREQ=['integrated-focused-v4','integrated-driver-v3','integrated-example-v3','integrated-vet-v3','integrated-build-v3','integrated-diag-build-v2','integrated-prepare-v1','integrated-prepare-tests-v1']
def source():
 h.need(h.git(h.C,'rev-parse','HEAD').decode().strip()==n.HEAD and not h.git(h.C,'status','--porcelain'),'canonical clean base')
 h.need(h.git(h.T,'rev-parse','HEAD').decode().strip()==n.HEAD,'isolated base')
 installed=json.loads((W/'integration-installed-v3.json').read_text())
 h.need(all(h.sha(h.T/p)==sha for p,sha in installed['files'].items()),'exact installed source')
 return h.git(h.T,'status','--porcelain','-z').hex()
def prepared():
 return {module+'/'+p.relative_to(h.T/'drivers/cogent/build'/module).as_posix():h.sha(p)for module in ['upstream','typesetting']for p in(h.T/'drivers/cogent/build'/module).rglob('*')if p.is_file()}
def prepare():
 h.need(not(F/'plan.json').exists()and not(F/'stop-live').exists(),'fresh final scope')
 old=json.loads((W/'native-plan.json').read_text());sdk=Path(old['sdk']);h.need(n.b.vector(sdk)==old['sdk_files'],'unchanged retained SDK')
 for name in PREREQ:
  r=json.loads((W/(name+'.json')).read_text());h.need(r['exit_code']==0 and r['error']is None and r['pins_stable']and r['logs_complete']and r['owned']['group_absent']and not r['owned']['errors'],'terminal prerequisite '+name)
 for name in ['integrated-focused-v4','integrated-driver-v3','integrated-example-v3','integrated-vet-v3','integrated-build-v3','integrated-diag-build-v2']:
  r=json.loads((W/(name+'.json')).read_text())
  for leaf in I.rglob('*'):
   if not leaf.is_file():continue
   actual=r['source_pins'].get(str(leaf));expected=h.sha(leaf)
   if name!='integrated-focused-v4'and leaf.relative_to(I).as_posix()=='drivers/cogent/grid_surface_offscreen_test.go':
    h.need(actual==h.sha(W/'integration-versions/v2/drivers/cogent/grid_surface_offscreen_test.go'),'exact pre-fidelity test source '+name)
   else:h.need(actual==expected,'exact final source prerequisite '+name+':'+str(leaf))
 paths=[p for p in I.rglob('*')if p.is_file()]+[Path(__file__),W/'integration-installed-v3.json',W/'integrated-diagnostic-overlay.json',W/'build-integrated-diagnostic-v2.py',W/'integration-check.py',W/'prepare-integration.py',W/'integrated-prepared-correspondence.json',W/'internal-integration-source-review-v2.json',W/'integration-versions/v2/drivers/cogent/grid_surface_offscreen_test.go']+[W/(name+'.json')for name in PREREQ]
 pins={**old['pins'],**{str(p):h.sha(p)for p in paths}}
 p={'pins':pins,'sdk':str(sdk),'sdk_files':old['sdk_files'],'isolated_status':source(),'isolated_prepared':prepared(),'reassess_by_utc':old['reassess_by_utc'],'binary':{'path':str(W/'grid-integrated-diagnostic'),'sha256':h.sha(W/'grid-integrated-diagnostic')},'ordinary_binary':{'path':str(W/'grid-integrated'),'sha256':h.sha(W/'grid-integrated')},'cases':['cpu','gpu'],'scope':'Exactly two serial corrected-source diagnostic functional native runs,120samples+128warm each. Positive exact-frame current layouts/zero body native widgets and CPU raster-copy/GPU fresh accepted route required. No ordinary timing acceptance; prototype medians not relabeled. Existing FIFO event routing only, no physical input/operator/OSsettings. Freshstop/sharedlease/330swatchdog/8MiBstreams/ownedprocessretirement. No rerun or further native campaign automatically admitted.'}
 (F/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(F/'plan.json'),'pins':len(pins),'native_executed':False}))
def run(name):
 raw=(F/'plan.json').read_bytes();araw=(F/'admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw);stop=F/('stop-'+name);globalstop=F/'stop-live'
 h.need(a['approved']and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact final admission');h.need(name in p['cases']and not stop.exists()and not globalstop.exists()and not(F/(name+'-result.json')).exists(),'fresh case');sdk=Path(p['sdk'])
 def stable():return(F/'plan.json').read_bytes()==raw and(F/'admission.json').read_bytes()==araw and all(h.sha(k)==z for k,z in p['pins'].items())and all(h.sha(p[k]['path'])==p[k]['sha256']for k in ['binary','ordinary_binary'])
 def interrupt(signum,frame):raise InterruptedError('final native signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupt);d={'case':name,'result':'INCOMPLETE','error':None,'timing_acceptance':False,'physical_input_generated':False,'full_mac_qualified':False}
 try:
  h.need(source()==p['isolated_status']and prepared()==p['isolated_prepared']and n.b.vector(sdk)==p['sdk_files']and stable(),'exact final native inputs')
  if name=='gpu':
   r=json.loads((F/'cpu-result.json').read_text());h.need(r['result']=='PASS_FINAL_NATIVE_ROUTE'and r['run']['owned']['group_absent']and(F/'stop-cpu').exists(),'sealed CPU predecessor')
  with g.LiveLease()as lease:
   h.need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['reassess_by_utc']),'lease and immediate launch deadline')
   args=[p['binary']['path'],'-perf','-rows=10000','-perf-warmup=128','-perf-samples=120','-perf-source-details']+(['-gpu-scene']if name=='gpu'else[])
   r=g.execute(args,sdk/'examples/loadedgrid',F/name,lambda:stop.exists()or globalstop.exists(),stable,timeout=330,limit=8<<20);d['run']=r
   h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned terminal final run');h.need(not(F/name/'stderr').read_bytes(),'empty final native stderr')
   summary=v.validate((F/name/'stdout').read_text(),{'diagnostic':True,'gpu':name=='gpu'},sdk)
   h.need(lease.held()and stable()and source()==p['isolated_status']and prepared()==p['isolated_prepared']and n.b.vector(sdk)==p['sdk_files']and not stop.exists()and not globalstop.exists(),'terminal unchanged inputs');d.update(result='PASS_FINAL_NATIVE_ROUTE',summary=summary,lease_held_through_cleanup=True)
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});globalstop.touch()
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(F/(name+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'case':name,'result':d['result'],'error':d['error'],'frames':d.get('summary',{}).get('diagnostic_surface_frames')}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':
 h.need(sys.argv[1:]in[['prepare'],['run','cpu'],['run','gpu']],'known final stage');prepare()if sys.argv[1]=='prepare'else run(sys.argv[2])
