from pathlib import Path
import importlib.util,json,os,shutil,sys,signal
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('surface_owned',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sdk=Path(json.loads((W/'implementation-scope.json').read_text())['sdk']);name=sys.argv[1];shutil.copytree(W/'candidate',W/'source-versions'/name)
pins={str(p):h.sha(p)for p in list((W/'candidate').rglob('*.go'))+[W/'overlay.json',Path(__file__),Path(h.__file__),Path(h.GUARD),h.GO]}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','LANG':os.environ.get('LANG','en_US.UTF-8')}
args=['test','-v','-race','-count=1','-p=1','-overlay='+str(W/'overlay.json'),'-tags=offscreen','-run','^TestGridCellSurface','-timeout=3m','.']
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args]
def interrupt(signum,frame):raise InterruptedError('headless surface signal '+str(signum))
previous=signal.signal(signal.SIGTERM,interrupt)
try:
 r=h.g.execute(av,sdk/'drivers/cogent',W/name,lambda:(W/'stop-headless').exists(),lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=300,limit=8<<20);r['source_pins']=pins;r['native_ui_executed']=False;(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and r['owned']['errors']==[] else 1)
finally:signal.signal(signal.SIGTERM,previous)
