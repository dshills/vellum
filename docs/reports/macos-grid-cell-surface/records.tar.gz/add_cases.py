from pathlib import Path
p=Path(__file__).resolve().parent/'candidate/drivers/cogent/grid_surface_offscreen_test.go'
s=p.read_text();s+='''
type surfaceVariableSource struct { *nativeGridSource; heights *virtual.RowHeights }
func(s *surfaceVariableSource) RowOffset(i int)(int,error){return s.heights.RowOffset(i)}
func(s *surfaceVariableSource) RowAt(i int)(int,error){return s.heights.RowAt(i)}

func TestGridCellSurfaceVariableFrozenEmptyAndTypography(t *testing.T) {
 for _,tc:=range []struct{name string;rows,frozen int;variable bool}{
  {"no-frozen",10000,0,false},{"variable",10000,2,true},{"empty",0,0,false},
 } {t.Run(tc.name,func(t *testing.T){
  source:=&nativeGridSource{rows:tc.rows,revision:1}
  var input virtual.GridSource=source
  if tc.variable {
   heights:=make([]int,tc.rows);for i:=range heights {heights[i]=19+i%7}
   h,e:=virtual.NewRowHeights(heights);if e!=nil {t.Fatal(e)}
   input=&surfaceVariableSource{nativeGridSource:source,heights:h}
  }
  cols:=make([]virtual.GridColumn,20);for i:=range cols {cols[i]=virtual.GridColumn{ID:fmt.Sprint("c",i),Title:fmt.Sprint("column",i),Width:77+i%4}}
  model,e:=virtual.NewGrid(input,cols,virtual.GridConfig{RowHeight:23,HeaderHeight:27,FrozenColumns:tc.frozen,OverscanRows:1,OverscanColumns:1},virtual.GridViewport{Width:300,Height:180});if e!=nil {t.Fatal(e)}
  cfg:=manualConfig(t,7);cfg.LogicalDPI=162
  m,a:=gridManual(t,cfg,func()ui.Node{return ui.Node{ID:"g",Kind:ui.DataGrid,Grid:model,Grow:true}})
  gridFrame(t,m);g:=surfaceBinding(t,m,a);surfaceEnable(t,m,a,g)
  if e:=a.Do(func(){
   for _,pane:=range g.panes[2:] {pane.OverrideStyle=true;pane.Styles.Font.Size=units.Dp(19);pane.Styles.Text.Indent=units.Px(3);pane.Styles.Text.Hanging=units.Px(2)}
   g.host.Update()
  });e!=nil{t.Fatal(e)}
  gridFrame(t,m)
  if g.cellSurface==nil {t.Fatal("supported typography lost value route")}
  surfaceCompareWithOriginal(t,m,a,g)
  if tc.rows>0 {
   surfaceEnable(t,m,a,g)
   if e:=a.Do(func(){if e:=model.Scroll(103,11);e!=nil{t.Fatal(e)};_=a.Invalidate("one")});e!=nil{t.Fatal(e)}
   gridFrame(t,m);surfaceCompareWithOriginal(t,m,a,g)
  }
 })}
}
''';p.write_text(s)
