from pathlib import Path
import difflib,hashlib,json,shutil
W=Path(__file__).resolve().parent;I=W/'integration';sdk=Path(json.loads((W/'implementation-scope.json').read_text())['sdk']);C=Path('/Users/dshills/Development/projects/Vellum')
assert not I.exists();I.mkdir()
files=['grid.go','grid_geometry.go','grid_scroll.go','grid_surface.go','grid_surface_offscreen_test.go','grid_contract_test.go']
for name in files:
 p=I/'drivers/cogent'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(W/'candidate/drivers/cogent'/name,p)
p=I/'drivers/cogent/grid_surface.go';s=p.read_text().replace('// Private experiment: the original widget implementation remains the reference.','// A scene may select the ordinary widget route as an independent reference.')
s=s.replace('if g.cellSurface.failed || !g.cellSurface.completed || !p.Scene.PassiveTextSurfaceAllowed() {','if g.cellSurface.failed || !g.cellSurface.completed || g.cellSurface.dirty[0] || g.cellSurface.dirty[1] || !p.Scene.PassiveTextSurfaceAllowed() {');p.write_text(s)
# The legacy oracle belongs only to implementation-specific test fixtures.
p=I/'drivers/cogent/grid_offscreen_test.go';s=(sdk/'drivers/cogent/grid_offscreen_test.go').read_text().replace('return m, a\n}', '''if err := a.Do(func(){m.implementation.find("one").state.body.Scene.SetProperty(gridCellSurfaceProperty,true)});err!=nil {t.Fatal(err)}
 return m,a
}''',1);p.write_text(s)
p=I/'drivers/cogent/grid_surface_offscreen_test.go';s=p.read_text().replace('"bytes"','"bytes"\n"image/color"\n"cogentcore.org/core/colors"');s+='''
func TestGridCellSurfaceRestyleOnlyRetiresCachedStyles(t *testing.T) {
 model,_:=testNativeGrid(t,10000)
 m,a:=gridManual(t,manualConfig(t,7),func()ui.Node{return ui.Node{ID:"g",Kind:ui.DataGrid,Grid:model,Grow:true}})
 gridFrame(t,m);g:=surfaceBinding(t,m,a);surfaceEnable(t,m,a,g)
 var generation uint64
 if e:=a.Do(func(){
  generation=g.projection.State.Generation
  pane:=g.panes[3];pane.OverrideStyle=true;pane.Styles.Color=colors.Uniform(color.RGBA{R:211,G:31,B:42,A:255})
  // Restyle requests rendering without layout; old templates cannot be painted.
  pane.Restyle()
  if !g.cellSurface.dirty[1] {t.Fatal("restyle did not dirty inherited styles")}
  g.host.Scene.RenderWidget()
  if !g.cellSurface.failed || g.measurement.Load()!=nil || !g.layoutPending.Load(){t.Fatal("paint-only restyle accepted stale templates")}
 });e!=nil{t.Fatal(e)}
 gridFrame(t,m)
 if e:=a.Do(func(){
  if g.cellSurface!=nil || len(g.cells)==0 || g.projection.State.Generation!=generation {t.Fatal("restyle-only fallback did not recover ordinary cells at same generation")}
 });e!=nil{t.Fatal(e)}
 _=gridInspection(t,a,model)
 surfaceEnable(t,m,a,g);surfaceCompareWithOriginal(t,m,a,g)
}
''';p.write_text(s)
# The only prepared dependency change is the explicit Core eligibility hook.
rel=Path('core/passive_text_batch.go');old=(sdk/'drivers/cogent/build/upstream'/rel).read_text();new=(W/'candidate/drivers/cogent/build/upstream'/rel).read_text()
coretest='''// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package core
import (
 "testing"
 "cogentcore.org/core/math32"
 "cogentcore.org/core/paint/render"
 "cogentcore.org/core/paint/renderers/rasterx"
)
type surfaceRendererWithoutBatch struct {render.Renderer}
func TestPassiveTextSurfaceAdmission(t *testing.T) {
 var absent *Scene
 if absent.PassiveTextSurfaceAllowed(){t.Fatal("nil scene admitted")}
 sc:=&Scene{Renderer:rasterx.New(math32.Vec2(20,20))}
 if !sc.PassiveTextSurfaceAllowed(){t.Fatal("ordinary rasterx declined")}
 original:=sc.Renderer;sc.Renderer=surfaceRendererWithoutBatch{original}
 if sc.PassiveTextSurfaceAllowed(){t.Fatal("renderer without capability admitted")}
 sc.Renderer=original;sc.WidgetInit=func(Widget){}
 if sc.PassiveTextSurfaceAllowed(){t.Fatal("custom initialization admitted")}
 sc.WidgetInit=nil;sc.renderBBoxes=true
 if sc.PassiveTextSurfaceAllowed(){t.Fatal("bounding-box inspector admitted")}
 sc.renderBBoxes=false;sc.selectedWidget=&Text{}
 if sc.PassiveTextSurfaceAllowed(){t.Fatal("selected inspector widget admitted")}
 sc.selectedWidget=nil;before:=DebugSettings.RenderTrace;DebugSettings.RenderTrace=true
 defer func(){DebugSettings.RenderTrace=before}()
 if sc.PassiveTextSurfaceAllowed(){t.Fatal("debug render tracing admitted")}
}
'''
p=I/'prepared'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new)
p=p.with_name('passive_text_surface_test.go');p.write_text(coretest)
# Patch generated after gofmt by finalize-stage.py.
meta={'base':json.loads((W/'implementation-scope.json').read_text())['base'],'prototype_plan_sha256':hashlib.sha256((W/'native-plan.json').read_bytes()).hexdigest(),'runtime_deltas':['paint-only Restyle now fails closed to existing owner fallback instead of painting cached templates','legacy Manual oracle moved to tests; normal NewManual uses same route as native'],'native_pair_scope':'Recorded prototype ordinary static/local benchmark branch, not exact integrated binary qualification. Fullmatrix acceptance remains open.','source_adopted':False}
(I/'scope.json').write_text(json.dumps(meta,indent=2)+'\n')
