"""Archive bounded checkpoint records, preserving raw bytes and source versions."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;out=W/'checkpoint-records.tar.gz';index=W/'archive-index.json'
assert not out.exists()and not index.exists()
files={}
for p in sorted(W.rglob('*')):
 if p.is_symlink():raise ValueError('unexpected record symlink '+str(p))
 if not p.is_file():continue
 rel=p.relative_to(W).as_posix()
 if p.name in ['grid-candidate','grid-diagnostic','grid-integrated','grid-integrated-diagnostic']or rel in ['archive-index.json','checkpoint-records.tar.gz']:continue
 if '__pycache__'in p.parts:continue
 assert p.stat().st_size<=16<<20,('record bound',rel,p.stat().st_size)
 files[rel]=p.read_bytes()
manifest={'schema':'vellum-grid-cell-surface-records-v1','source_root':str(W),'files':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}for k,v in files.items()},'excluded':'Four local native executable payloads (hashes/receipts retained); no SDK/vendor payload copied. No raw result or failed attempt relabeled.'}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with out.open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as tar:
 for name,data in files.items():
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.uid=item.gid=0;item.mtime=0;tar.addfile(item,io.BytesIO(data))
with tarfile.open(out,'r:gz')as tar:
 names=tar.getnames();assert set(names)==set(files)and len(names)==len(files)
 for member in tar:
  assert member.isfile()and not member.name.startswith('/')and '..'not in Path(member.name).parts
  assert tar.extractfile(member).read()==files[member.name]
d={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(files),'expanded_bytes':sum(map(len,files.values())),'manifest_sha256':hashlib.sha256(files['MANIFEST.json']).hexdigest(),'validated_every_member':True};index.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
