from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;I=W/'integration';sdk=Path(json.loads((W/'implementation-scope.json').read_text())['sdk']);s=importlib.util.spec_from_file_location('surface_final_diag_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
o=json.loads((I/'overlay.json').read_text());o['Replace'][str(sdk/'drivers/cogent/grid_geometry.go')]=str(W/'diagnostic-grid-geometry.go');p=W/'integrated-diagnostic-overlay.json';p.write_text(json.dumps(o,indent=2)+'\n')
paths=[x for x in I.rglob('*')if x.is_file()]+[p,W/'diagnostic-grid-geometry.go',Path(__file__),Path(h.__file__),Path(h.GUARD),h.GO];pins={str(x):h.sha(x)for x in paths}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','LANG':os.environ.get('LANG','en_US.UTF-8')}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),'build','-p=1','-overlay='+str(p),'-o',str(W/'grid-integrated-diagnostic'),'.']
def interrupt(signum,frame):raise InterruptedError('integrated diagnostic build signal '+str(signum))
old=signal.signal(signal.SIGTERM,interrupt)
try:
 r=h.g.execute(av,sdk/'examples/loadedgrid',W/'integrated-diag-build-v2',lambda:(W/'stop-integration').exists(),lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=600,limit=8<<20);r['source_pins']=pins;r['native_ui_executed']=False;(W/'integrated-diag-build-v2.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and r['owned']['errors']==[]else 1)
finally:signal.signal(signal.SIGTERM,old)
