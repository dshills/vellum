from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,time
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;W=Path('/private/tmp/vellum-shell-contrast-20261027')
sys.path.insert(0,str(R/'scripts'));from sdk_environment import child_environment
from child_process import run_child
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=Path('/private/tmp/vellum-v1-public-checks-20261027/public-sdk/vellum-v1.0.0');m=json.loads((S/'SDK_MANIFEST.json').read_text())
assert m['source']['commit']=='1fc594b6952d3b072a4c72b619a6f259da389474'
for n,h in m['files'].items():assert sha(S/n)==h,n
W.mkdir();stage=W/'sdk';shutil.copytree(S,stage)
main='examples/macapps/cmd/macshell/main.go';before=(stage/main).read_text();after=(R/main).read_text();assert before.replace('Width: 480, Height: 280, View:', 'Width: 480, Height: 280, Chrome: app.WindowChrome{Appearance: app.AppearanceLight}, View:')==after
shutil.copyfile(R/main,stage/main)
changed=[n for n,h in m['files'].items() if sha(stage/n)!=h];assert changed==[main],changed
native=stage/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a';assert sha(native)=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',GOTOOLCHAIN='local',GOWORK='off',CGO_LDFLAGS_ALLOW='-Wl,-rpath,@executable_path/native')
checks=[]
for name,cwd,args in [('shell-offscreen-compile',stage/'examples/macapps',['go','test','-mod=readonly','-race','-tags','offscreen','./cmd/macshell']),('shell-vet',stage/'examples/macapps',['go','vet','-mod=readonly','-tags','offscreen','./cmd/macshell']),('window-policy-regressions',stage,['go','test','-mod=readonly','-race','./app','-run','^TestWindowChrome']),('offscreen-native-policy-refusal',stage/'drivers/cogent',['go','test','-mod=readonly','-race','-tags','offscreen','.','-run','^TestManualRejectsNativeChromeBeforeWindowConstruction$'])]:
 start=time.monotonic()
 with (X/(name+'.stdout')).open('wb') as out,(X/(name+'.stderr')).open('wb') as err:p=run_child(args,cwd=cwd,env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=4<<20)
 record={'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)};checks.append(record);print(json.dumps(record),flush=True)
 assert p.returncode==0,(name,(X/(name+'.stderr')).read_text()[-1500:])
assert sha(R/main)==sha(stage/main)
result={'baseline_sdk_source':m['source'],'sdk_files_verified':len(m['files']),'changed_product_files':changed,'main_sha256':sha(stage/main),'native_archive_sha256':sha(native),'checks':checks,'features_unchanged':True,'global_settings_unchanged':True}
(X/'focused-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':True,'checks':len(checks)}))
