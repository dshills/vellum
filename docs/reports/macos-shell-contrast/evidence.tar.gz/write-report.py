from pathlib import Path
import json,hashlib,shutil,tarfile,gzip,io
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;D=X.parents[1]/'deliveries/macos-shell-contrast-20261027';O=R/'docs/reports/macos-shell-contrast';O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((X/'replacement-package.json').read_text());v=json.loads((X/'replacement-native.json').read_text())
for n in ['replacement-package.json','replacement-native.json']:shutil.copyfile(X/n,O/n)
shutil.copyfile(D/'SHA256SUMS',O/'SHA256SUMS');shutil.copyfile(R/'examples/macapps/cmd/macshell/main.go',X/'main-reviewed.go')
files=sorted(f for f in X.iterdir() if f.is_file() and f.suffix in {'.py','.json','.stdout','.stderr','.txt','.go'})+sorted((X/'native').iterdir())
index=[{'path':str(f.relative_to(X)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
with (O/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for f in files:
    b=f.read_bytes();m=tarfile.TarInfo(str(f.relative_to(X)));m.size=len(b);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(b))
(O/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(O/'evidence.tar.gz'),'members':index},indent=2)+'\n')
for src,dst in [('b-initial.jpg','shell-b.jpg'),('a-edited.jpg','shell-a.jpg')]:shutil.copyfile(X/'native'/src,O/dst)
(O/'README.md').write_text('''# Mac Shell contrast repair and replacement verification

**The fixed-light contrast defect is corrected and verified in the replacement.**
Both windows have readable dark labels on a light surface, including on the
observed dark-appearance desktop. Feature/API, backend and release/performance
policy are unchanged. The optional fixture still has a separate captured-window
exposure discrepancy described below; it remains out of the proposed upload set.

## Exact change and source

Fix commit: `'''+p['source_commit']+'''`.
Only `examples/macapps/cmd/macshell/main.go` changes executable behavior. Its
existing `ui.MacTheme(false)` is shared by the driver and root background; both
native windows explicitly select `app.AppearanceLight`. No system preference is
changed and no adaptive-theme feature is introduced. Per-window commands, PNG
artwork and lifecycle code are unchanged. [Fix review/checks](../../reviews/macos-shell-contrast/README.md).

The replacement builds from an isolated verified SDK copy (8,856 file identities),
with exactly that one product source file replaced by its committed bytes. All
'''+str(p['module_records_unchanged'])+''' module identities/origins and the source-built native archive
`'''+p['native_archive_sha256']+'''` are unchanged.
The actual external link map selects that archive; its full hash and matching
lines are retained. No other SDK/app candidate was rebuilt or overwritten.

## Replacement identity

- App version1.0.0, **build11**; previous held package was build10.
- Source executable SHA256: `'''+p['source_binary_sha256']+'''`.
- Signed executable SHA256: `'''+p['packaged_binary_sha256']+'''`.
- Notice inventory SHA256: `'''+p['notice_inventory_sha256']+'''`.
- ZIP SHA256: `'''+p['archive_sha256']+'''`.

The old/new pre-sign binary, inventory and archive identities are separately
recorded in [the package record](replacement-package.json). The 418 original
notice files, component references and collection labels are identical; only
inventory.artifact_sha256 changes to bind the new executable. The old inventory
correctly rejects this replacement executable. No new third-party material or
new rights grant is asserted. Historical exact-payload owner approval is unchanged
and is not relabeled as approval of these new archive bytes.

The unchanged public app producer accepts the existing release/native-audit and
clean-source guards with the exact new binary-bound notices. The manifest records
private_build=false, native_distribution_audit=approved, ad-hoc signing and
notarized=false; its audit declaration refers to the unchanged native/dependency
payload. This reviewed first-party correction and new artifact identities are an
explicit delta. Final-asset publication remains separately unapproved.

The durable replacement is in the research workspace's
`deliveries/macos-shell-contrast-20261027/`, with README, SHA256SUMS and manifest.
The original seven archives and their prior checksum lists remain unchanged.
Do not replace the old Shell ZIP without updating its filename/location/hash
references. No asset, tag, merge or signing identity was published/used here.

## Focused checks and native observations

Final Shell offscreen executable compilation/race wiring and vet pass. Existing
per-window policy ownership/validation and unsupported-native-chrome refusal
regressions pass. These are supporting automated checks; they do not emulate
native decoration. No broad qualification/performance campaign was rerun.

The new ZIP is extracted and strictly signature-verified, then copied without
extended attributes to an isolated launch path. Native accessibility actions and
unedited captures establish:

- B starts at0, its toolbar increments only B to1. Disabling editing makes B's
  native toolbar button unavailable; reenabling restores it.
- Closing B leaves A live at0. A's own toolbar increments A to1 and repaints A.
- B's initial content and A's post-command content visibly have correct contrast.
- Closing the last window retires the process, in both the main check and one
  bounded exposure control. No uncollected process exit code is claimed.
- After closure, strict signature, signed executable/manifest hashes, ZIP hash
  and all418 binary-bound notices still verify. All prior seven archive hashes
  remain unchanged.

![Corrected window B](shell-b.jpg)
![Corrected window A after its own toolbar command](shell-a.jpg)

[Native result](replacement-native.json) and [indexed raw evidence](evidence-index.json)
include all AX states/captures. These checks use native accessibility actions,
not physical mouse verification, human accessibility qualification or download/
quarantine acceptance. The current support and ad-hoc/unnotarized limits remain.

## Separate remaining exposure/capture discrepancy

After closing B, accessibility identifies A at0 while the capture retains B's
previous rendered content. A native Raise alone still captures B content in a
second bounded run. Executing A's own toolbar command produces correct A1 content.
Both windows' captured backgrounds/text have corrected contrast throughout.
The first `a-initial`/`a-current` captures are retained as discrepancies, not
misrepresented as correct A0 rendering. Only `a-edited.jpg` supports the A image above.

This evidence does not distinguish a presentation/exposure defect from a
computer-use capture issue. Record it as **unresolved**; full native exposure
acceptance is not claimed. The smallest next investigation is an app-restricted,
independent window-frame observation before and after expose/repaint, without
editing user data or changing global appearance. Do not expand this focused
contrast repair into a backend campaign. The optional fixture stays held from
public recommendation until the discrepancy is resolved or independently classified.

The prior [publication packet](../macos-v1-public-packaging/PUBLICATION_PACKET.md)
continues to recommend the unchanged SDK plus five other apps. Historical
contrast-failure evidence remains valid for its older binary. This replacement
resolves that contrast defect; no upload approval is implied for either ZIP.
''')
(D/'README.md').write_text('''# Vellum Mac Shell — contrast-corrected replacement

Version1.0.0 build11, source '''+p['source_commit']+'''.
Verify SHA256SUMS, extract Vellum Mac Shell.zip and open the app. Apps require
Apple Silicon macOS; this build is ad-hoc signed and unnotarized. Downloaded
quarantine/Gatekeeper behavior remains unqualified; no security bypass is part
of these instructions. No public asset upload has occurred.

Both windows explicitly use Light appearance and the matching light content
surface. Each Edit toolbar affects only its own in-memory document. Disable
editing toggles that window's toolbar availability. Close one window to keep the
other alive; closing the last exits. The app never opens personal notebooks.

Contrast, toolbar counters/availability and normal shutdown were verified in this
exact ZIP-extracted package. A separate unresolved exposure/capture discrepancy
remains: after closing B, captures can retain B content while accessibility
identifies A; A's toolbar action repaints correct A content. This optional fixture
is still held from the proposed public upload set until that discrepancy is
classified/resolved. Do not call this full multiwindow visual qualification.

The other SDK/app archives are unchanged. Historical build10 remains retained
with its original checksum and failure evidence. See the repository report
at docs/reports/macos-shell-contrast/README.md for exact checks and limitations.
''')
# Update only current status; preserve all historical packets/checksum lists.
f=R/'README.md';s=f.read_text().replace('The optional Mac Shell fixture\nis held for dark-appearance contrast.', 'A [contrast-corrected Mac Shell replacement](docs/reports/macos-shell-contrast/README.md)\nis verified locally; a separate exposure/capture discrepancy keeps that optional\nfixture outside the proposed public set.');f.write_text(s)
f=R/'docs/macos-v1.md';s=f.read_text().replace('the optional Mac Shell fixture\nis held for poor contrast in the observed dark appearance.', 'the optional Mac Shell fixture\nnow has a [contrast-corrected replacement](reports/macos-shell-contrast/README.md),\nwith a separate unresolved exposure/capture discrepancy. It remains outside the\nproposed public upload set.');f.write_text(s)
f=R/'docs/README.md';s=f.read_text().replace('- [Current macOS public packaging]', '- [Mac Shell contrast correction](reports/macos-shell-contrast/README.md): verified replacement, unchanged notices and a remaining exposure/capture discrepancy.\n- [Current macOS public packaging]');f.write_text(s)
f=R/'docs/reviews/macos-shell-contrast/README.md';s=f.read_text()+'''
The committed fix is repackaged as build11. Final extracted native checks verify
readable contrast in B and in A after its command repaint, independent document
counters, toolbar availability and normal final-window shutdown. Post-launch
signatures, notice bindings and archive hashes pass. A separate exposure/capture
mismatch is reproduced and explicitly retained as unresolved, so public upload
recommendation for this optional fixture remains held. No original archive,
audit approval, SDK or other app is changed. See the final report for identities.
''';f.write_text(s)
print(json.dumps({'evidence_members':len(index),'evidence_bytes':(O/'evidence.tar.gz').stat().st_size,'report':str(O)}))
