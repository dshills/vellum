"""Read bounded official upstream artifacts; never execute downloaded bytes."""
from pathlib import Path
import datetime,hashlib,json,sys,time,urllib.request
P=Path(__file__).resolve().parent
name,url,bound=sys.argv[1],sys.argv[2],int(sys.argv[3])
out=P/name
assert not out.exists() and not(P/(name+'.receipt.json')).exists()
start=time.monotonic();started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat();size=0;error=None;code=None;effective=None
try:
 request=urllib.request.Request(url,headers={'User-Agent':'Vellum-distribution-provenance','Accept':'application/vnd.github+json' if 'api.github.com' in url else 'application/octet-stream'})
 with urllib.request.urlopen(request,timeout=10)as source:
  code=source.status;effective=source.url.split('?',1)[0]
  with out.open('xb')as dest:
   while data:=source.read(65536):
    size+=len(data)
    if size>bound or time.monotonic()-start>25:raise ValueError('download exceeds byte/time bound')
    dest.write(data)
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
record={'url':url,'effective_url':effective,'http_status':code,'started_utc':started_utc,'elapsed_seconds':time.monotonic()-start,'downloaded_bytes':out.stat().st_size if out.exists()else 0,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()if out.exists()else None,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'error':error,'downloaded_code_executed':False}
(P/(name+'.receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(0 if error is None else 1)
