"""Verify downloaded native artifacts and inspect the twelve pinned font inputs."""
from pathlib import Path
import hashlib,json,re,struct,tomllib,zipfile
P=Path(__file__).resolve().parent
C=Path('/Users/dshills/Development/projects/Vellum')
R=Path('/private/tmp/vellum-font-notices')
sha=lambda b:hashlib.sha256(b).hexdigest()
for receipt in P.glob('*.receipt.json'):
 d=json.loads(receipt.read_text());path=P/receipt.name.removesuffix('.receipt.json')
 assert d['error'] is None and d['http_status']==200 and d['downloaded_bytes']==path.stat().st_size and d['sha256']==sha(path.read_bytes())
 assert d['producer_sha256']==sha((P/'fetch.py').read_bytes()) and not d['downloaded_code_executed']
release=json.loads((P/'upstream-release.json').read_text());assets={a['name']:a for a in release['assets']}
assert release['tag_name']=='v29.0.1.1' and release['immutable']
for name in ['commit-sha','wgpu-macos-aarch64-release.zip']:
 assert assets[name]['size']==(P/name).stat().st_size and assets[name]['digest']=='sha256:'+sha((P/name).read_bytes())
commit=(P/'commit-sha').read_text().strip();assert re.fullmatch('[a-f0-9]{40}',commit)
tree=json.loads((P/'source-tree.json').read_text());assert tree['sha']==commit and not tree['truncated']
nodes={n['path']:n for n in tree['tree']}
source_files={}
for name in ['Cargo.lock','Cargo.toml','LICENSE.APACHE','LICENSE.MIT']:
 b=(P/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==nodes[name]['sha']
 source_files[name]={'sha256':sha(b),'git_blob':nodes[name]['sha'],'bytes':len(b)}
lock=tomllib.loads((P/'Cargo.lock').read_text());manifest=tomllib.loads((P/'Cargo.toml').read_text())
assert manifest['package']['license']=='MIT OR Apache-2.0'
native=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu/libs-darwin@v0.0.0-20260628152755-66a5dfa57f8d/arm64/libwgpu_native.a')
native_bytes=native.read_bytes()
with zipfile.ZipFile(P/'wgpu-macos-aarch64-release.zip')as z:
 infos=z.infolist();assert len(infos)<=128 and len({i.filename for i in infos})==len(infos)
 lib=z.getinfo('lib/libwgpu_native.a');assert 0<lib.file_size<64<<20
 assert z.read(lib)==native_bytes
 assert z.read('wgpu-native-meta/wgpu-native-git-tag').decode().strip()=='v29.0.1.1'
noto=json.loads((P/'noto-release.json').read_text());noto_tree=json.loads((P/'noto-source-tree.json').read_text())
assert noto['tag_name']=='NotoSans-v2.015' and noto['target_commitish']==noto_tree['sha'] and not noto_tree['truncated']
ofl=(P/'NotoSans-OFL.txt').read_bytes();ofl_node=next(n for n in noto_tree['tree']if n['path']=='OFL.txt')
assert hashlib.sha1(b'blob '+str(len(ofl)).encode()+b'\0'+ofl).hexdigest()==ofl_node['sha']
assert (R/'drivers/cogent/build/upstream/text/fonts/noto/OFL.txt').read_bytes()==ofl

fonts=[]
for family in ['noto','robotomono']:
 for path in sorted((C/'drivers/cogent/build/upstream/text/fonts'/family).glob('*.ttf')):
  b=path.read_bytes();assert 12<=len(b)<1<<20 and b[:4]==b'\0\1\0\0'
  count=struct.unpack_from('>H',b,4)[0];assert count<=128 and 12+count*16<=len(b)
  tables=[]
  for i in range(count):
   tag,checksum,offset,length=struct.unpack_from('>4sIII',b,12+i*16)
   assert offset+length<=len(b)
   if tag==b'name':tables.append(b[offset:offset+length])
  assert len(tables)==1
  names=tables[0];version,count,storage=struct.unpack_from('>HHH',names)
  assert version==0 and count<=1000 and 6+count*12<=storage<=len(names)
  entries=[]
  for i in range(count):
   platform,encoding,language,kind,size,offset=struct.unpack_from('>6H',names,6+i*12)
   assert storage+offset+size<=len(names)
   if platform!=3 or encoding not in [1,10] or kind not in [0,1,5,13,14]:continue
   value=names[storage+offset:storage+offset+size].decode('utf-16-be')
   entries.append({'platform':platform,'encoding':encoding,'language':language,'name_id':kind,'value':value})
  relative=path.relative_to(C/'drivers/cogent/build/upstream').as_posix()
  assert (R/'drivers/cogent/build/upstream'/relative).read_bytes()==b
  if family=='noto':
   assert any(e['name_id']==5 and e['value']=='Version 2.015'for e in entries)
   assert any(e['name_id']==0 and e['value']==ofl.decode().splitlines()[0]for e in entries)
  fonts.append({'file':relative,'bytes':len(b),'sha256':sha(b),'windows_unicode_name_records':entries,'scope':'Selected Windows Unicode name-table strings, not a general font parser or source-lineage attestation.'})
assert len(fonts)==12
q={'result':'VERIFIED_UPSTREAM_NATIVE_BYTE_MATCH_AND_FONT_NOTICE_INPUTS','native_release_id':release['id'],'native_tag':release['tag_name'],'native_source_revision_declared_by_release':commit,'source_revision_independently_rebuilt':False,'release_asset':{'url':assets['wgpu-macos-aarch64-release.zip']['browser_download_url'],'bytes':(P/'wgpu-macos-aarch64-release.zip').stat().st_size,'sha256':sha((P/'wgpu-macos-aarch64-release.zip').read_bytes()),'published_github_digest_matches':True},'native_archive':{'module':'github.com/oliverbestmann/webgpu/libs-darwin','version':'v0.0.0-20260628152755-66a5dfa57f8d','file':'arm64/libwgpu_native.a','bytes':len(native_bytes),'sha256':sha(native_bytes),'upstream_zip_member':'lib/libwgpu_native.a','bytes_equal':True},'source_declarations':source_files,'cargo_lock_package_records':len(lock['package']),'cargo_lock_packages':[{k:x[k]for k in ['name','version','source','checksum']if k in x}for x in lock['package']],'selected_compiled_crates_or_features_qualified':False,'signature_or_attestation_verified':False,'noto_notice':{'source_revision':noto_tree['sha'],'url':'https://github.com/notofonts/latin-greek-cyrillic/blob/'+noto_tree['sha']+'/OFL.txt','bytes':len(ofl),'sha256':sha(ofl),'git_blob':ofl_node['sha'],'historical_subset_lineage_verified':False},'font_inputs':fonts,'distribution_audit':'pending','runtime_executed':False,'analyzer_sha256':sha(Path(__file__).read_bytes())}
(P/'summary.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({k:q[k]for k in ['result','native_release_id','cargo_lock_package_records','distribution_audit','runtime_executed']}))
