VERIFIED_SCOPED_UPSTREAM_BINDINGS

Official recorded asset digests, Git blob identities and the selected arm64 library byte comparison reconcile. All six retained Noto faces carry Version2.015/copyright2022 matching the fetched exact OFL header. The current notice collector excludes OFL.txt.

The proposed verbatim supplemental-notice patch is appropriately scoped if module-own-license and public distribution/audit gates remain unchanged. Cargo lock records identify dependency versions, not compiled features or selected linked components. Font metadata does not prove exact subset lineage. No legal, signature or reproducible-build clearance; no network/native/test/provider activity was performed. Exact reviewed hashes are in provenance-review.json.
