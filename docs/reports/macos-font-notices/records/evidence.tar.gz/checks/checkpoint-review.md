APPROVED_SOURCE_AND_EVIDENCE — ten final source/report hashes; no unresolved findings.

Stable final nine-source tests and private SDKv2/relocation receipts reconcile. Preparation preserves6216 leaves and adds only the exact notice; both SDK OFL copies match. The original collector fails the intended assertion. The report was added after the code/SDK endpoint, and earlier eight-source evidence stays historical.

Notice preservation and artifact identity are scoped facts. Rights/distribution, signatures, reproducible build, crate-feature closure, font lineage, native runtime and full Mac acceptance remain unapproved. Provider review and archive records are separate before-commit gates. The nine-source certificate is unchanged.
