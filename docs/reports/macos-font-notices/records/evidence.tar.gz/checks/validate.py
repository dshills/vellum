"""Verify scoped notice preparation, code-only gates and private SDK contents."""
from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-font-notices');P=Path(__file__).resolve().parent
U=Path('/private/tmp/vellum-macos-upstream-provenance')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and not review['unresolved_findings']
sources=review['sources'];assert len(sources)==9 and all(sha(R/n)==h for n,h in sources.items())
receipts={}
for name,argv in {
 'preparation-tests':['python3','prepare_test.py'],
 'release-final':['python3','scripts/release-sdk_test.py'],
 'inventory-final':['python3','scripts/distribution-inventory_test.py'],
 'checker-final':['python3','scripts/check-sdk_test.py'],
 'produce-v2':['python3','scripts/release-sdk.py','--output',str(P/'vellum-sdk-v2.tar.gz')],
 'relocate-v2':['python3','scripts/check-sdk.py','--archive',str(P/'vellum-sdk-v2.tar.gz'),'--sha256','1462bc20d96ed1206ddafa5200e0ba07de42b5f30ab77edf53652dc282a9a86f'],
}.items():
 f=P/(name+'.json');d=json.loads(f.read_text())
 assert d['argv']==argv and d['exit_code']==0 and d['error']is None
 assert d['cwd']==str(R/'drivers/cogent'if name=='preparation-tests'else R)
 assert d['source_commit']=='eba38f14a96fb7b8e44612dc922a07793d3a5724'and not d['live_tests']and not d['headless_gpu_requested']
 assert d['producer_sha256']==sha(P/'code_run.py')and d['source_delta_stable']and d['source_delta_before']==d['source_delta_after']==sources
 assert len(d['prepared_after'])==6217 and d['prepared_before']==d['prepared_after']and not d['overlay_inputs_before']and not d['overlay_inputs_after']
 for c in ['stdout','stderr']:assert d[c+'_sha256']==sha(P/(name+'.'+c))
 receipts[name]={'sha256':sha(f),'elapsed_seconds':d['elapsed_seconds']}
prepare=json.loads((P/'prepare.json').read_text());before=prepare['prepared_before'];after=prepare['prepared_after'];notice='upstream/text/fonts/noto/OFL.txt'
assert prepare['exit_code']==0 and prepare['error']is None and prepare['source_delta_stable']and prepare['producer_sha256']==sha(P/'code_run-v1.py')
assert len(before)==6216 and len(after)==6217 and set(after)-set(before)=={notice}and all(after[n]==h for n,h in before.items())
assert after==json.loads((P/'relocate-v2.json').read_text())['prepared_after']
for n,h in prepare['source_delta_after'].items():assert sources[n]==h
fault=json.loads((P/'original-collector-fault.json').read_text());assert fault['result']=='EXPECTED_ORIGINAL_COLLECTOR_FAILURE'and fault['exit_code']==1 and fault['sources_unchanged']
assert fault['producer_sha256']==sha(P/'fault.py')and fault['baseline_collector_sha256']==sha(P/'release-sdk-baseline.py')
for c in ['stdout','stderr']:assert fault[c+'_sha256']==sha(P/('original-collector-fault.'+c))
sdk=P/'vellum-sdk-v2.tar.gz';digest=sha(sdk);assert digest=='1462bc20d96ed1206ddafa5200e0ba07de42b5f30ab77edf53652dc282a9a86f'
produced=json.loads((P/'produce-v2.stdout').read_text());relocated=json.loads((P/'relocate-v2.stdout').read_text())
assert produced['sha256']==digest and produced['private_build']and relocated['native_runtime']=='not executed'and relocated['public_distribution_audit']=='not certified'
expected=(U/'NotoSans-OFL.txt').read_bytes()
with tarfile.open(sdk,'r:gz')as t:
 names=t.getnames();manifest_name=next(n for n in names if n.endswith('/SDK_MANIFEST.json'));prefix=manifest_name.removesuffix('SDK_MANIFEST.json')
 manifest_bytes=t.extractfile(manifest_name).read();manifest=json.loads(manifest_bytes)
 assert manifest['private_build']and not manifest['source']['clean']and manifest['source']['commit']=='eba38f14a96fb7b8e44612dc922a07793d3a5724'
 copies=[n for n in names if n.endswith('/text/fonts/noto/OFL.txt')];assert len(copies)==2
 for n in copies:assert t.extractfile(n).read()==expected and manifest['files'][n.removeprefix(prefix)]==hashlib.sha256(expected).hexdigest()
 inventory=t.extractfile(prefix+'THIRD_PARTY_INVENTORY.json').read();notices=json.loads(inventory)
 assert notices['distribution_audit']=='pending'
 core=next(x for x in notices['modules']if x['module']=='cogentcore.org/core')
 assert any(n['file']=='text/fonts/noto/OFL.txt'for n in core['license_files'])
 (P/'sdk-manifest.json').write_bytes(manifest_bytes);(P/'third-party-inventory.json').write_bytes(inventory)
upstream=json.loads((U/'summary.json').read_text());assert upstream['result']=='VERIFIED_UPSTREAM_NATIVE_BYTE_MATCH_AND_FONT_NOTICE_INPUTS'and upstream['distribution_audit']=='pending'and not upstream['runtime_executed']
summary={'result':'PASS_SCOPED_FONT_NOTICE_RESTORATION','base_commit':'eba38f14a96fb7b8e44612dc922a07793d3a5724','sources':sources,'prepared_before':6216,'prepared_after':6217,'changed_existing_prepared_files':0,'added_notice':notice,'notice_sha256':hashlib.sha256(expected).hexdigest(),'sdk_sha256':digest,'sdk_bytes':sdk.stat().st_size,'sdk_manifest_files':len(manifest['files']),'sdk_notice_copies':copies,'checks':receipts,'original_collector_fault':'EXPECTED_FAILURE','upstream_summary_sha256':sha(U/'summary.json'),'source_review_sha256':sha(P/'source-review.json'),'validator_sha256':sha(__file__),'distribution_audit':'pending','native_runtime_executed':False,'full_mac_qualified':False,'scope':'Notice-only native patch and supplementalOFL discovery; no font/embed/runtime implementation bytes changed. Exact upstream nativearchive byte match is separate from source-build/crate-feature/signature provenance. Noto source notice matches embeddedcopyright/version, without reconstructing subset lineage. PrivateSDK captures the nine-source pre-report endpoint, not a future commit.'}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k]for k in ['result','prepared_after','sdk_manifest_files','sdk_bytes','distribution_audit','native_runtime_executed']}))
