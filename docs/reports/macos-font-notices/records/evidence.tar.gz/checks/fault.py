"""Run the new nested-OFL regression against the unchanged baseline collector."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-font-notices');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert (P/'release-sdk-baseline.py').read_bytes()==subprocess.check_output(['git','show','HEAD:scripts/release-sdk.py'],cwd=R)
code="""import importlib.util,sys,unittest
from pathlib import Path
sys.path.insert(0,sys.argv[1])
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
test=load('notice_tests',Path(sys.argv[1])/'release-sdk_test.py')
test.release=load('original_release',sys.argv[2])
suite=unittest.TestSuite([test.ReleaseChecks('test_font_ofl_notice_is_copied_without_granting_module_license')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
"""
argv=[sys.executable,'-c',code,str(R/'scripts'),str(P/'release-sdk-baseline.py')]
before={n:sha(R/n)for n in ['scripts/release-sdk.py','scripts/release-sdk_test.py']}
started=time.monotonic()
with(P/'original-collector-fault.stdout').open('xb')as so,(P/'original-collector-fault.stderr').open('xb')as se:
 result=run_child(argv,cwd=R,env=child_environment(),stdout=so,stderr=se,timeout=60)
after={n:sha(R/n)for n in before}
stderr=(P/'original-collector-fault.stderr').read_text()
assert result.returncode==1 and 'AssertionError: Lists differ: [] != [\'fonts/noto/OFL.txt\']'in stderr and before==after
receipt={'result':'EXPECTED_ORIGINAL_COLLECTOR_FAILURE','exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started,'argv':argv,'sources':before,'sources_unchanged':before==after,'baseline_collector_sha256':sha(P/'release-sdk-baseline.py'),'stdout_sha256':sha(P/'original-collector-fault.stdout'),'stderr_sha256':sha(P/'original-collector-fault.stderr'),'producer_sha256':sha(__file__),'runtime_executed':False}
(P/'original-collector-fault.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k]for k in ['result','exit_code','elapsed_seconds','sources_unchanged']}))
