"""Source-bound inert native-harness overlay tests; no window fixture launch."""
from pathlib import Path
import datetime,hashlib,json,sys,time
P=Path(__file__).resolve().parent;B=Path('/private/tmp/vellum-macos-post-loop-native');R=Path('/Users/dshills/Development/projects/Vellum');sys.path.insert(0,str(B));import native_common as c
sha=c.sha
source={name:sha(P/name)for name in ['soak.go','soak_failure.go','soak_failure_test.go','overlay.json','run_checks.py']}
manifest=c.read(B/'binaries.json');c.current_identity(manifest['source_identity'])
for name,h in source.items():
 f=P/name;dest=P/'producers'/(h+f.suffix);dest.parent.mkdir(exist_ok=True)
 if not dest.exists():
  with dest.open('xb')as out:out.write(f.read_bytes())
commands={'race':['go','test','-race','-p=1','-count=1','-tags=vellum_native_checks','-overlay='+str(P/'overlay.json'),'./cmd/window-cycle-smoke'],'vet':['go','vet','-p=1','-tags=vellum_native_checks','-overlay='+str(P/'overlay.json'),'./cmd/window-cycle-smoke']}
env=c.child_environment();env.update(GOMAXPROCS='2',GOPROXY='off')
for name,argv in commands.items():
 start=time.monotonic();record={'argv':argv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'source_commit':manifest['source_commit'],'exit_code':None,'error':None,'inert_native_harness_tests':True,'native_window_fixture_executed':False}
 try:
  with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:r=c.run_child(argv,cwd=R/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=180,log_limit_bytes=2<<20);record['exit_code']=r.returncode
 except BaseException as e:record['error']={'type':type(e).__name__,'message':str(e)}
 record.update(elapsed_seconds=time.monotonic()-start,source_stable=all(sha(P/n)==h for n,h in source.items()),logs={ch:{'sha256':sha(P/(name+'.'+ch)),'bytes':(P/(name+'.'+ch)).stat().st_size}for ch in ['stdout','stderr']})
 with(P/(name+'.json')).open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_stable']}),flush=True)
 assert record['exit_code']==0 and record['error']is None and record['source_stable']
c.current_identity(manifest['source_identity'])
