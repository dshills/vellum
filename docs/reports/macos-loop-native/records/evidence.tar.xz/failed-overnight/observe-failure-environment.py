"""Bounded read-only power events and fresh retirement check after owned failure."""
from pathlib import Path
import datetime,hashlib,json,sys,time
B=Path('/private/tmp/vellum-macos-post-loop-native');P=Path('/private/tmp/vellum-macos-soak-cover');D=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-soak-cover/overnight-failure')
sys.path.insert(0,str(B));import native_common as c
sha=c.sha
need=c.need
need(c.read(P/'soak-overnight.json')['exit_code']==1,'original native terminal failure')
observation=c.group_absent(15600)
commands={'powerd':(['/usr/bin/log','show','--style','json','--timezone','UTC','--start','2026-10-16 03:42:00+0000','--end','2026-10-16 03:46:00+0000','--predicate','process == "powerd" AND (eventMessage CONTAINS[c] "display" OR eventMessage CONTAINS[c] "sleep" OR eventMessage CONTAINS[c] "wake")'],30),'power-settings':(['/usr/bin/pmset','-g','custom'],10)}
result={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':sha(__file__),'owned_group_absence':observation,'commands':{},'settings_changed':False,'native_application_executed':False,'causal_failure_attribution_established':False}
for name,(argv,timeout)in commands.items():
 d={'argv':argv,'timeout_seconds':timeout,'exit_code':None,'error':None};start=time.monotonic()
 try:
  with(D/(name+'.stdout')).open('xb')as out,(D/(name+'.stderr')).open('xb')as err:
   r=c.run_child(argv,env=c.child_environment(),stdout=out,stderr=err,timeout=timeout,log_limit_bytes=2<<20);d['exit_code']=r.returncode
 except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)}
 d.update(elapsed_seconds=time.monotonic()-start,logs={ch:{'sha256':sha(D/(name+'.'+ch)),'bytes':(D/(name+'.'+ch)).stat().st_size}for ch in ['stdout','stderr']});result['commands'][name]=d
with(D/'environment-observation.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
with(D/'observe-failure-environment.py').open('xb')as out:out.write(Path(__file__).read_bytes())
print(json.dumps(result))
