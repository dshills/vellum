"""Retain the original failed executable privately without launching it."""
from pathlib import Path
import datetime,hashlib,json,shutil
P=Path(__file__).resolve().parent
source=Path('/private/tmp/vellum-macos-soak-cover/window-cycle-v2')
target=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-soak-cover/overnight-failure-bin/window-cycle-v2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected='9fb6b4be4b3c9617fe8ea00b4b3d3a96f6595bc6071094acc95c520acb72e931'
assert sha(source)==expected and source.stat().st_size==60201762
target.parent.mkdir(parents=True,exist_ok=True)
with source.open('rb') as inp,target.open('xb') as out:
    shutil.copyfileobj(inp,out,length=1<<20)
target.chmod(0o755)
assert sha(target)==expected
with (P/'failed-binary-preservation.json').open('x') as out:
    out.write(json.dumps({'source':str(source),'durable':str(target),'sha256':expected,
        'bytes':target.stat().st_size,'producer_sha256':sha(Path(__file__)),
        'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'native_application_executed':False},indent=2)+'\n')
print('Preserved original failed executable; no execution.')
