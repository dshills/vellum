"""Commit reviewed checkpoint and fast-forward clean canonical checkout only."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys, time
P=Path(__file__).resolve().parent
R=Path('/private/tmp/vellum-soak-diagnostics-checkpoint')
C=Path('/Users/dshills/Development/projects/Vellum')
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-loop-native')
D=R/'docs/reports/macos-loop-native/records'
BASE='82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment

def git(root,*args):
    completed=run_child(['git','-c','gc.auto=0','-C',str(root),*args],
        env=child_environment(),capture_output=True,timeout=60)
    assert completed.returncode==0,completed.stderr
    return completed.stdout.decode().strip()

def tracked(root):
    return {n:sha(root/n) for n in git(root,'ls-files').splitlines()}

def prepared(root):
    return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)
        for name in ['upstream','typesetting']
        for f in sorted((root/'drivers/cogent/build'/name).rglob('*')) if f.is_file()}

review=read(P/'final-review.json');qualification=read(D/'qualification.json')
assert review['commit_ready'] is True and not review['unresolved_findings']
assert review['promotion_producer_sha256']==sha(Path(__file__))
assert qualification['result']=='PASS_SCOPED_NATIVE_FOLLOWUPS_AND_DIAGNOSTIC_SOURCE'
assert not any(qualification[k] for k in ['original_overnight_qualified','diagnostic_native_event_qualified',
    'full_idle_budget_qualified','causal_performance_gain_qualified','ordinary_warm_targets_qualified','full_p11_qualified','full_mac_qualified'])
assert sha(D/'evidence.tar.xz')==qualification['archive_sha256']
assert sha(D/'archive-index.json')==qualification['archive_index_sha256']
build=read(P/'diagnostic-build.json')
assert sha(P/'diagnostic-build.json')==qualification['integrated_checks']['diagnostic-build']['receipt_sha256']
assert build['exit_code']==0 and build['error'] is None and build['sources_stable']
binary=P/'window-cycle-diagnostics'
assert build['binary']['path']==str(binary)
assert binary.stat().st_size==build['binary']['bytes'] and sha(binary)==build['binary']['sha256']
build_sha256=sha(P/'diagnostic-build.json')
expected=set(qualification['checkpoint_sources'])|{'docs/reports/macos-loop-native/records/'+n
    for n in ['qualification.json','evidence.tar.xz','archive-index.json']}
assert len(expected)==11 and set(review['sources'])==expected
assert all(sha(R/n)==h for n,h in review['sources'].items())
assert git(R,'rev-parse','HEAD')==git(C,'rev-parse','HEAD')==BASE
assert not git(C,'status','--porcelain')
assert git(C,'symbolic-ref','--short','HEAD')=='codex/foundation-completion'
changes=set(git(R,'diff','HEAD','--name-only').splitlines())|set(git(R,'ls-files','--others','--exclude-standard').splitlines())
assert changes==expected
before=tracked(C)
manifest=read(Path('/private/tmp/vellum-macos-post-loop-native/binaries.json'))
assert before==manifest['source_identity']['tracked']
dependency=prepared(C)
assert dependency==manifest['source_identity']['prepared']==prepared(R) and len(dependency)==6229
marker=Path('/private/tmp/vellum-macos-quiet-current/stop-live')
assert sha(marker)=='db5c4df12d8f08cedc63b39d7998a963aa1ca313aaa3b5a434ad64836064164f'
git(R,'diff','--check');git(R,'add','--',*sorted(expected));git(R,'diff','--cached','--check')
assert set(git(R,'diff','--cached','--name-only').splitlines())==expected
O.mkdir(parents=True,exist_ok=True)
receipt=O/'canonical-promotion.json'
with receipt.open('x') as out:
    out.write('{}\n')
record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':BASE,'changed_files':sorted(expected),
    'final_review_sha256':sha(P/'final-review.json'),'producer_sha256':sha(Path(__file__)),
    'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'native_application_executed':False,'prepared_source_changed':False}
start=time.monotonic()
try:
    git(R,'commit','-m','test(macos): qualify native loop and preserve soak failures')
    commit=git(R,'rev-parse','HEAD');record['commit']=commit
    assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,BASE]
    assert not git(R,'status','--porcelain')
    assert set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==expected
    final={**before,**review['sources']}
    assert tracked(R)==final
    assert git(C,'rev-parse','HEAD')==BASE and not git(C,'status','--porcelain') and tracked(C)==before
    assert prepared(C)==dependency
    git(C,'fetch',str(R),commit)
    assert git(C,'rev-parse','FETCH_HEAD')==commit
    git(C,'merge','--ff-only','FETCH_HEAD')
    assert git(C,'rev-parse','HEAD')==commit and not git(C,'status','--porcelain')
    assert tracked(C)==final and prepared(C)==dependency
    assert sha(marker)=='db5c4df12d8f08cedc63b39d7998a963aa1ca313aaa3b5a434ad64836064164f'
    for source in [*P.rglob('*'),*D.iterdir()]:
        if not source.is_file() or '__pycache__' in source.parts or source.name=='window-cycle-diagnostics':
            continue
        rel=Path('records')/source.name if source.parent==D else Path('private-evidence')/source.relative_to(P)
        target=O/rel;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out:
            out.write(source.read_bytes())
        assert sha(target)==sha(source)
    assert sha(P/'diagnostic-build.json')==build_sha256
    assert binary.stat().st_size==build['binary']['bytes'] and sha(binary)==build['binary']['sha256']
    target=O/'bin/window-cycle-diagnostics'
    target.parent.mkdir(exist_ok=True)
    with target.open('xb') as out:
        out.write(binary.read_bytes())
    target.chmod(0o755)
    assert sha(target)==build['binary']['sha256']
    record.update(result='PASS_CANONICAL_PROMOTION',canonical_clean=True,tracked_files=len(final),
        prepared_files=len(dependency),tracked_exact=True,prepared_exact=True,
        archive_sha256=sha(D/'evidence.tar.xz'),durable_evidence_exact=True)
except BaseException as error:
    record.update(result='FAILED_CANONICAL_PROMOTION',error={'type':type(error).__name__,'message':str(error)})
    raise
finally:
    record['elapsed_seconds']=time.monotonic()-start
    record['terminal_observation_errors']=[]
    for key,args in [('observed_head',['rev-parse','HEAD']),('observed_status',['status','--porcelain'])]:
        try:
            record[key]=git(C,*args)
        except BaseException as error:
            detail={'observation':key,'type':type(error).__name__,'message':str(error)}
            record['terminal_observation_errors'].append(detail)
            record['result']='FAILED_CANONICAL_PROMOTION'
            if 'error' not in record:
                record['error']=detail
    receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
assert record['result']=='PASS_CANONICAL_PROMOTION'
