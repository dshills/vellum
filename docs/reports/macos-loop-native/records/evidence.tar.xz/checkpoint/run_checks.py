"""Bounded inert checks on the integrated diagnostic checkpoint; no live app."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time
R = Path('/private/tmp/vellum-soak-diagnostics-checkpoint')
P = Path(__file__).resolve().parent
sys.path.insert(0, str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def source():
    names = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=R, timeout=10).decode().split('\0'))
    names.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=R, timeout=10).decode().split('\0'))
    return {n: sha(R/n) for n in sorted(names) if n}

before = source()
prepared = {p.relative_to(R/'drivers/cogent/build').as_posix(): sha(p)
            for name in ['upstream', 'typesetting']
            for p in sorted((R/'drivers/cogent/build'/name).rglob('*')) if p.is_file()}
manifest = json.loads(Path('/private/tmp/vellum-macos-post-loop-native/binaries.json').read_text())
assert prepared == manifest['source_identity']['prepared'] and len(prepared) == 6229
env = child_environment()
env.update(GOMAXPROCS='2', GOPROXY='off', GOCACHE='/Users/dshills/Library/Caches/go-build',
           GOMODCACHE='/Users/dshills/Development/Go/pkg/mod', GOPATH='/Users/dshills/Development/Go')
commands = {
    'integrated-race': ['go','test','-race','-p=1','-count=1','-tags=vellum_native_checks','./cmd/window-cycle-smoke'],
    'integrated-vet': ['go','vet','-p=1','-tags=vellum_native_checks','./cmd/window-cycle-smoke'],
    'diagnostic-build': ['go','build','-p=1','-trimpath','-tags=vellum_native_checks','-o',str(P/'window-cycle-diagnostics'),'./cmd/window-cycle-smoke']}
for name, argv in commands.items():
    record = {'argv': argv, 'cwd': str(R/'drivers/cogent'), 'sources': before,
              'prepared_files': len(prepared), 'producer_sha256': sha(Path(__file__)),
              'base_commit': manifest['source_commit'], 'native_application_executed': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exit_code': None, 'error': None}
    start = time.monotonic()
    try:
        with (P/(name+'.stdout')).open('xb') as out, (P/(name+'.stderr')).open('xb') as err:
            record['exit_code'] = run_child(argv, cwd=R/'drivers/cogent', env=env,
                stdout=out, stderr=err, timeout=180, log_limit_bytes=2<<20).returncode
        if name == 'diagnostic-build' and record['exit_code'] == 0:
            binary = P/'window-cycle-diagnostics'
            record['binary'] = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary)}
    except BaseException as error:
        record['error'] = {'type': type(error).__name__, 'message': str(error)}
    record.update(elapsed_seconds=time.monotonic()-start, sources_stable=source()==before,
                  logs={ch: {'sha256': sha(P/(name+'.'+ch)), 'bytes': (P/(name+'.'+ch)).stat().st_size}
                        for ch in ['stdout', 'stderr']})
    with (P/(name+'.json')).open('x') as out:
        out.write(json.dumps(record, indent=2)+'\n')
    print(json.dumps({k: record[k] for k in ['exit_code','error','elapsed_seconds','sources_stable']}), flush=True)
    assert record['exit_code'] == 0 and record['error'] is None and record['sources_stable']
