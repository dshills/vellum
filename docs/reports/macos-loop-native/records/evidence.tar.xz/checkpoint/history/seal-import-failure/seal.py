"""Archive actual scoped evidence; failed overnight remains a failed result."""
from pathlib import Path
import datetime, hashlib, importlib.util, io, json, subprocess, tarfile
P=Path(__file__).resolve().parent
R=Path('/private/tmp/vellum-soak-diagnostics-checkpoint')
C=Path('/Users/dshills/Development/projects/Vellum')
B=Path('/private/tmp/vellum-macos-post-loop-native')
M=Path('/private/tmp/vellum-macos-post-loop-measurements')
F=Path('/private/tmp/vellum-soak-drift-diagnostics')
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts')
D=R/'docs/reports/macos-loop-native/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

review=read(P/'checkpoint-source-review.json')
assert review['prism_ready'] and not review['unresolved_findings']
assert all(sha(R/n)==h for n,h in review['sources'].items())
assert {'prism_run.py','seal.py','promote.py'}<=set(review['reviewed_producers'])
assert all(sha(P/n)==h for n,h in review['reviewed_producers'].items() if n!='seal.py')
assert sha(P/'history/prism-zero-discard-only/seal.py')==review['reviewed_producers']['seal.py']
post=read(P/'post-provider-seal-review.json')
assert post['seal_ready'] is True and not post['unresolved_findings']
assert post['seal_producer_sha256']==sha(Path(__file__))
assert post['source_review_sha256']==sha(P/'checkpoint-source-review.json')
assert post['provider_resolution_sha256']==sha(P/'provider-resolution.json')
prism=read(P/'prism.json'); execution=read(P/'prism-execution.json')
assert execution['exit_code']==0 and execution['error'] is None and execution['sources_stable']
assert execution['sources']==review['sources'] and execution['json_sha256']==sha(P/'prism.json')
assert execution['review_sha256']==sha(P/'checkpoint-source-review.json')
assert execution['producer_sha256']==sha(P/'prism_run.py')
assert execution['staged_sources']==review['sources'] and execution['staged_sources_stable'] and execution['staged_diff_stable']
assert execution['staged_diff_sha256']==sha(P/'prism-staged.diff')
assert hashlib.sha256(subprocess.check_output(['git','diff','--cached','--binary'],cwd=R,timeout=10)).hexdigest()==execution['staged_diff_sha256']
for channel in ['stdout','stderr']:
    assert execution[channel+'_sha256']==sha(P/('prism.'+channel))
coverage=prism['coverage']
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert coverage['complete'] and coverage['llmCalls']==coverage['chunks']==1
assert coverage['files']==len(review['sources'])
assert not any([prism['findings'],prism['suppressed'],coverage['excluded'],coverage['skipped'],coverage['truncatedBytes']])
resolution=read(P/'provider-resolution.json')
assert resolution['source_changed'] is False and not resolution['unresolved_blocking_findings']
assert resolution['prism_report_sha256']==sha(P/'prism.json')
assert resolution['prism_execution_sha256']==sha(P/'prism-execution.json')
assert resolution['discarded_findings']==prism['discarded'] and len(prism['discarded'])==1
item=prism['discarded'][0]['finding']
assert item['severity']=='low' and item['category']=='style' and item['title']=='Typo in error message'
assert resolution['disposition']=='ACCEPTED_NONBLOCKING_COSMETIC'
evidence=read(F/'evidence-review.json')
assert evidence['result']=='APPROVED_SCOPED_EVIDENCE' and not evidence['unresolved_findings']
v=module('checkpoint_native_validation',B/'validate_native.py')
w=module('checkpoint_measurement_validation',M/'validate_measurement.py')
cases={}
for root,validator,names in [(B,v,['queue-normal','queue-panic','queue-idle','queue-stop','window-five']),
                             (M,w,['idle-eight-minute','grid-cpu-profile','grid-source-details'])]:
    for name in names:
        saved=read(root/(name+'-validation.json'))
        assert validator.validate(name)==saved
        cases[name]={'validation_sha256':sha(root/(name+'-validation.json')),
                     'run_receipt_sha256':sha(root/(name+'.json')),
                     'result':saved['result'], 'source_commit':saved['source_commit']}
original=read(O/'macos-soak-cover/overnight-failure/soak-overnight.json')
assert original['exit_code']==1
assert read(O/'macos-soak-cover/overnight-failure/soak-overnight-validation.json')['result']=='FAILED_VALIDATION'
assert read(B/'retired-soak-failure.json')['full_overnight_qualified'] is False
checks={}
for name in ['integrated-race','integrated-vet','diagnostic-build']:
    receipt=read(P/(name+'.json'))
    assert receipt['exit_code']==0 and receipt['error'] is None and receipt['sources_stable']
    assert receipt['native_application_executed'] is False
    for channel in ['stdout','stderr']:
        assert receipt['logs'][channel]['sha256']==sha(P/(name+'.'+channel))
    for n,h in review['sources'].items():
        # Readable reports were corrected after these checks. The tested Go
        # endpoint must still match exactly; a prose-only correction does not
        # require repeating race/vet/build or replace their original receipts.
        if n.endswith('.go'):
            assert receipt['sources'][n]==h
    checks[name]={'receipt_sha256':sha(P/(name+'.json')), 'exit_code':0,
                  'elapsed_seconds':receipt['elapsed_seconds'], 'native_application_executed':False}

# Keep original names/bytes, including historical unsuccessful controls. These
# archived controllers record their original absolute execution paths; they are
# evidence, not a relocatable native launch tool.
selected={}
for prefix,root in [('native',B),('measurements',M),('overlay',F),('checkpoint',P),
                    ('failed-overnight',O/'macos-soak-cover/overnight-failure'),
                    ('visible-milestone',O/'macos-soak-cover/milestones')]:
    for f in sorted(root.rglob('*')):
        if not f.is_file() or '__pycache__' in f.parts or 'outputs' in f.relative_to(root).parts:
            continue
        if f.name=='window-cycle-diagnostics':
            continue
        assert not f.is_symlink()
        selected[prefix+'/'+f.relative_to(root).as_posix()]=f
helpers={
    'helpers/composed-validate_live.py':Path('/private/tmp/vellum-macos-composed-endurance/validate_live.py'),
    'helpers/benchmark-grid.py':C/'scripts/benchmark-grid.py',
    'helpers/child_process.py':C/'scripts/child_process.py',
    'helpers/sdk_environment.py':C/'scripts/sdk_environment.py',
    'helpers/live_lease.py':B/'live_lease.py'}
selected.update(helpers)
assert len(selected)<400 and sum(f.stat().st_size for f in selected.values())<32<<20
D.mkdir(parents=True,exist_ok=True)
archive=D/'evidence.tar.xz';index=[]
with tarfile.open(archive,'x:xz',preset=3) as out:
    for name,f in sorted(selected.items()):
        data=f.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0
        out.addfile(entry,io.BytesIO(data))
        index.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:xz') as stored:
    members=stored.getmembers();assert len(members)==len(index)
    for member,row in zip(members,index):
        assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
        assert hashlib.sha256(stored.extractfile(member).read()).hexdigest()==row['sha256']
with (D/'archive-index.json').open('x') as out:
    out.write(json.dumps({'members':index,'executable_binaries_included':False,
        'uncompressed_bytes':sum(row['bytes'] for row in index)},indent=2)+'\n')
qualification={
    'schema':'vellum-macos-loop-native-checkpoint-v1',
    'result':'PASS_SCOPED_NATIVE_FOLLOWUPS_AND_DIAGNOSTIC_SOURCE',
    'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_commit':'82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4',
    'checkpoint_sources':review['sources'], 'native_source_commit':'82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4',
    'native_tracked_files':4479,'native_prepared_files':6229,
    'native_binaries':read(B/'binaries.json')['outputs'],
    'native_cases':cases, 'integrated_checks':checks,
    'original_overnight_result':'FAILED_NATIVE_WINDOW_SOAK',
    'original_overnight_receipt_sha256':sha(O/'macos-soak-cover/overnight-failure/soak-overnight.json'),
    'original_overnight_qualified':False, 'diagnostic_native_event_qualified':False,
    'sampled_short_idle_cpu_threshold_met':True,'full_idle_budget_qualified':False,
    'causal_performance_gain_qualified':False,'ordinary_warm_targets_qualified':False,
    'full_p11_qualified':False,'full_mac_qualified':False,
    'internal_source_review_sha256':sha(P/'checkpoint-source-review.json'),
    'internal_evidence_review_sha256':sha(F/'evidence-review.json'),
    'post_provider_seal_review_sha256':sha(P/'post-provider-seal-review.json'),
    'provider_resolution_sha256':sha(P/'provider-resolution.json'),
    'provider_review':{'execution_sha256':sha(P/'prism-execution.json'),'coverage':coverage,
        'findings':0,'discarded':1,'suppressed':0,'discarded_disposition':'ACCEPTED_NONBLOCKING_COSMETIC'},
    'archive_sha256':sha(archive),'archive_index_sha256':sha(D/'archive-index.json'),
    'seal_producer_sha256':sha(Path(__file__)),
    'limits':['Native runs predate diagnostic source changes; no live failure-event acceptance.',
        'Failed original overnight remains failed; scheduling proof is not qualification.',
        'Short sampled idle has endpoint states and primary paint counters only.',
        'Profiling/detail modes are diagnostic, not ordinary timing or causal comparison.',
        'No physical input, human IME/VoiceOver, native/GPU memory, release or full Mac acceptance.']}
with (D/'qualification.json').open('x') as out:
    out.write(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'result':qualification['result'],'archive_members':len(index),
                  'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive)}))
