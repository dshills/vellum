"""Prepare a source checkpoint without changing the clean native-run endpoint."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess

C = Path('/Users/dshills/Development/projects/Vellum')
R = Path('/private/tmp/vellum-soak-diagnostics-checkpoint')
P = Path(__file__).resolve().parent
F = Path('/private/tmp/vellum-soak-drift-diagnostics')
B = Path('/private/tmp/vellum-macos-post-loop-native')
M = Path('/private/tmp/vellum-macos-post-loop-measurements')
O = Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts')
BASE = '82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        out.write(json.dumps(value, indent=2) + '\n')

def copy(source, target):
    assert source.is_file() and not source.is_symlink()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as out:
        out.write(source.read_bytes())
    assert sha(source) == sha(target)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=C, timeout=10).decode().strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=C, timeout=10).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, timeout=10).decode().strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=R, timeout=10).strip()
manifest = read(B/'binaries.json')
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=C, timeout=10).decode().split('\0')
tracked = {n: sha(C/n) for n in names if n}
assert tracked == manifest['source_identity']['tracked'] and len(tracked) == 4479
prepared = {p.relative_to(C/'drivers/cogent/build').as_posix(): sha(p)
            for name in ['upstream', 'typesetting']
            for p in sorted((C/'drivers/cogent/build'/name).rglob('*')) if p.is_file()}
assert prepared == manifest['source_identity']['prepared'] and len(prepared) == 6229
for name in ['upstream', 'typesetting']:
    shutil.copytree(C/'drivers/cogent/build'/name, R/'drivers/cogent/build'/name)
copied = {p.relative_to(R/'drivers/cogent/build').as_posix(): sha(p)
          for name in ['upstream', 'typesetting']
          for p in sorted((R/'drivers/cogent/build'/name).rglob('*')) if p.is_file()}
assert copied == prepared
review = read(F/'diagnostic-source-review.json')
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
for name in ['soak.go', 'soak_failure.go', 'soak_failure_test.go']:
    assert sha(F/name) == review['sources'][name]
    target = R/'drivers/cogent/cmd/window-cycle-smoke'/name
    if target.exists():
        assert name == 'soak.go' and sha(target) == review['baseline_soak_sha256']
        target.write_bytes((F/name).read_bytes())
    else:
        copy(F/name, target)

# Preserve new results separately from historical success-only preparations.
snapshots = {}
for label, source, target in [
    ('post-loop-native', B, O/'macos-post-loop-native/completed-20261016'),
    ('post-loop-measurements', M, O/'macos-post-loop-measurements/completed-20261016'),
    ('diagnostic-overlay', F, O/'macos-soak-diagnostics/overlay-20261016')]:
    files = {}
    for path in sorted(source.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or 'outputs' in path.relative_to(source).parts:
            continue
        relative = path.relative_to(source).as_posix()
        copy(path, target/relative)
        files[relative] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    snapshots[label] = {'source': str(source), 'durable': str(target), 'files': files}
# Private executable copies support later offline profile reading. They are not
# shipped in the source archive or presented as reproducible compiler outputs.
for name, entry in manifest['outputs'].items():
    binary = Path(entry['binary']['path'])
    assert sha(binary) == entry['binary']['sha256']
    destination = O/'macos-post-loop-native/completed-20261016/bin'/name
    copy(binary, destination)
    destination.chmod(0o755)
write(P/'preparation.json', {
    'schema': 'vellum-soak-diagnostics-preparation-v1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_commit': BASE, 'canonical_clean': True,
    'tracked_files': len(tracked), 'prepared_files': len(prepared),
    'prepared_copy_exact': True,
    'candidate_source_review_sha256': sha(F/'diagnostic-source-review.json'),
    'producer_sha256': sha(Path(__file__)), 'snapshots': snapshots,
    'native_application_executed_by_preparation': False})
print(json.dumps({'result':'PREPARED', 'snapshot_files': {k: len(v['files']) for k,v in snapshots.items()}}))
