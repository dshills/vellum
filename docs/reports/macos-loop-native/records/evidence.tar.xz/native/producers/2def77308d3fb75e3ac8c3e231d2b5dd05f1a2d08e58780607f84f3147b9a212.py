"""Bounded CPU-only policy and lifecycle controls after the known soak failure."""
from pathlib import Path
import datetime,hashlib,json,sys,time
import native_common as c
P=Path(__file__).resolve().parent;sha=c.sha
names=['native_common.py','run_native.py','validate_native.py','native-configuration.json','validate_retired_failure.py','retired-failure-inputs.json','test_retired_failure.py','test_native_policy.py','test_native_validation.py','test_native_lifecycle.py','run_policy_controls.py']
source={name:sha(P/name)for name in names}
for name in names:
 f=P/name;dest=P/'producers'/(source[name]+f.suffix);dest.parent.mkdir(exist_ok=True)
 if dest.exists():assert sha(dest)==source[name]
 else:
  with dest.open('xb')as out:out.write(f.read_bytes())
assert not c.stopping(),'human return'
assert c.read(c.S/'soak-overnight.json')['exit_code']==1,'only after known old native failure'
argv=[sys.executable,'-m','unittest','test_native_validation','test_native_lifecycle','test_retired_failure','test_native_policy','-v'];start=time.monotonic()
with c.LiveLease()as lease:
 before=c.group_absent(15600)
 with(P/'policy-controls.stdout').open('xb')as out,(P/'policy-controls.stderr').open('xb')as err:r=c.run_child(argv,cwd=P,env=c.child_environment(),stdout=out,stderr=err,timeout=60,log_limit_bytes=1<<20)
 result={'result':'PASS_CPU_ONLY_POLICY_CONTROLS'if r.returncode==0 else'FAILED_CPU_ONLY_POLICY_CONTROLS','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'source':source,'sources_stable':all(sha(P/n)==h for n,h in source.items()),'preflight_group_absence':before,'live_lease_held':lease.held(),'native_application_executed':False,'scope':'Synthetic policy/parser/Python-child controls only. Original overnight remains failed.','logs':{ch:{'sha256':sha(P/('policy-controls.'+ch)),'bytes':(P/('policy-controls.'+ch)).stat().st_size}for ch in ['stdout','stderr']}}
 with(P/'policy-controls.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result));assert r.returncode==0 and result['sources_stable']
