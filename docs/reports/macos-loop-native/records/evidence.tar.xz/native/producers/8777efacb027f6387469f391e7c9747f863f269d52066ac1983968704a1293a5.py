"""CPU-only prerequisite policy controls, using a synthetic fresh-group observation."""
from copy import deepcopy
from unittest.mock import patch
import unittest
import native_common as c
import validate_native as v
class SchedulingPolicyChecks(unittest.TestCase):
 def config(self):return c.config()
 def admission(self):
  with patch.object(c,'group_absent',return_value={'observed_group':15600,'argv':['ps','-axo','pid=,pgid=,stat='],'stdout_sha256':'a'*64,'stdout_bytes':100,'members':[]}):return c.predecessor(self.config())
 def test_failed_retired_policy_does_not_qualify_soak(self):
  prior=self.admission();proof=v.validate_predecessor(self.config(),prior);self.assertEqual(prior['result'],'FAILED_RETIRED_PREDECESSOR');self.assertIs(prior['original_overnight_qualified'],False);self.assertIs(proof['full_mac_qualified'],False)
 def test_missing_retirement_cannot_admit(self):
  prior=self.admission();prior['fresh_group_absence']['members']=[{'pid':15600}]
  with self.assertRaises(ValueError):v.validate_predecessor(self.config(),prior)
 def test_wrong_fresh_owner_cannot_admit(self):
  prior=self.admission();prior['fresh_group_absence']['observed_group']=15601
  with self.assertRaises(ValueError):v.validate_predecessor(self.config(),prior)
 def test_full_success_claim_cannot_hide_failure(self):
  prior=self.admission();prior['original_overnight_qualified']=True
  with self.assertRaises(ValueError):v.validate_predecessor(self.config(),prior)
 def test_changed_proof_binding_refuses(self):
  cfg=self.config();cfg['retired_failure_proof_sha256']='0'*64
  with self.assertRaises(ValueError):v.validate_predecessor(cfg,self.admission())
 def test_unknown_policy_refuses(self):
  cfg=self.config();cfg['predecessor_scheduling_policy']='accept_any_exit'
  with self.assertRaises(ValueError):v.validate_predecessor(cfg,self.admission())
 def test_original_success_validator_still_refuses_failed_soak(self):
  cfg=self.config();cfg['predecessor_scheduling_policy']='completed_soak_only'
  with self.assertRaisesRegex(ValueError,'native terminal'):v.validate_predecessor(cfg,self.admission())
if __name__=='__main__':unittest.main()
