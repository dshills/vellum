# Native follow-up preparation after event-driven Mac loop

Source: clean `82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4`.
Three successful native build receipts bind the complete recorded 4,479 tracked
and 6,229 prepared source vectors to the queue, composed-window and grid binaries.
`build-result-review.json` records the independent review and its limits.

`controls.json` and its raw logs record 18 passing CPU-only harness controls.
The parser controls use explicitly synthetic payloads assembled from older raw
logs. Lifecycle controls launch ordinary Python children with a synthetic lease
and source association. They exercise denied admission, normal and nonzero exit,
stop-triggered cleanup and the stderr byte limit. They are not native functional,
physical pointer, accessibility, idle CPU or performance evidence.

The controller's fixed sequence is queue normal, panic, delayed idle dispatch,
worker-only stop, then five composed windows with 33 native selectors each.
Every native launch requires the shared live lease, absent stop markers, source
approval, completed and raw-validated original eight-hour soak, fresh predecessor
process-group absence, prior case validation and unchanged build/source inputs.
No queued native follow-up has run yet. The eight-hour soak uses its separately
frozen older source and binary; it cannot qualify this new event-loop revision.

The eight-minute idle and native grid profiling runs in `queued-checks.json`
remain proposals requiring their own reviewed controller and result validation.
Source approval and a successful controller exit do not replace raw-result checks.
