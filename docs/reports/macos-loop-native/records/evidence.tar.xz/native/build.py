"""Clean committed-source build-only preparation outside native quiet intervals."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent;S=Path('/private/tmp/vellum-macos-soak-cover');B=Path('/private/tmp/vellum-macos-native-idle')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
HEAD='82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
name=sys.argv[1];targets={'queue':('drivers/cogent',['./cmd/mainqueue-smoke'],False),'window':('drivers/cogent',['./cmd/window-cycle-smoke'],True),'grid':('examples/loadedgrid',['.'],False)}
review=json.loads((P/'build-review.json').read_text());assert review['execution_ready']and not review['unresolved_findings']and review['sources']=={'build.py':sha(Path(__file__))}
assert name in targets and not any((P/(name+'.'+s)).exists()for s in ['json','stdout','stderr'])
output=P/'outputs'/name;output.parent.mkdir(exist_ok=True);assert not output.exists()
now=datetime.datetime.now(datetime.timezone.utc);events=[json.loads(x)for x in(S/'soak-overnight.stdout').read_bytes().splitlines()];last=[e for e in events if e.get('event')=='vellum.soak.sample'][-1]
end=datetime.datetime.fromisoformat(last['end_utc'].replace('Z','+00:00'));quiet=end+datetime.timedelta(seconds=240)
assert last['phase']=='visible'and last['cpu_60s_interval']and 0<=(now-end).total_seconds()<90 and(quiet-now).total_seconds()>150,'outside admitted gap'
assert not(S/'soak-overnight.json').exists()
assert not any((Path('/private/tmp')/('vellum-macos-'+n)/'stop-live').exists()for n in ['listbox','composed-endurance','composed-soak','post-glyph-native','soak-occlusion','soak-cover'])
def git(*args):return subprocess.check_output(['git',*args],cwd=R,timeout=10)
def identity():
 assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain').strip()
 tracked={}
 for row in git('ls-tree','-rz','--full-tree','HEAD').split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();f=R/name.decode();assert kind=='blob'and f.is_file()and not f.is_symlink()
  data=f.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
  tracked[name.decode()]=hashlib.sha256(data).hexdigest()
 prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
 assert len(tracked)==4479 and len(prepared)==6229 and prepared==json.loads((B/'final-source-association.json').read_text())['prepared']
 return {'commit':HEAD,'git_clean':True,'tracked':tracked,'prepared':prepared}
before=identity();assert (quiet-datetime.datetime.now(datetime.timezone.utc)).total_seconds()>145
cwd,packages,native_checks=targets[name];argv=['go','build','-p=1','-trimpath']
if native_checks:argv.append('-tags=vellum_native_checks')
argv.extend(['-o',str(output),*packages])
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off'}
assert env['CGO_ENABLED']=='1'
record={'schema':'vellum-post-loop-clean-build-v1','argv':argv,'cwd':str(R/cwd),'started_utc':now.isoformat(),'producer_sha256':sha(Path(__file__)),'source_review_sha256':sha(P/'build-review.json'),'prior_quiet_sample':last,'next_expected_quiet_start':quiet.isoformat(),'identity_before':before,'native_application_executed':False,'exit_code':None,'error':None}
producers=P/'producers';producers.mkdir(exist_ok=True);producer=producers/(record['producer_sha256']+'.py')
if not producer.exists():producer.write_bytes(Path(__file__).read_bytes())
start=time.monotonic()
try:
 with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
  record['exit_code']=run_child(argv,cwd=R/cwd,env=env,stdout=out,stderr=err,timeout=60,log_limit_bytes=2<<20).returncode
 if record['exit_code']==0:
  record['binary']={'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size}
  metadata=run_child(['go','version','-m',str(output)],cwd=R,env=env,capture_output=True,timeout=5)
  assert metadata.returncode==0 and not metadata.stderr
  info=metadata.stdout.decode();assert 'vcs.revision='+HEAD in info and 'vcs.modified=false'in info and 'CGO_ENABLED=1'in info
  (P/(name+'-go-version.txt')).write_text(info);record['go_version_metadata_sha256']=sha(P/(name+'-go-version.txt'))
except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 try:record['identity_after']=identity();record['identity_stable']=record['identity_after']==before
 except BaseException as error:record['identity_stable']=False;record['identity_error']={'type':type(error).__name__,'message':str(error)}
 try:record['binary_stable']=not record.get('binary')or sha(output)==record['binary']['sha256']
 except BaseException as error:record['binary_stable']=False;record['binary_error']={'type':type(error).__name__,'message':str(error)}
 record['elapsed_seconds']=time.monotonic()-start;record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record['finished_before_next_expected_quiet']=datetime.datetime.now(datetime.timezone.utc)<quiet
 for suffix in ['stdout','stderr']:
  f=P/(name+'.'+suffix);record[suffix+'_sha256']=sha(f)if f.exists()else None
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','identity_stable','finished_before_next_expected_quiet']}))
if record['exit_code']!=0 or record['error']or not record['identity_stable']or not record['binary_stable']or not record['finished_before_next_expected_quiet']:sys.exit(1)
