"""Freeze clean observed build outputs; never launch an application."""
from pathlib import Path
import datetime,hashlib,json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((P/'build-review.json').read_text());assert review['execution_ready']and not review['unresolved_findings']and review['sources']=={'build.py':sha(P/'build.py')}
outputs={};identity=None
for name in ['queue','window','grid']:
 q=json.loads((P/(name+'.json')).read_text())
 assert q['exit_code']==0 and q['error']is None and q['identity_stable']and q['binary_stable']and q['finished_before_next_expected_quiet']and not q['native_application_executed']
 assert q['identity_before']==q['identity_after']and q['identity_after']['git_clean']and q['identity_after']['commit']=='82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4'
 assert q['source_review_sha256']==sha(P/'build-review.json')and q['producer_sha256']==sha(P/'build.py')==sha(P/'producers'/(q['producer_sha256']+'.py'))
 assert len(q['identity_after']['tracked'])==4479 and len(q['identity_after']['prepared'])==6229
 if identity is None:identity=q['identity_after']
 else:assert identity==q['identity_after']
 assert all(sha(P/(name+'.'+suffix))==q[suffix+'_sha256']for suffix in ['stdout','stderr'])
 binary=Path(q['binary']['path']);assert sha(binary)==q['binary']['sha256']and binary.stat().st_size==q['binary']['bytes']
 assert sha(P/(name+'-go-version.txt'))==q['go_version_metadata_sha256']
 metadata=(P/(name+'-go-version.txt')).read_text();assert 'vcs.revision='+identity['commit']in metadata and 'vcs.modified=false'in metadata and 'CGO_ENABLED=1'in metadata
 outputs[name]={'binary':q['binary'],'build_receipt_sha256':sha(P/(name+'.json')),'build_metadata_sha256':q['go_version_metadata_sha256'],'elapsed_seconds':q['elapsed_seconds']}
manifest={'schema':'vellum-post-loop-observed-builds-v1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':identity['commit'],'source_identity':identity,'outputs':outputs,'capture_producer_sha256':sha(Path(__file__)),'build_review_sha256':sha(P/'build-review.json'),'native_application_executed':False,'native_acceptance_qualified':False,'performance_gain_qualified':False,'full_mac_qualified':False,'limits':['Observed source/build/output association, not hermetic compiler/cache/native-SDK attestation.','Binaries are private test outputs and have not been executed.','Original overnight soak retains its separate frozen endpoint; these builds cannot qualify that trace.']}
with(P/'binaries.json').open('x')as f:f.write(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'result':'PASS_CLEAN_BUILD_ASSOCIATION','source_commit':manifest['source_commit'],'outputs':{n:q['binary']for n,q in outputs.items()}}))
