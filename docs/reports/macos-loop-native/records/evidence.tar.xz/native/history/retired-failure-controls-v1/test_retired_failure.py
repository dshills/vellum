"""Known failure retirement controls; never launches a native app."""
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import importlib.util,json,shutil,tempfile,unittest
import validate_retired_failure as v
S=v.S
spec=importlib.util.spec_from_file_location('failure_control_cleanup',S/'validate_soak.py');cleanup=importlib.util.module_from_spec(spec);spec.loader.exec_module(cleanup)
class RetiredFailureChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.run=v.read(S/'soak-overnight.json');cls.events=[json.loads(line)for line in(S/'soak-overnight.stdout').read_text().splitlines()if line.strip()]
 def test_known_failure_accepts_only_scheduling_scope(self):
  p=v.validate();self.assertEqual(p['result'],'VALIDATED_FAILED_RETIRED_SOAK')
  for field in ['sampled_idle_cpu_target_met','full_overnight_qualified','full_idle_budget_qualified','full_p11_qualified','full_mac_qualified']:self.assertIs(p[field],False)
 def refuse(self,change):
  r,e=deepcopy(self.run),deepcopy(self.events);change(r,e)
  with self.assertRaises(ValueError):v.failed_payload(r,e,cleanup.terminal)
 def test_zero_exit_is_not_known_failure(self):self.refuse(lambda r,e:r.update(exit_code=0))
 def test_unreaped_child_is_not_retired(self):self.refuse(lambda r,e:r.update(direct_child_terminal=False))
 def test_remaining_group_members_refuse(self):self.refuse(lambda r,e:r.update(post_terminal_group_members=[15600]))
 def test_cancellation_is_not_this_failure(self):self.refuse(lambda r,e:r.update(stop_reason='human-return'))
 def test_changed_owner_refuses(self):self.refuse(lambda r,e:r.update(pid=15601,process_group=15601))
 def test_unheld_lease_cleanup_refuses(self):self.refuse(lambda r,e:r['native_lease'].update(held_through_cleanup=False))
 def test_tracked_native_leak_refuses(self):self.refuse(lambda r,e:e[-1]['native_cleanup'].update(NativeOutstanding=1))
 def test_visible_terminal_window_refuses(self):self.refuse(lambda r,e:e[-1]['native_cleanup']['Windows'][0].update(Visible=True))
 def test_claimed_overnight_completion_refuses(self):self.refuse(lambda r,e:e[-1].update(result='PASS_NATIVE_WINDOW_SOAK',completed_cycles=1))
 def test_modified_raw_file_refuses_before_receipt_reinterpretation(self):
  with tempfile.TemporaryDirectory(prefix='vellum-failed-proof-control-')as directory:
   root=Path(directory)
   for name in v.read(v.P/'retired-failure-inputs.json')['files']:shutil.copyfile(S/name,root/name)
   (root/'soak-overnight.stdout').write_bytes(b'changed raw bytes\n')
   with patch.object(v,'S',root),self.assertRaisesRegex(ValueError,'retained original input soak-overnight.stdout'):v.validate()
if __name__=='__main__':unittest.main()
