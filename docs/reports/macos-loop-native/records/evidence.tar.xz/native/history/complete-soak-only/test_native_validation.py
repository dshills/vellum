"""CPU-only validator fault controls. Never launches an app or qualifies a run."""
from copy import deepcopy
from pathlib import Path
import hashlib,importlib.util,json,unittest
import validate_native as v
E=Path('/private/tmp/vellum-macos-composed-endurance');S=Path('/private/tmp/vellum-macos-soak-cover')
def pure(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
need=v.need
need(v.sha(S/'validate_soak.py')=='2ffcfc73e4d51c41ac55c4cea5a8df983084a6bf6105ff2b591fcc8651aa4473','pure terminal helper source')
need(v.sha(E/'validate_live.py')==json.loads((S/'inputs.json').read_text())['predecessor_validator_sha256'],'pure plan source')
plan=pure('fault_control_plan',E/'validate_live.py');soak=pure('fault_control_soak',S/'validate_soak.py')
class PayloadChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  # A deliberately synthetic five-cycle control assembled from old raw events.
  # Counts/timeout/profile flags and memory Completed fields are changed here;
  # this is parser evidence, never a clean82 native execution receipt.
  events=[json.loads(line)for line in (E/'composed-1000.stdout').read_text().splitlines()if line.strip()]
  cycles=[e for e in events if e['event']=='vellum.composed-cycle'][:5]
  memory=[deepcopy(e)for e in events if e['event']=='vellum.window-cycle.sample'][:6]
  for n,m in enumerate(memory):m['sample']['Completed']=n
  result=deepcopy(events[-1]);result.update(requested_cycles=5,completed_cycles=5,cooperative_timeout_seconds=300,heap_profile_requested=False,samples=[m['sample']for m in memory])
  cls.synthetic=[memory[0]]
  for n,cycle in enumerate(cycles):
   cls.synthetic.extend([{'event':'vellum.native-action','window':f'native-cycle-{n:04d}','action':a}for a in cycle['native_actions']]+[cycle,memory[n+1]])
  cls.synthetic.append(result)
 def test_all_queue_payloads(self):
  for mode,count,wakes in [('normal',100,11000),('panic',1,11000),('idle',3,1000),('stop',0,1000)]:
   p={'case':mode,'callbacks_started':count,'wake_requests':wakes,'queue_stopped':True,'native_creation_refused':True,'panic_identity_preserved':mode=='panic'}
   v.queue_payload(p,'queue-'+mode)
   for field,bad in [('callbacks_started',count+1),('wake_requests',wakes+1),('queue_stopped',False),('native_creation_refused',False),('panic_identity_preserved',mode!='panic')]:
    changed={**p,field:bad}
    with self.subTest(mode=mode,field=field),self.assertRaises(ValueError):v.queue_payload(changed,'queue-'+mode)
 def test_queue_wrong_type_or_extra(self):
  p={'case':'stop','callbacks_started':0,'wake_requests':1000,'queue_stopped':True,'native_creation_refused':True,'panic_identity_preserved':False}
  for change in [{'callbacks_started':False},{'queue_stopped':1},{'extra':True}]:
   with self.assertRaises(ValueError):v.queue_payload({**p,**change},'queue-stop')
 def test_synthetic_composed_positive(self):
  result=v.composed_payload(deepcopy(self.synthetic),plan,soak.terminal);self.assertEqual(result['actions'],165)
 def test_missing_action(self):
  e=deepcopy(self.synthetic);del e[1]
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_owner_not_completed(self):
  e=deepcopy(self.synthetic);e[1]['action']['OwnerAndNativeCompleted']=False
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_wrong_native_role(self):
  e=deepcopy(self.synthetic);e[16]['action']['NativeRole']='AXButton'
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_reordered_cycle_boundary(self):
  e=deepcopy(self.synthetic);e[33],e[34]=e[34],e[33]
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_visible_terminal_window(self):
  e=deepcopy(self.synthetic);e[-1]['native_cleanup']['Windows'][0]['Visible']=True
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_missing_memory_sample(self):
  e=deepcopy(self.synthetic);del e[-2]
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_inflated_qualification(self):
  e=deepcopy(self.synthetic);e[-1]['full_p11_qualified']=True
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
 def test_wrong_timeout(self):
  e=deepcopy(self.synthetic);e[-1]['cooperative_timeout_seconds']=14400
  with self.assertRaises(ValueError):v.composed_payload(e,plan,soak.terminal)
if __name__=='__main__':unittest.main()
