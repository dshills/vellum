"""Bounded CPU-only harness controls, admitted outside the soak's quiet windows."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent
sys.path.insert(0,'/Users/dshills/Development/projects/Vellum/scripts')
from child_process import run_child
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc)
S=Path('/private/tmp/vellum-macos-soak-cover')
markers=[S/'stop-live',P/'stop-live',Path('/private/tmp/vellum-macos-listbox/stop-live')]
assert not any(f.exists()for f in markers),'human return'
events=[json.loads(line)for line in(S/'soak-overnight.stdout').read_text().splitlines()if line.strip()]
samples=[e for e in events if e.get('event')=='vellum.soak.sample'];last=samples[-1]
end=datetime.datetime.fromisoformat(last['end_utc'].replace('Z','+00:00'));age=(now-end).total_seconds()
assert 0<=age<=90 and 240-age>150,('outside safe early gap',age)
sources={n:sha(P/n)for n in ['native_common.py','run_native.py','validate_native.py','test_native_validation.py','test_native_lifecycle.py','run_controls.py']}
producer=P/'producers'/str(sources['run_controls.py']+'.py');producer.parent.mkdir(exist_ok=True)
if producer.exists():assert sha(producer)==sources['run_controls.py']
else:producer.write_bytes(Path(__file__).read_bytes())
argv=[sys.executable,'-m','unittest','test_native_validation','test_native_lifecycle','-v']
result={'scope':'CPU-only synthetic parser and owned child controls. Not a native app execution or functional acceptance.','producer_sha256':sha(__file__),'sources':sources,'argv':argv,'started_utc':now.isoformat(),'prior_sample_end_utc':last['end_utc'],'gap_age_at_start_seconds':age,'deadline_seconds':60,'exit_code':None,'error':None,'native_application_executed':False}
start=time.monotonic()
try:
 with(P/'controls.stdout').open('xb')as out,(P/'controls.stderr').open('xb')as err:
  r=run_child(argv,cwd=P,env=child_environment(),stdout=out,stderr=err,timeout=60,log_limit_bytes=1<<20)
  result['exit_code']=r.returncode
except BaseException as e:result['error']={'type':type(e).__name__,'message':str(e)}
result.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources_stable=all(sha(P/n)==h for n,h in sources.items()),stop_marker_at_exit=any(f.exists()for f in markers),logs={ch:{'sha256':sha(P/('controls.'+ch)),'bytes':(P/('controls.'+ch)).stat().st_size}for ch in ['stdout','stderr']})
result['result']='PASS_CPU_ONLY_HARNESS_CONTROLS'if result['exit_code']==0 and result['error']is None and result['sources_stable']and not result['stop_marker_at_exit']else'FAILED_CPU_ONLY_HARNESS_CONTROLS'
with(P/'controls.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));sys.exit(0 if result['result']=='PASS_CPU_ONLY_HARNESS_CONTROLS'else 1)
