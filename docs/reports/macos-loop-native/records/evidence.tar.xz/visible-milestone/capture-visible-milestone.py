"""Capture a scoped immutable prefix of the original running overnight soak."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,math
P=Path('/private/tmp/vellum-macos-soak-cover');M=P/'milestones';D=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-soak-cover/milestones');D.mkdir(exist_ok=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def need(v,message):
 if not v:raise ValueError(message)
need(sha(P/'inputs.json')=='d283d2174e738aff659414d2b47fc8bbbbed54cc70f6804acb2914e36f6c003d','original input identity')
need(sha(P/'validate_soak.py')=='2ffcfc73e4d51c41ac55c4cea5a8df983084a6bf6105ff2b591fcc8651aa4473','original pure validator')
spec=importlib.util.spec_from_file_location('milestone_pure_soak',P/'validate_soak.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
raw=(P/'soak-overnight.stdout').read_bytes();need(0<len(raw)<=64<<20,'bounded prefix');prefix=raw if raw.endswith(b'\n')else raw[:raw.rfind(b'\n')+1]
events=[json.loads(line)for line in prefix.splitlines()if line.strip()]
ends=[e for e in events if e.get('event')=='vellum.soak.phase-end'];need([e['phase']for e in ends]==['visible'],'only completed visible phase')
end=ends[0];visible=[e for e in events if e.get('event')=='vellum.soak.sample'and e['phase']=='visible'];occluded=[e for e in events if e.get('event')=='vellum.soak.sample'and e['phase']=='occluded']
need(len(visible)==24 and end['samples']==24 and end['elapsed_seconds']>=7200 and len(occluded)==1,'milestone counts/duration')
need(all(v.state(s['start_state'],'visible')and v.state(s['end_state'],'visible')for s in visible),'visible endpoints')
transition=[e for e in events if e.get('event')=='vellum.soak.transition'and e['phase']=='occluded'];need(len(transition)==1,'one occluded transition');t=transition[0];target,cover=t['target'],t['cover']
need(t['observed']is True and t['state_accepted']is True and t['last_query_error']==''and v.state(target,'occluded'),'observed native occlusion')
need(t['cover_contains_target']is True and v.frame_contains(cover['Frame'],target['Frame'])and cover['Visible']is True and cover['Miniaturized']is False and cover['Opaque']is True and cover['Alpha']==1 and cover['Level']==target['Level']and 0<=cover['OrderedIndex']<target['OrderedIndex'],'actual enclosing front opaque cover')
need(all(v.state(s['start_state'],'occluded')and v.state(s['end_state'],'occluded')for s in occluded),'occluded endpoints')
for sample in visible+occluded:
 used,elapsed,wall=sample['process_cpu_seconds'],sample['elapsed_seconds'],sample['wall_elapsed_seconds']
 need(all(v.finite(x)for x in [used,elapsed,wall,sample['one_cpu_percent']])and used>=0 and 60<=elapsed<=66 and abs(wall-elapsed)<=1 and abs(sample['one_cpu_percent']-100*used/elapsed)<1e-8 and sample['cpu_60s_interval']is True,'eligible CPU arithmetic')
 need(type(sample['primary_paint_wakes'])is int and sample['primary_paint_wakes']==0 and sample['app_originated_wakeups_available']is False and sample['present_count_available']is False and sample['full_p11_qualified']is False,'counter/scope')
need(not(P/'soak-overnight.json').exists(),'run not terminal at this capture')
observations=sorted((P/'observations').glob('owned-*.json'));observation=observations[-1];observed=json.loads(observation.read_text())
need(observed['pid']==observed['process_group']==15600 and observed['live_observed']is True and observed['observation_error']is None and observed['phase']=='occluded'and observed['quiet_samples']==25 and observed['stderr_bytes']==0 and observed['stop_markers_present']==[],'bounded scoped liveness observation')
now=datetime.datetime.now(datetime.timezone.utc);stamp=datetime.datetime.fromisoformat(observed['observed_utc']);need(0<=(now-stamp).total_seconds()<=180,'recent actual owned-process observation')
result={'result':'OBSERVED_VISIBLE_PHASE_END_AND_OCCLUSION_TRANSITION','captured_utc':now.isoformat(),'producer_sha256':sha(__file__),'inputs_sha256':sha(P/'inputs.json'),'helper_sha256':sha(P/'validate_soak.py'),'owned_process_observation_sha256':sha(observation),'prefix_sha256':hashlib.sha256(prefix).hexdigest(),'prefix_bytes':len(prefix),'source_commit':json.loads((P/'inputs.json').read_text())['source_commit'],'source_context':'Original separately frozen621aca2 plus five reviewed fixture/spec leaves, not the new82c0c5e event loop.','visible_phase_elapsed_seconds':end['elapsed_seconds'],'visible_eligible_quiet_samples':24,'visible_cpu_one_core_percent_range':[min(s['one_cpu_percent']for s in visible),max(s['one_cpu_percent']for s in visible)],'visible_sampled_cpu_target_met':all(s['one_cpu_percent']<.5 for s in visible),'occluded_transition':t,'first_occluded_sample':occluded[0],'primary_paint_wakes_observed':0,'stderr_bytes_at_process_observation':0,'run_observed_live':True,'full_overnight_qualified':False,'full_idle_budget_qualified':False,'full_mac_qualified':False,'limits':['A complete immutable stdout prefix and recent actual process observation, not a terminal run qualification.','Window states are sampled at endpoints; complete four-phase and terminal validation remain pending.','Primary paint counters do not establish app-wide wakeups/present counts; current new-loop performance is unmeasured.']}
for root in [M,D]:
 for name,data in [('visible-phase-end.stdout',prefix),('visible-phase-end-owned-observation.json',observation.read_bytes()),('capture-visible-milestone.py',Path(__file__).read_bytes())]:
  destination=root/name
  if destination.resolve()==Path(__file__).resolve():continue
  with destination.open('xb')as out:out.write(data)
 with(root/'visible-phase-end.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['result','visible_phase_elapsed_seconds','visible_eligible_quiet_samples','visible_sampled_cpu_target_met','prefix_sha256','run_observed_live','full_overnight_qualified']}))
