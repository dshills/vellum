"""Pinned admission and fixed plans for post-loop idle/render diagnostics."""
from pathlib import Path
import importlib.util,json,sys
P=Path(__file__).resolve().parent;B=Path('/private/tmp/vellum-macos-post-loop-native')
sys.path.insert(0,str(B))
import native_common as base
sha=base.sha;read=base.read;need=base.need;load=base.load
R=base.R;LiveLease=base.LiveLease;subprocess=base.subprocess
child_environment=base.child_environment;current_identity=base.current_identity;group_absent=base.group_absent
ORDER=['idle-eight-minute','grid-cpu-profile','grid-source-details']
def stopping():return base.stopping()+([str(P/'stop-live')]if(P/'stop-live').exists()else[])
def config():
 c=read(P/'measurement-configuration.json');need(c['source_commit']=='82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4','source endpoint')
 need(sha(B/'native-review.json')==c['base_harness_review_sha256']and sha(B/'native-configuration.json')==c['base_configuration_sha256'],'reviewed base harness')
 base.config();base.approved()
 need(sha(B/'run_native.py')==c['derived_controller_source_sha256'],'derived owned-loop source')
 need(sha(B/'binaries.json')==c['binaries_manifest_sha256'],'clean-source build manifest')
 for path,digest in c['helper_sources'].items():need(sha(path)==digest,'pure helper source '+path)
 return c

def approved():
 r=read(P/'measurement-review.json');need(r['execution_ready']is True and r['unresolved_findings']==[],'measurement source approval')
 need(all(sha(P/n)==h for n,h in r['sources'].items()),'measurement reviewed source identity');return r

def predecessor(_):return base.predecessor(base.config())
def prior_cases(case):
 need(case in ORDER,'measurement case');v=load('required_native_case_validator',B/'validate_native.py');proof={}
 for name in ['queue-normal','queue-panic','queue-idle','queue-stop','window-five']:
  saved=read(B/(name+'-validation.json'));need(v.validate(name)==saved and saved['result']=='PASS_SCOPED_NATIVE_CASE','complete current-source queue/window prerequisites')
  proof[name]={'validation_sha256':sha(B/(name+'-validation.json')),'fresh_group_absence':group_absent(read(B/(name+'.json'))['process_group'])}
 v=load('previous_measurement_validator',P/'validate_measurement.py')
 for name in ORDER[:ORDER.index(case)]:
  saved=read(P/(name+'-validation.json'));need(v.validate(name)==saved and saved['result']=='PASS_SCOPED_MEASUREMENT','previous measurement validation')
  proof[name]={'validation_sha256':sha(P/(name+'-validation.json')),'fresh_group_absence':group_absent(read(P/(name+'.json'))['process_group'])}
 return proof

def plan(case):
 need(case in ORDER,'fixed measurement plan')
 if case=='idle-eight-minute':return 'window',['-composed','-cycles=1','-sample-every=1','-timeout=11m','-soak=8m','-soak-quiet=60s','-soak-settle=10s','-soak-interval=90s'],720
 args=['-perf','-rows=1000000','-perf-samples='+('360'if case=='grid-cpu-profile'else'120'),'-perf-warmup=128']
 if case=='grid-cpu-profile':need(not(P/'grid-cpu-profile.pprof').exists()and not(P/'grid-cpu-profile.pprof').is_symlink(),'profile output must be new')
 args+=['-perf-cpu-profile='+str(P/'grid-cpu-profile.pprof')]if case=='grid-cpu-profile'else['-perf-source-details']
 return 'grid',args,180

def built(name,_):return base.built(name,base.config())
def input_pins(review,case,target):
 paths={P/n for n in review['sources']}|{P/'measurement-review.json',P/'measurement-configuration.json'}
 base_review=base.approved();paths|={B/n for n in base_review['sources']}
 paths|={B/n for n in ['native-review.json','native-configuration.json','binaries.json','build-review.json','build-result-review.json','build.py',target+'.json',target+'.stdout',target+'.stderr',target+'-go-version.txt']}
 paths|={Path(n)for n in config()['helper_sources']}
 return {str(f):sha(f)for f in paths}

def profile_artifacts(case):
 if case!='grid-cpu-profile':return {}
 f=P/'grid-cpu-profile.pprof';need(f.is_file()and not f.is_symlink()and 0<f.stat().st_size<=64<<20,'bounded completed CPU profile')
 return {'cpu_profile':{'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)}}
