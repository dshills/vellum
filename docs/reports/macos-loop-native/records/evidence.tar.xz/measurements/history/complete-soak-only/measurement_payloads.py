"""Pure payload checks: exact short-idle plan and diagnostic grid modes only."""
import datetime,math

def need(value,message):
 if not value:raise ValueError(message)
def finite(value):return type(value)in[int,float]and math.isfinite(value)

def idle_payload(events,v,helpers):
 # Body derived from the hash-bound P8 raw soak validator. Runtime helpers are
 # side-effect-free functions, loaded only after their source pins match.
 duration,quiet,settle,interval,timeout=480,60,10,90,660
 state,frame_contains,terminal=helpers.state,helpers.frame_contains,helpers.terminal
 allowed={'vellum.native-action','vellum.composed-cycle','vellum.soak.transition','vellum.soak.phase','vellum.soak.phase-end','vellum.soak.sample','vellum.window-cycle.sample','vellum.window-soak.result'};need(all(e.get('event')in allowed for e in events),'event type')
 actions=[e for e in events if e['event']=='vellum.native-action'];cycles=[e for e in events if e['event']=='vellum.composed-cycle'];results=[e for e in events if e['event']=='vellum.window-soak.result'];memory=[e['sample']for e in events if e['event']=='vellum.window-cycle.sample'];samples=[e for e in events if e['event']=='vellum.soak.sample'];starts=[e for e in events if e['event']=='vellum.soak.phase'];ends=[e for e in events if e['event']=='vellum.soak.phase-end']
 need(len(actions)==33 and len(cycles)==len(results)==1 and all(a['window']=='soak'for a in actions),'native control counts')
 c=cycles[0];aa=c['native_actions'];need(aa==[a['action']for a in actions]and[(a['Target'],a['Kind'],a['Value'])for a in aa]==v.PLAN,'native action plan')
 for a in aa:need(a['OwnerAndNativeCompleted']is True and type(a['Attempts'])is int and type(a['Admissions'])is int and 1<=a['Admissions']<=a['Attempts']and finite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5.25 and a['NativeRole']and'FailureContext'not in a and'AttachmentRetirement'not in a,'completed action')
 need(c['cycle']==1 and c['native_action_plan']==2 and c['native_list_requests']==3 and c['native_canvas_selections']==2 and c['native_color_edits']==2 and c['native_breadcrumb_requests']==2 and c['native_tree_disclosures']==2 and c['tree_accessibility_rows']>0,'composed counts')
 need(all(c[k]is True for k in['native_list_rejected','native_breadcrumb_rejected','native_breadcrumb_truncated','native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])and c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and v.rect(c['root_screen_points'])and v.rect(c['density_clip_screen_points'])and c['full_p11_qualified']is False,'composed publication')
 phases=['visible','occluded','minimized','background'];need([e['phase']for e in starts]==[e['phase']for e in ends]==phases,'four ordered phases')
 need(all(e['event']=='vellum.native-action'for e in events[:33])and events[33]['event']=='vellum.composed-cycle','action prefix')
 cursor=34
 for phase in phases:
  transition=events[cursor];need(transition['event']=='vellum.soak.transition'and transition['phase']==phase and transition['observed']is True and transition['state_accepted']is True and transition['last_query_error']=='','observed accepted transition');cursor+=1
  target,cover=transition['target'],transition['cover'];need(state(target,phase)and cover['Title']=='Vellum cycle survivor','transition windows')
  stamp=datetime.datetime.fromisoformat(transition['observed_utc'].replace('Z','+00:00'));need(stamp.tzinfo is not None and stamp.utcoffset()==datetime.timedelta(0),'transition UTC')
  contains=frame_contains(cover['Frame'],target['Frame']);need(transition['cover_contains_target']is contains,'actual frame containment arithmetic')
  if phase=='occluded':need(contains and cover['Visible']is True and cover['Miniaturized']is False and cover['Opaque']is True and cover['Alpha']==1 and cover['Level']==target['Level']and 0<=cover['OrderedIndex']<target['OrderedIndex'],'opaque front cover contains strict occluded target')
  need(events[cursor]['event']=='vellum.soak.phase'and events[cursor]['phase']==phase,'phase start order');cursor+=1
  while events[cursor]['event']=='vellum.window-cycle.sample':
   need(events[cursor+1]['event']=='vellum.soak.sample'and events[cursor+1]['phase']==phase and events[cursor]['sample']==events[cursor+1]['forced_gc_memory'],'ordered memory/sample pair');cursor+=2
  need(events[cursor]['event']=='vellum.soak.phase-end'and events[cursor]['phase']==phase,'phase end order');cursor+=1
 need(cursor==len(events)-1 and events[cursor]['event']=='vellum.window-soak.result','terminal event order')
 for j,role in[(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton'),(27,'AXList'),(28,'AXList'),(29,'AXList'),(30,'AXButton'),(31,'AXButton')]:need(aa[j]['NativeRole']==role,'action native role')
 need(len(samples)==len(memory)>0 and memory==[s['forced_gc_memory']for s in samples],'sample/memory pairing')
 counts={};cpu={};commits=0;all_eligible=True
 for phase,start,end in zip(phases,starts,ends):
  ss=[s for s in samples if s['phase']==phase];need(ss and [s['sample']for s in ss]==list(range(1,len(ss)+1)),'sample sequence')
  need(start['requested_seconds']==duration/4 and end['samples']==len(ss)and finite(end['elapsed_seconds'])and end['elapsed_seconds']>=duration/4 and finite(end['process_cpu_seconds'])and end['process_cpu_seconds']>=0,'phase duration')
  for s in ss:
   need(state(s['start_state'],phase)and state(s['end_state'],phase),'observed phase state')
   elapsed,wall,used=s['elapsed_seconds'],s['wall_elapsed_seconds'],s['process_cpu_seconds'];need(all(finite(x)for x in[elapsed,wall,used])and elapsed>0 and wall>0 and used>=0,'CPU interval')
   need(abs(s['one_cpu_percent']-100*used/elapsed)<1e-8,'CPU arithmetic')
   eligible=quiet>=60 and elapsed>=60 and elapsed<=quiet+max(1,quiet/10)and abs(wall-elapsed)<=1
   need(s['cpu_60s_interval']is eligible and s['app_originated_wakeups_available']is False and s['present_count_available']is False and s['full_p11_qualified']is False,'measurement scope')
   utc0=datetime.datetime.fromisoformat(s['start_utc'].replace('Z','+00:00'));utc1=datetime.datetime.fromisoformat(s['end_utc'].replace('Z','+00:00'));need(abs((utc1-utc0).total_seconds()-wall)<.001,'wall interval')
   need(type(s['primary_paint_wakes'])is int and s['primary_paint_wakes']>=0,'paint counter')
   if phase=='background':commits+=1
   need(s['background_commits']==commits,'worker completion count')
   all_eligible=all_eligible and eligible
  need(end['background_commits']==commits,'phase worker count');counts[phase]=len(ss);cpu[phase]=[min(s['one_cpu_percent']for s in ss),max(s['one_cpu_percent']for s in ss)]
 need(commits==counts['background']and commits>0,'background work')
 result=results[0];need(events[-1]is result and result['result']=='PASS_NATIVE_WINDOW_SOAK'and result['requested_cycles']==result['completed_cycles']==1 and result['native_action_plan']==2 and result['composed_workspace']is True and result['dense_labels_per_composed_window']==1000 and result['samples']==memory,'final result')
 need(result['soak_config']=={k:int(n*1e9)for k,n in[('Duration',duration),('Quiet',quiet),('Settle',settle),('Interval',interval)]}and result['cooperative_timeout_seconds']==timeout and result['heap_profile_requested']is False,'soak config')
 need(result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20 and all(m['Completed']==0 and 0<m['HeapAlloc']<=512<<20 and 0<m['RSSBytes']<=1<<30 for m in memory),'sampled guards')
 need(all(result[k]is False for k in['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed'])and result['samples_after_forced_gc']is True and result['geometry_persistence_disabled_in_fixture']is True,'final scope');terminal(result['native_cleanup'])
 return {'duration_requested_seconds':duration,'observed_phase_elapsed_seconds':sum(e['elapsed_seconds']for e in ends),'phase_samples':counts,'quiet_cpu_one_core_percent_ranges':cpu,'eligible_sixty_second_intervals':sum(s['cpu_60s_interval']for s in samples),'all_quiet_intervals_eligible':all_eligible,'sampled_idle_cpu_target_met':all_eligible and all(s['one_cpu_percent']<.5 for s in samples),'primary_paint_wakes_total':sum(s['primary_paint_wakes']for s in samples),'background_commits':commits,'native_selector_actions':33,'native_cleanup':result['native_cleanup'],'full_idle_budget_qualified':False,'causal_cpu_improvement_qualified':False,'os_application_background_qualified':False,'continuously_observed_window_state_qualified':False,'limits':['Window state is sampled at interval endpoints. Background names allocating-worker work, not OS app background.','Only primary paint wakes are available; app-wide wakeups/presents remain unavailable.','A source-bound short observation has a different duration/configuration from the old-source overnight soak and cannot attribute improvement.']}

def grid_payload(records,case,b,profile_path):
 need(case in ['grid-cpu-profile','grid-source-details'],'diagnostic grid case')
 profiled=case=='grid-cpu-profile';count=360 if profiled else 120
 selected=b.validate_records(records,1000000,False,count,False,allow_profile=profiled,allow_source_details=not profiled,gpu_scene_rendering=False)
 setup,ready,end=records[0],records[1],records[-1]
 need(setup['cpu_profile']is profiled and setup['source_details']is(not profiled)and setup['alloc_profile']is False and setup['input_details']is False,'exact diagnostic mode')
 need(ready['warmup']==ready['warm_callbacks']==128,'guarded warmup')
 need(setup['cpu_profile_path']==(profile_path if profiled else ''),'requested profile output')
 return {'rows':1000000,'variable':False,'renderer':'cpu','samples':count,'warmup':128,'diagnostic':'process-wide Go CPU profile'if profiled else'nested source timing','metrics_ns':{name:b.distribution([r['metrics'][name]for r in selected])for name in b.METRICS},'native_gpu_memory_available':False,'physical_presentation_available':False,'ordinary_warm_target_qualified':False,'performance_improvement_qualified':False,'limits':['Profiled/detailed measurements are diagnostic and excluded from ordinary warm targets.','Phase and source intervals can nest; independent percentiles must not be added.','CPU profile includes observers and other Go work; native/GPU execution is not attributed.']}
