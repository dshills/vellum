# Post-loop idle and rendering diagnostics: preparation

These private controllers target the clean `82c0c5e` native binaries associated
with the complete recorded 4,479 tracked and 6,229 prepared source files in
`../macos-post-loop-native/binaries.json`.

The fixed sequence is an eight-minute four-state idle observation, a fixed-million
row CPU-rendered grid with a process-wide Go CPU profile (360 measured frames),
then a separate source-details grid run (120 measured frames). Grid warmup is
128 closed-trajectory frames. The two grid modes are diagnostic; their samples
cannot qualify the ordinary 4 ms p95 / 6 ms p99 frame targets.

Each launch requires current absence of human-return markers, the shared live
lease, a terminal and raw-validated original eight-hour soak, all five clean-source
queue/window passes, fresh predecessor group absence, reviewed source, exact
build/binary association and bounded owned-process cleanup. Controllers never
change input sources, accessibility settings, clipboard or OS preferences.

`controls.json` and raw logs record 17 passing CPU-only synthetic parser and
Python-child lifecycle controls. The idle fixtures alter historical preflight
values deliberately; the grid fixtures are synthetic test records. Those controls
are not actual native measurements. No measurement app has been executed yet.

An idle CPU miss remains an observed miss. Four endpoint-sampled window states,
primary paint counters and Go/process memory do not establish app-wide wakeups,
presentation counts, OS application background, native/GPU memory or full Mac
completion. This short run differs from the older-source eight-hour soak in both
source and configuration and cannot by itself attribute improvement.
