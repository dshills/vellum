"""Synthetic payload fault controls. No native applications, no acceptance claims."""
from copy import deepcopy
from pathlib import Path
import datetime,hashlib,importlib.util,json,unittest
from measurement_payloads import idle_payload,grid_payload
P=Path(__file__).resolve().parent;S=Path('/private/tmp/vellum-macos-soak-cover');E=Path('/private/tmp/vellum-macos-composed-endurance')
def pure(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
c=json.loads((P/'measurement-configuration.json').read_text())
for path,h in c['helper_sources'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
helpers=pure('control_soak_helpers',S/'validate_soak.py');plan=pure('control_native_plan',E/'validate_live.py');fixtures=pure('control_benchmark_fixtures',Path('/Users/dshills/Development/projects/Vellum/scripts/benchmark-grid_test.py'));bench=fixtures.benchmark
class IdleChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  # Synthetic plan-shaped data, adapted from the old 40-second raw preflight.
  # All changed duration/CPU/UTC/worker fields are test fixtures, not evidence.
  raw=[json.loads(line)for line in(S/'soak-preflight.stdout').read_text().splitlines()if line.strip()]
  cls.data=deepcopy(raw[:34]);memory=[]
  for phase in ['visible','occluded','minimized','background']:
   transition=deepcopy(next(e for e in raw if e['event']=='vellum.soak.transition'and e['phase']==phase));start=deepcopy(next(e for e in raw if e['event']=='vellum.soak.phase'and e['phase']==phase));sample=deepcopy(next(e for e in raw if e['event']=='vellum.soak.sample'and e['phase']==phase));end=deepcopy(next(e for e in raw if e['event']=='vellum.soak.phase-end'and e['phase']==phase))
   commit=1 if phase=='background'else 0;start['requested_seconds']=120
   stamp=datetime.datetime.fromisoformat(sample['start_utc'].replace('Z','+00:00'))
   sample.update(sample=1,elapsed_seconds=60.,wall_elapsed_seconds=60.,process_cpu_seconds=.12,one_cpu_percent=.2,end_utc=(stamp+datetime.timedelta(seconds=60)).isoformat(),cpu_60s_interval=True,background_commits=commit)
   end.update(elapsed_seconds=120.,process_cpu_seconds=.12,samples=1,background_commits=commit)
   mem={'event':'vellum.window-cycle.sample','sample':sample['forced_gc_memory']};memory.append(mem['sample']);cls.data.extend([transition,start,mem,sample,end])
  result=deepcopy(raw[-1]);result.update(samples=memory,cooperative_timeout_seconds=660,heap_profile_requested=False,soak_config={k:int(n*1e9)for k,n in [('Duration',480),('Quiet',60),('Settle',10),('Interval',90)]});cls.data.append(result)
 def check(self,data):return idle_payload(data,plan,helpers)
 def test_synthetic_positive_and_no_qualification(self):
  r=self.check(deepcopy(self.data));self.assertEqual(r['eligible_sixty_second_intervals'],4);self.assertTrue(r['sampled_idle_cpu_target_met']);self.assertFalse(r['full_idle_budget_qualified']);self.assertFalse(r['causal_cpu_improvement_qualified'])
 def test_cpu_miss_is_preserved(self):
  d=deepcopy(self.data);sample=next(e for e in d if e['event']=='vellum.soak.sample');sample.update(process_cpu_seconds=.6,one_cpu_percent=1.);r=self.check(d);self.assertFalse(r['sampled_idle_cpu_target_met'])
 def test_occlusion_or_cover_failure_refused(self):
  for change in [lambda e:e['target'].update(OcclusionVisible=True),lambda e:e['cover'].update(Opaque=False),lambda e:e['cover'].update(OrderedIndex=999)]:
   d=deepcopy(self.data);change(next(e for e in d if e['event']=='vellum.soak.transition'and e['phase']=='occluded'))
   with self.assertRaises(ValueError):self.check(d)
 def test_cpu_arithmetic_or_eligibility_corruption(self):
  for change in [{'one_cpu_percent':2.},{'cpu_60s_interval':False},{'wall_elapsed_seconds':61.}]:
   d=deepcopy(self.data);next(e for e in d if e['event']=='vellum.soak.sample').update(change)
   with self.assertRaises(ValueError):self.check(d)
 def test_missing_phase(self):
  d=deepcopy(self.data);d=[e for e in d if e.get('phase')!='minimized']
  with self.assertRaises(ValueError):self.check(d)
 def test_unsafe_memory_or_visible_terminal(self):
  for change in [lambda d:d[-1]['samples'][0].update(HeapAlloc=513<<20),lambda d:d[-1]['native_cleanup']['Windows'][0].update(Visible=True),lambda d:d[-1].update(full_p11_qualified=True)]:
   d=deepcopy(self.data);change(d)
   with self.assertRaises(ValueError):self.check(d)
class GridChecks(unittest.TestCase):
 def records(self,profiled):
  d=fixtures.records(360)if profiled else fixtures.detailed_records(120)
  for e in d:e.update(warmup_guard=1,source_details=not profiled,alloc_profile=False,input_details=False)
  for e in [d[0],d[1],d[-1]]:e.update(rows=1000000,cpu_profile=profiled)
  d[0].update(stored_value_bytes=1000000*160,cpu_profile_path='/synthetic/cpu.pprof'if profiled else'')
  d[1].update(warmup=128,warm_callbacks=128,warm_start_viewport={'Width':800,'Height':600,'ScrollX':0,'ScrollY':0},warm_end_viewport={'Width':800,'Height':600,'ScrollX':0,'ScrollY':0})
  return d
 def check(self,d,profiled):return grid_payload(d,'grid-cpu-profile'if profiled else'grid-source-details',bench,'/synthetic/cpu.pprof')
 def test_both_synthetic_diagnostics(self):
  for profiled in [True,False]:
   r=self.check(self.records(profiled),profiled);self.assertEqual(r['metrics_ns']['ui_work_ns']['count'],360 if profiled else 120);self.assertFalse(r['ordinary_warm_target_qualified'])
 def test_profile_mode_cannot_be_ordinary_or_wrong_path(self):
  for change in [lambda d:d[0].update(cpu_profile=False),lambda d:d[0].update(cpu_profile_path='/wrong'),lambda d:d[1].update(warm_callbacks=64)]:
   d=self.records(True);change(d)
   with self.assertRaises(ValueError):self.check(d,True)
 def test_detailed_mode_retains_raw_ticket_checks(self):
  for change in [lambda d:d[2].update(callbacks=2),lambda d:d[2]['native_sample'].update(Completed=False),lambda d:d[2]['native_sample']['SourceDetails']['Records'][0].update(DrawNS=999)]:
   d=self.records(False);change(d)
   with self.assertRaises(ValueError):self.check(d,False)
 def test_profile_sample_count_mismatch(self):
  d=self.records(True);del d[2]
  with self.assertRaises(ValueError):self.check(d,True)
if __name__=='__main__':unittest.main()
