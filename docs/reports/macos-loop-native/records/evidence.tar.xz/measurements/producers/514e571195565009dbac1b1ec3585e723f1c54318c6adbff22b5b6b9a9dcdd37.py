"""Synthetic CPU children exercise controller cleanup; no Cocoa app or real lease."""
from pathlib import Path
from unittest.mock import patch
import contextlib,hashlib,io,json,os,sys,tempfile,threading,time,unittest
import measurement_common as c
import run_measurement as producer
ROOT=c.P
class FixtureLease:
 def __init__(self):self.path=Path('/private/tmp/synthetic-controller-test-lease');self.active=False
 def __enter__(self):self.active=True;return self
 def held(self):return self.active
 def __exit__(self,*ignored):self.active=False
class LifecycleChecks(unittest.TestCase):
 def fixture(self,code,*,gate=None,stop=False):
  with tempfile.TemporaryDirectory(prefix='vellum-controller-cpu-')as directory,contextlib.ExitStack()as stack:
   root=Path(directory);(root/'outputs').mkdir();(root/'drivers/cogent').mkdir(parents=True)
   binary=root/'outputs/queue';binary.write_text('#!'+sys.executable+'\n'+code+'\n');binary.chmod(0o700)
   for name in ['measurement-review.json','measurement-configuration.json','binaries.json','queue.json','queue-go-version.txt','live-authorization.json']:(root/name).write_text('{}\n')
   entry={'binary':{'path':str(binary),'sha256':c.sha(binary),'bytes':binary.stat().st_size},'build_receipt_sha256':c.sha(root/'queue.json')}
   actual_stopping=c.stopping
   def markers():return actual_stopping()+([str(root/'stop')]if(root/'stop').exists()else[])
   def predecessor(_):
    if gate=='predecessor':raise ValueError('synthetic missing predecessor')
    return {'synthetic':True}
   def prior(_):
    if gate=='prior':raise ValueError('synthetic missing prior case')
    return {}
   def built(*_):
    if gate=='source':raise ValueError('synthetic source mismatch')
    return {'source_commit':'synthetic-test-only','source_identity':{}},entry
   for name,value in {'P':root,'B':root,'R':root,'stopping':markers,'config':lambda:{},'approved':lambda:{'sources':{},'execution_ready':True},'LiveLease':FixtureLease,'predecessor':predecessor,'prior_cases':prior,'built':built,'current_identity':lambda _:True,'plan':lambda _:('queue',['-case=normal'],30),'profile_artifacts':lambda _:{},'input_pins':lambda *_:{str(root/name):c.sha(root/name)for name in ['measurement-review.json','measurement-configuration.json','binaries.json','queue.json','queue-go-version.txt','live-authorization.json']}}.items():stack.enter_context(patch.object(c,name,value))
   stack.enter_context(patch.object(sys,'argv',['run_measurement.py','idle-eight-minute']))
   triggered=threading.Event()
   def cancel_owned():
    deadline=time.monotonic()+2
    while time.monotonic()<deadline:
     if(root/'idle-eight-minute-owned-process.json').exists():
      (root/'stop').write_text('synthetic cancellation');triggered.set();return
     time.sleep(.01)
   waiter=threading.Thread(target=cancel_owned)if stop else None
   if waiter:waiter.start()
   caught=None
   try:
    with contextlib.redirect_stdout(io.StringIO()):producer.main()
   except ValueError as error:caught=str(error)
   finally:
    if waiter:waiter.join(timeout=3);self.assertTrue(triggered.is_set(),'owned child was not observed before cancellation')
   receipt=root/'idle-eight-minute.json'
   result=json.loads(receipt.read_text())if receipt.exists()and receipt.stat().st_size else None
   owned=(root/'idle-eight-minute-owned-process.json').exists()
   return result,owned,caught
 def test_predecessor_gate_starts_no_process(self):
  r,owned,error=self.fixture('raise SystemExit(0)',gate='predecessor');self.assertIsNone(r);self.assertFalse(owned);self.assertIn('missing predecessor',error)
 def test_prior_case_gate_starts_no_process(self):
  r,owned,error=self.fixture('raise SystemExit(0)',gate='prior');self.assertIsNone(r);self.assertFalse(owned);self.assertIn('missing prior',error)
 def test_source_gate_starts_no_process(self):
  r,owned,error=self.fixture('raise SystemExit(0)',gate='source');self.assertIsNone(r);self.assertFalse(owned);self.assertIn('source mismatch',error)
 def assert_retired(self,r):
  self.assertTrue(r['direct_child_terminal']);self.assertTrue(r['group_absence_confirmed']);self.assertTrue(r['logs_complete']);self.assertEqual(r['cleanup_errors'],[])
 def test_success_cleanup(self):
  r,owned,error=self.fixture("print('synthetic child')");self.assertTrue(owned);self.assertIsNone(error);self.assertEqual(r['result'],'TERMINAL_NATIVE_CASE_OK');self.assert_retired(r)
 def test_nonzero_retained_as_failure(self):
  r,owned,error=self.fixture('raise SystemExit(7)');self.assertTrue(owned);self.assertIsNotNone(error);self.assertEqual(r['exit_code'],7);self.assertEqual(r['result'],'FAILED_OR_CANCELED_NATIVE_CASE');self.assert_retired(r)
 def test_cancel_reaps_owned_child(self):
  r,owned,error=self.fixture('import time\ntime.sleep(30)',stop=True);self.assertTrue(owned);self.assertIsNotNone(error);self.assertEqual(r['stop_reason'],'human-return-marker');self.assertEqual(r['result'],'FAILED_OR_CANCELED_NATIVE_CASE');self.assert_retired(r)
 def test_log_overflow_fails_with_bounded_prefix(self):
  r,owned,error=self.fixture("import os\nos.write(2,b'x'*(5<<20))");self.assertTrue(owned);self.assertIsNotNone(error);self.assertEqual(r['error']['message'],'native log byte bound');self.assertEqual(r['logs']['stderr']['bytes'],4<<20);self.assertEqual(r['result'],'FAILED_OR_CANCELED_NATIVE_CASE');self.assert_retired(r)
if __name__=='__main__':unittest.main()
