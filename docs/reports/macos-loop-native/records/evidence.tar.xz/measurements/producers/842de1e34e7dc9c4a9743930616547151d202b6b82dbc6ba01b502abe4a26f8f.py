"""Read-only raw/receipt validation; no process creation or native operations."""
from pathlib import Path
import hashlib,importlib.util,json,math,sys
from measurement_payloads import idle_payload,grid_payload
P=Path(__file__).resolve().parent;B=Path('/private/tmp/vellum-macos-post-loop-native');S=Path('/private/tmp/vellum-macos-soak-cover');E=Path('/private/tmp/vellum-macos-composed-endurance')
ORDER=['idle-eight-minute','grid-cpu-profile','grid-source-details'];BASE=['queue-normal','queue-panic','queue-idle','queue-stop','window-five']
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(f):return json.loads(Path(f).read_text())
def need(v,msg):
 if not v:raise ValueError(msg)
def pure(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def validate(case):
 need(case in ORDER,'case');r=read(P/(case+'.json'));owned=read(P/(case+'-owned-process.json'));c=read(P/'measurement-configuration.json');review=read(P/'measurement-review.json');manifest=read(B/'binaries.json')
 need(review['execution_ready']is True and review['unresolved_findings']==[]and all(sha(P/n)==h for n,h in review['sources'].items()),'reviewed measurement source')
 need(sha(B/'native-review.json')==c['base_harness_review_sha256']and sha(B/'native-configuration.json')==c['base_configuration_sha256']and sha(B/'binaries.json')==c['binaries_manifest_sha256'],'reviewed base source/build')
 base_review=read(B/'native-review.json');need(base_review['execution_ready']is True and base_review['unresolved_findings']==[]and all(sha(B/n)==h for n,h in base_review['sources'].items()),'base reviewed inputs')
 need(all(sha(path)==h for path,h in c['helper_sources'].items()),'raw helper source identity')
 need(r['schema']=='vellum-post-loop-measurement-v1'and r['result']=='TERMINAL_NATIVE_CASE_OK'and r['case']==case,'successful terminal receipt')
 need(r['error']is None and r['stop_reason']is None and r['cleanup_errors']==[]and r['exit_code']==0 and r['stop_markers_at_exit']==[],'terminal errors')
 need(all(r[k]is True for k in ['direct_child_terminal','group_absence_confirmed','source_stable','artifacts_stable','logs_complete','profile_artifacts_complete','native_application_executed']),'terminal observations')
 need(type(r['pid'])is int and r['pid']>0 and r['pid']==r['process_group']==owned['pid']==owned['process_group'],'owned process')
 need(r['native_lease']=={'path':'/private/tmp/vellum-macos-live-oct15.lock','acquired':True,'held_through_cleanup':True},'shared lease')
 need(r['source_commit']==c['source_commit']==manifest['source_commit']==manifest['source_identity']['commit']=='82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4'and len(manifest['source_identity']['tracked'])==4479 and len(manifest['source_identity']['prepared'])==6229,'exact recorded source endpoint')
 for key,path in [('producer_sha256',P/'run_measurement.py'),('review_sha256',P/'measurement-review.json'),('configuration_sha256',P/'measurement-configuration.json'),('binaries_manifest_sha256',B/'binaries.json')]:need(r[key]==owned[key]==sha(path),'receipt binding '+key)
 target='window'if case=='idle-eight-minute'else'grid';entry=manifest['outputs'][target];build=read(B/(target+'.json'))
 required={str(P/n)for n in review['sources']}|{str(P/'measurement-review.json'),str(P/'measurement-configuration.json')}|{str(B/n)for n in base_review['sources']}|{str(B/n)for n in ['native-review.json','native-configuration.json','binaries.json','build-review.json','build-result-review.json','build.py',target+'.json',target+'.stdout',target+'.stderr',target+'-go-version.txt']}
 required|=set(c['helper_sources'])
 need(set(r['pins'])==required and r['pins']==owned['pins']and all(sha(path)==h for path,h in r['pins'].items()),'complete stable launch pins')
 need(r['binary_sha256']==entry['binary']['sha256']==sha(entry['binary']['path'])and entry['binary']['bytes']==Path(entry['binary']['path']).stat().st_size,'executed binary')
 need(r['build_receipt_sha256']==entry['build_receipt_sha256']==sha(B/(target+'.json'))and build['exit_code']==0 and build['error']is None and build['identity_stable']is True and build['binary_stable']is True and build['identity_before']==build['identity_after']==manifest['source_identity']and build['binary']==entry['binary'],'stable source-bound build')
 need(sha(B/(target+'-go-version.txt'))==entry['build_metadata_sha256']==build['go_version_metadata_sha256']and all(sha(B/(target+'.'+ch))==build[ch+'_sha256']for ch in ['stdout','stderr']),'build metadata/logs')
 if case=='idle-eight-minute':args=['-composed','-cycles=1','-sample-every=1','-timeout=11m','-soak=8m','-soak-quiet=60s','-soak-settle=10s','-soak-interval=90s'];watchdog=720
 else:
  args=['-perf','-rows=1000000','-perf-samples='+('360'if case=='grid-cpu-profile'else'120'),'-perf-warmup=128']+(['-perf-cpu-profile='+str(P/'grid-cpu-profile.pprof')]if case=='grid-cpu-profile'else['-perf-source-details']);watchdog=180
 need(r['argv']==owned['argv']==[entry['binary']['path'],*args]and r['watchdog_seconds']==owned['watchdog_seconds']==watchdog and r['cwd']==owned['cwd']=='/Users/dshills/Development/projects/Vellum/drivers/cogent','exact measurement plan')
 need(type(r['elapsed_seconds'])in[int,float]and math.isfinite(r['elapsed_seconds'])and 0<r['elapsed_seconds']<=watchdog+30,'bounded elapsed time')
 obs=r['group_observation'];need(obs['observed_group']==r['process_group']and obs['argv']==['ps','-axo','pid=,pgid=,stat=']and obs['members']==[]and obs['stdout_bytes']>0,'recorded group absence')
 for ch in ['stdout','stderr']:
  f=P/(case+'.'+ch);info=r['logs'][ch];need(info['sha256']==info['stream_sha256']==sha(f)and info['bytes']==f.stat().st_size and info['bytes']<=(64<<20 if ch=='stdout'else 4<<20),'bounded raw '+ch)
 soak=pure('measurement_soak_helpers',S/'validate_soak.py')
 prior=r['predecessor'];need(prior==owned['predecessor'],'owned predecessor binding')
 base_v=pure('measurement_base_native_validator',B/'validate_native.py');base_v.validate_predecessor(read(B/'native-configuration.json'),prior)
 names=BASE+ORDER[:ORDER.index(case)];need(set(r['prior_cases'])==set(names)and r['prior_cases']==owned['prior_cases'],'complete prerequisite cases')
 for name in names:
  root=B if name in BASE else P;proof=read(root/(name+'-validation.json'));info=r['prior_cases'][name]
  need(info['validation_sha256']==sha(root/(name+'-validation.json'))and info['fresh_group_absence']['members']==[],'prerequisite identity/retirement')
  # Base cases are independently raw-validated; prior measurement proof is
  # recursively revalidated in an acyclic sequence of at most two predecessors.
  need((base_v.validate(name)if name in BASE else validate(name))==proof,'raw prerequisite validation')
 raw=(P/(case+'.stdout')).read_text();need(raw.strip(),'nonempty output')
 lines=raw.splitlines();need(all(len(line.encode())<=1<<20 for line in lines),'raw line bound');events=[json.loads(line)for line in lines if line.strip()]
 if case=='idle-eight-minute':
  plan=pure('measurement_native_plan',E/'validate_live.py');payload=idle_payload(events,plan,soak);need(r['profile_artifacts']=={},'no idle profile')
 else:
  bench=pure('measurement_grid_records',Path('/Users/dshills/Development/projects/Vellum/scripts/benchmark-grid.py'));payload=grid_payload(events,case,bench,str(P/'grid-cpu-profile.pprof'))
  if case=='grid-cpu-profile':
   f=P/'grid-cpu-profile.pprof';need(f.is_file()and not f.is_symlink()and 0<f.stat().st_size<=64<<20,'bounded profile')
   need(r['profile_artifacts']=={'cpu_profile':{'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)}},'completed profile identity')
  else:need(r['profile_artifacts']=={},'source-details profile absent')
 return {'result':'PASS_SCOPED_MEASUREMENT','case':case,'source_commit':r['source_commit'],'validator_sha256':sha(__file__),'run_receipt_sha256':sha(P/(case+'.json')),'binary_sha256':r['binary_sha256'],'raw_stdout_sha256':r['logs']['stdout']['sha256'],'raw_stderr_sha256':r['logs']['stderr']['sha256'],'raw_stderr_bytes':r['logs']['stderr']['bytes'],'profile_artifacts':r['profile_artifacts'],'recorded_owned_group_absence_confirmed':True,'payload':payload,'ordinary_warm_target_qualified':False,'causal_improvement_qualified':False,'physical_input_qualified':False,'native_gpu_memory_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False}
if __name__=='__main__':
 case=sys.argv[1]
 try:result=validate(case)
 except Exception as e:result={'result':'FAILED_VALIDATION','case':case,'error':{'type':type(e).__name__,'message':str(e)},'validator_sha256':sha(__file__)}
 with(P/(case+'-validation.json')).open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result));sys.exit(1 if result['result']=='FAILED_VALIDATION'else 0)
