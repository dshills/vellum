"""Offline attribution of completed diagnostic runs; no native application."""
from pathlib import Path
import datetime,hashlib,json,sys,time
import measurement_common as c
P=Path(__file__).resolve().parent;B=c.B;sha=c.sha
for name in ['grid-cpu-profile','grid-source-details']:
 proof=c.read(P/(name+'-validation.json'));assert proof['result']=='PASS_SCOPED_MEASUREMENT'
 assert proof['run_receipt_sha256']==sha(P/(name+'.json'))
raw=sha(P/'grid-source-details.stdout');records=[json.loads(line)for line in(P/'grid-source-details.stdout').read_text().splitlines()if line.strip()];samples=records[2:-1]
bench=c.load('offline_attribution_grid_validation',c.R/'scripts/benchmark-grid.py');bench.validate_records(records,1000000,False,120,False,allow_source_details=True)
fields=['DrawNS','RasterNS','CopyNS','SetFromGoImageNS','SetFromGoImageAttempts','ImageCacheHits','LogicalUploadRGBABytes'];values={f:[]for f in fields};kinds=set();record_counts=[]
for sample in samples:
 rows=sample['native_sample']['SourceDetails']['Records'];record_counts.append(len(rows));kinds.update(row['Kind']for row in rows)
 for f in fields:values[f].append(sum(row[f]for row in rows))
summary={'schema':'vellum-native-source-attribution-v1','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':'82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4','producer_sha256':sha(__file__),'source_details_raw_sha256':raw,'native_source_record_kinds':sorted(kinds),'source_records_per_ticket':sorted(set(record_counts)),'samples':120,'totals':{f:sum(v)for f,v in values.items()},'distributions':{f:bench.distribution(v)for f,v in values.items()},'source_raster_fraction_of_draw_elapsed':sum(values['RasterNS'])/sum(values['DrawNS']),'source_copy_fraction_of_draw_elapsed':sum(values['CopyNS'])/sum(values['DrawNS']),'ordinary_timing_qualified':False,'causal_optimization_gain_qualified':False,'native_gpu_time_qualified':False,'limits':['Source copy/image API intervals nest in draw; their times must not be added to UI or independent percentiles.','Scalar logical upload bytes/attempts are API-side observations, not confirmed GPU transfers or success.','These are separate detailed/profiler diagnostic processes; they do not qualify ordinary warm latency.']}
with(P/'native-source-attribution.json').open('x')as out:out.write(json.dumps(summary,indent=2)+'\n')
manifest=c.read(B/'binaries.json');binary=Path(manifest['outputs']['grid']['binary']['path']);profile=P/'grid-cpu-profile.pprof';proof=c.read(P/'grid-cpu-profile-validation.json');assert sha(profile)==proof['profile_artifacts']['cpu_profile']['sha256'];assert sha(binary)==manifest['outputs']['grid']['binary']['sha256']
for name,options in [('cpu-flat',['-top','-nodecount=40']),('cpu-cumulative',['-top','-cum','-nodecount=40'])]:
 argv=['go','tool','pprof',*options,str(binary),str(profile)];start=time.monotonic();rdata={'argv':argv,'producer_sha256':sha(__file__),'profile_sha256':sha(profile),'binary_sha256':sha(binary),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':None,'error':None}
 try:
  with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:r=c.base.run_child(argv,cwd=c.R,env=c.child_environment(),stdout=out,stderr=err,timeout=30,log_limit_bytes=2<<20);rdata['exit_code']=r.returncode
 except BaseException as e:rdata['error']={'type':type(e).__name__,'message':str(e)}
 rdata.update(elapsed_seconds=time.monotonic()-start,logs={ch:{'sha256':sha(P/(name+'.'+ch)),'bytes':(P/(name+'.'+ch)).stat().st_size}for ch in ['stdout','stderr']})
 with(P/(name+'.json')).open('x')as out:out.write(json.dumps(rdata,indent=2)+'\n')
 assert rdata['exit_code']==0 and rdata['error']is None,rdata
print(json.dumps({'source_raster_fraction_of_draw_elapsed':summary['source_raster_fraction_of_draw_elapsed'],'source_copy_fraction_of_draw_elapsed':summary['source_copy_fraction_of_draw_elapsed'],'source_records_per_ticket':summary['source_records_per_ticket'],'source_record_kinds':summary['native_source_record_kinds'],'distributions':{k:summary['distributions'][k]for k in ['RasterNS','CopyNS']}}))
