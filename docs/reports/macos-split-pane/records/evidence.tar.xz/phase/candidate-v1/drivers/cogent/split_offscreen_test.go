//go:build offscreen

package cogent

import (
	"bytes"
	"image"
	"math"
	"testing"
	"time"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/math32"
	"github.com/dshills/vellum/ui"
)

func TestSplitManualKeyboardPointerGeometryAndRetainedDraft(t *testing.T) {
	for _, orientation := range []ui.Orientation{ui.Horizontal, ui.Vertical} {
		t.Run(string(orientation), func(t *testing.T) {
			fraction := float32(0.5)
			calls := 0
			config := manualConfig(t, 7)
			view := func() ui.Node {
				n := splitFixture()
				n.Number, n.Orientation, n.Grow = fraction, orientation, true
				n.Change = func(e ui.ChangeEvent) { fraction = e.Number; calls++ }
				return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Focus: ui.FocusRequest{ID: "split", Sequence: 1}, Children: []ui.Node{n}}
			}
			m, a := simpleManual(t, config, view)
			unitSettle(t, m)
			w := m.implementation.find("one")
			r := findRecord(w.state.root, "split")
			c := r.control.split
			field := findRecord(w.state.root, "left").widget.(*core.TextField)
			if !field.ApplyNativeEdit("Retained draft", 14, 14, -1, -1, "insert") {
				t.Fatal("draft refused")
			}
			draft := field.EditingState()
			before, err := m.Capture(testContext, "one")
			if err != nil {
				t.Fatal(err)
			}
			send := func(code key.Codes, modifiers key.Modifiers) {
				t.Helper()
				if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Code: code, Modifiers: modifiers}); err != nil {
					t.Fatal(err)
				}
				unitSettle(t, m)
			}
			increase, decrease := key.CodeRightArrow, key.CodeLeftArrow
			axis := math32.X
			if orientation == ui.Vertical {
				increase, decrease, axis = key.CodeDownArrow, key.CodeUpArrow, math32.Y
			}
			send(increase, 0)
			if math.Abs(float64(fraction-0.51)) > 1e-6 || calls != 1 || findRecord(w.state.root, "left").widget != field || field.EditingState() != draft {
				t.Fatal("keyboard resize lost accepted value/draft", fraction, calls, field.EditingState())
			}
			send(decrease, 0)
			send(key.CodeHome, 0)
			if fraction != 0.05 {
				t.Fatal("Home did not use lower bound", fraction)
			}
			send(key.CodeEnd, 0)
			if fraction != 0.95 {
				t.Fatal("End did not use upper bound", fraction)
			}
			fraction = 0.5
			if err := a.Invalidate("one"); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			if c.handle.Geom.TotalBBox.Empty() || c.panes[0].Geom.TotalBBox.Empty() || c.panes[1].Geom.TotalBBox.Empty() {
				t.Fatal("split pane/handle geometry missing")
			}
			snapshot, err := m.Snapshot(testContext)
			if err != nil {
				t.Fatal(err)
			}
			id := accessibilitySplitHandleID("split")
			var target ManualElement
			for _, e := range snapshot.Windows[0].Elements {
				if e.ID == id {
					target = e
				}
			}
			if target.ID != id || target.Bounds != c.handle.Geom.TotalBBox {
				t.Fatal("measured private divider target missing", target)
			}
			if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.MouseDown, Button: events.Left, Target: id, TargetIncarnation: target.Incarnation}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			if _, err := config.Clock.Advance(core.TimingSettings.SlideStartTime + time.Nanosecond); err != nil {
				t.Fatal(err)
			}
			position := func(value float32) image.Point {
				p := c.handle.Geom.TotalBBox.Min.Add(c.handle.Geom.TotalBBox.Size().Div(2))
				coordinate := int(c.handle.Min + value*(c.handle.Max-c.handle.Min))
				origin := r.widget.AsWidget().Geom.ContentBBox.Min
				if axis == math32.X {
					p.X = origin.X + coordinate
				} else {
					p.Y = origin.Y + coordinate
				}
				return p
			}
			for _, value := range []float32{0.65, 0.75} {
				if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.MouseMove, Position: position(value)}); err != nil {
					t.Fatal(err)
				}
				unitSettle(t, m)
			}
			if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.MouseUp, Button: events.Left, Position: position(0.75)}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			if math.Abs(float64(fraction-0.75)) > 0.015 || r.control.split != c || field.EditingState() != draft {
				t.Fatal("actual pointer resizing failed accepted fraction/retention", fraction, calls)
			}
			after, err := m.Capture(testContext, "one")
			if err != nil || bytes.Equal(before.Pix, after.Pix) {
				t.Fatal("accepted split resize produced no completed pixels", err)
			}
			bounds := accessibilityBounds(w.state.root)[id]
			if bounds[2] <= 0 || bounds[3] <= 0 {
				t.Fatal("split accessible divider bounds missing", bounds)
			}
			send(key.CodeTab, 1<<key.Shift)
			snapshot, err = m.Snapshot(testContext)
			if err != nil || snapshot.Windows[0].FocusedID != "left" {
				t.Fatal("reverse divider traversal did not reach first pane", snapshot, err)
			}
			send(key.CodeTab, 0)
			send(key.CodeTab, 0)
			snapshot, err = m.Snapshot(testContext)
			if err != nil || snapshot.Windows[0].FocusedID != "right" {
				t.Fatal("divider traversal did not reach second pane", snapshot, err)
			}
		})
	}
}

func TestSplitManualOrientationChangeKeepsHandleAndChildren(t *testing.T) {
	orientation := ui.Horizontal
	m, a := simpleManual(t, manualConfig(t, 7), func() ui.Node {
		n := splitFixture()
		n.Orientation, n.Grow = orientation, true
		return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Children: []ui.Node{n}}
	})
	unitSettle(t, m)
	w := m.implementation.find("one")
	r := findRecord(w.state.root, "split")
	c, child := r.control.split, r.children[0].widget
	orientation = ui.Vertical
	if err := a.Invalidate("one"); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, m)
	if r.control.split != c || r.children[0].widget != child || c.handle != r.widget.(*core.Splits).Parts.Child(0) || c.panes[0].Geom.TotalBBox.Min.Y >= c.panes[1].Geom.TotalBBox.Min.Y {
		t.Fatal("orientation update lost native identity or top/bottom layout")
	}
	nodes, _ := accessibilitySnapshot(w.state.root, nil)
	for _, n := range nodes {
		if n.Role == "split-handle" && n.Orientation != "horizontal" {
			t.Fatal("divider semantic orientation stale", n)
		}
	}
}
