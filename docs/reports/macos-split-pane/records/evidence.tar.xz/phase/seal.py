"""Seal controlled split panes and scoped software qualification, without UI."""
from pathlib import Path
import hashlib, json, tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-split-pane');report=r/'docs/reports/macos-split-pane';records=report/'records'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((p/'source-final-v3.json').read_text());baseline=json.loads((p/'source-final-v1.json').read_text())['sources']
assert len(source['sources'])==20 and all(h(r/n)==v for n,v in source['sources'].items())
assert {n for n in baseline if baseline[n]!=source['sources'][n]}=={'drivers/cogent/controls.go','drivers/cogent/split.go','drivers/cogent/split_test.go'}
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f) for module in ['upstream','typesetting'] for f in sorted((r/'drivers/cogent/build'/module).rglob('*')) if f.is_file()}
assert len(prepared)==6198 and prepared==json.loads(Path('/private/tmp/vellum-macos-ui-containers/qualification.json').read_text())['prepared']
required=['portable-race-final-v3','adapter-race-final-v3','split-race-final-v3','vet-final-v3','gallery-build-final-v3'];receipts={}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv' not in d:continue
 name=f.stem
 assert d['source_commit']==source['base_commit'] and d['error'] is None and d['source_delta_stable'] and d['prepared_before']==prepared==d['prepared_after'] and d['overlay_inputs_before']==d['overlay_inputs_after'],name
 for channel in ['stdout','stderr']:assert h(p/(name+'.'+channel))==d[channel+'_sha256'],name
 for path,digest in d['overlay_inputs_before'].items():assert h(Path(path))==digest,name
 if name in required:assert d['exit_code']==0 and d['source_delta_before']==source['sources']==d['source_delta_after'],name
 receipts[name]={'sha256':h(f),'exit_code':d['exit_code'],'final_source_qualified':name in required}
assert all(n in receipts for n in required)
rollback=json.loads((p/'rollback-original-v1.json').read_text());assert rollback['exit_code']==1 and rollback['source_delta_before']==source['sources'] and 'invalid split update mutated accepted native structure' in (p/'rollback-original-v1.stdout').read_text()
negative={'name-original-v1':'focus target "split" is hidden','collapse-original-v1':'implicitly collapsed 0.005','command-original-v1':'swallowed application command split 0','manual-min-original-v1':'implicitly collapsed 0.995 (0,0)-(0,0)','pixel-original-v1':'implicitly collapsed 5e-07 (0,0)-(0,0)'}
for name,needle in negative.items():
 d=json.loads((p/(name+'.json')).read_text());assert d['exit_code']==1 and d['source_delta_before']==baseline and d['overlay_inputs_before'] and needle in (p/(name+'.stdout')).read_text(),name
review=json.loads((p/'review-final-v3.json').read_text());assert review.get('status',review.get('result'))=='APPROVED_SOURCE' and not review['findings']
assert {Path(n).relative_to(r).as_posix():v for n,v in review['reviewed_file_sha256'].items()}==source['sources']
prism=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text())
assert process['exit_code']==1 and process['source_index_stable'] and process['before']==process['after']==baseline
assert prism['coverage']['complete'] and prism['coverage']['files']==20 and prism['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert len(prism['findings'])==1 and prism['findings'][0]['id']=='1836ac2091b7d2a7'
pool={}
for f in sorted(p.rglob('*')):
 if f.is_file() and f.suffix in ['.go','.txt','.m','.md']:pool.setdefault(h(f),[]).append(f.relative_to(p).as_posix())
variants={name:{n:{'sha256':v,'available_phase_payloads':pool.get(v,[])} for n,v in json.loads((p/(name+'.json')).read_text())['source_delta_before'].items()} for name in receipts}
(p/'historical-source-payloads.json').write_text(json.dumps(variants,indent=2)+'\n')
limits=['Twenty changed source leaf hashes and unchanged6198 prepared identities are endpoints, not a full compiler/SDK/native binary closure','Five final-v3 checks bind all20 final leaves and unchanged6198 prepared identities after the internal three-leaf correction','Provider baseline20 and internal final three-leaf correction remain distinct; raw provider1/one finding is preserved and not rerun','Inert Cocoa role/orientation and actual Manual input/geometry/raster remain separate from native attachment, physical pointer/key input and human VoiceOver','Manual viewport correction qualifies software sizing; live Driver initial sizing/resizing remains unqualified','Display fractions temporarily round positive panes to at least one pixel when divider/gap plus two pixels fit; accepted fractions are restored and explicit application minimums may overflow','Native/GPU memory, sustained performance/endurance, physical Mac input/display/GPU cases, third-party rights/signing/release and full Mac completion remain open']
disposition='Internal review rejects the low-confidence missing-validation concern: exact-two-child validation and complete successful allocation precede finishControl; a transactional rejection regression verifies three-child and nil-mount refusal preserves accepted panes. Internal review additionally fixes accepted pane-ID publication on mount failure. Provider was not rerun.'
q={'result':'PASS_SPLIT_PANE','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'receipts':receipts,'baseline_qualification_source':baseline,'source_review_sha256':h(p/'review-final-v3.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'prism_coverage':prism['coverage'],'prism_raw_exit_code':1,'prism_findings':1,'prism_findings_resolved':True,'provider_disposition':disposition,'limits':limits}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');records.mkdir(parents=True,exist_ok=True)
t=prism['coverage']['tokens'][0];failures=sum(v['exit_code']!=0 for v in receipts.values())
(report/'README.md').write_text(f'''# Controlled split panes

Vellum provides `ui.SplitPane`: two retained child panes, side-by-side by default
or top/bottom with Vertical Orientation. Number is the first pane's accepted
fraction; omitted Numeric means 0.05..0.95 with a 0.01 step. Explicit finite bounds
remain strictly inside0..1. Nested nodes form larger adjustable layouts.

Native pointer moves and main-axis arrows/Home/End request owner Change values.
Accepted state remains authoritative without optimistic native collapse. Current
bounds/callbacks apply on delivery; removal, disabled ancestry, pane-order or
orientation changes refuse stale requests. Read-only dividers remain focusable.
Tab visits first-pane targets, divider, then second-pane targets. Private pane
hosts retain child editing/scroll state and isolate native styling from children.
The gallery has a Split panes page; the [catalog](../../controls.md) and
[contract](../../../specs/controls.md) describe the API.

Mac semantics expose AXSplitGroup and a qualified AXSplitter with value, bounds,
actions, focus, measured geometry and divider orientation. Generated split: targets
cannot collide with descriptor IDs. Native Parts keeps its handle-0 Maker key;
renaming that key recreates the widget and loses its retained input/focus binding.
The managed renderer removes native implicit collapse below1%. Layout-only
one-pixel rounding preserves tiny positive panes when divider/gap plus two pixels
fit, then restores accepted TileSplits. Explicit minimums can still overflow.
Normal-phase digit suppression preserves registered scene command priority while
refusing native collapse/equalization outside owner control.

## Verification and corrections

Portable race, complete offscreen adapter race (including existing Manual/replay
consumers), focused split/gallery race3, adapter vet and native gallery compilation
pass against all twenty final-v3 leaves and unchanged6,198 prepared files.
The gallery was compiled only. The initial broad run's local Unix-socket bind was
refused by the sandbox; its raw exit1 is preserved. A permitted local-socket rerun
passes the same full suite without source changes. A supplemental transactional
regression and internal review identified a distinct accepted-ID rollback defect:
preparing a failed child mount changed the retained queue binding. Separate planned
IDs now route preparation; accepted IDs publish only after a complete successful
plan. The strengthened test requires accepted metadata and previously queued valid
resize delivery to survive refusal. The exact old two-production-leaf overlay fails
this same test. All five final-v3 checks run after that three-leaf correction;
seventeen other leaves match the provider baseline. No repeated provider run was
needed for this localized internal correction.

Actual Manual tests cover both orientations, pointer resizing, keyboard bounds,
measured pane ratio/divider containment, completed pixels, retained draft text and
selection, visual Tab order, identity through orientation changes, read-only and
disabled-ancestor behavior, registered digit shortcuts from a pane and divider,
and tiny positive/subpixel fractions. Direct retained fixtures test latest callback
and bounds, refusal, pane reorder, queued disabled/retired delivery, qualified
focus targets and numeric semantic actions. Inert Cocoa objects check roles and
orientation without a window. A start-focus request in an inert fixture schedules
future focus; actual shown focus is proved by Manual routing, not that inert call.
Caret geometry/visual layout can change when panes resize; logical draft/selection
comparison deliberately excludes those coordinates.

Internal review found native Maker-key retirement, implicit sub1% collapse and
digit command interception. All are corrected. Later boundary checks found
subpixel zero-width rounding and Manual reapplying physical window size as a
body-content minimum. Removing that software-only minimum lets the body grow into
the actual padded/bordered scene allocation. Existing Manual/replay consumers
pass the complete race suite after this explicit geometry correction. Live Driver
sizing was not changed or qualified.

Five genuine negative overlays restore each bad behavior independently against
the final-v1 fixtures: renamed handle loses focus; native renderer hides all four
small-fraction cases; First-phase guard swallows registered commands; old Manual
minimum clips the far pane; missing pixel rounding gives zero-area subpixel panes.
Each returns exit1 with a real assertion; final focused race3 passes unchanged
corresponding fixtures. Exact overlay payloads/inputs and source families remain
in the archive. Initial color/unused-import compiler errors, lifecycle/geometry
failures and weak fixture attempts are historical evidence, not qualification.
Multiple Manual instances originally shared one cleanup lifetime; subtests now
own each independent instance. Exact original/v2/final and selected intermediate
source payloads are retained; historical maps explicitly list remaining gaps.
{len(receipts)} receipts/{len(receipts)*2} logs preserve {failures} raw exit1 attempts.
Binaries, caches and complete compiler/SDK closure are excluded.

## Review scope and open Mac gates

Internal source review approves the exact final twenty leaves. Prism runs once
using Anthropic Claude Sonnet5.5 with complete twenty-file baseline coverage,
{prism['coverage']['chunks']} chunks, {t['input']} input/{t['output']} output tokens:
raw exit1, one medium confidence.35 concern about unchecked pane index/nil widget
at finishControl. The complete transaction validates exactly two children before
allocation, refuses nil mounts, and finishes allocation before attaching/order.
Internal review rejects the missing-invariant concern as unreachable through the
supported validated API. A supplemental regression proves three-child and nil-mount
refusal preserve structure; its review found the distinct accepted-ID rollback edge
above. The corrected production publication and strengthened queued-delivery test
are internally reviewed and pass full final qualification. The provider report
remains raw1; Prism was not repeated for that localized three-leaf correction.
Baseline provider coverage, final internal delta review and execution remain distinct.

Separate evidence review binds the [checkpoint](records/checkpoint.json),
[archive](records/evidence.tar.xz) and [member index](records/evidence-index.json).
No desktop windows/input/settings or general clipboard writes occurred. Physical
Mac input/VoiceOver, native/GPU memory, sustained performance/endurance,
distribution rights/signing/release and full Mac framework qualification remain
open.
''')
(records/'source-review.json').write_bytes((p/'review-final-v3.json').read_bytes())
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in ['.go','.m','.json','.md','.py','.stdout','.stderr','.txt','.log']:continue
 if f.name.startswith('evidence-review') or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in source['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size} for n,f in inputs.items()};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','w:xz') as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
e={'source_manifest_sha256':h(p/'source-final-v3.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.xz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'review-final-v3.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e,indent=2))
