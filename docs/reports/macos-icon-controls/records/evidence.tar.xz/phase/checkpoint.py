"""Verify sealed reviews and immutable endpoints before staging checkpoint metadata."""
from pathlib import Path
import hashlib,json,subprocess
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-icon-controls');records=r/'docs/reports/macos-icon-controls/records'
h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
e=json.loads((p/'endpoints.json').read_text());q=json.loads((p/'qualification.json').read_text());source=json.loads((p/'source-final-v2.json').read_text())
review=json.loads((p/'evidence-review-final.json').read_text());assert review.get('result',review.get('status'))=='APPROVED_EVIDENCE' and review['endpoints']==e
for filename,digest in review['reviewed_artifact_sha256'].items():assert h(Path(filename))==digest,filename
assert h(p/'qualification.json')==e['qualification_sha256'] and h(r/'docs/reports/macos-icon-controls/README.md')==e['report_sha256'] and h(records/'evidence.tar.xz')==e['archive_sha256'] and h(records/'evidence-index.json')==e['index_sha256']
assert all(h(r/n)==digest for n,digest in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()};assert prepared==q['prepared']
(records/'evidence-review.json').write_bytes((p/'evidence-review-final.json').read_bytes())
checkpoint={'result':'REVIEWED_ICON_CONTROLS','base_commit':source['base_commit'],'source_manifest_sha256':e['source_manifest_sha256'],'qualification_sha256':e['qualification_sha256'],'source_review_sha256':e['source_review_sha256'],'evidence_review_sha256':h(p/'evidence-review-final.json'),'report_sha256':e['report_sha256'],'archive':{'sha256':e['archive_sha256'],'members':e['archive_members'],'index_sha256':e['index_sha256']},'prepared_files':e['prepared_files'],'command_receipts':e['receipts'],'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':q['prism_findings'],'prism_findings_resolved':True,'prism_sha256':e['prism_sha256'],'prism_raw_exit_code':q['prism_raw_exit_code'],'provider_disposition':q['provider_disposition'],'source':source['sources'],'promotion_producer_sha256':h(p/'promote.py'),'checkpoint_producer_sha256':h(Path(__file__)),'limits':q['limits']}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip()==checkpoint['base_commit']
print('Checkpoint verified; evidence artifacts',len(review['reviewed_artifact_sha256']))
