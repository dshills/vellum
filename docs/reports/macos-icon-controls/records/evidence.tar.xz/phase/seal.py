"""Seal scoped runtime, source review and single-provider evidence; never run UI."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-icon-controls')
report=r/'docs/reports/macos-icon-controls';records=report/'records'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
baseline=json.loads((p/'source-final-v1.json').read_text());final=json.loads((p/'source-final-v2.json').read_text())
assert len(final['sources'])==18 and set(final['sources'])==set(baseline['sources'])
assert all(h(r/n)==digest for n,digest in final['sources'].items())
changed=[n for n in final['sources']if final['sources'][n]!=baseline['sources'][n]]
assert changed==['specs/controls.md']
assert (p/'candidate-v2/specs/controls.md').read_bytes()==(r/'specs/controls.md').read_bytes()+b'\n'
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
previous=json.loads(Path('/private/tmp/vellum-macos-split-pane/qualification.json').read_text())
assert len(prepared)==6198 and prepared==previous['prepared']
receipts={}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv' not in d or 'source_delta_before' not in d:continue
 assert d['exit_code'] in [0,1] and d['error']is None and d['source_delta_stable']
 assert d['prepared_before']==d['prepared_after']==prepared
 assert d['overlay_inputs_before']==d['overlay_inputs_after']
 for channel in ['stdout','stderr']:assert h(p/(f.stem+'.'+channel))==d[channel+'_sha256']
 receipts[f.stem]={'receipt_sha256':h(f),'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'source':d['source_delta_before'],'stdout_sha256':d['stdout_sha256'],'stderr_sha256':d['stderr_sha256']}
required=['icons-final-v1','portable-final-v2','adapter-final-v2','vet-final-v2','gallery-final-v2']
for name in required:
 d=json.loads((p/(name+'.json')).read_text())
 assert d['exit_code']==0 and d['source_delta_before']==baseline['sources']
negative={'button-unscoped-v2':'button bypassed owner delivery','button-retirement-v1':'removed button delivered queued action','icon-final-style-v2':'icon removal/change or explicit sizing not retained'}
for name,message in negative.items():
 d=json.loads((p/(name+'.json')).read_text())
 assert d['exit_code']==1 and d['source_delta_before']==baseline['sources'] and message in (p/(name+'.stdout')).read_text()
 output=(p/(name+'.stdout')).read_text()
 assert '=== RUN   TestIcons' in output and '--- FAIL: TestIcons' in output and '[build failed]' not in output and d['overlay_inputs_before']
 for filename,digest in d['overlay_inputs_before'].items():assert h(Path(filename))==digest
review=json.loads((p/'review-final-v2.json').read_text())
assert review.get('result',review.get('status'))=='APPROVED_SOURCE'
assert review['reviewed_file_sha256']=={str(r/n):digest for n,digest in final['sources'].items()}
provider=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and process['source_index_stable'] and process['before']==process['after']==baseline['sources']
assert provider['coverage']['complete'] and provider['coverage']['files']==18 and not provider['findings']
assert provider['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert process['prism_sha256']==h(p/'prism-v1/prism.json')
families=[]
for manifest,directory in [('original-source.json','original'),('source-candidate-v1.json','candidate-v1'),('source-candidate-v2.json','candidate-v2')]:
 m=json.loads((p/manifest).read_text())
 for name,digest in m['sources'].items():
  f=p/directory/name;assert h(f)==digest;families.append((name,digest))
families.extend(final['sources'].items())
gaps={name:[leaf for leaf,digest in receipt['source'].items()if(leaf,digest)not in families]for name,receipt in receipts.items()}
(p/'historical-source-payloads.json').write_text(json.dumps({'available_manifests':['original-source.json','source-candidate-v1.json','source-candidate-v2.json','source-final-v2.json'],'receipt_payload_gaps':gaps,'scope':'Exact selected original/candidate/final root leaves plus declared mutation-overlay payloads; initial source variants with listed gaps are historical diagnostics only; not a full compiler/dependency/SDK closure.'},indent=2)+'\n')
limits=['Full Mac, physical input/VoiceOver, native/GPU memory, sustained performance/endurance and release/distribution qualification remain open.',
 'Five passing runtime/build receipts bind baseline18. Final18 differs only by one removed terminal LF in a specification; executable/test leaves are identical. Final internal review binds current source.',
 'One provider review covers complete baseline18; final documentation-only formatting is separately approved; provider is not repeated.',
 'Software frames and actual Manual routing, direct retained fixtures and inert Cocoa selector checks have distinct scopes. Gallery is BUILD ONLY.',
 'Prepared6198 identities and selected root payloads are endpoints; compiler/SDK/native binary closure and initial historical variants with listed payload gaps are not archived.',
 'Mutation overlays exercise current fixtures with declared faulty seams; they are not complete original-production builds.']
q={'result':'PASS_ICON_CONTROLS','base_commit':final['base_commit'],'source':final['sources'],'runtime_source':baseline['sources'],'final_documentation_delta':{'path':changed[0],'operation':'remove one final LF','baseline_sha256':baseline['sources'][changed[0]],'final_sha256':final['sources'][changed[0]]},'required_receipts':required,'negative_receipts':negative,'prepared':prepared,'receipts':receipts,'source_review_sha256':h(p/'review-final-v2.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'prism_coverage':provider['coverage'],'prism_raw_exit_code':0,'prism_findings':0,'prism_findings_resolved':True,'provider_disposition':'Complete baseline18 approved by one provider run, zero findings. Final code/test bytes unchanged; one specification terminal LF removed and internally approved.','limits':limits}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(parents=True,exist_ok=True)
failed=sum(d['exit_code']==1 for d in receipts.values())
(report/'README.md').write_text(f'''# Built-in icons and button presentation

Vellum adds a retained passive `ui.Icon`, 23 portable symbol names returned by
`ui.Symbols()`, icon-bearing Button/ToggleButton and primary, secondary, quiet
and compact toolbar-action button appearances. Unknown names/raw SVG/paths are
refused. Application styles and themes override native defaults. Unlabeled icons
are decorative; labeled icons have a passive Mac image role. Icon-only actions
require a nonblank accessible name. Icons add no action or Tab stop.
Toggle symbols occupy both accepted states; omission restores the ordinary native
checked-state indicator. Presentation changes retain widget, model and callbacks.
See the [catalog](../../controls.md) and [contract](../../../specs/controls.md).

Buttons now join the bounded window-scoped owner queue. Delivery uses the current
callback and disabled ancestry; removal and window closure revoke pending work.
This deliberately replaces the preceding synchronous global Application.Do route.
The keyed reconciliation fixture now registers its model window, queues before
callback replacement and drains after reordering. A separate closure fixture keeps
another window alive and proves its owner admission while origin actions are refused.

## Verification and review

Portable race, complete offscreen adapter race, focused icon/gallery/keyed race3,
adapter vet and native gallery BUILD ONLY pass. The full adapter execution takes
90.60 seconds. Tests parse and rasterize all 23 symbols, route actual Manual pointer
and keyboard input, compare completed appearance pixels, preserve incarnation and
accepted toggle state, exercise style override/restoration, validate owner delivery,
and check named/decorative semantics. Inert Cocoa checks the production AXImage
selector without creating a window. These are distinct from human VoiceOver,
physical input or native memory/performance acceptance.

Three declared mutation overlays compile and fail real assertions: an unscoped
synchronous Do route bypasses deferred delivery; skipping retirement delivers a
removed button; removing managed FinalStyler loses explicit icon size. The same
final executable/test leaves pass race3. These are localized faulty seams in the
new adapter, not complete original-production builds.

Internal source review approves the final 18 leaves. Prism runs once with Anthropic
Claude Sonnet 5.5, complete 18-file coverage, 3 chunks, 36,592 input/2,804 output
tokens, raw exit 0 and no findings. One trailing specification blank line caught
by the precommit whitespace check was removed as a final formatting correction.
The final 18-file source differs from the reviewed and executed baseline only by
removing that one terminal LF; all executable/test
leaves are identical. Separate final internal review binds this formatting change.
Prism and runtime checks are not repeated for the unchanged behavior; no claim is
made that earlier executions saw the later documentation byte.

Initial sandbox refusal for local Unix sockets, a compile error from using a
nonexistent Switch.SetIcon member, and the legacy unregistered-window/synchronous
fixture failure are preserved as historical attempts. Toggle artwork now uses
native IconOn/IconOff; the permitted socket suite and corrected fixture pass.
{len(receipts)} receipts/{len(receipts)*2} logs preserve {failed} raw exit-1 attempts.
Exact original, candidate and final selected payloads and mutation inputs are
archived; the historical map lists early source-payload gaps. Binaries/caches and
full compiler/SDK/native dependency closure are excluded. The 6,198 prepared identities
remain unchanged and do not by themselves certify third-party artwork/asset rights.

Separate evidence review binds the [checkpoint](records/checkpoint.json),
[archive](records/evidence.tar.xz) and [member index](records/evidence-index.json).
Physical Mac input/accessibility/display workflows, native/GPU memory, sustained
performance/endurance, distribution rights/signing/release and full Mac framework
completion remain open. The gallery was built without launch.
''')
(records/'source-review.json').write_bytes((p/'review-final-v2.json').read_bytes())
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in ['.go','.m','.json','.md','.py','.stdout','.stderr','.txt','.log']:continue
 if f.name.startswith('evidence-review') or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in final['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size}for n,f in inputs.items()}
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','w:xz')as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
e={'source_manifest_sha256':h(p/'source-final-v2.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.xz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'review-final-v2.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e,indent=2))
