from pathlib import Path
import json
p=Path('/private/tmp/vellum-macos-tree-retention')
e=[]
for line in (p/'composed-1000.stdout').read_text().splitlines():
 try:e.append(json.loads(line))
 except json.JSONDecodeError:pass
cycles=[x for x in e if x.get('event')=='vellum.composed-cycle'];samples=[x['sample']for x in e if x.get('event')=='vellum.window-cycle.sample']
print(json.dumps({'completed_cycles':len(cycles),'last_cycle':cycles[-1]['cycle']if cycles else None,'last_sample':samples[-1]if samples else None,'finished_receipt':(p/'composed-1000.json').exists(),'stderr_bytes':(p/'composed-1000.stderr').stat().st_size}))
