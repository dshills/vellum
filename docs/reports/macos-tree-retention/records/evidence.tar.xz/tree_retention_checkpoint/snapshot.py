from pathlib import Path
import datetime,hashlib,json,subprocess,sys
P=Path('/private/tmp/vellum-macos-tree-retention');R=Path('/private/tmp/vellum-large-data');sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
name=sys.argv[1];expected=str(P/'window-cycle');raw=subprocess.check_output(['ps','-axo','pid=,args='],text=True)
rows=[]
for line in raw.splitlines():
 parts=line.strip().split(None,1)
 if len(parts)==2 and parts[1].startswith(expected+' -composed -cycles=1000 '):rows.append((int(parts[0]),parts[1]))
assert len(rows)==1,rows
pid,command=rows[0];before=subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True).strip();assert before==command
cycles=[]
for line in (P/'composed-1000.stdout').read_text().splitlines():
 try:x=json.loads(line)
 except json.JSONDecodeError:continue
 if x.get('event')=='vellum.composed-cycle':cycles.append(x['cycle'])
r=run_child(['vmmap','-summary',str(pid)],capture_output=True,timeout=30)
(P/(name+'.stdout')).write_bytes(r.stdout);(P/(name+'.stderr')).write_bytes(r.stderr)
record={'argv':['vmmap','-summary',str(pid)],'owned_command':command,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed_cycles_at_capture':max(cycles,default=0),'exit_code':r.returncode,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
for channel in ['stdout','stderr']:record[channel+'_sha256']=hashlib.sha256((P/(name+'.'+channel)).read_bytes()).hexdigest()
(P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(r.returncode)
