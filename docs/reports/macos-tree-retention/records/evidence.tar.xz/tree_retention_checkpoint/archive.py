from pathlib import Path
import json,hashlib,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-tree-retention');D=R/'docs/reports/macos-tree-retention/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==0 and not process['error']and process['source_index_stable']and review['coverage']['complete']and review['coverage']['files']==5 and not review['findings']
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'internal-terminal-review.json').read_text());assert internal['result']=='APPROVED_EVIDENCE'and not internal['unresolved_findings']
summary=json.loads((P/'final-summary.json').read_text());assert summary['cycles']==1000 and summary['forced_gc_samples']==41 and summary['tree_ax_rows_counts']==[18]
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.heap'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['tree_retention_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Frozen committed framework/native acceptance input;1000sequentialcomposedcycles,41samples,2ownednativevmmap snapshots, diagnosticheap, exactprovenancevalidator/internalsourceandevidencereviews;5filereportPrism. Nativebinaryexcluded; hashinreceipt.'},indent=2)+'\n')
q={'result':'REVIEWED_1000_COMPOSED_TREE_RETENTION','base_commit':summary['commit'],'sources':sources,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':0,'prism_coverage_complete':True,'prism_files':5,'prism_findings':0,'cycles':1000,'tree_ax_rows_each':18,'forced_gc_samples':41,'prepared_files':6204,'prepared_changed':False,'production_code_changed':False,'full_p6_qualified':False,'full_p11_qualified':False,'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
