from pathlib import Path
import hashlib,json,re,subprocess
from run import identity
P=Path('/private/tmp/vellum-macos-tree-retention');R=Path('/private/tmp/vellum-large-data')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def load(n):return json.loads((P/(n+'.json')).read_text())
def receipt(n):
 x=load(n);assert x['exit_code']==0 and not x['error']and x['source_prepared_stable']
 assert x['baseline_sha256']==sha(P/'baseline.json')and x['source_commit']==load('baseline')['commit']
 assert x['producer_sha256']==sha(P/'run.py')and x['authorization_sha256']==sha(P/'testing-authorization.json')
 for channel in ['stdout','stderr']:assert x[channel+'_sha256']==sha(P/(n+'.'+channel))
 return x
baseline=load('baseline');assert len(baseline['prepared'])==6204 and not baseline['source_status']
assert identity()==baseline
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==baseline['commit']
assert all(sha(R/n)==h for n,h in baseline['selected_source'].items())
actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert actual==baseline['prepared']
build=receipt('retention-build');run=receipt('composed-1000');assert run['source_commit']==baseline['commit']and run['executable_sha256']==sha(P/'window-cycle')
assert build['mode']=='build'and build['argv']==['go','build','-tags=vellum_native_checks','-o',str(P/'window-cycle'),'./cmd/window-cycle-smoke']
assert run['mode']=='live'and run['argv']==[str(P/'window-cycle'),'-composed','-cycles=1000','-sample-every=25','-timeout=45m','-heap-profile='+str(P/'final.heap')]
assert run['timeout_seconds']==3000 and run['authorization_sha256']=='0896c3d50e2557a1b1739bc22d7304e17b513bb8350990318dbf68f74fbcd369'
ev=[json.loads(x)for x in (P/'composed-1000.stdout').read_text().splitlines()if x.startswith('{')];cycles=[x for x in ev if x.get('event')=='vellum.composed-cycle'];results=[x for x in ev if x.get('event')=='vellum.window-cycle.result'];assert len(cycles)==1000 and len(results)==1
assert [c['cycle']for c in cycles]==list(range(1,1001))
for c in cycles:
 assert c['native_text_accepted']and c['editor_history_replayed']and c['grid_tree_completed']and c['tree_accessibility_completed']and c['tree_accessibility_rows']>0 and c['modal_open_close']and c['all_dense_labels_fully_visible']and c['dense_defined']==c['dense_fully_visible']==1000 and not c['full_p11_qualified']
result=results[0];assert result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['requested_cycles']==result['completed_cycles']==1000 and result['composed_workspace']and not result['full_p11_qualified']and not result['preferences_changed']and not result['clipboard_access']
cleanup=result['native_cleanup'];assert cleanup['MainThread']and cleanup['CleanupObserved']and cleanup['CallbacksStopped']and not cleanup['WindowTitles']and cleanup['NativeOutstanding']==cleanup['AccessibilityWindows']==cleanup['PendingCallbacks']==0
samples=result['samples'];assert len(samples)==41 and [s['Completed']for s in samples]==list(range(0,1001,25));assert [x['sample']for x in ev if x.get('event')=='vellum.window-cycle.sample']==samples
assert result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20
assert result['samples_after_forced_gc']and result['geometry_persistence_disabled_in_fixture']
assert all(s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 for s in samples)
assert result['heap_profile_requested']and 0<(P/'final.heap').stat().st_size<=8<<20
snapshots=[]
for n in ['vmmap-early','vmmap-late']:
 x=load(n);assert x['exit_code']==0 and x['owned_command']==' '.join(run['argv'])
 assert x['argv'][:2]==['vmmap','-summary']and len(x['argv'])==3 and x['producer_sha256']==sha(P/'snapshot.py')
 for channel in ['stdout','stderr']:assert x[channel+'_sha256']==sha(P/(n+'.'+channel))
 lines=(P/(n+'.stdout')).read_text().splitlines();headers=[s for s in lines if s.startswith('Process:')];assert len(headers)==1 and re.search(r'\['+re.escape(x['argv'][2])+r'\]$',headers[0])
 chosen=[s.strip()for s in lines if s.startswith(('Physical footprint:','Physical footprint (peak):','MALLOC_SMALL ','IOSurface ','owned unmapped (graphics)','TOTAL '))]
 snapshots.append({'name':n,'pid':int(x['argv'][2]),'cycle':x['completed_cycles_at_capture'],'raw_native_summary_lines':chosen})
assert snapshots[0]['cycle']<snapshots[1]['cycle']
assert snapshots[0]['pid']==snapshots[1]['pid']
warm=[s for s in samples if s['Completed']>=100]
summary={'result':'PASS_1000_COMPOSED_CYCLES_AND_NATIVE_OUTLINE_COMPLETION','commit':baseline['commit'],'executable_sha256':run['executable_sha256'],'prepared_files':6204,'prepared_changed':False,'elapsed_seconds':run['elapsed_seconds'],'cycles':1000,'dense_labels_per_cycle':1000,'tree_ax_rows_counts':sorted(set(c['tree_accessibility_rows']for c in cycles)),'forced_gc_samples':len(samples),'warm_sample_cycles':[100,1000],'warm_go_heap_bytes':[min(s['HeapAlloc']for s in warm),max(s['HeapAlloc']for s in warm)],'warm_rss_bytes':[min(s['RSSBytes']for s in warm),max(s['RSSBytes']for s in warm)],'terminal_sample':samples[-1],'native_cleanup':cleanup,'native_snapshots':snapshots,'heap_profile_sha256':sha(P/'final.heap'),'heap_profile_bytes':(P/'final.heap').stat().st_size,'full_p6_qualified':False,'full_p11_qualified':False,'gpu_memory_qualified':False,'native_heap_budget_qualified':False,'scope':'One sampled lifecycle/retention campaign, perturbed by two read-only vmmap snapshots. Logical and native outline completion per cycle; no frame/presentation/input-latency, physical-display, human screen-reader or overnight qualification.'}
(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
