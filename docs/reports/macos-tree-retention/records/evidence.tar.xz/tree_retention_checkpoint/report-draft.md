# Completed-outline composed native retention

This campaign repeats the all-component native window lifecycle workload on
committed bf3b1b5, after the tree completion/retained-view publication fixes.
Each fresh workspace contains every accepted UI kind, editor/history, managed
Grid and Tree, docked GPU canvas, modal and 1000 density labels. The acceptance
command additionally requires the current owner tree inspection to match an
actual completed Cocoa outline transaction and its native row metadata.

The run freezes committed source and all 6204 prepared dependency files. It uses
one owned process group, a 45-minute cooperative native deadline and 50-minute
external watchdog. Samples force Go GC every 25 cycles and apply the existing
512 MiB Go-heap and 1 GiB RSS guards. Two read-only vmmap snapshots perturb the
run and remain allocation-region observations rather than GPU-memory claims.
The fixture disables only its own geometry persistence and accesses no clipboard
or OS input/accessibility preferences. It does not hide failures by raising guards.

Results pending. The raw process exit, endpoint source/prepared checks, 1000
sequential cycle records, native outline row counts, 41 samples and terminal
native cleanup must all qualify before this report records a pass.

Observed native text acceptance counts only after the controlled model changes.
Editor history and initial Grid/Tree changes are direct owner operations. Most
standard control callbacks, hierarchical disclosure and data views within a modal
are not exercised by this fixture. Density proves native semantic frame containment,
not physical raster legibility or the requested geometry at 100% display scale.
No pacing, input latency, ordinary frame budget, five cold/warm populations,
human screen-reader, physical display or overnight-soak claim follows.
