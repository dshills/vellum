APPROVED_SOURCE — four exact sources bound; no unresolved findings.

The detached cache and completed identity are installed atomically. Direct preparation invalidates that identity; final publication cannot re-certify it. Full JSON/custom marshaling stays outside the mutex. Scalar, scope, Go-focus metadata and type guards preserve fallback and newest-handler behavior.

Tests cover cache detachment/reuse, invalidation, metadata/type changes, custom/mutable/borrowed fallback and lifecycle retirement. This is source approval only; final code/benchmark evidence is separate. No native/whole-frame performance, public API expansion or broader Mac qualification is inferred.
