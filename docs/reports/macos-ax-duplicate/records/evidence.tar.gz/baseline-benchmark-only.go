//go:build offscreen

package cogent

import (
	"fmt"
	"testing"
)

// Measure the duplicate publication phase with fresh transferred containers on
// every owned call. No native window or changed native publication is created.
func BenchmarkAccessibilityDuplicatePublication(b *testing.B) {
	for _, cells := range []int{0, 40, 400} {
		for _, owned := range []bool{false, true} {
			b.Run(fmt.Sprintf("cells-%d/owned-%t", cells, owned), func(b *testing.B) {
				fixture := gridAXPayloadFixture(cells)
				semantic, err := accessibilitySemantic(fixture)
				if err != nil {
					b.Fatal(err)
				}
				bridge := &accessibilityBridge{lastSnapshot: semantic}
				bridge.prepareGridPublication(fixture, nil)
				publish := func() {
					nodes := cloneAccessibilityNodes(fixture)
					handlers := gridAXHandlers(nodes, nil)
					if owned {
						bridge.updateOwned(nodes, handlers)
					} else {
						bridge.update(nodes, handlers)
					}
				}
				publish()
				b.ReportAllocs()
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					publish()
				}
				b.StopTimer()
				if bridge.generation.Load() != 0 {
					b.Fatal("benchmark published native changes")
				}
				accessibilityPayloadBenchmarkSink = bridge.lastSnapshot
			})
		}
	}
}

