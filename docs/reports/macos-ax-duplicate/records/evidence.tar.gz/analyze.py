from pathlib import Path
import hashlib,json,re,statistics,subprocess
R=Path('/private/tmp/vellum-ax-duplicate');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((P/'source.json').read_text());sources=source['sources']
assert all(sha(R/n)==h for n,h in sources.items())
checks={}
for name,expected in [('baseline-bench-v3',0),('candidate-bench-v3',0),('full-offscreen-race-v3',0),('vet-v3',0),('native-build-v4',0),('no-reuse-fault-v3',1),('invalidation-fault-v3',1)]:
 d=json.loads((P/(name+'.json')).read_text())
 assert d['exit_code']==expected and d['error']is None and not d['live_tests'] and not d['headless_gpu_requested']
 assert d['source_commit']==source['base_commit'] and d['source_delta_stable'] and d['source_delta_before']=={**sources,'docs/reports/macos-ax-duplicate/README.md':sha(P/'pre-final-report.md')}
 assert d['prepared_before']==d['prepared_after'] and len(d['prepared_before'])==6217
 assert d['overlay_inputs_before']==d['overlay_inputs_after']
 for suffix in ['stdout','stderr']:assert sha(P/(name+'.'+suffix))==d[suffix+'_sha256']
 checks[name]={'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'receipt_sha256':sha(P/(name+'.json')),'stdout_sha256':d['stdout_sha256'],'stderr_sha256':d['stderr_sha256']}
assert 'identical owned refresh replaced detached completed storage' in (P/'no-reuse-fault-v3.stdout').read_text()
assert 'direct removal kept ready identity' in (P/'invalidation-fault-v3.stdout').read_text()
for name in ['accessibility.go','accessibility_grid_publication.go']:
 assert (P/('baseline-'+name)).read_bytes()==subprocess.check_output(['git','show',source['base_commit']+':drivers/cogent/'+name],cwd=R)
benchmark=(R/'drivers/cogent/accessibility_duplicate_offscreen_test.go').read_text().split('// Seed a duplicate-only bridge')[0].replace('\n\t"reflect"','')
assert (P/'baseline-benchmark-only.go').read_text()==benchmark

def parse(name):
 rows={}
 for line in (P/(name+'.stdout')).read_text().splitlines():
  m=re.match(r'BenchmarkAccessibilityDuplicatePublication/(\S+)-\d+\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
  if m:rows.setdefault(m[1],[]).append([int(x)for x in m.groups()[1:]])
 assert len(rows)==6 and all(len(r)==5 for r in rows.values())
 return rows
before,after=parse('baseline-bench-v3'),parse('candidate-bench-v3');comparison={}
for key in before:
 b=[statistics.median(x[i]for x in before[key])for i in range(3)];a=[statistics.median(x[i]for x in after[key])for i in range(3)]
 comparison[key]={'baseline_samples':before[key],'candidate_samples':after[key],'columns':['ns_per_op','bytes_per_op','allocs_per_op'],'baseline_median':b,'candidate_median':a,'median_change_percent':[round((a[i]/b[i]-1)*100,4)for i in range(3)]}
summary={'result':'PASS_SCOPED_DUPLICATE_AX_CACHE','base_commit':source['base_commit'],'sources':sources,'checks':checks,'prepared_files':6217,'prepared_stable':True,'benchmark':comparison,'native_binary_sha256':sha(P/'window-cycle-smoke-final'),'native_binary_executed':False,'live_tests':False,'full_mac_qualified':False,'limits':['Benchmark includes fresh node/handler container creation, full encoding and duplicate preparation; no native sends/windows/frame timings.','Five sequential samples per benchmark/route at 0,40,400cells. Human online, no quiet-host wall-time qualification or statistical-significance claim.','Original implementation supplied by exact Git blob overlay with identical benchmark body; new cache-specific tests omitted only from original overlay.','Full adapter root-package offscreen race/vet and native fixture compile pass; command subpackage suites and native runtime not run.','First untagged native compile refused build constraints; corrected compile used required vellum_native_checks.','Preliminary v1/v2 checks are historical endpoints. Final v3 checks bind ownership-correct test captures; tagged build is v4. Benchmark body and runtime implementation are unchanged from v2. Report updated only after final checks; its check-time version is retained separately.','Long native endurance failed at123/1000 and remains unresolved; live performance, retention, physical interaction and release audit remain open.']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'checks':checks,'owned400':comparison['cells-400/owned-true']}))
