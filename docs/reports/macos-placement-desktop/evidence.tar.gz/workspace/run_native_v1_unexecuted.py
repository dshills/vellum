"""One owned WindowServer placement session; external CUA supplies input."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, selectors, signal, subprocess, sys, time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-placement-desktop-native')
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'))
from child_process import terminate_owned_group,run_child
from sdk_environment import child_environment
sys.path.insert(0,'/private/tmp/vellum-empty-text-native-isolated-v2')
from live_lease import LiveLease
from build_native import identity,sha
STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
def read(p):return json.loads(Path(p).read_bytes())
def need(value,message):
 if not value:raise ValueError(message)
def absence(pid):
 r=run_child(['ps','-axo','pid=,pgid=,stat='],env=child_environment(),capture_output=True,timeout=5)
 need(r.returncode==0 and not r.stderr,'owned group observation')
 for line in r.stdout.decode().splitlines():
  fields=line.split();need(len(fields)==3,'ps fields');need(int(fields[1])!=pid,'owned group remains')
 return dict(group=pid,members=[],observation_sha256=hashlib.sha256(r.stdout).hexdigest())
def main():
 need(len(sys.argv)==1,'no arguments')
 review=read(W/'native-readiness.json');need(review['execution_ready']and review['unresolved_findings']==[],'native readiness')
 pins=review['inputs'];need(all(sha(p)==h for p,h in pins.items()),'review pins')
 build=read(P/'build.json');source=read(P/'source.json');need(build['exit_code']==0 and build['source_stable']and build['source_commit']==source['commit'],'clean build')
 binary=Path(build['binary']['path']);need(binary.stat().st_size==build['binary']['bytes']and sha(binary)==build['binary']['sha256'],'binary pin')
 need(identity()==source,'source vector')
 def stable():return all(sha(p)==h for p,h in pins.items())and sha(binary)==build['binary']['sha256']
 def stopping():return STOP.exists()or(P/'stop-live').exists()
 need(not stopping(),'human-return marker')
 with LiveLease()as lease:
  need(lease.held()and not stopping()and stable(),'lease/source/stop admission')
  out=P/'run-1';out.mkdir(mode=0o700)
  env={**child_environment(True),'GOMAXPROCS':'2','VELLUM_NATIVE_PLACEMENT_PROBE':str(out)}
  argv=[str(binary)];d=dict(result='STARTED',argv=argv,cwd=str(T/'examples/placement'),source_commit=source['commit'],build_sha256=sha(P/'build.json'),review_sha256=sha(W/'native-readiness.json'),producer_sha256=sha(__file__),pins=pins,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=None,error=None,cleanup_errors=[],native_runtime_executed=False,group_absence_confirmed=False,direct_child_terminal=False,lease_held_through_cleanup=False,watchdog_seconds=710,settings_changes=False)
  child=None;start=time.monotonic();counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()]
  try:
   with(P/'native.stdout').open('xb')as stdout,(P/'native.stderr').open('xb')as stderr,selectors.DefaultSelector()as ready:
    need(stable()and lease.held()and not stopping(),'final admission')
    child=subprocess.Popen(argv,cwd=d['cwd'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    d.update(pid=child.pid,process_group=child.pid,native_runtime_executed=True)
    with(P/'owned-process.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(result='OWNED_NATIVE_PROCESS_STARTED',pid=child.pid,output=str(out))),flush=True)
    for i,pipe in enumerate([child.stdout,child.stderr]):ready.register(pipe,selectors.EVENT_READ,i)
    terminal=None
    while ready.get_map()or child.poll()is None:
     need(not stopping(),'human-return marker')
     if time.monotonic()-start>710:raise TimeoutError('native watchdog')
     if child.poll()is not None:
      if terminal is None:terminal=time.monotonic()
      if time.monotonic()-terminal>5:raise TimeoutError('pipe writers survived child')
     for key,_ in ready.select(.2):
      data=os.read(key.fd,64<<10)
      if not data:ready.unregister(key.fileobj);continue
      i=key.data;limit=[64<<20,4<<20][i];accepted=min(len(data),limit-counts[i])
      if accepted:
       stream=[stdout,stderr][i];need(stream.write(data[:accepted])==accepted,'short native log write');stream.flush();counts[i]+=accepted;digests[i].update(data[:accepted])
      need(accepted==len(data),'native log bound')
    d['exit_code']=child.wait(timeout=5)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   def fail(stage,e):d['cleanup_errors'].append(dict(stage=stage,type=type(e).__name__,message=str(e)))
   if child is not None:
    try:
     if child.poll()is None:
      try:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=5)
      except(ProcessLookupError,subprocess.TimeoutExpired):pass
    except BaseException as e:fail('graceful-retirement',e)
    try:terminate_owned_group(child)
    except BaseException as e:fail('forced-retirement',e)
    try:
     if child.poll()is None:child.kill()
     d['exit_code']=child.wait(timeout=5);d['direct_child_terminal']=child.poll()is not None
    except BaseException as e:fail('direct-child-reap',e)
    for pipe in [child.stdout,child.stderr]:
     try:pipe.close()
     except BaseException as e:fail('pipe-close',e)
    try:d['group_observation']=absence(child.pid);d['group_absence_confirmed']=True
    except BaseException as e:fail('group-absence',e)
   try:d['source_stable']=identity()==source;d['pins_stable']=stable()
   except BaseException as e:fail('identity',e)
   try:
    d['logs']={n:dict(bytes=counts[i],sha256=sha(P/n),stream_sha256=digests[i].hexdigest())for i,n in enumerate(['native.stdout','native.stderr'])}
    d['logs_complete']=all(v['sha256']==v['stream_sha256']and v['bytes']==(P/n).stat().st_size for n,v in d['logs'].items())
   except BaseException as e:fail('log-identity',e)
   d.update(lease_held_through_cleanup=lease.held(),elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stop_marker_at_exit=stopping())
   good=d['exit_code']==0 and d['error']is None and not d['cleanup_errors']and d['direct_child_terminal']and d['group_absence_confirmed']and d.get('source_stable')and d.get('pins_stable')and d.get('logs_complete')and lease.held()and not stopping()
   d['result']='TERMINAL_NATIVE_PROCESS_OK'if good else'FAILED_OR_CANCELED_NATIVE_PROCESS'
   with(P/'native.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
   print(json.dumps({k:d[k]for k in ['result','exit_code','error','cleanup_errors','elapsed_seconds']}),flush=True)
  need(good,'native process failed or canceled')
if __name__=='__main__':main()
