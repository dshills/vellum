"""Save read-only native model evidence after an externally supplied CUA action."""
from pathlib import Path
import datetime,hashlib,json,sys
P=Path('/private/tmp/vellum-placement-desktop-native');R=P/'run-1'
def main():
 step=sys.argv[1];assert step and all(c.isalnum()or c in '-_'for c in step)
 data=(R/'latest.json').read_bytes();assert 0<len(data)<=256<<10
 latest=json.loads(data);assert latest['native_platform']=='MacOS'and latest['geometry_persistence_disabled']is True
 log=(R/'events.jsonl').read_bytes();assert len(log)<=8<<20
 d=dict(step=step,captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),latest_sha256=hashlib.sha256(data).hexdigest(),event_log_prefix_bytes=len(log),event_log_prefix_sha256=hashlib.sha256(log).hexdigest(),latest=latest)
 out=P/'steps';out.mkdir(exist_ok=True)
 with(out/(step+'.json')).open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 s=latest['state'];print(json.dumps(dict(step=step,event=latest['event'],observed_utc=latest.get('observed_utc'),objects=s['Objects'],history=s['History'],view=s['View'],gesture=s['Gesture'],source_activations=s['SourceActivations'],canvas_changes=s['CanvasChanges'],removals=s['Removals'],hidden_source=s['HiddenSource'],hidden_target=s['HiddenTarget'],snap=s['Snap'],locked=s['Locked'],reject_notes=s['RejectNotes'],armed=s['RemoveOnDrag'],reserved=s['Reserved'],selected=s['Selected'],frames=[(e['id'],e['frame'])for e in latest.get('accessibility',{}).get('elements',[])if e['name']in ['Block','Connector','Note','Component canvas']])))
if __name__=='__main__':main()
