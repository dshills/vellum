//go:build darwin && cgo && !offscreen && vellum_native_checks

package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"testing"
	"time"

	"cogentcore.org/core/core"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/canvas"
	"github.com/dshills/vellum/drivers/cogent"
	"github.com/dshills/vellum/history"
	"github.com/dshills/vellum/placement"
	"github.com/dshills/vellum/ui"
)

// AppKit's event loop must run on the original main OS thread. Go runs test
// functions on another goroutine, so the explicit desktop mode enters here.
// Ordinary tests keep their usual testing.M execution and never launch a window.
func TestMain(m *testing.M) {
	if os.Getenv("VELLUM_NATIVE_PLACEMENT_PROBE") == "" {
		os.Exit(m.Run())
	}
	flag.Parse()
	if flag.Lookup("test.run").Value.String() != "^TestNativePlacementDesktopProbe$" || len(flag.Args()) != 0 {
		fmt.Fprintln(os.Stderr, "native probe requires its exact explicit test selector")
		os.Exit(2)
	}
	os.Exit(nativePlacementProbeMain())
}

type nativeProbeReporter struct{ failed bool }

func (p *nativeProbeReporter) Error(v ...any)                 { p.failed = true; fmt.Fprintln(os.Stderr, v...) }
func (p *nativeProbeReporter) Fatal(v ...any)                 { p.Error(v...); panic("native probe failed") }
func (p *nativeProbeReporter) Fatalf(format string, v ...any) { p.Fatal(fmt.Sprintf(format, v...)) }
func (p *nativeProbeReporter) Skip(v ...any)                  { p.Fatal(v...) }
func nativePlacementProbeMain() (code int) {
	defer func() {
		if value := recover(); value != nil {
			fmt.Fprintln(os.Stderr, value)
			code = 1
		}
	}()
	p := &nativeProbeReporter{}
	runNativePlacementDesktopProbe(p)
	if p.failed {
		return 1
	}
	return 0
}

// This probe does not generate pointer/key events or invoke placement commands.
// An external desktop operator supplies those inputs to the ordinary demo view.
// Its diagnostic buttons model source/target removal during a real active drag.
type nativePlacementProbe struct {
	m                                          *model
	a                                          *app.Application
	ref                                        app.WindowRef
	sourceActivations, canvasChanges, removals int
	hideSource, hideTarget                     bool
	removeOnDrag                               string
}

func (p *nativePlacementProbe) view() ui.Node {
	root := view(p.a, p.ref, p.m)
	var wrap func(ui.Node) ui.Node
	wrap = func(n ui.Node) ui.Node {
		if n.PlacementSource != nil {
			old := n.Activate
			n.Activate = func() { p.sourceActivations++; old() }
		}
		if n.ID == "palette" && p.hideSource {
			n.Children = nil
		}
		if n.ID == "drawing" {
			if p.hideTarget {
				return ui.Node{ID: "probe-no-canvas", Kind: ui.Label, Text: "Canvas removed", Grow: true}
			}
			old := n.Change
			n.Change = func(e ui.ChangeEvent) { p.canvasChanges++; old(e) }
		}
		for i := range n.Children {
			n.Children[i] = wrap(n.Children[i])
		}
		return n
	}
	root = wrap(root)
	bar := ui.Node{ID: "probe-controls", Kind: ui.Toolbar}
	for _, mode := range []string{"source", "target", "window"} {
		bar.Children = append(bar.Children, ui.Node{ID: "probe-arm-" + mode, Kind: ui.Button, Text: "Remove " + mode + " on next drag", Activate: func() { p.removeOnDrag = mode; _ = p.a.Invalidate("placement") }})
	}
	bar.Children = append(bar.Children, ui.Node{ID: "probe-restore", Kind: ui.Button, Text: "Restore bindings", Activate: func() { p.hideSource, p.hideTarget, p.removeOnDrag = false, false, ""; _ = p.a.Invalidate("placement") }})
	root.Children = append(root.Children, bar)
	return root
}

type nativePlacementState struct {
	Objects                                               []canvas.Rect
	View                                                  canvas.Viewport
	Selected, Status                                      string
	History                                               history.State
	Gesture                                               placement.State
	SourceActivations, CanvasChanges, Removals            int
	HiddenSource, HiddenTarget, Snap, Locked, RejectNotes bool
	RemoveOnDrag                                          string
	Next                                                  uint64
	Reserved                                              int
}

func (p *nativePlacementProbe) state() nativePlacementState {
	return nativePlacementState{Objects: slices.Clone(p.m.scene.Objects), View: p.m.scene.View, Selected: p.m.scene.Selected, Status: p.m.status, History: p.m.journal.Snapshot(), Gesture: p.m.palette.State(), SourceActivations: p.sourceActivations, CanvasChanges: p.canvasChanges, Removals: p.removals, HiddenSource: p.hideSource, HiddenTarget: p.hideTarget, Snap: p.m.snap, Locked: p.m.locked, RejectNotes: p.m.rejectNotes, RemoveOnDrag: p.removeOnDrag, Next: p.m.next, Reserved: p.a.Pending().Reserved}
}

const nativeProbeByteLimit = 8 << 20

type nativeProbeWriter struct {
	root  string
	log   *os.File
	bytes int
}

func newNativeProbeWriter(root string) (*nativeProbeWriter, error) {
	if !filepath.IsAbs(root) || filepath.Clean(root) != root {
		return nil, fmt.Errorf("probe requires a clean absolute directory")
	}
	info, err := os.Lstat(root)
	if err != nil {
		return nil, err
	}
	if !info.IsDir() || info.Mode()&os.ModeSymlink != 0 || info.Mode().Perm()&0077 != 0 {
		return nil, fmt.Errorf("probe requires a private directory")
	}
	resolved, err := filepath.EvalSymlinks(root)
	if err != nil || resolved != root {
		return nil, fmt.Errorf("probe directory must not use symlinks")
	}
	entries, err := os.ReadDir(root)
	if err != nil {
		return nil, err
	}
	if len(entries) != 0 {
		return nil, fmt.Errorf("probe directory must be empty")
	}
	log, err := os.OpenFile(filepath.Join(root, "events.jsonl"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return nil, err
	}
	return &nativeProbeWriter{root: root, log: log}, nil
}
func (w *nativeProbeWriter) write(value any) error {
	data, err := json.Marshal(value)
	if err != nil {
		return err
	}
	data = append(data, '\n')
	if len(data) > 256<<10 || w.bytes+len(data) > nativeProbeByteLimit {
		return fmt.Errorf("probe output bound")
	}
	n, err := w.log.Write(data)
	w.bytes += n
	if err != nil {
		return err
	}
	if n != len(data) {
		return fmt.Errorf("short probe log write")
	}
	tmp := filepath.Join(w.root, "latest.tmp")
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	n, writeErr := f.Write(data)
	closeErr := f.Close()
	if err = errors.Join(writeErr, closeErr); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	if n != len(data) {
		_ = os.Remove(tmp)
		return fmt.Errorf("short probe snapshot write")
	}
	return os.Rename(tmp, filepath.Join(w.root, "latest.json"))
}

func TestNativePlacementDesktopProbe(t *testing.T) {
	t.Skip("desktop mode runs explicitly on TestMain's original OS thread")
}
func runNativePlacementDesktopProbe(t interface {
	Fatal(...any)
	Fatalf(string, ...any)
	Error(...any)
	Skip(...any)
}) {
	root := os.Getenv("VELLUM_NATIVE_PLACEMENT_PROBE")
	if root == "" {
		t.Skip("explicit private output and external desktop operator required")
	}
	w, err := newNativeProbeWriter(root)
	if err != nil {
		t.Fatal(err)
	}
	defer w.log.Close()
	previous := core.DebugSettings.DisableWindowGeometrySaver
	core.DebugSettings.DisableWindowGeometrySaver = true
	defer func() { core.DebugSettings.DisableWindowGeometrySaver = previous }()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()
	m, err := newModel()
	if err != nil {
		t.Fatal(err)
	}
	defer m.palette.Close()
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	p := &nativePlacementProbe{m: m, a: a}
	p.ref, err = a.OpenWindow(app.Window{ID: "placement", Title: "Vellum native placement probe", Width: 1100, Height: 800, View: p.view})
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() {
		var last []byte
		var ax cogent.AccessibilityInspection
		ticker := time.NewTicker(50 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				done <- nil
				return
			case <-ticker.C:
			}
			for _, marker := range []string{filepath.Join(root, "stop-live"), "/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live"} {
				if _, err := os.Stat(marker); err == nil {
					done <- fmt.Errorf("probe stopped by marker")
					cancel()
					return
				} else if !errors.Is(err, os.ErrNotExist) {
					done <- err
					cancel()
					return
				}
			}
			var state nativePlacementState
			if err := a.Do(func() {
				state = p.state()
				if state.Gesture.Active && state.Gesture.Dragging && p.removeOnDrag != "" {
					mode := p.removeOnDrag
					p.removeOnDrag = ""
					p.removals++
					switch mode {
					case "source":
						p.hideSource = true
					case "target":
						p.hideTarget = true
					case "window":
						a.Close()
					}
					_ = a.Invalidate("placement")
				}
			}); err != nil {
				if errors.Is(err, app.ErrClosed) {
					continue
				}
				done <- err
				cancel()
				return
			}
			encoded, err := json.Marshal(state)
			if err != nil {
				done <- err
				cancel()
				return
			}
			if bytes.Equal(encoded, last) && ax.Reachable {
				continue
			}
			query, stop := context.WithTimeout(ctx, 2*time.Second)
			next, axErr := cogent.InspectAccessibility(query, "placement")
			stop()
			if axErr == nil {
				ax = next
			}
			if err := w.write(map[string]any{"event": "placement.probe.sample", "observed_utc": time.Now().UTC(), "state": state, "accessibility": ax, "accessibility_error": fmt.Sprint(axErr), "geometry_persistence_disabled": core.DebugSettings.DisableWindowGeometrySaver}); err != nil {
				done <- err
				cancel()
				return
			}
			last = encoded
		}
	}()
	joined := false
	defer func() {
		cancel()
		if !joined {
			select {
			case <-done:
			case <-time.After(3 * time.Second):
			}
		}
	}()
	nativeErr := a.Run(ctx, cogent.Driver{Commands: m.commands})
	deadline := ctx.Err()
	cancel()
	var observerErr error
	select {
	case observerErr = <-done:
		joined = true
	case <-time.After(3 * time.Second):
		t.Fatal("probe observer did not join")
	}
	final := p.state() // Driver and observer have both stopped; model is now caller-owned.
	if err := w.write(map[string]any{"event": "placement.probe.closed", "state": final, "native_error": fmt.Sprint(nativeErr), "observer_error": fmt.Sprint(observerErr), "deadline_error": fmt.Sprint(deadline), "geometry_persistence_disabled": core.DebugSettings.DisableWindowGeometrySaver}); err != nil {
		t.Error(err)
	}
	if nativeErr != nil || observerErr != nil || deadline != nil || final.Gesture.Active || final.Reserved != 0 {
		t.Fatalf("native=%v observer=%v deadline=%v state=%+v", nativeErr, observerErr, deadline, final)
	}
}

func TestNativeProbeWriterPrivateAtomicBounds(t *testing.T) {
	root, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	w, err := newNativeProbeWriter(root)
	if err != nil {
		t.Fatal(err)
	}
	defer w.log.Close()
	if err := w.write(map[string]int{"value": 1}); err != nil {
		t.Fatal(err)
	}
	before, err := os.ReadFile(filepath.Join(root, "latest.json"))
	if err != nil {
		t.Fatal(err)
	}
	w.bytes = nativeProbeByteLimit
	if err := w.write(map[string]int{"value": 2}); err == nil {
		t.Fatal("unbounded log accepted")
	}
	after, _ := os.ReadFile(filepath.Join(root, "latest.json"))
	if !bytes.Equal(before, after) {
		t.Fatal("refusal replaced latest state")
	}
	if _, err := newNativeProbeWriter(root); err == nil {
		t.Fatal("nonempty directory accepted")
	}
	other, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(other, 0755); err != nil {
		t.Fatal(err)
	}
	if _, err := newNativeProbeWriter(other); err == nil {
		t.Fatal("nonprivate directory accepted")
	}
}
