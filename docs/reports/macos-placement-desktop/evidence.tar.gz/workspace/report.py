"""Preserve the failed desktop attempt without relabeling it as interaction proof."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-placement-desktop-native')
O=T/'docs/reports/macos-placement-desktop'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def main():
 review=read(W/'result-review.json');run=read(P/'native.json');build=read(P/'build.json');source=read(P/'source.json');post=read(P/'postflight.json')
 assert run['result']=='FAILED_OR_CANCELED_NATIVE_PROCESS'and run['exit_code']==1 and run['error']is None
 assert run['source_stable']and run['pins_stable']and run['logs_complete']and run['group_absence_confirmed']and run['direct_child_terminal']and run['lease_held_through_cleanup']and not run['cleanup_errors']
 rows=[json.loads(x)for x in(P/'run-1/events.jsonl').read_bytes().splitlines()];samples=rows[:-1];last=rows[-1]
 assert len(rows)==13 and len(samples)==12 and sum(r['accessibility']['reachable']for r in samples)==1
 assert last['event']=='placement.probe.closed'and last['deadline_error']=='context deadline exceeded'and last['native_error']==last['observer_error']=='<nil>'
 for row in rows:
  s=row['state'];assert not(s['Objects']or s['Gesture']['Active']or s['Reserved']or s['History']['UndoCount']or s['History']['RedoCount']or s['SourceActivations']or s['CanvasChanges']or s['Removals'])
 assert post['mouse_or_key_actions_requested']==0 and not post['members']and not post['exact_probe_processes']
 outcome=dict(operation="cua.getApp('com.vellum.placement.nativeprobe')",returned_error=post['cua_binding_result'],tool_wall_seconds=post['cua_binding_wall_seconds'],binding_succeeded=False,pointer_key_drag_actions_requested=0,cause='unassigned; application/external-accessibility/automation integration not diagnosed',retry_performed=False)
 (W/'cua-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
 O.mkdir()
 files={}
 def add(prefix,base,names):
  for n in names:
   p=base/n;assert p.is_file()and not p.is_symlink();data=p.read_bytes();assert len(data)<=2<<20
   key=prefix+'/'+n;assert key not in files;files[key]=data
 add('workspace',W,[p.relative_to(W).as_posix()for p in W.rglob('*')if p.is_file()])
 add('native',P,['build.json','build.stdout','build.stderr','source.json','go-version.txt','otool.txt','preflight.json','postflight.json','owned-process.json','native.json','native.stdout','native.stderr','run-1/events.jsonl','run-1/latest.json','steps/00-initial.json','Vellum Placement Probe.app/Contents/Info.plist'])
 checks=Path('/private/tmp/vellum-placement-desktop-v4-f1b9178')
 add('checks-v4',checks,[p.relative_to(checks).as_posix()for n in ['writer','routing','vet','compile']for p in(checks/n).iterdir()if p.is_file()])
 manifest=dict(schema='vellum-placement-desktop-evidence-v1',files={n:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for n,data in sorted(files.items())},binary_hash_only=build['binary'],native_workflow_accepted=False,physical_input_qualified=False)
 encoded=(json.dumps(manifest,indent=2)+'\n').encode();(O/'evidence.manifest.json').write_bytes(encoded)
 with(O/'evidence.tar.gz').open('xb')as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
  for n,data in sorted({**files,'MANIFEST.json':encoded}.items()):
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o600;info.mtime=0;archive.addfile(info,io.BytesIO(data))
 result=dict(source_commit=build['source_commit'],tracked_files=len(source['tracked']),prepared_files=len(source['prepared']),source_review_sha256=sha(W/'final-review.json'),result_review_sha256=sha(W/'result-review.json'),native_result=run['result'],native_exit_code=run['exit_code'],native_elapsed_seconds=run['elapsed_seconds'],native_error=last['native_error'],observer_error=last['observer_error'],deadline_error=last['deadline_error'],sample_records=len(samples),reachable_native_snapshots=1,startup_unavailable_snapshots=11,closed_records=1,jsonl_bytes=(P/'run-1/events.jsonl').stat().st_size,cua=outcome,group_absence_confirmed=True,cleanup_errors=[],source_stable=True,readiness_pins_stable=True,workflow_accepted=False,full_macos_qualified=False,evidence=dict(archive_sha256=sha(O/'evidence.tar.gz'),archive_bytes=(O/'evidence.tar.gz').stat().st_size,manifest_sha256=sha(O/'evidence.manifest.json'),entries=len(files)+1,expanded_bytes=sum(len(v)for v in files.values())+len(encoded)))
 (O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 (O/'README.md').write_text(f'''# Native placement desktop probe

The reusable placement feature and independent demo retain their existing
software-routing evidence. This checkpoint adds an opt-in native observer, tests
its failure/cleanup controls and preserves one **failed desktop attempt**. It does
not establish native drag/drop, keyboard placement or full Mac acceptance.

Source is clean commit `{build['source_commit']}`: {len(source['tracked'])} tracked
files and {len(source['prepared'])} prepared files. The default example still calls
its original implementation. Only the Mac `vellum_placement_probe` build tag
selects a separate main entry point, with consistent native system/core identities.
A Go test executable would select the upstream offscreen driver; it is explicitly
refused as native evidence. See the [example](../../../examples/placement/README.md)
and [contract](../../../specs/placement.md).

| Check | Actual result | Scope |
|---|---|---|
| Private writer, observer retirement and panic/refusal controls, race | PASS, 3.253 s | No native input/window |
| Independent placement routing suite, offscreen race | PASS, 5.551 s | Software events/model/history |
| Native probe vet and executable compile | PASS, 0.470 / 3.170 s | Compile/static only |
| Fresh clean committed native bundle | PASS, 3.896 s | Build only |
| Native desktop session | FAIL, exit 1, {run['elapsed_seconds']:.3f} s | Ten-minute context deadline |
| External desktop app binding | FAIL, {outcome['tool_wall_seconds']:.4f} s | Server `-10005: timeoutReached`; no inputs requested |
| Terminal cleanup and fresh process observation | PASS | Owned group/exact executable absent |

The session began at `{run['started_utc']}` and ended at
`{run['finished_utc']}` UTC. Twelve startup samples contain eleven unavailable
accessibility snapshots, followed by **one** reachable native AXWindow with 24
elements. The observer skips unchanged model state; these are not ten minutes of
continuous accessibility or presentation sampling. A thirteenth, closed record
contains `context deadline exceeded`, with nil native/observer errors. The saved
JSONL is 26,559 bytes. Objects, Undo/Redo counts, activation/change/removal counts,
gesture state and reserved completions remain empty/zero throughout.

The desktop inventory found the exact running bundle before `cua.getApp` timed
out. No source click, drag, key action, placement, selection, transform, snapping,
rejection or removal case was attempted. The cause of the external binding
timeout remains unassigned; this evidence does not distinguish application,
external-accessibility and automation-service causes. The probe closed at its own
deadline while the binding request was still pending; the outer 710-second
watchdog did not have to force termination. Its controller reaped the owned group
and held the shared lease through cleanup. A later independent process observation
again found no group members or exact probe executable. No further CUA attempt
was made. Source/build/review pins and log hashes remained stable.

Internal source review fixed the original offscreen test-driver selection,
observer teardown without proven join, private test-directory setup and secondary
panic-path error retention. Failed source/check endpoints are preserved. One
bounded Prism review used Anthropic `claude-sonnet-5-5`, six files / 21,492 bytes,
one chunk/call, complete coverage and one raw medium finding. Independent review
refuted that finding against the actual owner/mutex, completion and nonblocking
wake paths; the raw provider exit 1 and finding remain in the archive. There was
no second provider call for this checkpoint.

The probe never synthesizes inputs or calls placement/history commands. Its
diagnostic controls can remove a binding/window after observing a threshold drag.
Target removal is armed at the first sampled drag; a future run must inspect the
pre-removal Accepted/TargetID state before claiming accepted-candidate cancellation.
Successful process closure alone is never workflow acceptance. Physical hardware,
continuous visible previews, held-Escape/capture loss, ancestor scrolling,
cross-display/scale transitions, cross-window capture, GPU presentation/performance,
native heap reclamation and human assistive technology remain unqualified.
Cross-window payload/capture transfer remains unsupported by this initial API.
P4/P6/P9/P11, ordinary latency, overnight, interoperability and distribution
acceptance retain their existing open gates and failures.

[Result summary](result.json), [file manifest](evidence.manifest.json) and
[preserved evidence](evidence.tar.gz) contain the original source, failures,
reviews, provider outcome, producers, full source vectors, actual receipts and
native records. Executable bytes are hash-only exclusions.

Archive SHA-256: `{result['evidence']['archive_sha256']}`.
Manifest SHA-256: `{result['evidence']['manifest_sha256']}`.
The archive contains {result['evidence']['entries']} entries,
{result['evidence']['expanded_bytes']:,} expanded bytes and
{result['evidence']['archive_bytes']:,} compressed bytes.
''')
 updates={
 'docs/reports/README.md':'\n- [Native placement desktop probe](macos-placement-desktop/README.md): native-only observer and offscreen controls; external app binding timed out, no input workflows ran, failed deadline and clean owned-group retirement retained.\n',
 'docs/implementation.md':'\n## Placement desktop acceptance attempt\n\nThe [native placement probe](reports/macos-placement-desktop/README.md) adds a\ndedicated opt-in Mac executable with bounded read-only observations and diagnostic\nremoval controls. Writer/observer race controls, the independent placement\noffscreen suite and native vet/build pass. The actual desktop session failed at\nits ten-minute deadline after external app binding timed out; no pointer/key\nactions were requested. Its group was reaped and absent. Native placement and\nexternal accessibility workflow acceptance remain open; the timeout cause is\nunassigned. This does not change the feature API or close broader Mac gates.\n',
 'examples/placement/README.md':'\nThe [first native desktop attempt](../../docs/reports/macos-placement-desktop/README.md)\nreached one completed native accessibility snapshot, then expired while external\napp binding was pending. No pointer/key action ran; native placement workflow\nacceptance remains open. The offscreen/race checks and failed native deadline are\nreported separately, with source/build pins and owned-process retirement evidence.\n',
 'specs/placement.md':'\nThe [native acceptance attempt](../docs/reports/macos-placement-desktop/README.md)\nrecords a reachable native window and a failed external app binding, followed by\nthe probe deadline and verified owned-group retirement. No pointer/key workflow\nran. The timeout cause remains unassigned; the desktop, external accessibility\nand physical requirements remain open. A diagnostic target-removal run must retain\nits pre-removal Accepted/TargetID state before qualifying candidate cancellation.\n'}
 for name,extra in updates.items():
  p=T/name;s=p.read_text()
  if name=='specs/placement.md':s=s.replace('Physical checks remain deferred while the\nhuman is using the machine.','Native pointer acceptance remains a separately recorded gate.')
  p.write_text(s+extra)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
