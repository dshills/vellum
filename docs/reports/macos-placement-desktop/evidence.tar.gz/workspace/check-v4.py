from pathlib import Path
import datetime,hashlib,json,sys,time
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-placement-desktop-v4-f1b9178');P.mkdir()
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['examples/placement/main.go','examples/placement/main_default.go','examples/placement/native_probe_darwin.go','examples/placement/native_probe_darwin_test.go','examples/placement/README.md','specs/placement.md'];before={n:sha(T/n)for n in files}
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2','PYTHONDONTWRITEBYTECODE':'1'}
env.pop('VELLUM_NATIVE_PLACEMENT_PROBE',None)
commands=[('writer',['go','test','-race','-p=1','-tags=vellum_placement_probe','-run=^TestNativeProbe','-count=1','.']),('routing',['go','test','-race','-p=1','-tags=offscreen','-count=1','./...']),('vet',['go','vet','-p=1','-tags=vellum_placement_probe','./...']),('compile',['go','build','-p=1','-trimpath','-tags=vellum_placement_probe','-o',str(P/'placement-check'),'.'])]
for name,argv in commands:
 out=P/name;out.mkdir();start=time.monotonic();d=dict(argv=argv,cwd=str(T/'examples/placement'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_files=before,producer_sha256=sha(__file__),native_UI_launched=False)
 with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:r=run_child(argv,cwd=d['cwd'],env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20)
 d.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_stable=all(sha(T/n)==h for n,h in before.items()),logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']})
 if name=='compile'and r.returncode==0:d['unexecuted_binary']=dict(path=str(P/'placement-check'),bytes=(P/'placement-check').stat().st_size,sha256=sha(P/'placement-check'))
 (out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['source_files','logs']}),flush=True);assert r.returncode==0 and d['source_stable']
