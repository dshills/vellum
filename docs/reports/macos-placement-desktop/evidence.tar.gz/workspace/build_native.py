"""Compile one clean native placement executable; never launch it here."""
from pathlib import Path
import datetime, hashlib, json, os, plistlib, subprocess, sys, time
W=Path(__file__).resolve().parent
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
P=Path('/private/tmp/vellum-placement-desktop-native')
sys.dont_write_bytecode=True
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=15)
def identity():
 assert not git('status','--porcelain','-z'),'clean source required'
 names=git('ls-files','-z').decode().split('\0')[:-1]
 tracked={n:sha(T/n)for n in names}
 prepared={p.relative_to(T/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/module).rglob('*')if p.is_file()and not p.is_symlink()}
 assert len(prepared)==6243
 return dict(commit=git('rev-parse','HEAD').decode().strip(),tracked=tracked,prepared=prepared)
def main():
 P.mkdir(mode=0o700)
 before=identity();(P/'source.json').write_text(json.dumps(before,indent=2)+'\n')
 bundle=P/'Vellum Placement Probe.app';contents=bundle/'Contents';exe=contents/'MacOS'/'placementprobe';exe.parent.mkdir(parents=True)
 plist=dict(CFBundleIdentifier='com.vellum.placement.nativeprobe',CFBundleName='Vellum Placement Probe',CFBundleDisplayName='Vellum Placement Probe',CFBundleExecutable='placementprobe',CFBundlePackageType='APPL',CFBundleVersion='1',NSHighResolutionCapable=True)
 with(contents/'Info.plist').open('xb')as f:plistlib.dump(plist,f)
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
 argv=['go','build','-p=1','-trimpath','-tags=vellum_placement_probe','-o',str(exe),'.'];start=time.monotonic()
 d=dict(argv=argv,cwd=str(T/'examples/placement'),source_commit=before['commit'],source_sha256=sha(P/'source.json'),producer_sha256=sha(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False)
 with(P/'build.stdout').open('xb')as out,(P/'build.stderr').open('xb')as err:r=run_child(argv,cwd=d['cwd'],env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20)
 d.update(exit_code=r.returncode,source_stable=identity()==before,elapsed_seconds=time.monotonic()-start)
 if r.returncode==0:
  metadata=run_child(['go','version','-m',str(exe)],env=env,capture_output=True,timeout=20);assert metadata.returncode==0
  (P/'go-version.txt').write_bytes(metadata.stdout)
  text=metadata.stdout.decode();assert 'vcs.revision='+before['commit']in text and 'vcs.modified=false'in text and 'CGO_ENABLED=1'in text
  d.update(binary=dict(path=str(exe),sha256=sha(exe),bytes=exe.stat().st_size),bundle=str(bundle),plist_sha256=sha(contents/'Info.plist'),metadata_sha256=sha(P/'go-version.txt'))
 d['logs']={n:dict(bytes=(P/n).stat().st_size,sha256=sha(P/n))for n in ['build.stdout','build.stderr']}
 (P/'build.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='logs'}));assert d['exit_code']==0 and d['source_stable']
if __name__=='__main__':main()
