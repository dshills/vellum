"""Adopt reviewed shared GPU failure cleanup through owned patch 0048."""
import difflib, hashlib, json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-frame-cleanup');driver=r/'drivers/cogent';folder=driver/'native/patches/framecleanup'
sha=lambda b:hashlib.sha256(b).hexdigest()
review=json.loads((p/'source-review-v3.json').read_text());assert review['status']=='APPROVED_SOURCE' and not review['findings']
folder.mkdir(parents=True,exist_ok=False);inputs={};outputs={};patch=[]
for n,expected in review['original_files'].items():
 original=driver/'build/upstream'/n;old=original.read_bytes() if original.is_file() else b''
 assert (sha(old)if old else None)==expected
 new=(p/'candidate'/n).read_bytes();inputs[n]=expected;outputs[n]=sha(new)
 patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
name='0048-owned-frame-failure-cleanup.patch';data=''.join(patch).encode();(folder/name).write_bytes(data)
for n,v in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (folder/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=driver/'native/dependencies.json';m=json.loads(manifest.read_text());prefix='native/patches/framecleanup';assert not any(s['inputs']==prefix+'/original-hashes.json'for s in m['dependencies'][0]['stages'])
m['dependencies'][0]['stages'].append({'origin':'drivers/cogent/'+prefix,'inputs':prefix+'/original-hashes.json','outputs':prefix+'/output-hashes.json','patches':[{'file':prefix+'/'+name,'sha256':sha(data)}]});manifest.write_text(json.dumps(m,indent=2)+'\n')
test=driver/'prepare_test.py';s=test.read_text();assert s.count('list(range(1, 48))')==1;test.write_text(s.replace('list(range(1, 48))','list(range(1, 49))'))
(folder/'README.md').write_text('''# Owned frame failure cleanup

Patch 0048 shares checked pass preparation and submission between ordinary and
measured drawing. Encoder/pass/finish refusal releases partial handles and aborts
the acquired surface. Only a successfully finished and submitted buffer may be
presented or read as an image. Queue submission is synchronous admission; it does
not establish successful GPU execution. Legacy void End logs refusal, while the
checked End and drawer paths return it.

Surface retirement detaches owned view/texture references before release, releases
view before texture, and unlocks once. Idle abort/present is a no-op. Surface
Release also retires an outstanding acquisition before normal teardown. The frame
owner must serialize acquisition, encoding, presentation/abort and teardown;
concurrent or stale owners, arbitrary abandoned passes and broad panic recovery
are not supported by this checkpoint. RenderTexture has no acquired surface lock.

The new tests inject nil/partial creation and finish failures into the actual
shared control functions, check counted reference order and the actual Surface
mutex, and exercise both production End methods with an unsubmitted frame.
They do not inject failures into a physical GPU/backend, qualify device recovery,
or prove native graphics memory reclamation. Prepared input/output/patch hashes
are pinned; the module cache is unchanged. Modified upstream files retain their
BSD-style notices; new Vellum source/tests carry MIT notices.
''')
(r/'specs/gpu-frame-lifecycle.md').write_text('''# GPU frame ownership and failure

A native frame has one serialized owner. Successful surface acquisition owns its
texture/view and holds the surface lock until Present or AbortCurrentTexture.
Idle abort and idle presentation do nothing. Retirement first detaches references,
then releases view, texture and finally the lock. Teardown retires a held frame
before releasing render/surface/device state; callers stop encoding first.

Ordinary and measured rendering use the same checked preparation. A temporary
yield returns no pass; failed encoder or pass creation releases every returned
partial handle and aborts the frame. Partial native acquisition/view errors also
release returned resources. Nil encoder/pass results without an error are refused.
Surface outdated/lost recovery remains bounded by the existing acquisition policy.

Submission consumes the pass and encoder. It releases the pass before Finish and
releases the finished buffer before the encoder, including partial-buffer failures.
Only a valid finished buffer reaches queue submission. Failed submission aborts
the frame and prevents presentation; image capture does not read an unsubmitted
frame. Checked End and ordinary/measured drawer paths return refusal; the legacy
void End method logs it. Measured presentation remains separate from encoding and
returns zero presentation time on refusal. Queue.Submit admission does not prove
GPU completion, and this change does not add device-loss recreation.

Counted-reference tests exercise the actual shared control functions and actual
Surface mutex, including repeated idle abort, teardown and Go release/queue panic
unwind. Production End refusal is checked for both ordinary and measured paths.
These are code-level ownership checks, not physical backend fault injection or
Cocoa/IOSurface reclamation evidence. Stale/concurrent owners, abandoned active
passes, broad panic recovery, physical device loss and native memory/performance
acceptance require separate work. Desktop checks stay deferred while the user is
using the computer. See the phase report in docs/reports/macos-frame-cleanup.
''')
spec=r/'specs/macos-completion.md';s=spec.read_text();s+='\nThe [GPU frame ownership contract](gpu-frame-lifecycle.md) gives ordinary and\nmeasured paths shared checked failure cleanup. Failed preparation/submission\naborts surface ownership and prevents presentation or image capture. This code\ncheckpoint remains separate from physical backend faults, device recreation and\nactual native graphics-memory/performance acceptance.\n';spec.write_text(s)
print(json.dumps({'patch_sha256':sha(data),'outputs':outputs,'expected_prepared_files':6183}))
