"""Seal the bounded frame cleanup checkpoint without claiming native GPU acceptance."""
import hashlib,io,json,os,shutil,tarfile
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-frame-cleanup');out=r/'docs/reports/macos-frame-cleanup'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
source=read('source-final.json')['sources'];base=read('source-final.json')['base_commit'];selected=read('source-prism.json')['sources']
assert len(source)==8 and len(selected)==6 and all(source[n]==h for n,h in selected.items()) and all(sha(r/n)==h for n,h in source.items())
cert=read('source-review-final.json');assert cert['status']=='APPROVED_SOURCE' and not cert['findings'] and cert['files']==source and cert['source_manifest_sha256']==sha(p/'source-final.json')
pr=read('prism-v1/prism.json');proc=read('prism-v1/process.json');assert proc['exit_code']==0 and proc['error']is None and proc['source_index_stable'] and proc['before']==proc['after']==selected
assert pr['coverage']['complete'] and pr['coverage']['files']==6 and not pr['findings'] and pr['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()};assert len(prepared)==6183
stage=r/'drivers/cogent/native/patches/framecleanup';outputs=json.loads((stage/'output-hashes.json').read_text());inputs=json.loads((stage/'original-hashes.json').read_text());assert len(outputs)==9 and all(prepared['upstream/'+n]==h for n,h in outputs.items())
old=read('owned-prepare.json')['prepared_before'];assert len(old)==6181 and read('owned-prepare.json')['prepared_after']==prepared
assert {n for n in old if old[n]!=prepared[n]}=={'upstream/'+n for n,h in inputs.items()if h is not None}
assert set(prepared)-set(old)=={'upstream/'+n for n,h in inputs.items()if h is None}
final={'gpu-offscreen-race','driver-offscreen-race','native-build','prepare-tests','gpu-vet'};receipts={};groups={'final':source}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'source_delta_stable'not in d:continue
 name=f.stem;assert d['exit_code']==int(name=='frame-overlay-race') and d['error']is None and d['source_delta_stable'] and not d['live_tests'] and d['source_commit']==base
 assert d['source_delta_before']==d['source_delta_after']
 group='final'if d['source_delta_before']==source else'historical_'+hashlib.sha256(json.dumps(d['source_delta_before'],sort_keys=True).encode()).hexdigest()[:12];groups[group]=d['source_delta_before']
 for channel in ['stdout','stderr']:assert sha(p/(name+'.'+channel))==d[channel+'_sha256']
 if name in final:assert group=='final' and d['prepared_before']==d['prepared_after']==prepared
 if name in ['frame-overlay-race-v2','frame-overlay-race-v3']:
  assert len(d['overlay_inputs_before'])==10 and d['overlay_inputs_before']==d['overlay_inputs_after'] and len(d['prepared_before'])==6181 and d['prepared_before']==d['prepared_after']
 receipts[name]={'sha256':sha(f),'raw_exit_code':d['exit_code'],'source_group':group,'exact_final_prepared_input':name in final,'overlay_input_binding':bool(d.get('overlay_inputs_before'))}
assert len(receipts)==9 and set(final)<=set(receipts)
binary=p/'window-cycle-smoke-owned';assert binary.is_file()
q={'result':'PASS_OWNED_FRAME_FAILURE_CLEANUP_OFFSCREEN','base_commit':base,'source':source,'source_groups':groups,'prepared':prepared,'stage_inputs':inputs,'stage_outputs':outputs,'receipts':receipts,'source_review_sha256':sha(p/'source-review-final.json'),'prism_source':selected,'prism_raw_exit_code':0,'prism_findings':0,'prism_static_leaves_internally_verified':read('source-prism.json')['excluded_static_leaves'],'native_build_sha256':sha(binary),'final_owned_source_native_window_executed':False,'physical_gpu_fault_injection':False,'native_memory_qualified':False,'gpu_memory_qualified':False,'full_p11_qualified':False,'macos_completion':False,'next_live_tests_deferred':True,'preferences_changed':False,'input_sources_changed':False,'source_scope':'Eight selected repository leaves and all6183 prepared identities; nine decoded patch outputs. Provider selects6 patch/test/registration/spec/doc leaves,2 pin maps internally verified. Compiler/cache/SDK full closure excluded.','historical_failure':'V1 preliminary overlay compile exits1 due wrong errors.Log1 import; corrected before V2/V3. V1 wrapper did not bind overlay targets; archived frozen V1 copies are supporting input records, not a full execution-time overlay closure. V2/V3 bind nine target hashes plus overlay and pass; both precede the final capture guard and owned adoption.','limits':'Injected counted handles exercise actual shared ownership functions and actual Surface mutex. End refusal uses actual production ordinary/measured methods with nil unsubmitted pass. No physical GPU/backend failure, drawable/native heap proof, broad abandoned-pass/panic recovery, stale/concurrent frame owner or device recreation qualification. Queue submission is synchronous admission, not GPU completion.'}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records=out/'records';records.mkdir(parents=True,exist_ok=False);shutil.copy2(Path(__file__),records/'archive-producer.py.txt')
files={}
for folder,dirs,names in os.walk(p):
 dirs[:]=sorted(d for d in dirs if not d.endswith('.app')and not(Path(folder)/d).is_symlink())
 for name in sorted(names):
  f=Path(folder)/name
  if f.is_file()and not f.is_symlink()and f.suffix in ['.json','.stdout','.stderr','.py','.txt','.log','.go']:
   files[f.relative_to(p).as_posix()]=f.read_bytes()
index={n:hashlib.sha256(b).hexdigest()for n,b in files.items()};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n');archive=records/'evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(b),0o644,0;tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive)as tf:assert {m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest()for m in tf.getmembers()if m.isfile()}==index
(out/'README.md').write_text('''# Mac GPU frame failure cleanup

Owned patch 0048 gives ordinary and measured frame rendering one checked
preparation/submission control path. Encoder/pass/finish refusal releases partial
handles and aborts surface ownership. Failed frames are not presented or read as
images. Successful submission keeps the existing pass → finish → queue → buffer
→ encoder release order. Queue admission does not establish GPU completion.
The checked End and drawer paths return errors; legacy void End logs them.

Surface retirement detaches view/texture references before release, releases the
view before the texture and unlocks once. Repeated idle abort/present does nothing;
Surface Release retires an outstanding frame before normal teardown. Partial
acquisition/view failures release their returned handles. This contract requires
one serialized frame owner and encoding stopped before teardown. It does not add
support for stale/concurrent owners, abandoned active passes, broad panic resource
recovery or device-loss recreation. RenderTexture has no acquired surface lock.

## Verified scope

Fresh preparation passes with 6,183 files: seven existing GPU/drawer files change
and two source/test files are added. Nine decoded outputs match the pinned hashes.
The full GPU/gpudraw offscreen race suites pass three repetitions; the adapter
race suite, GPU/gpudraw vet, native-consumer compilation and all 11 preparation
tests pass. Five final check receipts bind unchanged eight selected repository
leaves and all 6,183 prepared identities. The native binary is compiled only and
retains the pre-existing duplicate -lobjc warning.

Counted-reference fault tables execute the actual shared production functions
for acquisition yield/refusal, nil and partial encoder/pass results, finish
failure, nil/partial command buffers, successful queue admission and Go queue
panic unwind. Actual Surface mutex tests verify abort/teardown order, once-only
release/unlock, repeated idle behavior and release-panic cleanup. Actual ordinary
and measured End entrypoints refuse an unsubmitted frame with one abort and zero
presentations. These inert handles do not inject a physical backend failure.
The image-capture guard is source-reviewed and compiled; real failed-backend
readback is not exercised.

## Version and review evidence

A preliminary overlay compile fails because errors.Log1 initially referred to the
standard errors package. That raw exit remains 1; the import is corrected before
V2 and V3 overlay races pass. V1 lacks execution-time overlay-target binding;
frozen copies remain supporting records only. V2/V3 bind all nine candidate hashes
and the overlay, with unchanged 6,181 prepared originals. Both are historical and
precede the final capture guard and owned preparation. They are not relabeled as
final-source checks. Nine command receipts retain raw exits and output hashes.

Internal review covers all eight final source/spec/pin leaves and nine decoded
outputs. One Prism review using Anthropic Claude Sonnet 5.5 selects six patch,
preparation and documentation leaves, completes coverage and returns exit 0 with
no findings. Two static pin maps are checked internally. The indexed archive
preserves candidate versions, receipts, code-check producer, review input/output
and exact source/prepared maps. Binaries, caches and host desktop artifacts are
excluded. This is selected-source evidence, not a compiler/cache/SDK full closure.

No native window, drawable, input source, clipboard or user preference is touched.
Actual graphics-memory reclamation, physical device faults, sustained latency,
P11/endurance, human input/display and public-distribution gates remain open.
Desktop/performance checks remain deferred while the user uses the computer.
''')
print(json.dumps({'result':q['result'],'qualification_sha256':sha(p/'qualification.json'),'archive_sha256':sha(archive),'archive_members':len(index),'receipts':len(receipts)}))
