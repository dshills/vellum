// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import "fmt"

import "github.com/oliverbestmann/webgpu/wgpu"

type releasedReference interface{ Release() }
type ownedReference interface {
	comparable
	Release()
}

// surfaceFrame is used only by the serialized acquisition owner. Interface
// references are always admitted nonnil; concrete handles never leave GPU code.
type surfaceFrame struct{ view, texture releasedReference }

func (f *surfaceFrame) held() bool { return f.view != nil || f.texture != nil }

func (f *surfaceFrame) retire(unlock func()) {
	if !f.held() {
		return
	}
	view, texture := f.view, f.texture
	f.view, f.texture = nil, nil
	defer unlock()
	if texture != nil {
		defer texture.Release()
	}
	if view != nil {
		view.Release()
	}
}

// prepareOwnedPass is shared by ordinary and measured rendering. Successful
// acquisition stays owned only after both encoder and render pass exist.
func prepareOwnedPass[C ownedReference, P ownedReference](
	acquire func() (*wgpu.TextureView, error), abort func(),
	encoder func() (C, error), pass func(C, *wgpu.TextureView) (P, error),
) (c C, p P, err error) {
	view, err := acquire()
	if view == nil {
		return c, p, err
	}
	succeeded := false
	defer func() {
		if succeeded {
			return
		}
		defer abort()
		var zeroC C
		if c != zeroC {
			defer c.Release()
		}
		var zeroP P
		if p != zeroP {
			p.Release()
		}
		c, p = zeroC, zeroP
	}()
	if err != nil {
		return c, p, err
	}
	c, err = encoder()
	var zeroC C
	if err != nil {
		return c, p, err
	}
	if c == zeroC {
		return c, p, fmt.Errorf("gpu: encoder factory returned nil without error")
	}
	p, err = pass(c, view)
	var zeroP P
	if err != nil {
		return c, p, err
	}
	if p == zeroP {
		return c, p, fmt.Errorf("gpu: pass factory returned nil without error")
	}
	succeeded = true
	return c, p, nil
}

// submitOwnedPass releases the pass before Finish, and buffer before encoder on
// every return. Only a valid finished buffer reaches the queue.
func submitOwnedPass[C ownedReference, P ownedReference, B ownedReference](
	c C, p P, finish func(C) (B, error), submit func(B),
) error {
	var zeroC C
	if c != zeroC {
		defer c.Release()
	}
	var zeroP P
	if p != zeroP {
		p.Release()
	}
	if c == zeroC || p == zeroP {
		return fmt.Errorf("gpu: submission requires an encoder and pass")
	}
	buffer, err := finish(c)
	var zeroB B
	if buffer != zeroB {
		defer buffer.Release()
	}
	if err != nil {
		return err
	}
	if buffer == zeroB {
		return fmt.Errorf("gpu: finish returned nil without error")
	}
	submit(buffer)
	return nil
}
