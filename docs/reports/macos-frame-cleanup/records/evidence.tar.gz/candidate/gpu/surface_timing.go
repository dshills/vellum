package gpu

import (
	"fmt"
	"time"

	"cogentcore.org/core/base/errors"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// GetCurrentTextureMeasured preserves the ordinary acquisition/retry order.
// Only waiting for ownership and the backend acquisition calls are excluded.
// Reconfiguration, status checks and texture view creation remain UI work.
func (sf *Surface) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	start := time.Now()
	sf.Lock()
	acquireNS := time.Since(start).Nanoseconds()
	stexture, err := acquireSurfaceFrame(func() (wgpu.SurfaceTexture, error) {
		start := time.Now()
		frame, err := sf.surface.TryGetCurrentTexture()
		acquireNS += time.Since(start).Nanoseconds()
		return frame, err
	}, sf.Config)
	if errors.Log(err) != nil {
		sf.Unlock()
		return nil, acquireNS, err
	}
	texture, ok := stexture.Get()
	if !ok || texture == nil {
		sf.Unlock()
		return nil, acquireNS, nil
	}
	view, err := texture.TryCreateView(&wgpu.TextureViewDescriptor{
		MipLevelCount: texture.GetMipLevelCount(), ArrayLayerCount: texture.GetDepthOrArrayLayers(), Format: sf.Format.Format,
	})
	if err != nil || view == nil {
		if view != nil {
			view.Release()
		}
		texture.Release()
		sf.Unlock()
		if err == nil {
			err = fmt.Errorf("gpu: texture view factory returned nil without error")
		}
		return nil, acquireNS, err
	}
	sf.frame = surfaceFrame{view: view, texture: texture}
	return view, acquireNS, nil
}

// PresentMeasured excludes only the backend presentation call. Texture cleanup
// and ownership release remain charged in the encompassing encoding interval.
func (sf *Surface) PresentMeasured() int64 {
	if !sf.frame.held() {
		return 0
	}
	defer sf.AbortCurrentTexture()
	start := time.Now()
	sf.surface.Present()
	return time.Since(start).Nanoseconds()
}

// A render texture has no surface acquisition or presentation wait.
func (rt *RenderTexture) GetCurrentTextureMeasured() (*wgpu.TextureView, int64, error) {
	view, err := rt.GetCurrentTexture()
	return view, 0, err
}
func (rt *RenderTexture) AbortCurrentTexture()   {}
func (rt *RenderTexture) PresentMeasured() int64 { return 0 }
