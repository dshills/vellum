// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpu

import (
	"errors"
	"github.com/oliverbestmann/webgpu/wgpu"
	"reflect"
	"testing"
)

type countedFrameRef struct {
	name     string
	events   *[]string
	releases int
	panics   bool
}

type observedFrameRenderer struct {
	Renderer
	aborts, presents int
}

func (r *observedFrameRenderer) AbortCurrentTexture()   { r.aborts++ }
func (r *observedFrameRenderer) Present()               { r.presents++ }
func (r *observedFrameRenderer) PresentMeasured() int64 { r.presents++; return 7 }

func TestVellumOrdinaryAndMeasuredEndRefuseUnsubmittedFrame(t *testing.T) {
	for _, measured := range []bool{false, true} {
		renderer := &observedFrameRenderer{}
		sy := &GraphicsSystem{Renderer: renderer}
		var err error
		if measured {
			var elapsed int64
			elapsed, err = sy.EndRenderPassMeasured(nil)
			if elapsed != 0 {
				t.Fatal("failed submission qualified presentation timing")
			}
		} else {
			err = sy.EndRenderPassChecked(nil)
		}
		if err == nil || renderer.aborts != 1 || renderer.presents != 0 || sy.CommandEncoder != nil {
			t.Fatal("failed End did not abort without presenting", err, renderer)
		}
	}
}

func (r *countedFrameRef) Release() {
	r.releases++
	*r.events = append(*r.events, r.name)
	if r.panics {
		panic(r.name)
	}
}

func TestVellumSurfaceFrameAbortAndReleaseUnlockOnce(t *testing.T) {
	for _, teardown := range []bool{false, true} {
		var events []string
		view := &countedFrameRef{name: "view", events: &events}
		texture := &countedFrameRef{name: "texture", events: &events}
		sf := &Surface{}
		sf.Lock()
		sf.frame = surfaceFrame{view: view, texture: texture}
		if teardown {
			sf.Release()
		} else {
			sf.AbortCurrentTexture()
		}
		sf.AbortCurrentTexture()
		if !sf.TryLock() {
			t.Fatal("abort/teardown retained surface lock")
		}
		sf.Unlock()
		if sf.frame.held() || view.releases != 1 || texture.releases != 1 || !reflect.DeepEqual(events, []string{"view", "texture"}) {
			t.Fatal("frame retirement differs", events)
		}
		// An idle presentation must not call the nil native surface or unlock again.
		sf.Present()
		if elapsed := sf.PresentMeasured(); elapsed != 0 {
			t.Fatal("idle present measured backend work")
		}
	}
}

func TestVellumSurfaceRetirementClearsAndUnlocksOnGoPanic(t *testing.T) {
	var events []string
	view := &countedFrameRef{name: "view", events: &events, panics: true}
	texture := &countedFrameRef{name: "texture", events: &events}
	sf := &Surface{}
	sf.Lock()
	sf.frame = surfaceFrame{view: view, texture: texture}
	func() {
		defer func() {
			if recover() == nil {
				t.Error("injected release panic absent")
			}
		}()
		sf.AbortCurrentTexture()
	}()
	if !sf.TryLock() {
		t.Fatal("panic retained frame lock")
	}
	sf.Unlock()
	if sf.frame.held() || texture.releases != 1 {
		t.Fatal("panic retained owner texture")
	}
	sf.AbortCurrentTexture()
}

func TestVellumPrepareOwnedFrameFailuresAndSuccess(t *testing.T) {
	failure := errors.New("controlled native factory failure")
	for _, stage := range []string{"yield", "acquire", "encoder", "nil_encoder", "partial_encoder", "pass", "nil_pass", "partial_pass", "success"} {
		t.Run(stage, func(t *testing.T) {
			var events []string
			c := &countedFrameRef{name: "encoder.release", events: &events}
			p := &countedFrameRef{name: "pass.release", events: &events}
			var frame surfaceFrame
			view := &countedFrameRef{name: "view.release", events: &events}
			texture := &countedFrameRef{name: "texture.release", events: &events}
			unlocks := 0
			acquire := func() (*wgpu.TextureView, error) {
				events = append(events, "acquire")
				if stage == "yield" {
					return nil, nil
				}
				frame = surfaceFrame{view: view, texture: texture}
				if stage == "acquire" {
					return &wgpu.TextureView{}, failure
				}
				return &wgpu.TextureView{}, nil
			}
			abort := func() { events = append(events, "abort"); frame.retire(func() { unlocks++ }) }
			encoder := func() (*countedFrameRef, error) {
				events = append(events, "encoder.create")
				switch stage {
				case "encoder":
					return nil, failure
				case "nil_encoder":
					return nil, nil
				case "partial_encoder":
					return c, failure
				}
				return c, nil
			}
			pass := func(*countedFrameRef, *wgpu.TextureView) (*countedFrameRef, error) {
				events = append(events, "pass.create")
				switch stage {
				case "pass":
					return nil, failure
				case "nil_pass":
					return nil, nil
				case "partial_pass":
					return p, failure
				}
				return p, nil
			}
			gotC, gotP, err := prepareOwnedPass(acquire, abort, encoder, pass)
			if stage == "yield" {
				if err != nil || gotC != nil || gotP != nil || len(events) != 1 {
					t.Fatal("yield constructed frame", events, err)
				}
				return
			}
			if stage == "success" {
				if err != nil || gotC != c || gotP != p || !frame.held() || unlocks != 0 {
					t.Fatal("successful preparation retired frame", events, err)
				}
				gotP.Release()
				gotC.Release()
				abort()
				return
			}
			if err == nil || gotC != nil || gotP != nil || frame.held() || unlocks != 1 || view.releases != 1 || texture.releases != 1 {
				t.Fatal("failure retained frame or admitted output", events, err)
			}
			if stage != "nil_encoder" && stage != "nil_pass" && !errors.Is(err, failure) {
				t.Fatal("factory error identity lost", err)
			}
			wantC := 0
			if stage == "partial_encoder" || stage == "pass" || stage == "nil_pass" || stage == "partial_pass" {
				wantC = 1
			}
			wantP := 0
			if stage == "partial_pass" {
				wantP = 1
			}
			if c.releases != wantC || p.releases != wantP {
				t.Fatal("partial handles differ", events)
			}
			if len(events) < 3 || events[len(events)-3] != "abort" || events[len(events)-2] != "view.release" || events[len(events)-1] != "texture.release" {
				t.Fatal("abort did not follow encoder/pass retirement", events)
			}
		})
	}
}

func TestVellumSubmitOwnedPassFailureOrdering(t *testing.T) {
	failure := errors.New("controlled Finish failure")
	for _, stage := range []string{"finish", "nil_buffer", "partial_buffer", "success", "queue_panic"} {
		t.Run(stage, func(t *testing.T) {
			var events []string
			c := &countedFrameRef{name: "encoder.release", events: &events}
			p := &countedFrameRef{name: "pass.release", events: &events}
			b := &countedFrameRef{name: "buffer.release", events: &events}
			finish := func(*countedFrameRef) (*countedFrameRef, error) {
				events = append(events, "finish")
				switch stage {
				case "finish":
					return nil, failure
				case "nil_buffer":
					return nil, nil
				case "partial_buffer":
					return b, failure
				}
				return b, nil
			}
			submit := func(*countedFrameRef) {
				events = append(events, "submit")
				if stage == "queue_panic" {
					panic("controlled queue panic")
				}
			}
			var err error
			func() {
				defer func() {
					got := recover()
					if (stage == "queue_panic") != (got != nil) {
						t.Errorf("panic=%v", got)
					}
				}()
				err = submitOwnedPass(c, p, finish, submit)
			}()
			want := []string{"pass.release", "finish"}
			if stage == "success" || stage == "queue_panic" {
				want = append(want, "submit")
			}
			if stage == "partial_buffer" || stage == "success" || stage == "queue_panic" {
				want = append(want, "buffer.release")
			}
			want = append(want, "encoder.release")
			if !reflect.DeepEqual(events, want) || c.releases != 1 || p.releases != 1 {
				t.Fatal("submission ownership order", events, want)
			}
			if stage == "success" || stage == "queue_panic" {
				return
			}
			if err == nil {
				t.Fatal("failed finish qualified submission")
			}
			if stage != "nil_buffer" && !errors.Is(err, failure) {
				t.Fatal("finish error identity lost")
			}
		})
	}
}

func TestVellumAcquireSurfaceFrameRetiresPartialError(t *testing.T) {
	failure := errors.New("partial acquisition")
	for _, status := range []wgpu.SurfaceGetCurrentTextureStatus{wgpu.SurfaceGetCurrentTextureStatusSuccessOptimal, wgpu.SurfaceGetCurrentTextureStatusOutdated} {
		texture := &wgpu.Texture{}
		releases, configs := 0, 0
		got, err := acquireSurfaceFrameOwned(func() (wgpu.SurfaceTexture, error) {
			return wgpu.SurfaceTexture{Texture: texture, Status: status}, failure
		}, func() { configs++ }, func(value *wgpu.Texture) {
			if value != texture {
				t.Fatal("wrong acquired owner")
			}
			releases++
		})
		if !errors.Is(err, failure) || got.Texture != nil || releases != 1 || configs != 0 {
			t.Fatal("partial acquisition not retired", got, err, releases, configs)
		}
	}
}
