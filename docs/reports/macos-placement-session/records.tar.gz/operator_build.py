from pathlib import Path
import sys,json,time,hashlib
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-placement-session-3801970');T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
commands=[('operator-compile',['/usr/bin/clang','-isysroot','/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk','-fobjc-arc','-framework','Cocoa','-framework','ApplicationServices','-framework','CoreGraphics',str(W/'operator.m'),'-o',str(P/'operator')]),('kernel-self-check',[str(P/'operator'),'--kernel-self-check']),('metadata',['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go','version','-m','-json',str(P/'Vellum Placement Session.app/Contents/MacOS/placementprobe')])]
results=[]
for name,args in commands:
 start=time.monotonic()
 with (W/(name+'.stdout')).open('xb')as out,(W/(name+'.stderr')).open('xb')as err:r=run_child(args,cwd=W,timeout=60,stdout=out,stderr=err,log_limit_bytes=1<<20)
 results.append(dict(name=name,argv=args,exit_code=r.returncode,seconds=time.monotonic()-start));assert r.returncode==0,name
meta=json.loads((W/'metadata.stdout').read_bytes());settings={s['Key']:s.get('Value','') for s in meta['Settings']};assert meta['Path']=='github.com/dshills/vellum/examples/placement' and settings.get('-race')=='true' and settings.get('-tags')=='vellum_placement_probe'
identity=json.loads((W/'kernel-self-check.stdout').read_bytes());assert identity['result']=='KERNEL_IDENTITY_SELF_CHECK' and not identity['native_input_posted']
files=[P/'operator',P/'Vellum Placement Session.app/Contents/MacOS/placementprobe',W/'operator.m',W/'campaign.py',W/'finalizer.py',W/'shared.py',W/'placement.mod',W/'placement.sum'];(W/'build-receipt.json').write_text(json.dumps({'result':'PASS_BUILD_AND_READ_ONLY_SELF_CHECK','commands':results,'files':{str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files},'native_input_executed':False},indent=2)+'\n');print('Operator compiled, kernel self-check passed; no native input')
