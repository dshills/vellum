from pathlib import Path
import os,sys,json,time,shutil
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-placement-session-3801970');P.mkdir(exist_ok=True,mode=0o700)
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
mod=W/'placement.mod'
if not mod.exists():
 s=(T/'examples/placement/go.mod').read_text().replace('=> ../..\n','=> '+str(T)+'\n').replace('=> ../../drivers/cogent\n','=> '+str(T/'drivers/cogent')+'\n').replace('=> ../../drivers/cogent/build/upstream\n','=> '+str(T/'drivers/cogent/build/upstream')+'\n').replace('=> ../../drivers/cogent/build/typesetting\n','=> '+str(T/'drivers/cogent/build/typesetting')+'\n');s+='\nreplace github.com/oliverbestmann/webgpu/libs-darwin => "/private/tmp/vellum-gpu-sdk-stage0077/relocated SDK/vellum-v0.1.0-alpha.2/drivers/cogent/build/libs-darwin"\n';mod.write_text(s);shutil.copyfile(T/'examples/placement/go.sum',W/'placement.sum')
base=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go'];m=['-modfile='+str(mod),'-mod=readonly','-p=2'];mode=sys.argv[1];args={
'probe-tests':base+['test',*m,'-race','-tags=vellum_placement_probe','./...','-count=1','-timeout=3m','-v'],
'routing':base+['test',*m,'-race','-tags=offscreen','./...','-count=1','-timeout=4m'],
'vet':base+['vet',*m,'-tags=vellum_placement_probe','./...'],
'build':base+['build',*m,'-race','-trimpath','-buildvcs=false','-tags=vellum_placement_probe','-o',str(P/'Vellum Placement Session.app/Contents/MacOS/placementprobe'),'.']
}[mode];env=dict(os.environ,GOMAXPROCS='2',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOPROXY='off');env.pop('GOFLAGS',None);start=time.monotonic()
with (W/(mode+'.stdout')).open('xb') as out,(W/(mode+'.stderr')).open('xb') as err:r=run_child(args,cwd=T/'examples/placement',env=env,stdout=out,stderr=err,timeout=300)
d={'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start};(W/(mode+'-command.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
