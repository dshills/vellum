from pathlib import Path
import hashlib,json,plistlib
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-placement-session-3801970');old=W.parent/'macos-placement-native-input';B=P/'Vellum Placement Session.app/Contents/MacOS/placementprobe'
s=(old/'operator-v5.m').read_text().replace('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live',str(P/'stop-native')).replace('[expectedPath hasPrefix:@"/private/tmp/vellum-placement-native-input/"]','[expectedPath isEqual:@"'+str(B)+'"]');(W/'operator.m').write_text(s)
s=(old/'campaign-v6.py').read_text().replace('from build import P as BUILD_P, SDK, BINARY, STOP, h, sha, need, read','from shared import P as BUILD_P, SDK, BINARY, STOP, h, sha, need, read').replace("P=Path('/private/tmp/vellum-placement-native-input-case2')", "P=BUILD_P").replace("OPERATOR=BUILD_P/'operator-v5'", "OPERATOR=BUILD_P/'operator'");(W/'campaign.py').write_text(s)
(W/'finalizer.py').write_bytes((old/'finalizer.py').read_bytes())
(W/'shared.py').write_text('''from pathlib import Path
from types import SimpleNamespace
import json,hashlib
P=Path('/private/tmp/vellum-placement-session-3801970')
SDK=Path('/private/tmp/vellum-macos-native-results-97aee13')
BINARY=P/'Vellum Placement Session.app/Contents/MacOS/placementprobe'
STOP=P/'stop-native'
def need(good,message):
 if not good: raise ValueError(message)
def read(p): return json.loads(Path(p).read_bytes())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exclusive(p,value):
 with Path(p).open('x') as f:f.write(json.dumps(value,indent=2)+'\\n')
h=SimpleNamespace(exclusive=exclusive)
''')
B.parent.mkdir(parents=True,exist_ok=True)
with (B.parent.parent/'Info.plist').open('xb') as f:plistlib.dump(dict(CFBundleIdentifier='com.vellum.placement.session3801970',CFBundleName='Vellum Placement Session',CFBundleExecutable='placementprobe',CFBundlePackageType='APPL',CFBundleVersion='1',NSHighResolutionCapable=True),f)
(W/'delta.json').write_text(json.dumps({'base_operator':str(old/'operator-v5.m'),'operator_delta':'Only fixed session stop path and exact target executable allowlist; kernel identity, fixed actions, bounds, foreground, PID posting, held-input balancing unchanged','base_campaign':str(old/'campaign-v6.py'),'campaign_delta':'Only shared import and fresh scope/operator paths; action/check functions unchanged','finalizer_byte_identical':True,'native_input_executed':False,'old_stop_seal_preserved':True},indent=2)+'\n')
print('Fresh operator/campaign prepared; no launch')
