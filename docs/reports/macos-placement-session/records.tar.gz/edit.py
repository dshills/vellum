from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13');p=T/'examples/placement/native_probe_darwin.go';s=p.read_text();needle='func (w *nativeProbeWriter) write(value any) error {';s=s.replace(needle,'''// Only this probe's private output directory owns its cancellation marker.
// Historical test-session paths must never authorize or stop a fresh session.
func (w *nativeProbeWriter) checkStop() error {
	if _, err := os.Lstat(filepath.Join(w.root, "stop-live")); err == nil {
		return fmt.Errorf("probe stopped by session marker")
	} else if !errors.Is(err, os.ErrNotExist) {
		return err
	}
	return nil
}

'''+needle)
a=s.index('\t\t\tfor _, marker := range []string{');z=s.index('\n\t\t\tvar state nativePlacementState',a);s=s[:a]+'''\t\t\tif err := w.checkStop(); err != nil {
				return err
			}'''+s[z:];p.write_text(s)
p=T/'examples/placement/native_probe_darwin_test.go';s=p.read_text();s+='''
func TestNativeProbeSessionStopIsolationAndObserverJoin(t *testing.T) {
	one, err := newNativeProbeWriter(privateProbeDir(t))
	if err != nil { t.Fatal(err) }
	defer one.log.Close()
	two, err := newNativeProbeWriter(privateProbeDir(t))
	if err != nil { t.Fatal(err) }
	defer two.log.Close()
	if err := one.checkStop(); err != nil { t.Fatal(err) }
	if err := two.checkStop(); err != nil { t.Fatal(err) }
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	ready := make(chan struct{})
	o := startNativeProbeObserver(cancel, func() error { <-ready; return one.checkStop() })
	if err := os.WriteFile(filepath.Join(one.root, "stop-live"), nil, 0600); err != nil { close(ready); t.Fatal(err) }
	close(ready)
	select { case <-ctx.Done(): case <-time.After(time.Second): t.Fatal("session marker did not cancel observer") }
	cleaned := false
	err = retireNativeProbe(cancel, o, time.Second, func() error { cleaned = true; return nil })
	if err == nil || !strings.Contains(err.Error(), "session marker") || !cleaned { t.Fatal("marker failure/join/teardown lost", err, cleaned) }
	if err := two.checkStop(); err != nil { t.Fatal("one session stopped another", err) }
	// A marker-inspection error must fail closed rather than continue observing.
	two.root = filepath.Join(two.root, "events.jsonl", "not-a-directory")
	if err := two.checkStop(); err == nil { t.Fatal("marker I/O failure ignored") }
}
''';p.write_text(s)
p=T/'examples/placement/README.md';s=p.read_text().replace('A ten-minute deadline and the shared human-return\nmarker end the session.', 'A ten-minute deadline and a session-owned `stop-live` marker in the private\noutput directory end the session. The test controller must create this marker\nwhen desktop permission is withdrawn or the user returns. Historical markers\nfrom other sessions are kept intact and do not control a new probe.');p.write_text(s)
