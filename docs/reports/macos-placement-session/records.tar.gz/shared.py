from pathlib import Path
from types import SimpleNamespace
import json,hashlib
P=Path('/private/tmp/vellum-placement-session-3801970')
SDK=Path('/private/tmp/vellum-macos-native-results-97aee13')
BINARY=P/'Vellum Placement Session.app/Contents/MacOS/placementprobe'
STOP=P/'stop-native'
def need(good,message):
 if not good: raise ValueError(message)
def read(p): return json.loads(Path(p).read_bytes())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exclusive(p,value):
 with Path(p).open('x') as f:f.write(json.dumps(value,indent=2)+'\n')
h=SimpleNamespace(exclusive=exclusive)
