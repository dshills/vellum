"""Serial PID-directed input, independently observed through the native probe.

This child and all its fixed subprocesses inherit the outer owned process group.
No commands, model setters, offscreen input or AX press/text actions are invoked.
AX frontmost activation/query is limited to the owned native probe.
"""
from pathlib import Path
import base64, datetime, json, math, os, signal, subprocess, sys, time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W))
from shared import P as BUILD_P, SDK, BINARY, STOP, h, sha, need, read
P=BUILD_P
from finalizer import finish
OPERATOR=BUILD_P/'operator'
OUT=P/'probe'
actions=[];checks=[];start=time.monotonic();probe=None;birth=None

def guard():
    need(not STOP.exists() and not (P/'stop-native').exists(),'stop requested')
    need(time.monotonic()-start < 210,'campaign watchdog')
    for name in ['events.jsonl','latest.json']:
        path=OUT/name
        if path.exists():need(path.stat().st_size <= (8<<20 if name=='events.jsonl' else 256<<10),'probe output bound')

def latest():
    guard()
    try:return read(OUT/'latest.json')
    except FileNotFoundError:return None

def wait_for(predicate, seconds=5):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        record=latest()
        if record is not None and predicate(record):return record
        need(probe.poll() is None,'native probe exited before expected state')
        time.sleep(.05)
    raise TimeoutError('expected native state not observed')

def state():return latest()['state']
def objects(s):return s['Objects'] or []
def check(name,good,**details):
    checks.append(dict(name=name,passed=bool(good),**details));need(good,name)
def frame(name):
    expected='node:'+base64.urlsafe_b64encode(name.encode()).decode().rstrip('=')
    elements=[e for e in latest()['accessibility']['elements'] if e['id']==expected]
    need(len(elements)==1,'one native element '+name)
    value=elements[0]['frame'];need(len(value)==4 and all(math.isfinite(n) for n in value) and value[2]>0 and value[3]>0,'positive native frame '+name)
    return value
def center(name,dx=0,dy=0):
    x,y,w,height=frame(name);return [x+w/2+dx,y+height/2+dy]

def event_records():
    path=OUT/'events.jsonl';data=path.read_bytes();need(len(data)<=8<<20,'events bound')
    return [json.loads(line) for line in data.splitlines()]

def action(kind,**extra):
    global birth
    guard();need(probe.poll() is None,'owned probe is live before action')
    plan=dict(pid=probe.pid,executable=str(BINARY),kind=kind,**extra)
    if birth is not None:plan['birth']=birth
    i=len(actions);file=P/('action-%02d.json'%i);h.exclusive(file,plan)
    begin=time.monotonic();r=subprocess.run([str(OPERATOR),str(file)],capture_output=True,timeout=8,check=False)
    need(len(r.stdout)+len(r.stderr)<=16384,'operator log bound')
    receipt=dict(index=i,plan=plan,exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),elapsed_seconds=time.monotonic()-begin)
    actions.append(receipt);h.exclusive(P/('action-%02d-result.json'%i),receipt)
    if kind=='identify':
        need(r.returncode==0,'native process identification');identity=json.loads(r.stdout);need(identity['pid']==probe.pid and identity['result']=='OWNED_IDENTITY','operator identity');birth=identity['birth']
    else:need(r.returncode==0,'native action '+kind+' '+str(i))
    return receipt

def click(name):action('click',start=center(name))
def await_idle():return wait_for(lambda r:not r['state']['Gesture']['Active'] and r['state']['Reserved']==0)['state']

def drag(item,point,kind='drag',expected='accepted'):
    before=state();first=len(event_records());action(kind,start=center('tool-'+item),end=point)
    after=await_idle();records=event_records()[first:];samples=[r['state'] for r in records if r['event']=='placement.probe.sample']
    active=[s for s in samples if s['Gesture']['Active']]
    check('native gesture observed '+item,bool(active),kind=kind,expectation=expected)
    if expected=='accepted':
        accepted=[s for s in active if s['Gesture']['Dragging'] and s['Gesture']['Accepted']]
        check('threshold then accepted preview '+item,any(not s['Gesture']['Dragging'] for s in active) and bool(accepted))
        check('exactly one placement '+item,len(objects(after))==len(objects(before))+1 and after['History']['UndoCount']==before['History']['UndoCount']+1 and after['Next']==before['Next']+1)
        check('no unrelated release action '+item,after['CanvasChanges']==before['CanvasChanges'] and after['SourceActivations']==before['SourceActivations'])
        obj=objects(after)[-1];pos=accepted[-1]['Gesture']['Position']
        check('preview equals committed position '+item,abs(obj['X']-pos['X'])<1e-6 and abs(obj['Y']-pos['Y'])<1e-6,object=obj,position=pos)
    else:
        check('canceled/rejected drop adds no history '+item,objects(after)==objects(before) and after['History']==before['History'] and after['Next']==before['Next'])
        check('canceled release consumed '+item,after['SourceActivations']==before['SourceActivations'] and after['CanvasChanges']==before['CanvasChanges'])
        if expected=='rejected':check('visible rejected proposal state '+item,any(s['Gesture']['Dragging'] and not s['Gesture']['Accepted'] and s['Gesture']['TargetID']=='drawing' for s in active))
    check('gesture and reservation released '+item,not after['Gesture']['Active'] and after['Reserved']==0)
    return before,after

def run():
    global probe
    need(os.getpid()==os.getpgrp(),'outer-owned campaign group')
    need(not OUT.exists(),'fresh probe directory');OUT.mkdir(mode=0o700)
    env={**os.environ,'VELLUM_NATIVE_PLACEMENT_PROBE':str(OUT),'GORACE':'halt_on_error=1 exitcode=66 atexit_sleep_ms=0'}
    probe=subprocess.Popen([str(BINARY)],cwd=SDK/'examples/placement',env=env)
    need(os.getpgid(probe.pid)==os.getpgrp(),'native child inherits owned group')
    h.exclusive(P/'probe-owned.json',dict(pid=probe.pid,group=os.getpgrp(),binary=str(BINARY)))
    initial=wait_for(lambda r:r['event']=='placement.probe.sample' and r['accessibility']['reachable'] and r['accessibility']['native_window'],20)
    check('fresh native initial state',not objects(initial['state']) and initial['geometry_persistence_disabled'] and initial['native_platform']=='MacOS')
    action('identify');action('activate')
    click('tool-block');s=await_idle();check('pointer click only focuses palette',not objects(s) and s['SourceActivations']==0)
    action('key',key='return');s=wait_for(lambda r:len(objects(r['state']))==1)['state'];first=objects(s)[0]
    check('native Return uses placement command',s['SourceActivations']==1 and s['History']['UndoCount']==1 and first['ID']=='block-1')
    click('undo');wait_for(lambda r:not objects(r['state']))
    click('redo');s=wait_for(lambda r:len(objects(r['state']))==1)['state'];check('Undo/Redo preserves object identity and bytes',objects(s)[0]==first and s['Next']==1)
    before,after=drag('block',center('drawing',61,43))
    check('grid snapping applies to native drop',objects(after)[-1]['X']%20==0 and objects(after)[-1]['Y']%20==0)
    click('drawing');old=state()['View'];action('key',key='right');action('key',key='down');pan=state()['View'];check('native keyboard pan',pan['Center']!=old['Center'])
    action('scroll',start=center('drawing',37,-24),delta=-3);zoom=state()['View'];check('native scroll zoom',zoom['Zoom']!=pan['Zoom'])
    click('snap');wait_for(lambda r:not r['state']['Snap'])
    end=center('drawing',113,-67);before,after=drag('connector',end)
    f=frame('drawing');v=before['View'];expected=[v['Center']['X']+(end[0]-(f[0]+f[2]/2))*v['Width']/f[2]/v['Zoom'],v['Center']['Y']+((f[1]+f[3]/2)-end[1])*v['Height']/f[3]/v['Zoom']]
    obj=objects(after)[-1];error=[abs(obj['X']-expected[0]),abs(obj['Y']-expected[1])]
    check('native transformed coordinate agrees with independent AX-frame estimate',max(error)<6,expected=expected,actual=[obj['X'],obj['Y']],world_error=error,tolerance=6,qualification='AX widget frame includes content insets; exact transformed formula is covered separately by deterministic routing')
    # Select the original object after pan/zoom using its world-space center.
    f=frame('drawing');v=state()['View'];px=f[0]+f[2]/2+((first['X']+first['Width']/2)-v['Center']['X'])*v['Zoom']*f[2]/v['Width'];py=f[1]+f[3]/2-((first['Y']+first['Height']/2)-v['Center']['Y'])*v['Zoom']*f[3]/v['Height']
    before=state();action('click',start=[px,py]);s=wait_for(lambda r:r['state']['CanvasChanges']>before['CanvasChanges'])['state'];check('native canvas selection',s['Selected']==first['ID'] and s['History']==before['History'])
    click('reject-notes');wait_for(lambda r:r['state']['RejectNotes']);drag('note',center('drawing',-73,49),expected='rejected')
    click('lock');wait_for(lambda r:r['state']['Locked']);drag('block',center('drawing',-61,-37),expected='rejected')
    click('lock');wait_for(lambda r:not r['state']['Locked']);click('reject-notes');wait_for(lambda r:not r['state']['RejectNotes'])
    drag('note',center('drawing',-83,61),kind='escape-drag',expected='canceled')
    drag('block',center('help'),expected='outside')
    for mode in ['source','target']:
        click('probe-arm-'+mode);wait_for(lambda r:r['state']['RemoveOnDrag']==mode)
        drag('block',center('drawing',-31,-43),expected='removed')
        s=state();check('removal observed '+mode,s['HiddenSource'] if mode=='source' else s['HiddenTarget'])
        click('probe-restore');wait_for(lambda r:not r['state']['HiddenSource'] and not r['state']['HiddenTarget'])
    # Closure while capture is active is terminal. The operator must refuse any
    # further normal event after the target exits; that refusal is expected and
    # is retained as a nonzero operator result, not converted to a normal pass.
    click('probe-arm-window');wait_for(lambda r:r['state']['RemoveOnDrag']=='window');before=state()
    try:action('drag',start=center('tool-block'),end=center('drawing'))
    except ValueError:
        reasons=['owned target identity or stop changed','owned target lost foreground','sole owned native window','owned window identity/bounds changed','kernel process start identity','kernel executable path identity','kernel process identity changed during path lookup']
        need(actions[-1]['exit_code']!=0 and any(reason in actions[-1]['stderr'] for reason in reasons) and not STOP.exists(),'expected terminal operator refusal')
    else:raise ValueError('operator failed to refuse closed target')
    code=probe.wait(timeout=8);final=read(OUT/'latest.json')
    check('native closure exits zero',code==0,exit_code=code)
    check('closure cancels without creating an object',final['event']=='placement.probe.closed' and objects(final['state'])==objects(before) and final['state']['History']==before['History'] and not final['state']['Gesture']['Active'] and final['state']['Reserved']==0)
    check('native lifecycle observer clean',final['native_error']=='<nil>' and final['observer_error']=='<nil>' and final['deadline_error']=='<nil>')
    return dict(initial=initial,final=final)

def main():
    receipt=dict(result='INCOMPLETE',error=None,checks=checks,actions=actions,cleanup_errors=[],physical_hardware_input=False,settings_changed=False,cross_display_qualified=False,continuous_preview_visibility_qualified=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    try:receipt.update(run());receipt['result']='PASS_AUTOMATED_NATIVE_PLACEMENT'
    except BaseException as e:receipt.update(result='FAILED_AUTOMATED_NATIVE_PLACEMENT',error=dict(type=type(e).__name__,message=str(e)))
    finally:
        def cleanup_error(stage,e):receipt['cleanup_errors'].append(dict(stage=stage,type=type(e).__name__,message=str(e)))
        if probe is not None and probe.poll() is None:
            try:probe.terminate()
            except BaseException as e:cleanup_error('terminate',e)
            try:probe.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:probe.kill()
                except BaseException as e:cleanup_error('kill',e)
                try:probe.wait(timeout=2)
                except BaseException as e:cleanup_error('reap',e)
            except BaseException as e:cleanup_error('graceful-wait',e)
        if receipt['cleanup_errors']:receipt['result']='FAILED_AUTOMATED_NATIVE_PLACEMENT'
        receipt.update(probe_exit_code=probe.returncode if probe else None,elapsed_seconds=time.monotonic()-start)
        finish(receipt,P/'campaign.json',P/'campaign-closed','PASS_AUTOMATED_NATIVE_PLACEMENT','FAILED_AUTOMATED_NATIVE_PLACEMENT')
if __name__=='__main__':main()
