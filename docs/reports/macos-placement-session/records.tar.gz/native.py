"""Single fresh current-source native attempt; old sealed plans are never run."""
from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,threading,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-placement-session-3801970');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');STOP=P/'stop-native';HEAD='3801970e5f51938939bb1315bf56e86259cd1121'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
spec=importlib.util.spec_from_file_location('placement_live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py');lease=importlib.util.module_from_spec(spec);spec.loader.exec_module(lease)
def need(good,message):
 if not good:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def prepared():
 d={}
 for name in ['upstream','typesetting']:
  root=T/'drivers/cogent/build'/name
  for p in root.rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():d[name+'/'+p.relative_to(root).as_posix()]=sha(p)
 return {'files':len(d),'sha256':hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
def source():
 need(git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD and not git(C,'status','--porcelain'),'clean canonical base')
 changed=git(T,'diff','HEAD','--name-only').decode().splitlines();need(set(changed)=={'examples/placement/native_probe_darwin.go','examples/placement/native_probe_darwin_test.go','examples/placement/README.md'},'exact probe-only source scope')
 names=git(T,'ls-files','-z').decode().split('\0')[:-1]
 leaves={n:sha(T/n) for n in names if n.endswith(('.go','.mod','.sum','.m','.h'))}
 return {'commit':HEAD,'diff_sha256':hashlib.sha256(git(T,'diff','HEAD','--binary')).hexdigest(),'compiled_source_leaves':leaves}

def prepare():
 need(not (W/'native-plan-v2.json').exists() and not (W/'result.json').exists() and not STOP.exists() and not (P/'probe').exists(),'fresh plan')
 build=json.loads((W/'build-receipt.json').read_bytes());need(build['result']=='PASS_BUILD_AND_READ_ONLY_SELF_CHECK','build ready')
 pins={p:v['sha256'] for p,v in build['files'].items()}
 for p in [Path(__file__),W/'build-receipt.json',W/'operator_build.py',Path(lease.__file__),T/'scripts/child_process.py',P/'Vellum Placement Session.app/Contents/Info.plist']:pins[str(p)]=sha(p)
 plan={'source':source(),'prepared':prepared(),'inputs':pins,'scope':'One bounded PID-directed native placement attempt; no settings, clipboard, AX press/text actions or global input. Human hardware/continuous preview/display/performance not qualified.','argv':[sys.executable,'-B',str(W/'campaign.py')],'timeout':240,'stop':str(STOP),'probe_stop':str(P/'probe/stop-live'),'old_seals_preserved':True,'input_executed':False}
 need(plan['prepared']=={'files':6260,'sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'},'prepared identity');(W/'native-plan-v2.json').write_text(json.dumps(plan,indent=2)+'\n');print('Prepared fresh source-bound plan; no input')

def run():
 need(not (W/'result.json').exists() and not STOP.exists() and not (P/'probe').exists(),'single fresh attempt')
 review=json.loads((W/'native-admission.json').read_bytes());plan_bytes=(W/'native-plan-v2.json').read_bytes();plan=json.loads(plan_bytes);plan_digest=hashlib.sha256(plan_bytes).hexdigest();need(review['execution_ready'] and review['plan_sha256']==plan_digest,'reviewed exact plan')
 def stable():
  need(all(sha(p)==v for p,v in plan['inputs'].items()),'pins unchanged');need(source()==plan['source'],'source identity unchanged')
 stable();need(prepared()==plan['prepared'],'prepared identity unchanged')
 d={'result':'INCOMPLETE','plan_sha256':plan_digest,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':None,'physical_hardware_input':False,'settings_changed':False};done=threading.Event()
 def watch():
  while not done.wait(.2):
   if STOP.exists() or (P/'probe/stop-live').exists():_thread.interrupt_main();return
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('native controller terminated')))
 try:
  with lease.LiveLease():
   stable();need(not STOP.exists(),'stop requested');threading.Thread(target=watch,daemon=True).start()
   env=dict(os.environ,GOWORK='off',GOENV='off',GOTOOLCHAIN='local');[env.pop(k,None) for k in ['GOFLAGS','GOMAXPROCS','GOMEMLIMIT']]
   with (W/'native.stdout').open('xb') as out,(W/'native.stderr').open('xb') as err:r=run_child(plan['argv'],cwd=W,env=env,timeout=240,stdout=out,stderr=err,log_limit_bytes=8<<20)
   d['exit_code']=r.returncode;campaign=json.loads((P/'campaign.json').read_bytes());d['campaign_result']=campaign['result'];d['campaign_error']=campaign['error'];d['action_count']=len(campaign['actions']);d['check_count']=len(campaign['checks']);d['checks_passed']=sum(x['passed'] for x in campaign['checks']);stable();need(prepared()==plan['prepared'],'prepared terminal identity')
   need(r.returncode==0 and campaign['result']=='PASS_AUTOMATED_NATIVE_PLACEMENT' and not campaign['error'] and not campaign['cleanup_errors'] and not campaign['finalization_errors'],'native workflow acceptance')
   d['result']='PASS_AUTOMATED_NATIVE_PLACEMENT'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED_NATIVE_PLACEMENT',error={'type':type(e).__name__,'message':str(e)})
 finally:
  done.set();STOP.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':
 need(sys.argv[1:] in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
