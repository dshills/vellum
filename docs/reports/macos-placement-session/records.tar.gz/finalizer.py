"""Retain failure fidelity even when cleanup or terminal output fails."""
from pathlib import Path
import json

def finish(receipt, destination, seal, successful, failed):
    errors=receipt.setdefault('finalization_errors',[])
    def error(stage,e):errors.append(dict(stage=stage,type=type(e).__name__,message=str(e)))
    try:Path(seal).touch()
    except BaseException as e:error('seal',e)
    if errors:receipt['result']=failed
    try:
        print(json.dumps(dict(result='PENDING_EXCLUSIVE_RECEIPT',intended_result=receipt['result'],error=receipt.get('error'),finalization_errors=errors)),flush=True)
    except BaseException as e:error('report',e);receipt['result']=failed
    try:
        with Path(destination).open('x') as output:output.write(json.dumps(receipt,indent=2)+'\n')
    except BaseException as e:error('exclusive-receipt',e);receipt['result']=failed
    if receipt['result']!=successful or errors:raise RuntimeError('failed checkpoint; inspect raw output and exclusive receipt')
