#import <Cocoa/Cocoa.h>
#import <ApplicationServices/ApplicationServices.h>
#import <CoreGraphics/CoreGraphics.h>
#include <signal.h>
#include <unistd.h>
#include <libproc.h>

// Private test operator. Only PID-directed CGEvents; never global event posting,
// AX press/text actions, text entry, clipboard access, settings or permission
// requests. AX frontmost query/activation is restricted to the owned probe.
static volatile sig_atomic_t interrupted;
static void stopSignal(int value) { interrupted = value; }
static NSString *const humanStop = @"/private/tmp/vellum-placement-session-3801970/stop-native";
static BOOL stopped(void) { return interrupted || [[NSFileManager defaultManager] fileExistsAtPath:humanStop]; }
static void need(BOOL good, NSString *why) {
    if (!good) @throw [NSException exceptionWithName:@"OperatorFailure" reason:why userInfo:nil];
}
static void pauseFor(double seconds) {
    for (int i = 0; i < (int)ceil(seconds * 100); ++i) {
        need(!stopped(), @"stop requested");
        usleep(10000);
    }
}
static NSRunningApplication *target;
static NSString *birth;
static NSString *expectedPath;
static pid_t targetPID;
static BOOL mouseHeld;
static CGKeyCode keyHeld;
static BOOL hasKey;
static CGPoint lastPoint;
static CGWindowID ownedWindow;
static CGRect ownedBounds;
static AXUIElementRef axTarget;
static NSString *kernelIdentity(pid_t pid, NSString *path) {
    struct proc_bsdinfo info = {0};
    char executable[PROC_PIDPATHINFO_MAXSIZE] = {0};
    need(proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, sizeof(info)) == sizeof(info), @"kernel process start identity");
    need(proc_pidpath(pid, executable, sizeof(executable)) > 0 && [[NSString stringWithUTF8String:executable] isEqual:path], @"kernel executable path identity");
    need(info.pbi_pid == pid && info.pbi_start_tvsec > 0 && info.pbi_start_tvusec < 1000000, @"kernel process start fields");
    struct proc_bsdinfo after = {0};
    need(proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &after, sizeof(after)) == sizeof(after) && after.pbi_pid == pid &&
         after.pbi_start_tvsec == info.pbi_start_tvsec && after.pbi_start_tvusec == info.pbi_start_tvusec, @"kernel process identity changed during path lookup");
    return [NSString stringWithFormat:@"%llu:%llu", (unsigned long long)info.pbi_start_tvsec, (unsigned long long)info.pbi_start_tvusec];
}
static void windowIdentity(void) {
    NSArray *windows = CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly | kCGWindowListExcludeDesktopElements, kCGNullWindowID));
    int count = 0; CGWindowID found = 0; CGRect bounds = CGRectZero;
    for (NSDictionary *window in windows) {
        if ([window[(id)kCGWindowOwnerPID] intValue] != targetPID || [window[(id)kCGWindowLayer] intValue] != 0) continue;
        need(CGRectMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)window[(id)kCGWindowBounds], &bounds), @"native window bounds");
        count++; found = [window[(id)kCGWindowNumber] unsignedIntValue];
    }
    need(count == 1 && found != 0, @"sole owned native window");
    if (!ownedWindow) { ownedWindow = found; ownedBounds = bounds; }
    need(found == ownedWindow && CGRectEqualToRect(bounds, ownedBounds), @"owned window identity/bounds changed");
}
static void identity(BOOL foreground) {
    need(!stopped() && [kernelIdentity(targetPID, expectedPath) isEqual:birth], @"owned target identity or stop changed");
    if (foreground) {
        CFTypeRef frontmost = NULL;
        AXError error = AXUIElementCopyAttributeValue(axTarget, kAXFrontmostAttribute, &frontmost);
        BOOL active = error == kAXErrorSuccess && frontmost && CFGetTypeID(frontmost) == CFBooleanGetTypeID() && CFBooleanGetValue(frontmost);
        if (frontmost) CFRelease(frontmost);
        need(active, @"owned target lost foreground");
        windowIdentity();
    }
}
static void post(CGEventRef event, BOOL guard) {
    need(event != NULL, @"event allocation");
    @try {
        if (guard) {
            identity(YES);
            CGEventType type = CGEventGetType(event);
            if (type == kCGEventMouseMoved || type == kCGEventLeftMouseDown || type == kCGEventLeftMouseDragged || type == kCGEventLeftMouseUp || type == kCGEventScrollWheel)
                need(CGRectContainsPoint(ownedBounds, CGEventGetLocation(event)), @"each posted coordinate stays in owned window");
        }
        CGEventSetIntegerValueField(event, kCGEventSourceUserData, 0x56454c4c554d);
        CGEventPostToPid(targetPID, event);
    } @finally { CFRelease(event); }
}
static void mouse(CGEventType type, CGPoint point, BOOL guard) {
    CGEventRef event = CGEventCreateMouseEvent(NULL, type, point, kCGMouseButtonLeft);
    if (event) CGEventSetIntegerValueField(event, kCGMouseEventClickState, 1);
    post(event, guard);
}
static void key(CGKeyCode code, BOOL down, CGEventFlags flags, BOOL guard) {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, code, down);
    if (event) CGEventSetFlags(event, flags);
    post(event, guard);
}
static void press(CGKeyCode code, CGEventFlags flags) {
    key(code, YES, flags, YES); keyHeld = code; hasKey = YES; pauseFor(.08);
    key(code, NO, flags, YES); hasKey = NO; pauseFor(.25);
}
static CGPoint point(NSArray *values) {
    need([values isKindOfClass:NSArray.class] && values.count == 2, @"point shape");
    double x = [values[0] doubleValue], y = [values[1] doubleValue];
    need(isfinite(x) && isfinite(y) && fabs(x) < 20000 && fabs(y) < 20000, @"finite bounded point");
    // Probe NSAccessibility frames use Cocoa's bottom-left screen coordinates.
    CGPoint result = CGPointMake(x, CGDisplayBounds(CGMainDisplayID()).size.height - y);
    NSArray *windows = CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly | kCGWindowListExcludeDesktopElements, kCGNullWindowID));
    int ownedWindows = 0; BOOL inside = NO;
    for (NSDictionary *window in windows) {
        if ([window[(id)kCGWindowOwnerPID] intValue] != targetPID || [window[(id)kCGWindowLayer] intValue] != 0) continue;
        CGRect bounds; if (!CGRectMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)window[(id)kCGWindowBounds], &bounds)) continue;
        ownedWindows++; inside |= CGRectContainsPoint(bounds, result);
    }
    need(ownedWindows == 1 && inside, @"point must stay inside the sole owned native window");
    return result;
}
int main(int argc, const char **argv) {
    @autoreleasepool {
        signal(SIGTERM, stopSignal); signal(SIGINT, stopSignal);
        int result = 1;
        @try {
            need(argc == 2, @"one bounded private action file");
            if (!strcmp(argv[1], "--kernel-self-check")) {
                char path[PROC_PIDPATHINFO_MAXSIZE] = {0};
                need(proc_pidpath(getpid(), path, sizeof(path)) > 0, @"self executable path");
                NSString *token = kernelIdentity(getpid(), [NSString stringWithUTF8String:path]);
                printf("{\"result\":\"KERNEL_IDENTITY_SELF_CHECK\",\"pid\":%d,\"birth\":\"%s\",\"native_input_posted\":false}\n", getpid(), token.UTF8String);
                return 0;
            }
            NSString *file = [NSString stringWithUTF8String:argv[1]];
            NSData *data = [NSData dataWithContentsOfFile:file]; need(data && data.length <= 4096, @"action file bound");
            NSDictionary *action = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            need([action isKindOfClass:NSDictionary.class], @"action object");
            targetPID = [action[@"pid"] intValue]; expectedPath = action[@"executable"];
            need(targetPID > 1 && [expectedPath isKindOfClass:NSString.class] && [expectedPath isEqual:@"/private/tmp/vellum-placement-session-3801970/Vellum Placement Session.app/Contents/MacOS/placementprobe"], @"private target allowlist");
            need(AXIsProcessTrusted() && CGPreflightPostEventAccess(), @"existing native input permissions");
            [NSApplication sharedApplication];
            target = [NSRunningApplication runningApplicationWithProcessIdentifier:targetPID]; birth = kernelIdentity(targetPID, expectedPath);
            axTarget = AXUIElementCreateApplication(targetPID); need(axTarget != NULL, @"owned AX application allocation");
            need(AXUIElementSetMessagingTimeout(axTarget, .5) == kAXErrorSuccess, @"bounded owned AX query");
            identity(NO);
            NSString *kind = action[@"kind"];
            need([@[@"identify", @"activate", @"click", @"drag", @"escape-drag", @"key", @"scroll"] containsObject:kind], @"fixed action kind");
            if ([kind isEqual:@"identify"]) {
                printf("{\"result\":\"OWNED_IDENTITY\",\"pid\":%d,\"birth\":\"%s\"}\n", targetPID, birth.UTF8String);
                return 0;
            }
            need([action[@"birth"] isKindOfClass:NSString.class] && [action[@"birth"] isEqual:birth], @"controller-pinned process birth");
            if ([kind isEqual:@"activate"]) {
                // Directly launched Go apps may lack LaunchServices dates. Use
                // only their kernel-identified AX application's frontmost bit.
                need(AXUIElementSetAttributeValue(axTarget, kAXFrontmostAttribute, kCFBooleanTrue) == kAXErrorSuccess, @"activate owned probe"); pauseFor(.6); identity(YES);
            } else {
                identity(YES);
                if ([kind isEqual:@"key"]) {
                    NSString *name = action[@"key"];
                    NSDictionary *codes = @{@"return": @36, @"escape": @53, @"right": @124, @"down": @125, @"close": @13, @"undo": @6, @"redo": @6};
                    need(codes[name] != nil, @"fixed key allowlist");
                    CGEventFlags flags = ([name isEqual:@"close"] || [name isEqual:@"undo"] || [name isEqual:@"redo"]) ? kCGEventFlagMaskCommand : 0;
                    if ([name isEqual:@"redo"]) flags |= kCGEventFlagMaskShift;
                    press([codes[name] unsignedShortValue], flags);
                } else {
                    CGPoint start = point(action[@"start"]); lastPoint = start;
                    mouse(kCGEventMouseMoved, start, YES); pauseFor(.12);
                    if ([kind isEqual:@"scroll"]) {
                        int delta = [action[@"delta"] intValue]; need(delta != 0 && abs(delta) <= 10, @"bounded wheel delta");
                        CGEventRef event = CGEventCreateScrollWheelEvent(NULL, kCGScrollEventUnitLine, 1, delta); if (event) CGEventSetLocation(event, start); post(event, YES); pauseFor(.5);
                    } else {
                        mouse(kCGEventLeftMouseDown, start, YES); mouseHeld = YES; pauseFor(.25);
                        if (![kind isEqual:@"click"]) {
                            CGPoint end = point(action[@"end"]);
                            // Tiny movement is below the six-logical-pixel threshold.
                            CGPoint nextPoint = CGPointMake(start.x + 1, start.y); mouse(kCGEventLeftMouseDragged, nextPoint, YES); lastPoint = nextPoint; pauseFor(.25);
                            for (int step = 1; step <= 12; step++) {
                                nextPoint = CGPointMake(start.x + (end.x-start.x)*step/12, start.y + (end.y-start.y)*step/12);
                                mouse(kCGEventLeftMouseDragged, nextPoint, YES); lastPoint = nextPoint; pauseFor(.04);
                            }
                            pauseFor(.7);
                            if ([kind isEqual:@"escape-drag"]) press(53, 0);
                        }
                        mouse(kCGEventLeftMouseUp, lastPoint, YES); mouseHeld = NO; pauseFor(.35);
                    }
                }
            }
            identity(YES);
            printf("{\"result\":\"POSTED_TO_OWNED_PID\",\"pid\":%d,\"birth\":\"%s\",\"global_events\":false}\n", targetPID, birth.UTF8String);
            result = 0;
        } @catch (NSException *e) {
            fprintf(stderr, "%s: %s\n", e.name.UTF8String, e.reason.UTF8String);
        } @finally {
            // Release only keys/buttons this invocation held, directed to the same
            // still-owned process. Foreground loss/stop never prevents balancing.
            BOOL stillOwned = NO;
            @try { stillOwned = targetPID > 1 && birth && [kernelIdentity(targetPID, expectedPath) isEqual:birth]; }
            @catch (NSException *e) { /* An exited/replaced target receives no cleanup input. */ }
            if (stillOwned) {
                @try { if (mouseHeld) mouse(kCGEventLeftMouseUp, lastPoint, NO); }
                @catch (NSException *e) { fprintf(stderr, "mouse balance failure: %s\n", e.reason.UTF8String); result = 1; }
                @try { if (hasKey) key(keyHeld, NO, 0, NO); }
                @catch (NSException *e) { fprintf(stderr, "key balance failure: %s\n", e.reason.UTF8String); result = 1; }
            }
            if (axTarget) { CFRelease(axTarget); axTarget = NULL; }
        }
        return result;
    }
}
