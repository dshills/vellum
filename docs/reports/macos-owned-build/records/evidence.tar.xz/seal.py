from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
R=Path('/private/tmp/vellum-owned-build');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-owned-build/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((P/'summary.json').read_text());sources=s['sources'];review=json.loads((P/'checkpoint-review.json').read_text());adj=json.loads((P/'prism-adjudication.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==sources and not review['unresolved_findings']
assert all(sha(R/n)==h for n,h in sources.items())
assert adj['sources']==sources and not adj['unresolved_findings'] and adj['prism_coverage_complete']and adj['current_sources_covered']==sources
for version in ['prism-v1','prism-v2']:
 raw=json.loads((P/version/'prism.json').read_text());proc=json.loads((P/version/'process.json').read_text());cov=raw['coverage']
 assert proc['error']is None and proc['source_index_stable'] and cov['complete']and not cov['skipped']and not cov['excluded']and cov['truncatedBytes']==0
 assert cov['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
 assert adj['reviews'][version]['prism_sha256']==sha(P/version/'prism.json') and adj['reviews'][version]['process_sha256']==sha(P/version/'process.json')
D.mkdir(exist_ok=False)
files=[f for f in sorted(P.rglob('*'))if f.is_file()and '__pycache__'not in f.parts]
omitted={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size,'reason':'Private compiled app or SDK; identity retained, not executed. Final compiler output and SDK preserved separately in workspace artifacts.'}for f in files if f.name=='vellum-workbench' or f.parent.name=='MacOS' or f.name in ['vellum-sdk.tar.gz','vellum-sdk-final.tar.gz']}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[f for f in sorted(P.rglob('*'))if f.is_file()and '__pycache__'not in f.parts and f.relative_to(P).as_posix()not in omitted]
assert not any(f.is_symlink()for f in files)
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
archive=D/'evidence.tar.xz'
with archive.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted};(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**s,'result':'PASS_SCOPED_OWNED_MAC_BUILD_CHECKPOINT','checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':adj['invocations'],'prism_llm_calls':adj['llm_calls'],'prism_chunks':adj['chunks'],'prism_raw_initial_exit_code':1,'prism_raw_followup_exit_code':0,'prism_initial_findings':2,'prism_fixed_findings':2,'prism_unresolved_findings':0,'prism_coverage_complete':True,'prism_adjudication_sha256':sha(P/'prism-adjudication.json'),'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
subprocess.run(['git','add','docs/reports/macos-owned-build/records'],cwd=R,check=True)
print(json.dumps({k:q[k]for k in ['result','archive_members','archive_bytes','archive_sha256','prism_unresolved_findings']}))
