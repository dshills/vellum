from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
R=Path('/private/tmp/vellum-owned-build');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent;O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-owned-build')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
env=child_environment()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=env,capture_output=True,timeout=60)
 if d.returncode:raise ValueError(d.stderr.decode())
 return d.stdout.decode().strip()
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in (root/'drivers/cogent/build'/m).rglob('*')if f.is_file()}
D=R/'docs/reports/macos-owned-build/records';q=json.loads((D/'qualification.json').read_text());review=json.loads((P/'final-review.json').read_text())
assert q['result']=='PASS_SCOPED_OWNED_MAC_BUILD_CHECKPOINT'and review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not review['unresolved_findings']and q['prism_coverage_complete']and q['prism_unresolved_findings']==0
assert all(not q[k]for k in ['native_binary_executed','private_app_launched','signing_identity_requested','notarized','published','hermetic_build_qualified','independent_provenance_qualified','full_native_component_closure_qualified','distribution_rights_approved','native_latency_qualified','retained_memory_qualified','full_mac_qualified'])
base=q['base_commit'];commit=git(R,'rev-parse','HEAD')
assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]and git(C,'rev-parse','HEAD')==base and not git(C,'status','--porcelain')and not git(R,'status','--porcelain')
changed=set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines());expected_changed=set(q['sources'])|{'docs/reports/macos-owned-build/records/'+n for n in ['qualification.json','archive-index.json','evidence.tar.xz']}
assert changed==expected_changed and len(changed)==14
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names}
assert review['sources']=={n:expected[n]for n in changed} and all(expected[n]==h for n,h in q['sources'].items())
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/name.decode();assert kind=='blob'and path.is_file()and not path.is_symlink();data=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
assert prepared(C)==prepared(R)==q['prepared_after']==q['prepared_before']and len(q['prepared_after'])==6226
marker=Path('/private/tmp/vellum-macos-quiet-current/stop-live');assert sha(marker)==q['human_online_live_stop_sha256'];marker_hash=sha(marker)
O.mkdir(parents=True,exist_ok=True);output=O/'canonical-promotion.json';output.open('x').close();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'changed_files':sorted(changed),'scope':'Observed private Mac compiler binary/map pairing and bounded build diagnostics; no native runtime or distribution-rights/fullMac claim.'};start=time.monotonic()
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 actual=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_files':len(expected),'tracked_exact':set(actual)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_files':6226,'prepared_exact':prepared(C)==q['prepared_after'],'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'heads_exact':git(C,'rev-parse','HEAD')==commit and git(R,'rev-parse','HEAD')==commit,'human_online_live_stop_preserved':sha(marker)==marker_hash,'archive_sha256':sha(C/'docs/reports/macos-owned-build/records/evidence.tar.xz'),'final_review_sha256':sha(P/'final-review.json')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean','heads_exact','human_online_live_stop_preserved'])and record['archive_sha256']==q['archive_sha256']
 for name in ['qualification.json','archive-index.json','evidence.tar.xz']:shutil.copyfile(D/name,O/name)
 for name in ['final-review.json','final-review.md']:shutil.copyfile(P/name,O/name)
 shutil.copytree(P/'private build v3',O/'private-build')
 shutil.copyfile(P/'vellum-sdk-final.tar.gz',O/'vellum-sdk-private.tar.gz')
 assert sha(O/'private-build/vellum-workbench')==q['binary_sha256']and sha(O/'vellum-sdk-private.tar.gz')==q['sdk_sha256'];record['durable_private_artifacts_exact']=True;record['result']='PASS_CANONICAL_PROMOTION'
except BaseException as error:
 record['result']='FAILED_CANONICAL_PROMOTION';record['error']={'type':type(error).__name__,'message':str(error)};raise
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');output.write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
