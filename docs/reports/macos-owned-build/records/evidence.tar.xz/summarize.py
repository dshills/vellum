from pathlib import Path
import hashlib,json,re,subprocess,tarfile
R=Path('/private/tmp/vellum-owned-build');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review-v3.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==11
assert all(sha(R/n)==h for n,h in sources.items())
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in (root/'drivers/cogent/build'/module).rglob('*')if f.is_file()}
prepared_now=prepared(R);assert len(prepared_now)==6226
checks={}
jobs={
 'build-unit-v5':['scripts/build-macos.py','scripts/build_output.py','scripts/build-macos_test.py','scripts/child_process.py'],
 'child-unit-v4':['scripts/child_process.py','scripts/child_process_test.py'],
 'inventory-unit-v1':['scripts/child_process.py'],
 'archive-unit-v1':[],
 'sdk-unit-v2':['scripts/child_process.py'],
 'sdk-verifier-unit-v1':['scripts/child_process.py'],
 'package-unit-v1':['scripts/child_process.py'],
 'actual-build-v3':[n for n in sources if not n.startswith('docs/reports/')],
 'sdk-archive-v2':[n for n in sources if not n.startswith('docs/reports/')],
 'private-package-v3':['scripts/child_process.py'],
 'sdk-relocation-v2':['scripts/child_process.py']}
for name,needed in jobs.items():
 d=json.loads((P/(name+'.json')).read_text())
 assert d['exit_code']==0 and d['error']is None and d['source_delta_stable'] and not d['live_tests'] and not d['headless_gpu_requested']
 assert d['prepared_before']==d['prepared_after']==prepared_now
 assert all(d['source_delta_before'][n]==d['source_delta_after'][n]==sources[n]for n in needed)
 assert all(d[c+'_sha256']==sha(P/(name+'.'+c))for c in ['stdout','stderr'])
 text=(P/(name+'.stderr')).read_text();counts=re.findall(r'Ran (\d+) tests?',text)
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'current_sources_matched':needed,'source_stable':True,'prepared_files':len(prepared_now)}
 if counts:checks[name]['unit_tests']=int(counts[-1])
B=P/'private build v3';receipt=json.loads((B/'build-receipt.json').read_text());before=json.loads((B/'inputs-before.json').read_text());after=json.loads((B/'inventory.json').read_text());obs=after['native_link_observation']
assert {k:v for k,v in after.items()if k!='native_link_observation'}==before
assert receipt['source']==before['source'] and receipt['build_configuration']==before['build_configuration']
assert receipt['artifact_pair_binding']=='producer-observed-same-build' and obs['artifact_pair_binding']=='caller-supplied-unverified'
assert receipt['command']['exit_code']==0 and receipt['command']['outputs_initially_absent'] and not receipt['runtime_executed'] and receipt['distribution_audit']=='pending'
assert set(receipt['artifacts'])=={'vellum-workbench','vellum-workbench.map','inventory.json','inputs-before.json','build.stdout','build.stderr'}
assert set(x.name for x in B.iterdir())==set(receipt['artifacts'])|{'build-receipt.json'}
for n,d in receipt['artifacts'].items():assert sha(B/n)==d['sha256'] and (B/n).stat().st_size==d['bytes']
assert obs['binary']==receipt['artifacts']['vellum-workbench'] and obs['link_map']==receipt['artifacts']['vellum-workbench.map']
assert all(sha(R/f['file'])==f['sha256'] and (R/f['file']).stat().st_size==f['bytes']for f in before['sdk_files'])
app=P/'VellumOwnedBuildFinal.app/Contents';manifest=json.loads((app/'Resources/APP_MANIFEST.json').read_text())
assert sha(app/'MacOS/VellumOwnedBuild')==receipt['artifacts']['vellum-workbench']['sha256']==manifest['source_binary_sha256']
assert manifest['signed_identity']is None and not manifest['notarized'] and manifest['native_distribution_audit']=='pending'
sdk=json.loads((P/'sdk-relocation-v2.stdout').read_text());assert sdk['archive_sha256']==sha(P/'vellum-sdk-final.tar.gz') and sdk['native_runtime']=='not executed' and sdk['digest_verified_against_expected']
with tarfile.open(P/'vellum-sdk-final.tar.gz')as tar:
 names=tar.getnames();prefix=next(n[:-len('scripts/build-macos.py')]for n in names if n.endswith('/scripts/build-macos.py'))
 for n,h in sources.items():
  if n.startswith('docs/reports/'):continue
  assert hashlib.sha256(tar.extractfile(prefix+n).read()).hexdigest()==h
mutations=json.loads((P/'mutation-checks.json').read_text());assert mutations['result']=='PASS'and len(mutations['controls'])==5 and all(m['detected']and m['failures']and not m['errors']for m in mutations['controls'])
assert all(sources[n]==h for n,h in mutations['source_sha256'].items())
summary={'result':'PASS_SCOPED_OWNED_MAC_BUILD_CHECKS','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sources':sources,'checks':checks,'prepared_before':prepared_now,'prepared_after':prepared_now,'prepared_files':6226,'actual_receipt_sha256':sha(B/'build-receipt.json'),'binary_sha256':receipt['artifacts']['vellum-workbench']['sha256'],'map_sha256':receipt['artifacts']['vellum-workbench.map']['sha256'],'inventory_sdk_files':len(before['sdk_files']),'linker_objects':obs['object_count'],'archives':len(obs['archives']),'selected_archive_members':sum(len(a['selected_members'])for a in obs['archives']),'unresolved_archives':len(obs['unresolved_archives']),'sdk_sha256':sha(P/'vellum-sdk-final.tar.gz'),'sdk_verified_files':sdk['verified_files'],'artifact_pair_binding':receipt['artifact_pair_binding'],'collector_pair_binding':obs['artifact_pair_binding'],'fault_controls':5,'fault_controls_sha256':sha(P/'mutation-checks.json'),'internal_source_review_sha256':sha(P/'source-review-v3.json'),'human_online_live_stop_sha256':sha('/private/tmp/vellum-macos-quiet-current/stop-live'),'native_binary_executed':False,'private_app_launched':False,'signing_identity_requested':False,'notarized':False,'published':False,'hermetic_build_qualified':False,'independent_provenance_qualified':False,'full_native_component_closure_qualified':False,'distribution_rights_approved':False,'native_latency_qualified':False,'retained_memory_qualified':False,'full_mac_qualified':False,'excluded_attempts':{'child-unit-v1':'sandbox denied own-PID observation','build-unit-v1':'fixture expected the wrong missing-map error type; fixed','build-unit-v2':'superseded before reviewed integrity corrections','child-unit-v2':'superseded before strict process-observation correction','build-unit-v3':'superseded by added environment/inode guard regressions','actual-build-v1':'superseded before output integrity corrections','actual-build-v2':'superseded by provider cleanup-reporting correction','sdk-archive-v1 and sdk-relocation-v1':'superseded by corrected final SDK','private-package-v2':'superseded by corrected final binary package','build-unit-v4 and child-unit-v3':'superseded by provider corrections and final unit checks','sdk-unit-v1':'sandbox denied Go cache access; escalated v2 passed','private-package-v1':'producer correctly refused an existing output directory; corrected fixture uses new .app','mutation-v1':'in-memory alternate module failed to reuse mocked dependencies; excluded setup errors, corrected five controls pass'},'limits':['Same local observed compiler invocation and sampled input stability; not hermetic/independent provenance','Distribution audit pending; complete embedded Rust/C source/rights closure remains open','No produced app executed, live GUI/GPU/performance/endurance or human checks; full Mac open']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['sources','checks','prepared_before','prepared_after','excluded_attempts']},indent=2))
