from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-owned-build');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review-v2.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==11
assert all(sha(R/n)==h for n,h in sources.items())
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
out=P/'prism-v1';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Private macOS owned-build producer compiles workbench once with external linker map, no app execution. Before/after SDK/source/config inputs, resolved Go tool, controlled environment and producer sampled identities must agree. Exact emitted binary/map hashes checked through native inventory and publication. Collector arbitrary-pair scope stays caller-supplied-unverified; only receipt says producer-observed-same-build. Fresh no-space compiler stage, descriptor-anchored exclusive final directory outside checkout, no-follow regular streaming bounded artifact reads, known-created inode checks, expected serialized JSON and streamed log hashes, receipt-last and exact final receipt-byte check. Bounded concurrent binary stdout/stderr (4MiB/channel,600s), timeout/overflow/sink failure kill owned group without buffering flood. Defaults unchanged. Internal source approval resolves3 earlier findings;10 build tests,9 child tests,real Mac compilation,private unsigned packaging,SDK export/relocation and5 guard-removal controls pass. Documentation distinguishes observed pairing from hermetic provenance, Rust/C closure, redistribution rights and runtime qualification. No signing identity/notarization/publication/GUI/GPU launch or Mac acceptance claim; public audit pending. Review11 current implementation/test/check/docs/spec files once; no full Mac completion claim.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'source-review-v2.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
