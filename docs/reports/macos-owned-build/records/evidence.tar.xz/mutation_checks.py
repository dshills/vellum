"""Fault controls for owned-build integrity guards; no compiler/application launches."""
from pathlib import Path
import hashlib, importlib.util, io, json, sys, unittest
R=Path('/private/tmp/vellum-owned-build'); P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
spec=importlib.util.spec_from_file_location('owned_build_tests',R/'scripts/build-macos_test.py')
tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
original_output=(R/'scripts/build_output.py').read_text()
original_build=(R/'scripts/build-macos.py').read_text()
cases=[
 ('metadata-content', 'build', 'if artifacts != expected:', 'if False:', 'test_replaced_or_edited_metadata_never_becomes_receipt_truth'),
 ('created-inode', 'output', 'if key(before) != self.created.get(name):', 'if False:', 'test_output_bounds_symlink_fifo_and_duplicate_preservation'),
 ('parent-containment', 'output', 'if self.path != admitted or self.path.is_relative_to(root):', 'if False:', 'test_initialization_parent_redirection_refuses_before_output_creation'),
 ('receipt-content', 'build', 'if identity["sha256"] != completed["receipt_sha256"] or identity["bytes"] != len(json_bytes(receipt)):', 'if False:', 'test_altered_completion_receipt_refuses_and_is_retired'),
 ('sampled-input-drift', 'build', 'if {key: value for key, value in after.items() if key != "native_link_observation"} != before:', 'if False:', 'test_failures_retain_diagnostics_without_success_receipt')]
results=[]
for name,module,old,new,test in cases:
 namespace={'__file__':str(R/'scripts'/('build_output.py'if module=='output'else'build-macos.py')),'__name__':'fault_'+name.replace('-','_')}
 source=original_output if module=='output'else original_build
 assert source.count(old)==1
 source=source.replace(old,new)
 if name=='created-inode':
  source=source.replace('if not stat.S_ISREG(entry.st_mode) or key(entry) != self.created.get(name):','if not stat.S_ISREG(entry.st_mode):')
 exec(compile(source,namespace['__file__'],'exec'),namespace)
 if module=='build':
  namespace['inventory']=tests.build.inventory
  for symbol in ['go_identity','run_child','child_environment']:
   namespace[symbol]=(lambda name:lambda *args,**kwargs:getattr(tests.build,name)(*args,**kwargs))(symbol)
 original_class=tests.BuildOutput; original_function=tests.build.build
 try:
  if module=='output': tests.BuildOutput=namespace['BuildOutput']
  else: tests.build.build=namespace['build']
  log=io.StringIO(); suite=unittest.TestSuite([tests.BuildChecks(test)])
  result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
  (P/('fault-'+name+'.log')).write_text(log.getvalue())
  results.append({'control':name,'test':test,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'detected':not result.wasSuccessful(),'mutated_source_sha256':hashlib.sha256(source.encode()).hexdigest()})
 finally:
  tests.BuildOutput=original_class;tests.build.build=original_function
report={'result':'PASS'if all(row['detected']and row['failures']and not row['errors']for row in results)else'FAIL','source_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in ['scripts/build_output.py','scripts/build-macos.py','scripts/build-macos_test.py']},'controls':results,'native_executed':False,'scope':'In-memory guard removal must fail an existing targeted regression; each original test passed separately.'}
(P/'mutation-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(0 if report['result']=='PASS'else 1)
