from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-owned-build');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review-v3.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==11
assert all(sha(R/n)==h for n,h in sources.items())
old=json.loads((P/'prism-v1/process.json').read_text())['sources']
selected={n:h for n,h in sources.items()if old[n]!=h}
assert set(selected)=={'scripts/build-macos.py','scripts/build-macos_test.py','scripts/child_process_test.py','specs/release.md','docs/reports/macos-owned-build/README.md'}
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
out=P/'prism-v2';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'sources':selected,'checkpoint_sources':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'prior_review_sha256':sha(P/'prism-v1/prism.json'),'scope':'Targeted correction review of five changed files. Prior complete eleven-file Prism review found silent cleanup/diagnostic errors and overflow fixture .2second startup deadline. Corrected producer preserves original error, attaches cleanup phase/error and unconfirmed output/receipt-retirement status; CLI includes it. Regression injects failed receipt publication+retirement and checks original identity and structuredCLI. Overflow fixture gets5seconds; idle timeout keeps .2. Specs/report disclose cleanup failure. Eleven build and nine child tests pass, actual corrected Mac compile and private app package pass; SDK relocation pending. No runtime launch, explicit signing identity/notarization/publish/public-rights/fullMac claim. Remaining six source hashes unchanged from original fullreview.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(selected),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':selected,'checkpoint_sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'source-review-v3.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
