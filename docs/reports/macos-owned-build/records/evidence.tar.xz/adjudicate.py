from pathlib import Path
import hashlib,json
R=Path('/private/tmp/vellum-owned-build');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((P/'summary.json').read_text())['sources'];latest={};calls=chunks=0
for version in ['prism-v1','prism-v2']:
 raw=json.loads((P/version/'prism.json').read_text());proc=json.loads((P/version/'process.json').read_text());cov=raw['coverage']
 assert proc['error']is None and proc['source_index_stable']and proc['exit_code']in [0,1]
 assert cov['complete']and not cov['skipped']and not cov['excluded']and cov['truncatedBytes']==0 and cov['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
 assert cov['files']==len(proc['sources']);calls+=cov['llmCalls'];chunks+=cov['chunks']
 latest.update(proc['sources'])
 if version=='prism-v2':assert not raw['findings']and proc['exit_code']==0
assert latest==s and all(sha(R/n)==h for n,h in s.items())
first=json.loads((P/'prism-v1/prism.json').read_text());assert {f['id']for f in first['findings']}=={'f04dd83c99ed0f1b','1bdca35b1615a028'}
findings=[{'id':'f04dd83c99ed0f1b','status':'fixed','disposition':'Preserve original error; attach cleanup phase/error and unconfirmed completion/receipt-retirement state. CLI exposes cleanup diagnostic. Injected failed receipt publication/removal verifies original exception identity and CLI metadata.','files':['scripts/build-macos.py','scripts/build-macos_test.py'],'evidence':'build-unit-v5'}, {'id':'1bdca35b1615a028','status':'fixed','disposition':'Overflow case receives a five-second startup/output deadline; sleeping-child deadline remains0.2 seconds.','files':['scripts/child_process_test.py'],'evidence':'child-unit-v4'}]
r={'result':'RESOLVED_WITH_TARGETED_PROVIDER_FOLLOWUP','sources':s,'findings':findings,'unresolved_findings':[],'prism_coverage_complete':True,'current_sources_covered':latest,'invocations':2,'llm_calls':calls,'chunks':chunks,'raw_first_exit_code':1,'raw_followup_exit_code':0,'raw_findings_preserved':True,'internal_source_review_sha256':sha(P/'source-review-v3.json'),'reviews':{version:{'process_sha256':sha(P/version/'process.json'),'prism_sha256':sha(P/version/'prism.json')}for version in ['prism-v1','prism-v2']}}
(P/'prism-adjudication.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'result':r['result'],'files':len(s),'invocations':r['invocations'],'calls':calls,'chunks':chunks,'unresolved':0}))
