# Read-only complete-frame / AX diagnosis

Assigned canonical baseline: `f68941bf8db129784aa7a137c9d84a3dee69370d`. The 17 exact read inputs and historical profile identity are in `inputs.json`. No source, test, Go, native, GUI, provider, Git, preference or preparation action was performed.

The highest-value source-backed issue is a grid AX **withdraw / restore publication cycle**, followed by the full native JSON transport and tree rebuild. It is not evidence that Undo, accessibility itself or the 400-cell workload should be removed.

## What the current code does

1. The originating `Driver.refresh` runs under Application.Do and rootMu, takes dirty, reconciles and calls `syncAccessibility` immediately (`driver.go:134–176`). `syncGrid` accepts the new snapshot/generation before this (`grid.go:579–687`).
2. The completed measurement is still the prior generation at this point. `currentMeasurement` rejects it (`grid_geometry.go:137–147`); `gridAccessibility` therefore returns zero rows/cells/headers (`grid_accessibility.go:12–15`). The table host nevertheless publishes the new row/column count and `GridGeneration` (`accessibility.go:274–281`). This produces a genuinely different semantic snapshot, not a byte-identical duplicate.
3. `accessibilityBridge.update` marshals nodes once to compare them and again inside the generation envelope. It replaces owner handlers and advances the generation for changed trees (`accessibility.go:141–169`). Exact duplicates are already suppressed, and the identical-refresh admitted-action test requires that behavior (`accessibility_test.go:239–263`).
4. Native `vellumAXUpdate` validates the complete payload before mutation, constructs hierarchy/next/child arrays, retires IDs missing from `next`, then replaces `state.elements` (`accessibility_darwin.m:267–285,337–367`). Thus the pre-frame empty-grid publication can retire the complete visible AX grid map.
5. The actual retained grid renders, captures native geometry and stores an immutable measurement. A different generation or host bounds owner-invalidates (`grid.go:886–889; grid_geometry.go:75–130`). This is specifically why the capture tail exists.
6. The next owner refresh uses the successfully cached grid projection, avoiding repeated source materialization and host Update (`grid.go:588–604`), but accessibility now sees the matching completed measurement and publishes the visible nodes again. Since the previous native map excluded them, ordinary lookup at `m:349` cannot reuse those former objects. Normal single-scroll ordering therefore implies empty-grid withdrawal followed by a full-grid restoration. This count is a control-flow inference; this analysis did not run a publication counter.
7. Completed geometry currently travels separately as an unversioned ID→rectangle map on every host RenderWidget (`accessibility.go:707–736`, `m:370–375`). Cached geometry may precede semantics; semantics remove geometry for IDs absent from their full snapshot. A new protocol must treat semantics, retained identity and this ordering together.

This cycle can produce native object churn, layout notifications and a transient empty accessibility table. The correctness reason for rejecting old actions is valid; it does not itself require deleting last-completed read-only objects.

## Profile limits and other work

The historical profile was recorded at `1be608c...`, not this assigned current baseline. Its proof says one process, 240 samples, process-wide CPU diagnostic, not a timing-budget/per-thread attribution. It reports `nativeAccessibilityUpdate` cumulative 0.57s and bridge.update 0.58s, versus syncGrid/reconcile about 0.04s each and native geometry about 0.05s. 0.57/240=2.375ms is only an amortized sampled CPU observation, not a precisely measured phase or promised savings.

In particular, the C entry constructs NSString then dispatches the parse/rebuild block asynchronously on main (`m:337–343`). The entry's Go CPU stack does **not** isolate that asynchronously executed work. The present transport copies into C.CString, decodes UTF-8 into NSString, and later creates UTF-8 NSData for NSJSONSerialization. Retained NSData from the original checked UTF-8 bytes would remove the decode/re-encode round trip while keeping the complete current protocol and validation. It is a low-risk independent experiment; it does not resolve empty-table churn by itself.

Actual accepted scrolls still rebuild the bounded native cell projection and recursively host.Update. Pooled widgets are positional (`grid.go:652–678`), so a one-row shift changes many pool-slot strings even though most domain cells overlap. Core Text's final updater reparses HTML and configTextAlloc reshapes (`core/text.go:315–329,509–526`), and SizeUp also reshapes (530–538). A future keyed cell pool / exact text-and-effective-layout/style cache could reuse those overlapping shapes. It must retain geometry, selected/cursor/invisible reset, inherited typography/theme, disabled/help, reparent/scale and private editing behavior. The observed profile does not make this the leading candidate; the already committed single-host Update and unchanged-projection guard should remain intact.

The current raw profile also has substantial SetFromGoImage / WriteTexture cumulative cost and CGO/runtime time. Full-surface upload or render restructuring requires its own renderer design and fresh phase measurements; AX cumulative CPU alone cannot rank every complete-frame source.

## Safest complete AX design: immediate action revocation, scoped pending, atomic completed publication

Use **per visible grid scope**, not a whole-window wait. Keep generic controls live and current independently. Do not wait for every model in a window to produce a frame: inactive tabs, obscured grids, modals, empty layouts and a failed/closed window would otherwise strand unrelated accessibility.

### Identity and ownership

A publication identity is `(bridge token, namespaced host ID, binding incarnation, visibility/scope epoch)`. Keep the grid portable accepted generation and completed-frame ordinal separately. The grid model/source stamp, viewport and measurement's requested scale must match; do not use Frames alone as readiness. Namespaced workbench/modal IDs must already be qualified by the owner. A real unmount, model replacement, namespace/parent/scope removal or window closure is a **remove**, never a pending layout transition.

Owner-held snapshots contain copied semantic records and action handlers; native-render snapshots contain copied completed rectangles/text geometry only. Native rendering still must not call Application.Do or read domain models. Merge the two immutable publications on the owner using the existing bounded completion/invalidation path. Every acceptance check uses the current root/control lifetime and exact binding; nothing retains a Grid/source pointer solely through a native read-only record.

### Pending transition

When the originating refresh accepts a new grid projection that lacks its matching completed frame, advance the Go bridge action epoch immediately and remove/disable that scope's action handlers. Publish a small pending-scopes transaction, with the new bridge epoch, while preserving that same-incarnation scope's **last safely published completed** nodes and rectangles read-only. Native selector permission and request admission must refuse pending-scope actions, and Go must independently reject pending/stale grid requests both at admission and owner delivery.

The phrase is intentionally "last safely published completed", not a guarantee that AX is synchronously the literal latest presented framebuffer: the existing asynchronous main queue already permits publication latency, and a newer accepted model may supersede a frame before its owner acknowledgment. The retained record still corresponds to a real completed frame and cannot be mistaken for a current accepted projection. Inspection should expose pending scopes/provenance so tests never count old records as current readiness.

Current non-grid controls must publish their newest names/help/value/enabled/focus/selection state during this wait. A global epoch-only revocation without native publication would disable every toolbar action indefinitely if one grid never renders. Conversely, advancing native generation for unrelated controls while retaining old grid handlers would make old grid actions valid again. Explicit per-scope action gates plus immediate current-handler removal avoid both failures.

Do not repeatedly emit identical pending state when the capture tail or focus produces a duplicate invalidation. Preserve the existing identical-refresh contract for current static controls. A newer pending generation supersedes the older pending target; the retained read-only grid remains only the last published completed one, never an accumulation of pending generations.

### Completed transition

Once owner state, retained projection, immutable measurement, scope identity, source stamp, viewport/scale and window lifetime all agree, construct **one immutable transaction** containing that scope's semantics and completed geometry. Apply it in a single main-queue block only if its exact scope identity still exists and generation/epoch has not been superseded. Validate the whole resulting tree and numeric payload before changing objects. Update native state generation, geometry and action-enabled status atomically; then issue the same layout/value/focus notifications as the accepted full protocol requires.

Native retained objects for stable IDs remain in the same scoped map through pending. Restore the same objects for the still-present IDs, create only genuinely new IDs, and retire only genuinely removed IDs after the new completed snapshot is accepted. This avoids resurrection after real deletion: removed scope objects are marked not live, parent/children links and geometry are cleared, scope caches are dropped, and a later same textual ID with a different incarnation cannot inherit old objects. Window detach retains current token/closed checks and clears all caches. Queued transactions for the old token/incarnation become inert.

The owner keeps latest handlers (closures capturing current refs) independent of native object reuse. Already-admitted older actions still fail the Go epoch/ref/lifetime rechecks. A native action taken from an old read-only pending record cannot be admitted. Row-selection flags, active-cell cursor, total/index metadata, full values, column headers, and text editor selection/client/session are all part of semantic dirtiness; no reduction in materialized visible cells is permitted.

### Delta optimization after correctness

Once the pending/completed protocol is qualified, compare the current bounded semantic scope to its last completed one. Send upserts for changed/new nodes, explicit removals, ordered parent-child topology and the current epoch rather than every unchanged node dictionary. A one-row shift then changes entering/leaving row/cell semantics and geometry for overlapping cells; unchanged header/label/value records need not cross CGO again. Full snapshot remains the startup/recovery/reference path. Validate delta base identity/generation and the final assembled tree before mutation; reject wrong-base or malformed/cyclic/duplicate payloads without partial changes.

Do not remove serialized GridGeneration and hope byte comparison handles it. Today it intentionally differentiates new grid refs even if displayed IDs/text happen to be unchanged. Separate action epoch/pending provenance first, preserving generation rejection. Likewise, do not reuse handlers or nodes solely because the source revision, cell key, pool position or `Frames` counter is unchanged.

## Alternative: bounded detached pending-object pool

A smaller native-only change could keep just the preceding grid scope's removed objects in a bounded inactive pool across the known pre-frame withdrawal and reuse them on restoration. All held objects must have `live=NO`, no actions, no links; the pool must be bounded by one preceding scope, cleared on real remove/close/remount and keyed by exact incarnation rather than arbitrary IDs. This reduces allocation but preserves transient empty tables, two publications and full JSON restoration. Current wire has no explicit pending-vs-real-delete marker/incarnation, so a heuristic generic cache of removed IDs is unsafe. The scoped pending/completed transaction is the preferable framework correction; the detached-pool approach is only a transitional alternative after explicit lifecycle metadata exists.

## Regression and acceptance matrix

Before optimization, add counters on the exact current protocol to confirm pre-frame withdrawal/restoration and distinguish CGO copy/enqueue, main parse/validate, retained commit and notifications. Counter instrumentation is diagnostic; ordinary release records remain separately qualified.

1. Real routed 400-cell vertical/horizontal/sub-row scroll: old read-only values+geometry remain available while pending, actions refuse, completed tree has all actual clipped cells/rows/headers and exact measured values/rectangles, stable overlapping native objects remain identical. Check pointer identity only for stable same-incarnation IDs, never recycled positional slots.
2. An older action admitted before pending, and an action attempted during pending, must not execute after owner advances; current completed action succeeds once. Existing stale selection-ref and identical-refresh tests remain meaningful.
3. Two rapid accepted generations before a frame, then stale completed packet followed by newest completed packet: stale one is inert; no false current readiness, pool growth, handler resurrection or duplicate notification.
4. Unchanged capture tail: no new semantic epoch or redundant identical pending/ready publication; completed rectangles stay correct. A geometry-only resize/scale/reparent changes the required atomic geometry even when text/keys match.
5. Current toolbar controls and another ready grid remain queryable/actionable while one grid is pending. Window modal/tab/workbench scope changes immediately withdraw removed scopes rather than waiting for hidden grid frames.
6. Logical WindowContext close before native teardown, forced native close, owner/app close and queued publication after detach: no action, callback, element/cache resurrection or cross-window token confusion.
7. Model replacement with same Node.ID, true removal/reinsert, namespace/parent move: old elements are retired, not reused as same-incarnation pending records. Wrong scope/incarnation/base delta is rejected atomically.
8. Selection all/toggle and cursor changes with unchanged visible IDs, source/filter/sort/domain revision changes, disabled/help/theme changes, visible/hidden/conflicted inline editor and ordinary/multiline selection/preedit/focus: correct latest semantics and permissions; private text publication/settlement is not bypassed.
9. Malformed snapshots/deltas, duplicate IDs, absent/cyclic parent, geometry for foreign scope/generation, unexpected bounds and budgets: previous valid publication stays internally coherent; no partial mutation. Failure/empty-layout policy must explicitly resolve or retain read-only pending without blocking other controls.
10. Actual Cocoa external/in-process queries compare current cells and screen hit-test bounds, total counts, row/column indices, selected cells, focus and retirement; no preference changes or human VoiceOver claim.
11. Only after source-bound correctness gates, use the unchanged four stored-table workloads, same 400-cell/frozen clips, optimized build, balanced fresh-process A/B and retained outliers. Record publication/object/byte counts and full UI-work distribution alongside source timings; no extrapolated 2.4ms savings, no added nested costs, no full P6 claim.

Suggested ownership: one owner for accessibility.go/.m/.go protocol plus focused native tests; grid measurement owner for immutable per-scope completion metadata/provenance; independent reviewer tests old/stale/close/remount/scope transitions. Do not alter the procedural/stored workload or committed generic reconcile/update behavior in this phase.
