"""Reconcile exact prototype outputs, fault controls and scoped offscreen kernel measurements."""
from pathlib import Path
import hashlib,json,statistics
W=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes());inputs={}
def pinned(p):
 p=Path(p);inputs[str(p)]=sha(p);return read(p)
def terminal(run,code=0):
 assert run['exit_code']==code and run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
 for name,info in run['logs'].items():
  # Controller argv cwd is fixed; logs are verified at their explicit case root below.
  assert info['bytes']>=0 and len(info['sha256'])==64
def raw(root,run):
 for name,info in run['logs'].items():
  p=root/name;assert p.stat().st_size==info['bytes']and sha(p)==info['sha256'];inputs[str(p)]=sha(p)
 values=[]
 for line in(root/'stdout').read_bytes().splitlines():
  try:value=json.loads(line)
  except(ValueError,UnicodeDecodeError):continue
  if isinstance(value,dict):values.append(value)
 return values
p=Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v4');r=pinned(p/'receipt.json');assert r['result']=='PASS_OFFSCREEN_FULL_LAYOUT_COMPARISON'
arms={}
for item in r['commands']:
 terminal(item['run']);arms[item['case']]=raw(p/item['case'],item['run']);assert len(arms[item['case']])==70
assert [(x['dpi'],x['variable'],x['frame'])for x in arms['baseline']]==[(x['dpi'],x['variable'],x['frame'])for x in arms['candidate']]
assert all(all(a[k]==b[k]for k in['pixels_sha256','geometry_sha256','intrinsic_sha256'])for a,b in zip(arms['baseline'],arms['candidate']))
c=Path('/private/tmp/vellum-grid-intrinsic-controls-99b632b');r=pinned(c/'receipt.json');assert r['result']=='PASS_FINAL_CANDIDATE_RACE_AND_COUNTERFACTUAL_CONTROLS'and len(r['cases'])==4
for item in r['cases']:
 terminal(item['run'],0 if item['positive']else 1);records=raw(c/item['name'],item['run'])
 if item['positive']:
  assert len(records)==70
  assert all(all(a[k]==b[k]for k in['pixels_sha256','geometry_sha256','intrinsic_sha256'])for a,b in zip(arms['baseline'],records))
 else:assert item['expected_message']in(c/item['name']/'stdout').read_text()
v2=Path('/private/tmp/vellum-grid-intrinsic-controls-99b632b-v2');r=pinned(v2/'receipt.json');assert r['result']=='PASS_FINAL_CANDIDATE_RACE_AND_COUNTERFACTUAL_CONTROLS'and len(r['cases'])==2
for item in r['cases']:
 terminal(item['run'],0 if item['positive']else 1);raw(v2/item['name'],item['run'])
 if not item['positive']:assert item['expected_message']in(v2/item['name']/'stdout').read_text()
assert (W/'regression-v1.go.txt').read_text().split('func TestGridIntrinsicPendingLazyShapeIsResized')[0]==(W/'regression-v2.go.txt').read_text().split('func TestGridIntrinsicPendingLazyShapeIsResized')[0]
for name in['candidate-v2.go.txt','original.go.txt','regression-v1.go.txt','regression-v2.go.txt','design-review.json']:inputs[str(W/name)]=sha(W/name)
bench=Path('/private/tmp/vellum-grid-intrinsic-bench-99b632b');r=pinned(bench/'receipt.json');assert r['result']=='PASS_OFFSCREEN_SYNC_LAYOUT_KERNEL_EXPERIMENT'and len(r['cases'])==4
samples={}
for item in r['cases']:
 terminal(item['run']);records=raw(bench/item['name'],item['run']);assert len(records)==10
 assert{(x['variable'],x['repeat'])for x in records}=={(v,i)for v in[False,True]for i in range(5)}
 for x in records:
  assert x['event']=='grid.intrinsic.bench'and x['iterations']>0 and x['ns_per_op']>0
  samples.setdefault((item['arm'],x['variable']),[]).append(x)
summary=[]
for variable in[False,True]:
 metrics={}
 for arm in['baseline','candidate']:
  values=samples[arm,variable];assert len(values)==10;metrics[arm]={k:statistics.median(x[k]for x in values)for k in['ns_per_op','allocs_per_op','bytes_per_op']}
 summary.append(dict(variable=variable,observations_per_arm=10,**metrics,time_change_percent=100*(metrics['candidate']['ns_per_op']/metrics['baseline']['ns_per_op']-1)))
initial=pinned(Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v5/receipt.json'));assert initial['result']=='INCOMPLETE'and len(initial['commands'])==1 and initial['commands'][0]['run']['exit_code']==1
terminal(initial['commands'][0]['run'],1)
result=dict(result='RECONCILED_GUARDED_INTRINSIC_PROTOTYPE',source_base='99b632bff6594f42c87a84c3dc9b5452e97ba1be',baseline='Exact prior grid_retained.go compiler overlay on otherwise unchanged99b source; not a clean historical executable',source_adopted=False,native_runtime_executed=False,full_layout_frozen_prior_pairs=70,complete_public_geometry_and_private_intrinsic_rune_geometry_equal=True,dependent_style_cases=20,final_candidate_race_pass=True,source_fault_controls=3,pending_fault_asserts_actual_shaped_offset=True,final_pending_test_only_delta_pass=True,failed_initial_pending_fixture_preserved=True,kernel=summary,kernel_scope='Owner dispatch plus grid model scroll, bounded projection sync/predicate and local layout. No paint, capture, native event/frame, presentation, retained/native/GPU memory or complete host isolation qualification.',native_gain_qualified=False,performance_gates_qualified=False,adoption_ready=False,inputs=inputs)
with(W/'analysis.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='inputs'}))
