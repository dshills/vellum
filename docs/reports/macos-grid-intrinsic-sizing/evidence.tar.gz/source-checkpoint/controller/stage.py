"""Bind and stage only the four installed, successfully checked checkpoint leaves."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-grid-intrinsic-production-99b632b')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'binding.json').exists()
a=read(W/'adoption.json');r=read(P/'receipt.json');assert r['result']=='PASS_EXACT_INSTALLED_NON_NATIVE_CHECKS'and r['error']is None and not r['native_runtime_executed']and len(r['commands'])==5
assert all(x['run']['exit_code']==0 and x['run']['error']is None and x['run']['logs_complete']and x['run']['pins_stable']and x['run']['owned']['terminal']and x['run']['owned']['group_absent']and not x['run']['owned']['errors']and not x['run']['observation_errors']for x in r['commands'])
for n in ['source.json','prepared.json']:
 assert all(sha(p)==h for p,h in read(P/n).items())
assert git(T,'rev-parse','HEAD').decode().strip()==a['base_commit']==git(C,'rev-parse','HEAD').decode().strip()
assert not git(C,'status','--porcelain=v1','--untracked-files=all')and not git(T,'diff','--cached','--name-only')
expected=set(a['sources']);changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==expected
assert all(sha(T/p)==h for p,h in a['sources'].items())
git(T,'add','--',*sorted(expected))
assert not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')and set(git(T,'diff','--cached','--name-only').decode().splitlines())==expected
payload=git(T,'diff','--cached','--binary');assert 0<len(payload)<80000
(W/'staged.diff').write_bytes(payload)
d=dict(base_commit=a['base_commit'],sources=a['sources'],source_files=4683,prepared_files=6249,staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(payload),production_receipt_sha256=sha(P/'receipt.json'),native_runtime_executed=False)
with(W/'binding.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d),flush=True)
