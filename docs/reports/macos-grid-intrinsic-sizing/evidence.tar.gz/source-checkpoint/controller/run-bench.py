"""Four serial A/B/B/A offscreen kernel processes; no native frame or adoption claim."""
from pathlib import Path
import importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-grid-intrinsic-bench-99b632b')
spec=importlib.util.spec_from_file_location('intrinsic_bench_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=T,timeout=20)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,timeout=20).decode().strip()=='99b632bff6594f42c87a84c3dc9b5452e97ba1be'
P.mkdir(mode=0o700);leaves=[W/n for n in['original.go.txt','candidate-v2.go.txt','bench-v1.go.txt']]
for p in leaves:subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(p)],check=True,timeout=20)
names=subprocess.check_output(['git','ls-files','-z'],cwd=T,timeout=20).decode().split('\0')[:-1]
pins={str(T/n):g.sha(T/n)for n in names};pins.update({str(p):g.sha(p)for module in['upstream','typesetting']for p in(T/'drivers/cogent/build'/module).rglob('*')if p.is_file()})
for p in[*leaves,Path(__file__).resolve(),W.parent/'macos-sdk-native-238b3b6/run.py']:pins[str(p)]=g.sha(p)
(P/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(g.sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',native_runtime_executed=False,source_adopted=False,cases=[],error=None)
try:
 for i,case in enumerate(['baseline','candidate','candidate','baseline']):
  source=W/('original.go.txt'if case=='baseline'else'candidate-v2.go.txt');name=str(i)+'-'+case;overlay=P/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(T/'drivers/cogent/grid_retained.go'):str(source),str(T/'drivers/cogent/grid_glyph_placement_warm_offscreen_test.go'):str(W/'bench-v1.go.txt')}},indent=2)+'\n');pins[str(overlay)]=g.sha(overlay)
  args=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','test','-tags','offscreen','-overlay',str(overlay),'-count=1','-timeout=120s','-benchtime=200ms','-v','-run','^TestGridIntrinsicBench$','.']
  run=g.execute(args,T/'drivers/cogent',P/name,lambda:False,stable,timeout=180,limit=8<<20);d['cases'].append(dict(name=name,arm=case,run=run));print(json.dumps(dict(case=name,exit_code=run['exit_code'],seconds=run['seconds'],error=run['error'])),flush=True)
  assert run['exit_code']==0 and run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
 assert stable()and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=T,timeout=20)
 d['result']='PASS_OFFSCREEN_SYNC_LAYOUT_KERNEL_EXPERIMENT'
except BaseException as e:d.update(result='FAILED_KERNEL_EXPERIMENT',error=dict(type=type(e).__name__,message=str(e)));raise
finally:
 with(P/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
