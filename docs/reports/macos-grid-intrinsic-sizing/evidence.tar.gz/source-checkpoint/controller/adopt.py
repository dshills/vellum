"""Install only the internally approved candidate/test and two prose additions."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='99b632bff6594f42c87a84c3dc9b5452e97ba1be';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'adoption.json').exists()
r=json.loads((W/'adoption-review.json').read_bytes());assert r['adoption_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
assert all(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain','-z')for root in[T,C])
assert sha(T/'drivers/cogent/grid_retained.go')==sha(W/'original.go.txt')==sha(C/'drivers/cogent/grid_retained.go')
test=T/'drivers/cogent/grid_intrinsic_size_offscreen_test.go';assert not test.exists()
for source,dest in[(W/'candidate-v2.go.txt',T/'drivers/cogent/grid_retained.go'),(W/'adopt-test.go.txt',test)]:dest.write_bytes(source.read_bytes())
for addition,dest in[(W/'spec-addition.md.txt',T/'specs/grid-native.md'),(W/'implementation-addition.md.txt',T/'docs/implementation.md')]:dest.write_text(dest.read_text()+addition.read_text())
paths=['drivers/cogent/grid_retained.go','drivers/cogent/grid_intrinsic_size_offscreen_test.go','specs/grid-native.md','docs/implementation.md']
for p in paths[:2]:subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(T/p)],check=True,timeout=20)
assert sha(T/paths[0])==sha(W/'candidate-v2.go.txt')and sha(test)==sha(W/'adopt-test.go.txt')
assert set(git(T,'ls-files','--modified').decode().splitlines())==set(paths)-{paths[1]}and git(T,'ls-files','--others','--exclude-standard').decode().splitlines()==[paths[1]]
assert not git(C,'status','--porcelain','-z')and git(C,'rev-parse','HEAD').decode().strip()==HEAD
d=dict(result='INTERNALLY_APPROVED_SOURCE_INSTALLED_UNCOMMITTED',base_commit=HEAD,sources={p:sha(T/p)for p in paths},native_runtime_executed=False,source_files=4683,prepared_files=6249,review_sha256=sha(W/'adoption-review.json'))
with(W/'adoption.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
