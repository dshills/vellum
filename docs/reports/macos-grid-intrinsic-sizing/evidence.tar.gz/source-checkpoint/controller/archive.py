"""Preserve source, reviews and raw checks without executable build outputs."""
from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
commit=json.loads((W/'commit-receipt.json').read_bytes());assert commit['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED'and commit['both_clean']
out=W/('checkpoint-'+commit['commit'][:7]);assert not out.exists()
roots={'controller':W,'prototype-v1':Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v1'),'prototype-v2':Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v2'),'prototype-v3':Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v3'),'prototype-v4':Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v4'),'prototype-v5-failed':Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v5'),'prototype-v6':Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v6'),'controls':Path('/private/tmp/vellum-grid-intrinsic-controls-99b632b'),'controls-v2':Path('/private/tmp/vellum-grid-intrinsic-controls-99b632b-v2'),'kernel':Path('/private/tmp/vellum-grid-intrinsic-bench-99b632b'),'production':Path('/private/tmp/vellum-grid-intrinsic-production-99b632b')}
sources=[];excluded=[]
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(root)
  if any(part.startswith('checkpoint-')or part=='__pycache__'for part in relative.parts):continue
  assert not p.is_symlink()
  if p.name=='loadedgrid':excluded.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)));continue
  sources.append((p,Path(prefix)/relative))
b=json.loads((W/'binding.json').read_bytes())
for name,h in b['sources'].items():p=T/name;assert sha(p)==h;sources.append((p,Path('committed-source')/name))
out.mkdir(mode=0o700);manifest={};total=0
for source,relative in sources:
 before=sha(source);target=out/relative;target.parent.mkdir(parents=True,exist_ok=True)
 with source.open('rb')as inp,target.open('xb')as dest:shutil.copyfileobj(inp,dest)
 assert sha(source)==sha(target)==before
 n=target.stat().st_size;total+=n;manifest[relative.as_posix()]=dict(bytes=n,sha256=before)
d=dict(commit=commit['commit'],files=manifest,excluded_executables=excluded,total_files=len(manifest),total_bytes=total,native_runtime_executed=False)
with(out/'MANIFEST.json').open('x')as dest:dest.write(json.dumps(d,indent=2)+'\n')
receipt=dict(path=str(out),manifest_sha256=sha(out/'MANIFEST.json'),files=len(manifest),bytes=total,excluded_executables=excluded)
with(W/'checkpoint.json').open('x')as dest:dest.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
