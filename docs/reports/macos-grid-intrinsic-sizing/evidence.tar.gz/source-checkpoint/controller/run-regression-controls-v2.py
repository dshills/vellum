"""Final candidate race checks and three expected-failure counterfactual source overlays."""
from pathlib import Path
import importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-grid-intrinsic-controls-99b632b-v2')
spec=importlib.util.spec_from_file_location('intrinsic_control_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
P.mkdir(mode=0o700)
leaves=[W/n for n in['original.go.txt','candidate-v2.go.txt','regression-v2.go.txt','fault-font.go.txt','fault-pending.go.txt']]
for p in leaves:subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(p)],check=True,timeout=20)
names=subprocess.check_output(['git','ls-files','-z'],cwd=T,timeout=20).decode().split('\0')[:-1]
pins={str(T/n):g.sha(T/n)for n in names};pins.update({str(p):g.sha(p)for module in['upstream','typesetting']for p in(T/'drivers/cogent/build'/module).rglob('*')if p.is_file()})
for p in[*leaves,Path(__file__).resolve(),W.parent/'macos-sdk-native-238b3b6/run.py']:pins[str(p)]=g.sha(p)
(P/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(g.sha(p)==h for p,h in pins.items())
cases=[('candidate-pending','candidate-v2.go.txt','^TestGridIntrinsicPending',True,None),('lost-pending','fault-pending.go.txt','^TestGridIntrinsicPending',False,'lazy allocation shape survived the required intrinsic sizing pass')]
d=dict(result='INCOMPLETE',native_runtime_executed=False,source_adopted=False,cases=[],error=None)
try:
 for name,file,pattern,positive,message in cases:
  overlay=P/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(T/'drivers/cogent/grid_retained.go'):str(W/file),str(T/'drivers/cogent/grid_glyph_placement_warm_offscreen_test.go'):str(W/'regression-v2.go.txt')}},indent=2)+'\n');pins[str(overlay)]=g.sha(overlay)
  args=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','test','-tags','offscreen']+(['-race']if positive else[])+['-overlay',str(overlay),'-count=1','-timeout=120s','-v','-run',pattern,'.']
  run=g.execute(args,T/'drivers/cogent',P/name,lambda:False,stable,timeout=180,limit=8<<20);text=(P/name/'stdout').read_text();d['cases'].append(dict(name=name,positive=positive,expected_message=message,run=run))
  print(json.dumps(dict(case=name,exit_code=run['exit_code'],seconds=run['seconds'],error=run['error'])),flush=True)
  assert run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
  assert run['exit_code']==(0 if positive else 1)
  if not positive:assert message in text and '--- FAIL: TestGridIntrinsic'in text
 assert stable()and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=T,timeout=20)
 d['result']='PASS_FINAL_CANDIDATE_RACE_AND_COUNTERFACTUAL_CONTROLS'
except BaseException as e:d.update(result='FAILED_REGRESSION_OR_CONTROL',error=dict(type=type(e).__name__,message=str(e)));raise
finally:
 with(P/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
