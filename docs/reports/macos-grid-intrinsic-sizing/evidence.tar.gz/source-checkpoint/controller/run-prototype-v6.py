"""Compare exact prior and candidate grid sizing with independent full-layout software oracles."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-grid-intrinsic-size-99b632b-v6')
spec=importlib.util.spec_from_file_location('intrinsic_grid_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=T,timeout=20)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,timeout=20).decode().strip()=='99b632bff6594f42c87a84c3dc9b5452e97ba1be'
P.mkdir(mode=0o700)
for p in[W/'original.go.txt',W/'candidate-v2.go.txt',W/'prototype-test-v5.go.txt']:subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(p)],check=True,timeout=20)
names=subprocess.check_output(['git','ls-files','-z'],cwd=T,timeout=20).decode().split('\0')[:-1]
pins={str(T/n):g.sha(T/n)for n in names};pins.update({str(p):g.sha(p)for module in['upstream','typesetting']for p in(T/'drivers/cogent/build'/module).rglob('*')if p.is_file()})
for p in[Path(__file__).resolve(),W/'original.go.txt',W/'candidate-v2.go.txt',W/'prototype-test-v5.go.txt',W.parent/'macos-sdk-native-238b3b6/run.py']:pins[str(p)]=g.sha(p)
(P/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(g.sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',native_runtime_executed=False,source_adopted=False,commands=[])
try:
 for case,source in[('baseline',W/'original.go.txt'),('candidate',W/'candidate-v2.go.txt')]:
  overlay=P/(case+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(T/'drivers/cogent/grid_retained.go'):str(source),str(T/'drivers/cogent/grid_glyph_placement_warm_offscreen_test.go'):str(W/'prototype-test-v5.go.txt')}},indent=2)+'\n');pins[str(overlay)]=g.sha(overlay)
  run=g.execute(['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','test','-tags','offscreen','-overlay',str(overlay),'-count=1','-timeout=120s','-v','-run','^TestGridIntrinsicPending','.'],T/'drivers/cogent',P/case,lambda:False,stable,timeout=180,limit=8<<20);d['commands'].append(dict(case=case,run=run));print(json.dumps(dict(case=case,exit_code=run['exit_code'],error=run['error'],seconds=run['seconds'])),flush=True)
  assert run['exit_code']==0 and run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
 assert stable()and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=T,timeout=20)
 d['result']='PASS_OFFSCREEN_FULL_LAYOUT_COMPARISON'
except BaseException as e:
 d.update(result='FAILED_OFFSCREEN_COMPARISON',error=dict(type=type(e).__name__,message=str(e)));raise
finally:
 with(P/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
