"""Package internally reconciled source/native evidence; no runtime source edits."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;N=W.parent/'macos-grid-intrinsic-native';S=W.parent/'macos-grid-intrinsic-size/checkpoint-599442a';P=Path('/private/tmp/vellum-grid-intrinsic-native-599442a');T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'docs/reports/macos-grid-intrinsic-sizing'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']and r['report_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'accepted results and producer')
a=read(N/'analysis.json');d=read(P/'native-receipt.json');b=read(P/'build-receipt.json');need(a['result']=='RECONCILED_NATIVE_GRID_INTRINSIC_COMPARISON'and d['result']=='PASS_NATIVE_GRID_INTRINSIC_COMPARISON'and(P/'stop-live').is_file(),'sealed native evidence')
members={}
def add(label,root,exclude=()):
 need(root.is_dir(),'existing evidence root')
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'evidence symlink')
  if p.is_file()and'__pycache__'not in p.parts and not any(x in p.relative_to(root).parts for x in exclude):members[label+p.relative_to(root).as_posix()]=p
add('native-controller/',N);add('native-checks/',P,exclude=('bin',));add('source-checkpoint/',S)
for name in['result-review.json','report.py','README.template.md','interpretation.md.txt','status-addition.md.txt']:members['report-producer/'+name]=W/name
for name in['child_process.py','sdk_environment.py','benchmark-grid.py']:members['helpers/'+name]=T/'scripts'/name
members['helpers/owned-runner.py']=W.parent/'macos-sdk-native-238b3b6/run.py';members['helpers/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py');members['helpers/prism-retirement.py']=Path('/private/tmp/vellum-native-attestation-probe-20261016/run-verifier.py')
for name in['drivers/cogent/grid.go','drivers/cogent/grid_retained.go','drivers/cogent/frame_metrics.go','drivers/cogent/driver.go','examples/loadedgrid/main.go','examples/loadedgrid/perf.go','examples/loadedgrid/perf_runtime.go','examples/loadedgrid/perf_profile.go','examples/loadedgrid/accessibility_smoke.go']:members['runtime-source/'+name]=T/name
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<600 and expanded<96<<20,'bounded evidence');need(not D.exists(),'fresh report destination')
rows=[]
for g in a['groups']:
 old,new=g['arms']['baseline'],g['arms']['candidate'];rows.append(f"| {g['group']} | {old['median_process_p95_ns']/1e6:.3f} | {new['median_process_p95_ns']/1e6:.3f} | {g['candidate_p95_lower_pairs']}/5 | {new['p95_target_passes']}/5 | {new['p99_target_passes']}/5 |")
interpretation=(W/'interpretation.md.txt').read_text();need(interpretation.strip(),'explicit reviewed interpretation')
binaries={c['case']:c['binary']for c in b['cases']};source=read(P/'source.json');native=next(c['native_window']for c in a['cases']if'native_window'in c)
provenance=(f"Fresh builds use clean source `{a['source_commit']}` with {len(source['files']):,} tracked and {len(source['prepared']):,} prepared files, unchanged and equal in both checkouts. The baseline is a compiler overlay restoring only the exact `99b632b` grid sizing file, with all other current source unchanged; it is not a clean historical build. Both metadata records identify the current commit, and the overlay has its own complete source vector and argv.\n\nBaseline executable SHA256 is `{binaries['baseline']['sha256']}`; candidate is `{binaries['candidate']['sha256']}`. The earlier uncommitted compile is separately identified in the source checkpoint and is not used here. All 43 native processes exit zero, complete their logs and have their owned groups observed absent. The campaign is sealed. Native endpoint data is retained in structured results.")
text=(W/'README.template.md').read_text()
for token,replacement in [('@@NATIVE_PROVENANCE@@',provenance),('@@TABLE@@','\n'.join(rows)),('@@INTERPRETATION@@',interpretation.strip())]:need(text.count(token)==1,'one template token');text=text.replace(token,replacement)
need('@@'not in text,'resolved template');D.mkdir()
manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},count=len(members),expanded_bytes=expanded,excluded_native_executables=binaries)
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,p in members.items():
    data=p.read_bytes();need(hashlib.sha256(data).hexdigest()==manifest['files'][n]['sha256'],'archive input drift');entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive member integrity')
result=dict(status='REVIEWED_GRID_INTRINSIC_SOURCE_AND_NATIVE_COMPARISON',source_commit=a['source_commit'],source_checkpoint_commit=read(S/'controller/commit-receipt.json'),native=d,analysis=a,build=b,result_review_sha256=sha(W/'result-review.json'),evidence=dict(sha256=sha(D/'evidence.tar.gz'),bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded),source_checkpoint_provider_calls=1,evidence_phase_provider_calls=0,production_source_changed_in_evidence_phase=False,physical_input_verified=False,native_gpu_execution_verified=False,native_memory_qualified=False,broad_no_regression_qualified=False,full_macos_qualified=False,public_distribution=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');(D/'README.md').write_text(text)
addition=(W/'status-addition.md.txt').read_text();need('@@REPORT_LINK@@'in addition,'status link token')
for name in['docs/implementation.md','specs/macos-completion.md']:
 p=T/name;link='reports/macos-grid-intrinsic-sizing/README.md'if name.startswith('docs/')else'../docs/reports/macos-grid-intrinsic-sizing/README.md';p.write_text(p.read_text()+addition.replace('@@REPORT_LINK@@',link))
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Grid intrinsic sizing and native comparison](macos-grid-intrinsic-sizing/README.md): guarded source reuse, mixed-text geometry oracles and separately reviewed matched native frame evidence.\n')
print(json.dumps(dict(result='GRID_INTRINSIC_REPORT_GENERATED',files=7,members=len(members),expanded_bytes=expanded,archive_bytes=(D/'evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'evidence.tar.gz'))))
