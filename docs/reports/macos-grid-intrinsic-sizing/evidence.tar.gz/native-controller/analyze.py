"""Independently reconcile all native raw cases and keep target failures explicit."""
from pathlib import Path
import datetime,hashlib,json,statistics,sys
sys.dont_write_bytecode=True
import run as m
read=m.read;sha=m.sha;need=m.need
receipt=read(m.P/'native-receipt.json');build=read(m.P/'build-receipt.json');source=read(m.P/'source.json');review=read(m.W/'readiness.json')
need(receipt['result']=='PASS_NATIVE_GRID_INTRINSIC_COMPARISON'and receipt['error']is None and not receipt['finalization_errors'],'complete terminal campaign')
need((m.P/'stop-live').is_file()and m.identity(m.T)==m.identity(m.C)==source,'sealed clean source/prepared parity')
need(all(sha(p)==h for p,h in review['inputs'].items()),'all reviewed inputs stable')
need(build['result']=='PASS_MATCHED_NATIVE_COMPILE_ONLY'and build['error']is None,'matched builds')
inputs={str(p):sha(p)for p in[m.P/'native-receipt.json',m.P/'build-receipt.json',m.P/'source.json',m.P/'baseline-source.json',m.W/'readiness.json',m.W/'analyze.py']}
for c in build['cases']:
 need(sha(c['binary']['path'])==c['binary']['sha256'],'native executable identity')
 for cmd in c['commands']:m.terminal(cmd['run']);m.g.absent(cmd['run']['pid'])
plan=m.plan_cases();need(len(receipt['cases'])==len(plan)==43,'exact case count');cases=[];pending={};pairs=[];endpoints={}
for expected,item in zip(plan,receipt['cases']):
 need(item['case']==expected and item['error']is None,'fixed planned case');run=item['run'];m.terminal(run);m.g.absent(run['pid']);root=m.P/'runs'/expected['label']
 for name in['stdout','stderr']:
  p=root/name;need(dict(bytes=p.stat().st_size,sha256=sha(p))==run['logs'][name],'raw log identity');inputs[str(p)]=sha(p)
 need(read(root/'receipt.json')==item,'exclusive case receipt parity');inputs[str(root/'receipt.json')]=sha(root/'receipt.json');inputs[str(root/'owned.json')]=sha(root/'owned.json')
 raw=[json.loads(x)for x in(root/'stdout').read_bytes().splitlines()]
 if expected['kind']=='ax':
  validation=m.validate_ax(raw);need(validation==item['validation'],'AX evidence parity');cases.append(dict(case=expected,validation=validation));continue
 samples=m.perf_records(raw,variable=expected['variable'],gpu=expected['gpu'],allocated=expected['kind']=='allocation',samples=expected['samples']);native=raw[1]['native_window']
 need(m.benchmark.summarize([samples])==item['validation']['timings_ns'],'raw timing summary parity');need(item['validation']['completed_callbacks']==raw[-1]['callbacks']==expected['samples'],'callback completion')
 phases={key:m.benchmark.distribution([s['metrics'][key]for s in samples])for key in m.benchmark.WORK_PHASES};metric=m.benchmark.distribution([s['metrics']['ui_work_ns']for s in samples]);record=dict(case=expected,samples=len(samples),native_window=native,ui_work_ns=metric,phases_ns=phases)
 if expected['kind']=='ordinary':
  record.update(p95_target_pass=metric['p95']<=4_000_000,p99_target_pass=metric['p99']<=6_000_000);group=expected['group'];need(group not in endpoints or endpoints[group]==native,'group endpoints unchanged');endpoints[group]=native
 else:
  profiles=m.profile_files(m.P,expected['flavor']);need(profiles==item['validation']['profile_files'],'bounded profile identities');record['profiles']=profiles
  for v in profiles.values():inputs[v['path']]=v['sha256']
 cases.append(record);key=expected['pair']
 if key in pending:
  previous,previous_samples,previous_native=pending.pop(key);match=m.match_pair(previous_samples,samples,previous_native,native);baseline=previous if previous['case']['flavor']=='baseline'else record;candidate=record if record['case']['flavor']=='candidate'else previous
  pairs.append(dict(pair=key,cases=[previous['case']['label'],expected['label']],**match,kind=expected['kind'],group=expected.get('group'),baseline_ui_work_ns=baseline['ui_work_ns'],candidate_ui_work_ns=candidate['ui_work_ns'],p95_change_percent=100*(candidate['ui_work_ns']['p95']/baseline['ui_work_ns']['p95']-1),p99_change_percent=100*(candidate['ui_work_ns']['p99']/baseline['ui_work_ns']['p99']-1)))
 else:pending[key]=(record,samples,native)
need(not pending and len(pairs)==21,'all21fullgeometrypairs');need([{k:p[k]for k in['pair','cases','pairs','full_geometry_sha256','native_window']}for p in pairs]==receipt['pairs'],'reconstructed pair receipt')
groups=[]
for group in['cpu-fixed','cpu-variable','gpu-fixed','gpu-variable']:
 paired=[p for p in pairs if p['group']==group];need(len(paired)==5,'five ordinary comparisons');arms={}
 for flavor in['baseline','candidate']:
  items=[c for c in cases if c['case'].get('group')==group and c['case']['flavor']==flavor];need(len(items)==5,'five processes each arm')
  arms[flavor]=dict(processes=5,samples=600,median_process_p95_ns=statistics.median(x['ui_work_ns']['p95']for x in items),median_process_p99_ns=statistics.median(x['ui_work_ns']['p99']for x in items),p95_target_passes=sum(x['p95_target_pass']for x in items),p99_target_passes=sum(x['p99_target_pass']for x in items))
 groups.append(dict(group=group,arms=arms,median_paired_p95_change_percent=statistics.median(x['p95_change_percent']for x in paired),median_paired_p99_change_percent=statistics.median(x['p99_change_percent']for x in paired),candidate_p95_lower_pairs=sum(x['p95_change_percent']<0 for x in paired)))
d=dict(schema=1,result='RECONCILED_NATIVE_GRID_INTRINSIC_COMPARISON',source_commit=m.HEAD,source_files=len(source['files']),prepared_files=len(source['prepared']),baseline=read(m.P/'baseline-source.json')['scope'],inputs=inputs,cases=cases,pairs=pairs,groups=groups,ordinary_processes=40,ordinary_samples=4800,ordinary_geometry_pairs=2400,allocation_processes=2,allocation_samples=1024,allocation_geometry_pairs=512,all_source_and_prepared_pins_stable=True,all_owned_children_terminal_and_groups_absent=True,physical_input_verified=False,native_gpu_execution_verified=False,native_memory_qualified=False,broad_no_regression_qualified=False,full_macos_qualified=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with(m.W/'analysis.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items()if k not in['inputs','cases','pairs']}))
