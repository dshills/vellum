"""One scoped Cocoa acceptance, two allocation diagnostics and forty ordinary processes."""
from pathlib import Path
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *

def fresh(root):
 need(not(root/'native-receipt.json').exists()and not(root/'runs').exists()and not(root/'stop-live').exists(),'fresh unsealed native campaign')
 need(not(root/'profiles').exists()or not any((root/'profiles').iterdir()),'new empty profile destinations')
def finalize(root,d):
 d['finalization_errors']=[];d['local_stop_present']=False
 try:(root/'stop-live').touch();d['local_stop_present']=True
 except BaseException as e:d['finalization_errors'].append(dict(stage='seal-stop',type=type(e).__name__,message=str(e)))
 d['result']='PASS_NATIVE_GRID_INTRINSIC_COMPARISON'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_NATIVE_GRID_INTRINSIC_COMPARISON'
 try:
  with(root/'native-receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 except BaseException as e:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(e).__name__,message=str(e)));d['result']='FAILED_OR_CANCELED_NATIVE_GRID_INTRINSIC_COMPARISON'
 return d

def validate_ax(records):
 need(len(records)==2 and [x.get('event')for x in records]==['grid.accessibility.pass','grid.accessibility.closed'],'exact AX stages')
 a,c=records;need(type(a.get('rows'))is int and a['rows']==1000000 and type(a.get('visible_minimum'))is int and a['visible_minimum']==400,'AX stored case')
 need(all(type(a.get(k))is int and a[k]>=400 for k in['overlap_objects_reused','replacement_objects_retired'])and a.get('native_press_admitted')is True,'AX identity/action evidence')
 need(c.get('attachment_query_refused')is True and c.get('geometry_persistence_disabled_in_fixture')is True,'AX closed attachment and no geometry persistence')
 return dict(rows=1000000,visible_minimum=400,overlap_objects_reused=a['overlap_objects_reused'],replacement_objects_retired=a['replacement_objects_retired'],native_press_admitted=True,attachment_query_refused=True,physical_input_verified=False,human_accessibility_verified=False)

def perf_records(records,*,variable,gpu,allocated,samples):
 result=benchmark.validate_records(records,1000000,variable,samples,False,allow_alloc_profile=allocated,gpu_scene_rendering=gpu)
 need(records[0].get('alloc_profile',False)is allocated and records[0].get('cpu_profile',False)is False and records[0].get('source_details',False)is False and records[0].get('input_details',False)is False,'exact allowed diagnostic flags')
 need(records[1].get('warmup')==128 and records[1].get('warm_callbacks')==128 and records[0].get('window_geometry_guard')==1 and records[0].get('warmup_guard')==1,'current geometry and warmup guards')
 return result

def match_pair(a,b,na,nb):
 benchmark.compare_geometry(a,b);need(na==nb and all(x['geometry']==y['geometry']for x,y in zip(a,b)),'all paired geometry and native endpoints equal')
 return dict(pairs=len(a),full_geometry_sha256=hashlib.sha256(json.dumps([s['geometry']for s in a],sort_keys=True,separators=(',',':')).encode()).hexdigest(),native_window=na)

def profile_files(root,flavor):
 result={}
 for suffix in['before','after']:
  p=root/'profiles'/(flavor+'.'+suffix+'.pprof');need(p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=64<<20,'bounded exclusive profile')
  with p.open('rb')as f:need(f.read(2)==b'\x1f\x8b','gzip profile')
  result[suffix]=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
 return result

def plan_cases():
 result=[dict(label='candidate-ax',flavor='candidate',kind='ax',argv=['-accessibility-smoke','-rows=1000000'])]
 for flavor in['baseline','candidate']:
  result.append(dict(label=flavor+'-allocation',flavor=flavor,kind='allocation',variable=False,gpu=True,samples=512,pair='allocation',argv=['-perf','-rows=1000000','-gpu-scene','-perf-samples=512','-perf-warmup=128','-perf-alloc-profile='+str(P/'profiles'/flavor)]))
 for gpu in[False,True]:
  for variable in[False,True]:
   group=('gpu'if gpu else'cpu')+('-variable'if variable else'-fixed')
   for repeat in range(1,6):
    for flavor in(['baseline','candidate']if repeat%2 else['candidate','baseline']):
     argv=['-perf','-rows=1000000','-perf-samples=120','-perf-warmup=128']+(['-gpu-scene']if gpu else[])+(['-variable-rows']if variable else[])
     result.append(dict(label=f'{group}-r{repeat}-{flavor}',flavor=flavor,kind='ordinary',variable=variable,gpu=gpu,samples=120,group=group,repeat=repeat,pair=f'{group}-r{repeat}',argv=argv))
 need(len(result)==43,'fixed bounded plan');return result

def main():
 fresh(P);review=read(W/'readiness.json');need(review['execution_ready']is True and not review['unresolved_findings'],'native readiness review');pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(P/'stop-live').exists();need(stable()and not stopping(),'initial admission')
 build=read(P/'build-receipt.json');need(build['result']=='PASS_MATCHED_NATIVE_COMPILE_ONLY','matched terminal builds');binaries={x['case']:x['binary']for x in build['cases']};source=read(P/'source.json');d=dict(result='INCOMPLETE',source_commit=HEAD,producer_sha256=sha(__file__),review_sha256=sha(W/'readiness.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False,physical_input_generated=False,settings_changes=False,native_gpu_execution_verified=False,native_memory_qualified=False,full_macos_qualified=False,error=None,cases=[],pairs=[])
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping()and identity(T)==identity(C)==source,'lease/source admission');(P/'runs').mkdir();pending={};previous=None;endpoints={}
   for case in plan_cases():
    need(lease.held()and stable()and not stopping(),'case admission')
    if previous is not None:g.absent(previous)
    if case['kind']=='allocation':need(all(not(P/'profiles'/(case['flavor']+'.'+s+'.pprof')).exists()for s in['before','after']),'new profile destinations')
    binary=binaries[case['flavor']];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'fixed binary')
    out=P/'runs'/case['label'];run=g.execute([binary['path'],*case['argv']],T/'examples/loadedgrid',out,stopping,stable,timeout=180,limit=8<<20);record=dict(case=case,run=run,error=None);d['cases'].append(record);d['native_runtime_executed']=d['native_runtime_executed']or run['created']
    try:
     terminal(run);previous=run['pid'];records=[json.loads(x)for x in(out/'stdout').read_bytes().splitlines()]
     if case['kind']=='ax':record['validation']=validate_ax(records)
     else:
      samples=perf_records(records,variable=case['variable'],gpu=case['gpu'],allocated=case['kind']=='allocation',samples=case['samples']);native=records[1]['native_window'];record['validation']=dict(samples=len(samples),completed_callbacks=records[-1]['callbacks'],native_window=native,timings_ns=benchmark.summarize([samples]),ordinary_case=case['kind']=='ordinary',profile_files=profile_files(P,case['flavor'])if case['kind']=='allocation'else{})
      key=case['pair']
      if key in pending:
       old,oldnative,oldlabel=pending.pop(key);paired=match_pair(old,samples,oldnative,native);d['pairs'].append(dict(pair=key,cases=[oldlabel,case['label']],**paired))
      else:pending[key]=(samples,native,case['label'])
      if case['kind']=='ordinary':
       group=case['group'];need(group not in endpoints or endpoints[group]==native,'same group native endpoints throughout');endpoints[group]=native
    except BaseException as e:record['error']=dict(type=type(e).__name__,message=str(e));raise
    finally:
     with(out/'receipt.json').open('x')as f:f.write(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(case=case['label'],result='COMPLETED',seconds=run['seconds'])),flush=True)
   need(len(d['cases'])==43 and len(d['pairs'])==21 and not pending,'all fixed cases and pairs');need(identity(T)==identity(C)==source and stable()and not stopping(),'final source/pin admission');d.update(source_stable=True,prepared_stable=True,pins_stable=True,lease_held_through_cleanup=lease.held(),ordinary_processes=40,ordinary_samples=4800,ordinary_full_geometry_pairs=2400,allocation_processes=2,allocation_samples=1024,allocation_full_geometry_pairs=512)
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 finally:finalize(P,d);print(json.dumps({k:v for k,v in d.items()if k not in['cases','pairs']}),flush=True)
 need(d['error']is None and not d['finalization_errors'],'native comparison failed or canceled')
if __name__=='__main__':main()
