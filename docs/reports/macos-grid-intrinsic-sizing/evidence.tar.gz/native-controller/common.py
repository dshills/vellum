from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');COMMIT_RECEIPT=W.parent/'macos-grid-intrinsic-size/commit-receipt.json';_commit=json.loads(COMMIT_RECEIPT.read_bytes());assert _commit['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED'and _commit['both_clean'];HEAD=_commit['commit'];P=Path('/private/tmp/vellum-grid-intrinsic-native-'+HEAD[:7]);STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live');FIELD='drivers/cogent/grid_retained.go'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
guard_path=W.parent/'macos-sdk-native-238b3b6/run.py';need(sha(guard_path)=='e76238012be63f58cbc5923e27f6fc227a3aca8443d85d64f466c0675382c7ac','immutable reviewed owned child helper');g=module('grid_intrinsic_native_owned_guard',guard_path);benchmark=module('grid_intrinsic_native_validator',T/'scripts/benchmark-grid.py')
from child_process import run_child

def identity(root):
 def git(*args):return run_child(['git',*args],cwd=root,capture_output=True,check=True,timeout=20).stdout
 need(git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-z'),'clean exact source');files={};prepared={}
 for n in git('ls-files','-z').decode().split('\0')[:-1]:
  p=root/n;need(p.is_file()and not p.is_symlink(),'tracked regular file');files[n]=sha(p)
 for name in['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/name).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 need(len(files)==4683 and len(prepared)==6249,'source counts');return dict(commit=HEAD,files=files,prepared=prepared)

def terminal(run):
 need(run['created']and run['error']is None and not run['observation_errors']and run['exit_code']==0 and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit'],'successful terminal owned child')
