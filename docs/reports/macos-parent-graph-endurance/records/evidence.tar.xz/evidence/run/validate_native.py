"""Read-only raw-result checks for the five post-loop native smoke cases."""
from pathlib import Path
import hashlib, importlib.util, json, math, sys
P=Path(__file__).resolve().parent
S=Path('/private/tmp/vellum-macos-soak-cover')
E=Path('/private/tmp/vellum-macos-composed-endurance')
from cases import CASES,ORDER
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(f):return json.loads(Path(f).read_text())
def need(value,message):
 if not value:raise ValueError(message)
def finite(value):return type(value)in[int,float]and math.isfinite(value)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def queue_payload(payload,case):
 mode=case.removeprefix('queue-');counts={'normal':100,'panic':1,'idle':3,'stop':0}
 expected={'case':mode,'callbacks_started':counts[mode],'wake_requests':11000 if mode in ['normal','panic']else 1000,'queue_stopped':True,'native_creation_refused':True,'panic_identity_preserved':mode=='panic'}
 need(payload==expected and all(type(payload[k])is int for k in ['callbacks_started','wake_requests'])and all(type(payload[k])is bool for k in ['queue_stopped','native_creation_refused','panic_identity_preserved']),'native queue completion payload')
 return {'callbacks_started':counts[mode],'wake_requests':expected['wake_requests'],'panic_identity_preserved':expected['panic_identity_preserved'],'delayed_dispatch_qualified':mode=='idle','worker_only_stop_qualified':mode=='stop','measured_idle_cpu_gain_qualified':False}

def composed_payload(events,v,terminal,case="window-five"):
 cfg=CASES[case];count=cfg["cycles"];sample_at=[0]+list(range(cfg["every"],count+1,cfg["every"]))
 if sample_at[-1]!=count:sample_at.append(count)
 allowed=['vellum.native-action','vellum.composed-cycle','vellum.window-cycle.sample','vellum.window-cycle.result']
 need(all(type(e)is dict and e.get('event')in allowed for e in events),'composed event type')
 cycles=[e for e in events if e['event']=='vellum.composed-cycle'];partials=[e for e in events if e['event']=='vellum.native-action'];results=[e for e in events if e['event']=='vellum.window-cycle.result'];samples=[e['sample']for e in events if e['event']=='vellum.window-cycle.sample']
 need(len(cycles)==count and len(partials)==count*33 and len(results)==1 and len(samples)==len(sample_at),'configured window event counts')
 need([c['cycle']for c in cycles]==list(range(1,count+1)),'cycle sequence')
 expected_order=['vellum.window-cycle.sample']
 for cycle in range(1,count+1):
  expected_order.extend(['vellum.native-action']*33+['vellum.composed-cycle'])
  if cycle in sample_at:expected_order.append('vellum.window-cycle.sample')
 expected_order.append('vellum.window-cycle.result')
 need([e['event']for e in events]==expected_order,'ordered action/cycle/sample events')
 for index,c in enumerate(cycles):
  need(c['native_action_plan']==2,'action plan version')
  need(all(c[k]is True for k in ['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible','native_list_rejected','native_breadcrumb_rejected','native_breadcrumb_truncated']),'composed owner publication predicates')
  need(c['native_list_requests']==3 and c['native_canvas_selections']==2 and c['native_color_edits']==2 and c['native_breadcrumb_requests']==2 and c['native_tree_disclosures']==2 and c['tree_accessibility_rows']>0,'control completion counts')
  need(c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and c['full_p11_qualified']is False and v.rect(c['root_screen_points'])and v.rect(c['density_clip_screen_points']),'dense workload/geometry')
  actions=c['native_actions'];need([(a['Target'],a['Kind'],a['Value'])for a in actions]==v.PLAN,'exact 33-action plan')
  pp=partials[index*33:(index+1)*33];need([p['action']for p in pp]==actions and all(p['window']==f'native-cycle-{index:04d}'for p in pp),'partial/full action consistency')
  for a in actions:
   need(type(a['Attempts'])is int and type(a['Admissions'])is int and 1<=a['Admissions']<=a['Attempts'],'admission counts')
   need(a['OwnerAndNativeCompleted']is True and type(a['NativeRole'])is str and a['NativeRole']and 'AttachmentRetirement'not in a and 'FailureContext'not in a and finite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5.25,'native completion/action wall guard')
  for j,role in [(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton'),(27,'AXList'),(28,'AXList'),(29,'AXList'),(30,'AXButton'),(31,'AXButton')]:need(actions[j]['NativeRole']==role,'required native role')
 result=results[0];need(events[-1]is result and result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['requested_cycles']==result['completed_cycles']==count and result['native_action_plan']==2,'terminal composed result')
 need(result['composed_workspace']is True and result['dense_labels_per_composed_window']==1000 and result['cooperative_timeout_seconds']==cfg['timeout_seconds'] and result['heap_profile_requested']is bool(cfg['heap_profile']),'terminal workload')
 need(all(result[k]is False for k in ['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed']),'scope flags')
 need(all(result[k]is True for k in ['samples_after_forced_gc','geometry_persistence_disabled_in_fixture','historical_id_tombstones_retained']),'sample scope')
 need(samples==result['samples']and [s['Completed']for s in samples]==sample_at,'sample sequence')
 need(result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20,'memory safety guards')
 for s in samples:need(all(type(s[k])is int and s[k]>0 for k in ['HeapAlloc','RSSBytes','Goroutines'])and s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 and finite(s['ElapsedSeconds'])and s['ElapsedSeconds']>0,'sample values')
 need(all(a['ElapsedSeconds']<=b['ElapsedSeconds']for a,b in zip(samples,samples[1:])),'sample time ordering')
 terminal(result['native_cleanup'])
 return {'cycles':count,'actions':count*33,'steps_per_cycle':33,'total_attempts':sum(a['Attempts']for c in cycles for a in c['native_actions']),'total_admissions':sum(a['Admissions']for c in cycles for a in c['native_actions']),'native_cleanup':result['native_cleanup'],'hidden_inactive_untitled_native_windows':len(result['native_cleanup']['Windows']),'zero_cocoa_windows_qualified':False,'menu_restoration_qualified':False,'sampled_go_heap_bytes':[min(s['HeapAlloc']for s in samples),max(s['HeapAlloc']for s in samples)],'sampled_rss_bytes':[min(s['RSSBytes']for s in samples),max(s['RSSBytes']for s in samples)],'queue_admissions_are_not_accepted_callbacks':True,'retry_cause_observed':False}

def validate_predecessor(c,prior):
 if c.get('predecessor_scheduling_policy')=='recorded_failed_retired_for_independent_checks':
  for name,key in [('validate_retired_failure.py','retired_failure_validator_sha256'),('retired-failure-inputs.json','retired_failure_inputs_sha256'),('retired-soak-failure.json','retired_failure_proof_sha256'),('retired-failure-review.json','retired_failure_review_sha256')]:need(sha(P/name)==c[key],'known-failure policy binding '+name)
  approval=read(P/'retired-failure-review.json');need(approval['execution_ready_for_scheduling_proof']is True and approval['unresolved_findings']==[],'approved scheduling proof')
  validator=module('native_failed_retirement',P/'validate_retired_failure.py');saved=read(P/'retired-soak-failure.json');need(validator.validate()==saved,'raw known-failure proof')
  need(saved['result']=='VALIDATED_FAILED_RETIRED_SOAK'and all(saved[k]is False for k in ['full_overnight_qualified','full_idle_budget_qualified','full_mac_qualified']),'scheduling-only failure')
  expected={'result':'FAILED_RETIRED_PREDECESSOR','validation_sha256':sha(P/'retired-soak-failure.json'),'run_receipt_sha256':saved['run_receipt_sha256'],'sampled_idle_cpu_target_met':False,'full_idle_budget_qualified':False,'original_overnight_qualified':False}
  need({k:v for k,v in prior.items()if k!='fresh_group_absence'}==expected and prior['fresh_group_absence']['observed_group']==15600 and prior['fresh_group_absence']['members']==[],'known-failure predecessor admission')
  return saved
 need(c.get('predecessor_scheduling_policy')in[None,'completed_soak_only'],'unsupported predecessor policy')
 need(sha(S/'inputs.json')==c['predecessor_inputs_sha256']and sha(S/'validate_soak.py')==c['predecessor_validator_sha256'],'predecessor producer pins')
 soak=module('post_loop_pure_soak',S/'validate_soak.py');saved=read(S/'soak-overnight-validation.json')
 need(soak.validate('soak-overnight','overnight')==saved and saved['result']=='COMPLETE_OVERNIGHT_PHASE_TRACE','complete raw predecessor')
 need(prior['validation_sha256']==sha(S/'soak-overnight-validation.json')and prior['run_receipt_sha256']==sha(S/'soak-overnight.json')and prior['sampled_idle_cpu_target_met']==saved['sampled_idle_cpu_target_met']and prior['full_idle_budget_qualified']is False and prior['fresh_group_absence']['members']==[],'completed predecessor scope/binding')
 return saved

def validate(case):
 need(case in ORDER,'case');r=read(P/(case+'.json'));owned=read(P/(case+'-owned-process.json'));c=read(P/'native-configuration.json');manifest=read(P/'binaries.json');review=read(P/'native-review.json')
 need(review['execution_ready']is True and review['unresolved_findings']==[]and all(sha(P/n)==h for n,h in review['sources'].items()),'reviewed native harness')
 need(r['schema']=='vellum-post-loop-native-run-v1'and r['result']=='TERMINAL_NATIVE_CASE_OK'and r['case']==case,'terminal receipt')
 need(r['exit_code']==0 and r['error']is None and r['stop_reason']is None and r['cleanup_errors']==[]and r['stop_markers_at_exit']==[],'terminal errors')
 need(all(r[k]is True for k in ['direct_child_terminal','group_absence_confirmed','source_stable','artifacts_stable','logs_complete','native_application_executed']),'terminal observations')
 need(type(r['pid'])is int and r['pid']>0 and r['pid']==r['process_group']==owned['pid']==owned['process_group'],'owned group identity')
 need(r['native_lease']=={'path':'/private/tmp/vellum-macos-live-oct15.lock','acquired':True,'held_through_cleanup':True},'shared live lease')
 need(r['source_commit']==manifest['source_commit']==manifest['source_identity']['commit']==c['source_commit']=='6330b2d42050b46c2019e558074e087ed281e56a','current source endpoint')
 need(len(manifest['source_identity']['tracked'])==4490 and len(manifest['source_identity']['prepared'])==6229,'complete recorded source vectors')
 for key,name in [('producer_sha256','run_native.py'),('review_sha256','native-review.json'),('configuration_sha256','native-configuration.json'),('binaries_manifest_sha256','binaries.json')]:need(r[key]==owned[key]==sha(P/name),'run binding '+name)
 need(r['pins']==owned['pins']and set(r['pins'])==set(review['sources'])|{'native-review.json','native-configuration.json','binaries.json','window'+'.json','window'+'-go-version.txt','live-authorization.json'},'required input pins')
 need(all(sha(P/n)==h for n,h in r['pins'].items()),'stable pinned artifacts')
 for name,key in [('binaries.json','binaries_manifest_sha256'),('build-review.json','build_review_sha256'),('build-result-review.json','build_result_review_sha256'),('live_lease.py','lease_source_sha256'),('live-authorization.json','authorization_sha256')]:need(sha(P/name)==c[key],'configuration '+name)
 target='window';entry=manifest['outputs'][target];build=read(P/(target+'.json'))
 need(r['binary_sha256']==entry['binary']['sha256']==sha(entry['binary']['path'])and entry['binary']['bytes']==Path(entry['binary']['path']).stat().st_size,'executed binary')
 need(r['build_receipt_sha256']==entry['build_receipt_sha256']==sha(P/(target+'.json'))and build['exit_code']==0 and build['error']is None and build['identity_stable']is True and build['binary_stable']is True and build['identity_before']==build['identity_after']==manifest['source_identity'],'stable successful source-bound build')
 need(entry['binary']==build['binary']and build['source_review_sha256']==c['build_review_sha256']and build['producer_sha256']==sha(P/'build.py'),'build producer/review')
 need(sha(P/(target+'-go-version.txt'))==entry['build_metadata_sha256']==build['go_version_metadata_sha256'],'build metadata')
 need(all(sha(P/(target+'.'+ch))==build[ch+'_sha256']for ch in ['stdout','stderr']),'build streams')
 args=CASES[case]['args']
 need(r['argv']==owned['argv']==[entry['binary']['path'],*args]and r['cwd']==owned['cwd']=='/private/tmp/vellum-ax-graph/drivers/cogent'and r['watchdog_seconds']==owned['watchdog_seconds']==CASES[case]['watchdog_seconds'],'exact native invocation')
 need(finite(r['elapsed_seconds'])and 0<r['elapsed_seconds']<=r['watchdog_seconds']+30,'controller wall bound')
 profile=CASES[case]['heap_profile']
 need(r['profile_ok']is True,'bounded profile output')
 if profile:
  f=Path(profile);need(r['profile']=={'path':profile,'bytes':f.stat().st_size,'sha256':sha(f)}and f.is_file()and not f.is_symlink()and 0<f.stat().st_size<=8<<20,'raw bounded profile')
 else:need(r['profile']is None,'unexpected profile output')
 obs=r['group_observation'];need(obs['observed_group']==r['process_group']and obs['argv']==['ps','-axo','pid=,pgid=,stat=']and obs['members']==[]and obs['stdout_bytes']>0,'recorded owned group absence')
 for ch in ['stdout','stderr']:
  f=P/(case+'.'+ch);info=r['logs'][ch];need(info['sha256']==info['stream_sha256']==sha(f)and info['bytes']==f.stat().st_size and info['bytes']<=(64<<20 if ch=='stdout'else 4<<20),'raw '+ch)
 need(r['predecessor']==owned['predecessor'],'owned predecessor binding');validate_predecessor(c,r['predecessor'])
 need(sha(S/'validate_soak.py')==c['predecessor_validator_sha256'],'pure cleanup source');soak=module('post_loop_pure_cleanup',S/'validate_soak.py')
 need(set(r['prior_cases'])==set(ORDER[:ORDER.index(case)])and r['prior_cases']==owned['prior_cases'],'case order')
 for name,info in r['prior_cases'].items():need(info['validation_sha256']==sha(P/(name+'-validation.json'))and read(P/(name+'-validation.json'))['result']=='PASS_SCOPED_NATIVE_CASE'and info['fresh_group_absence']['members']==[],'preceding case')
 raw=(P/(case+'.stdout')).read_text();need(raw.strip(),'nonempty native output')
 if target=='queue':payload=queue_payload(json.loads(raw),case)
 else:
  need(sha(E/'validate_live.py')==read(S/'inputs.json')['predecessor_validator_sha256'],'pure action plan identity')
  v=module('post_loop_pure_plan',E/'validate_live.py');payload=composed_payload([json.loads(line)for line in raw.splitlines()if line.strip()],v,soak.terminal,case)
 return {'result':'PASS_SCOPED_NATIVE_CASE','case':case,'source_commit':r['source_commit'],'validator_sha256':sha(__file__),'run_receipt_sha256':sha(P/(case+'.json')),'binary_sha256':r['binary_sha256'],'raw_stdout_sha256':r['logs']['stdout']['sha256'],'raw_stderr_sha256':r['logs']['stderr']['sha256'],'raw_stderr_bytes':r['logs']['stderr']['bytes'],'direct_child_terminal':True,'recorded_owned_group_absence_confirmed':True,'payload':payload,'physical_input_qualified':False,'human_voiceover_qualified':False,'full_idle_budget_qualified':False,'native_gpu_memory_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False}

if __name__=='__main__':
 case=sys.argv[1]
 try:result=validate(case)
 except Exception as e:result={'result':'FAILED_VALIDATION','case':case,'error':{'type':type(e).__name__,'message':str(e)},'validator_sha256':sha(__file__)}
 with(P/(case+'-validation.json')).open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result));sys.exit(1 if result['result']=='FAILED_VALIDATION'else 0)
