"""Bounded CPU-only synthetic controller/parser regression checks."""
from pathlib import Path
import hashlib,json,sys,time
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
label=sys.argv[1];assert label in ['controls','controls-v2','controls-v3']
inputs={f.name:sha(f)for f in sorted(P.glob('*.py'))}
argv=[sys.executable,'-m','unittest','-v','test_native_lifecycle','test_native_validation']
record={'argv':argv,'inputs':inputs,'native_application_executed':False,'synthetic_children_only':True,'exit_code':None,'error':None}
start=time.monotonic()
try:
 with(P/(label+'.stdout')).open('xb')as out,(P/(label+'.stderr')).open('xb')as err:
  record['exit_code']=run_child(argv,cwd=P,env=child_environment(),stdout=out,stderr=err,timeout=60,log_limit_bytes=4<<20).returncode
except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 record.update(elapsed_seconds=time.monotonic()-start,sources_stable=all(sha(P/n)==h for n,h in inputs.items()),
  logs={ch:{'bytes':(P/(label+'.'+ch)).stat().st_size,'sha256':sha(P/(label+'.'+ch))}for ch in ['stdout','stderr']})
 with(P/(label+'.json')).open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','sources_stable']}),flush=True)
assert record['exit_code']==0 and record['error']is None and record['sources_stable']
