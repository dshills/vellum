"""One clean frozen-source native fixture build; never launches an application."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-ax-graph');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
from live_lease import LiveLease
HEAD='6330b2d42050b46c2019e558074e087ed281e56a';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'build-review.json').read_text())
assert review['execution_ready']and not review['unresolved_findings']and review['sources']=={'build.py':sha(Path(__file__))}
name='window';output=P/'outputs'/name;output.parent.mkdir(exist_ok=True)
assert not output.exists()and not any((P/(name+'.'+s)).exists()for s in ['json','stdout','stderr'])
reference=Path('/private/tmp/vellum-macos-ax-graph/baseline.json')
prepared_reference=json.loads(reference.read_text())['prepared'];reference_sha=sha(reference)
markers=[P/'stop-live',Path('/private/tmp/vellum-macos-listbox/stop-live'),Path('/private/tmp/vellum-macos-ax-graph/stop-live')]
def git(*args):return subprocess.check_output(['git',*args],cwd=R,timeout=10)
def identity():
 assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain').strip()
 tracked={}
 for row in git('ls-tree','-rz','--full-tree','HEAD').split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();f=R/name.decode();assert kind=='blob'and f.is_file()and not f.is_symlink()
  data=f.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
  tracked[name.decode()]=hashlib.sha256(data).hexdigest()
 prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
 assert len(tracked)==4490 and len(prepared)==6229 and prepared==prepared_reference and sha(reference)==reference_sha
 return {'commit':HEAD,'git_clean':True,'tracked':tracked,'prepared':prepared}
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off'}
assert env['CGO_ENABLED']=='1'
argv=['go','build','-p=1','-trimpath','-tags=vellum_native_checks','-o',str(output),'./cmd/window-cycle-smoke']
with LiveLease()as lease:
 assert lease.held()and not any(m.exists()for m in markers)
 before=identity()
 record={'schema':'vellum-current-endurance-build-v1','argv':argv,'cwd':str(R/'drivers/cogent'),
  'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':sha(Path(__file__)),
  'source_review_sha256':sha(P/'build-review.json'),'identity_before':before,'prepared_reference_sha256':reference_sha,
  'native_application_executed':False,'exit_code':None,'error':None,'shared_lease_held':lease.held()}
 producers=P/'producers';producers.mkdir(exist_ok=True);producer=producers/(record['producer_sha256']+'.py')
 if not producer.exists():producer.write_bytes(Path(__file__).read_bytes())
 start=time.monotonic()
 try:
  with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
   record['exit_code']=run_child(argv,cwd=R/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=120,log_limit_bytes=2<<20).returncode
  if record['exit_code']==0:
   record['binary']={'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size}
   metadata=run_child(['go','version','-m',str(output)],cwd=R,env=env,capture_output=True,timeout=5)
   assert metadata.returncode==0 and not metadata.stderr
   info=metadata.stdout.decode();assert 'vcs.revision='+HEAD in info and 'vcs.modified=false'in info and 'CGO_ENABLED=1'in info
   with(P/(name+'-go-version.txt')).open('x')as out:out.write(info)
   record['go_version_metadata_sha256']=sha(P/(name+'-go-version.txt'))
 except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
 finally:
  try:record['identity_after']=identity();record['identity_stable']=record['identity_after']==before
  except BaseException as error:record['identity_stable']=False;record['identity_error']={'type':type(error).__name__,'message':str(error)}
  try:record['binary_stable']='binary'in record and sha(output)==record['binary']['sha256']and output.stat().st_size==record['binary']['bytes']
  except BaseException as error:record['binary_stable']=False;record['binary_error']={'type':type(error).__name__,'message':str(error)}
  record.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
   shared_lease_held_through_cleanup=lease.held(),stop_markers_at_exit=[str(m)for m in markers if m.exists()])
  for suffix in ['stdout','stderr']:
   f=P/(name+'.'+suffix);record[suffix+'_sha256']=sha(f)if f.exists()else None
  with(P/(name+'.json')).open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
  print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','identity_stable','binary_stable']}),flush=True)
 assert record['exit_code']==0 and record['error']is None and record['identity_stable']and record['binary_stable']and not record['stop_markers_at_exit']and lease.held()
