"""Source/build/admission checks for the post-loop native follow-ups."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph');S=Path('/private/tmp/vellum-macos-soak-cover')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
from live_lease import LiveLease
from cases import CASES,ORDER
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def need(value,why):
 if not value:raise ValueError(why)
def read(f):return json.loads(Path(f).read_text())
def load(name,f):
 spec=importlib.util.spec_from_file_location(name,f);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def markers():return [P/'stop-live',Path('/private/tmp/vellum-macos-ax-graph/stop-live'),*[Path('/private/tmp')/('vellum-macos-'+n)/'stop-live'for n in ['listbox','composed-endurance','composed-soak','post-glyph-native','soak-occlusion','soak-cover']]]
def stopping():return [str(f)for f in markers()if f.exists()]
def config():
 c=read(P/'native-configuration.json')
 need(c['source_commit']=='6330b2d42050b46c2019e558074e087ed281e56a','source endpoint')
 for name,key in [('binaries.json','binaries_manifest_sha256'),('build-review.json','build_review_sha256'),('build-result-review.json','build_result_review_sha256'),('live_lease.py','lease_source_sha256'),('live-authorization.json','authorization_sha256')]:need(sha(P/name)==c[key],'configuration binding '+name)
 return c

def current_identity(expected):
 need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,timeout=10).decode().strip()==expected['commit'],'current HEAD')
 need(not subprocess.check_output(['git','status','--porcelain'],cwd=R,timeout=10).strip(),'current checkout clean')
 names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R,timeout=10).decode().split('\0')if n]
 need(set(names)==set(expected['tracked']),'tracked source names')
 need(all((R/n).is_file()and not(R/n).is_symlink()and sha(R/n)==h for n,h in expected['tracked'].items()),'tracked source bytes')
 actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
 need(actual==expected['prepared'],'prepared source vector')
 return True

def group_absent(pid):
 need(type(pid)is int and pid>0,'owned group identity')
 argv=['ps','-axo','pid=,pgid=,stat='];r=run_child(argv,env=child_environment(),capture_output=True,timeout=5)
 need(r.returncode==0 and not r.stderr and r.stdout.strip(),'process group observation failed')
 members=[]
 for line in r.stdout.decode().splitlines():
  fields=line.split();need(len(fields)==3 and fields[0].isdecimal()and fields[1].isdecimal()and fields[2],'malformed process observation')
  if int(fields[1])==pid:members.append({'pid':int(fields[0]),'pgid':pid,'state':fields[2]})
 need(not members,'owned native group is still present')
 return {'observed_group':pid,'argv':argv,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stdout_bytes':len(r.stdout),'members':members}

def predecessor(c):
 if c.get('predecessor_scheduling_policy')=='recorded_failed_retired_for_independent_checks':
  for name,key in [('validate_retired_failure.py','retired_failure_validator_sha256'),('retired-failure-inputs.json','retired_failure_inputs_sha256'),('retired-soak-failure.json','retired_failure_proof_sha256'),('retired-failure-review.json','retired_failure_review_sha256')]:need(sha(P/name)==c[key],'reviewed known-failure scheduling input '+name)
  approval=read(P/'retired-failure-review.json');need(approval['execution_ready_for_scheduling_proof']is True and approval['unresolved_findings']==[],'scheduling proof approval')
  v=load('known_retired_soak_failure',P/'validate_retired_failure.py');proof=v.validate();need(proof==read(P/'retired-soak-failure.json'),'raw known-failure retirement proof')
  need(proof['result']=='VALIDATED_FAILED_RETIRED_SOAK'and proof['full_overnight_qualified']is False and proof['full_idle_budget_qualified']is False and proof['full_mac_qualified']is False,'failure is scheduling-only')
  return {'result':'FAILED_RETIRED_PREDECESSOR','validation_sha256':sha(P/'retired-soak-failure.json'),'run_receipt_sha256':proof['run_receipt_sha256'],'sampled_idle_cpu_target_met':False,'full_idle_budget_qualified':False,'original_overnight_qualified':False,'fresh_group_absence':group_absent(proof['pid'])}
 need(c.get('predecessor_scheduling_policy')in[None,'completed_soak_only'],'unsupported predecessor scheduling policy')
 need(sha(S/'inputs.json')==c['predecessor_inputs_sha256']and sha(S/'validate_soak.py')==c['predecessor_validator_sha256'],'original soak producer pins')
 saved=read(S/'soak-overnight-validation.json');run=read(S/'soak-overnight.json')
 need(saved['result']=='COMPLETE_OVERNIGHT_PHASE_TRACE'and saved['run_receipt_sha256']==sha(S/'soak-overnight.json'),'terminal validated overnight predecessor required')
 validator=load('post_loop_prior_soak',S/'validate_soak.py');need(validator.validate('soak-overnight','overnight')==saved,'raw predecessor revalidation')
 need(run['result']=='TERMINAL_NATIVE_RUN_OK'and run['exit_code']==0 and run['error']is None and run['direct_child_terminal']and run['group_absence_confirmed'],'terminal predecessor ownership')
 need(saved['full_idle_budget_qualified']is False and saved['full_mac_qualified']is False,'preserve predecessor scope')
 return {'validation_sha256':sha(S/'soak-overnight-validation.json'),'run_receipt_sha256':sha(S/'soak-overnight.json'),'sampled_idle_cpu_target_met':saved['sampled_idle_cpu_target_met'],'full_idle_budget_qualified':False,'fresh_group_absence':group_absent(run['process_group'])}

def built(name,c):
 manifest=read(P/'binaries.json');entry=manifest['outputs'][name];b=read(P/(name+'.json'))
 need(sha(P/(name+'.json'))==entry['build_receipt_sha256']and b['exit_code']==0 and b['error']is None and b['identity_stable']and b['binary_stable'],'successful build binding')
 need(b['identity_before']==b['identity_after']==manifest['source_identity']and len(manifest['source_identity']['tracked'])==4490 and len(manifest['source_identity']['prepared'])==6229,'complete source association')
 need(b['source_review_sha256']==c['build_review_sha256']and b['producer_sha256']==sha(P/'build.py'),'build review/producer binding')
 need(all(sha(P/(name+'.'+channel))==b[channel+'_sha256']for channel in ['stdout','stderr']),'build raw logs')
 need(sha(P/(name+'-go-version.txt'))==entry['build_metadata_sha256']==b['go_version_metadata_sha256'],'build metadata')
 need(entry['binary']==b['binary']and Path(entry['binary']['path'])==P/'outputs'/name and sha(P/'outputs'/name)==entry['binary']['sha256']and(P/'outputs'/name).stat().st_size==entry['binary']['bytes'],'native executable identity')
 current_identity(manifest['source_identity'])
 return manifest,entry

def approved():
 review=read(P/'native-review.json');need(review['execution_ready']and not review['unresolved_findings'],'native harness source approval')
 need(all(sha(P/n)==h for n,h in review['sources'].items()),'native harness reviewed inputs')
 return review

def prior_cases(case):
 order=ORDER;need(case in order,'native case')
 validator=load('post_loop_result_validator',P/'validate_native.py')
 evidence={}
 for prior in order[:order.index(case)]:
  saved=read(P/(prior+'-validation.json'));fresh=validator.validate(prior)
  need(fresh==saved and saved['result']=='PASS_SCOPED_NATIVE_CASE','previous native case validation')
  evidence[prior]={'validation_sha256':sha(P/(prior+'-validation.json')),'fresh_group_absence':group_absent(read(P/(prior+'.json'))['process_group'])}
 return evidence
