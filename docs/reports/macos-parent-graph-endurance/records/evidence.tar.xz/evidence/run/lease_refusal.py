"""Real cooperative-lock refusal check; no native application should launch."""
from pathlib import Path
import hashlib,json,sys,time
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
from live_lease import LiveLease
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
record={'producer_sha256':sha(Path(__file__)),'argv':[sys.executable,str(P/'run_native.py'),'window-five','--expect-lease-refusal'],'native_application_executed':False,'exit_code':None,'error':None}
start=time.monotonic()
with LiveLease()as lease:
 try:
  assert lease.held()
  with(P/'lease-refusal.stdout').open('xb')as out,(P/'lease-refusal.stderr').open('xb')as err:
   record['exit_code']=run_child(record['argv'],cwd=P,env=child_environment(),stdout=out,stderr=err,timeout=30,log_limit_bytes=1<<20).returncode
  proof=json.loads((P/'overlap-refusal.json').read_text())
  assert proof['result']=='PASS_ACTIVE_LEASE_REFUSAL'and proof['native_application_executed']is False and proof['owned_process_created']is False
  assert lease.held();record['proof_sha256']=sha(P/'overlap-refusal.json')
 except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
 finally:
  record.update(elapsed_seconds=time.monotonic()-start,lease_held_through_child=lease.held(),logs={ch:{'bytes':(P/('lease-refusal.'+ch)).stat().st_size,'sha256':sha(P/('lease-refusal.'+ch))}for ch in ['stdout','stderr']})
  with(P/'lease-refusal.json').open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['exit_code','error','lease_held_through_child']}),flush=True)
assert record['exit_code']==0 and record['error']is None and record['lease_held_through_child']
