"""Recorded failed-soak retirement proof for scheduling independent tests only."""
from pathlib import Path
import hashlib,importlib.util,json,sys
P=Path(__file__).resolve().parent;S=Path('/private/tmp/vellum-macos-soak-cover')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(f):return json.loads(Path(f).read_text())
def need(v,msg):
 if not v:raise ValueError(msg)
def failed_payload(r,events,terminal):
 need(r['result']=='FAILED_OR_CANCELED_NATIVE_RUN'and r['exit_code']==1 and r['error']is None and r['stop_reason']is None and r['cleanup_errors']==[]and r['stop_marker_at_exit']is False,'exact known terminal failure')
 need(all(r[k]is True for k in ['direct_child_terminal','group_absence_confirmed','inputs_stable','binary_stable','logs_complete','artifacts_stable','predecessor_group_reobserved_absent'])and r['post_terminal_group_members']==[],'recorded retirement/stability')
 need(r['pid']==r['process_group']==15600 and type(r['pid'])is int,'known owner identity')
 need(r['native_lease']=={'path':'/private/tmp/vellum-macos-live-oct15.lock','acquired':True,'held_through_cleanup':True},'lease-held failure cleanup')
 result=events[-1];need(result['event']=='vellum.window-soak.result'and result['result']=='FAILED_NATIVE_WINDOW_SOAK'and result['requested_cycles']==1 and result['completed_cycles']==0 and result['native_action_plan']==2,'failed inner result')
 samples=[e for e in events if e.get('event')=='vellum.soak.sample'];need(len(samples)==30 and [s['phase']for s in samples]==['visible']*24+['occluded']*6 and all(s['cpu_60s_interval']is True for s in samples),'known incomplete phase trace')
 need([e['phase']for e in events if e.get('event')=='vellum.soak.phase-end']==['visible'],'only visible phase completed')
 need(result['samples']==[s['forced_gc_memory']for s in samples]and result['cooperative_timeout_seconds']==28980 and result['soak_config']=={'Duration':28800000000000,'Quiet':60000000000,'Settle':10000000000,'Interval':300000000000},'unchanged original workload')
 need(all(result[k]is False for k in ['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed']),'failed run grants no acceptance')
 terminal(result['native_cleanup'])
 obs=r['group_observation'];need(obs['argv']==['ps','-axo','pid=,pgid=,comm=']and obs['exit_code']==0 and obs['stdout_bytes']>0 and obs['stderr_bytes']==0 and obs['stdout_sha256']==r['group_observation_sha256'],'recorded group observation')
 return {'result':'VALIDATED_FAILED_RETIRED_SOAK','pid':15600,'exit_code':1,'failure':'soak occluded state drift','visible_quiet_samples':24,'occluded_quiet_samples':6,'completed_phases':['visible'],'recorded_owned_group_absence_confirmed':True,'native_cleanup':result['native_cleanup'],'sampled_idle_cpu_target_met':False,'full_overnight_qualified':False,'full_idle_budget_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,'scheduling_scope':'Independent followups only; controller must acquire shared lease and freshly observe PGID15600 absent. Original failed soak remains failed.'}
def validate():
 c=read(P/'retired-failure-inputs.json');need(c['expected_run_receipt_sha256']=='f331589b3a61ead2d26885ee11ede4e0e5ce96e715f5e1a779a1d682f1816337'and c['expected_owned_pid']==15600 and c['native_soak_acceptance_granted']is False and c['fresh_group_absence_after_shared_lease_required']is True,'explicit known-failure scheduling policy')
 for name,info in c['files'].items():need((S/name).is_file()and not(S/name).is_symlink()and sha(S/name)==info['sha256']and(S/name).stat().st_size==info['bytes'],'retained original input '+name)
 need(sha(S/'soak-overnight.json')==c['expected_run_receipt_sha256'],'known failed receipt')
 r=read(S/'soak-overnight.json');owned=read(S/'soak-overnight-owned-process.json');inputs=read(S/'inputs.json');build=read(S/'native-build-v2.json');artifact=read(S/'binary.json')
 for key in ['pid','process_group','argv','cwd','producer_sha256','inputs_sha256','authorization_sha256','qualification_inputs_sha256','harness_review_sha256','lease_source_sha256','build_receipt_sha256','binary_manifest_sha256','executable_sha256']:need(r[key]==owned[key],'owned-start binding '+key)
 for key,name in [('producer_sha256','run_native.py'),('inputs_sha256','soak-overnight-inputs.json'),('authorization_sha256','live-authorization.json'),('qualification_inputs_sha256','inputs.json'),('harness_review_sha256','diagnostic-harness-review.json'),('lease_source_sha256','live_lease.py'),('build_receipt_sha256','native-build-v2.json'),('binary_manifest_sha256','binary.json')]:need(r[key]==sha(S/name),'producer/input binding '+key)
 review=read(S/'diagnostic-harness-review.json');need(review['unresolved_findings']==[]and all(sha(S/n)==h for n,h in review['sources'].items()),'original reviewed harness')
 need(r['executable_sha256']==c['expected_binary_sha256']==artifact['binary_sha256']==sha(S/'window-cycle-v2'),'executed binary')
 need(build['exit_code']==0 and build['error']is None and build['source_delta_before']==build['source_delta_after']==inputs['identity']['delta']and build['prepared_before']==build['prepared_after']==inputs['identity']['prepared']and len(build['prepared_after'])==6227,'successful recorded source-bound build')
 need(r['argv']==[str(S/'window-cycle-v2'),'-composed','-cycles=1','-sample-every=1','-timeout=8h3m','-soak=8h','-soak-quiet=60s','-soak-settle=10s','-soak-interval=5m','-heap-profile='+str(S/'soak-overnight.heap')],'exact failed argv')
 need((S/'soak-overnight.stderr').read_text()=='soak occluded state drift\ncompleted 0 of 1 cycles\n','known native error')
 for ch in ['stdout','stderr']:
  f=S/('soak-overnight.'+ch);need(r['logs'][ch]['sha256']==r['logs'][ch]['stream_sha256']==sha(f)and r['logs'][ch]['bytes']==f.stat().st_size,'complete raw '+ch)
 need(sha(S/'validate_soak.py')=='2ffcfc73e4d51c41ac55c4cea5a8df983084a6bf6105ff2b591fcc8651aa4473','original pure cleanup helper')
 spec=importlib.util.spec_from_file_location('retired_failure_pure_cleanup',S/'validate_soak.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 events=[json.loads(line)for line in(S/'soak-overnight.stdout').read_text().splitlines()if line.strip()];result=failed_payload(r,events,v.terminal)
 result.update(run_receipt_sha256=sha(S/'soak-overnight.json'),raw_stdout_sha256=sha(S/'soak-overnight.stdout'),raw_stderr_sha256=sha(S/'soak-overnight.stderr'),inputs_sha256=sha(P/'retired-failure-inputs.json'),validator_sha256=sha(__file__))
 return result
if __name__=='__main__':
 result=validate()
 with(P/'retired-soak-failure.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
