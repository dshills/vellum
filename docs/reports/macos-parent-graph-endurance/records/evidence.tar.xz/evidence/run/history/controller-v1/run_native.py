"""One owned post-loop native case; shared lease precedes every admission check."""
import datetime,hashlib,json,os,selectors,signal,sys,time
import native_common as c
from child_process import terminate_owned_group

def main():
 case=sys.argv[1];c.need(case in c.ORDER,'fixed native case')
 refusal=sys.argv[2:]==['--expect-lease-refusal'];c.need(refusal or not sys.argv[2:],'unsupported arguments')
 c.need(not c.stopping(),'human-return stop marker')
 configuration=c.config();review=c.approved()
 if refusal:
  refused=False
  try:
   with c.LiveLease():pass
  except RuntimeError as error:
   c.need(str(error)=='another Vellum live fixture owns the shared lease','unexpected lease failure');refused=True
  c.need(refused,'expected existing native owner; no app launched')
  result={'result':'PASS_ACTIVE_LEASE_REFUSAL','case':case,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':c.sha(__file__),'review_sha256':c.sha(c.P/'native-review.json'),'native_application_executed':False,'owned_process_created':False}
  with(c.P/'overlap-refusal.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result));return
 with c.LiveLease()as lease:
  c.need(not c.stopping(),'stop after lease')
  prior=c.predecessor(configuration);previous=c.prior_cases(case)
  target='window';manifest,entry=c.built(target,configuration)
  args=c.CASES[case]['args']
  profile=c.CASES[case]['heap_profile'];c.need(profile is None or not c.Path(profile).exists(),'profile output already exists')
  argv=[entry['binary']['path'],*args];watchdog=c.CASES[case]['watchdog_seconds']
  pins={n:c.sha(c.P/n)for n in set(review['sources'])|{'native-review.json','native-configuration.json','binaries.json',target+'.json',target+'-go-version.txt','live-authorization.json'}}
  def stable():return all(c.sha(c.P/n)==h for n,h in pins.items())and c.sha(c.P/'outputs'/target)==entry['binary']['sha256']
  c.need(stable()and lease.held()and not c.stopping(),'launch pins/lease/stop')
  receipt=c.P/(case+'.json');receipt.open('x').close();c.need(not(c.P/(case+'-owned-process.json')).exists(),'existing native owner record')
  d={'schema':'vellum-post-loop-native-run-v1','result':'STARTED_NATIVE_CASE','case':case,'argv':argv,'cwd':str(c.R/'drivers/cogent'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':c.sha(__file__),'review_sha256':c.sha(c.P/'native-review.json'),'configuration_sha256':c.sha(c.P/'native-configuration.json'),'binaries_manifest_sha256':c.sha(c.P/'binaries.json'),'build_receipt_sha256':entry['build_receipt_sha256'],'binary_sha256':entry['binary']['sha256'],'source_commit':manifest['source_commit'],'predecessor':prior,'prior_cases':previous,'pins':pins,'watchdog_seconds':watchdog,'exit_code':None,'error':None,'stop_reason':None,'cleanup_errors':[],'direct_child_terminal':False,'group_absence_confirmed':False,'source_stable':False,'artifacts_stable':False,'native_application_executed':False,'native_lease':{'path':str(lease.path),'acquired':lease.held(),'held_through_cleanup':False}}
  child=None;start=time.monotonic();counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()]
  try:
   with(c.P/(case+'.stdout')).open('xb')as out,(c.P/(case+'.stderr')).open('xb')as err,selectors.DefaultSelector()as ready:
    c.need(stable()and lease.held()and not c.stopping(),'final launch admission')
    child=c.subprocess.Popen(argv,cwd=d['cwd'],env=c.child_environment(True),stdout=c.subprocess.PIPE,stderr=c.subprocess.PIPE,start_new_session=True)
    d['pid']=d['process_group']=child.pid;d['native_application_executed']=True
    with(c.P/(case+'-owned-process.json')).open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
    for index,pipe in enumerate([child.stdout,child.stderr]):ready.register(pipe,selectors.EVENT_READ,index)
    terminal_at=None
    while ready.get_map()or child.poll()is None:
     if c.stopping():d['stop_reason']='human-return-marker';raise InterruptedError(d['stop_reason'])
     if time.monotonic()-start>watchdog:d['stop_reason']='watchdog';raise TimeoutError(d['stop_reason'])
     if child.poll()is not None:
      if terminal_at is None:terminal_at=time.monotonic()
      if time.monotonic()-terminal_at>5:raise TimeoutError('pipe writers survived direct child')
     for key,_ in ready.select(.2):
      data=os.read(key.fd,64<<10)
      if not data:ready.unregister(key.fileobj);continue
      index=key.data;limit=(64<<20)if index==0 else(4<<20);accepted=min(len(data),limit-counts[index])
      if accepted:
       stream=[out,err][index];c.need(stream.write(data[:accepted])==accepted,'short native log write');stream.flush();counts[index]+=accepted;digests[index].update(data[:accepted])
      if accepted!=len(data):raise OSError('native log byte bound')
    d['exit_code']=child.wait(timeout=5)
  except BaseException as error:d['error']={'type':type(error).__name__,'message':str(error)}
  finally:
   def failed(stage,error):d['cleanup_errors'].append({'stage':stage,'type':type(error).__name__,'message':str(error)})
   if child is not None:
    try:
     if child.poll()is None:
      try:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=5)
      except(ProcessLookupError,c.subprocess.TimeoutExpired):pass
     terminate_owned_group(child)
    except BaseException as error:failed('owned-group-retirement',error)
    try:
     if child.poll()is None:child.kill()
     d['exit_code']=child.wait(timeout=5);d['direct_child_terminal']=child.poll()is not None
    except BaseException as error:failed('direct-child-reap',error)
    for pipe in [child.stdout,child.stderr]:
     try:pipe.close()
     except BaseException as error:failed('pipe-close',error)
    try:d['group_observation']=c.group_absent(child.pid);d['group_absence_confirmed']=True
    except BaseException as error:failed('group-absence',error)
   try:d['source_stable']=c.current_identity(manifest['source_identity'])
   except BaseException as error:failed('source-identity',error)
   try:d['artifacts_stable']=stable()
   except BaseException as error:failed('artifact-identity',error)
   try:
    d['logs']={channel:{'bytes':counts[index],'sha256':c.sha(c.P/(case+'.'+channel)),'stream_sha256':digests[index].hexdigest()}for index,channel in enumerate(['stdout','stderr'])}
    d['logs_complete']=all(item['sha256']==item['stream_sha256']and item['bytes']==(c.P/(case+'.'+channel)).stat().st_size for channel,item in d['logs'].items())
   except BaseException as error:d['logs_complete']=False;failed('log-identity',error)
   try:d['stop_markers_at_exit']=c.stopping()
   except BaseException as error:d['stop_markers_at_exit']=['observation-failed'];failed('stop-marker-observation',error)
   try:
    d['profile']=None if profile is None else{'path':profile,'bytes':c.Path(profile).stat().st_size,'sha256':c.sha(profile)}
    d['profile_ok']=profile is None or(c.Path(profile).is_file()and not c.Path(profile).is_symlink()and 0<d['profile']['bytes']<=8<<20)
   except BaseException as error:d['profile_ok']=False;failed('profile-observation',error)
   d['native_lease']['held_through_cleanup']=lease.held();d['elapsed_seconds']=time.monotonic()-start;d['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
   good=d['exit_code']==0 and d['error']is None and d['stop_reason']is None and d['direct_child_terminal']and d['group_absence_confirmed']and d['source_stable']and d['artifacts_stable']and d['logs_complete']and d['profile_ok']and not d['cleanup_errors']and not d['stop_markers_at_exit']and lease.held()
   d['result']='TERMINAL_NATIVE_CASE_OK'if good else'FAILED_OR_CANCELED_NATIVE_CASE'
   receipt.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k]for k in ['result','case','exit_code','error','stop_reason','cleanup_errors','elapsed_seconds']}))
  c.need(d['result']=='TERMINAL_NATIVE_CASE_OK','native case did not complete')

if __name__=='__main__':main()
