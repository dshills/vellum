"""Synthetic parser fault controls, never native qualification."""
from copy import deepcopy
from pathlib import Path
import importlib.util,json,unittest
import validate_native as v
E=Path('/private/tmp/vellum-macos-composed-endurance');S=Path('/private/tmp/vellum-macos-soak-cover')
def pure(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
plan=pure('current_endurance_control_plan',E/'validate_live.py');soak=pure('current_endurance_control_cleanup',S/'validate_soak.py')
class PayloadChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  # Reuse actual earlier-source shape only as synthetic parser input; receipts,
  # identities and observations of a current native run are never fabricated.
  prior=[json.loads(line)for line in Path('/private/tmp/vellum-macos-post-loop-native/window-five.stdout').read_text().splitlines()]
  cls.template=deepcopy([e for e in prior if e['event']=='vellum.composed-cycle'][0])
  cls.sample=deepcopy(prior[0]);cls.result=deepcopy(prior[-1])
 def synthetic(self,case='window-five'):
  cfg=v.CASES[case];count=cfg['cycles'];events=[];samples=[]
  def memory(n):
   m=deepcopy(self.sample);m['sample'].update(Completed=n,ElapsedSeconds=n+1.0);samples.append(m['sample']);events.append(m)
  memory(0)
  for n in range(1,count+1):
   cycle=deepcopy(self.template);cycle['cycle']=n
   events.extend([{'event':'vellum.native-action','window':f'native-cycle-{n-1:04d}','action':a}for a in cycle['native_actions']]);events.append(cycle)
   if n%cfg['every']==0 or n==count:memory(n)
  terminal=deepcopy(self.result);terminal.update(requested_cycles=count,completed_cycles=count,cooperative_timeout_seconds=cfg['timeout_seconds'],heap_profile_requested=bool(cfg['heap_profile']),samples=samples)
  events.append(terminal);return events
 def check(self,events,case='window-five'):return v.composed_payload(events,plan,soak.terminal,case)
 def test_both_synthetic_plans(self):
  for case in v.ORDER:
   with self.subTest(case=case):self.assertEqual(self.check(self.synthetic(case),case)['cycles'],v.CASES[case]['cycles'])
 def test_missing_action(self):
  events=self.synthetic();del events[1]
  with self.assertRaises(ValueError):self.check(events)
 def test_owner_not_completed(self):
  events=self.synthetic();events[1]['action']['OwnerAndNativeCompleted']=False
  with self.assertRaises(ValueError):self.check(events)
 def test_wrong_native_role(self):
  events=self.synthetic();events[16]['action']['NativeRole']='AXButton'
  with self.assertRaises(ValueError):self.check(events)
 def test_reordered_cycle(self):
  events=self.synthetic();events[33],events[34]=events[34],events[33]
  with self.assertRaises(ValueError):self.check(events)
 def test_visible_terminal_window(self):
  events=self.synthetic();events[-1]['native_cleanup']['Windows'][0]['Visible']=True
  with self.assertRaises(ValueError):self.check(events)
 def test_wrong_memory_cadence(self):
  events=self.synthetic('window-thousand');samples=[e for e in events if e['event']=='vellum.window-cycle.sample'];samples[1]['sample']['Completed']=24
  with self.assertRaises(ValueError):self.check(events,'window-thousand')
 def test_wrong_long_timeout(self):
  events=self.synthetic('window-thousand');events[-1]['cooperative_timeout_seconds']=10800
  with self.assertRaises(ValueError):self.check(events,'window-thousand')
 def test_missing_last_sample(self):
  events=self.synthetic('window-thousand');del events[-2]
  with self.assertRaises(ValueError):self.check(events,'window-thousand')
 def test_five_cycles_cannot_qualify_thousand(self):
  with self.assertRaises(ValueError):self.check(self.synthetic(),'window-thousand')
 def test_inflated_qualification(self):
  events=self.synthetic();events[-1]['full_p11_qualified']=True
  with self.assertRaises(ValueError):self.check(events)
if __name__=='__main__':unittest.main()
