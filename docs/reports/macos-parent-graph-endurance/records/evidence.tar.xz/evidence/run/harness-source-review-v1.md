Builder readiness is approved separately. The lifecycle harness needs one cleanup correction: a failed graceful SIGTERM step must not skip unconditional group SIGKILL. Preserve independent direct reap, pipe closure and absence observations.

The 5→1000 order, exact33-action validator, sample/memory/profile/time bounds, source/build guards and scheduling-only failed-soak policy look consistent. Current CPU controls and final build/freeze/configuration bindings remain pending; no native launch approval or actual runtime result is asserted.
