from pathlib import Path
from collections import Counter
import datetime,hashlib,json,math
p=Path(__file__).resolve().parent
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
validation=json.loads((p/'window-thousand-validation.json').read_text())
audit=json.loads((p/'window-thousand-terminal-audit.json').read_text())
assert validation['result']=='PASS_SCOPED_NATIVE_CASE'and audit['result']=='TERMINAL_RECEIPT_LOGS_AND_FRESH_ABSENCE_CHECKED'
assert validation['raw_stdout_sha256']==sha(p/'window-thousand.stdout')==audit['logs']['stdout']['sha256']
events=[json.loads(line)for line in(p/'window-thousand.stdout').read_text().splitlines()]
cycles=[e for e in events if e['event']=='vellum.composed-cycle']
final=events[-1];samples=final['samples'];actions=[a for c in cycles for a in c['native_actions']]
assert len(cycles)==1000 and len(actions)==33000 and len(samples)==41
retries=[]
for c in cycles:
 for index,a in enumerate(c['native_actions']):
  if a['Attempts']>1 or a['Admissions']>1:
   retries.append({'cycle':c['cycle'],'plan_index':index,'target':a['Target'],'kind':a['Kind'],'value':a['Value'],'attempts':a['Attempts'],'admissions':a['Admissions'],'elapsed_seconds':a['ElapsedSeconds']})
def dist(values):
 ordered=sorted(values)
 return {'count':len(ordered),'min':ordered[0],'p50':ordered[math.ceil(len(ordered)*.5)-1],'p95':ordered[math.ceil(len(ordered)*.95)-1],'p99':ordered[math.ceil(len(ordered)*.99)-1],'max':ordered[-1]}
def memory(selected):
 return {'sample_count':len(selected),'completed_range':[selected[0]['Completed'],selected[-1]['Completed']],'go_heap_alloc_bytes':dist([s['HeapAlloc']for s in selected]),'rss_bytes':dist([s['RSSBytes']for s in selected]),'goroutines':dist([s['Goroutines']for s in selected]),'first':selected[0],'last':selected[-1]}
retry_targets=Counter(a['target']for a in retries)
result={
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'result':'ANALYZED_COMPLETED_SCOPED_NATIVE_LIFECYCLE',
 'source_commit':validation['source_commit'],'cycles':len(cycles),'actions':len(actions),
 'total_attempts':sum(a['Attempts']for a in actions),'total_admissions':sum(a['Admissions']for a in actions),
 'extra_attempts':sum(a['Attempts']-1 for a in actions),'extra_admissions':sum(a['Admissions']-1 for a in actions),
 'retry_records':len(retries),'retry_cycles':len(set(r['cycle']for r in retries)),
 'retry_targets':dict(sorted(retry_targets.items())),
 'max_attempts_per_action':max(a['Attempts']for a in actions),'max_admissions_per_action':max(a['Admissions']for a in actions),
 'action_elapsed_seconds':dist([a['ElapsedSeconds']for a in actions]),
 'tree_accessibility_rows':dict(sorted(Counter(c['tree_accessibility_rows']for c in cycles).items())),
 'memory_all':memory(samples),'memory_from_25':memory([s for s in samples if s['Completed']>=25]),
 'memory_from_500':memory([s for s in samples if s['Completed']>=500]),
 'elapsed_seconds':audit['elapsed_seconds'],'native_cleanup':final['native_cleanup'],
 'inputs_sha256':{n:sha(p/n)for n in ['window-thousand.stdout','window-thousand.stderr','window-thousand.json','window-thousand-validation.json','window-thousand-terminal-audit.json','analyze_completion.py']},
 'scope':['Controller/action wall times are not physical input-to-present or UI-frame timings.','Queue admissions are not accepted callback counts; the causes of 54 additional attempts/admissions were not observed.','Forced-GC fixture samples and the Go heap profile do not qualify unbounded-retention, native heap/GPU/private bytes or the empty-1000-control budgets. Historical window identity tombstones are retained.','One hidden inactive untitled Cocoa window remains in the pre-exit snapshot; zero-Cocoa-window and original-menu-restoration acceptance remain open.','Original overnight soak remains failed; no physical input, IME/VoiceOver, fullP11 or fullMac acceptance.'],
 'professional_memory_qualified':False,'ordinary_frame_budget_qualified':False,'full_mac_qualified':False,
}
assert result['total_attempts']==result['total_admissions']==validation['payload']['total_attempts']==33054
assert result['extra_attempts']==result['extra_admissions']==54
for name,value in [('completion-analysis.json',result),('completion-retry-records.json',retries),('completion-memory-samples.json',samples)]:
 with(p/name).open('x')as out:out.write(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['result','cycles','actions','total_attempts','total_admissions','extra_attempts','retry_records','retry_cycles','retry_targets','max_attempts_per_action','elapsed_seconds']}))
print(json.dumps({k:result[k]for k in ['action_elapsed_seconds','memory_all','memory_from_25','memory_from_500']}))
