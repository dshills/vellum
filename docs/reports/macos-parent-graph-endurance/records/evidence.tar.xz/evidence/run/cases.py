"""Fixed independent native cycle cases; no automatic scheduling."""
CASES={
 'window-five':{'cycles':5,'every':1,'heap_profile':None,'timeout_seconds':300,'watchdog_seconds':360,'args':['-composed','-cycles=5','-sample-every=1','-timeout=5m']},
 'window-thousand':{'cycles':1000,'every':25,'heap_profile':'/private/tmp/vellum-macos-parent-graph-endurance/window-thousand.heap','timeout_seconds':14400,'watchdog_seconds':14700,'args':['-composed','-cycles=1000','-sample-every=25','-timeout=4h','-heap-profile=/private/tmp/vellum-macos-parent-graph-endurance/window-thousand.heap']}}
ORDER=list(CASES)
