"""Read-only owned-process/raw-prefix observations; never native qualification."""
from pathlib import Path
import datetime,hashlib,json,subprocess
P=Path(__file__).resolve().parent
owner=json.loads((P/'window-thousand-owned-process.json').read_text());pid=owner['pid']
expected=owner['argv'][0];assert pid==owner['process_group']and type(pid)is int and pid>0
argv=['ps','-p',str(pid),'-o','pid=,pgid=,stat=,etime=,comm=']
r=subprocess.run(argv,capture_output=True,text=True,timeout=5)
fields=r.stdout.strip().split(maxsplit=4)
live=r.returncode==0 and not r.stderr and len(fields)==5 and fields[0]==fields[1]==str(pid)and fields[4] == expected and bool(fields[2]) and fields[2][0] not in ['Z','X']
raw=(P/'window-thousand.stdout').read_bytes();assert len(raw)<=64<<20
complete=raw[:raw.rfind(b'\n')+1];events=[json.loads(line)for line in complete.splitlines()]
cycles=[e for e in events if e.get('event')=='vellum.composed-cycle'];samples=[e for e in events if e.get('event')=='vellum.window-cycle.sample']
observation={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'pid':pid,'pgid':owner['process_group'],
 'process_observation':{'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},'expected_process_observed_live':live,
 'source_commit':owner['source_commit'],'completed_cycle_records':len(cycles),'native_action_records':sum(e.get('event')=='vellum.native-action'for e in events),
 'memory_samples':len(samples),'last_memory_sample':samples[-1]['sample']if samples else None,
 'raw_stdout_bytes':len(raw),'complete_prefix_bytes':len(complete),'complete_prefix_sha256':hashlib.sha256(complete).hexdigest(),
 'raw_stderr_bytes':(P/'window-thousand.stderr').stat().st_size,'terminal_receipt_bytes':(P/'window-thousand.json').stat().st_size,
 'native_application_executed_by_observer':False,'full_run_qualified':False}
with(P/'observations.ndjson').open('a')as out:out.write(json.dumps(observation,separators=(',',':'))+'\n')
print(json.dumps(observation))
