"""Reparse retained historical timing; no benchmark, app, or source mutation."""
from pathlib import Path
import datetime,hashlib,json,math,statistics
P=Path(__file__).resolve().parent;M=Path('/private/tmp/vellum-macos-post-loop-measurements');R=Path('/private/tmp/vellum-ax-graph')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
fields=['input_ns','owner_ns','reconcile_ns','layout_paint_ns','gather_ns','raster_upload_ns','encode_submit_ns']
result={'scope':'Read-only analysis of retained diagnostic frames on source82c0c5e; not current6330 timing or ordinary acceptance.',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':sha(Path(__file__)),
 'native_application_executed':False,'new_performance_test_executed':False,'ordinary_targets_qualified':False,'comparisons':{}}
for name,count in [('grid-cpu-profile',360),('grid-source-details',120)]:
 path=M/(name+'.stdout');digest=sha(path);events=[json.loads(l)for l in path.read_text().splitlines()if l.startswith('{')]
 setup=events[0];assert setup['event']=='grid.perf.setup'and setup['build_settings']['vcs.revision']=='82c0c5ec17fd7f90da1a0ac4a26d65a3de8367a4'
 samples=[e for e in events if e['event']=='grid.perf.sample'];end=events[-1]
 assert len(samples)==count==end['samples']==end['callbacks']and end['dropped']==end['pending']==0
 for s in samples:
  m=s['metrics'];n=s['native_sample'];assert n['Completed']and not n['Failure']and s['callbacks']==1
  assert all(type(m[k])is int and m[k]>=0 for k in fields)
  assert sum(m[k]for k in fields)==m['ui_work_ns']==n['TotalUIWorkNS']
 total=sum(s['metrics']['ui_work_ns']for s in samples)
 stats={}
 for key in [*fields,'ui_work_ns']:
  values=[s['metrics'][key]for s in samples];ordered=sorted(values)
  stats[key]={'mean_ms':statistics.mean(values)/1e6,'p95_ms':ordered[math.ceil(.95*len(values))-1]/1e6,
   'sum_ns':sum(values),'fraction_of_summed_counted_ui_work':sum(values)/total}
 assert abs(sum(stats[k]['fraction_of_summed_counted_ui_work']for k in fields)-1)<1e-12
 assert sha(path)==digest
 result['comparisons'][name]={'raw_stdout_sha256':digest,'source_commit':setup['build_settings']['vcs.revision'],'samples':count,
  'diagnostic_cpu_profile':setup['cpu_profile'],'diagnostic_source_details':setup['source_details'],'gpu_scene_rendering':setup['gpu_scene_rendering'],'stage_statistics':stats}
paths=['drivers/cogent/frame_metrics.go','drivers/cogent/frame_source_metrics.go',
 'drivers/cogent/build/upstream/paint/renderers/gpuscene/renderer.go','drivers/cogent/build/upstream/paint/renderers/gpuscene/resources.go',
 'drivers/cogent/build/upstream/paint/renderers/sceneplan/packet.go','drivers/cogent/build/upstream/paint/renderers/sceneplan/packed_spans.go']
result['inspected_current_source_sha256']={n:sha(R/n)for n in paths}
result['source_findings']=[
 'Current GPU-scene route calls ScenePacket, EncodeGPU and resources.render inside the source Draw region; its host stages are not separately timed in these CPU-renderer diagnostic runs.',
 'Existing encoder deduplicates masks by immutable pointer within one encoding, but serializes span rows per operation. Span x coordinates are absolute, so repeated glyph instances at different origins cannot share those raw blocks unchanged.',
 'Possible relative-span sharing is a hypothesis requiring capture/encoding/data-size measurements. Existing data does not establish useful repetition, a CPU saving, or a memory saving; no cache/format rewrite is selected.',
 'Full graph validation is outside exact TotalUIWork. The6330 native graph optimization does not authorize subtracting historical validation cost from the4/6ms target.']
result['next_bounded_action']='After the same active1000-window run is actually terminal and inspected, use fresh source-bound CPU/GPU scene diagnostics to distinguish capture/encode/upload from layout/reconciliation. Keep ordinary timing comparisons separate and preserve every existing admission/ownership/refusal boundary.'
result['limits']=['Summed-stage fractions use matched per-sample work, not addition of independent percentiles.',
 'Intervals are elapsed counted regions, not OS-thread CPU or GPU execution. Queued/acquire/present and untraced native work remain separate.',
 'Retained inputs are historical diagnostic evidence. Current6330 ordinary targets, fullP6/P11, native/GPU memory, pacing and fullMac are unqualified.',
 'No other native application, benchmark, compiler or OS settings operation was started by this analysis.']
with(P/'offline-perf-audit.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({n:{k:round(d['stage_statistics'][k]['fraction_of_summed_counted_ui_work']*100,2)for k in fields}for n,d in result['comparisons'].items()}))
