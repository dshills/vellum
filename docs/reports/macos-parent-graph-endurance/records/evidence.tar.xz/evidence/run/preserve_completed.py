from pathlib import Path
import datetime,hashlib,json,os,stat
p=Path(__file__).resolve().parent
out=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-parent-graph-endurance/completed-20261016T085850Z')
sha=lambda b:hashlib.sha256(b).hexdigest()
review=json.loads((p/'completion-evidence-review.json').read_text())
assert review['result']=='APPROVED_SCOPED_COMPLETED_LIFECYCLE_EVIDENCE'and not review['unresolved_findings']
for name,expected in review['reviewed_artifact_sha256'].items():assert sha((p/name).read_bytes())==expected,name
selected={}
def add(path,name,expected=None):
 assert path.is_file()and not path.is_symlink(),path
 data=path.read_bytes()
 if expected is not None:assert sha(data)==expected,path
 assert name not in selected,name
 selected[name]=(path,data,stat.S_IMODE(path.stat().st_mode))
for root,dirs,files in os.walk(p,followlinks=False):
 dirs[:]=sorted(n for n in dirs if n not in ['__pycache__','outputs'])
 assert all(not(Path(root)/n).is_symlink()for n in dirs)
 for name in sorted(files):
  path=Path(root)/name
  add(path,'run/'+path.relative_to(p).as_posix())
old=Path('/private/tmp/vellum-macos-soak-cover')
inputs=json.loads((p/'retired-failure-inputs.json').read_text())
for name,record in inputs['files'].items():add(old/name,'scheduling-predecessor/'+name,record['sha256'])
# Preserve every additional source named by the old reviewed harness, as well as
# the exact pure action-plan helper used by the unchanged current validator.
old_review=json.loads((old/'diagnostic-harness-review.json').read_text())
for name,expected in old_review['sources'].items():
 if 'scheduling-predecessor/'+name not in selected:add(old/name,'scheduling-predecessor/'+name,expected)
plan=Path('/private/tmp/vellum-macos-composed-endurance/validate_live.py')
add(plan,'action-plan-predecessor/validate_live.py',json.loads((old/'inputs.json').read_text())['predecessor_validator_sha256'])
fixture=Path('/private/tmp/vellum-ax-graph/drivers/cogent/cmd/window-cycle-smoke')
for path in sorted(fixture.glob('*.go')):add(path,'fixture-source/'+path.name)
private=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-parent-graph-endurance/bin/window')
private_digest=sha(private.read_bytes())
assert private_digest=='d613b353a507f16f6c8e4c50cae6bd2ca6a50f7319a2fba38e5061be1a78d8b4'
out.mkdir(parents=True,exist_ok=False)
records={}
for name,(original,data,mode)in sorted(selected.items()):
 path=out/name;path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb')as stream:stream.write(data)
 path.chmod(mode)
 assert path.read_bytes()==data and original.read_bytes()==data,name
 records[name]={'bytes':len(data),'sha256':sha(data),'mode':mode,'source':str(original)}
manifest={
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'result':'PRESERVED_REVIEWED_COMPLETED_SCOPED_NATIVE_CASE',
 'source_commit':'6330b2d42050b46c2019e558074e087ed281e56a',
 'files':records,'file_count':len(records),'total_bytes':sum(v['bytes']for v in records.values()),
 'internal_review_sha256':sha((p/'completion-evidence-review.json').read_bytes()),
 'private_binary':{'path':str(private),'sha256':private_digest,'bytes':private.stat().st_size,'included_in_this_bundle':False},
 'executables_excluded':True,'symlinks_followed':0,
 'strict_validator_was_not_rerun':True,
 'scope':'Byte-verified raw native completion, historical failures, producers and fixture context. Referenced private executables remain outside the bundle. Saved scripts retain original absolute paths and are not claimed portable or automatically replayed.',
 'full_mac_qualified':False,'professional_memory_qualified':False,'physical_input_qualified':False,
}
b=(json.dumps(manifest,indent=2)+'\n').encode()
(out/'manifest.json').write_bytes(b)
print(json.dumps({k:manifest[k]for k in ['result','file_count','total_bytes','internal_review_sha256','executables_excluded','symlinks_followed']}|{'destination':str(out),'manifest_sha256':sha(b)}))
