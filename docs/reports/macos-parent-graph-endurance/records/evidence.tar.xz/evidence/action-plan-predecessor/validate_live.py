"""Independent raw-log validation; never imports a producer or launches native code."""
from pathlib import Path
import base64, datetime, hashlib, json, math, statistics, sys

P=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(name):return json.loads((P/name).read_text())
def require(value,why):
 if not value:raise ValueError(why)
def number(v):return type(v)in[int,float]and math.isfinite(v)
def rect(r):return type(r)is list and len(r)==4 and all(number(v)for v in r)and r[2]>0 and r[3]>0
def breadcrumb(item):return 'workspace-path/breadcrumb/item/'+base64.urlsafe_b64encode(item.encode()).decode().rstrip('=')
PLAN=[('check','set','false'),('switch','press',''),('toggle','press',''),('check','set','true'),('slider','set','37'),('number','increment',''),('radio','set','a'),('segment','set','b'),('selector','set','a'),('button','press',''),('disclosure','collapse',''),('disclosure','expand',''),('tabs','set','about'),('tabs','set','live'),('tabs','set','colors'),('color/color/red','set','12'),('color/color/hex','set','#3567B580'),('tabs','set','live'),('tree:b3V0bGluZQ:row:bjA','press',''),('tree:b3V0bGluZQ:row:bjA','collapse',''),('tree:b3V0bGluZQ:row:bjA','expand',''),('text','set','Cocoa composed edit'),('dialog-open','press',''),('dialog-close','press',''),(breadcrumb('home'),'press',''),(breadcrumb('models'),'press',''),('tabs','set','selections'),('component-list','set','last'),('component-list','set','a'),('component-list','set','last'),('selection-left','press',''),('selection-right','press',''),('tabs','set','live')]

def validate(name,mode):
 require(mode=='full','mode')
 count,every,cooperative,watchdog=(5,5,'3m',240)if mode=='preflight'else(1000,25,'4h',14700)
 run=read(name+'.json');inputs=read(name+'-inputs.json');owned=read(name+'-owned-process.json')
 artifact=read('binary-'+mode+'.json');review=read('source-review.json');bn='native-build-v4'if mode=='preflight'else'native-build-committed';build=read(bn+'.json')
 require(review['result']=='APPROVED_SOURCE'and review['unresolved_findings']==[]and len(review['sources'])==4 and artifact['source_review_sha256']==sha(P/'source-review.json')and artifact['reviewed_sources']==review['sources'],'exact source approval')
 require(run['mode']==mode and run['result']=='TERMINAL_NATIVE_RUN_OK','run success')
 require(run['exit_code']==0 and run['error']is None and run['stop_reason']is None and run['cleanup_errors']==[],'terminal errors')
 require(all(run[k]is True for k in['direct_child_terminal','group_absence_confirmed','inputs_stable','binary_stable','logs_complete']),'terminal observations')
 require(run['stop_marker_at_exit']is False,'stop marker')
 require(type(run['pid'])is int and run['pid']>0 and run['process_group']==run['pid']==owned['pid']==owned['process_group'],'owned process')
 require(run['inputs_sha256']==sha(P/(name+'-inputs.json'))==owned['inputs_sha256'],'input binding')
 require(run['producer_sha256']==sha(P/'run_live.py')==owned['producer_sha256'],'producer binding')
 require(run['authorization_sha256']==sha(P/'live-authorization.json')==owned['authorization_sha256'],'authorization binding')
 require(run['binary_manifest_sha256']==sha(P/('binary-'+mode+'.json'))==owned['binary_manifest_sha256'],'binary manifest binding')
 require(run['build_receipt_sha256']==sha(P/(bn+'.json'))==artifact['build_receipt_sha256'],'build binding')
 require(artifact['capture_producer_sha256']==sha(P/'capture_build.py'),'capture producer')
 require(run['executable_sha256']==artifact['binary_sha256']==sha(artifact['binary']),'executed output identity')
 require(artifact['binary_bytes']==Path(artifact['binary']).stat().st_size>0,'output size')
 argv=[artifact['binary'],'-composed',f'-cycles={count}',f'-sample-every={every}',f'-timeout={cooperative}']
 if mode=='full':argv.append('-heap-profile='+str(P/(name+'.heap')))
 require(run['argv']==argv==owned['argv']and run['watchdog_seconds']==watchdog,'exact run plan')
 require(run['cwd']==build['cwd']==owned['cwd']==str(Path('/private/tmp/vellum-composed-controls/drivers/cogent')),'cwd')
 require(build['argv']==['go','build','-tags=vellum_native_checks','-o',artifact['binary'],'./cmd/window-cycle-smoke'],'build argv')
 require(build['producer_sha256']==sha(P/'code_run.py')and build['source_commit']==inputs['commit'],'build context')
 require(build['exit_code']==0 and build['error']is None and build['source_delta_stable']is True and build['source_delta_before']==build['source_delta_after'],'stable successful build')
 require(build['overlay_inputs_before']==build['overlay_inputs_after']=={},'no overlays')
 require(build['prepared_before']==build['prepared_after']==inputs['prepared']and len(inputs['prepared'])==6227,'prepared context')
 for leaf,h in build['source_delta_before'].items():require(inputs['delta'].get(leaf)==h,'build delta '+leaf)
 # A clean committed campaign may contain the reviewed leaves as tracked inputs.
 observed={**inputs['tracked'],**inputs['delta']}
 require(all(observed.get(n)==h for n,h in artifact['reviewed_sources'].items()),'reviewed source vector')
 if mode=='full':require(inputs['clean']is True and inputs['delta']=={} and build['source_delta_before']=={},'clean campaign')
 for ch in['stdout','stderr']:
  require(build[ch+'_sha256']==sha(P/(bn+'.'+ch)),'build '+ch)
  log=run['logs'][ch];f=P/(name+'.'+ch)
  require(log['sha256']==log['stream_sha256']==sha(f)and log['bytes']==f.stat().st_size,'complete '+ch)
 require(run['post_terminal_group_members']==[],'owned group empty')
 obs=run['group_observation']
 require(obs['argv']==['ps','-axo','pid=,pgid=,comm=']and obs['exit_code']==0 and obs['stdout_bytes']>0 and obs['stderr_bytes']==0 and obs['stderr_sha256']==hashlib.sha256(b'').hexdigest()and obs['stdout_sha256']==run['group_observation_sha256'],'process observation')
 events=[]
 for lineno,line in enumerate((P/(name+'.stdout')).read_text().splitlines(),1):
  if not line.strip():continue
  require(line.startswith('{'),f'non-JSON stdout line {lineno}')
  event=json.loads(line);require(type(event)is dict and event.get('event')in['vellum.native-action','vellum.composed-cycle','vellum.window-cycle.sample','vellum.window-cycle.result'],f'event {lineno}')
  events.append(event)
 cycles=[e for e in events if e['event']=='vellum.composed-cycle'];partials=[e for e in events if e['event']=='vellum.native-action'];results=[e for e in events if e['event']=='vellum.window-cycle.result'];samples=[e['sample']for e in events if e['event']=='vellum.window-cycle.sample']
 require(len(PLAN)==33 and len(cycles)==count and len(partials)==33*count and len(results)==1,'event counts')
 require([c['cycle']for c in cycles]==list(range(1,count+1)),'cycle sequence')
 for i,c in enumerate(cycles):
  require(c['native_action_plan']==2,'plan version')
  require(all(c[k]is True for k in['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible','native_list_rejected','native_breadcrumb_rejected','native_breadcrumb_truncated']),'cycle completed predicates')
  require(c['native_list_requests']==3 and c['native_canvas_selections']==2 and c['native_color_edits']==2 and c['native_breadcrumb_requests']==2 and c['native_tree_disclosures']==2 and c['tree_accessibility_rows']>0,'cycle controls')
  require(c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and c['full_p11_qualified']is False,'density/workload')
  require(rect(c['root_screen_points'])and rect(c['density_clip_screen_points']),'effective geometry')
  actions=c['native_actions'];require([(a['Target'],a['Kind'],a['Value'])for a in actions]==PLAN,'33 exact ordered tuples')
  pp=partials[i*33:(i+1)*33]
  require([p['action']for p in pp]==actions and all(p['window']==f'native-cycle-{i:04d}'for p in pp),'partial/full consistency')
  for a in actions:
   require(type(a['Attempts'])is int and type(a['Admissions'])is int and 1<=a['Admissions']<=a['Attempts'],'admission counts')
   require(a['OwnerAndNativeCompleted']is True and type(a['NativeRole'])is str and a['NativeRole']and 'AttachmentRetirement'not in a and 'FailureContext'not in a,'native action completion')
   require(number(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5.25,'bounded action wall time')
  for j,role in[(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton'),(27,'AXList'),(28,'AXList'),(29,'AXList'),(30,'AXButton'),(31,'AXButton')]:require(actions[j]['NativeRole']==role,'required native action role')
 result=results[0]
 require(events[-1]is result and result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['requested_cycles']==result['completed_cycles']==count and result['native_action_plan']==2,'final result')
 require(result['composed_workspace']is True and result['dense_labels_per_composed_window']==1000 and result['cooperative_timeout_seconds']==(180 if mode=='preflight'else 14400),'result plan')
 require(all(result[k]is False for k in['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed']),'scope flags')
 require(all(result[k]is True for k in['samples_after_forced_gc','geometry_persistence_disabled_in_fixture','historical_id_tombstones_retained']),'sample scope')
 clean=result['native_cleanup']
 require(all(clean[k]is True for k in['MainThread','CleanupObserved','CallbacksStopped'])and clean['WindowTitles']==[]and all(clean[k]==0 for k in['NativeOutstanding','AccessibilityWindows','PendingCallbacks','MenuCallbacks','TrayCallbacks']),'tracked native cleanup')
 require(all(type(w['Title'])is str and w['Title']==''and all(w[k]is False for k in['Visible','Miniaturized','Key','OcclusionVisible'])and type(w['Frame'])is list and len(w['Frame'])==4 and all(number(v)for v in w['Frame'])and w['Frame'][2]>=0 and w['Frame'][3]>=0 for w in clean['Windows']),'inactive untitled terminal windows')
 require(all(clean['FilePanels'][k]==0 for k in['Tracked','Visible','Open','Save']),'retired file panels')
 require(clean['Menu']['Owned']is False and clean['Menu']['OriginalRestored']is False and clean['Menu']['TargetRetired']is True and clean['Menu']['Items']==[],'retired menu; no restoration qualification')
 require(all(clean['Tray'][k]is False for k in['Present','Visible','Template'])and clean['Tray']['TargetRetired']is True and clean['Tray']['Identity']==0 and clean['Tray']['Items']==[]and all(clean['Tray'][k]==''for k in['Title','Tooltip','AccessibilityLabel'])and all(clean['Tray'][k]==0 for k in['ImageWidth','ImageHeight','PixelWidth','PixelHeight']),'retired tray')
 require(samples==result['samples']and [s['Completed']for s in samples]==list(range(0,count+1,every)),'sample agreement')
 require(result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20,'safety limits')
 require(all(type(s[k])is int and s[k]>0 for s in samples for k in['HeapAlloc','RSSBytes','Goroutines']),'sample values')
 require(all(s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 and number(s['ElapsedSeconds'])and s['ElapsedSeconds']>0 for s in samples),'sampled guards')
 require(all(a['ElapsedSeconds']<=b['ElapsedSeconds']for a,b in zip(samples,samples[1:])),'sample time ordering')
 require(result['heap_profile_requested']==(mode=='full'),'profile request')
 retries=[{'cycle':i+1,'step':j+1,'action':a}for i,c in enumerate(cycles)for j,a in enumerate(c['native_actions'])if a['Attempts']!=1 or a['Admissions']!=1]
 summary={'result':'PASS_FIVE_COMPOSED_CONTROLS_PREFLIGHT'if mode=='preflight'else'PASS_1000_COMPOSED_CONTROLS_CYCLES','mode':mode,'validated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validator_sha256':sha(__file__),'run_receipt_sha256':sha(P/(name+'.json')),'binary_manifest_sha256':sha(P/('binary-'+mode+'.json')),'inputs_sha256':run['inputs_sha256'],'base_commit':inputs['commit'],'cycles':count,'steps_per_cycle':33,'actions':count*33,'raw_events':len(events),'prepared_files':6227,'elapsed_seconds':run['elapsed_seconds'],'native_cleanup':clean,'hidden_inactive_untitled_native_windows':len(clean['Windows']),'zero_cocoa_windows_qualified':False,'menu_restoration_qualified':False,'direct_child_terminal':True,'owned_group_absence_confirmed':True,'total_attempts':sum(a['Attempts']for c in cycles for a in c['native_actions']),'total_admissions':sum(a['Admissions']for c in cycles for a in c['native_actions']),'queue_admissions_are_not_accepted_callbacks':True,'retry_cause_observed':False,'steps_with_retries':len(retries),'retries':retries,'sampled_go_heap_bytes':[min(s['HeapAlloc']for s in samples),max(s['HeapAlloc']for s in samples)],'sampled_rss_bytes':[min(s['RSSBytes']for s in samples),max(s['RSSBytes']for s in samples)],'terminal_sample':samples[-1],'tree_ax_row_counts':sorted(set(c['tree_accessibility_rows']for c in cycles)),'action_wall_time_seconds':{str(j+1)+':'+target+':'+kind:{'median':statistics.median(c['native_actions'][j]['ElapsedSeconds']for c in cycles),'max':max(c['native_actions'][j]['ElapsedSeconds']for c in cycles)}for j,(target,kind,value)in enumerate(PLAN)},'scope':'Actual Cocoa selectors with owner/publication predicates, exact workload and tracked service/visible-window retirement. Hidden untitled inactive windows are retained without attributed cause or zero-Cocoa-window/OS-global claims. Wall time includes inspection/waits, not frame or input latency. Sampled RSS does not attribute native/GPU allocation.','physical_input_qualified':False,'native_focus_reveal_qualified':False,'human_voiceover_qualified':False,'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False}
 if mode=='full':
  profile=P/(name+'.heap');require(0<profile.stat().st_size<=8<<20,'bounded profile');summary.update(heap_profile_sha256=sha(profile),heap_profile_bytes=profile.stat().st_size)
 return summary

if __name__=='__main__':
 name,mode=sys.argv[1:];out=P/(name+'-validation.json')
 try:result=validate(name,mode)
 except Exception as e:result={'result':'FAILED_VALIDATION','error':{'type':type(e).__name__,'message':str(e)},'validator_sha256':sha(__file__)}
 with out.open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k not in['action_wall_time_seconds','retries']}))
 sys.exit(1 if result['result']=='FAILED_VALIDATION'else 0)
