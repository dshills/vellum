from pathlib import Path
import datetime,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent
bundle=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-parent-graph-endurance/completed-20261016T085850Z')
out=p/'checkpoint-overlay/docs/reports/macos-parent-graph-endurance/records';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((bundle/'manifest.json').read_text())
assert manifest['result']=='PRESERVED_REVIEWED_COMPLETED_SCOPED_NATIVE_CASE'
inputs={}
for name,record in manifest['files'].items():
 data=(bundle/name).read_bytes();assert sha(data)==record['sha256']and len(data)==record['bytes']
 inputs['evidence/'+name]=data
inputs['evidence/manifest.json']=(bundle/'manifest.json').read_bytes()
for name in ['archive_completed.py','draft_report.py']:inputs['checkpoint-producers/'+name]=(p/name).read_bytes()
archive=out/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',format=tarfile.PAX_FORMAT,preset=6)as tar:
 for name,data in sorted(inputs.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600 if name.endswith('.heap')else 0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:xz')as tar:
 members=tar.getmembers();assert len(members)==len(inputs)
 assert all(m.isfile()and m.name in inputs for m in members)
 assert all(tar.extractfile(m).read()==inputs[m.name]for m in members)
index={'schema':'vellum-macos-composed-lifecycle-evidence-v1','archive':{'file':'evidence.tar.xz','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size},'member_count':len(inputs),'uncompressed_bytes':sum(map(len,inputs.values())),'members':{n:{'sha256':sha(b),'bytes':len(b)}for n,b in sorted(inputs.items())},'private_binary':manifest['private_binary'],'executables_excluded':True,'portable_replay_claimed':False}
with(out/'archive-index.json').open('x')as stream:stream.write(json.dumps(index,indent=2)+'\n')
sources=json.loads((p/'checkpoint-report-sources.json').read_text())
assert all(sha((p/'checkpoint-overlay'/n).read_bytes())==h for n,h in sources.items())
validation=json.loads((p/'window-thousand-validation.json').read_text())
qualification={'schema':'vellum-current-source-macos-composed-lifecycle-v1','result':'PREPARED_SCOPED_LIFECYCLE_EVIDENCE_CHECKPOINT','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executed_source_commit':validation['source_commit'],'checkpoint_sources':sources,'archive':index['archive'],'archive_index_sha256':sha((out/'archive-index.json').read_bytes()),'internal_evidence_review_sha256':sha((p/'completion-evidence-review.json').read_bytes()),'strict_validation_sha256':sha((p/'window-thousand-validation.json').read_bytes()),'validation_result':validation['result'],'cycles':1000,'actions':33000,'extra_queue_admissions':54,'source_tracked_files':4490,'prepared_files':6229,'recorded_and_fresh_owned_process_absence_checked':True,'zero_cocoa_windows_qualified':False,'original_menu_restoration_qualified':False,'professional_memory_qualified':False,'ordinary_frame_budget_qualified':False,'full_overnight_qualified':False,'physical_input_qualified':False,'human_accessibility_qualified':False,'full_mac_qualified':False,'report_source_review_pending':True,'provider_review_pending':True,'checkpoint_complete':False}
with(out/'qualification.json').open('x')as stream:stream.write(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'result':qualification['result'],'archive_bytes':archive.stat().st_size,'archive_sha256':index['archive']['sha256'],'members':len(inputs),'uncompressed_bytes':index['uncompressed_bytes'],'checkpoint_complete':False}))
