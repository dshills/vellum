from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
base=Path('/Users/dshills/Development/projects/Vellum');out=p/'checkpoint-overlay'
analysis=json.loads((p/'completion-analysis.json').read_text())
assert analysis['cycles']==1000 and analysis['actions']==33000 and analysis['extra_attempts']==54
report='''# Current-source Mac composed lifecycle check

The optimized executable from committed source `6330b2d42050b46c2019e558074e087ed281e56a`
completed 1,000 fresh composed windows and the exact version-2 plan of 33,000
acknowledged native/owner actions. The unchanged strict validator returns
`PASS_SCOPED_NATIVE_CASE`. The controller exited zero after 11,530.226 seconds
(about 3 hours 12 minutes), with no stop reason, error or cleanup error. Its
recorded group absence and a later independent process-table query both found
the exact owned PID/group 28898 absent. No other owned native or heavy build/test
job ran during this campaign; this does not establish continuous global host
isolation.

## What this covers

Each fresh window requires the current text/editor history, virtual grid and
outline completion, tree accessibility disclosure, modal open/close, color
controls, ListBox accepted/rejected/repeated selection proposals, named
Canvas2D selection and breadcrumb paths. Every cycle publishes the fixture's
1,000 fully contained dense-label predicates, with 15 exposed tree rows, before
teardown. List/canvas/tree native identities, generation and scope are checked
against owner publication by the bound fixture. These are native API and toolkit
routing observations. Requested 1920×1080 logical geometry and toolkit clipping
do not establish physical display size, occlusion, pixels or physical pointer
behavior. Earlier 24/26-step results do not substitute for this 33-step mix.

There are 33,054 queue attempts and admissions for 33,000 completed actions.
Fifty-four action records retry once, across 52 cycles: tabs 31, component-list
21, disclosure 2. Queue admissions are not accepted callback counts. Retry causes
were not observed, so no cause is assigned to the parent-graph optimization,
native input ordering, machine load or another actor. Action elapsed guards
include fixture settling/completion work and are not UI-frame or physical
input-to-present latency measurements.

The final main-thread snapshot records zero outstanding tracked native
operations, accessibility windows, file panels and pending callbacks; menu/tray
targets are retired. It also records one hidden, inactive, untitled Cocoa window
at `[0,446,54,54]`, and `Menu.OriginalRestored=false`. This does not qualify zero
Cocoa windows or original-menu restoration. The process subsequently exits and
fresh process/group absence is checked; the pre-exit hidden window is not claimed
to survive process exit. Clipboard access and preference changes are disabled
and reported false by the fixture; global OS state is outside this observation.

## Sampled memory and retained evidence

Forty-one forced-GC samples cover cycle 0 and every 25 completed cycles. Across
all samples, live Go heap ranges from 30,153,056 to 50,844,552 bytes and RSS from
184,909,824 to 403,210,240 bytes; goroutines range from 6 to 8 and end at 7. From
cycle 25 onward, Go heap ranges from 44,365,752 to 50,844,552 bytes and RSS from
373,866,496 to 403,210,240 bytes. RSS increases from 374,259,712 bytes at cycle 25
to 403,210,240 at cycle 1,000. These observations do not prove leak-free or
unbounded-retention behavior. Historical window-ID tombstones are retained.
The 512 MiB Go-heap/1 GiB RSS limits are safety guards. This composed interaction
fixture is not the empty 1,000-control baseline and does not qualify its
40 MiB/150 MiB budgets or attribute native/GPU/private bytes. The final Go heap
profile is 485,651 bytes; it is not a native/GPU allocation profile.

The native invocation uses `-composed -cycles=1000 -sample-every=25 -timeout=4h`
and the bounded heap-profile option, under the existing shared native lease and
human-return markers. The source-bound build records 4,490 tracked and 6,229
prepared dependency files, actual build metadata and an executable SHA-256.
Source, binary, pinned harness and raw-log stability are checked through cleanup.
The full stdout is 14,125,140 bytes with SHA-256
`53631800025ebfa04f14c64e82c3296379eecd3e5b73fcf2b07ced0be4ecdcb6`;
stderr is empty. The strict validator runs once after actual terminal evidence,
with exact event/action order, completions, geometry predicates, samples,
bindings, scope flags and cleanup checks. Internal review reports no unresolved
findings. The earlier controller-fault and failed-soak records remain preserved.

The raw trace/profile, receipts, producers, fixture context, source/build maps,
predecessor scheduling-failure evidence and internal review are indexed in
`records/archive-index.json` and retained in `records/evidence.tar.xz`. Private
executables are excluded and identified separately by receipts. Saved producers
retain original absolute paths; this is an evidence bundle, not a portable
replay or executable distribution. `records/qualification.json` binds the exact
scoped checkpoint and archive. No diagnostic draft added after source `6330b2d`
is qualified by this run.

## Remaining Mac work

This completes the current-source 33-step lifecycle execution gate only. The
original eight-hour soak remains failed (`soak occluded state drift`); a successful
overnight and full app-wide idle wake/present evidence remain required. The
ordinary 4 ms p95/6 ms p99 frame targets are still failed. Native/GPU memory,
physical pointer and display scaling, human IME/VoiceOver, interoperability,
distribution and full P4/P6/P9/P11/Mac acceptance remain open. Parent-graph
validation is outside exact TotalUIWork timing; this lifecycle run is not a
whole-frame performance comparison or proof of an ordinary latency gain.
'''
files={
 'docs/reports/macos-parent-graph-endurance/README.md':report,
 'docs/reports/README.md':(base/'docs/reports/README.md').read_text()+'\n- [Current-source composed lifecycle](macos-parent-graph-endurance/README.md): committed `6330b2d` completes 1,000 windows and the current 33,000-action plan; terminal/source/cleanup evidence is scoped separately from memory, performance, overnight and physical/human acceptance.\n',
 'specs/macos-completion.md':(base/'specs/macos-completion.md').read_text()+'''\n\n## Current-source composed lifecycle result\n\nThe [current-source lifecycle check](../docs/reports/macos-parent-graph-endurance/README.md)\ncompletes 1,000 fresh windows and all 33,000 version-2 native/owner actions on\ncommitted `6330b2d`, including the current ListBox and named Canvas2D paths.\nExact event order, completion predicates, density, sampled memory, source/build\nbindings, terminal cleanup and fresh owned-process absence are checked. Fifty-four\nactions retry once; the additional queue admissions have no observed cause and\nare not accepted callback counts. One hidden inactive untitled Cocoa window and\nfalse original-menu restoration remain explicit pre-exit limitations.\n\nThis closes that source's current 33-step execution gate, with no qualification\nfor native/GPU/private memory or unbounded retention, ordinary frame/input latency,\nphysical display/pointer or human accessibility. The failed overnight stays failed;\nfull idle, P4/P6/P9/P11, interoperability, distribution and Mac acceptance remain\nopen. Later source changes need their own appropriate runtime evidence.\n''',
 'specs/workbench-endurance.md':(base/'specs/workbench-endurance.md').read_text()+'''\n\nThe [committed `6330b2d` campaign](../docs/reports/macos-parent-graph-endurance/README.md)\nnow completes the current 1,000-window/33,000-action mix under that unchanged\nfour-hour bound, with 41 forced-GC samples and a bounded final Go heap profile.\nExact raw order, action/owner/native completion and source/cleanup bindings pass\nthe strict post-terminal validator. Fifty-four extra queue attempts/admissions\nremain separate from 33,000 completed actions; their causes were not observed.\nThe terminal snapshot retains one hidden inactive untitled Cocoa window and no\noriginal-menu-restoration proof. Sample ranges and a Go profile do not establish\nunbounded-retention, native/GPU/private allocation budgets or the empty-control\nbaseline. The original failed overnight remains failed. Physical/human, ordinary\nlatency, full idle/wake/present and P11/Mac requirements remain unchanged and open.\n'''
}
for name,text in files.items():
 path=out/name;path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x')as f:f.write(text)
manifest={name:hashlib.sha256((out/name).read_bytes()).hexdigest()for name in files}
(p/'checkpoint-report-sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'result':'DRAFTED_SCOPED_LIFECYCLE_REPORT_AND_SPEC_STATUS','files':len(files),'bytes':sum((out/n).stat().st_size for n in files),'canonical_source_modified':False}))
