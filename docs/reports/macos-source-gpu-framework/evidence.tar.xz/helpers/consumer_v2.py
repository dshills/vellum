"""Private Go builds against only the exact source-built static archive; never run a GPU."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654');Q=P/'consumer-v2';T=Path('/private/tmp/vellum-macos-native-results-97aee13');UP=T/'drivers/cogent/build/upstream'
s=importlib.util.spec_from_file_location('gpu_source_fetch',W/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g,sha,read,need=f.g,f.sha,f.read,f.need
STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
GO=Path('/opt/homebrew/bin/go').resolve();GOROOT=GO.parent.parent
LIB=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu/libs-darwin@v0.0.0-20260628152755-66a5dfa57f8d')
ROOTS={'gpu':['TestVellumRGBAUploadNativeRows','TestVellumTextureNativeOwnershipAndReadback','TestVellumStorageNativeReadback','TestVellumPipelineNativeOwnership'],'scene':['TestVellumGPUSceneNativeIntegerCompositor','TestVellumGPUSceneNativeSharedDrawerOrderAndFallback','TestVellumGPUSceneNativeActualTextAndPaths','TestVellumGPUSceneNativeCoveredUniforms','TestVellumGPUSceneNativeInputAttemptBytesFailureAndRecovery']}
def stopping():return STOP.exists()or(Q/'stop-build').exists()
def environment():
 return ['GOWORK=off','GOTOOLCHAIN=local','GOENV=off','GOFLAGS=','GOPROXY=off','GOSUMDB=off','GONOPROXY=','GONOSUMDB=','CGO_ENABLED=1','GOOS=darwin','GOARCH=arm64','GOMAXPROCS=2','GOCACHE='+str(Q/'go-cache'),'GOTMPDIR='+str(Q/'go-tmp'),'GOROOT='+str(GOROOT),'CC=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang','CGO_CFLAGS=','CGO_CPPFLAGS=','CGO_CXXFLAGS=','CGO_LDFLAGS=','MACOSX_DEPLOYMENT_TARGET=13.0','DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer','SDKROOT=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk']
def command(args):return ['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/usr/bin/env',*environment(),str(GO),*args]
def json_stream(data):
 out=[];decoder=json.JSONDecoder();index=0
 while index<len(data):
  while index<len(data)and data[index].isspace():index+=1
  if index==len(data):break
  value,index=decoder.raw_decode(data,index);out.append(value)
 return out

def prepare():
 need(not Q.exists()and not(W/'consumer-v2-plan.json').exists(),'new private Go preparation')
 build=read(W/'build-receipt.json');need(build['result']=='PASS_OWN_PINNED_SOURCE_WGPU_BUILD_AND_PROBES'and not build['error']and not build['finalization_errors'],'terminal source-built archive')
 static=[a for a in build['artifacts']if a['path'].endswith('.a')];need(len(static)==1 and sha(static[0]['path'])==static[0]['sha256'],'exact static artifact')
 Q.mkdir(mode=0o700);(Q/'go-tmp').mkdir(mode=0o700);module=Q/'libs-darwin';(module/'arm64').mkdir(parents=True,mode=0o700)
 for name in ['go.mod','libs.go']:(module/name).write_bytes((LIB/name).read_bytes())
 (module/'arm64/libwgpu_native.a').write_bytes(Path(static[0]['path']).read_bytes())
 text=(UP/'go.mod').read_text();old='replace github.com/go-text/typesetting => ../typesetting';need(text.count(old)==1,'exact private typesetting replacement')
 (Q/'consumer.mod').write_text(text.replace(old,'replace github.com/go-text/typesetting => '+str(UP.parent/'typesetting'))+'\nreplace github.com/oliverbestmann/webgpu/libs-darwin => '+str(module)+'\n');(Q/'consumer.sum').write_bytes((UP/'go.sum').read_bytes())
 (Q/'version').mkdir();(Q/'version/main.go').write_text('package main\nimport("encoding/json";"os";"github.com/oliverbestmann/webgpu/wgpu")\nfunc main(){v:=uint32(wgpu.GetVersion());if v!=0x1d000101{panic("unexpected static WGPU version")};if err:=json.NewEncoder(os.Stdout).Encode(map[string]uint32{"version":v});err!=nil{panic(err)}}\n')
 pins=dict(read(W/'build-readiness.json')['inputs']);pins.update({str(W/name):sha(W/name)for name in ['build-receipt.json','consumer_v2.py']})
 for root in [GOROOT,Q/'libs-darwin',Q/'version']:
  for p in root.rglob('*'):
   if p.is_file():pins[str(p)]=sha(p)
 for name in ['consumer.mod','consumer.sum']:pins[str(Q/name)]=sha(Q/name)
 pins['/opt/homebrew/bin/go']=sha('/opt/homebrew/bin/go')
 stable=lambda:all(sha(p)==h for p,h in pins.items());commands=[]
 for label,args in [('go-version',['version']),('go-packages',['list','-mod=readonly','-modfile='+str(Q/'consumer.mod'),'-tags=offscreen','-deps','-test','-json','./gpu','./paint/renderers/gpuscene'])]:
  run=g.execute(command(args),UP,Q/label,stopping,stable,timeout=180,limit=8<<20);commands.append(dict(label=label,run=run));need(f.terminal(run),'owned Go metadata '+label)
 packages=json_stream((Q/'go-packages/stdout').read_text());need(packages and all(not p.get('Incomplete')and not p.get('Error')and not p.get('DepsErrors')for p in packages),'complete Go dependency listing')
 fields=['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles','TestEmbedFiles','XTestEmbedFiles']
 for package in packages:
  directory=Path(package['Dir'])if package.get('Dir')else None
  for field in fields:
   for name in package.get(field,[]):
    p=Path(name)if Path(name).is_absolute()else directory/name
    need(p.is_file(),'listed Go source exists '+str(p));pins[str(p)]=sha(p)
  module_info=package.get('Module')or{};module_info=module_info.get('Replace')or module_info
  if module_info.get('GoMod'):
   p=Path(module_info['GoMod']);need(p.is_file(),'module manifest exists');pins[str(p)]=sha(p)
 jobs=[]
 for label,target in [('version',str(Q/'version/main.go')),('gpu','./gpu'),('scene','./paint/renderers/gpuscene')]:
  binary=Q/(label+'.test'if label!='version'else'version-probe');linkmap=Q/(label+'.linkmap');args=['build']if label=='version'else['test','-c'];args+=['-mod=readonly','-modfile='+str(Q/'consumer.mod'),'-tags=offscreen','-p=2','-buildvcs=true','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',str(binary),target];jobs.append(dict(label=label,argv=command(args),binary=str(binary),linkmap=str(linkmap)))
 plan=dict(result='PREPARED_PRIVATE_STATIC_GO_CONSUMER',inputs=pins,commands=commands,jobs=jobs,go=str(GO),go_version=(Q/'go-version/stdout').read_text().strip(),package_count=len(packages),static_archive=static[0],static_module=str(module),native_application_started=False,gpu_executed=False,shipped_library_changed=False,roots=ROOTS)
 with(W/'consumer-v2-plan.json').open('x')as out:out.write(json.dumps(plan,indent=2)+'\n')
 print(json.dumps({k:v for k,v in plan.items()if k not in['inputs','commands','jobs']}))

def validate_linkmap(data,module):
 if isinstance(data,str):data=data.encode('utf-8')
 need(type(data)is bytes and 0<len(data)<=32<<20,'bounded raw linker map')
 need(data.count(b'# Object files:')==1 and data.count(b'# Sections:')==1,'one ordered linker object table')
 before,after=data.split(b'# Object files:',1);objects,sections=after.split(b'# Sections:',1)
 table=objects.decode('utf-8');lines=[line for line in table.splitlines()if 'libwgpu_native'in line]
 need(lines and all(str(Path(module)/'arm64/libwgpu_native.a')+'('in line for line in lines),'only private static archive native object entries')
 need(b'_wgpuGetVersion'in sections,'native version symbol linked');return len(lines)
def validate_links(text):need('libwgpu_native.dylib'not in text and'libwgpu_native.a'not in text,'no runtime native WGPU library dependency')

def build():
 need(not(W/'consumer-v2-build.json').exists()and not(Q/'stop-build').exists(),'new one-shot private consumer build')
 plan=read(W/'consumer-v2-plan.json');review=read(W/'consumer-v2-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'separate consumer build review');need(str(GO)==plan['go'],'planned Go executable identity');pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',inputs=pins,commands=[],binaries=[],error=None,finalization_errors=[],native_application_started=False,gpu_executed=False)
 try:
  need(not stopping()and stable(),'consumer admission')
  with g.LiveLease()as lease:
   need(lease.held(),'machine lease')
   for job in plan['jobs']:
    label=job['label'];binary=Path(job['binary']);need(not binary.exists()and not Path(job['linkmap']).exists(),'fresh consumer outputs')
    run=g.execute(job['argv'],UP,Q/('build-'+label),stopping,stable,timeout=600,limit=8<<20);d['commands'].append(dict(label='build-'+label,run=run));need(f.terminal(run),'owned consumer build '+label);need(binary.is_file()and not binary.is_symlink()and 0<binary.stat().st_size<128<<20,'bounded consumer binary');pins[str(binary)]=sha(binary);pins[job['linkmap']]=sha(job['linkmap'])
    for suffix,args in [('links',['/usr/bin/otool','-L',str(binary)]),('metadata',[str(GO),'version','-m',str(binary)]),('load-commands',['/usr/bin/otool','-l',str(binary)])]:
     run=g.execute(args,UP,Q/(label+'-'+suffix),stopping,stable,timeout=30,limit=2<<20);d['commands'].append(dict(label=label+'-'+suffix,run=run));need(f.terminal(run),'consumer probe '+label+' '+suffix)
    validate_links((Q/(label+'-links/stdout')).read_text());need('minos 13.0'in(Q/(label+'-load-commands/stdout')).read_text(),'Go consumer declared minimum macOS13.0');objects=validate_linkmap(Path(job['linkmap']).read_bytes(),plan['static_module']);metadata=(Q/(label+'-metadata/stdout')).read_text();need('=>\t'+plan['static_module']+'\t'in metadata,'private Go replacement embedded');d['binaries'].append(dict(label=label,path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary),native_archive_object_entries=objects))
   run=g.execute(['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)',str(Q/'version-probe')],Q,Q/'static-version',stopping,stable,timeout=30,limit=1<<20);d['commands'].append(dict(label='static-version',run=run));need(f.terminal(run)and read(Q/'static-version/stdout')=={'version':0x1d000101},'Go static library version')
   need(stable()and not stopping()and lease.held(),'terminal consumer closure');d['result']='PASS_PRIVATE_STATIC_GO_BUILD_AND_VERSION_NO_GPU_EXECUTION'
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
 finally:
  try:(Q/'stop-build').touch()
  except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  try:print(json.dumps({**{k:v for k,v in d.items()if k not in['inputs','commands']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
  except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
  try:
   with(W/'consumer-v2-build.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
 need(d['error']is None and not d['finalization_errors'],'consumer build failed')
if __name__=='__main__':
 need(sys.argv[1:]in[['prepare'],['build']],'fixed phase');prepare()if sys.argv[1]=='prepare'else build()
