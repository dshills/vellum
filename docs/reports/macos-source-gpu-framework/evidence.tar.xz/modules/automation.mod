module github.com/dshills/vellum/examples/automation

go 1.25.6

require github.com/dshills/vellum v0.0.0

replace github.com/dshills/vellum => /private/tmp/vellum-macos-native-results-97aee13
