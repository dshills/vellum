"""Private source-archive workbench build and safe public-client native checks."""
from pathlib import Path
import datetime
import importlib.util
import json
import re
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = Path('/private/tmp/vellum-source-gpu-framework-7829cfc')
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
HEAD = '7829cfc9f1a0dc9e4d63b20d18a58a7292cbc4fa'
STOP = Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
PREVIOUS = W.parent / 'macos-source-built-gpu-276a654'
spec = importlib.util.spec_from_file_location('source_gpu_consumers', PREVIOUS / 'consumer_v2.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
g, sha, read, need = v.g, v.sha, v.read, v.need
GO = Path('/opt/homebrew/bin/go').resolve()
GOROOT = GO.parent.parent
ARCHIVE = Path('/private/tmp/vellum-source-built-gpu-276a654/build-target-v1/aarch64-apple-darwin/release/libwgpu_native.a')
ARCHIVE_SHA = '786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
MODULE = P / 'libs-darwin'
CASES = [100000, 1000000]


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, timeout=20)


def clean():
    for root in [T, C]:
        need(git(root, 'rev-parse', 'HEAD').decode().strip() == HEAD and
             not git(root, 'status', '--porcelain', '-z'), 'clean exact checkout')


def tree(root):
    result = {}
    for p in root.rglob('*'):
        need(not p.is_symlink(), 'regular tree ' + str(p))
        if p.is_file():
            result[str(p)] = sha(p)
    return result


def snapshot():
    clean()
    pins = {}
    parity = []
    for root in [T, C]:
        names = git(root, 'ls-files', '-z').decode().split('\0')[:-1]
        need(len(names) == 4712, 'tracked source count')
        tracked = {}
        for name in names:
            p = root / name
            need(p.is_file() and not p.is_symlink(), 'regular tracked source')
            tracked[name] = sha(p)
            pins[str(p)] = tracked[name]
        prepared = {}
        for name in ['upstream', 'typesetting']:
            for path, digest in tree(root / 'drivers/cogent/build' / name).items():
                prepared[str(Path(path).relative_to(root / 'drivers/cogent/build'))] = digest
                pins[path] = digest
        need(len(prepared) == 6249, 'prepared source count')
        parity.append((tracked, prepared))
    need(parity[0] == parity[1], 'complete source/prepared parity')
    return pins


def stable(pins):
    return all(Path(p).is_file() and sha(p) == digest for p, digest in pins.items())


def stopped(phase):
    return STOP.exists() or (P / ('stop-' + phase)).exists()


def environment():
    return [
        'GOWORK=off', 'GOTOOLCHAIN=local', 'GOENV=off', 'GOFLAGS=',
        'GOPROXY=off', 'GOSUMDB=off', 'GONOPROXY=', 'GONOSUMDB=',
        'CGO_ENABLED=1', 'GOOS=darwin', 'GOARCH=arm64', 'GOMAXPROCS=2',
        'GOCACHE=' + str(P / 'go-cache'), 'GOTMPDIR=' + str(P / 'go-tmp'),
        'GOROOT=' + str(GOROOT),
        'CC=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang',
        'CGO_CFLAGS=', 'CGO_CPPFLAGS=', 'CGO_CXXFLAGS=', 'CGO_LDFLAGS=',
        'MACOSX_DEPLOYMENT_TARGET=13.0',
        'DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer',
        'SDKROOT=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk',
    ]


def go(args):
    return ['/usr/bin/sandbox-exec', '-p', '(version 1)(allow default)(deny network*)',
            '/usr/bin/env', *environment(), str(GO), *args]


def exclusive(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def prepare():
    need(not P.exists() and not (W / 'plan.json').exists(), 'fresh preparation')
    need(not STOP.exists(), 'human-away admission')
    pins = snapshot()
    need(sha(ARCHIVE) == ARCHIVE_SHA and ARCHIVE.stat().st_size == 37401760,
         'exact source-built archive')
    pins[str(ARCHIVE)] = ARCHIVE_SHA
    P.mkdir(mode=0o700)
    for name in ['go-tmp', 'modules', 'native-tmp']:
        (P / name).mkdir(mode=0o700)
    (MODULE / 'arm64').mkdir(parents=True, mode=0o700)
    for name in ['go.mod', 'libs.go']:
        (MODULE / name).write_bytes((v.LIB / name).read_bytes())
    (MODULE / 'arm64/libwgpu_native.a').write_bytes(ARCHIVE.read_bytes())
    jobs = []
    for name, cwd, target, replacements in [
        ('workbench', T / 'drivers/cogent', './cmd/workbench', {
            '../..': T, './build/upstream': T / 'drivers/cogent/build/upstream',
            './build/typesetting': T / 'drivers/cogent/build/typesetting'}),
        ('automation', T / 'examples/automation', '.', {'../..': T}),
    ]:
        text = (cwd / 'go.mod').read_text()
        for old, new in replacements.items():
            needle = '=> ' + old
            need(text.count(needle + '\n') == 1, 'one exact module replacement')
            text = text.replace(needle + '\n', '=> ' + str(new) + '\n')
        if name == 'workbench':
            text += '\nreplace github.com/oliverbestmann/webgpu/libs-darwin => ' + str(MODULE) + '\n'
        mod = P / 'modules' / (name + '.mod')
        mod.write_text(text)
        if (cwd / 'go.sum').exists():
            mod.with_suffix('.sum').write_bytes((cwd / 'go.sum').read_bytes())
        args = ['build', '-mod=readonly', '-modfile=' + str(mod), '-p=2', '-buildvcs=true',
                '-ldflags=-linkmode=external -extldflags=-Wl,-map,' + str(P / (name + '.linkmap')),
                '-o', str(P / name), target]
        jobs.append(dict(name=name, cwd=str(cwd), argv=go(args),
                         binary=str(P / name), linkmap=str(P / (name + '.linkmap')), modfile=str(mod)))
    for root in [GOROOT, MODULE, P / 'modules']:
        # Go's installed tree may contain deliberate symlinks; pin logical bytes.
        for p in root.rglob('*'):
            if p.is_file():
                pins[str(p)] = sha(p)
    for p in [Path(__file__), PREVIOUS / 'consumer_v2.py', PREVIOUS / 'fetch_dependencies.py',
              W.parent / 'macos-sdk-native-238b3b6/run.py',
              T / 'scripts/child_process.py', T / 'scripts/sdk_environment.py',
              Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),
              Path('/opt/homebrew/bin/go'), GO,
              Path('/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang')]:
        pins[str(p)] = sha(p)
    commands = []
    for job in jobs:
        name = job['name']
        run = g.execute(go(['list', '-mod=readonly', '-modfile=' + job['modfile'], '-deps', '-json',
                            './cmd/workbench' if name == 'workbench' else '.']),
                        Path(job['cwd']), P / (name + '-packages'),
                        lambda: stopped('build'), lambda: stable(pins), timeout=180, limit=16 << 20)
        commands.append(dict(name=name + '-packages', run=run))
        need(v.f.terminal(run), 'owned offline package listing')
        packages = v.json_stream((P / (name + '-packages/stdout')).read_text())
        need(packages and all(not p.get('Incomplete') and not p.get('Error') and
                              not p.get('DepsErrors') for p in packages), 'complete package listing')
        for package in packages:
            directory = Path(package['Dir']) if package.get('Dir') else None
            for field in ['GoFiles', 'CgoFiles', 'CFiles', 'CXXFiles', 'MFiles', 'HFiles',
                          'FFiles', 'SFiles', 'SysoFiles', 'EmbedFiles']:
                for name in package.get(field, []):
                    p = Path(name) if Path(name).is_absolute() else directory / name
                    need(p.is_file(), 'listed source exists')
                    pins[str(p)] = sha(p)
            module = package.get('Module') or {}
            module = module.get('Replace') or module
            if module.get('GoMod'):
                pins[module['GoMod']] = sha(module['GoMod'])
        job['packages'] = len(packages)
    # The C binding includes generated headers that are not enumerated by go list.
    binding = Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu@v1.36.1-0.20261006093257-de8bdd5d5976/wgpu')
    pins.update(tree(binding))
    need(stable(pins) and not stopped('build'), 'preparation terminal identity')
    exclusive(W / 'plan.json', dict(source_commit=HEAD, inputs=pins, jobs=jobs, commands=commands,
                                  go=str(GO), static_module=str(MODULE), archive_sha256=ARCHIVE_SHA,
                                  cases=CASES, shipped_library_changed=False, native_runtime_started=False))
    print(json.dumps(dict(status='PREPARED', packages={j['name']: j['packages'] for j in jobs},
                          pins=len(pins), native_runtime_started=False)))


def linkmap(data, module, expected):
    need(type(data) is bytes and 0 < len(data) <= 32 << 20, 'bounded linker map')
    need(data.count(b'# Object files:') == 1 and data.count(b'# Sections:') == 1, 'one linker object table')
    table = data.split(b'# Object files:', 1)[1].split(b'# Sections:', 1)[0].decode('utf8')
    objects = [line for line in table.splitlines() if 'libwgpu_native' in line]
    if expected:
        need(objects and all(str(module / 'arm64/libwgpu_native.a') + '(' in line for line in objects),
             'all WGPU objects from exact private static library')
    else:
        need(not objects, 'stdlib public client has no native WGPU objects')
    return len(objects)


def metadata(data, name):
    info = json.loads(data)
    settings = {s['Key']: s['Value'] for s in info['Settings']}
    need(info['GoVersion'] == 'go1.27.2' and settings['vcs.revision'] == HEAD and
         settings['vcs.modified'] == 'false' and settings['GOARCH'] == 'arm64',
         'clean compiled Go/source identity')
    replacements = [m.get('Replace', {}).get('Path') for m in info.get('Deps', [])
                    if m['Path'] == 'github.com/oliverbestmann/webgpu/libs-darwin']
    need(replacements == ([str(MODULE)] if name == 'workbench' else []), 'embedded native module lineage')


def finish(phase, receipt, d):
    d['finalization_errors'] = []
    try:
        (P / ('stop-' + phase)).touch()
        d['local_stop_present'] = True
    except BaseException as error:
        d['finalization_errors'].append(dict(stage='seal', type=type(error).__name__))
    d['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    d['result'] = ('PASS_' + phase.upper()) if d['error'] is None and not d['finalization_errors'] else 'FAILED_' + phase.upper()
    try:
        print(json.dumps(dict(result='PENDING_EXCLUSIVE_RECEIPT', error=d['error'],
                              phase=phase, finalization_errors=d['finalization_errors'])), flush=True)
    except BaseException as error:
        d['finalization_errors'].append(dict(stage='report', type=type(error).__name__))
        d['result'] = 'FAILED_' + phase.upper()
    try:
        exclusive(W / receipt, d)
    except BaseException as error:
        d['finalization_errors'].append(dict(stage='receipt', type=type(error).__name__))
        d['result'] = 'FAILED_' + phase.upper()
    need(d['error'] is None and not d['finalization_errors'], 'phase failed')


def build():
    review = read(W / 'build-readiness.json')
    need(review['execution_ready'] is True and review['unresolved_findings'] == [], 'independent build readiness')
    plan = read(W / 'plan.json')
    need(str(GO) == plan['go'] and not (W / 'build.json').exists() and not stopped('build'), 'fresh pinned build')
    pins = dict(review['inputs'])
    d = dict(source_commit=HEAD, commands=[], binaries=[], error=None, inputs=pins,
             native_runtime_started=False, shipped_library_changed=False)
    try:
        with g.LiveLease() as lease:
            need(lease.held(), 'owned machine lease')
            clean()
            for job in plan['jobs']:
                name = job['name']
                need(not Path(job['binary']).exists() and not Path(job['linkmap']).exists(), 'new binary/map')
                run = g.execute(job['argv'], Path(job['cwd']), P / ('build-' + name),
                                lambda: stopped('build'), lambda: stable(pins), timeout=900, limit=8 << 20)
                d['commands'].append(dict(name='build-' + name, run=run))
                need(v.f.terminal(run) and not (P / ('build-' + name + '/stderr')).read_bytes(), 'clean owned build')
                binary = Path(job['binary'])
                need(binary.is_file() and not binary.is_symlink() and 0 < binary.stat().st_size < 128 << 20, 'bounded binary')
                pins[str(binary)] = sha(binary)
                pins[job['linkmap']] = sha(job['linkmap'])
                for suffix, args in [
                    ('links', ['/usr/bin/otool', '-L', str(binary)]),
                    ('metadata', [str(GO), 'version', '-m', '-json', str(binary)]),
                    ('load', ['/usr/bin/otool', '-l', str(binary)]),
                ]:
                    run = g.execute(args, T, P / (name + '-' + suffix), lambda: stopped('build'),
                                    lambda: stable(pins), timeout=30, limit=2 << 20)
                    d['commands'].append(dict(name=name + '-' + suffix, run=run))
                    need(v.f.terminal(run) and not (P / (name + '-' + suffix + '/stderr')).read_bytes(), 'terminal binary probe')
                v.validate_links((P / (name + '-links/stdout')).read_text())
                need('minos 13.0' in (P / (name + '-load/stdout')).read_text(), 'consumer minimum macOS13.0')
                metadata((P / (name + '-metadata/stdout')).read_bytes(), name)
                count = linkmap(Path(job['linkmap']).read_bytes(), MODULE, name == 'workbench')
                d['binaries'].append(dict(name=name, path=str(binary), bytes=binary.stat().st_size,
                                          sha256=sha(binary), private_archive_object_entries=count))
            clean()
            need(stable(pins) and not stopped('build') and lease.held(), 'terminal build closure')
    except BaseException as error:
        d['error'] = dict(type=type(error).__name__, message=str(error))
    finally:
        finish('build', 'build.json', d)


def safe_summary(stdout, stderr, rows):
    need(not stderr, 'controller stderr empty')
    expected = dict(status='PASS', rows=rows, requests=40, native_ready=True,
                    transport_joined=True, endpoint_removed=True, post_close_refused=True,
                    raw_native_output_published=False)
    need(stdout == json.dumps(expected, separators=(',', ':')).encode() + b'\n', 'exact safe summary')
    return expected


def native():
    review = read(W / 'native-readiness.json')
    need(review['execution_ready'] is True and review['unresolved_findings'] == [], 'independent native readiness')
    built = read(W / 'build.json')
    need(built['result'] == 'PASS_BUILD' and not built['error'] and not built['finalization_errors'], 'complete private build')
    need(not (W / 'native.json').exists() and not stopped('live'), 'one-shot native campaign')
    pins = review['inputs']
    binaries = {b['name']: b['path'] for b in built['binaries']}
    d = dict(source_commit=HEAD, cases=[dict(rows=rows, execution='not_started') for rows in CASES],
             error=None, physical_input_generated=False, settings_changes=False,
             raw_native_output_published=False, saved_per_call_DTOs=False, full_macos_qualified=False,
             evidence_scope='Source-reviewed public client assertions and safe scalar summaries; no retained raw DTOs or pixels.')
    try:
        with g.LiveLease() as lease:
            for case in d['cases']:
                need(lease.held() and stable(pins) and not stopped('live'), 'per-case admission')
                clean()
                rows = case['rows']
                out = P / ('native-' + str(rows))
                run = g.execute(['/usr/bin/env', 'TMPDIR=' + str(P / 'native-tmp'), binaries['automation'],
                                 '-workbench', binaries['workbench'], '-rows=' + str(rows)],
                                T / 'examples/automation', out, lambda: stopped('live'),
                                lambda: stable(pins), timeout=60, limit=1 << 20)
                case['run'] = run
                if run['created']:
                    case['execution'] = 'unknown_may_have_started'
                need(v.f.terminal(run), 'owned native client/group complete')
                case['summary'] = safe_summary((out / 'stdout').read_bytes(), (out / 'stderr').read_bytes(), rows)
                case['execution'] = 'confirmed_by_safe_client_summary'
                need(not list((P / 'native-tmp').glob('vellum-api-*')), 'private API temp directories removed')
                clean()
                need(stable(pins) and not stopped('live'), 'per-case terminal stability')
                print(json.dumps(dict(rows=rows, requests=40, result='PASS', seconds=run['seconds'])), flush=True)
            need(all(c['execution'] == 'confirmed_by_safe_client_summary' for c in d['cases']) and
                 lease.held() and stable(pins) and not stopped('live'), 'both exact cases and terminal guards')
            d['lease_held_through_cleanup'] = True
    except BaseException as error:
        d['error'] = dict(type=type(error).__name__, message=str(error))
    finally:
        finish('live', 'native.json', d)


if __name__ == '__main__':
    need(sys.argv[1:] in [['prepare'], ['build'], ['native']], 'fixed phase')
    {'prepare': prepare, 'build': build, 'native': native}[sys.argv[1]]()
