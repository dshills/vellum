"""Controls of the actual continuation state machine; no compiler/native child."""
from pathlib import Path
import contextlib
import copy
import importlib.util
import io
import json
import tempfile
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('framework_continuation_controls', W / 'framework_v2.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
passed = []


def rejects(label, call):
    try:
        call()
    except ValueError:
        passed.append(label)
        return
    raise AssertionError(label + ' accepted')


original = v.read(W / 'build.json')
v.validate_original_compile(original)
passed.append('exact-preserved-warning-bearing-compile')
for label, mutate in [
    ('failed-compiler-refused', lambda d: d['commands'][0]['run'].update(exit_code=1)),
    ('unowned-compiler-refused', lambda d: d['commands'][0]['run']['owned'].update(group_absent=False)),
    ('different-warning-receipt-refused', lambda d: d['commands'][0]['run']['logs']['stderr'].update(sha256='0' * 64)),
]:
    changed = copy.deepcopy(original)
    mutate(changed)
    rejects(label, lambda: v.validate_original_compile(changed))
old_sha = v.sha
v.sha = lambda path: '0' * 64 if Path(path).name == 'stderr' else old_sha(path)
rejects('changed-raw-warning-bytes-refused', lambda: v.validate_original_compile(original))
v.sha = old_sha

with tempfile.TemporaryDirectory(prefix='vellum-framework-v2-control-') as temporary:
    root = Path(temporary)
    v.W = v.Q = v.h.W = v.h.P = root
    v.h.STOP = root / 'universal-stop'
    v.h.clean = lambda: None
    v.h.stable = lambda pins: True
    (root / 'native-tmp').mkdir()
    (root / 'native-v2-readiness.json').write_text(json.dumps(dict(execution_ready=True, unresolved_findings=[], inputs={})))
    (root / 'build-v2.json').write_text(json.dumps(dict(result='PASS_BUILD-V2', error=None, finalization_errors=[],
        binaries=[dict(name='automation', path='/control/client'), dict(name='workbench', path='/control/workbench')])) )

    class Lease:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def held(self): return True

    def execute(argv, cwd, out, *args, **kwargs):
        out.mkdir()
        first = out.name == 'native-100000'
        summary = dict(status='PASS', rows=100000, requests=40, native_ready=True, transport_joined=True,
                       endpoint_removed=True, post_close_refused=True, raw_native_output_published=False)
        (out / 'stdout').write_bytes((json.dumps(summary, separators=(',', ':')) + '\n').encode() if first else b'')
        (out / 'stderr').write_bytes(b'')
        return dict(created=True, error=None if first else dict(type='ControlFailure'), exit_code=0 if first else 1,
                    observation_errors=[], logs_complete=True, pins_stable=True, stop_at_exit=False,
                    owned=dict(terminal=True, group_absent=True, errors=[]), seconds=0)

    v.g.LiveLease = Lease
    v.g.execute = execute
    with contextlib.redirect_stdout(io.StringIO()):
        rejects('v2-failed-second-case-fails-campaign', v.native)
    receipt = v.read(root / 'native-v2.json')
    assert receipt['result'] == 'FAILED_LIVE-V2' and receipt['error'] and not receipt['finalization_errors']
    assert [c['execution'] for c in receipt['cases']] == ['confirmed_by_safe_client_summary', 'unknown_may_have_started']
    assert receipt['local_stop_present'] and (root / 'stop-live-v2').exists()
    passed += ['v2-first-confirmation-survives-second-failure', 'v2-failed-campaign-sealed-and-saved']

result = dict(result='PASS_SYNTHETIC_V2_CONTROLS', count=len(passed), controls=passed,
              compiler_started=False, native_runtime_started=False)
with (W / 'controls-v2.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
