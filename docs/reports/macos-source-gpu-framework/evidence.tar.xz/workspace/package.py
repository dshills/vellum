"""Package this private integration evidence after independent result review."""
from pathlib import Path
import hashlib
import io
import json
import tarfile
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = Path('/private/tmp/vellum-source-gpu-framework-7829cfc')
Q = P / 'continuation-v3'
R = W / 'report'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())


def need(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    need(len(sys.argv) == 1 and not R.exists(), 'fresh evidence package')
    review_body = (W / 'result-review.json').read_bytes()
    review_sha = hashlib.sha256(review_body).hexdigest()
    review = json.loads(review_body)
    need(review['report_ready'] is True and review['unresolved_findings'] == [], 'independent result review')
    need(all(sha(p) == h for p, h in review['inputs'].items()), 'reviewed evidence bytes')
    build, native, plan = [read(W / n) for n in ['build-v3.json', 'native-v3.json', 'plan.json']]
    continuation = read(W / 'plan-v3.json')
    need(build['result'] == 'PASS_BUILD-V3' and native['result'] == 'PASS_LIVE-V3' and
         all(d['error'] is None and d['finalization_errors'] == [] for d in [build, native]), 'terminal results')
    need([c['rows'] for c in native['cases']] == [100000, 1000000] and
         all(c['execution'] == 'confirmed_by_safe_client_summary' and c['summary']['requests'] == 40
             for c in native['cases']), 'both confirmed cases')
    entries = {}

    def add(name, path):
        path = Path(path)
        need(name not in entries and path.is_file() and not path.is_symlink(), 'regular unique evidence')
        entries[name] = path

    for name in ['framework.py', 'controls.py', 'controls.json', 'preparation.json', 'plan.json',
                 'build-readiness.json', 'build.json', 'framework_v2.py', 'controls_v2.py',
                 'controls-v2.json', 'plan-v2.json', 'build-v2-readiness.json', 'build-v2.json',
                 'framework_v3.py', 'controls_v3.py', 'controls-v3.json', 'controls-v3-final.json',
                 'plan-v3.json', 'plan-v3-before-identity-strengthening.json',
                 'framework_v3-before-identity-strengthening.py', 'plan-v3-amendment.json',
                 'build-v3-readiness.json', 'build-v3.json', 'native-v3-readiness.json', 'native-v3.json',
                 'result-review.json', 'README.final.md', 'package.py']:
        add('workspace/' + name, W / name)
    helpers = {
        'consumer_v2.py': W.parent / 'macos-source-built-gpu-276a654/consumer_v2.py',
        'fetch_dependencies.py': W.parent / 'macos-source-built-gpu-276a654/fetch_dependencies.py',
        'owned_process.py': W.parent / 'macos-sdk-native-238b3b6/run.py',
        'child_process.py': Path('/private/tmp/vellum-macos-native-results-97aee13/scripts/child_process.py'),
        'sdk_environment.py': Path('/private/tmp/vellum-macos-native-results-97aee13/scripts/sdk_environment.py'),
        'live_lease.py': Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),
    }
    for name, path in helpers.items():
        add('helpers/' + name, path)
    commands = [(command, P) for command in plan['commands'] + read(W / 'build.json')['commands']]
    commands += [(command, P / 'continuation-v2') for command in read(W / 'build-v2.json')['commands']]
    commands += [(command, Q) for command in build['commands']]
    commands += [(dict(name='native-' + str(case['rows']), run=case['run']), Q) for case in native['cases']]
    for command, root in commands:
        # The controller logs contain only safe summaries; its child streams remain in memory.
        out = root / command['name']
        for name in ['stdout', 'stderr', 'owned.json']:
            add('runs/' + out.relative_to(P).as_posix() + '/' + name, out / name)
    for job in continuation['jobs']:
        add('linkmaps/' + job['name'] + '.linkmap', job['linkmap'])
        add('modules/' + job['name'] + '.mod', job['modfile'])
        checksum = Path(job['modfile']).with_suffix('.sum')
        if checksum.exists():
            add('modules/' + checksum.name, checksum)
    for name in ['go.mod', 'libs.go']:
        add('private-lib/' + name, P / 'libs-darwin' / name)
    index = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in sorted(entries.items())}
    excluded = []
    for path in [P / 'workbench', Q / 'automation', P / 'libs-darwin/arm64/libwgpu_native.a']:
        excluded.append(dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path)))
    R.mkdir()
    with tarfile.open(R / 'evidence.tar.xz', 'w:xz', preset=6) as archive:
        for name, path in sorted(entries.items()):
            body = path.read_bytes()
            need(hashlib.sha256(body).hexdigest() == index[name]['sha256'], 'stable package member')
            info = tarfile.TarInfo(name)
            info.size = len(body)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(body))
    with tarfile.open(R / 'evidence.tar.xz', 'r:xz') as archive:
        need(archive.getnames() == sorted(index), 'exact archive members')
        for member in archive:
            body = archive.extractfile(member).read()
            need(len(body) == index[member.name]['bytes'] and
                 hashlib.sha256(body).hexdigest() == index[member.name]['sha256'], 'readback member hash')
    manifest = dict(files=index, archive=dict(bytes=(R / 'evidence.tar.xz').stat().st_size,
                    sha256=sha(R / 'evidence.tar.xz')), excluded_principal_artifacts=excluded,
                    other_exclusions='Compiler caches, Go temporary files and installed source/tool bytes are not bundled; inventories fingerprint their observed inputs.')
    (R / 'evidence.manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    result = dict(result='PASS_PRIVATE_SOURCE_ARCHIVE_WORKBENCH_SEMANTICS', source_commit=plan['source_commit'],
                  archive_sha256=plan['archive_sha256'], shipped_library_changed=False, sdk_changed=False,
                  build_and_inspection_commands=1 + len(read(W / 'build-v2.json')['commands']) + len(build['commands']), binaries=build['binaries'],
                  compile_warning_bytes=1132, compile_warning_sha256=build['original_compile_warning_sha256'],
                  original_strict_stderr_validator_result='FAILED_BUILD_PRESERVED',
                  metadata_validator_attempt='FAILED_BUILD-V2_PRESERVED_KEYERROR_EMPTY_OMITTED_GO_VALUES',
                  cases=[{k: v for k, v in c.items() if k != 'run'} for c in native['cases']],
                  result_review_sha256=review_sha, requests=80, controls=dict(base=read(W / 'controls.json')['count'],
                      intermediate=read(W / 'controls-v2.json')['count'], final=read(W / 'controls-v3-final.json')['count'],
                      superseded_preexecution_v3_controls_not_credited=True),
                  review='Independent internal build/native/result reviews; no new Prism call for this evidence-only checkpoint. The preceding source-build checkpoint has its separately recorded Anthropic Prism review.',
                  physical_input_generated=False, settings_changes=False, raw_native_output_published=False,
                  retained_raw_DTOs=False, full_macos_qualified=False,
                  evidence_scope=native['evidence_scope'])
    (R / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    (R / 'README.md').write_bytes((W / 'README.final.md').read_bytes())
    need(sha(W / 'result-review.json') == review_sha and
         all(sha(p) == h for p, h in review['inputs'].items()), 'terminal reviewed evidence identity')
    print(json.dumps(dict(result='PACKAGED', members=len(index), archive=manifest['archive'])))


if __name__ == '__main__':
    main()
