"""Correct omitted-empty-value metadata handling; preserve prior sealed attempts."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_gpu_framework_v3_parent', W / 'framework.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
OLD = h.P
Q = OLD / 'continuation-v3'
h.P = Q
g, sha, read, need = h.g, h.sha, h.read, h.need
WARNING_SHA = '32e1a9d869aaa745f7e88acb2bd9c09779976e8d3f2321ab7f3e5d20d72bbcde'


def metadata(data, name):
    info = json.loads(data)
    need(type(info['Settings']) is list, 'Go settings array')
    settings = {}
    for setting in info['Settings']:
        need(type(setting) is dict and set(setting) <= {'Key', 'Value'} and
             type(setting.get('Key')) is str and bool(setting['Key']) and setting['Key'] not in settings and
             type(setting.get('Value', '')) is str, 'unique typed Go build settings')
        settings[setting['Key']] = setting.get('Value', '')
    need(info['GoVersion'] == 'go1.27.2' and settings['vcs.revision'] == h.HEAD and
         settings['vcs.modified'] == 'false' and settings['GOARCH'] == 'arm64' and
         settings['GOOS'] == 'darwin' and settings['CGO_ENABLED'] == '1',
         'clean compiled Go/source/platform identity')
    replacements = [m.get('Replace', {}).get('Path') for m in info.get('Deps', [])
                    if m['Path'] == 'github.com/oliverbestmann/webgpu/libs-darwin']
    need(replacements == ([str(h.MODULE)] if name == 'workbench' else []),
         'embedded native module lineage')


def validate_original_compile(original):
    need(original['result'] == 'FAILED_BUILD' and original['error'] ==
         dict(type='ValueError', message='clean owned build') and
         original['finalization_errors'] == [] and len(original['commands']) == 1 and
         original['binaries'] == [] and original['native_runtime_started'] is False,
         'preserved failed strict-validator attempt')
    command = original['commands'][0]
    need(command['name'] == 'build-workbench' and h.v.f.terminal(command['run']),
         'workbench compilation itself completed normally')
    stderr = OLD / 'build-workbench/stderr'
    need(stderr.stat().st_size == 1132 and sha(stderr) == WARNING_SHA and
         command['run']['logs']['stderr'] == dict(bytes=1132, sha256=WARNING_SHA) and
         not (OLD / 'build-workbench/stdout').read_bytes(), 'only exact reviewed warning bytes')


def prepare():
    need(not Q.exists() and not (W / 'plan-v3.json').exists() and not h.STOP.exists(), 'fresh continuation')
    original = read(W / 'build.json')
    validate_original_compile(original)
    h.clean()
    pins = dict(read(W / 'build-readiness.json')['inputs'])
    for path in [W / 'build.json', W / 'build-v2.json', W / 'framework_v2.py', W / 'plan-v2.json',
                 W / 'build-v2-readiness.json', Path(__file__), OLD / 'workbench', OLD / 'workbench.linkmap',
                 OLD / 'build-workbench/stdout', OLD / 'build-workbench/stderr', OLD / 'build-workbench/owned.json']:
        need(path.is_file() and not path.is_symlink(), 'preserved regular artifact')
        pins[str(path)] = sha(path)
    need(h.stable(pins), 'source and preserved compile match')
    Q.mkdir(mode=0o700)
    for name in ['go-tmp', 'native-tmp']:
        (Q / name).mkdir(mode=0o700)
    jobs = read(W / 'plan.json')['jobs']
    workbench = next(j for j in jobs if j['name'] == 'workbench')
    client = dict(next(j for j in jobs if j['name'] == 'automation'))
    client['binary'] = str(Q / 'automation')
    client['linkmap'] = str(Q / 'automation.linkmap')
    client['argv'] = h.go(['build', '-mod=readonly', '-modfile=' + client['modfile'], '-p=2', '-buildvcs=true',
                          '-ldflags=-linkmode=external -extldflags=-Wl,-map,' + client['linkmap'],
                          '-o', client['binary'], '.'])
    workbench = dict(workbench, compiled_in_preserved_attempt=True)
    h.exclusive(W / 'plan-v3.json', dict(source_commit=h.HEAD, inputs=pins, jobs=[workbench, client],
                original_compile_warning_sha256=WARNING_SHA, original_compile_reused=True,
                native_runtime_started=False, shipped_library_changed=False))
    print(json.dumps(dict(result='PREPARED_V3', compile_reused='workbench', native_runtime_started=False)))


def build():
    review = read(W / 'build-v3-readiness.json')
    need(review['execution_ready'] is True and review['unresolved_findings'] == [], 'independent v2 readiness')
    plan = read(W / 'plan-v3.json')
    pins = dict(review['inputs'])
    need(not (W / 'build-v3.json').exists() and not h.stopped('build-v3'), 'fresh continuation build')
    d = dict(source_commit=h.HEAD, inputs=pins, commands=[], binaries=[], error=None,
             original_compile_reused=True, original_compile_warning_sha256=WARNING_SHA,
             native_runtime_started=False, shipped_library_changed=False)
    try:
        with g.LiveLease() as lease:
            need(lease.held() and h.stable(pins) and not h.stopped('build-v3'), 'continuation admission')
            h.clean()
            validate_original_compile(read(W / 'build.json'))
            for job in plan['jobs']:
                name = job['name']
                binary = Path(job['binary'])
                if name == 'automation':
                    need(not binary.exists() and not Path(job['linkmap']).exists(), 'new client output')
                    run = g.execute(job['argv'], Path(job['cwd']), Q / 'build-automation',
                                    lambda: h.stopped('build-v3'), lambda: h.stable(pins), timeout=180, limit=8 << 20)
                    d['commands'].append(dict(name='build-automation', run=run))
                    need(h.v.f.terminal(run) and not (Q / 'build-automation/stderr').read_bytes(), 'clean owned client build')
                    need(binary.is_file() and not binary.is_symlink() and 0 < binary.stat().st_size < 128 << 20, 'bounded client')
                    pins[str(binary)] = sha(binary)
                    pins[job['linkmap']] = sha(job['linkmap'])
                for suffix, args in [
                    ('links', ['/usr/bin/otool', '-L', str(binary)]),
                    ('metadata', [str(h.GO), 'version', '-m', '-json', str(binary)]),
                    ('load', ['/usr/bin/otool', '-l', str(binary)]),
                ]:
                    run = g.execute(args, h.T, Q / (name + '-' + suffix), lambda: h.stopped('build-v3'),
                                    lambda: h.stable(pins), timeout=30, limit=2 << 20)
                    d['commands'].append(dict(name=name + '-' + suffix, run=run))
                    need(h.v.f.terminal(run) and not (Q / (name + '-' + suffix + '/stderr')).read_bytes(), 'terminal binary probe')
                h.v.validate_links((Q / (name + '-links/stdout')).read_text())
                need('minos 13.0' in (Q / (name + '-load/stdout')).read_text(), 'minimum macOS13.0')
                metadata((Q / (name + '-metadata/stdout')).read_bytes(), name)
                count = h.linkmap(Path(job['linkmap']).read_bytes(), h.MODULE, name == 'workbench')
                d['binaries'].append(dict(name=name, path=str(binary), bytes=binary.stat().st_size,
                                          sha256=sha(binary), private_archive_object_entries=count))
            h.clean()
            need(h.stable(pins) and not h.stopped('build-v3') and lease.held(), 'terminal continuation closure')
    except BaseException as error:
        d['error'] = dict(type=type(error).__name__, message=str(error))
    finally:
        h.finish('build-v3', 'build-v3.json', d)


def native():
    review = read(W / 'native-v3-readiness.json')
    need(review['execution_ready'] is True and review['unresolved_findings'] == [], 'independent native readiness')
    built = read(W / 'build-v3.json')
    need(built['result'] == 'PASS_BUILD-V3' and not built['error'] and not built['finalization_errors'], 'complete private build')
    need(not (W / 'native-v3.json').exists() and not h.stopped('live-v3'), 'one-shot native continuation')
    pins = review['inputs']
    binaries = {b['name']: b['path'] for b in built['binaries']}
    d = dict(source_commit=h.HEAD, cases=[dict(rows=rows, execution='not_started') for rows in h.CASES],
             error=None, physical_input_generated=False, settings_changes=False,
             raw_native_output_published=False, saved_per_call_DTOs=False, full_macos_qualified=False,
             evidence_scope='Source-reviewed public client assertions and safe scalar summaries; no retained raw DTOs or pixels.')
    try:
        with g.LiveLease() as lease:
            for case in d['cases']:
                need(lease.held() and h.stable(pins) and not h.stopped('live-v3'), 'per-case admission')
                h.clean()
                rows = case['rows']
                out = Q / ('native-' + str(rows))
                run = g.execute(['/usr/bin/env', 'TMPDIR=' + str(Q / 'native-tmp'), binaries['automation'],
                                 '-workbench', binaries['workbench'], '-rows=' + str(rows)],
                                h.T / 'examples/automation', out, lambda: h.stopped('live-v3'),
                                lambda: h.stable(pins), timeout=60, limit=1 << 20)
                case['run'] = run
                if run['created']:
                    case['execution'] = 'unknown_may_have_started'
                need(h.v.f.terminal(run), 'owned native client/group complete')
                case['summary'] = h.safe_summary((out / 'stdout').read_bytes(), (out / 'stderr').read_bytes(), rows)
                case['execution'] = 'confirmed_by_safe_client_summary'
                need(not list((Q / 'native-tmp').glob('vellum-api-*')), 'private API directories removed')
                h.clean()
                need(h.stable(pins) and not h.stopped('live-v3'), 'per-case terminal stability')
                print(json.dumps(dict(rows=rows, requests=40, result='PASS', seconds=run['seconds'])), flush=True)
            need(all(c['execution'] == 'confirmed_by_safe_client_summary' for c in d['cases']) and
                 lease.held() and h.stable(pins) and not h.stopped('live-v3'), 'both exact cases and terminal guards')
            d['lease_held_through_cleanup'] = True
    except BaseException as error:
        d['error'] = dict(type=type(error).__name__, message=str(error))
    finally:
        h.finish('live-v3', 'native-v3.json', d)


if __name__ == '__main__':
    need(sys.argv[1:] in [['prepare'], ['build'], ['native']], 'fixed continuation phase')
    {'prepare': prepare, 'build': build, 'native': native}[sys.argv[1]]()
