"""Synthetic validator/state controls only; no compiler or native child runs."""
from pathlib import Path
import contextlib
import importlib.util
import io
import json
import tempfile
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('framework_controls_target', W / 'framework.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
passed = []


def rejects(label, call):
    try:
        call()
    except (ValueError, UnicodeDecodeError, KeyError):
        passed.append(label)
        return
    raise AssertionError(label + ' accepted')


summary = dict(status='PASS', rows=100000, requests=40, native_ready=True,
               transport_joined=True, endpoint_removed=True, post_close_refused=True,
               raw_native_output_published=False)
encoded = json.dumps(summary, separators=(',', ':')).encode() + b'\n'
assert h.safe_summary(encoded, b'', 100000) == summary
passed.append('exact-safe-summary')
for label, payload, stderr in [
    ('duplicate-summary-field', encoded[:-2] + b',"rows":100000}\n', b''),
    ('extra-secret-field', encoded[:-2] + b',"token":"redacted-control"}\n', b''),
    ('wrong-case', encoded.replace(b'100000', b'1000000'), b''),
    ('stderr-output', encoded, b'control'),
    ('raw-output-prefix', b'control\n' + encoded, b''),
]:
    rejects(label, lambda: h.safe_summary(payload, stderr, 100000))

table = b'# Object files:\n[1] ' + str(h.MODULE / 'arm64/libwgpu_native.a').encode() + b'(one.o)\n# Sections:\n\xffliteral'
assert h.linkmap(table, h.MODULE, True) == 1
passed.append('raw-nonutf8-literal-tail-accepted')
rejects('foreign-static-library', lambda: h.linkmap(table.replace(str(h.MODULE).encode(), b'/control/other'), h.MODULE, True))
rejects('client-cannot-link-wgpu', lambda: h.linkmap(table, h.MODULE, False))
rejects('duplicate-object-table', lambda: h.linkmap(table + b'# Object files:', h.MODULE, True))
rejects('no-native-object-for-workbench', lambda: h.linkmap(b'# Object files:\n# Sections:\n', h.MODULE, True))

# Exercise the actual campaign transition and finalizer with a fake process runner.
# This deliberately succeeds once and fails the second case before safe confirmation.
with tempfile.TemporaryDirectory(prefix='vellum-framework-state-control-') as temporary:
    root = Path(temporary)
    h.W = h.P = root
    h.STOP = root / 'universal-stop'
    (root / 'native-tmp').mkdir()
    h.clean = lambda: None
    h.stable = lambda pins: True
    (root / 'native-readiness.json').write_text(json.dumps(dict(execution_ready=True, unresolved_findings=[], inputs={})))
    (root / 'build.json').write_text(json.dumps(dict(result='PASS_BUILD', error=None, finalization_errors=[],
        binaries=[dict(name='automation', path='/control/client'), dict(name='workbench', path='/control/workbench')])) )

    class Lease:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def held(self): return True

    def fake_execute(argv, cwd, out, *args, **kwargs):
        out.mkdir()
        first = out.name == 'native-100000'
        (out / 'stdout').write_bytes(encoded if first else b'')
        (out / 'stderr').write_bytes(b'')
        return dict(created=True, error=None if first else dict(type='ControlFailure'),
                    exit_code=0 if first else 1, observation_errors=[], logs_complete=True,
                    pins_stable=True, stop_at_exit=False,
                    owned=dict(terminal=True, group_absent=True, errors=[]), seconds=0)

    h.g.LiveLease = Lease
    h.g.execute = fake_execute
    with contextlib.redirect_stdout(io.StringIO()):
        rejects('failed-second-case-fails-campaign', h.native)
    receipt = h.read(root / 'native.json')
    assert receipt['result'] == 'FAILED_LIVE' and receipt['error'] and not receipt['finalization_errors']
    assert [case['execution'] for case in receipt['cases']] == [
        'confirmed_by_safe_client_summary', 'unknown_may_have_started']
    assert receipt['local_stop_present'] and (root / 'stop-live').exists()
    passed += ['first-confirmation-survives-second-failure', 'failed-campaign-sealed-and-saved']

result = dict(result='PASS_SYNTHETIC_CONTROLS', controls=passed, count=len(passed),
              compiler_started=False, native_runtime_started=False)
with (W / 'controls.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
