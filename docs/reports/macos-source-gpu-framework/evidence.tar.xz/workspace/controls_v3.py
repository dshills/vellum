"""Controls of the actual continuation state machine; no compiler/native child."""
from pathlib import Path
import contextlib
import copy
import importlib.util
import io
import json
import tempfile
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('framework_v3_controls', W / 'framework_v3.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
passed = []


def rejects(label, call):
    try:
        call()
    except ValueError:
        passed.append(label)
        return
    raise AssertionError(label + ' accepted')


observed = (v.OLD / 'continuation-v2/workbench-metadata/stdout').read_bytes()
v.metadata(observed, 'workbench')
passed.append('actual-omitted-empty-Go-settings-accepted')
for label, mutate in [
    ('changed-vcs-refused', lambda d: next(s for s in d['Settings'] if s['Key'] == 'vcs.revision').update(Value='0' * 40)),
    ('dirty-vcs-refused', lambda d: next(s for s in d['Settings'] if s['Key'] == 'vcs.modified').update(Value='true')),
    ('wrong-architecture-refused', lambda d: next(s for s in d['Settings'] if s['Key'] == 'GOARCH').update(Value='amd64')),
    ('wrong-cgo-refused', lambda d: next(s for s in d['Settings'] if s['Key'] == 'CGO_ENABLED').update(Value='0')),
    ('empty-key-refused', lambda d: d['Settings'].append({'Key': ''})),
    ('duplicate-setting-refused', lambda d: d['Settings'].append(copy.deepcopy(d['Settings'][0]))),
    ('nonstring-setting-refused', lambda d: d['Settings'][0].update(Value=None)),
    ('foreign-native-replacement-refused', lambda d: next(m for m in d['Deps'] if m['Path'].endswith('/libs-darwin'))['Replace'].update(Path='/control/foreign')),
]:
    changed = json.loads(observed)
    mutate(changed)
    rejects(label, lambda: v.metadata(json.dumps(changed), 'workbench'))
rejects('native-module-in-stdlib-client-refused', lambda: v.metadata(observed, 'automation'))

original = v.read(W / 'build.json')
v.validate_original_compile(original)
passed.append('exact-preserved-warning-bearing-compile')
for label, mutate in [
    ('failed-compiler-refused', lambda d: d['commands'][0]['run'].update(exit_code=1)),
    ('unowned-compiler-refused', lambda d: d['commands'][0]['run']['owned'].update(group_absent=False)),
    ('different-warning-receipt-refused', lambda d: d['commands'][0]['run']['logs']['stderr'].update(sha256='0' * 64)),
]:
    changed = copy.deepcopy(original)
    mutate(changed)
    rejects(label, lambda: v.validate_original_compile(changed))
old_sha = v.sha
v.sha = lambda path: '0' * 64 if Path(path).name == 'stderr' else old_sha(path)
rejects('changed-raw-warning-bytes-refused', lambda: v.validate_original_compile(original))
v.sha = old_sha

with tempfile.TemporaryDirectory(prefix='vellum-framework-v3-control-') as temporary:
    root = Path(temporary)
    v.W = v.Q = v.h.W = v.h.P = root
    v.h.STOP = root / 'universal-stop'
    v.h.clean = lambda: None
    v.h.stable = lambda pins: True
    (root / 'native-tmp').mkdir()
    (root / 'native-v3-readiness.json').write_text(json.dumps(dict(execution_ready=True, unresolved_findings=[], inputs={})))
    (root / 'build-v3.json').write_text(json.dumps(dict(result='PASS_BUILD-V3', error=None, finalization_errors=[],
        binaries=[dict(name='automation', path='/control/client'), dict(name='workbench', path='/control/workbench')])) )

    class Lease:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def held(self): return True

    def execute(argv, cwd, out, *args, **kwargs):
        out.mkdir()
        first = out.name == 'native-100000'
        summary = dict(status='PASS', rows=100000, requests=40, native_ready=True, transport_joined=True,
                       endpoint_removed=True, post_close_refused=True, raw_native_output_published=False)
        (out / 'stdout').write_bytes((json.dumps(summary, separators=(',', ':')) + '\n').encode() if first else b'')
        (out / 'stderr').write_bytes(b'')
        return dict(created=True, error=None if first else dict(type='ControlFailure'), exit_code=0 if first else 1,
                    observation_errors=[], logs_complete=True, pins_stable=True, stop_at_exit=False,
                    owned=dict(terminal=True, group_absent=True, errors=[]), seconds=0)

    v.g.LiveLease = Lease
    v.g.execute = execute
    with contextlib.redirect_stdout(io.StringIO()):
        rejects('v3-failed-second-case-fails-campaign', v.native)
    receipt = v.read(root / 'native-v3.json')
    assert receipt['result'] == 'FAILED_LIVE-V3' and receipt['error'] and not receipt['finalization_errors']
    assert [c['execution'] for c in receipt['cases']] == ['confirmed_by_safe_client_summary', 'unknown_may_have_started']
    assert receipt['local_stop_present'] and (root / 'stop-live-v3').exists()
    passed += ['v3-first-confirmation-survives-second-failure', 'v3-failed-campaign-sealed-and-saved']

result = dict(result='PASS_SYNTHETIC_V3_CONTROLS', count=len(passed), controls=passed,
              compiler_started=False, native_runtime_started=False)
with (W / 'controls-v3-final.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
