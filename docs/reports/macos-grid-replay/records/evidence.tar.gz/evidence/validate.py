"""Offline validation of this test-only stored-grid replay checkpoint."""
from pathlib import Path
import hashlib
import json

R = Path('/private/tmp/vellum-grid-replay')
P = Path(__file__).resolve().parent
sha = lambda f: hashlib.sha256(Path(f).read_bytes()).hexdigest()
review = json.loads((P / 'source-review.json').read_text())
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
sources = review['sources']
assert len(sources) == 2 and all(sha(R / n) == h for n, h in sources.items())
commands = {
    'full-offscreen-race-v3': ['go', 'test', '-race', '-tags=offscreen', '-count=1', '.'],
    'vet-v3': ['go', 'vet', '-tags=offscreen', '.'],
    'wheel-fault-v3': ['go', 'test', '-tags=offscreen', '-count=1', '-overlay=' + str(P / 'wheel-fault-overlay.json'), '-run', '^TestStoredGridRoutedReplayAcrossBatches/10000$', '-v', '.'],
}
receipts = {}
prepared = None
for name, argv in commands.items():
    path = P / (name + '.json')
    d = json.loads(path.read_text())
    assert d['argv'] == argv and d['cwd'] == str(R / 'drivers/cogent')
    assert d['mode'] == 'code' and not d['live_tests'] and not d['headless_gpu_requested']
    assert d['error'] is None and d['exit_code'] == (1 if name == 'wheel-fault-v3' else 0)
    assert d['source_commit'] == '2c87a3d877c092b8ccf8b281cf6473f494d4c567'
    assert d['producer_sha256'] == sha(P / 'code_run.py')
    assert d['source_delta_stable'] and d['source_delta_before'] == d['source_delta_after'] == sources
    assert d['prepared_before'] == d['prepared_after'] and len(d['prepared_before']) == 6216
    if prepared is None: prepared = d['prepared_before']
    assert d['prepared_before'] == prepared
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    if name != 'wheel-fault-v3': assert not d['overlay_inputs_before']
    else:
        assert len(d['overlay_inputs_before']) == 2
        assert all(sha(n) == h for n, h in d['overlay_inputs_before'].items())
    for channel in ['stdout', 'stderr']:
        assert d[channel + '_sha256'] == sha(P / (name + '.' + channel))
    if name == 'wheel-fault-v3':
        assert 'pilot did not exercise range/scroll/reverse/editor/history transitions' in (P / (name + '.stdout')).read_text()
    receipts[name] = {'sha256': sha(path), 'exit_code': d['exit_code'], 'elapsed_seconds': d['elapsed_seconds']}
summary = {
    'result': 'PASS_STORED_GRID_OFFSCREEN_REPLAY_CHECKPOINT',
    'base_commit': '2c87a3d877c092b8ccf8b281cf6473f494d4c567',
    'sources': sources, 'prepared_count': len(prepared),
    'datasets': [10000, 1000000], 'stored_fields_per_row': 20,
    'dispatch_batches': [1, 7, 64], 'trace_events': 16,
    'completed_checkpoints_per_instance': 10, 'windows': 2,
    'fault_control': 'Dropped wheel motion fails the required-transition oracle; exit1 is expected, not a runtime pass.',
    'receipts': receipts, 'source_review_sha256': sha(P / 'source-review.json'),
    'validator_sha256': sha(__file__), 'live_tests': False,
    'runtime_implementation_changed': False, 'full_p9_qualified': False,
    'full_mac_qualified': False,
    'scope': 'Test/spec-only change. Pilot authors one physical-coordinate trace per dataset in each test process; three fresh instances consume that identical trace. Formula/domain/history oracles supplement equality. No independently versioned large replay record, workers/canvas/P5 workspace, Cocoa/GPU/physical input, frame/heap/native memory budgets or overnight qualification.',
}
(P / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ['result', 'datasets', 'dispatch_batches', 'full_p9_qualified', 'live_tests']}))
