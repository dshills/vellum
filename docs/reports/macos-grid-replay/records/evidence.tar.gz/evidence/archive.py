"""Preserve reviewed software-only replay evidence and its exact scope."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path('/private/tmp/vellum-grid-replay');P=Path(__file__).resolve().parent
O=R/'docs/reports/macos-grid-replay/records'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources']
review=json.loads((P/'checkpoint-review.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not review['unresolved_findings'] and review['sources']==sources
assert all(sha(R/n)==h for n,h in sources.items())
summary=json.loads((P/'summary.json').read_text())
assert summary['result']=='PASS_STORED_GRID_OFFSCREEN_REPLAY_CHECKPOINT'
assert all(sources[n]==h for n,h in summary['sources'].items())
provider=json.loads((P/'prism-v1/prism.json').read_text())
process=json.loads((P/'prism-v1/process.json').read_text())
coverage=provider['coverage']
assert process['exit_code']==0 and process['error'] is None and process['source_index_stable'] and process['sources']==sources
assert process['prism_sha256']==sha(P/'prism-v1/prism.json')
assert process['producer_sha256']==sha(P/'prism.py') and process['review_sha256']==sha(P/'checkpoint-review.json')
assert coverage['complete'] and coverage['files']==3 and not coverage['skipped'] and not coverage['excluded'] and coverage['truncatedBytes']==0
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert not provider['findings']
members={}
for f in sorted(P.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts:continue
 assert not f.is_symlink()
 members['evidence/'+f.relative_to(P).as_posix()]=f.read_bytes()
for n in sources:members['source/'+n]=(R/n).read_bytes()
index={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in members.items()}
O.mkdir(parents=True,exist_ok=False)
archive=O/'evidence.tar.gz'
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT)as tar:
   for n,b in sorted(members.items()):
    item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o644;tar.addfile(item,io.BytesIO(b))
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(members)
 for item in tar.getmembers():assert item.isfile() and tar.extractfile(item).read()==members[item.name]
(O/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={'result':'PASS_SCOPED_STORED_GRID_REPLAY','base_commit':summary['base_commit'],'sources':sources,'prepared_files':6216,'checks':summary['receipts'],'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','internal_review_sha256':sha(P/'checkpoint-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_llm_calls':coverage['llmCalls'],'prism_coverage_complete':True,'prism_findings':0,'prism_process_sha256':sha(P/'prism-v1/process.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'archive_members':len(members),'archive_index_sha256':sha(O/'archive-index.json'),'producer_sha256':sha(__file__),'live_tests':False,'runtime_implementation_changed':False,'full_p9_qualified':False,'full_mac_qualified':False,'scope':summary['scope']}
(O/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
assert all(sha(R/n)==h for n,h in sources.items())
print(json.dumps({k:q[k]for k in ['result','archive_members','archive_bytes','archive_sha256','prism_invocations','prism_llm_calls','prism_findings']}))
