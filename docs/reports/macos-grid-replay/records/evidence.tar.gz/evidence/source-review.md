APPROVED_SOURCE — two current test/spec hashes bound; no unresolved findings.

The formula oracle closes the pilot-equality gap: measured row keys/values, reverse state and the undo original are independently checked. Raw input replay, owner-held history, detached checkpoints, exact image metadata, stale-input refusal and survivor checks are sound for this fixture.

Test-only scope; no runtime/API change or full P9/P11 qualification. Final stable race/vet/fault evidence is separate. No tests/native/UI/provider actions were run by this review.
