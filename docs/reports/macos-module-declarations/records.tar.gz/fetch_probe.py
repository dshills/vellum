from pathlib import Path
import urllib.request,hashlib,json,time,urllib.error
P=Path(__file__).resolve().parent;rows=[]
for name in ['LICENSE','libs-darwin/go.mod']:
 url='https://raw.githubusercontent.com/oliverbestmann/webgpu/66a5dfa57f8dd22992aa1b90bbb67ffa9ec2b46c/'+name;start=time.monotonic()
 try:
  with urllib.request.urlopen(url,timeout=20)as response:
   data=response.read((1<<20)+1);assert len(data)<=1<<20;assert response.geturl()==url
  file=P/('probe-'+name.replace('/','-'));file.write_bytes(data);rows.append({'url':url,'file':file.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'seconds':time.monotonic()-start})
 except(urllib.error.URLError,OSError)as error:rows.append({'url':url,'error':str(error),'seconds':time.monotonic()-start})
(P/'fetch-probe.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
