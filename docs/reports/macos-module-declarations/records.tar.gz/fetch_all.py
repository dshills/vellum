"""Bounded public-source inspection; no code execution, rights grant or module edits."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,json,hashlib,urllib.error,time
P=Path(__file__).resolve().parent;cache=Path('/Users/dshills/Development/Go/pkg/mod/cache/download/github.com/oliverbestmann/webgpu');mod=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def fetch(url,path):
 if path.exists():raise RuntimeError('existing output')
 request=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','User-Agent':'Vellum-pinned-notice-inspection'})
 try:
  with urllib.request.urlopen(request,timeout=15)as response:
   raw=response.read((1<<20)+1);assert len(raw)<=1<<20 and response.geturl()==url
  path.write_bytes(raw);return {'uri':url,'file':path.name,'bytes':len(raw),'sha256':sha(path),'http_status':200}
 except urllib.error.HTTPError as error:
  if error.code!=404:raise
  return {'uri':url,'http_status':404,'no_payload_substituted':True}
def one(name):
 infos=list((cache/name/'@v').glob('*.info'));assert len(infos)==1;info=json.loads(infos[0].read_text());origin=info['Origin'];commit=origin['Hash'];assert origin['URL']=='https://github.com/oliverbestmann/webgpu' and origin['Subdir']==name
 source=mod/(name+'@'+info['Version']);directory=P/name;directory.mkdir();rows={}
 for key,url in [('root','https://api.github.com/repos/oliverbestmann/webgpu/contents?ref='+commit),('module-tree','https://api.github.com/repos/oliverbestmann/webgpu/contents/'+name+'?ref='+commit),('README','https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/README.md'),('go.mod','https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/'+name+'/go.mod'),('libs.go','https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/'+name+'/libs.go'),('LICENSE','https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/LICENSE')]:
  rows[key]=fetch(url,directory/(key+'.raw'))
 for key in ['go.mod','libs.go']:assert rows[key]['http_status']==200 and (directory/(key+'.raw')).read_bytes()==(source/key).read_bytes()
 root=json.loads((directory/'root.raw').read_bytes());tree=json.loads((directory/'module-tree.raw').read_bytes())
 assert {x['name']for x in root}=={'README.md',name};assert not any('licen'in x['name'].lower() or x['name'].lower().startswith(('copying','notice'))for x in tree)
 assert (directory/'README.raw').read_text().strip()=='Prebuild wgpu libraries from wgpu-native.' and rows['LICENSE']['http_status']==404
 out={'module':'github.com/oliverbestmann/webgpu/'+name,'version':info['Version'],'origin':origin,'cached_origin_metadata_sha256':sha(infos[0]),'cached_go_mod_sha256':sha(source/'go.mod'),'cached_libs_go_sha256':sha(source/'libs.go'),'repository_root_names':sorted(x['name']for x in root),'module_root_names':sorted(x['name']for x in tree),'observations':rows,'declaration_found':False,'status':'upstream-pinned-declaration-absent','rights_status':'unresolved; no terms inferred from newer repository, other module or native archive','scope':'Pinned repository root and module-root inventory plus exact go.mod/libs.go equality; not a legal conclusion or upstream attestation'}
 (directory/'result.json').write_text(json.dumps(out,indent=2)+'\n');return out
start=time.monotonic()
with ThreadPoolExecutor(max_workers=5)as pool:rows=list(pool.map(one,['libs-android','libs-darwin','libs-ios','libs-linux','libs-windows']))
out={'schema':1,'base_commit':'f6d05b58e6fe45db81a1c93952a32f5af03e1611','result':'FIVE_PINNED_MODULE_DECLARATIONS_ABSENT','seconds':time.monotonic()-start,'modules':rows,'distribution_audit':'pending','native_or_build_executed':False,'source_or_cache_changed':False,'gates_closed':[]}
(P/'upstream-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'result':out['result'],'modules':len(rows),'seconds':out['seconds']}))
