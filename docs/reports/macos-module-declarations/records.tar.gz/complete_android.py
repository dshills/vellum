from pathlib import Path
import urllib.request,urllib.error,json,hashlib
P=Path(__file__).resolve().parent;name='libs-android';d=P/name;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cache=Path('/Users/dshills/Development/Go/pkg/mod/cache/download/github.com/oliverbestmann/webgpu')
infofile=next((cache/name/'@v').glob('*.info'));info=json.loads(infofile.read_text());origin=info['Origin'];commit=origin['Hash'];source=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu')/(name+'@'+info['Version'])
observations={}
for key in ['root','module-tree','README','go.mod']:
 file=d/(key+'.raw');uris={'root':'https://api.github.com/repos/oliverbestmann/webgpu/contents?ref='+commit,'module-tree':'https://api.github.com/repos/oliverbestmann/webgpu/contents/'+name+'?ref='+commit,'README':'https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/README.md','go.mod':'https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/'+name+'/go.mod'}
 observations[key]={'uri':uris[key],'file':file.name,'bytes':file.stat().st_size,'sha256':sha(file),'http_status':200,'retained_from_initial_fetch':True}
url='https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/'+name+'/lib.go'
with urllib.request.urlopen(url,timeout=15)as response:raw=response.read((1<<20)+1);assert response.geturl()==url
assert len(raw)<=1<<20 and raw==(source/'lib.go').read_bytes();file=d/'lib.go.raw';assert not file.exists();file.write_bytes(raw);observations['lib.go']={'uri':url,'file':file.name,'bytes':len(raw),'sha256':sha(file),'http_status':200}
url='https://raw.githubusercontent.com/oliverbestmann/webgpu/'+commit+'/LICENSE'
try:
 with urllib.request.urlopen(url,timeout=15)as response:raise RuntimeError('unexpected license payload')
except urllib.error.HTTPError as error:
 assert error.code==404;observations['LICENSE']={'uri':url,'http_status':404,'no_payload_substituted':True}
root=json.loads((d/'root.raw').read_bytes());tree=json.loads((d/'module-tree.raw').read_bytes())
assert {x['name']for x in root}=={'README.md',name} and not any('licen'in x['name'].lower()or x['name'].lower().startswith(('copying','notice'))for x in tree)
assert (d/'go.mod.raw').read_bytes()==(source/'go.mod').read_bytes() and (d/'README.raw').read_text().strip()=='Prebuild wgpu libraries from wgpu-native.'
out={'module':'github.com/oliverbestmann/webgpu/'+name,'version':info['Version'],'origin':origin,'cached_origin_metadata_sha256':sha(infofile),'cached_go_mod_sha256':sha(source/'go.mod'),'cached_lib_go_sha256':sha(source/'lib.go'),'repository_root_names':sorted(x['name']for x in root),'module_root_names':sorted(x['name']for x in tree),'observations':observations,'declaration_found':False,'status':'upstream-pinned-declaration-absent','rights_status':'unresolved; no terms inferred from newer repository, other module or native archive','scope':'Pinned repository root and module-root inventory plus exact go.mod/lib.go equality; not a legal conclusion or upstream attestation'}
(d/'result.json').write_text(json.dumps(out,indent=2)+'\n')
rows=[json.loads((P/n/'result.json').read_text())for n in ['libs-android','libs-darwin','libs-ios','libs-linux','libs-windows']]
for row in rows:
 directory=P/row['origin']['Subdir'];assert not row['declaration_found'] and row['observations']['LICENSE']['http_status']==404
 for record in row['observations'].values():
  if 'file'in record:assert sha(directory/record['file'])==record['sha256']
versions=json.loads((P.parent/'macos-app-notices-56e1dc7/module-notice-gaps.json').read_text())
for row,gap in zip(rows,versions):assert row['module']==gap['module']and row['version']==gap['version'];row['go_sum']=gap['sum'];assert (cache/row['origin']['Subdir']/'@v'/(row['version']+'.ziphash')).read_text().strip()==gap['sum']
result={'schema':1,'base_commit':'f6d05b58e6fe45db81a1c93952a32f5af03e1611','result':'FIVE_PINNED_MODULE_DECLARATIONS_ABSENT','modules':rows,'distribution_audit':'pending','native_or_build_executed':False,'source_or_cache_changed':False,'gates_closed':[],'initial_fetch_failure':'Android source filename was lib.go, not the assumed libs.go. Four completed records and Android retained raw responses reused; only missing Android lib.go and explicit404License rechecked. Original fetch program/partials retained.','limits':'Root and module-root text declarations only; no recursive binary inspection, exact linked membership, complete generated/native rights or upstream attestation claimed.'}
(P/'upstream-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':result['result'],'modules':len(rows),'gates_closed':[]}))
