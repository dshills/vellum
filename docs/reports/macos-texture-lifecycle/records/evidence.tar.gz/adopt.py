"""Package complete texture and deterministic readback ownership as patch49."""
import difflib,hashlib,json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-texture-lifecycle');driver=r/'drivers/cogent';stage=driver/'native/patches/texturelifecycle';stage.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();candidate=json.loads((p/'candidate-v3-inputs.json').read_text());inputs=json.loads((p/'original-inputs.json').read_text());assert len(candidate)==len(inputs)==5
outputs={};diff=[]
for n,h in candidate.items():
 f=driver/'build/upstream'/n;old=f.read_bytes()if f.is_file()else b'';assert (sha(old)if old else None)==inputs[n];new=(p/'candidate'/n).read_bytes();assert sha(new)==h;outputs[n]=h
 diff.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
name='0049-complete-texture-readback-ownership.patch';data=''.join(diff).encode();(stage/name).write_bytes(data)
for n,v in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (stage/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=driver/'native/dependencies.json';m=json.loads(manifest.read_text());prefix='native/patches/texturelifecycle';assert not any(s['inputs']==prefix+'/original-hashes.json'for s in m['dependencies'][0]['stages']);m['dependencies'][0]['stages'].append({'origin':'drivers/cogent/'+prefix,'inputs':prefix+'/original-hashes.json','outputs':prefix+'/output-hashes.json','patches':[{'file':prefix+'/'+name,'sha256':sha(data)}]});manifest.write_text(json.dumps(m,indent=2)+'\n')
test=driver/'prepare_test.py';s=test.read_text();assert s.count('list(range(1, 49))')==1;test.write_text(s.replace('list(range(1, 49))','list(range(1, 50))'))
(stage/'README.md').write_text('''# Complete texture and readback ownership

Patch 0049 uses the patch48 owned-reference constraint to publish a texture only
with its complete live view. Failure retires acquired references. Configuration
shortcuts require live device/queue and an owned live same-device pair. Changing
the device retires old texture, view, sampler and staging. Empty borrowed state
is cleared on retirement, and created pairs explicitly acquire owned mode.

Readback staging keeps matching live buffers, preserves old references/layout on
same-device allocation refusal, and releases replaced buffers synchronously.
The prior implementation depended on WebGPU Go finalizers after replacement.
Pinned TryCreate methods already release native handles on their error paths;
partial-return fault tables test defensive control contracts, not those backend
errors. The outer texture must still release a successful texture if view creation
fails. Factory references must be fresh and owned; caller operations are serialized.

Synchronous staging accepts positive single-layer/single-sample four-byte
RGBA8/BGRA8 resolves, with uint32 row/image and Go map-length bounds. Configure and
encode a matching copy before mapping; mapping never allocates an empty uncopied
replacement. Checked copy refuses stale/invalid inputs. GrabImage does not read
a refused copy. Raw ReadData keeps native channels; detached ReadGoImage bytes
normalize BGRA to NRGBA channel order without alpha/transfer conversion.

Tests include seven original-compatible invalid/borrowed/empty-borrowed cases,
counted factory failures, exact layout/refusal checks, 1,000 counted staging
replacements, device-change refusal and four-format image-channel vectors.
No physical GPU fault, readback or memory reclamation is qualified. Native
backend/in-flight retention, sustained performance and live memory tests remain
separate; desktop work is deferred while the human uses the machine. Modified
upstream notices remain BSD-style; new source/tests are MIT. The module cache is
not edited. All inputs/outputs and the patch are hash-pinned.
''')
spec=r/'specs/gpu-frame-lifecycle.md';s=spec.read_text();s+='''
## Texture and synchronous staging ownership

Texture creation publishes an owned live texture/view pair together. Failed view
creation retires the created texture; nil/invalid factory results are refused.
Same-format configuration reuses only an owned live pair on the same live device
and queue. Explicit device changes retire texture/view/sampler/staging references.
Retiring an empty borrowed binding clears its shared flag, so later owned creation
cannot inherit borrowed mode. Borrowed source objects retain their ownership.

Readback configuration reuses a matching live buffer or allocates a fresh owned
replacement. Allocation refusal preserves the prior buffer/layout; success
explicitly retires it, rather than waiting for finalizers. Replacement admits an
old-plus-new ownership interval; native reclamation may lag. Serialized caller
ownership covers configuration, copying, mapping, unmapping and retirement.

This synchronous API accepts positive single-layer/single-sample RGBA8/BGRA8
resolves and validates uint32 layout fields and Go map-length arithmetic. It does
not promise a physical-memory budget; managed canvas/view capture has separate
admission limits. ConfigReadBuffer precedes encoding CopyToReadBuffer, and caller
submission/completion precedes reading. ReadDataMapped refuses stale/missing
staging without allocating uncopied data. GrabImage finishes rendering but returns
no image if copy admission fails. ReadData keeps native channels; ReadGoImage
normalizes detached BGRA bytes to NRGBA order while preserving alpha/transfer bytes.

The pinned native factories already clean their own error references. Counted
partial-result tables are defensive control tests. A 1,000-replacement fixture
proves explicit release calls and maximum two owned handles during replacement;
it does not prove GPU heap retirement or sustained native readback performance.
Original-compatible wrapper-only regressions, layout/channel vectors and actual
invalid-input/device-change guards accompany source review and compilation.
''';spec.write_text(s)
spec=r/'specs/macos-completion.md';s=spec.read_text();s+='\nTexture creation and synchronous staging now have complete-pair publication,\nexplicit replacement retirement, device-change cleanup and checked layout/copy\nrefusal in the [GPU ownership contract](gpu-frame-lifecycle.md). Counted ownership\nand wrapper-only regressions remain separate from physical GPU readback/faults\nand the outstanding native graphics-memory/performance gates.\n';spec.write_text(s)
print(json.dumps({'patch_sha256':sha(data),'outputs':outputs,'expected_prepared_files':6186}))
