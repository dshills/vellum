// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

//go:build !js

package gpu

import (
	"bytes"
	"encoding/json"
	"fmt"
	"image"
	"os"
	"testing"

	"github.com/oliverbestmann/webgpu/wgpu"
)

// This fixture uses tiny headless GPU resources, no windows/surfaces, no input
// or presentation, and no timing/physical-memory acceptance. Held old Go wrappers
// prove explicit reference retirement rather than eventual finalizer activity.
// It also compiles against patch48 for original-compatible native regressions.
func TestVellumTextureNativeOwnershipAndReadback(t *testing.T) {
	if os.Getenv("VELLUM_TEXTURE_GPU_TEST") != "1" {
		t.Skip("explicit headless GPU correctness fixture required")
	}
	var gp *GPU
	var dev *Device
	defer func() {
		if dev != nil {
			dev.Release()
		}
		if gp != nil {
			gp.Release()
		}
		ReleaseInstance()
	}()
	var err error
	gp, dev, err = NoDisplayGPU()
	if err != nil || gp == nil || dev == nil {
		t.Fatal("headless GPU unavailable", err)
	}
	record := func(fields map[string]any) {
		fields["fixture"] = "texture_headless"
		fields["windows_created"] = 0
		data, err := json.Marshal(fields)
		if err != nil {
			t.Fatal(err)
		}
		fmt.Printf("VELLUM_TEXTURE_NATIVE %s\n", data)
	}
	format := TextureFormat{Size: image.Pt(3, 2), Layers: 1, Samples: 1, Format: wgpu.TextureFormatRGBA8UnormSrgb}
	t.Run("usage_reconfiguration", func(t *testing.T) {
		tx := NewTexture(dev)
		defer tx.Release()
		tx.Format = format
		img := image.NewRGBA(image.Rect(0, 0, 3, 2))
		for i := 3; i < len(img.Pix); i += 4 {
			img.Pix[i] = 255
		}
		if err := tx.SetFromGoImage(img, 0); err != nil {
			t.Fatal(err)
		}
		old := tx.texture
		required := wgpu.TextureUsageRenderAttachment | wgpu.TextureUsageCopySrc | wgpu.TextureUsageTextureBinding
		if err := tx.ConfigRenderTexture(dev, &format); err != nil {
			t.Fatal(err)
		}
		if old.IsValid() || tx.texture.GetUsage()&required != required {
			t.Fatal("same format reused incompatible image usage")
		}
		old = tx.texture
		if err := tx.SetFromGoImage(img, 0); err != nil {
			t.Fatal(err)
		}
		if old.IsValid() || tx.texture.GetUsage()&(wgpu.TextureUsageTextureBinding|wgpu.TextureUsageCopyDst) != (wgpu.TextureUsageTextureBinding|wgpu.TextureUsageCopyDst) {
			t.Fatal("upload reused incompatible render usage")
		}
		record(map[string]any{"case": "usage_reconfiguration", "retired_references": 2})
	})
	t.Run("staging_retirement", func(t *testing.T) {
		tx := NewTexture(dev)
		defer tx.Release()
		tx.Format = format
		var refs []*wgpu.Buffer
		defer func() {
			for _, b := range refs {
				b.Release()
			}
		}()
		for i := 0; i < 32; i++ {
			tx.Format.Size = image.Pt(3+i%3, 2+i)
			if err := tx.ConfigReadBuffer(); err != nil {
				t.Fatal(err)
			}
			for _, old := range refs {
				if old.IsValid() {
					t.Fatal("replaced staging reference waits for GC", i)
				}
			}
			refs = append(refs, tx.readBuffer)
			current := tx.readBuffer
			if err := tx.ConfigReadBuffer(); err != nil || current != tx.readBuffer {
				t.Fatal("matching staging was replaced", err)
			}
		}
		tx.Release()
		for _, b := range refs {
			if b.IsValid() {
				t.Fatal("staging survived owner release")
			}
		}
		record(map[string]any{"case": "staging_retirement", "created_buffers": 32, "retired_references": 32})
	})
	t.Run("device_change", func(t *testing.T) {
		other, err := NewDevice(gp)
		if err != nil {
			t.Fatal(err)
		}
		defer other.Release()
		tx := NewTexture(dev)
		defer tx.Release()
		if err := tx.ConfigRenderTexture(dev, &format); err != nil {
			t.Fatal(err)
		}
		if err := tx.ConfigReadBuffer(); err != nil {
			t.Fatal(err)
		}
		texture, view, staging := tx.texture, tx.view, tx.readBuffer
		if err := tx.ConfigRenderTexture(other, &format); err != nil {
			t.Fatal(err)
		}
		if texture.IsValid() || view.IsValid() || staging.IsValid() || tx.readBuffer != nil || tx.ReadBufferDims != (TextureBufferDims{}) {
			t.Fatal("device change retained old references")
		}
		if err := tx.ConfigReadBuffer(); err != nil {
			t.Fatal(err)
		}
		if tx.readBuffer == staging {
			t.Fatal("other-device staging reused")
		}
		record(map[string]any{"case": "device_change", "retired_references": 3})
	})
	for _, bgra := range []bool{false, true} {
		name := "rgba_readback"
		if bgra {
			name = "bgra_readback"
		}
		t.Run(name, func(t *testing.T) {
			tx := NewTexture(dev)
			defer tx.Release()
			tx.Format = format
			if bgra {
				tx.Format.Format = wgpu.TextureFormatBGRA8UnormSrgb
			}
			if err := tx.CreateTexture(wgpu.TextureUsageCopySrc | wgpu.TextureUsageCopyDst | wgpu.TextureUsageTextureBinding); err != nil {
				t.Fatal(err)
			}
			want := []byte{17, 43, 71, 255, 29, 59, 97, 255, 83, 113, 149, 255, 131, 163, 191, 255, 197, 211, 227, 255, 7, 19, 31, 255}
			native := append([]byte(nil), want...)
			if bgra {
				for i := 0; i < len(native); i += 4 {
					native[i], native[i+2] = native[i+2], native[i]
				}
			}
			size := tx.Format.Extent3D()
			if err := dev.Queue.TryWriteTexture(tx.texture.AsImageCopy(), native, &wgpu.TexelCopyBufferLayout{BytesPerRow: 12, RowsPerImage: 2}, &size); err != nil {
				t.Fatal(err)
			}
			if err := tx.ConfigReadBuffer(); err != nil {
				t.Fatal(err)
			}
			cmd, err := dev.Device.TryCreateCommandEncoder(nil)
			if err != nil {
				t.Fatal(err)
			}
			defer cmd.Release()
			if err := tx.CopyToReadBuffer(cmd); err != nil {
				t.Fatal(err)
			}
			buffer, err := cmd.TryFinish(nil)
			if err != nil {
				t.Fatal(err)
			}
			defer buffer.Release()
			dev.Queue.Submit(buffer)
			var raw []byte
			if err := tx.ReadData(&raw, true); err != nil || !bytes.Equal(raw, native) {
				t.Fatal("raw readback channel/padding mismatch", err, raw)
			}
			img, err := tx.ReadGoImage()
			if err != nil || img == nil || img.Rect != image.Rect(0, 0, 3, 2) || img.Stride != 12 || !bytes.Equal(img.Pix, want) {
				t.Fatal("NRGBA readback channel/padding mismatch", err, img)
			}
			record(map[string]any{"case": name, "pixels": 6, "padded_bytes": 512, "raw_native_channels": true, "image_rgba_channels": true})
		})
	}
}
