// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"image"
	"testing"

	"github.com/oliverbestmann/webgpu/wgpu"
)

// This regression also compiles against patch48. Empty native wrappers and a
// missing device cannot allocate; borrowed handles must be detached, not reused
// solely because their format matches. It never enters a native GPU factory.
func TestVellumTextureConfigurationRejectsIncompleteOrBorrowedMatch(t *testing.T) {
	for _, kind := range []string{"render", "depth", "multi"} {
		for _, borrowed := range []bool{false, true} {
			t.Run(kind+map[bool]string{false: "_invalid", true: "_borrowed"}[borrowed], func(t *testing.T) {
				format := TextureFormat{Size: image.Pt(2, 3), Layers: 1, Samples: 1, Format: wgpu.TextureFormatRGBA8UnormSrgb}
				if kind == "depth" {
					format.Format = Depth32.TextureFormat()
				}
				if kind == "multi" {
					format.Samples = 4
				}
				owner := &Texture{texture: &wgpu.Texture{}, view: &wgpu.TextureView{}, Format: format}
				tex, view := owner.texture, owner.view
				tx := owner
				if borrowed {
					tx = &Texture{}
					tx.SetShared(owner)
				}
				var err error
				switch kind {
				case "render":
					err = tx.ConfigRenderTexture(&Device{}, &format)
				case "depth":
					err = tx.ConfigDepth(&Device{}, Depth32, &format)
				case "multi":
					err = tx.ConfigMulti(&Device{}, &format)
				}
				if err == nil || tx.texture != nil || tx.view != nil || tx.shared {
					t.Fatal("incomplete/borrowed format shortcut accepted", err, tx.shared)
				}
				if borrowed && (owner.texture != tex || owner.view != view) {
					t.Fatal("configuration changed borrowed owner")
				}
			})
		}
	}
}

func TestVellumEmptyBorrowedTextureRetiresSharedState(t *testing.T) {
	tx := &Texture{}
	tx.SetShared(&Texture{})
	if !tx.shared {
		t.Fatal("empty shared state not established")
	}
	tx.ReleaseTexture()
	if tx.shared || tx.texture != nil || tx.view != nil {
		t.Fatal("empty borrowed retirement retained ownership mode")
	}
	tx.ReleaseTexture()
	if err := tx.CreateTexture(wgpu.TextureUsageTextureBinding); err == nil || tx.shared {
		t.Fatal("refused owned creation retained borrowed mode", err)
	}
}
