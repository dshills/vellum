"""Finalize patch49 from frozen v5; preserve the earlier owned v3 receipt/source."""
import difflib,hashlib,json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');canonical=Path('/Users/dshills/Development/projects/Vellum');p=Path('/private/tmp/vellum-macos-texture-lifecycle');driver=r/'drivers/cogent';stage=driver/'native/patches/texturelifecycle'
sha=lambda b:hashlib.sha256(b).hexdigest();candidate=json.loads((p/'candidate-v5-inputs.json').read_text());inputs=json.loads((p/'original-v5-inputs.json').read_text());assert len(candidate)==len(inputs)==7
outputs={};diff=[]
for n,h in candidate.items():
 old=(canonical/'drivers/cogent/build/upstream'/n).read_bytes()if inputs[n]is not None else b'';assert (sha(old)if old else None)==inputs[n];new=(p/'candidate'/n).read_bytes();assert sha(new)==h;outputs[n]=h
 diff.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
name='0049-complete-texture-readback-ownership.patch';data=''.join(diff).encode();(stage/name).write_bytes(data)
for n,v in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (stage/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=driver/'native/dependencies.json';m=json.loads(manifest.read_text());selected=[s for s in m['dependencies'][0]['stages']if s['inputs']=='native/patches/texturelifecycle/original-hashes.json'];assert len(selected)==1 and len(selected[0]['patches'])==1;selected[0]['patches'][0]['sha256']=sha(data);manifest.write_text(json.dumps(m,indent=2)+'\n')
f=stage/'README.md';s=f.read_text().replace('queue and an owned live same-device pair.', 'queue and an owned live same-device pair with the required usage bits.').replace('Configuration\nshortcuts require live device/queue and an owned live same-device pair.', 'Configuration\nshortcuts require live device/queue and an owned live same-device pair with the\nrequired usage bits.');s+='''
NoDisplayGPU now refuses a missing adapter before device creation and releases
admission references on failed device creation. An injected five-case table
checks these paths. The global instance remains shared until final shutdown.
An explicitly opted-in headless fixture uses tiny real GPU textures/buffers and
records image-to-render/upload usage replacement, 32 staging reference retirements,
device-change retirement and two 3x2 RGBA/BGRA copy/map/image roundtrips. Held old
Go wrappers verify explicit Release, not finalizer activity. This creates no window,
surface or presentation. Successful native pixel/reference checks do not prove
physical heap reclamation, backend fault recovery or runtime performance.
''';f.write_text(s)
f=r/'specs/gpu-frame-lifecycle.md';s=f.read_text().replace('and queue. Explicit device changes retire texture/view/sampler/staging references.', 'and queue with the required texture usage bits. Image/render usage transitions\nrecreate incompatible textures. Explicit device changes retire texture/view/sampler/staging references.');s+='''
An opt-in tiny headless GPU fixture checks actual image/render usage transitions,
32 staging reference retirements, device changes and exact 3x2 RGBA/BGRA padded
copy/map roundtrips. Old wrappers stay strongly held while their IsValid state
proves explicit reference release. These observations remain separate from
physical GPU heap reclamation, native surfaces/presentation and performance.
''';f.write_text(s)
print(json.dumps({'patch_sha256':sha(data),'outputs':outputs,'expected_prepared_files':6187}))
