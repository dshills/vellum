// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"fmt"
	"math"

	"github.com/oliverbestmann/webgpu/wgpu"
)

type liveOwnedReference interface {
	ownedReference
	IsValid() bool
}

// createTexturePair admits only a complete live texture/view pair. Factories
// return fresh owned references. Failed preparation publishes neither handle.
func createTexturePair[T liveOwnedReference, V liveOwnedReference](
	texture func() (T, error), view func(T) (V, error),
) (t T, v V, err error) {
	var zeroT T
	var zeroV V
	succeeded := false
	defer func() {
		if succeeded {
			return
		}
		oldT, oldV := t, v
		t, v = zeroT, zeroV
		if oldT != zeroT {
			defer oldT.Release()
		}
		if oldV != zeroV {
			oldV.Release()
		}
	}()
	t, err = texture()
	if err != nil {
		return
	}
	if t == zeroT || !t.IsValid() {
		err = fmt.Errorf("gpu: texture factory returned no live texture")
		return
	}
	v, err = view(t)
	if err != nil {
		return
	}
	if v == zeroV || !v.IsValid() {
		err = fmt.Errorf("gpu: view factory returned no live view")
		return
	}
	succeeded = true
	return
}

// replaceReadBuffer preserves the old buffer and dimensions on allocation
// refusal. A successful replacement explicitly retires the previous reference.
// Caller serializes configuration, copying, mapping and release; factories
// return fresh owned handles. Native/in-flight reclamation can complete later.
func replaceReadBuffer[B liveOwnedReference](current *B, have *TextureBufferDims, want TextureBufferDims, allocate func() (B, error)) error {
	var zero B
	if *current != zero && (*current).IsValid() && *have == want {
		return nil
	}
	candidate, err := allocate()
	if err != nil {
		if candidate != zero {
			candidate.Release()
		}
		return err
	}
	if candidate == zero || !candidate.IsValid() {
		if candidate != zero {
			candidate.Release()
		}
		return fmt.Errorf("gpu: staging factory returned no live buffer")
	}
	old := *current
	*current, *have = candidate, want
	if old != zero {
		old.Release()
	}
	return nil
}

// textureReadLayout is the four-byte resolve layout used by this synchronous
// readback API. Bounds cover native uint32 row/image fields and Go map lengths.
func textureReadLayout(format TextureFormat) (TextureBufferDims, error) {
	var empty TextureBufferDims
	if format.Size.X < 1 || format.Size.Y < 1 || format.Layers != 1 || format.Samples != 1 {
		return empty, fmt.Errorf("gpu: readback requires a positive single-layer resolve")
	}
	switch format.Format {
	case wgpu.TextureFormatRGBA8Unorm, wgpu.TextureFormatRGBA8UnormSrgb, wgpu.TextureFormatBGRA8Unorm, wgpu.TextureFormatBGRA8UnormSrgb:
	default:
		return empty, fmt.Errorf("gpu: unsupported synchronous readback format")
	}
	width, height := uint64(format.Size.X), uint64(format.Size.Y)
	if width > math.MaxUint32/4 || height > math.MaxUint32 {
		return empty, fmt.Errorf("gpu: readback dimensions exceed native layout fields")
	}
	dims := *NewTextureBufferDims(format.Size)
	if dims.PaddedRowSize > math.MaxUint32 || height > uint64(^uint(0)>>1)/dims.PaddedRowSize {
		return empty, fmt.Errorf("gpu: readback size exceeds native layout or Go map length")
	}
	return dims, nil
}

func (tx *Texture) reusableConfiguration(dev *Device, format TextureFormat) bool {
	return dev != nil && !tx.shared && tx.device.Device == dev.Device && tx.device.Queue == dev.Queue &&
		tx.texture.IsValid() && tx.view.IsValid() && tx.Format == format
}

// Reconfiguration on another device cannot reuse staging or sampler references
// from the prior device. These belong to this Texture, not to borrowed copies.
func (tx *Texture) configureDevice(dev *Device) {
	if tx.device.Device != dev.Device || tx.device.Queue != dev.Queue {
		tx.Release()
	}
	tx.device = *dev
}

// ReadData remains in native channel order. ReadGoImage owns detached data and
// normalizes BGRA resolve bytes to the NRGBA image's channel order.
func normalizeReadImageChannels(data []byte, format wgpu.TextureFormat) {
	if format != wgpu.TextureFormatBGRA8Unorm && format != wgpu.TextureFormatBGRA8UnormSrgb {
		return
	}
	for i := 0; i+3 < len(data); i += 4 {
		data[i], data[i+2] = data[i+2], data[i]
	}
}
