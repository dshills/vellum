// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"errors"
	"image"
	"math"
	"reflect"
	"testing"

	"github.com/oliverbestmann/webgpu/wgpu"
)

type textureRef struct {
	name     string
	valid    bool
	releases int
	events   *[]string
}

func (r *textureRef) IsValid() bool { return r != nil && r.valid && r.releases == 0 }
func (r *textureRef) Release()      { r.releases++; *r.events = append(*r.events, r.name) }

func TestVellumTexturePairPublishesOnlyCompleteCreation(t *testing.T) {
	failure := errors.New("controlled texture factory refusal")
	for _, stage := range []string{"texture_error", "partial_texture", "nil_texture", "invalid_texture", "view_error", "partial_view", "nil_view", "invalid_view", "success"} {
		t.Run(stage, func(t *testing.T) {
			var events []string
			texture := &textureRef{name: "texture.release", valid: true, events: &events}
			view := &textureRef{name: "view.release", valid: true, events: &events}
			viewCalls := 0
			x, y, err := createTexturePair(func() (*textureRef, error) {
				switch stage {
				case "texture_error":
					return nil, failure
				case "partial_texture":
					return texture, failure
				case "nil_texture":
					return nil, nil
				case "invalid_texture":
					texture.valid = false
				}
				return texture, nil
			}, func(got *textureRef) (*textureRef, error) {
				viewCalls++
				if got != texture {
					t.Fatal("view used another texture")
				}
				switch stage {
				case "view_error":
					return nil, failure
				case "partial_view":
					return view, failure
				case "nil_view":
					return nil, nil
				case "invalid_view":
					view.valid = false
				}
				return view, nil
			})
			if stage == "success" {
				if err != nil || x != texture || y != view || len(events) != 0 {
					t.Fatal("complete pair not retained", err, events)
				}
				view.Release()
				texture.Release()
				return
			}
			if err == nil || x != nil || y != nil {
				t.Fatal("incomplete creation published", stage, x, y, err)
			}
			if stage == "texture_error" || stage == "partial_texture" || stage == "view_error" || stage == "partial_view" {
				if err != failure {
					t.Fatal("factory error identity lost", err)
				}
			}
			var want []string
			switch stage {
			case "partial_texture", "invalid_texture", "view_error", "nil_view":
				want = []string{"texture.release"}
			case "partial_view", "invalid_view":
				want = []string{"view.release", "texture.release"}
			}
			if !reflect.DeepEqual(events, want) {
				t.Fatal("partial ownership differs", events, want)
			}
			if (stage == "texture_error" || stage == "partial_texture" || stage == "nil_texture" || stage == "invalid_texture") && viewCalls != 0 {
				t.Fatal("view factory called for refused texture")
			}
		})
	}
}

func TestVellumReadBufferRefusalPreservesOldAllocation(t *testing.T) {
	failure := errors.New("controlled staging refusal")
	for _, stage := range []string{"error", "partial", "nil", "invalid", "success", "hit"} {
		t.Run(stage, func(t *testing.T) {
			var events []string
			old := &textureRef{name: "old", valid: true, events: &events}
			next := &textureRef{name: "new", valid: true, events: &events}
			current := old
			have := *NewTextureBufferDims(image.Pt(64, 2))
			original := have
			want := *NewTextureBufferDims(image.Pt(65, 2))
			if stage == "hit" {
				want = have
			}
			calls := 0
			err := replaceReadBuffer(&current, &have, want, func() (*textureRef, error) {
				calls++
				switch stage {
				case "error":
					return nil, failure
				case "partial":
					return next, failure
				case "nil":
					return nil, nil
				case "invalid":
					next.valid = false
				}
				return next, nil
			})
			if stage == "hit" {
				if err != nil || calls != 0 || current != old || have != original || len(events) != 0 {
					t.Fatal("matching buffer replaced")
				}
				return
			}
			if calls != 1 {
				t.Fatal("allocation retry", calls)
			}
			if stage == "success" {
				if err != nil || current != next || have != want || !reflect.DeepEqual(events, []string{"old"}) {
					t.Fatal("replacement ownership differs", err, events)
				}
				return
			}
			if err == nil || current != old || have != original || old.releases != 0 {
				t.Fatal("refusal retired/reconfigured old buffer", err, events)
			}
			if (stage == "error" || stage == "partial") && err != failure {
				t.Fatal("allocation error identity lost")
			}
			wantReleases := 0
			if stage == "partial" || stage == "invalid" {
				wantReleases = 1
			}
			if next.releases != wantReleases {
				t.Fatal("partial staging not retired", events)
			}
		})
	}
}

func TestVellumReadBufferThousandResizesHaveExplicitRetirement(t *testing.T) {
	var current *textureRef
	var dims TextureBufferDims
	var events []string
	var refs []*textureRef
	live, peak := 0, 0
	for i := 0; i < 1000; i++ {
		want := *NewTextureBufferDims(image.Pt(64+i%3, i+1))
		err := replaceReadBuffer(&current, &dims, want, func() (*textureRef, error) {
			for _, r := range refs {
				if r.releases > 1 {
					t.Fatal("staging released twice")
				}
			}
			live = 0
			for _, r := range refs {
				if r.releases == 0 {
					live++
				}
			}
			live++
			if live > peak {
				peak = live
			}
			r := &textureRef{name: "retire", valid: true, events: &events}
			refs = append(refs, r)
			return r, nil
		})
		if err != nil || current != refs[len(refs)-1] || dims != want {
			t.Fatal("resize not committed", i, err)
		}
		if len(events) != i {
			t.Fatal("old staging waiting for GC", i, len(events))
		}
	}
	current.Release()
	for _, r := range refs {
		if r.releases != 1 {
			t.Fatal("staging ownership retained", r.releases)
		}
	}
	if peak != 2 || len(events) != 1000 {
		t.Fatal("replacement exceeds old-plus-new ownership", peak, len(events))
	}
}

func TestVellumReadLayoutAdmissionAndExactPadding(t *testing.T) {
	format := TextureFormat{Size: image.Pt(65, 3), Layers: 1, Samples: 1, Format: wgpu.TextureFormatRGBA8UnormSrgb}
	nativeMax := uint64(math.MaxUint32)
	dims, err := textureReadLayout(format)
	if err != nil || dims != (TextureBufferDims{Width: 65, Height: 3, UnpaddedRowSize: 260, PaddedRowSize: 512}) || dims.PaddedSize() != 1536 {
		t.Fatal("padding changed", dims, err)
	}
	for _, mutation := range []func(*TextureFormat){
		func(f *TextureFormat) { f.Size.X = 0 }, func(f *TextureFormat) { f.Size.Y = -1 }, func(f *TextureFormat) { f.Layers = 2 }, func(f *TextureFormat) { f.Samples = 4 }, func(f *TextureFormat) { f.Format = wgpu.TextureFormatRGBA16Float },
		func(f *TextureFormat) { f.Size.X = int(math.MaxUint32/4) + 1 }, func(f *TextureFormat) { f.Size.X = int((math.MaxUint32/256)*256/4) + 1 },
		func(f *TextureFormat) { f.Size.Y = int(nativeMax) + 1 }, func(f *TextureFormat) { f.Size = image.Pt(int((math.MaxUint32/256)*256/4), int(nativeMax)) },
	} {
		f := format
		mutation(&f)
		if got, err := textureReadLayout(f); err == nil || got != (TextureBufferDims{}) {
			t.Fatal("invalid/overflow layout admitted", f, got, err)
		}
	}
	for _, f := range []wgpu.TextureFormat{wgpu.TextureFormatRGBA8Unorm, wgpu.TextureFormatRGBA8UnormSrgb, wgpu.TextureFormatBGRA8Unorm, wgpu.TextureFormatBGRA8UnormSrgb} {
		format.Format = f
		if _, err := textureReadLayout(format); err != nil {
			t.Fatal("four-byte resolve refused", f, err)
		}
	}
}

func TestVellumReadbackRefusesInvalidNativeInputsWithoutMutation(t *testing.T) {
	format := TextureFormat{Size: image.Pt(65, 3), Layers: 1, Samples: 1, Format: wgpu.TextureFormatRGBA8UnormSrgb}
	tx := &Texture{Format: format, readBuffer: &wgpu.Buffer{}, ReadBufferDims: *NewTextureBufferDims(image.Pt(1, 1))}
	buffer, dims := tx.readBuffer, tx.ReadBufferDims
	if err := tx.ConfigReadBuffer(); err == nil {
		t.Fatal("missing device accepted")
	}
	if err := tx.CopyToReadBuffer(&wgpu.CommandEncoder{}); err == nil {
		t.Fatal("stale layout accepted")
	}
	if data, err := tx.ReadDataMapped(); err == nil || data != nil {
		t.Fatal("stale read configured/mapped a new empty buffer")
	}
	if tx.readBuffer != buffer || tx.ReadBufferDims != dims {
		t.Fatal("refusal changed staging")
	}
	tx.ReadBufferDims = *NewTextureBufferDims(format.Size)
	if err := tx.CopyToReadBuffer(&wgpu.CommandEncoder{}); err == nil {
		t.Fatal("invalid native staging accepted")
	}
	if data, err := tx.ReadDataMapped(); err == nil || data != nil {
		t.Fatal("invalid native staging mapped")
	}
	tx.Release()
	if tx.readBuffer != nil || tx.ReadBufferDims != (TextureBufferDims{}) {
		t.Fatal("release retained staging metadata")
	}
}

func TestVellumReadGoImageChannelOrder(t *testing.T) {
	for _, format := range []wgpu.TextureFormat{wgpu.TextureFormatRGBA8Unorm, wgpu.TextureFormatRGBA8UnormSrgb, wgpu.TextureFormatBGRA8Unorm, wgpu.TextureFormatBGRA8UnormSrgb} {
		data := []byte{5, 17, 31, 255, 49, 71, 101, 127}
		want := append([]byte(nil), data...)
		if format == wgpu.TextureFormatBGRA8Unorm || format == wgpu.TextureFormatBGRA8UnormSrgb {
			want = []byte{31, 17, 5, 255, 101, 71, 49, 127}
		}
		normalizeReadImageChannels(data, format)
		if !reflect.DeepEqual(data, want) {
			t.Fatal("image channels/alpha changed", format, data)
		}
	}
}

func TestVellumTextureDeviceChangeRetiresStaging(t *testing.T) {
	tx := &Texture{device: Device{Device: &wgpu.Device{}, Queue: &wgpu.Queue{}}, texture: &wgpu.Texture{}, view: &wgpu.TextureView{}, readBuffer: &wgpu.Buffer{}, ReadBufferDims: *NewTextureBufferDims(image.Pt(2, 3))}
	format := TextureFormat{Size: image.Pt(2, 3), Layers: 1, Samples: 1, Format: wgpu.TextureFormatRGBA8UnormSrgb}
	if err := tx.ConfigRenderTexture(&Device{}, &format); err == nil {
		t.Fatal("invalid replacement device accepted")
	}
	if tx.readBuffer != nil || tx.ReadBufferDims != (TextureBufferDims{}) || tx.texture != nil || tx.view != nil {
		t.Fatal("device change retained prior resources")
	}
}
