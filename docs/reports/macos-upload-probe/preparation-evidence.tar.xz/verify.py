from pathlib import Path
import json,hashlib,os
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');d=json.loads((q/'build-identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(q/'framework')==d['binary_sha256'] and os.access(q/'framework',os.X_OK);assert sha(Path(d['root'])/'libs-darwin/arm64/libwgpu_native.a')==d['archive_sha256'];assert all(sha(Path(p))==h for p,h in d['private_source_pins'].items());assert (Path(d['root'])/'core/src/upload_probe.rs').read_bytes()==(t/'tools/macos-calibration/upload/probe.rs').read_bytes()
for name in ['fixture.go','fixture_test.go']:assert (t/'tools/macos-calibration/upload/framework'/name).read_bytes()==(t/'tools/macos-calibration/framework'/name).read_bytes()
overlay=json.loads((q/'overlay.json').read_text())['Replace'];recipe=json.loads((t/'tools/macos-calibration/sourcecost/overlay.json').read_text())['patches'];assert len(overlay)==len(recipe)==3
for original,target in overlay.items():
 r=next(r for r in recipe if original.endswith('/'+r['file']));s=Path(original).read_text();assert s.count(r['before'])==1 and Path(target).read_text()==s.replace(r['before'],r['after'])
for p in (t/'tools/macos-calibration/upload').rglob('*.py'):compile(p.read_text(),str(p),'exec')
print('PASS exact private source/native/archive/binary/mode/three overlay identities;original view/routing bytes;sourcesyntax. No native execution or qualification claim.')
