from pathlib import Path
import sys,json,time,os,threading,_thread
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
base=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go'];mod=['-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly','-overlay='+str(W/'overlay.json')];mode=sys.argv[1];args={
 'test-diagnostic':base+['test',*['-overlay='+str(W/'diagnostic-overlay.json') if x.startswith('-overlay=') else x for x in mod],'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','-run=TestVellumSceneCompositionDiagnostic','-count=1','-v','-timeout=2m'],
 'test':base+['test',*mod,'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/sceneplan','-run=TestVellumGPUCulling|TestVellumScenePlanGPUCovered|TestVellumTileBinning','-count=1','-v','-timeout=2m'],
 'full':base+['test',*mod,'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/sceneplan','cogentcore.org/core/paint/renderers/rasterx','cogentcore.org/core/paint/renderers/gpuscene','-count=1','-timeout=4m'],
 'native-gpu-v2':base+['test',*mod,'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','-count=1','-v','-timeout=4m'],
 'native-gpu':base+['test',*mod,'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','-count=1','-v','-timeout=4m'],
 'vet':base+['vet',*mod,'-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','cogentcore.org/core/paint/renderers/sceneplan'],
 'build-diagnostic':base+['build',*['-overlay='+str(W/'diagnostic-overlay.json') if x.startswith('-overlay=') else x for x in mod],'-trimpath','-buildvcs=false','-o','/private/tmp/vellum-ready-native-5482f9b/bin/tile-culling-composition','.'],
 'build':base+['build',*mod,'-trimpath','-buildvcs=false','-o','/private/tmp/vellum-ready-native-5482f9b/bin/tile-culling','.']
}[mode];env=dict(os.environ,GOMAXPROCS='2',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOPROXY='off');env.pop('GOFLAGS',None);start=time.monotonic()
if mode.startswith('native-gpu'):env['VELLUM_GPU_SCENE_TEST']='1'
from contextlib import nullcontext
import importlib.util
spec=importlib.util.spec_from_file_location('culling_gpu_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py');lease=importlib.util.module_from_spec(spec);spec.loader.exec_module(lease)
finished=threading.Event();stop=W/('stop-'+mode)
if mode.startswith('native-gpu'):
 if stop.exists():raise ValueError('sealed GPU case')
 def watch():
  while not finished.wait(.2):
   if stop.exists():_thread.interrupt_main();return
 threading.Thread(target=watch,daemon=True).start()
try:
 with (lease.LiveLease() if mode.startswith('native-gpu') else nullcontext()):
  with (W/(mode+'.stdout')).open('xb')as out,(W/(mode+'.stderr')).open('xb')as err:r=run_child(args,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=300,log_limit_bytes=2<<20)
finally:
 finished.set()
 if mode.startswith('native-gpu'):stop.touch()
d={'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start};(W/(mode+'-command.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
