from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
F=T/'docs/reports/macos-scene-composition';F.mkdir(exist_ok=True);(F/'README.md').write_text((W/'report/README.md').read_text())
p=T/'specs/macos-completion.md';s=p.read_text();anchor='## Latest unattended evidence\n\n';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''The [scene composition and tile-culling checkpoint](../docs/reports/macos-scene-composition/README.md)
reconciles 480 measured packets across fixed/variable 10k/1M rows. Packet-local
masks already reuse 83 resources; Ops/Refs dominate input. The resulting private
GPU tile-culling experiment passes race, native pixel/retention, vet and build
checks, but is rejected: only one of five ordinary pairs improves, median
run-p95 5.002915 → 5.028750 ms. Separate diagnostics prove references fall
55,388 → 19,405; that does not establish a latency improvement. All ten ordinary
p95s fail 4 ms; one baseline p99 also fails 6 ms. Private overlays are archived,
with no runtime or prepared dependency changes and no further culling tuning.
All remaining full Mac gates remain open. The delivery plan records the next
material architecture boundary; source-details timings do not qualify it.

''');p.write_text(s)
p=T/'specs/macos-delivery.md';s=p.read_text()
a='''3. **M3-A is complete and rejected.** The current complete table matrix still
   fails. The internally reviewed segmented snapshot passes correctness checks
   but loses all five native pairs; the entire experiment is reverted. Stop
   small follow-up AX tuning. Use the available desktop next for M2/M5 native
   workflows. Before another M3 scene/renderer redesign, collect actual operation
   and resource-kind counts, encoded-buffer composition and source-phase evidence
   for the failing fixture. M6 inventory can proceed independently.'''
b='''3. **M3-A and tile culling are complete and rejected.** The complete table
   matrix still fails. No follow-up AX, packed-upload or tile-culling microtuning
   is queued. The [composition checkpoint](../docs/reports/macos-scene-composition/README.md)
   measures 480 actual packets and the failed five-pair culling comparison.
   Smaller input alone does not improve total-frame work. The next material
   implementation boundary is recorded below; CPU and GPU paths both need
   qualification. M6 inventory can proceed independently.'''
assert s.count(a)==1;s=s.replace(a,b)
a='''The bounded M3 investigation produces the current full-matrix decision. The
next deliverable is M3-A's adopted/rejected implementation result, then a full
matrix rerun after adoption. Update the remaining estimate from that result.'''
b='''The full matrix, rejected M3-A and rejected tile-culling comparisons are now
recorded. The next deliverable is a material retained-work architecture decision
and bounded implementation against the same frame targets, followed by a full
matrix rerun only after adoption. Update the remaining estimate from that result.'''
assert s.count(a)==1;s=s.replace(a,b)
a='Next: M3-A owned segmented ready snapshot below; no further small encoder tuning.';b='[Composition and rejected culling](../docs/reports/macos-scene-composition/README.md) now rule out smaller references alone. Next: material retained-work implementation below; no further AX/upload/culling microtuning.';assert s.count(a)==1;s=s.replace(a,b)
p.write_text(s)
print('Updated report and two completion specs')
