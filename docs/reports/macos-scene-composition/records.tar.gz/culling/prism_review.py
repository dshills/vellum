from pathlib import Path
import sys,time,json
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
args=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','60000','--max-diff-bytes','65000','--rules',str(W/'prism-rules.json'),'--format','json','--out',str(W/'prism.json')]
started=time.monotonic()
with (W/'prism.stdout').open('xb')as out,(W/'prism.stderr').open('xb')as err:
 r=run_child(args,cwd=T,timeout=300,stdout=out,stderr=err,log_limit_bytes=2<<20)
d={'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-started};(W/'prism-command.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
