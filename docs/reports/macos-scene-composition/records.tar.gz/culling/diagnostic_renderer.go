// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"image"
	"image/draw"
	"os"
	"sort"
	"time"

	"cogentcore.org/core/gpu"
	"cogentcore.org/core/gpu/gpudraw"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/system/composer"
)

const maxJournalPackets = 256

// Stats contains host-side routing counts only. A submitted packet is not a
// GPU-completion timestamp or proof that a presentation succeeded.
type Stats struct {
	Submitted, Reused, CPUFallbacks, Materializations uint64
	JournalBytes, JournalPackets                      int
	LastFallback                                      string
}

// Renderer is owned and serialized by the same Scene RC as rasterx.Renderer.
// Its CPU base plus bounded immutable journal reconstruct every accepted paint
// batch without readback. Only resources (GPU handles) are registered with the
// drawer; its retirement callback holds no widget, font or application state.
type Renderer struct {
	cpu          *rasterx.Renderer
	encoding     sceneplan.EncodingScratch
	journal      []*sceneplan.Packet
	journalBytes int
	resources    *resources
	drawer       *gpudraw.Drawer
	lease        *gpudraw.SceneSourceLease
	closed       bool
	imageExposed bool
	stats        Stats
}

func New(size math32.Vector2) render.Renderer {
	return &Renderer{cpu: rasterx.New(size).(*rasterx.Renderer)}
}
func (r *Renderer) SupportsTextBatch() bool {
	return r != nil && r.cpu != nil && r.cpu.SupportsTextBatch()
}

func (r *Renderer) Size() (units.Units, math32.Vector2) { return r.cpu.Size() }
func (r *Renderer) Source() []byte                      { return nil }
func (r *Renderer) Stats() Stats {
	s := r.stats
	s.JournalBytes = r.journalBytes
	s.JournalPackets = len(r.journal)
	return s
}
func (r *Renderer) materialize() {
	if len(r.journal) == 0 {
		return
	}
	dst := r.cpu.Image().(*image.RGBA)
	for _, p := range r.journal {
		p.Replay(dst)
		r.cpu.Scanner.SetWinding(p.Winding())
	}
	clear(r.journal)
	r.journal = r.journal[:0]
	r.journalBytes = 0
	r.stats.Materializations++
}
func (r *Renderer) invalidate() {
	if r.lease != nil {
		if err := r.lease.WithResources(func(*gpudraw.SceneGPUContext) error { r.resources.ready = false; return nil }); err != nil {
			r.closeLease()
		}
	}
}

// Image returns the usual mutable CPU image. Conservatively invalidate GPU
// reuse because a caller may modify those bytes after this explicit snapshot.
func (r *Renderer) Image() image.Image {
	r.materialize()
	r.imageExposed = true
	r.invalidate()
	return r.cpu.Image()
}
func (r *Renderer) Render(commands render.Render) render.Renderer {
	r.materialize()
	r.invalidate()
	r.cpu.Render(commands)
	return r
}
func (r *Renderer) SetSize(un units.Units, size math32.Vector2) {
	_, old := r.cpu.Size()
	if old == size {
		return
	}
	r.closeLease()
	r.encoding.Reset()
	clear(r.journal)
	r.journal = nil
	r.journalBytes = 0
	r.imageExposed = false
	r.cpu.SetSize(un, size)
}
func (r *Renderer) closeLease() error {
	if r.lease != nil {
		if err := r.lease.Close(); err != nil {
			// A pending composition or another admitted resource scope keeps
			// registry ownership until its safe drain point. The callback
			// retains private resources only, so the Scene can retire now.
			if requestErr := r.lease.RequestClose(); requestErr != nil {
				return requestErr
			}
		}
	}
	r.lease, r.drawer, r.resources = nil, nil, nil
	return nil
}
func (r *Renderer) Release() {
	r.encoding.Reset()
	if r.closed {
		r.cpu.Release()
		return
	}
	r.closed = true
	r.closeLease()
	// Preserve the usual explicit CPU snapshot semantics after destruction.
	r.materialize()
	r.cpu.Release()
}
func (r *Renderer) ensureLease(dw *gpudraw.Drawer) error {
	if r.closed {
		return fmt.Errorf("gpuscene: renderer retired")
	}
	if r.drawer == dw && r.lease != nil {
		return nil
	}
	// A new window/device cannot inherit a texture from the previous drawer.
	r.materialize()
	if err := r.closeLease(); err != nil {
		return err
	}
	res := &resources{}
	lease, err := dw.NewSceneSource(res.release)
	if err != nil {
		return err
	}
	r.drawer, r.lease, r.resources = dw, lease, res
	return nil
}
func (r *Renderer) remember(p *sceneplan.Packet) {
	if p.Independent() {
		clear(r.journal)
		r.journal = r.journal[:0]
		r.journalBytes = 0
	} else if len(r.journal) == maxJournalPackets || r.journalBytes+p.Bytes() > sceneplan.MaxBytes {
		r.materialize()
	}
	if p.Operations() != 0 {
		r.journal = append(r.journal, p)
		r.journalBytes += p.Bytes()
	}
	r.cpu.Scanner.SetWinding(p.Winding())
	// A retained mutable Image pointer has the original rasterx semantics:
	// subsequent accepted paint updates it, and later partial GPU paint must
	// conservatively seed any caller modifications from this same CPU base.
	if r.imageExposed {
		r.materialize()
	}
}
func (r *Renderer) fallback(dw composer.Drawer, commands render.Render, dp image.Point, op draw.Op, measured bool, reason error) composer.SourceTiming {
	r.materialize()
	// Keep an admitted pool across unsupported paint. Mark its bytes stale so
	// the next partial accepted batch seeds the reconstructed CPU base once.
	r.invalidate()
	r.stats.CPUFallbacks++
	if reason != nil {
		message := reason.Error()
		if len(message) > 256 {
			message = message[:256]
		}
		r.stats.LastFallback = message
	}
	changed := len(commands) != 0
	record := composer.SourceTiming{RasterAvailable: true, CopyAvailable: true, ImageChanged: changed}
	if changed {
		if measured {
			start := time.Now()
			r.cpu.Render(commands)
			record.RasterNS = time.Since(start).Nanoseconds()
		} else {
			r.cpu.Render(commands)
		}
	}
	img := r.cpu.Image()
	record.ImageWidth, record.ImageHeight = img.Bounds().Dx(), img.Bounds().Dy()
	// A fallback's owned Go texture may occupy a former borrowed GPU slot.
	// Force upload; checked slot conversion establishes independent ownership.
	if measured {
		start := time.Now()
		dw.Copy(dp, img, img.Bounds(), op, false)
		record.CopyNS = time.Since(start).Nanoseconds()
	} else {
		dw.Copy(dp, img, img.Bounds(), op, false)
	}
	return record
}

// DrawScene executes at the original paintSource ordinal, using the originating
// drawer's device. Both ordinary and diagnostic Core paths call this method.
// GPU host work remains inside outer Draw timing; CPU Raster/Copy timings are
// available only on fallback, without pretending Submit measures GPU execution.
func (r *Renderer) DrawScene(dw composer.Drawer, commands render.Render, dp image.Point, op draw.Op, measured bool) (record composer.SourceTiming) {
	var host *composer.SceneHostTiming
	if measured {
		host = &composer.SceneHostTiming{Available: true, Fallback: true}
		// A named result preserves attempted GPU work when a later refusal returns
		// the CPU fallback's own raster/copy observation.
		defer func() { record.SceneHost = *host }()
	}
	as, ok := dw.(gpudraw.AsGPUDrawer)
	if !ok || as.AsGPUDrawer() == nil {
		return r.fallback(dw, commands, dp, op, measured, fmt.Errorf("gpuscene: drawer has no GPU scene support"))
	}
	gpuDrawer := as.AsGPUDrawer()
	if err := r.ensureLease(gpuDrawer); err != nil {
		return r.fallback(dw, commands, dp, op, measured, err)
	}
	_, size := r.cpu.Size()
	bounds := image.Rectangle{Max: size.ToPointCeil()}
	if len(commands) == 0 && r.imageExposed {
		return r.fallback(dw, commands, dp, op, measured, fmt.Errorf("gpuscene: mutable CPU image exposure requires current copy"))
	}
	var packet *sceneplan.Packet
	var encoded *sceneplan.Encoded
	if len(commands) != 0 {
		var start time.Time
		if host != nil {
			host.CaptureAttempted = true
			start = time.Now()
		}
		packet = r.cpu.ScenePacket(commands)
		if host != nil {
			host.CaptureNS = time.Since(start).Nanoseconds()
		}
		if packet == nil {
			return r.fallback(dw, commands, dp, op, measured, fmt.Errorf("gpuscene: unsupported or over-budget paint batch"))
		}
		if host != nil {
			host.EncodeAttempted = true
			start = time.Now()
		}
		// Queue input writes copy these bytes synchronously below. Neither
		// the immutable journal nor GPU retirement retains this encoding.
		encoded, ok = packet.EncodeGPUWithScratch(&r.encoding)
		if host != nil {
			host.EncodeNS = time.Since(start).Nanoseconds()
		}
		if !ok {
			return r.fallback(dw, commands, dp, op, measured, fmt.Errorf("gpuscene: encoded paint exceeds limits"))
		}
		if host != nil {
			observation, err := vellumObserveScene(packet, encoded)
			observation.CommandTypes = map[string]int{}
			for _, command := range commands {
				observation.CommandTypes[fmt.Sprintf("%T", command)]++
			}
			if err != nil {
				observation.Error = err.Error()
			}
			if err := json.NewEncoder(os.Stdout).Encode(observation); err != nil {
				fmt.Fprintln(os.Stderr, "scene diagnostic output:", err)
			}
		}
	}
	var leaseStart time.Time
	if host != nil {
		host.LeaseAttempted = true
		leaseStart = time.Now()
	}
	err := r.lease.Draw(gpudraw.SceneDraw{Size: bounds.Size(), DP: dp, SR: bounds, Op: op}, func(ctx *gpudraw.SceneGPUContext) (*gpu.Texture, error) {
		if host != nil {
			host.ResourcesEntered = true
			start := time.Now()
			defer func() { host.ResourcesNS = time.Since(start).Nanoseconds() }()
		}
		res := r.resources
		if res.device.Device != ctx.Device.Device || res.size != bounds.Size() || res.texture == nil {
			res.release()
			if err := ctx.SetBudget(0); err != nil {
				return nil, err
			}
			if err := res.initialize(ctx.Device, bounds.Size(), ctx.SetBudget); err != nil {
				return nil, err
			}
		}
		if packet == nil {
			if !res.ready {
				return nil, fmt.Errorf("gpuscene: empty batch has no current GPU source")
			}
			return res.texture, nil
		}
		if (!res.ready || r.imageExposed) && !packet.Independent() {
			r.materialize()
			if err := res.seed(r.cpu.Image().(*image.RGBA)); err != nil {
				return nil, err
			}
		}
		if err := res.renderWithTiming(encoded, ctx.SetBudget, host); err != nil {
			return nil, err
		}
		return res.texture, nil
	})
	if host != nil {
		host.LeaseNS = time.Since(leaseStart).Nanoseconds()
	}
	if err != nil {
		return r.fallback(dw, commands, dp, op, measured, err)
	}
	if host != nil {
		host.DrawAccepted = true
		host.Fallback = false
		host.Reused = packet == nil
	}
	if packet != nil {
		r.remember(packet)
		r.stats.Submitted++
	} else {
		r.stats.Reused++
	}
	return composer.SourceTiming{ImageWidth: bounds.Dx(), ImageHeight: bounds.Dy(), ImageChanged: len(commands) != 0}
}

// Temporary diagnostic-only overlay. No accepted packet/encoding is modified.
// Resource identity here is a data-section offset within this packet, not a
// persistent content identity or an estimate of native/GPU resident memory.
type vellumSceneObservation struct {
	Event                  string         `json:"event"`
	Error                  string         `json:"error,omitempty"`
	PacketOperations       int            `json:"packet_operations"`
	Bounds                 [4]int         `json:"bounds"`
	EncodedKinds           [4]int         `json:"encoded_kinds"`
	CommandTypes           map[string]int `json:"command_types"`
	BufferBytes            [4]int         `json:"buffer_bytes"`
	TileCount              int            `json:"tile_count"`
	TileReferences         int            `json:"tile_references"`
	MaxTileReferences      int            `json:"max_tile_references"`
	MaskReferences         int            `json:"mask_references"`
	UnculledTileReferences int            `json:"unculled_gpu_tile_references"`
	Resources              map[string]int `json:"resources"`
	DataBytes              map[string]int `json:"data_bytes"`
}

func vellumObserveScene(p *sceneplan.Packet, e *sceneplan.Encoded) (s vellumSceneObservation, err error) {
	s.Event = "scene.composition.diagnostic"
	s.Resources, s.DataBytes = map[string]int{}, map[string]int{}
	if p == nil || e == nil {
		return s, fmt.Errorf("missing packet/encoding")
	}
	s.PacketOperations = p.Operations()
	r := p.Bounds()
	s.Bounds = [4]int{r.Min.X, r.Min.Y, r.Dx(), r.Dy()}
	s.BufferBytes = [4]int{len(e.Ops), len(e.Rows), len(e.Refs), len(e.Data)}
	if (len(e.Ops)%64 != 0 && len(e.Ops) != 4) || len(e.Rows)%8 != 0 || len(e.Refs)%4 != 0 || len(e.Data)%4 != 0 {
		return s, fmt.Errorf("encoding alignment")
	}
	starts := map[int]string{}
	add := func(word uint32, kind string) error {
		at := uint64(word) * 4
		if at >= uint64(len(e.Data)) {
			return fmt.Errorf("resource offset")
		}
		if prior, ok := starts[int(at)]; ok && prior != kind {
			return fmt.Errorf("resource kind collision")
		}
		starts[int(at)] = kind
		return nil
	}
	for i := 0; i+64 <= len(e.Ops); i += 64 {
		o := e.Ops[i : i+64]
		kind := binary.LittleEndian.Uint32(o[32:36])
		if kind > sceneplan.Spans {
			return s, fmt.Errorf("unknown operation kind")
		}
		s.EncodedKinds[kind]++
		minX, minY, maxX, maxY := int(binary.LittleEndian.Uint32(o)), int(binary.LittleEndian.Uint32(o[4:])), int(binary.LittleEndian.Uint32(o[8:])), int(binary.LittleEndian.Uint32(o[12:]))
		if minX < maxX && minY < maxY {
			s.UnculledTileReferences += ((maxX-1)/sceneplan.TileSize - minX/sceneplan.TileSize + 1) * ((maxY-1)/sceneplan.TileSize - minY/sceneplan.TileSize + 1)
		}

		if mask := binary.LittleEndian.Uint32(o[48:52]); mask != ^uint32(0) {
			s.MaskReferences++
			if err := add(mask, "mask"); err != nil {
				return s, err
			}
		}
		switch kind {
		case sceneplan.Pixels:
			if err := add(binary.LittleEndian.Uint32(o[40:44]), "pixels"); err != nil {
				return s, err
			}
		case sceneplan.Spans:
			if err := add(binary.LittleEndian.Uint32(o[40:44]), "spans"); err != nil {
				return s, err
			}
		}
	}
	s.TileCount = len(e.Rows) / 8
	if s.TileCount != e.Tiles.X*e.Tiles.Y {
		return s, fmt.Errorf("tile dimensions")
	}
	next := uint64(0)
	for i := 0; i < len(e.Rows); i += 8 {
		offset, count := binary.LittleEndian.Uint32(e.Rows[i:i+4]), binary.LittleEndian.Uint32(e.Rows[i+4:i+8])
		if uint64(offset) != next {
			return s, fmt.Errorf("noncontiguous tile references")
		}
		next += uint64(count)
		s.MaxTileReferences = max(s.MaxTileReferences, int(count))
	}
	if next > uint64(sceneplan.MaxTileReferences) || int(next)*4 != len(e.Refs) && !(next == 0 && len(e.Refs) == 4) {
		return s, fmt.Errorf("reference byte total")
	}
	s.TileReferences = int(next)
	for i := 0; i < s.TileReferences; i++ {
		if int(binary.LittleEndian.Uint32(e.Refs[i*4:i*4+4])) >= len(e.Ops)/64 {
			return s, fmt.Errorf("reference operation index")
		}
	}
	positions := make([]int, 0, len(starts))
	for at := range starts {
		positions = append(positions, at)
	}
	sort.Ints(positions)
	if len(positions) == 0 {
		if len(e.Data) != 4 {
			return s, fmt.Errorf("unexpected unowned data")
		}
		s.DataBytes["padding"] = 4
	} else {
		if positions[0] != 0 {
			return s, fmt.Errorf("resource prefix gap")
		}
		for i, at := range positions {
			end := len(e.Data)
			if i+1 < len(positions) {
				end = positions[i+1]
			}
			s.Resources[starts[at]]++
			s.DataBytes[starts[at]] += end - at
		}
	}
	return s, nil
}
