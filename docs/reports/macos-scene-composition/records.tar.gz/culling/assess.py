from pathlib import Path
import json,hashlib,statistics,math,subprocess,datetime
W=Path(__file__).resolve().parent
r=json.loads((W/'native-comparison.json').read_text());assert r['result']=='MEASURED' and r['error'] is None
runs={};paired=[]
def nr(a,q):return sorted(a)[math.ceil(len(a)*q)-1]
for label in ('baseline','candidate'):
 runs[label]=[]
 for i,rec in enumerate(r['cases'][label]['runs'],1):
  p=W/'native'/f'{i}-{label}'/'native.log';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==rec['log_sha256']
  records=[]
  for line in raw.splitlines():
   try:x=json.loads(line)
   except (ValueError,UnicodeDecodeError):continue
   assert x.get('event')!='scene.composition.diagnostic'
   if x.get('event')=='grid.perf.sample':records.append(x)
  assert len(records)==120 and rec['exit_code']==0
  assert all(x['native_sample']['Completed'] and not x['native_sample']['Failure'] and x['geometry']['cells']>=400 for x in records)
  v={'pair':i,'p95_ns':nr([x['metrics']['ui_work_ns'] for x in records],.95),'p99_ns':nr([x['metrics']['ui_work_ns'] for x in records],.99),'alloc_p50_bytes':nr([x['go_process_alloc_bytes'] for x in records],.5)}
  assert v['p95_ns']==rec['ui_work_ns']['p95'] and v['p99_ns']==rec['ui_work_ns']['p99'] and v['alloc_p50_bytes']==rec['go_process_alloc_bytes']['p50'];runs[label].append(v)
for a,b in zip(runs['baseline'],runs['candidate']):paired.append({'pair':a['pair'],'baseline_p95_ns':a['p95_ns'],'candidate_p95_ns':b['p95_ns'],'baseline_p99_ns':a['p99_ns'],'candidate_p99_ns':b['p99_ns'],'p95_improved':b['p95_ns']<a['p95_ns']})
med={k:int(statistics.median([x['p95_ns'] for x in v])) for k,v in runs.items()};alloc={k:int(statistics.median([x['alloc_p50_bytes'] for x in v])) for k,v in runs.items()}
assert med['baseline']-med['candidate']<400000 and sum(x['p95_improved'] for x in paired)<4
p={'source_base':'31afa90add2b2d3a68e0dc789ddad0268b792611','result':'REJECT_PRIVATE_OVERLAY','adoption_bar_met':False,'ordinary_samples_recomputed':1200,'paired_p95_improvements':sum(x['p95_improved'] for x in paired),'median_run_p95_ns':med,'median_of_run_alloc_p50_bytes':alloc,'pairs':paired,'p95_target_pass_runs':{k:sum(x['p95_ns']<=4000000 for x in v) for k,v in runs.items()},'p99_target_pass_runs':{k:sum(x['p99_ns']<=6000000 for x in v) for k,v in runs.items()},'diagnostic_samples':r['diagnostic']['samples'],'diagnostic_unculled_refs_p50':r['diagnostic']['unculled_refs']['p50'],'diagnostic_culled_refs_p50':r['diagnostic']['culled_refs']['p50'],'diagnostic_input_bytes_p50':r['diagnostic']['checked_input_bytes']['p50'],'diagnostic_timing_qualified':False,'runtime_changed':False,'closed_mac_gates':[],'next':'No further tile-culling tuning. Resolve material total-frame work with an explicit architecture decision; CPU path and human native gates remain open.','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(W/'assessment.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p,indent=2))
