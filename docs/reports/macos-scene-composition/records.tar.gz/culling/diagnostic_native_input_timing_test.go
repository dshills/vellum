//go:build !js

package gpuscene

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"testing"

	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/system/composer"
	"github.com/oliverbestmann/webgpu/wgpu"
)

func inputTimingFixture(t *testing.T, bounds image.Rectangle) (*sceneplan.Packet, *sceneplan.Encoded) {
	t.Helper()
	b := sceneplan.New(bounds)
	b.Draw(bounds, image.NewUniform(color.RGBA{13, 31, 59, 255}), image.Point{}, nil, image.Point{}, draw.Src)
	// Three operations force a non-power-of-two Ops encoding. Buffer growth
	// rounds capacity upward; metrics must still count the shorter payload.
	b.Draw(image.Rect(2, 3, 8, 9), image.NewUniform(color.RGBA{71, 19, 103, 255}), image.Point{}, nil, image.Point{}, draw.Src)
	b.Draw(image.Rect(11, 4, 20, 16), image.NewUniform(color.RGBA{29, 83, 47, 255}), image.Point{}, nil, image.Point{}, draw.Src)
	packet := b.Seal(false)
	if packet == nil {
		t.Fatal("fixture capture refused")
	}
	encoded, ok := packet.EncodeGPU()
	if !ok {
		t.Fatal("fixture encoding refused")
	}
	return packet, encoded
}

func TestVellumGPUSceneInputTimingFixtureHeadroom(t *testing.T) {
	_, encoded := inputTimingFixture(t, image.Rect(0, 0, 23, 19))
	for _, input := range [][]byte{encoded.Ops, encoded.Rows, encoded.Refs, encoded.Data} {
		n := len(input)
		if n > 0 && n&(n-1) != 0 {
			return
		}
	}
	t.Fatal("fixture has no input requiring capacity beyond its encoded length")
}

// This must be run only with the existing explicit native GPU admission. A
// validation-error write exercises the real checked API, not a synthetic count.
func TestVellumGPUSceneNativeInputAttemptBytesFailureAndRecovery(t *testing.T) {
	_, dev := nativeDevice(t)
	size := image.Pt(23, 19)
	res := &resources{}
	defer res.release()
	reserve := func(n uint64) error {
		if n > 1<<20 {
			return fmt.Errorf("tiny native fixture budget exceeded")
		}
		return nil
	}
	if err := res.initialize(dev, size, reserve); err != nil {
		t.Fatal(err)
	}
	expected := image.NewRGBA(image.Rectangle{Max: size})
	packet, encoded := inputTimingFixture(t, expected.Rect)
	var scratch sceneplan.EncodingScratch
	encoded, _ = packet.EncodeGPUWithScratch(&scratch)
	inputBytes := uint64(len(encoded.Ops) + len(encoded.Rows) + len(encoded.Refs) + len(encoded.Data) + 16)
	successful := func() {
		t.Helper()
		var ok bool
		encoded, ok = packet.EncodeGPUWithScratch(&scratch)
		if !ok {
			t.Fatal("scratch recovery encoding refused")
		}
		host := &composer.SceneHostTiming{Available: true}
		if err := res.renderWithTiming(encoded, reserve, host); err != nil {
			t.Fatal(err)
		}
		if !host.InputAttempted || host.InputNS < 0 || host.InputWriteAttempts != 5 || host.InputWriteErrors != 0 || host.LogicalInputBytes != inputBytes || host.QueueSubmitAttempts != 1 {
			t.Fatal("actual successful writes differ from encoded byte ledger", host, inputBytes)
		}
	}
	successful()
	// Change borrowed bytes after checked submission returns, before waiting for
	// completion/readback. Queue writes must already have copied their inputs.
	other := sceneplan.New(expected.Rect)
	other.Draw(expected.Rect, image.NewUniform(color.RGBA{211, 7, 13, 255}), image.Point{}, nil, image.Point{}, draw.Src)
	if _, ok := other.Seal(false).EncodeGPUWithScratch(&scratch); !ok {
		t.Fatal("overwrite encoding refused")
	}
	if !packet.Replay(expected) || !bytes.Equal(readTexture(t, dev, res.texture).Pix, expected.Pix) {
		t.Fatal("later scratch overwrite changed submitted pixels")
	}
	var encodedOK bool
	encoded, encodedOK = packet.EncodeGPUWithScratch(&scratch)
	if !encodedOK {
		t.Fatal("original encoding recovery refused")
	}
	headroom := false
	for i, input := range [][]byte{encoded.Ops, encoded.Rows, encoded.Refs, encoded.Data} {
		if res.buffers[i+1].GetSize() > uint64(len(input)) {
			headroom = true
		}
	}
	if !headroom {
		t.Fatal("fixture needs a capacity larger than encoded length to distinguish attempted bytes")
	}
	// Preserve both owned references. Wait for earlier submissions before swapping
	// this test-owned slot; the rejected buffer deliberately lacks CopyDst usage.
	dev.WaitDone()
	original := res.buffers[2]
	refused, err := dev.Device.TryCreateBuffer(&wgpu.BufferDescriptor{Label: "Vellum diagnostic checked-write refusal", Size: original.GetSize(), Usage: wgpu.BufferUsageStorage})
	if err != nil {
		t.Fatal(err)
	}
	res.buffers[2] = refused
	restored := false
	restore := func() {
		if restored {
			return
		}
		res.buffers[2] = original
		refused.Release()
		restored = true
	}
	defer restore()
	host := &composer.SceneHostTiming{Available: true}
	err = res.renderWithTiming(encoded, reserve, host)
	if err == nil {
		t.Fatal("native write unexpectedly accepted storage buffer without CopyDst")
	}
	t.Logf("checked input write refusal: %v", err)
	if refused.GetUsage()&wgpu.BufferUsageCopyDst != 0 {
		t.Fatal("refusal fixture unexpectedly permits CopyDst")
	}
	if loss := dev.LossError(); loss != nil {
		t.Fatal("checked usage refusal contaminated device lifetime", loss)
	}
	partialBytes := uint64(len(encoded.Ops) + len(encoded.Rows))
	if !host.InputAttempted || host.InputNS < 0 || host.InputWriteAttempts != 2 || host.InputWriteErrors != 1 || host.LogicalInputBytes != partialBytes || host.QueueSubmitAttempts != 0 {
		t.Fatal("checked refusal lost attempted bytes, error or early return", host, partialBytes)
	}
	restore()
	successful()
	packet.Replay(expected)
	got := readTexture(t, dev, res.texture)
	if !bytes.Equal(got.Pix, expected.Pix) {
		t.Fatal("restored native input path changed compositor pixels")
	}
}

func TestVellumGPUSceneNativeTileCullingPartialEdgesAndRecovery(t *testing.T) {
	_, dev := nativeDevice(t)
	bounds := image.Rect(0, 0, 35, 33)
	res := &resources{}
	defer res.release()
	reserve := func(n uint64) error {
		if n > 1<<20 {
			return fmt.Errorf("tiny culling budget exceeded")
		}
		return nil
	}
	if err := res.initialize(dev, bounds.Size(), reserve); err != nil {
		t.Fatal(err)
	}
	expected := image.NewRGBA(bounds)
	for pass := 0; pass < 2; pass++ {
		b := sceneplan.New(bounds)
		if pass == 0 {
			b.Draw(bounds, image.NewUniform(color.RGBA{7, 11, 17, 255}), image.Point{}, nil, image.Point{}, draw.Src)
		}
		mask := image.NewAlpha(bounds)
		for i := range mask.Pix {
			mask.Pix[i] = byte(i*7 + 3)
		}
		b.Draw(bounds, image.NewUniform(color.RGBA{3, 5, 7, 31}), image.Point{}, mask, image.Point{}, draw.Over)
		b.Draw(bounds, image.NewUniform(color.NRGBA64{31, 71, 127, 32768}), image.Point{}, nil, image.Point{}, draw.Over)
		b.Draw(image.Rect(16, 16, 35, 33), image.White, image.Point{}, nil, image.Point{}, draw.Over)
		b.BeginSpans(color.RGBA{7, 11, 17, 23}, draw.Over)
		for y := 0; y < 33; y++ {
			b.Span(y, 0, 35, uint32(y*1019))
		}
		b.Draw(image.Rect(0, 0, 16, 16), image.Transparent, image.Point{}, nil, image.Point{}, draw.Src)
		b.Draw(image.Rect(1, 1, 15, 15), image.NewUniform(color.RGBA{7, 11, 17, 255}), image.Point{}, mask, image.Point{}, draw.Over)
		p := b.Seal(false)
		if p == nil {
			t.Fatal("culling capture refused")
		}
		legacy, ok := p.Encode()
		if !ok {
			t.Fatal("legacy encode refused")
		}
		encoded, ok := p.EncodeGPU()
		if !ok || len(encoded.Refs) >= len(legacy.Refs) {
			t.Fatal("no positive native culling coverage", pass)
		}
		host := &composer.SceneHostTiming{Available: true}
		if err := res.renderWithTiming(encoded, reserve, host); err != nil {
			t.Fatal(err)
		}
		if host.InputWriteAttempts != 5 || host.QueueSubmitAttempts != 1 || host.LogicalInputBytes != uint64(len(encoded.Ops)+len(encoded.Rows)+len(encoded.Refs)+len(encoded.Data)+16) {
			t.Fatal("native byte/submit ledger differs", host)
		}
		fresh := image.NewRGBA(bounds)
		if !p.Replay(fresh) || !p.Replay(expected) {
			t.Fatal("replay refused")
		}
		if pass == 1 && (p.Independent() || bytes.Equal(fresh.Pix, expected.Pix)) {
			t.Fatal("partial batch does not require retained target pixels")
		}
		if !bytes.Equal(readTexture(t, dev, res.texture).Pix, expected.Pix) {
			t.Fatal("native culled pixels differ from original replay", pass)
		}
	}
}

func TestVellumSceneCompositionDiagnosticKindsResourcesAndNoMutation(t *testing.T) {
	bounds := image.Rect(0, 0, 32, 32)
	b := sceneplan.New(bounds)
	c := image.NewUniform(color.RGBA{7, 11, 19, 255})
	mask := image.NewAlpha(image.Rect(0, 0, 2, 2))
	copy(mask.Pix, []byte{255, 127, 31, 0})
	b.Draw(bounds, c, image.Point{}, nil, image.Point{}, draw.Src)
	// Equal full clears exercise the encoded operation compaction.
	b.Draw(bounds, c, image.Point{}, nil, image.Point{}, draw.Over)
	b.Draw(image.Rect(1, 1, 3, 3), c, image.Point{}, mask, image.Point{}, draw.Over)
	b.Draw(image.Rect(4, 4, 6, 6), c, image.Point{}, mask, image.Point{}, draw.Over)
	pixels := image.NewRGBA(image.Rect(0, 0, 2, 2))
	copy(pixels.Pix, []byte{3, 5, 7, 255})
	b.Draw(image.Rect(7, 7, 9, 9), pixels, image.Point{}, mask, image.Point{}, draw.Over)
	b.BeginSpans(color.RGBA{13, 17, 23, 255}, draw.Over)
	b.Span(10, 1, 3, 32768)
	b.Span(11, 2, 4, 65535)
	p := b.Seal(false)
	if p == nil {
		t.Fatal("capture refused")
	}
	e, ok := p.EncodeGPU()
	if !ok {
		t.Fatal("encode refused")
	}
	before := [][]byte{bytes.Clone(e.Ops), bytes.Clone(e.Rows), bytes.Clone(e.Refs), bytes.Clone(e.Data)}
	s, err := vellumObserveScene(p, e)
	if err != nil {
		t.Fatal(err)
	}
	if s.PacketOperations != 6 || s.EncodedKinds != [4]int{1, 2, 1, 1} || s.MaskReferences != 3 || s.Resources["mask"] != 1 || s.Resources["pixels"] != 1 || s.Resources["spans"] != 1 || s.DataBytes["mask"] != 4 || s.DataBytes["pixels"] != 16 || s.DataBytes["spans"] != 40 || len(e.Data) != 60 {
		t.Fatalf("unexpected composition: %+v", s)
	}
	if s.TileCount != 4 || s.TileReferences != 8 || s.MaxTileReferences != 5 {
		t.Fatalf("unexpected tiles %+v", s)
	}
	for i, after := range [][]byte{e.Ops, e.Rows, e.Refs, e.Data} {
		if !bytes.Equal(before[i], after) {
			t.Fatal("diagnostic mutated encoding", i)
		}
	}
	// Corrupt copies to verify the observer refuses rather than misreports bytes.
	for _, mutate := range []func(*sceneplan.Encoded){func(x *sceneplan.Encoded) { x.Ops = x.Ops[:len(x.Ops)-1] }, func(x *sceneplan.Encoded) { x.Rows = x.Rows[:len(x.Rows)-1] }, func(x *sceneplan.Encoded) { x.Data = x.Data[:len(x.Data)-1] }, func(x *sceneplan.Encoded) { x.Refs = make([]byte, 0) }} {
		copy := *e
		mutate(&copy)
		if _, err := vellumObserveScene(p, &copy); err == nil {
			t.Fatal("invalid encoding admitted")
		}
	}
}

func TestVellumSceneCompositionDiagnosticPositiveCullingCounter(t *testing.T) {
	bounds := image.Rect(0, 0, 32, 32)
	b := sceneplan.New(bounds)
	b.Draw(bounds, image.Black, image.Point{}, nil, image.Point{}, draw.Src)
	mask := image.NewAlpha(bounds)
	for i := range mask.Pix {
		mask.Pix[i] = 127
	}
	b.Draw(bounds, image.White, image.Point{}, mask, image.Point{}, draw.Over)
	b.Draw(bounds, image.White, image.Point{}, nil, image.Point{}, draw.Over)
	p := b.Seal(false)
	e, ok := p.EncodeGPU()
	if !ok {
		t.Fatal("encode refused")
	}
	s, err := vellumObserveScene(p, e)
	if err != nil || s.UnculledTileReferences != 12 || s.TileReferences != 4 {
		t.Fatal("culling counter differs", s, err)
	}
}
