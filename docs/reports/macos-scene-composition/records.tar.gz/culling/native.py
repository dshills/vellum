"""Five ordinary release pairs plus one separately instrumented culling diagnostic."""
from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,threading
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-ready-native-5482f9b');HEAD='31afa90add2b2d3a68e0dc789ddad0268b792611';STOP=W/'stop-native-comparison'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('tile_culling_grid_runner',T/'scripts/benchmark-grid.py');l=load('tile_culling_live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def prepared():
 leaves={}
 for name in ['upstream','typesetting']:
  root=T/'drivers/cogent/build'/name
  for p in root.rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():leaves[name+'/'+p.relative_to(root).as_posix()]=sha(p)
 return {'files':len(leaves),'sha256':hashlib.sha256(json.dumps(leaves,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
def clean():need(all(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain') for root in [C,T]),'clean source identity')
def prepare():
 need(not STOP.exists() and not (W/'native-plan.json').exists() and not (W/'native-comparison.json').exists(),'fresh plan');clean()
 for name in ['full','vet','native-gpu-v2','test-diagnostic','build','build-diagnostic']:need(json.loads((W/(name+'-command.json')).read_text())['exit_code']==0,'passing '+name)
 old=json.loads((W.parent/'macos-ax-semantic-02f8dbe/binary-receipt.json').read_text());need(all(sha(C/'drivers/cogent'/n)==v for n,v in old['compiled_leaves'].items()),'baseline compiled leaves');need(not git(C,'diff','bd672a6',HEAD,'--','drivers/cogent','go.mod','examples/loadedgrid'),'baseline runtime unchanged')
 binaries={'baseline':{'path':old['path'],'sha256':old['sha256']},'candidate':{'path':str(P/'bin/tile-culling'),'sha256':sha(P/'bin/tile-culling')},'diagnostic':{'path':str(P/'bin/tile-culling-composition'),'sha256':sha(P/'bin/tile-culling-composition')}}
 need(sha(T/'drivers/cogent/build/upstream/paint/renderers/sceneplan/packet.go')==sha(W/'original_packet.go'),'unaltered original encoder')
 pins={str(p):sha(p) for p in [Path(__file__),W/'packet.go',W/'original_packet.go',W/'overlay.json',W/'diagnostic-overlay.json',W/'diagnostic_renderer.go',W/'covered_encoding_test.go',W/'tile_binning_vellum_test.go',W/'native_input_timing_test.go',W/'diagnostic_native_input_timing_test.go',T/'scripts/benchmark-grid.py',Path(l.__file__)]}
 plan={'source_base':HEAD,'prepared':prepared(),'inputs':pins,'binaries':binaries,'pairs':5,'samples':120,'warmup':128,'rows':10000,'variable':False,'gpu_scene':True,'diagnostic':'One separate120sample source-details culling-count run; never ordinary timing acceptance','scope':'Only temporary packet.go production overlay; testfile mappings excluded by normal Go release compilation. No checkout/prepared edits. Baseline reuses verified serializerreleasebinary; runtimebyteidenticalcurrentloadedgrid dependency sources.','bar':{'median_run_p95_reduction_ns':400000,'minimum_improved_pairs':4,'no_correctness_retention_tail_regression':True}}
 need(plan['prepared']=={'files':6260,'sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'},'prepared identity');need(all(sha(x['path'])==x['sha256'] for x in binaries.values()),'binary identity');(W/'native-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Prepared fixed five-pair comparison plan')
def run():
 need(not STOP.exists() and not (W/'native-comparison.json').exists(),'fresh comparison');raw=(W/'native-plan.json').read_bytes();plan=json.loads(raw);digest=hashlib.sha256(raw).hexdigest();review=json.loads((W/'native-admission.json').read_bytes());need(review['execution_ready'] and review['plan_sha256']==digest,'exact reviewed plan')
 def boundary():
  need(not STOP.exists(),'stop requested');clean();need(all(sha(p)==v for p,v in plan['inputs'].items()),'source/overlay pins changed');need(all(sha(v['path'])==v['sha256'] for v in plan['binaries'].values()),'binary changed')
 d={'result':'INCOMPLETE','plan_sha256':digest,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':{'baseline':{'runs':[]},'candidate':{'runs':[]}},'error':None,'native_pointer_tested':False};finished=threading.Event()
 def watch():
  while not finished.wait(.2):
   if STOP.exists():_thread.interrupt_main();return
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('comparison terminated')))
 try:
  boundary();need(prepared()==plan['prepared'],'prepared before');need(all(os.environ.get(k) is None for k in ['GOMAXPROCS','GOMEMLIMIT','GOFLAGS']),'ordinary environment')
  with l.LiveLease():
   d['displays']=b.metadata_command(['system_profiler','SPDisplaysDataType','-json'],15);threading.Thread(target=watch,daemon=True).start();runs={'baseline':[],'candidate':[]}
   for repeat in range(5):
    for label in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
     boundary();directory=W/'native'/f'{repeat+1}-{label}';data,outcome=b.run_case(Path(plan['binaries'][label]['path']),directory,10000,False,120,128,False,180,gpu_scene_rendering=True)
     need(b'"scene.composition.diagnostic"' not in (directory/'native.log').read_bytes(),'diagnostic leaked into ordinary run');runs[label].append(data);stats=b.distribution([x['metrics']['ui_work_ns'] for x in data]);alloc=b.distribution([x['go_process_alloc_bytes'] for x in data]);d['cases'][label]['runs'].append({'directory':str(directory),'exit_code':outcome['exit_code'],'log_sha256':outcome['log_sha256'],'ui_work_ns':stats,'go_process_alloc_bytes':alloc});print(json.dumps({'pair':repeat+1,'build':label,'p95_ms':stats['p95']/1e6,'alloc_p50':alloc['p50']}),flush=True)
    b.compare_geometry(runs['baseline'][-1],runs['candidate'][-1])
   for label in runs:d['cases'][label]['timings_ns']=b.summarize(runs[label]);d['cases'][label]['target_met']=b.warm_target_met({label:d['cases'][label]})
   boundary();directory=W/'diagnostic';data,outcome=b.run_case(Path(plan['binaries']['diagnostic']['path']),directory,10000,False,120,128,False,180,source_details=True,gpu_scene_rendering=True)
   pending=[];ready=False;correlated=[]
   for line in (directory/'native.log').read_bytes().splitlines():
    try:record=json.loads(line)
    except (ValueError,UnicodeDecodeError):continue
    if record.get('event')=='scene.composition.diagnostic':
     need(not record.get('error'),'diagnostic observer refused')
     if ready:pending.append(record)
    elif record.get('event')=='grid.perf.ready':ready=True;pending=[]
    elif record.get('event')=='grid.perf.sample':
     hosts=[x['SceneHost'] for x in record['native_sample']['SourceDetails']['Records'] if x.get('SceneHost',{}).get('CaptureAttempted')];need(len(pending)==len(hosts)==1,'one diagnostic per measured source');p=pending[0];h=hosts[0];need(h['DrawAccepted'] and not h['Fallback'] and not h['Reused'],'positive GPU route');need(p['unculled_gpu_tile_references']>p['tile_references'],'positive actual culling');need(sum(p['buffer_bytes'])+16==h['LogicalInputBytes'] and sum(p['data_bytes'].values())==p['buffer_bytes'][3],'exact diagnostic byte ledger');correlated.append({'index':record['index'],'tag':record['tag'],'generation':record['generation'],'packet':p,'scene_host':h});pending=[]
   need(len(correlated)==120,'all diagnostic samples correlated');(directory/'composition.json').write_text(json.dumps(correlated,indent=2)+'\n');d['diagnostic']={'directory':str(directory),'exit_code':outcome['exit_code'],'samples':len(correlated),'scope':'Separate source-details run, no ordinary timing acceptance','unculled_refs':b.distribution([x['packet']['unculled_gpu_tile_references'] for x in correlated]),'culled_refs':b.distribution([x['packet']['tile_references'] for x in correlated]),'checked_input_bytes':b.distribution([sum(x['packet']['buffer_bytes'])+16 for x in correlated])}
   boundary();d['prepared_after']=prepared();need(d['prepared_after']==plan['prepared'],'prepared after');d['result']='MEASURED'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:finished.set();STOP.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'native-comparison.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'error':d['error'],'diagnostic':d.get('diagnostic')}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:] in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
