// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package sceneplan

import (
	"bytes"
	"encoding/binary"
	"image"
	"image/color"
	"image/draw"
	"math/rand"
	"reflect"
	"testing"
	"unsafe"
)

// Tile-outer scalar execution reads the serialized ABI rather than Packet.ops.
// Arithmetic follows the pinned integer shader; it creates no GPU device.
func replayEncodedGPU(t *testing.T, e *Encoded, dst *image.RGBA) {
	t.Helper()
	word := func(b []byte, i uint32) uint32 { return binary.LittleEndian.Uint32(b[int(i)*4:]) }
	blend := func(dst, src, alpha, coverage uint32, over bool) uint32 {
		if !over {
			return (src * coverage / 16776960) & 255
		}
		a := (65535 - alpha*coverage/65535) * 257
		return ((dst*a + src*coverage) / 16776960) & 255
	}
	for y := 0; y < dst.Rect.Dy(); y++ {
		for x := 0; x < dst.Rect.Dx(); x++ {
			tile := uint32((y/TileSize)*e.Tiles.X + x/TileSize)
			start := word(e.Rows, tile*2)
			count := word(e.Rows, tile*2+1)
			at := dst.PixOffset(x, y)
			for ri := start; ri < start+count; ri++ {
				oi := word(e.Refs, ri) * opWords
				minX, minY := int(word(e.Ops, oi)), int(word(e.Ops, oi+1))
				if x < minX || y < minY || x >= int(word(e.Ops, oi+2)) || y >= int(word(e.Ops, oi+3)) {
					continue
				}
				kind, over := word(e.Ops, oi+8), word(e.Ops, oi+9) == uint32(draw.Over)
				src := [4]uint32{word(e.Ops, oi+4), word(e.Ops, oi+5), word(e.Ops, oi+6), word(e.Ops, oi+7)}
				if kind == Spans {
					row := word(e.Ops, oi+10) + uint32(y-minY)*2
					s0, n := word(e.Data, row), word(e.Data, row+1)
					for si := s0; si < s0+n*3; si += 3 {
						if uint32(x) >= word(e.Data, si) && uint32(x) < word(e.Data, si+1) {
							for ch := 0; ch < 4; ch++ {
								dst.Pix[at+ch] = byte(blend(uint32(dst.Pix[at+ch]), src[ch], src[3], word(e.Data, si+2), over))
							}
						}
					}
					continue
				}
				if kind == Pixels {
					v := word(e.Data, word(e.Ops, oi+10)+uint32(y-minY)*word(e.Ops, oi+11)+uint32(x-minX))
					for ch := 0; ch < 4; ch++ {
						src[ch] = ((v >> uint(ch*8)) & 255) * 257
					}
				}
				mask := word(e.Ops, oi+12)
				if mask != ^uint32(0) {
					byteAt := (uint32(y-minY)+word(e.Ops, oi+15))*word(e.Ops, oi+13) + uint32(x-minX) + word(e.Ops, oi+14)
					a := ((word(e.Data, mask+byteAt/4) >> ((byteAt % 4) * 8)) & 255) * 257
					for ch := 0; ch < 4; ch++ {
						dst.Pix[at+ch] = byte(blend(uint32(dst.Pix[at+ch]), src[ch], src[3], a, over))
					}
				} else {
					for ch := 0; ch < 4; ch++ {
						v := src[ch]
						if over {
							v = (uint32(dst.Pix[at+ch])*(65535-src[3])*257/65535 + src[ch])
						}
						dst.Pix[at+ch] = byte(v >> 8)
					}
				}
			}
		}
	}
}

func TestVellumScenePlanGPUCoveredMixedOracle(t *testing.T) {
	random := rand.New(rand.NewSource(9057))
	for trial := 0; trial < 100; trial++ {
		// The independent expected stream is an existing mixed fixture. Only explicit
		// inserted clears are removable; all other original mask/pixel/span bytes stay.
		want := stagingFixture(129, true)
		expanded := *want
		expanded.ops = nil
		removed := 0
		for _, o := range want.ops {
			if o.kind == Uniform && o.op == draw.Over && o.color[3] == 65535 {
				clear := o
				clear.op = draw.Src
				clear.color = [4]uint32{0, 0, 0, 0}
				expanded.ops = append(expanded.ops, clear)
				removed++
			}
			expanded.ops = append(expanded.ops, o)
		}
		original, ok := expanded.Encode()
		if !ok {
			t.Fatal("original refused")
		}
		before := stagingDigest(&expanded)
		e, ok := expanded.EncodeGPU()
		oracle, _ := want.Encode()
		if !ok || !bytes.Equal(e.Ops, oracle.Ops) || !bytes.Equal(e.Data, oracle.Data) || e.Tiles != oracle.Tiles || removed == 0 {
			t.Fatal("compact ABI differs from independent original stream", trial)
		}
		if len(e.Ops) != len(original.Ops)-removed*opWords*4 {
			t.Fatal("no exact operation reduction")
		}
		seed := image.NewRGBA(want.bounds)
		random.Read(seed.Pix)
		got := image.NewRGBA(seed.Rect)
		copy(got.Pix, seed.Pix)
		if !expanded.Replay(seed) {
			t.Fatal("original replay refused")
		}
		replayEncodedGPU(t, e, got)
		if !bytes.Equal(got.Pix, seed.Pix) {
			t.Fatal("serialized tile execution changed pixels", trial)
		}
		// Freeze the independently pixel-checked result before testing detachment.
		oracle = &Encoded{Ops: bytes.Clone(e.Ops), Rows: bytes.Clone(e.Rows), Refs: bytes.Clone(e.Refs), Data: bytes.Clone(e.Data), Tiles: e.Tiles}
		// A second encoding is detached from both the packet and a previous encoding.
		saved := append([]byte(nil), e.Refs...)
		clear(e.Ops)
		again, _ := expanded.EncodeGPU()
		if !reflect.DeepEqual(again, oracle) || !bytes.Equal(e.Refs, saved) || stagingDigest(&expanded) != before || expanded.Independent() != want.Independent() {
			t.Fatal("encoding mutated packet or held result")
		}
	}
}

func TestVellumScenePlanGPUCoveredBoundaries(t *testing.T) {
	bounds := image.Rect(0, 0, 35, 33)
	for _, tc := range []struct {
		name            string
		rect            image.Rectangle
		alpha           uint16
		op              draw.Op
		mask, interrupt bool
		removed         int
	}{
		{"opaque", image.Rect(1, 2, 20, 19), 65535, draw.Over, false, false, 1},
		{"clipped", image.Rect(-4, -2, 40, 37), 65535, draw.Over, false, false, 1},
		{"full-default", image.Rectangle{}, 65535, draw.Over, false, false, 1},
		{"almost-opaque", bounds, 65534, draw.Over, false, false, 0},
		{"src", bounds, 65535, draw.Src, false, false, 0},
		{"masked", bounds, 65535, draw.Over, true, false, 0},
		{"intervening-span", bounds, 65535, draw.Over, false, true, 0},
	} {
		t.Run(tc.name, func(t *testing.T) {
			b := New(bounds)
			u := image.NewUniform(color.NRGBA64{17, 31, 63, 511})
			b.Draw(tc.rect, u, image.Pt(7, 9), nil, image.Pt(-2, 3), draw.Src)
			if tc.interrupt {
				b.BeginSpans(color.RGBA{1, 3, 5, 7}, draw.Over)
				b.Span(4, 0, 5, 32768)
			}
			var mask image.Image
			if tc.mask {
				m := image.NewAlpha(bounds)
				for i := range m.Pix {
					m.Pix[i] = 255
				}
				mask = m
			}
			b.Draw(tc.rect, image.NewUniform(color.NRGBA64{333, 1777, 6333, tc.alpha}), image.Pt(-7, -9), mask, image.Point{}, tc.op)
			p := b.Seal(true)
			if p == nil {
				t.Fatal("valid fixture refused")
			}
			u.C = color.RGBA{255, 0, 0, 255}
			old, ok := p.Encode()
			if !ok {
				t.Fatal("original encode refused")
			}
			e, ok := p.EncodeGPU()
			if !ok || len(e.Ops) != len(old.Ops)-tc.removed*opWords*4 {
				t.Fatal("wrong compact operation count")
			}
			seed := image.NewRGBA(bounds)
			for i := range seed.Pix {
				seed.Pix[i] = byte(i*71 + 3)
			}
			got := image.NewRGBA(bounds)
			copy(got.Pix, seed.Pix)
			p.Replay(seed)
			replayEncodedGPU(t, e, got)
			if !bytes.Equal(seed.Pix, got.Pix) {
				t.Fatal("boundary serialized pixels changed")
			}
			if tc.removed == 0 && !tc.interrupt && tc.op != draw.Src && !reflect.DeepEqual(e, old) {
				t.Fatal("ineligible pair encoded bytes changed")
			}
		})
	}
	empty := New(bounds).Seal(false)
	a, _ := empty.Encode()
	b, _ := empty.EncodeGPU()
	if !reflect.DeepEqual(a, b) {
		t.Fatal("empty encoding changed")
	}
	var nilPacket *Packet
	if e, ok := nilPacket.EncodeGPU(); e != nil || ok {
		t.Fatal("nil packet admitted")
	}
	// Unequal rectangles and Src/Src/Over chains only drop the final covered Src.
	bld := New(bounds)
	bld.Draw(bounds, image.Black, image.Point{}, nil, image.Point{}, draw.Src)
	bld.Draw(bounds.Inset(1), image.Black, image.Point{}, nil, image.Point{}, draw.Src)
	bld.Draw(bounds.Inset(1), image.White, image.Point{}, nil, image.Point{}, draw.Over)
	p := bld.Seal(false)
	e, _ := p.EncodeGPU()
	if len(e.Ops) != 2*opWords*4 || p.Operations() != 3 || !p.Independent() {
		t.Fatal("chain changed original accounting/reset")
	}
}

func TestVellumScenePlanGPUCoveredOriginalLimits(t *testing.T) {
	bounds := image.Rect(0, 0, 8192, 2048)
	for _, n := range []int{32, 33} {
		b := New(bounds)
		for i := 0; i < n; i++ {
			b.Draw(bounds, image.White, image.Point{}, nil, image.Point{}, draw.Op(1-i%2))
		}
		p := b.Seal(false)
		if p == nil {
			t.Fatal("bounded builder unexpectedly refused")
		}
		_, oldOK := p.Encode()
		e, newOK := p.EncodeGPU()
		if oldOK != newOK || newOK != (n == 32) {
			t.Fatal("original tile-reference admission changed", n)
		}
		if newOK && len(e.Ops) != 16*opWords*4 {
			t.Fatal("exact reference boundary not compacted")
		}
	}
	// A real builder packet fits retained bytes but exceeds encoded bytes because
	// tile references and headers add to a large image+mask. Covered draws cannot
	// rescue this refusal. Mask snapshots are charged by their full validated size.
	bounds = image.Rect(0, 0, 3072, 2048)
	b := New(bounds)
	for i := 0; i < 42; i++ {
		b.Draw(bounds, image.White, image.Point{}, nil, image.Point{}, draw.Op(1-i%2))
	}
	img := image.NewRGBA(bounds)
	mask := image.NewAlpha(image.Rect(0, 0, 2048, 2048))
	b.Draw(image.Rect(0, 0, 1, 1), image.White, image.Point{}, mask, image.Point{}, draw.Over)
	b.Draw(bounds, img, image.Point{}, nil, image.Point{}, draw.Src)
	p := b.Seal(false)
	if p == nil || p.Bytes() > MaxBytes {
		t.Fatal("retained-byte fixture refused")
	}
	if _, ok := p.Encode(); ok {
		t.Fatal("original encoded-byte fixture did not refuse")
	}
	if _, ok := p.EncodeGPU(); ok {
		t.Fatal("covered clear revived encoded-byte refusal")
	}
	for _, count := range []int{MaxOps, MaxOps + 1} {
		b := New(image.Rect(0, 0, 1, 1))
		for i := 0; i < count; i++ {
			b.Draw(b.packet.bounds, image.White, image.Point{}, nil, image.Point{}, draw.Op(1-i%2))
		}
		p := b.Seal(false)
		if count > MaxOps {
			if p != nil {
				t.Fatal("logical op limit revived")
			}
			continue
		}
		e, ok := p.EncodeGPU()
		if !ok || p.Operations() != MaxOps || len(e.Ops) != MaxOps/2*opWords*4 {
			t.Fatal("exact op limit changed")
		}
	}
	b = New(image.Rect(0, 0, 1, 1))
	b.packet.bytes = MaxBytes - int(unsafe.Sizeof(operation{}))
	b.Draw(b.packet.bounds, image.Black, image.Point{}, nil, image.Point{}, draw.Src)
	b.Draw(b.packet.bounds, image.White, image.Point{}, nil, image.Point{}, draw.Over)
	if !b.Failed() || b.Seal(false) != nil {
		t.Fatal("covered clear revived builder byte refusal")
	}
}

// Independent encoded-stream oracle: start from the frozen original encoder,
// scan each existing tile list backwards, and retain its last replacement suffix.
// It does not use Packet operations or production overwrite-fence bookkeeping.
func cullingReferencePrune(e *Encoded, bounds image.Rectangle) *Encoded {
	if e == nil {
		return nil
	}
	out := &Encoded{Ops: e.Ops, Data: e.Data, Tiles: e.Tiles, Rows: make([]byte, len(e.Rows))}
	for y := 0; y < e.Tiles.Y; y++ {
		for x := 0; x < e.Tiles.X; x++ {
			bin := y*e.Tiles.X + x
			at := int(binary.LittleEndian.Uint32(e.Rows[bin*8:]))
			n := int(binary.LittleEndian.Uint32(e.Rows[bin*8+4:]))
			first := 0
			tile := image.Rect(x*TileSize, y*TileSize, min((x+1)*TileSize, bounds.Max.X), min((y+1)*TileSize, bounds.Max.Y))
			for j := n - 1; j >= 0; j-- {
				id := int(binary.LittleEndian.Uint32(e.Refs[(at+j)*4:]))
				o := e.Ops[id*opWords*4:]
				rect := image.Rect(int(binary.LittleEndian.Uint32(o)), int(binary.LittleEndian.Uint32(o[4:])), int(binary.LittleEndian.Uint32(o[8:])), int(binary.LittleEndian.Uint32(o[12:])))
				kind, op, alpha, mask := binary.LittleEndian.Uint32(o[32:]), binary.LittleEndian.Uint32(o[36:]), binary.LittleEndian.Uint32(o[28:]), binary.LittleEndian.Uint32(o[48:])
				if kind == Uniform && mask == ^uint32(0) && (op == uint32(draw.Src) || alpha == 65535) && tile.In(rect) {
					first = j
					break
				}
			}
			binary.LittleEndian.PutUint32(out.Rows[bin*8:], uint32(len(out.Refs)/4))
			binary.LittleEndian.PutUint32(out.Rows[bin*8+4:], uint32(n-first))
			out.Refs = append(out.Refs, e.Refs[(at+first)*4:(at+n)*4]...)
		}
	}
	if len(out.Refs) == 0 {
		out.Refs = make([]byte, 4)
	}
	return out
}

func TestVellumGPUCullingPartialEdgesAndMixedPainterOrder(t *testing.T) {
	bounds := image.Rect(0, 0, 35, 33)
	b := New(bounds)
	b.Draw(bounds, image.Black, image.Point{}, nil, image.Point{}, draw.Src)
	mask := image.NewAlpha(bounds)
	for i := range mask.Pix {
		mask.Pix[i] = byte(i*7 + 3)
	}
	b.Draw(bounds, image.White, image.Point{}, mask, image.Point{}, draw.Over)
	b.Draw(bounds, image.NewUniform(color.NRGBA64{31, 71, 127, 65534}), image.Point{}, nil, image.Point{}, draw.Over)
	// Includes four fully covered tiles, including both partial surface edges.
	b.Draw(image.Rect(16, 16, 35, 33), image.White, image.Point{}, nil, image.Point{}, draw.Over)
	b.BeginSpans(color.RGBA{7, 11, 17, 23}, draw.Over)
	for y := 0; y < 33; y++ {
		b.Span(y, 0, 35, uint32(y*1019))
	}
	// Transparent Src is a replacement; partial opaque and masked fills are not.
	b.Draw(image.Rect(0, 0, 16, 16), image.Transparent, image.Point{}, nil, image.Point{}, draw.Src)
	pixels := image.NewRGBA(image.Rect(0, 0, 32, 32))
	for i := 0; i < len(pixels.Pix); i += 4 {
		copy(pixels.Pix[i:i+4], []byte{7, 11, 17, 31})
	}
	b.Draw(image.Rect(5, 6, 31, 29), pixels, image.Point{}, nil, image.Point{}, draw.Over)
	b.Draw(image.Rect(1, 1, 15, 15), image.White, image.Point{}, nil, image.Point{}, draw.Over)
	p := b.Seal(false)
	if p == nil {
		t.Fatal("mixed fixture refused")
	}
	before := stagingDigest(p)
	original, oldOK := p.originalBinningEncode(true)
	got, ok := p.EncodeGPU()
	if !oldOK || !ok {
		t.Fatal("mixed encoding refused")
	}
	want := cullingReferencePrune(original, bounds)
	if !reflect.DeepEqual(got, want) || len(got.Refs) >= len(original.Refs) {
		t.Fatal("pruned reference suffix differs")
	}
	for trial := 0; trial < 32; trial++ {
		seed := image.NewRGBA(bounds)
		rand.New(rand.NewSource(int64(77 + trial))).Read(seed.Pix)
		actual := image.NewRGBA(bounds)
		copy(actual.Pix, seed.Pix)
		p.Replay(seed)
		replayEncodedGPU(t, got, actual)
		if !bytes.Equal(actual.Pix, seed.Pix) {
			t.Fatal("mixed tile replay differs", trial)
		}
	}
	legacy, ok := p.Encode()
	legacyWant, oldOK := p.originalBinningEncode(false)
	if ok != oldOK || !reflect.DeepEqual(legacy, legacyWant) || before != stagingDigest(p) {
		t.Fatal("legacy bytes or packet changed")
	}
	var scratch EncodingScratch
	held, ok := p.EncodeGPUWithScratch(&scratch)
	if !ok || !reflect.DeepEqual(held, want) {
		t.Fatal("scratch differs")
	}
	saved := bytes.Clone(got.Refs)
	empty := New(bounds).Seal(false)
	empty.EncodeGPUWithScratch(&scratch)
	again, _ := p.EncodeGPUWithScratch(&scratch)
	if !reflect.DeepEqual(again, want) || !bytes.Equal(saved, got.Refs) {
		t.Fatal("scratch recovery or detached refs changed")
	}
}
