from pathlib import Path
import json
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;P=T/'drivers/cogent/build/upstream/paint/renderers/sceneplan'
p=P/'packet.go';s=p.read_text();(W/'original_packet.go').write_text(s)
s=s.replace('''	dataBytes, refs, retainedRefs, retainedOps := 0, 0, 0, 0
''','''	dataBytes, refs, retainedRefs, retainedOps := 0, 0, 0, 0
	// GPU-only per-tile overwrite fences use original operation ordinals+1.
	// Allocate lazily: an initial full clear alone cannot hide an earlier draw.
	// Original operation/reference/byte admission below remains unchanged.
	var lastReset []uint32
''',1)
needle='''		if len(p.ops)*opWords*4+len(counts)*8+refs*4+dataBytes > MaxBytes {
			return nil, false
		}
'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''		if compact && keep && i > 0 && o.kind == Uniform && (o.op == draw.Src || o.color[3] == 65535) {
			// Only complete actual tiles are independent of every earlier draw.
			// The surface's final partial tiles stop at bounds, not TileSize.
			for y := y0; y <= y1; y++ {
				for x := x0; x <= x1; x++ {
					if o.rect.Min.X <= x*TileSize && o.rect.Min.Y <= y*TileSize &&
						o.rect.Max.X >= min((x+1)*TileSize, p.bounds.Max.X) && o.rect.Max.Y >= min((y+1)*TileSize, p.bounds.Max.Y) {
						if lastReset == nil { lastReset = make([]uint32, len(counts)) }
						lastReset[y*tiles.X+x] = uint32(i+1)
					}
				}
			}
		}
''',1)
s=s.replace('''	if retainedRefs > 2*len(counts) {''','''	if lastReset != nil {
		retainedRefs = 0
		for i, o := range p.ops {
			if p.coveredClear(i) { continue }
			for y := o.rect.Min.Y/TileSize; y <= (o.rect.Max.Y-1)/TileSize; y++ {
				for x := o.rect.Min.X/TileSize; x <= (o.rect.Max.X-1)/TileSize; x++ {
					bin := y*tiles.X+x
					if uint32(i+1) >= lastReset[bin] { counts[bin]++; retainedRefs++ }
				}
			}
		}
	} else if retainedRefs > 2*len(counts) {''',1)
needle='''				bin := y*tiles.X + x
				binary.LittleEndian.PutUint32(e.Refs[positions[bin]*4:], encodedIndex)'''
assert s.count(needle)==1
s=s.replace(needle,'''				bin := y*tiles.X + x
				if lastReset != nil && uint32(i+1) < lastReset[bin] { continue }
				binary.LittleEndian.PutUint32(e.Refs[positions[bin]*4:], encodedIndex)''',1)
s=s.replace('''// encoded result owns compact operation IDs and tile references.''','''// encoded result owns compact operation IDs and tile references. Each tile also
// omits references before its last fully covering unmasked Uniform replacement
// (Src or opaque Over), retaining painter order after that replacement.''')
(W/'packet.go').write_text(s)
p=P/'covered_encoding_test.go';s=p.read_text();s=s.replace('''if !ok || !reflect.DeepEqual(e, oracle) || removed == 0''','''if !ok || !bytes.Equal(e.Ops, oracle.Ops) || !bytes.Equal(e.Data, oracle.Data) || e.Tiles != oracle.Tiles || removed == 0''',1)
s=s.replace('''		// A second encoding is detached from both the packet and a previous encoding.''','''		// Freeze the independently pixel-checked result before testing detachment.
		oracle = &Encoded{Ops:bytes.Clone(e.Ops),Rows:bytes.Clone(e.Rows),Refs:bytes.Clone(e.Refs),Data:bytes.Clone(e.Data),Tiles:e.Tiles}
		// A second encoding is detached from both the packet and a previous encoding.''',1)
s=s.replace('''if tc.removed == 0 && !reflect.DeepEqual(e, old)''','''if tc.removed == 0 && !tc.interrupt && tc.op != draw.Src && !reflect.DeepEqual(e, old)''',1)
s+='''
// Independent encoded-stream oracle: start from the frozen original encoder,
// scan each existing tile list backwards, and retain its last replacement suffix.
// It does not use Packet operations or production overwrite-fence bookkeeping.
func cullingReferencePrune(e *Encoded, bounds image.Rectangle) *Encoded {
 if e == nil { return nil }
 out:=&Encoded{Ops:e.Ops,Data:e.Data,Tiles:e.Tiles,Rows:make([]byte,len(e.Rows))}
 for y:=0;y<e.Tiles.Y;y++ { for x:=0;x<e.Tiles.X;x++ {
  bin:=y*e.Tiles.X+x;at:=int(binary.LittleEndian.Uint32(e.Rows[bin*8:]));n:=int(binary.LittleEndian.Uint32(e.Rows[bin*8+4:]));first:=0
  tile:=image.Rect(x*TileSize,y*TileSize,min((x+1)*TileSize,bounds.Max.X),min((y+1)*TileSize,bounds.Max.Y))
  for j:=n-1;j>=0;j-- {
   id:=int(binary.LittleEndian.Uint32(e.Refs[(at+j)*4:]));o:=e.Ops[id*opWords*4:]
   rect:=image.Rect(int(binary.LittleEndian.Uint32(o)),int(binary.LittleEndian.Uint32(o[4:])),int(binary.LittleEndian.Uint32(o[8:])),int(binary.LittleEndian.Uint32(o[12:])))
   kind,op,alpha,mask:=binary.LittleEndian.Uint32(o[32:]),binary.LittleEndian.Uint32(o[36:]),binary.LittleEndian.Uint32(o[28:]),binary.LittleEndian.Uint32(o[48:])
   if kind==Uniform && mask==^uint32(0) && (op==uint32(draw.Src)||alpha==65535) && tile.In(rect) { first=j;break }
  }
  binary.LittleEndian.PutUint32(out.Rows[bin*8:],uint32(len(out.Refs)/4));binary.LittleEndian.PutUint32(out.Rows[bin*8+4:],uint32(n-first))
  out.Refs=append(out.Refs,e.Refs[(at+first)*4:(at+n)*4]...)
 } }
 if len(out.Refs)==0 { out.Refs=make([]byte,4) };return out
}

func TestVellumGPUCullingPartialEdgesAndMixedPainterOrder(t *testing.T) {
 bounds:=image.Rect(0,0,35,33);b:=New(bounds)
 b.Draw(bounds,image.Black,image.Point{},nil,image.Point{},draw.Src)
 mask:=image.NewAlpha(bounds);for i:=range mask.Pix { mask.Pix[i]=byte(i*7+3) }
 b.Draw(bounds,image.White,image.Point{},mask,image.Point{},draw.Over)
 b.Draw(bounds,image.NewUniform(color.NRGBA64{31,71,127,65534}),image.Point{},nil,image.Point{},draw.Over)
 // Includes four fully covered tiles, including both partial surface edges.
 b.Draw(image.Rect(16,16,35,33),image.White,image.Point{},nil,image.Point{},draw.Over)
 b.BeginSpans(color.RGBA{7,11,17,23},draw.Over);for y:=0;y<33;y++ { b.Span(y,0,35,uint32(y*1019)) }
 // Transparent Src is a replacement; partial opaque and masked fills are not.
 b.Draw(image.Rect(0,0,16,16),image.Transparent,image.Point{},nil,image.Point{},draw.Src)
 pixels:=image.NewRGBA(image.Rect(0,0,32,32));for i:=0;i<len(pixels.Pix);i+=4 {copy(pixels.Pix[i:i+4],[]byte{7,11,17,31})}
 b.Draw(image.Rect(5,6,31,29),pixels,image.Point{},nil,image.Point{},draw.Over)
 b.Draw(image.Rect(1,1,15,15),image.White,image.Point{},nil,image.Point{},draw.Over)
 p:=b.Seal(false);if p==nil{t.Fatal("mixed fixture refused")};before:=stagingDigest(p)
 original,oldOK:=p.originalBinningEncode(true);got,ok:=p.EncodeGPU();if !oldOK||!ok{t.Fatal("mixed encoding refused")}
 want:=cullingReferencePrune(original,bounds);if !reflect.DeepEqual(got,want)||len(got.Refs)>=len(original.Refs){t.Fatal("pruned reference suffix differs")}
 for trial:=0;trial<32;trial++ {
  seed:=image.NewRGBA(bounds);rand.New(rand.NewSource(int64(77+trial))).Read(seed.Pix);actual:=image.NewRGBA(bounds);copy(actual.Pix,seed.Pix)
  p.Replay(seed);replayEncodedGPU(t,got,actual);if !bytes.Equal(actual.Pix,seed.Pix){t.Fatal("mixed tile replay differs",trial)}
 }
 legacy,ok:=p.Encode();legacyWant,oldOK:=p.originalBinningEncode(false);if ok!=oldOK||!reflect.DeepEqual(legacy,legacyWant)||before!=stagingDigest(p){t.Fatal("legacy bytes or packet changed")}
 var scratch EncodingScratch;held,ok:=p.EncodeGPUWithScratch(&scratch);if !ok||!reflect.DeepEqual(held,want){t.Fatal("scratch differs")}
 saved:=bytes.Clone(got.Refs);empty:=New(bounds).Seal(false);empty.EncodeGPUWithScratch(&scratch);again,_:=p.EncodeGPUWithScratch(&scratch);if !reflect.DeepEqual(again,want)||!bytes.Equal(saved,got.Refs){t.Fatal("scratch recovery or detached refs changed")}
}
'''
(W/'covered_encoding_test.go').write_text(s)
p=P/'tile_binning_vellum_test.go';s=p.read_text();needle='''			want, accepted := p.originalBinningEncode(compact)
''';assert s.count(needle)==4;s=s.replace(needle,needle+'''			if compact && accepted { want = cullingReferencePrune(want,p.bounds) }
''');(W/'tile_binning_vellum_test.go').write_text(s)
(W/'overlay.json').write_text(json.dumps({'Replace':{str(P/n):str(W/n) for n in ['packet.go','covered_encoding_test.go','tile_binning_vellum_test.go']}},indent=2)+'\n')
