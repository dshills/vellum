from pathlib import Path
import json
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
p=T/'drivers/cogent/build/upstream/paint/renderers/gpuscene/renderer.go';s=p.read_text().replace('import (','import (\n "encoding/binary"\n "encoding/json"\n "os"\n "sort"',1)
needle='''		if !ok {
			return r.fallback(dw, commands, dp, op, measured, fmt.Errorf("gpuscene: encoded paint exceeds limits"))
		}
'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''		if host != nil {
			observation, err := vellumObserveScene(packet, encoded)
			observation.CommandTypes = map[string]int{}
			for _, command := range commands { observation.CommandTypes[fmt.Sprintf("%T", command)]++ }
			if err != nil { observation.Error = err.Error() }
			if err := json.NewEncoder(os.Stdout).Encode(observation); err != nil { fmt.Fprintln(os.Stderr, "scene diagnostic output:", err) }
		}
''')
s+='''
// Temporary diagnostic-only overlay. No accepted packet/encoding is modified.
// Resource identity here is a data-section offset within this packet, not a
// persistent content identity or an estimate of native/GPU resident memory.
type vellumSceneObservation struct {
 Event string `json:"event"`
 Error string `json:"error,omitempty"`
 PacketOperations int `json:"packet_operations"`
 Bounds [4]int `json:"bounds"`
 EncodedKinds [4]int `json:"encoded_kinds"`
 CommandTypes map[string]int `json:"command_types"`
 BufferBytes [4]int `json:"buffer_bytes"`
 TileCount int `json:"tile_count"`
 TileReferences int `json:"tile_references"`
 MaxTileReferences int `json:"max_tile_references"`
 MaskReferences int `json:"mask_references"`
 Resources map[string]int `json:"resources"`
 DataBytes map[string]int `json:"data_bytes"`
}
func vellumObserveScene(p *sceneplan.Packet, e *sceneplan.Encoded) (s vellumSceneObservation, err error) {
 s.Event = "scene.composition.diagnostic"
 s.Resources, s.DataBytes = map[string]int{}, map[string]int{}
 if p == nil || e == nil { return s, fmt.Errorf("missing packet/encoding") }
 s.PacketOperations = p.Operations()
 r := p.Bounds(); s.Bounds = [4]int{r.Min.X,r.Min.Y,r.Dx(),r.Dy()}
 s.BufferBytes = [4]int{len(e.Ops),len(e.Rows),len(e.Refs),len(e.Data)}
 if (len(e.Ops)%64 != 0 && len(e.Ops)!=4) || len(e.Rows)%8!=0 || len(e.Refs)%4!=0 || len(e.Data)%4!=0 { return s, fmt.Errorf("encoding alignment") }
 starts := map[int]string{}
 add := func(word uint32, kind string) error {
  at := uint64(word)*4
  if at >= uint64(len(e.Data)) { return fmt.Errorf("resource offset") }
  if prior, ok := starts[int(at)]; ok && prior != kind { return fmt.Errorf("resource kind collision") }
  starts[int(at)] = kind; return nil
 }
 for i:=0; i+64<=len(e.Ops); i+=64 {
  o:=e.Ops[i:i+64];kind:=binary.LittleEndian.Uint32(o[32:36])
  if kind>sceneplan.Spans { return s, fmt.Errorf("unknown operation kind") };s.EncodedKinds[kind]++
  if mask:=binary.LittleEndian.Uint32(o[48:52]);mask!=^uint32(0) {
   s.MaskReferences++;if err:=add(mask,"mask");err!=nil{return s,err}
  }
  switch kind {
  case sceneplan.Pixels: if err:=add(binary.LittleEndian.Uint32(o[40:44]),"pixels");err!=nil{return s,err}
  case sceneplan.Spans: if err:=add(binary.LittleEndian.Uint32(o[40:44]),"spans");err!=nil{return s,err}
  }
 }
 s.TileCount = len(e.Rows)/8
 if s.TileCount!=e.Tiles.X*e.Tiles.Y { return s,fmt.Errorf("tile dimensions") }
 next:=uint64(0)
 for i:=0;i<len(e.Rows);i+=8 {
  offset,count:=binary.LittleEndian.Uint32(e.Rows[i:i+4]),binary.LittleEndian.Uint32(e.Rows[i+4:i+8])
  if uint64(offset)!=next{return s,fmt.Errorf("noncontiguous tile references")}
  next+=uint64(count);s.MaxTileReferences=max(s.MaxTileReferences,int(count))
 }
 if next>uint64(sceneplan.MaxTileReferences) || int(next)*4!=len(e.Refs) && !(next==0 && len(e.Refs)==4) { return s,fmt.Errorf("reference byte total") }
 s.TileReferences=int(next)
 for i:=0;i<s.TileReferences;i++ { if int(binary.LittleEndian.Uint32(e.Refs[i*4:i*4+4]))>=len(e.Ops)/64{return s,fmt.Errorf("reference operation index")} }
 positions:=make([]int,0,len(starts));for at:=range starts { positions=append(positions,at) };sort.Ints(positions)
 if len(positions)==0 {
  if len(e.Data)!=4{return s,fmt.Errorf("unexpected unowned data")};s.DataBytes["padding"]=4
 } else {
  if positions[0]!=0{return s,fmt.Errorf("resource prefix gap")}
  for i,at:=range positions { end:=len(e.Data);if i+1<len(positions){end=positions[i+1]};s.Resources[starts[at]]++;s.DataBytes[starts[at]]+=end-at }
 }
 return s,nil
}
'''
(W/'renderer.go').write_text(s)
p=T/'drivers/cogent/build/upstream/paint/renderers/gpuscene/native_input_timing_test.go';test=p.read_text();test+='''
func TestVellumSceneCompositionDiagnosticKindsResourcesAndNoMutation(t *testing.T) {
 bounds:=image.Rect(0,0,32,32);b:=sceneplan.New(bounds)
 c:=image.NewUniform(color.RGBA{7,11,19,255});mask:=image.NewAlpha(image.Rect(0,0,2,2));copy(mask.Pix,[]byte{255,127,31,0})
 b.Draw(bounds,c,image.Point{},nil,image.Point{},draw.Src)
 // Equal full clears exercise the encoded operation compaction.
 b.Draw(bounds,c,image.Point{},nil,image.Point{},draw.Over)
 b.Draw(image.Rect(1,1,3,3),c,image.Point{},mask,image.Point{},draw.Over)
 b.Draw(image.Rect(4,4,6,6),c,image.Point{},mask,image.Point{},draw.Over)
 pixels:=image.NewRGBA(image.Rect(0,0,2,2));copy(pixels.Pix,[]byte{3,5,7,255})
 b.Draw(image.Rect(7,7,9,9),pixels,image.Point{},mask,image.Point{},draw.Over)
 b.BeginSpans(color.RGBA{13,17,23,255},draw.Over);b.Span(10,1,3,32768);b.Span(11,2,4,65535)
 p:=b.Seal(false);if p==nil {t.Fatal("capture refused")};e,ok:=p.EncodeGPU();if !ok{t.Fatal("encode refused")}
 before:=[][]byte{bytes.Clone(e.Ops),bytes.Clone(e.Rows),bytes.Clone(e.Refs),bytes.Clone(e.Data)}
 s,err:=vellumObserveScene(p,e);if err!=nil{t.Fatal(err)}
 if s.PacketOperations!=6 || s.EncodedKinds!=[4]int{1,2,1,1} || s.MaskReferences!=3 || s.Resources["mask"]!=1 || s.Resources["pixels"]!=1 || s.Resources["spans"]!=1 || s.DataBytes["mask"]!=4 || s.DataBytes["pixels"]!=16 || s.DataBytes["spans"]!=40 || len(e.Data)!=60 {t.Fatalf("unexpected composition: %+v",s)}
 if s.TileCount!=4 || s.TileReferences!=8 || s.MaxTileReferences!=5 {t.Fatalf("unexpected tiles %+v",s)}
 for i,after:=range [][]byte{e.Ops,e.Rows,e.Refs,e.Data} {if !bytes.Equal(before[i],after){t.Fatal("diagnostic mutated encoding",i)}}
 // Corrupt copies to verify the observer refuses rather than misreports bytes.
 for _,mutate:=range []func(*sceneplan.Encoded){func(x *sceneplan.Encoded){x.Ops=x.Ops[:len(x.Ops)-1]},func(x *sceneplan.Encoded){x.Rows=x.Rows[:len(x.Rows)-1]},func(x *sceneplan.Encoded){x.Data=x.Data[:len(x.Data)-1]},func(x *sceneplan.Encoded){x.Refs=make([]byte,0)}} {
  copy:=*e;mutate(&copy);if _,err:=vellumObserveScene(p,&copy);err==nil{t.Fatal("invalid encoding admitted")}
 }
}
'''
(W/'native_input_timing_test.go').write_text(test)
(W/'overlay.json').write_text(json.dumps({'Replace':{str(T/'drivers/cogent/build/upstream/paint/renderers/gpuscene/renderer.go'):str(W/'renderer.go'),str(p):str(W/'native_input_timing_test.go')}},indent=2)+'\n')
