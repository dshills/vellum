"""Actual encoded route composition, diagnostic overlay only; never timing acceptance."""
from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,threading
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');W=Path(__file__).resolve().parent;STOP=W/'stop-native';HEAD='31afa90add2b2d3a68e0dc789ddad0268b792611';B=Path('/private/tmp/vellum-ready-native-5482f9b/bin/scene-composition')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('composition_grid_runner',T/'scripts/benchmark-grid.py');l=load('composition_live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def prepared():
 leaves={}
 for module in ['upstream','typesetting']:
  root=T/'drivers/cogent/build'/module
  for p in root.rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():leaves[module+'/'+p.relative_to(root).as_posix()]=sha(p)
 return {'files':len(leaves),'sha256':hashlib.sha256(json.dumps(leaves,sort_keys=True,separators=(',',':')).encode()).hexdigest()}

def prepare():
 need(not (W/'native-plan.json').exists() and not STOP.exists(),'fresh plan')
 pins={str(p):sha(p) for p in [B,W/'overlay.json',W/'renderer.go',W/'native_input_timing_test.go',Path(__file__),T/'scripts/benchmark-grid.py',Path(l.__file__)]}
 base={str(root):{'commit':git(root,'rev-parse','HEAD').decode().strip(),'status':git(root,'status','--porcelain').decode()} for root in [C,T]};need(all(x=={'commit':HEAD,'status':''} for x in base.values()),'clean source')
 receipt={'source':base,'prepared':prepared(),'inputs':pins,'binary':{'path':str(B),'bytes':B.stat().st_size,'sha256':sha(B)},'scope':'Four serial source-details-only native table cases; temporary overlay emits encoded operation/resource counts, not latency acceptance. No framework/prepared source edits, no pointer/settings input.','cases':[{'rows':n,'variable':v} for v in [False,True] for n in [10000,1000000]],'samples':120,'warmup':128}
 need(receipt['prepared']=={'files':6260,'sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'},'prepared identity');(W/'native-plan.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Prepared source-bound composition diagnostic plan')

def run():
 need(not STOP.exists() and not (W/'result.json').exists(),'fresh diagnostic')
 data=(W/'native-plan.json').read_bytes();plan=json.loads(data);digest=hashlib.sha256(data).hexdigest();review=json.loads((W/'native-admission.json').read_bytes());need(review['execution_ready'] and review['plan_sha256']==digest,'reviewed exact plan')
 def boundary():
  need(not STOP.exists(),'stop requested');need(all(sha(p)==v for p,v in plan['inputs'].items()),'pins changed');need(all(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain') for root in [C,T]),'source changed')
 d={'result':'INCOMPLETE','plan_sha256':digest,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'error':None,'timing_acceptance':False};finished=threading.Event()
 def watch():
  while not finished.wait(.2):
   if STOP.exists():_thread.interrupt_main();return
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('diagnostic terminated')))
 try:
  boundary();need(prepared()==plan['prepared'],'prepared before')
  with l.LiveLease():
   d['displays']=b.metadata_command(['system_profiler','SPDisplaysDataType','-json'],15);threading.Thread(target=watch,daemon=True).start()
   for case in plan['cases']:
    boundary();name=('variable' if case['variable'] else 'fixed')+'-'+str(case['rows']);directory=W/'native'/name
    samples,outcome=b.run_case(B,directory,case['rows'],case['variable'],120,128,False,180,source_details=True,gpu_scene_rendering=True)
    observations=[];correlated=[];pending=[];ready=False
    for line in (directory/'native.log').read_bytes().splitlines():
     try:record=json.loads(line)
     except (ValueError,UnicodeDecodeError):continue
     if record.get('event')=='scene.composition.diagnostic':
      need(not record.get('error'),'decoder refusal');observations.append(record)
      if ready:pending.append(record)
     elif record.get('event')=='grid.perf.ready':ready=True;pending=[]
     elif record.get('event')=='grid.perf.sample':
      captures=[x['SceneHost'] for x in record['native_sample']['SourceDetails']['Records'] if x.get('SceneHost',{}).get('CaptureAttempted')]
      need(len(pending)==len(captures)==1,'one observed packet per completed measured source')
      observation=pending[0];host=captures[0];need(host['DrawAccepted'] and not host['Fallback'] and not host['Reused'],'accepted GPU route')
      need(sum(observation['buffer_bytes'])+16==host['LogicalInputBytes'],'exact checked input byte total');need(sum(observation['data_bytes'].values())==observation['buffer_bytes'][3],'resource byte partition')
      correlated.append({'index':record['index'],'tag':record['tag'],'generation':record['generation'],'frame':record['frame'],'geometry':record['geometry'],'packet':observation,'scene_host':host});pending=[]
    need(len(correlated)==120,'all measured samples correlated')
    (directory/'composition.json').write_text(json.dumps(correlated,indent=2)+'\n');d['runs'].append({'name':name,**case,'directory':str(directory),'exit_code':outcome['exit_code'],'log_sha256':outcome['log_sha256'],'all_packet_observations':len(observations),'correlated_samples':len(correlated),'input_bytes':b.distribution([sum(x['packet']['buffer_bytes'])+16 for x in correlated]),'encoded_kinds':{str(k):b.distribution([x['packet']['encoded_kinds'][k] for x in correlated]) for k in range(4)}})
    print(json.dumps(d['runs'][-1]),flush=True)
   boundary();d['prepared_after']=prepared();need(d['prepared_after']==plan['prepared'],'prepared after');d['result']='MEASURED_COMPOSITION_ONLY'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED_DIAGNOSTIC',error={'type':type(e).__name__,'message':str(e)})
 finally:finished.set();STOP.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'error':d['error']}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:] in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
