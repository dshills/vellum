from pathlib import Path
import sys,json,time,os
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
base=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go'];mod=['-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly','-overlay='+str(W/'overlay.json')];mode=sys.argv[1];args={
 'test':base+['test',*mod,'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','-run=TestVellumSceneCompositionDiagnostic|TestVellumGPUSceneInputTimingFixtureHeadroom','-count=1','-v','-timeout=2m'],
 'vet':base+['vet',*mod,'-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene'],
 'build':base+['build',*mod,'-trimpath','-buildvcs=false','-o','/private/tmp/vellum-ready-native-5482f9b/bin/scene-composition','.']
}[mode];env=dict(os.environ,GOMAXPROCS='2',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOPROXY='off');env.pop('GOFLAGS',None);start=time.monotonic()
with (W/(mode+'.stdout')).open('xb')as out,(W/(mode+'.stderr')).open('xb')as err:r=run_child(args,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=300,log_limit_bytes=2<<20)
d={'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start};(W/(mode+'-command.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
