"""Root-bound stage0105 source identity only; no plan/build/admission creation."""
from pathlib import Path
import hashlib,json

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
def read_bound(value):
 need(type(value)is dict and set(value)=={'path','sha256'},'explicit bound source record')
 path=Path(value['path']);digest=value['sha256']
 need(path.is_absolute()and all(not p.is_symlink()for p in[path,*path.parents])and path.is_file(),'absolute regular source evidence')
 need(path.stat().st_size<=16<<20,'bounded source evidence')
 need(type(digest)is str and len(digest)==64 and set(digest)<=set('0123456789abcdef')and sha(path)==digest,'actual source evidence hash')
 return path,json.loads(path.read_bytes())
def load_final_source(scope):
 contract=scope/'final-source.json'
 need(contract.is_file()and not contract.is_symlink()and contract.stat().st_size<=65536,'root final source contract required')
 supplied=json.loads(contract.read_bytes())
 need(type(supplied)is dict and set(supplied)=={'schema','stage','commit_receipt','accepted_stage0105_proposal'}and type(supplied['schema'])is int and supplied['schema']==1 and supplied['stage']=='0105','explicit stage0105 final source contract')
 receipt,commit=read_bound(supplied['commit_receipt']);proposal,accepted=read_bound(supplied['accepted_stage0105_proposal'])
 head=commit.get('head');source=commit.get('source_files');prepared=commit.get('prepared_files')
 need(type(head)is str and len(head)==40 and set(head)<=set('0123456789abcdef'),'actual full final commit')
 need(commit.get('canonical_clean')is True and commit.get('candidate_clean')is True,'root actual clean commit receipt')
 need(type(source)is dict and 0<len(source)<20000 and type(prepared)is dict and len(prepared)==6328,'actual complete tracked/prepared maps')
 need(sum(n.startswith('upstream/')for n in prepared)==6029 and sum(n.startswith('typesetting/')for n in prepared)==299,'stage0105 Core6029 plus typesetting299')
 need(accepted.get('stage')=='0105'and type(accepted.get('public_selected_files'))is dict and accepted['public_selected_files']and type(accepted.get('core_selected_files'))is dict and len(accepted['core_selected_files'])==4,'accepted stage0105 four changed Core files and reviewed public bytes')
 need(all(source.get(n)==h for n,h in accepted['public_selected_files'].items()),'final reviewed public/API/example/docs bytes differ')
 need(all(prepared.get('upstream/'+n)==h for n,h in accepted['core_selected_files'].items()),'final four stage0105 prepared outputs differ')
 vectors=[]
 for name,count,expected in [('candidate-vector.json',6029,{n[len('upstream/'):]:h for n,h in prepared.items()if n.startswith('upstream/')}),('candidate-prepared-vector.json',6328,prepared)]:
  path=proposal.parent/name;need(str(path)in accepted.get('inputs',{}),'accepted complete stage0105 vector input')
  path,actual=read_bound({'path':str(path),'sha256':accepted['inputs'][str(path)]})
  need(type(actual)is dict and len(actual)==count and actual==expected,'complete accepted stage0105 prepared vector differs');vectors.append(path)
 return commit,{str(p):sha(p)for p in[contract,Path(__file__).resolve(),receipt,proposal,*vectors]}
