from pathlib import Path
import importlib.util,json,hashlib,sys
sys.dont_write_bytecode=True
X=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts');W=X/'macos-sdk-display105';W.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('existing_sdk_package_guard',X/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
fs=importlib.util.spec_from_file_location('display105_final_source',W/'final_source.py');f=importlib.util.module_from_spec(fs);fs.loader.exec_module(f);r,final_pins=f.load_final_source(W);h.HEAD=r['head'];h.W=W;h.P=Path('/private/tmp/vellum-display105-sdk-'+h.HEAD[:7]);h.PROV=X/'macos-source-gpu-sdk-a274e8a/gpu-provenance.json'
def current_source(root):
 h.need(h.git(root,'rev-parse','HEAD').decode().strip()==h.HEAD and not h.git(root,'status','--porcelain'),'current clean Core105 source')
 names=h.git(root,'ls-files','-z').decode().split('\0')[:-1];source={n:h.sha(root/n)for n in names}
 prepared={m+'/'+p.relative_to(root/'drivers/cogent/build'/m).as_posix():h.sha(p)for m in['upstream','typesetting']for p in(root/'drivers/cogent/build'/m).rglob('*')if p.is_file()}
 h.need(source==r['source_files']and prepared==r['prepared_files'],'complete root-verified Core105 source and prepared vectors')
 return {'head':h.HEAD,'tracked':source,'prepared':prepared}
h.source=current_source
if sys.argv[1:]==['prepare']:
 h.prepare();p=json.loads((W/'plan.json').read_bytes());p['pins'][str(Path(__file__))]=h.sha(Path(__file__));p['pins'][str(W/'retain.py')]=h.sha(W/'retain.py');p['pins'][str(W/'verify-association.py')]=h.sha(W/'verify-association.py');p['pins'].update(final_pins);p['scope']='Headless private SDK package and unchanged full relocation checker on actual final stage0105 source with four reviewed Core changes and unchanged owned source-built GPU. No native execution, public distribution, signing or notarization. Native timing preflight and final app checks follow separately.'
 (W/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print('final current SDK plan',h.sha(W/'plan.json'))
elif sys.argv[1:]==['run']:h.run()
else:raise ValueError('prepare/run')
