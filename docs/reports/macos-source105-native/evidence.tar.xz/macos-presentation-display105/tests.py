"""Controller regression controls. All records/hosts are synthetic; no native launch."""
from pathlib import Path
import copy, datetime, importlib.util, json, os, re, tempfile, unittest
from types import SimpleNamespace
from unittest.mock import patch
s=importlib.util.spec_from_file_location('native_preflight_controller',Path(__file__).with_name('controller.py'));c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
# Synthetic test identity only, never a final-source/build/native admission.
c.HEAD='a'*40

def receipt():
    return dict(created=True,exit_code=0,error=None,observation_errors=[],logs_complete=True,pins_stable=True,stop_at_exit=False,owned=dict(terminal=True,group_absent=True,errors=[]))

def journal(case,binary='a'*64):
    config=c.expected_config(case);w=config['Warmup'];n=config['Samples'];tree=case['kind']=='tree'
    tags=list(range(1,w+n+3))if tree else list(range((1<<32)+1,(1<<32)+w+1))+list(range(1,n+1))
    frames=[];inputs=[];samples=[]
    for i,tag in enumerate(tags):
        at=10+i*.016
        frame={k:0 for k in ['QueuedNS','InputNS','OwnerNS','ReconcileNS','LayoutPaintNS','GatherNS','RasterUploadNS','EncodeSubmitNS','AcquireNS','PresentCallNS','TotalUIWorkNS']}
        frame.update(Tag=tag,Window='perf',Generation=i+1,Completed=True,Failure='');frames.append(frame)
        inputs.append(dict(Scope=1,Tag=tag,Received=at))
        samples.append(dict(Sequence=i+1,Scope=1,Tag=tag,Generation=i+1,Composition=i+1,Armed=True,DrawableID=0,Acquired=at+.001,Presented=at+.005,State='presented'))
    native=dict(Scopes=[dict(ID=1,Window='perf',Closed=False)],Inputs=inputs,Samples=samples,Pending=0,Skipped=0,Unavailable=0,Invalid=0,Retired=0,Overflow=False,Failed=False,Failure='')
    point=dict(Frames=dict(Samples=frames,Dropped=0,Pending=0,Failure=''),Presentation=native)
    after=copy.deepcopy(point);after['Presentation']['Scopes'][0]['Closed']=True
    return dict(Schema='vellum-presentation-capture-v1',Result='CAPTURED_DIAGNOSTIC',Window='perf',RunError='',BinarySHA256=binary,Config=config,Build={'go_version':'go1.25.6','GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'1'},ContinuousWork=False,WorkerRetired=True,RuntimeReturned=True,AcquisitionCutoff=len(samples),ReceiptCutoff=len(inputs),BeforeClose=point,AfterClose=after,CutoffMethod='acquisition-sequence prefix at completed CPU cohort')

class FakeHost:
    def __init__(self,failure=None):self.failure=failure;self.calls=[];self.finished=False;self.geometry_calls=0
    def check(self):
        if self.failure=='boundary':raise ValueError('source drift')
    def finish(self):
        self.finished=True
        if self.failure=='final-boundary':raise ValueError('source drift at cleanup')
    def geometry(self):
        self.geometry_calls+=1
        return {'files':1 if self.failure=='geometry'and self.geometry_calls%2==0 else 0}
    def probes(self,out):
        if self.failure=='probe':raise ValueError('display probe unavailable')
        return {'synthetic':True}
    def native(self,case,path,out):
        self.calls.append(case['id']);out.mkdir();(out/'stderr').write_bytes(b'')
        path.write_text(json.dumps(journal(case)))
        r=receipt()
        if self.failure=='native':r['exit_code']=1
        if self.failure=='stderr':(out/'stderr').write_bytes(b'unknown native diagnostic')
        return r
    def validate(self,case,path):
        if self.failure=='validation':raise ValueError('missing native callback')
        return {'synthetic_only':True,'cadence_threshold_met':False,'release_qualified':False}

class ControllerTests(unittest.TestCase):
    def test_previous_campaign_stays_sealed_and_hash_bound(self):
        pins=c.previous_evidence()
        self.assertEqual(pins,c.read(c.P/'comparison-baseline.json')['inputs'])
        self.assertIn(str(c.PREVIOUS/'stop-live'),pins)
        real_sha=c.sha
        with patch.object(c,'sha',lambda path:'0'*64 if Path(path)==c.PREVIOUS/'result.json'else real_sha(path)):
            with self.assertRaisesRegex(ValueError,'comparison evidence changed'):c.previous_evidence()
    def test_previous_population_or_status_cannot_be_relabeled(self):
        real_read=c.read;prior=real_read(c.PREVIOUS/'result.json')
        for kind in ['release-promoted','missing-completed','missing-attempt','extra-attempt','third-promoted','latency-promoted']:
            changed=copy.deepcopy(prior)
            if kind=='release-promoted':changed['release_qualified']=True
            elif kind=='missing-completed':changed['completed'].pop()
            elif kind=='missing-attempt':changed['cases'].pop('paced-grid-gpu')
            elif kind=='extra-attempt':changed['cases']['paced-tree-cpu']={}
            elif kind=='third-promoted':changed['cases']['paced-grid-gpu']['result']='PASS_SCOPED_NATIVE_FEEDBACK'
            else:changed['cases']['serial-grid-cpu']['validation']['measured_input_latency_ms']['p95']=0
            with self.subTest(kind=kind),patch.object(c,'read',lambda path:changed if Path(path)==c.PREVIOUS/'result.json'else real_read(path)):
                with self.assertRaises(ValueError):c.previous_evidence()
        path=c.PREVIOUS/'native-result-review.json';changed=copy.deepcopy(real_read(path));changed['full_M3_qualified']=True
        with patch.object(c,'read',lambda p:changed if Path(p)==path else real_read(p)):
            with self.assertRaisesRegex(ValueError,'failed scope audit'):c.previous_evidence()
    def test_previous_history_rejects_missing_raw_retirement_and_sparse_campaign(self):
        real_read=c.read;path=c.PREVIOUS/'paced-grid-gpu/native-command.json'
        changed=copy.deepcopy(real_read(path));changed['owned']['group_absent']=False
        with patch.object(c,'read',lambda p:changed if Path(p)==path else real_read(p)):
            with self.assertRaisesRegex(ValueError,'receipt|retirement'):c.previous_evidence()
        actual_is_file=Path.is_file;missing=c.PREVIOUS/'paced-grid-gpu/native/stderr'
        with patch.object(Path,'is_file',lambda p:False if p==missing else actual_is_file(p)):
            with self.assertRaisesRegex(ValueError,'raw files missing'):c.previous_evidence()
        actual_exists=Path.exists;fourth=c.PREVIOUS/'paced-tree-cpu'
        with patch.object(Path,'exists',lambda p:True if p==fourth else actual_exists(p)):
            with self.assertRaisesRegex(ValueError,'fourth historical case'):c.previous_evidence()
    def test_fixed_cases_and_exact_flags(self):
        self.assertEqual([v['samples']for v in c.CASES],[120,120,600,600])
        self.assertEqual([v['kind']for v in c.CASES],['grid','tree','grid','tree'])
        for case in c.CASES:
            args=c.arguments(case,'/binary',Path('/journal'))
            self.assertEqual(args.count('-perf'),1)
            self.assertEqual('-perf-60hz'in args,case['paced'])
            self.assertEqual('-gpu-scene'in args,case['gpu']and case['kind']=='grid')
            self.assertEqual('-perf-gpu-scene'in args,case['gpu']and case['kind']=='tree')
            actual=(c.T/'examples'/('loaded'+case['kind'])/'main.go').read_text()
            declared=set(re.findall(r'flag\.(?:Bool|Int|String|Duration)\("([^"\n]+)"',actual))
            self.assertTrue({arg[1:].split('=',1)[0]for arg in args[1:]}<=declared,'argument absent from actual consumer CLI')
            self.assertEqual(args.count('-experimental-display-backpressure=1s'),1);self.assertEqual(c.expected_config(case)['DisplayBackpressureNS'],1_000_000_000)
            self.assertIn('-perf-warmup=128',args);self.assertIn('-perf-presentation=/journal',args)
            self.assertIn('-'+('rows'if case['kind']=='grid'else'nodes')+'=10000',args)
    def test_only_complete_owned_receipts_pass(self):
        self.assertTrue(c.passed(receipt()))
        for field,value in [('created',False),('exit_code',1),('error',{}),('observation_errors',[{}]),('logs_complete',False),('pins_stable',False),('stop_at_exit',True)]:
            r=receipt();r[field]=value;self.assertFalse(c.passed(r),field)
        for field,value in [('terminal',False),('group_absent',False),('errors',[{}])]:
            r=receipt();r['owned'][field]=value;self.assertFalse(c.passed(r),field)
    def test_four_serial_cases_and_no_release_claim(self):
        with tempfile.TemporaryDirectory()as temp:
            host=FakeHost();r=c.execute_cases({'cases':c.CASES},host,Path(temp))
            self.assertEqual(r['result'],'PASS_SCOPED_NATIVE_FEEDBACK_PREFLIGHT');self.assertEqual(r['completed'],[v['id']for v in c.CASES]);self.assertTrue(host.finished);self.assertFalse(r['release_qualified'])
            self.assertTrue((Path(temp)/'stop-live').exists())
            for case in c.CASES:self.assertTrue((Path(temp)/case['id']/'sealed').exists())
            # No existing campaign output can be silently replaced.
            with self.assertRaises(FileExistsError):c.write(Path(temp)/'result.json',{})
    def test_each_failure_stops_and_seals_without_later_launch(self):
        for failure in ['boundary','probe','native','stderr','validation','geometry','final-boundary']:
            with self.subTest(failure=failure),tempfile.TemporaryDirectory()as temp:
                root=Path(temp);host=FakeHost(failure);r=c.execute_cases({'cases':c.CASES},host,root)
                self.assertEqual(r['result'],'FAILED_OR_CANCELED');self.assertTrue(host.finished);self.assertTrue((root/'stop-live').exists());self.assertFalse(r['release_qualified'])
                if failure=='final-boundary':self.assertEqual(len(host.calls),4)
                else:self.assertLessEqual(len(host.calls),1);self.assertFalse((root/c.CASES[1]['id']).exists())
                if host.calls:
                    case=root/c.CASES[0]['id'];d=json.loads((case/'result.json').read_text())
                    self.assertTrue((case/'sealed').exists());self.assertEqual(d['retained_journal']['sha256'],c.sha(case/'presentation.json'))
    def test_strict_validator_accepts_both_complete_serial_workloads(self):
        with tempfile.TemporaryDirectory()as temp:
            path=Path(temp)/'capture.json'
            for case in c.CASES[:2]:
                path.write_text(json.dumps(journal(case)));r=c.validate_capture(path,case,'a'*64)
                self.assertEqual(r['result'],'VALID_SERIAL_NATIVE_FEEDBACK_JOURNAL');self.assertEqual(r['measured_input_latency_ms']['count'],120);self.assertFalse(r['cadence_qualified'])
                bad=journal(case);bad['BeforeClose']['Presentation']['Samples'][2]['State']='pending';path.write_text(json.dumps(bad))
                with self.assertRaises(ValueError):c.validate_capture(path,case,'a'*64)
    def test_strict_validator_refuses_wrong_case_binary_and_retirement(self):
        case=c.CASES[0]
        with tempfile.TemporaryDirectory()as temp:
            path=Path(temp)/'capture.json'
            for mutate in [lambda j:j['Config'].pop('DisplayBackpressureNS'),lambda j:j['Config'].update(DisplayBackpressureNS=100_000_000),lambda j:j['Config'].update(GPURequested=True),lambda j:j.update(BinarySHA256='b'*64),lambda j:j.update(WorkerRetired=False),lambda j:j['AfterClose']['Presentation']['Scopes'][0].update(Closed=False)]:
                j=journal(case);mutate(j);path.write_text(json.dumps(j))
                with self.assertRaises(ValueError):c.validate_capture(path,case,'a'*64)
    def test_geometry_fingerprint_refuses_symlink_and_tracks_absence(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp).resolve()/'Core';root.mkdir()
            with patch.object(c,'CORE_DATA',root):
                self.assertEqual(c.geometry_state(),{'directory_exists':True,'files':{}})
                f=root/'window-geometry-0.3.6.json';f.write_text('{}');v=c.geometry_state();self.assertIn(f.name,v['files'])
                f.unlink();f.symlink_to(root/'missing')
                with self.assertRaises(ValueError):c.geometry_state()
    def test_admission_requires_current_availability_review_and_bounded_deadline(self):
        now=datetime.datetime.now(datetime.timezone.utc)
        plan={'head':c.HEAD,'cases':c.CASES,'native_execution_ready':False}
        review={'approved':True,'controller_ready':True,'unresolved_findings':[],'plan_sha256':'x','inputs':{}}
        record={'execution_ready':True,'plan_sha256':'x','review_sha256':'x','human_authorization':{'desktop_available':True,'message':'The machine is yours for testing'},'not_before_utc':(now-datetime.timedelta(minutes=1)).isoformat(),'last_launch_utc':(now+datetime.timedelta(minutes=1)).isoformat()}
        with patch.object(c,'sha',return_value='x'):
            self.assertGreater(c.admission(plan,review,record,now),now)
            for mutate in [lambda r:r['human_authorization'].update(desktop_available=False),lambda r:r['human_authorization'].update(message=''),lambda r:r.update(review_sha256='bad'),lambda r:r.update(last_launch_utc=(now-datetime.timedelta(seconds=1)).isoformat()),lambda r:r.update(last_launch_utc=(now+datetime.timedelta(hours=1)).isoformat()),lambda r:r.update(not_before_utc=now.replace(tzinfo=None).isoformat())]:
                bad=copy.deepcopy(record);mutate(bad)
                with self.assertRaises(ValueError):c.admission(plan,review,bad,now)
            bad=copy.deepcopy(review);bad['unresolved_findings']=['open']
            with self.assertRaises(ValueError):c.admission(plan,bad,record,now)
    def test_journal_fingerprint_refuses_fifo_symlink_directory_and_oversize(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);normal=root/'normal';normal.write_bytes(b'{}')
            self.assertEqual(c.file_record(normal,2)['sha256'],c.sha(normal))
            fifo=root/'fifo';os.mkfifo(fifo);link=root/'link';link.symlink_to(normal)
            oversized=root/'large';oversized.write_bytes(b'0123456789')
            for path in [fifo,link,root,oversized]:
                with self.assertRaises((ValueError,OSError)):c.file_record(path,2)
            large_journal=root/'large-journal'
            with large_journal.open('wb')as f:f.truncate((64<<20)+1)
            for path in [fifo,link,root,large_journal]:
                with self.assertRaises((ValueError,OSError)):c.validate_capture(path,c.CASES[0],'a'*64)
    def test_expiry_during_complete_boundary_scan_refuses_before_executor(self):
        now=datetime.datetime.now(datetime.timezone.utc);expired=[False];calls=[]
        class Clock:
            @classmethod
            def now(cls,zone):return now+datetime.timedelta(minutes=2)if expired[0]else now
        def scan(plan):expired[0]=True
        with tempfile.TemporaryDirectory()as temp,patch.object(c,'P',Path(temp)),patch.object(c,'datetime',SimpleNamespace(datetime=Clock,timezone=datetime.timezone)),patch.object(c,'boundary',side_effect=scan):
            host=object.__new__(c.NativeHost);host.plan={};host.deadline=now+datetime.timedelta(minutes=1);host.signaled=[False];host.runtime_pins={};host.lease=SimpleNamespace(held=lambda:True);host.g=SimpleNamespace(execute=lambda *a,**k:calls.append(a))
            with self.assertRaises(ValueError):host.command(['/never-launched'],c.T,Path(temp)/'native',30)
            self.assertEqual(calls,[])
    def test_final_checksum_rechecks_signal_deadline_lease_and_drift(self):
        for mode in['signal','deadline','lease','drift']:
            with self.subTest(mode=mode),tempfile.TemporaryDirectory()as temp:
                root=Path(temp);payload=root/'input';payload.write_bytes(b'fixed');expected=c.sha(payload);expired=[False];held=[True];host=object.__new__(c.NativeHost)
                host.plan={'pins':{str(payload):expected}};host.signaled=[False];host.runtime_pins={};host.lease=SimpleNamespace(held=lambda:held[0]);now=datetime.datetime.now(datetime.timezone.utc);host.deadline=now+datetime.timedelta(minutes=1)
                class Clock:
                    @classmethod
                    def now(cls,zone):return now+datetime.timedelta(minutes=2)if expired[0]else now
                real_sha=c.sha
                def last_scan(path):
                    result=real_sha(path)
                    if Path(path)==payload:
                        if mode=='signal':host.signaled[0]=True
                        elif mode=='deadline':expired[0]=True
                        elif mode=='lease':held[0]=False
                        else:return 'f'*64
                    return result
                with patch.object(c,'P',root),patch.object(c,'sha',side_effect=last_scan),patch.object(c,'datetime',SimpleNamespace(datetime=Clock,timezone=datetime.timezone)):
                    self.assertFalse(host.launch_stable(),'last-scan change admitted '+mode)
    def test_missing_final_binding_has_no_source_or_sdk_fallback(self):
        with tempfile.TemporaryDirectory()as temp,patch.object(c,'P',Path(temp)):
            with self.assertRaises(FileNotFoundError):c.configure_binding()

    def test_signals_do_not_interrupt_cleanup_and_sealing(self):
        state=[False];handler=c.cancellation_handler(state)
        handler(c.signal.SIGTERM,None);handler(c.signal.SIGINT,None)
        self.assertTrue(state[0])
        with tempfile.TemporaryDirectory()as temp,patch.object(c,'P',Path(temp)):
            real=object.__new__(c.NativeHost);real.plan={};real.runtime_pins={};real.signaled=[False];real.lease=SimpleNamespace(held=lambda:True);real.deadline=datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(days=1)
            # Expiry must never bypass the final source/lease inspection.
            with patch.object(c,'boundary',return_value=None)as check:
                real.finish();check.assert_called_once()
            def final_boundary(plan):c.cancellation_handler(real.signaled)(c.signal.SIGTERM,None)
            host=FakeHost();host.finish=real.finish
            with patch.object(c,'boundary',side_effect=final_boundary):
                r=c.execute_cases({'cases':c.CASES},host,Path(temp))
            self.assertEqual(r['result'],'FAILED_OR_CANCELED');self.assertTrue(real.signaled[0]);self.assertIn('final_boundary_error',r)
            self.assertTrue((Path(temp)/'result.json').exists());self.assertTrue((Path(temp)/'stop-live').exists())
            for case in c.CASES:self.assertTrue((Path(temp)/case['id']/'sealed').exists())
    def test_real_signals_during_final_boundary_preserve_sealing(self):
        with tempfile.TemporaryDirectory()as temp,patch.object(c,'P',Path(temp)):
            state=[False];previous={sig:c.signal.signal(sig,c.cancellation_handler(state))for sig in[c.signal.SIGTERM,c.signal.SIGINT]}
            try:
                host=FakeHost();real=object.__new__(c.NativeHost);real.plan={};real.runtime_pins={};real.signaled=state;real.lease=SimpleNamespace(held=lambda:True);real.deadline=datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(days=1);host.finish=real.finish
                def interrupt(plan):
                    os.kill(os.getpid(),c.signal.SIGTERM);os.kill(os.getpid(),c.signal.SIGINT)
                with patch.object(c,'boundary',side_effect=interrupt):result=c.execute_cases({'cases':c.CASES},host,Path(temp))
                self.assertTrue(state[0]);self.assertEqual(result['result'],'FAILED_OR_CANCELED');self.assertTrue((Path(temp)/'stop-live').exists());self.assertTrue((Path(temp)/'result.json').exists())
            finally:
                for sig,handler in previous.items():c.signal.signal(sig,handler)

    def test_runtime_admission_files_cannot_drift_during_native_call(self):
        with tempfile.TemporaryDirectory()as temp:
            f=Path(temp)/'admission';f.write_text('original')
            host=object.__new__(c.NativeHost);host.runtime_pins={str(f):c.sha(f)}
            self.assertTrue(host.runtime_stable());f.write_text('changed');self.assertFalse(host.runtime_stable())

from finalize_metadata_test import Metadata

if __name__=='__main__':unittest.main(verbosity=2)
