"""In-memory inspection controls; never imports the launch helper or executes Go."""
import ast
import copy
import json
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name('run.py')
TREE = ast.parse(SOURCE.read_text())
NAMESPACE = {'Path': Path, 'json': json}
SELECTED = [n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name in {'need', 'expected_origins', 'inspect'}]
assert len(SELECTED) == 3
exec(compile(ast.Module(body=SELECTED, type_ignores=[]), str(SOURCE), 'exec'), NAMESPACE)
SDK = Path('/private/tmp/in-memory-sdk105')
CONSUMER = SDK.parent / 'in-memory-consumer'
EXPECTED = NAMESPACE['expected_origins'](SDK)
REQUIRED = ['cogentcore.org/core', 'github.com/dshills/vellum', 'github.com/dshills/vellum/drivers/cogent', 'github.com/go-text/typesetting', 'github.com/oliverbestmann/webgpu/libs-darwin']


def metadata():
    return {'GoVersion': 'go1.25.6', 'Path': 'example.com/vellum-sdk-display105-consumer',
            'Main': {'Path': 'example.com/vellum-sdk-display105-consumer', 'Version': '(devel)'},
            'Settings': [{'Key': k, 'Value': v} for k, v in {'GOOS': 'darwin', 'GOARCH': 'arm64', 'CGO_ENABLED': '1'}.items()],
            'Deps': [{'Path': k, 'Replace': {'Path': str(EXPECTED[k]), 'Version': '(devel)'}} for k in REQUIRED]}


class MetadataControls(unittest.TestCase):
    def inspect(self, m):
        return NAMESPACE['inspect']('metadata', json.dumps(m), {'consumer': str(CONSUMER)}, {'sdk': str(SDK)})

    def test_valid_five_linked_modules(self):
        m = metadata()
        m['Deps'].append({'Path': 'example.org/external', 'Version': 'v1.2.3'})
        self.assertEqual(set(self.inspect(m)['local_origins']), set(REQUIRED))

    def test_valid_relative_origin(self):
        m = metadata()
        m['Deps'][0]['Replace']['Path'] = '../in-memory-sdk105/drivers/cogent/build/upstream'
        self.assertEqual(self.inspect(m)['local_origins'][REQUIRED[0]], str(EXPECTED[REQUIRED[0]]))

    def test_all_nine_present_allowed(self):
        m = metadata()
        m['Deps'] = [{'Path': k, 'Replace': {'Path': str(v), 'Version': '(devel)'}} for k, v in EXPECTED.items()]
        self.assertEqual(len(self.inspect(m)['local_origins']), 9)

    def test_each_required_module_missing_rejected(self):
        for k in REQUIRED:
            with self.subTest(module=k):
                m = metadata()
                m['Deps'] = [d for d in m['Deps'] if d['Path'] != k]
                with self.assertRaises(ValueError): self.inspect(m)

    def test_wrong_origin_rejected(self):
        m = metadata(); m['Deps'][0]['Replace']['Path'] = '/private/tmp/another-sdk/core'
        with self.assertRaises(ValueError): self.inspect(m)

    def test_wrong_replacement_version_rejected(self):
        m = metadata(); m['Deps'][0]['Replace']['Version'] = 'v0.1.0'
        with self.assertRaises(ValueError): self.inspect(m)

    def test_unexpected_replacement_rejected(self):
        m = metadata(); m['Deps'].append({'Path': 'example.org/extra', 'Replace': {'Path': str(SDK), 'Version': '(devel)'}})
        with self.assertRaises(ValueError): self.inspect(m)

    def test_known_optional_wrong_origin_rejected(self):
        m = metadata(); m['Deps'].append({'Path': 'github.com/oliverbestmann/webgpu/libs-linux', 'Replace': {'Path': str(SDK / 'wrong'), 'Version': '(devel)'}})
        with self.assertRaises(ValueError): self.inspect(m)

    def test_duplicate_dependency_rejected(self):
        m = metadata(); m['Deps'].append(copy.deepcopy(m['Deps'][0]))
        with self.assertRaises(ValueError): self.inspect(m)

    def test_graph_still_requires_exact_nine(self):
        graph = [{'Path': k, 'Replace': {'Dir': str(v)}} for k, v in EXPECTED.items()]
        inspect = lambda rows: NAMESPACE['inspect']('graph', '\n'.join(json.dumps(r) for r in rows), {}, {'sdk': str(SDK)})
        self.assertEqual(len(inspect(graph)), 9)
        with self.assertRaises(ValueError): inspect(graph[:-1])


if __name__ == '__main__': unittest.main(verbosity=2)
