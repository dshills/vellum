"""One fresh SDK consumer: fixed headless preparation, then separately admitted native smoke."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;X=W.parent;N=W/'native'
HEAD='8cc374a070ad782dcc3e61a981c6501f5b82749c'
HELPER=X/'macos-display105-checks/run.py';LEASE=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,why):
    if not ok:raise ValueError(why)
def write(p,value):
    with Path(p).open('x')as f:f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load('sdk105_existing_boundary',HELPER);g=load('sdk105_existing_owner',c.E)
def geometry():
    root=Path('/Users/dshills/Library/Cogent Core');need(all(not p.is_symlink()for p in[root,*root.parents]),'geometry ancestors');files={}
    for name in['window-geometry-0.3.6.json','window-geometry-0.3.6.lst','window-geometry-0.3.6.lck']:
        p=root/name;need(not p.is_symlink(),'geometry leaf')
        if p.exists():need(p.is_file()and p.stat().st_size<=16<<20,'bounded regular geometry');files[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
    return {'directory_exists':root.exists(),'files':files}
def binding(plan):
    b=read(plan['binding']);need(b['head']==HEAD and sha(plan['binding'])==plan['binding_sha256'],'actual final source binding');c.boundary(b);return b
def prepare(path):
    need(not(W/'plan.json').exists(),'fresh preparation');path=Path(path);need(path.is_absolute()and all(not p.is_symlink()for p in[path,*path.parents]),'explicit canonical binding path')
    b=read(path);review=path.parent/'association-review.json';r=read(review)
    need(b['head']==HEAD and r['approved']is True and r['head']==HEAD and r['binding_sha256']==sha(path),'actual independently associated fresh SDK')
    c.boundary(b);need(b['go']['version']=='go1.25.6'and sha(b['go']['path'])==b['go']['sha256'],'actual pinned compiler')
    out=Path('/private/tmp/vellum-sdk-display105-native-consumer-'+HEAD[:7]);need(not out.exists(),'fresh owned output');out.mkdir(mode=0o700)
    consumer=out/'consumer application';binary=out/'consumer-native';python=Path(sys.executable).resolve();sdk=Path(b['sdk'])
    commands=[{'id':'generate','cwd':str(out),'argv':[str(python),'-B',str(sdk/'scripts/new-app.py'),str(consumer),'--module=example.com/vellum-sdk-display105-consumer'],'timeout':60},*({'id':name,'cwd':str(consumer),'argv':['/bin/sh',str(c.H),*args],'timeout':timeout}for name,args,timeout in [('graph',['list','-m','-json','all'],60),('build',['build','-p=1','-o',str(binary),'.'],240),('metadata',['version','-m','-json',str(binary)],30)])]
    pins={str(p):sha(p)for p in[Path(__file__),HELPER,c.E,c.H,LEASE,python,path,review,Path(b['go']['path'])]};pins.update(b['association_inputs'])
    plan={'scope':'fresh verified SDK public consumer only; no race/vet rerun or native admission','head':HEAD,'binding':str(path),'binding_sha256':sha(path),'pins':pins,'output':str(out),'consumer':str(consumer),'binary':str(binary),'commands':commands,'python':str(python)}
    c.boundary(b);need(all(sha(p)==v for p,v in pins.items()),'prepared pins stable');write(W/'plan.json',plan);print(json.dumps({'plan_sha256':sha(W/'plan.json'),'native_executed':False}))
def expected_origins(sdk):
    return {'cogentcore.org/core':sdk/'drivers/cogent/build/upstream','github.com/dshills/vellum':sdk,'github.com/dshills/vellum/drivers/cogent':sdk/'drivers/cogent','github.com/go-text/typesetting':sdk/'drivers/cogent/build/typesetting',**{'github.com/oliverbestmann/webgpu/libs-'+n:sdk/'drivers/cogent/build'/('libs-'+n)for n in['android','darwin','ios','linux','windows']}}
def inspect(name,text,plan,b):
    expected={k:str(v.resolve())for k,v in expected_origins(Path(b['sdk'])).items()}
    if name=='graph':
        decoder=json.JSONDecoder();modules=[]
        while text.strip():text=text.lstrip();value,end=decoder.raw_decode(text);modules.append(value);text=text[end:]
        need(len({m['Path']for m in modules})==len(modules),'unique graph modules');actual={m['Path']:str(Path(m['Replace']['Dir']).resolve())for m in modules if m.get('Replace',{}).get('Dir')};need(actual==expected,'nine exact fresh SDK graph replacements');return actual
    if name=='metadata':
        m=json.loads(text);need(m['GoVersion']=='go1.25.6'and m['Path']==m['Main']['Path']=='example.com/vellum-sdk-display105-consumer'and m['Main']['Version']=='(devel)'and not m['Main'].get('Replace'),'actual native main/compiler');settings={i['Key']:i.get('Value','')for i in m['Settings']}
        need(len(settings)==len(m['Settings'])and settings.get('GOOS')=='darwin'and settings.get('GOARCH')=='arm64'and settings.get('CGO_ENABLED')=='1'and settings.get('-tags','')==''and settings.get('-race')!='true'and '-N'not in settings.get('-gcflags','')and '-l'not in settings.get('-gcflags',''),'optimized native metadata');actual={};need(len({d['Path']for d in m['Deps']})==len(m['Deps']),'unique actual dependencies')
        for d in m['Deps']:
            if 'Replace'in d:need(d['Path']in expected and d['Replace']['Version']=='(devel)','actual local dependency');actual[d['Path']]=str((Path(plan['consumer'])/d['Replace']['Path']).resolve())
        required={'cogentcore.org/core','github.com/dshills/vellum','github.com/dshills/vellum/drivers/cogent','github.com/go-text/typesetting','github.com/oliverbestmann/webgpu/libs-darwin'}
        need(required<=actual.keys()and all(origin==expected[module]for module,origin in actual.items()),'required five linked SDK modules and exact present origins');return {'settings':settings,'local_origins':actual}
def profile(b,pins,consumer):
    protected=[Path(b['canonical']),Path(b['candidate']),Path(b['sdk']),Path('/Users/dshills/Library/Cogent Core')]
    if consumer.exists():protected.append(consumer)
    return '(version 1)(allow default)(deny network* (remote ip) (local ip))'+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in protected)+''.join('(deny file-write* (literal '+json.dumps(str(p))+'))'for p in pins)
def checks():
    plan=read(W/'plan.json');admit=read(W/'headless-admission.json');need(admit['approved']is True and admit['plan_sha256']==sha(W/'plan.json')and not(W/'headless-result.json').exists()and not(W/'stop-checks').exists(),'fresh exact headless admission')
    b=binding(plan);consumer=Path(plan['consumer']);pins={**plan['pins'],str(W/'plan.json'):sha(W/'plan.json'),str(W/'headless-admission.json'):sha(W/'headless-admission.json')};stop=[False]
    def flag(*args):stop[0]=True
    previous={n:signal.signal(n,flag)for n in[signal.SIGINT,signal.SIGTERM]};stopping=lambda:stop[0]or(W/'stop-checks').exists();stable=lambda:not stopping()and all(sha(p)==v for p,v in pins.items())and not stopping()
    env={'PATH':str(Path(b['go']['path']).parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(Path.home()),'LANG':os.environ.get('LANG','en_US.UTF-8'),'CGO_ENABLED':'1','GOMAXPROCS':'2','GOTOOLCHAIN':'local'};result={'result':'FAILED_FRESH_SDK_CONSUMER_HEADLESS','commands':{},'error':None,'native_executed':False,'plan_sha256':sha(W/'plan.json')}
    try:
        for phase in plan['commands']:
            c.boundary(b);need(stable(),'headless pre-launch boundary');argv=['/usr/bin/sandbox-exec','-p',profile(b,pins,consumer),'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*phase['argv']];r=g.execute(argv,Path(phase['cwd']),W/phase['id'],stopping,stable,timeout=phase['timeout'],limit=2<<20);result['commands'][phase['id']]=r;write(W/(phase['id']+'-receipt.json'),r);need(passed(r),'owned headless phase failed')
            if phase['id']=='generate':
                generated=c.vector(consumer);need(set(generated)=={'main.go','model.go','model_test.go','go.mod','go.sum','LICENSE'},'exact unmodified generator population');need(all(sha(consumer/n)==sha(Path(b['sdk'])/'examples/hello'/n)for n in generated if n!='go.mod'),'unmodified SDK example bytes');result['generated_files']=generated;pins.update({str(consumer/n):v for n,v in generated.items()})
            result.setdefault('observations',{})[phase['id']]=inspect(phase['id'],(W/phase['id']/'stdout').read_text(),plan,b);need(stable(),'headless post-launch pins')
        binary=Path(plan['binary']);result['binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary)};result['result']='PASS_FRESH_SDK_CONSUMER_HEADLESS'
    except BaseException as e:result['error']={'type':type(e).__name__,'message':str(e)}
    finally:
        try:c.boundary(b);need(stable(),'headless final pins');result['final_boundary_stable']=True
        except BaseException as e:result.update(result='FAILED_FRESH_SDK_CONSUMER_HEADLESS',boundary_error=str(e))
        write(W/'headless-result.json',result);(W/'stop-checks').touch()
        for n,h in previous.items():signal.signal(n,h)
    need(result['result']=='PASS_FRESH_SDK_CONSUMER_HEADLESS','retain failed evidence; no retry')
def passed(r):
    return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def prepare_native():
    plan=read(W/'plan.json');h=read(W/'headless-result.json');need(h['result']=='PASS_FRESH_SDK_CONSUMER_HEADLESS'and h['final_boundary_stable']and h['plan_sha256']==sha(W/'plan.json')and not N.exists(),'actual completed headless prerequisite');b=binding(plan)
    pins={**plan['pins'],str(W/'plan.json'):sha(W/'plan.json'),str(W/'headless-result.json'):sha(W/'headless-result.json'),h['binary']['path']:h['binary']['sha256'],**{str(Path(plan['consumer'])/n):v for n,v in h['generated_files'].items()}}
    for name,r in h['commands'].items():
        need(passed(r),'actual headless receipt');pins[str(W/(name+'-receipt.json'))]=sha(W/(name+'-receipt.json'))
        for stream,info in r['logs'].items():
            p=W/name/stream;need(p.stat().st_size==info['bytes']<=2<<20 and sha(p)==info['sha256'],'exact raw headless log');pins[str(p)]=info['sha256']
    need(all(sha(p)==v for p,v in pins.items()),'native preparation pins');N.mkdir();write(N/'plan.json',{'scope':'one fresh SDK public-consumer functional native smoke; not performance/release qualification','pins':pins,'binding':plan['binding'],'binding_sha256':plan['binding_sha256'],'geometry':geometry(),'argv':[plan['binary'],'--benchmark','--idle=1s','--samples=3'],'timeout':45});print(json.dumps({'native_plan_sha256':sha(N/'plan.json'),'native_executed':False}))
def native():
    plan=read(N/'plan.json');admit=read(N/'admission.json');need(admit['approved']is True and admit['plan_sha256']==sha(N/'plan.json')and not(N/'result.json').exists()and not(N/'stop-live').exists(),'fresh separate native admission');b=binding(plan);lease=load('sdk105_shared_lease',LEASE);consumer=Path(read(W/'plan.json')['consumer']);pins={**plan['pins'],str(N/'plan.json'):sha(N/'plan.json'),str(N/'admission.json'):sha(N/'admission.json')};stop=[False]
    def flag(*args):stop[0]=True
    previous={n:signal.signal(n,flag)for n in[signal.SIGINT,signal.SIGTERM]};result={'result':'FAILED_FRESH_SDK_NATIVE_CONSUMER','error':None,'performance_qualified':False}
    try:
        deadline=datetime.datetime.fromisoformat(admit['last_launch_utc']);need(deadline.tzinfo is not None,'aware native deadline')
        with lease.LiveLease()as held:
            stopping=lambda:stop[0]or(N/'stop-live').exists()or not held.held()or datetime.datetime.now(datetime.timezone.utc)>=deadline;stable=lambda:not stopping()and all(sha(p)==v for p,v in pins.items())and not stopping()
            try:
                c.boundary(b);result['geometry_before']=geometry();need(result['geometry_before']==plan['geometry']and stable(),'native pre-launch boundary');env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(Path.home()),'LANG':os.environ.get('LANG','en_US.UTF-8'),'GOMAXPROCS':'2'};argv=['/usr/bin/sandbox-exec','-p',profile(b,pins,consumer),'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*plan['argv']];r=g.execute(argv,consumer,N/'run',stopping,stable,timeout=45,limit=1<<20);result['receipt']=r;need(passed(r),'normal owned native return');result['report']=g.validate_record((N/'run/stdout').read_text());need(result['report']['go_version']=='go1.25.6','actual runtime compiler');result['result']='PASS_ONE_FRESH_SDK_NATIVE_CONSUMER'
            finally:
                c.boundary(b);result['geometry_after']=geometry();need(result['geometry_after']==plan['geometry']and all(sha(p)==v for p,v in pins.items())and held.held()and not stop[0]and not(N/'stop-live').exists(),'native final boundary');result['final_boundary_stable']=True
    except BaseException as e:result.update(result='FAILED_FRESH_SDK_NATIVE_CONSUMER',error={'type':type(e).__name__,'message':str(e)})
    finally:
        write(N/'result.json',result);(N/'stop-live').touch()
        for n,h in previous.items():signal.signal(n,h)
    need(result['result']=='PASS_ONE_FRESH_SDK_NATIVE_CONSUMER','retain failed evidence; no retry')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare','checks','prepare-native','native']);parser.add_argument('--binding');args=parser.parse_args();need((args.mode=='prepare')==bool(args.binding),'only prepare takes explicit --binding')
    if args.mode=='prepare':prepare(args.binding)
    elif args.mode=='checks':checks()
    elif args.mode=='prepare-native':prepare_native()
    else:native()
