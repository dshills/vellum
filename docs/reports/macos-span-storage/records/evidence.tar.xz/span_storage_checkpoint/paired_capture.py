from pathlib import Path
import hashlib,json,re,statistics,subprocess
P=Path('/private/tmp/vellum-macos-span-storage');R=Path('/private/tmp/vellum-span-storage')
results={n:[]for n in ['original','candidate']}
for pair in range(1,6):
 for mode in (['original','candidate']if pair%2 else ['candidate','original']):
  name=f'pair-{pair}-{mode}';fixture=P/(name+'_test.go')
  s=(P/('capture-'+mode+'_test.go')).read_text().replace(str(P/('capture-'+mode+'-packet.json')),str(P/(name+'-packet.json')))
  fixture.write_text(s);overlay=json.loads((P/('capture-'+mode+'-overlay.json')).read_text());overlay['Replace'][str(R/'drivers/cogent/span_capture_external_test.go')]=str(fixture)
  selected=P/(name+'-overlay.json');selected.write_text(json.dumps(overlay,indent=2)+'\n')
  child=subprocess.run(['python3',str(P/'code_run.py'),name,'drivers/cogent','go','test','-tags=offscreen','-p=1','-overlay='+str(selected),'-run=^TestVellumSpanStorageActualCapture$','-count=1','-v','.'],stdout=subprocess.DEVNULL)
  assert child.returncode==0
  match=re.search(r'CAPTURE_ACTUAL_GRID\s+(\d+)\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(P/(name+'.stdout')).read_text());assert match
  row=dict(zip(['iterations','ns_per_op','bytes_per_op','allocations_per_op'],map(int,match.groups())));row['pair']=pair;results[mode].append(row);print(name,row,flush=True)
 a=json.loads((P/f'pair-{pair}-original-packet.json').read_text());b=json.loads((P/f'pair-{pair}-candidate-packet.json').read_text());assert a==b
summary={'result':'MEASURED_LOCAL_UNPROFILED_CAPTURE_ONLY','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'pairs':5,'results':results,'medians':{mode:{field:statistics.median([r[field]for r in rows])for field in ['ns_per_op','bytes_per_op','allocations_per_op']}for mode,rows in results.items()},'actual_pixels_encoding_and_accounting_equal':True,'cpu_profiling_active':False,'host_native_endurance_concurrent':True,'native_frame_gain_qualified':False,'scope':'Procedural400-cell softwaredriver batch,DPI96,fixedrows,NotoSans15,GOMAXPROCS2; other native endurance process active. Local timing/allocation observation only,not wholeframe/P6/native/GPU memory qualification.'}
(P/'paired-local-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='results'}),flush=True)
