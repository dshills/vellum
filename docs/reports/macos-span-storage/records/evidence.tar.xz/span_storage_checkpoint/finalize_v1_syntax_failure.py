from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-span-storage');P=Path('/private/tmp/vellum-macos-span-storage')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
base=json.loads((P/'prepared-baseline.json').read_text());after=json.loads((P/'prepared-final.json').read_text());assert len(base)==6210 and len(after)==6211
checks={};code={n:sha(R/n)for n in set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())if n.startswith('drivers/')};assert len(code)==6
for name in ['final-prepare','final-preparation-tests','final-sceneplan-race','final-sceneplan-vet','final-actual-matrix','final-adapter-vet','final-adapter-race','final-native-build']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and not d['error'] and d['source_delta_stable']
 assert all(d['source_delta_before'][n]==d['source_delta_after'][n]==h for n,h in code.items()) and d['overlay_inputs_before']==d['overlay_inputs_after']
 # Preparation unit tests mock their own installations and do not use the real
 # prepared dependencies; their stable snapshots precede normal regeneration.
 if name=='final-preparation-tests':assert d['prepared_before']==d['prepared_after']==base
 else:assert d['prepared_after']==after and d['prepared_before']==(base if name=='final-prepare'else after)
 for c in ['stdout','stderr']:assert sha(P/(name+'.'+c))==d[c+'_sha256']
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'argv':d['argv'],'uses_prepared_dependencies':name!='final-preparation-tests'}
assert json.loads((P/'matrix-comparison.json').read_text())['frames']==48
for name,needle in [('copy','serialized row order or coverage differs'),('capacity','row retains capacity from another row')]:
 d=json.loads((P/('negative-'+name+'.json')).read_text());assert d['exit_code']==1 and not d['error'] and d['source_delta_stable']and needle in(P/('negative-'+name+'.stdout')).read_text()
f=R/'specs/rendering.md';s=f.read_text();s=s.replace('memory, or the unchanged P6 targets. See the scoped report.','memory, or the unchanged P6 targets. See [the scoped report](../docs/reports/macos-span-storage/README.md).');f.write_text(s)
f=R/'docs/reports/macos-span-storage/README.md';s=f.read_text().replace('source review found no issues. Normal preparation, the 48-frame current-driver
matrix, final code/build gates and checkpoint reviews are pending. Native follow-up','source review found no issues. Normal preparation reproduces two pinned outputs
(6,210 to 6,211 leaves); every other dependency leaf is unchanged. All 48 current
driver records match the stage-59 reference across four DPI settings and
fixed/variable rows, including pixels, payload shape and accounting. Sceneplan
race/vet, full adapter race/vet, preparation tests and native build pass. The
preparation unit tests use mocked installations and stable stage-59 dependency
snapshots, while testing the new manifest/pins; regeneration and runtime code
gates separately bind the exact stage-60 dependencies. The native binary is
built and hash-bound but has not been launched. Internal final review and one
bounded Anthropic Claude Sonnet 5.5 Prism review precede commit. Native follow-up');f.write_text(s)
names=sorted(set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()));assert len(names)==8
sources={n:sha(R/n)for n in names};manifest={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources};(P/'checkpoint-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
local=json.loads((P/'paired-local-summary.json').read_text());build=json.loads((P/'native-binary.json').read_text());assert build['produced_file_sha256']==sha(P/'loadedgrid')
summary={**manifest,'result':'PASS_SCOPED_PACKED_SPAN_STORAGE','checks':checks,'prepared_before_files':6210,'prepared_after_files':6211,'all_other_leaves_unchanged':True,'software_frames_identical':48,'negative_controls_detected':2,'local_capture_pairs':5,'local_capture_cpu_profiling_active':False,'host_native_endurance_concurrent':True,'local_capture_medians':local['medians'],'native_build_sha256':build['produced_file_sha256'],'native_binary_launched':False,'native_gpu_run':False,'native_performance_gain_qualified':False,'physical_or_retained_memory_gain_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False};(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS8code/buildgates,48exactframes,two detectedfaults,6210to6211;8sourcefiles bound')
