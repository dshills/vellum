from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('/private/tmp/vellum-span-storage');P=Path('/private/tmp/vellum-macos-span-storage');D=R/'drivers/cogent/native/patches/spanstorage'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
review=json.loads((P/'candidate-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings']
summary=json.loads((P/'paired-local-summary.json').read_text());assert summary['pairs']==5 and summary['actual_pixels_encoding_and_accounting_equal']and not summary['cpu_profiling_active']
original=R/'drivers/cogent/build/upstream/paint/renderers/sceneplan/builder.go';assert sha(original)==sha(P/'original-builder.go')
base={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert len(base)==6210
(P/'prepared-baseline.json').write_text(json.dumps(base,indent=2)+'\n')
outputs={'paint/renderers/sceneplan/builder.go':P/'builder.go','paint/renderers/sceneplan/span_storage_vellum_test.go':P/'span_storage_test.go'};inputs={};hashes={};chunks=[]
for rel,src in outputs.items():
 old=R/'drivers/cogent/build/upstream'/rel;inputs[rel]=sha(old)if old.exists()else None;hashes[rel]=sha(src)
 chunks.extend(difflib.unified_diff(old.read_text().splitlines(True)if old.exists()else[],src.read_text().splitlines(True),fromfile='a/'+rel if old.exists()else'/dev/null',tofile='b/'+rel))
D.mkdir();patch=D/'0060-packed-owned-span-rows.patch';patch.write_text(''.join(chunks))
for name,d in [('original-hashes',inputs),('output-hashes',hashes)]:(D/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
f=R/'drivers/cogent/native/dependencies.json';d=json.loads(f.read_text());core=d['dependencies'][0];assert[int(p['file'].rsplit('/',1)[-1][:4])for stage in core['stages']for p in stage['patches']]==list(range(1,60))
core['stages'].append({'origin':'drivers/cogent/native/patches/spanstorage','inputs':'native/patches/spanstorage/original-hashes.json','outputs':'native/patches/spanstorage/output-hashes.json','patches':[{'file':'native/patches/spanstorage/'+patch.name,'sha256':sha(patch)}]});f.write_text(json.dumps(d,indent=2)+'\n')
f=R/'drivers/cogent/prepare_test.py';s=f.read_text();assert s.count('list(range(1, 60))')==1;f.write_text(s.replace('list(range(1, 60))','list(range(1, 61))'))
(D/'README.md').write_text("""# Packed owned span rows

Owned patch 0060 copies a span operation into one exact detached backing buffer.
Rows use full slice expressions with capacity equal to length. Appending cannot
write the next row. Construction storage and spare headers retire as before;
original byte charges, admission order, span order and encodings are unchanged.

The 600-stream original row-layout oracle checks serialized GPU/original bytes,
seeded replay, borrowed construction mutation and appended row isolation. Existing
budget/refused-allocation tests remain in force. New tests are MIT. Preparation
checks all input/output hashes and the patch SHA256.
""")
f=R/'specs/rendering.md';f.write_text(f.read_text()+"""

## Packed owned span rows

Stage 60 uses one exact detached span backing per operation. Every row has
capacity equal to its length, including empty/gapped rows. Row order, span order,
clipping, partial alpha and seeded replay match the original layout. Construction
row-header refunds and operation admission still happen before compact storage
allocation. Original Packet.Bytes and both Encode/EncodeGPU results are unchanged;
the original accounting covers every retained span once.

A 600-stream original-row oracle checks byte identity, seeded pixels and isolation
from borrowed construction mutations and appended row copies. Five interleaved
unprofiled local 400-cell captures reduce allocations 106,337 to 88,944 per capture;
median local times were 3.832 versus 3.738 ms. A separate native endurance process
was active. This observation does not qualify native frame, retained/physical
memory, or the unchanged P6 targets. See the scoped report.
""")
report=R/'docs/reports/macos-span-storage';report.mkdir();(report/'records').mkdir()
(report/'README.md').write_text("""# Packed owned span rows

Stage 60 copies all rows in a span operation into one detached backing buffer.
Each row's capacity is capped at its length. Admission/refund order, retained
accounting, span order, original/GPU encoded bytes and CPU reconstruction stay
unchanged. Construction slices remain separate and retire on sealing.

Five interleaved unprofiled local 400-cell driver captures measured median
3.832 ms before and 3.738 ms after. Allocation count fell from 106,337 to 88,944
(17,393 fewer); median allocated bytes were 9,283,434 and 9,273,835. These are
procedural fixed-row DPI96/NotoSans15 software captures with two benchmark threads
while the separate native endurance process ran. They do not qualify native
whole-frame timing or physical/retained memory.

The sceneplan race suite and a 600-stream independent original-row oracle pass.
Borrowed construction overwrite, append isolation, exact capacity, serialized
original/GPU bytes and seeded partial-alpha pixels are checked. Two deliberately
faulty overlays fail missing-copy and row-capacity assertions. Internal candidate
source review found no issues. Normal preparation, the 48-frame current-driver
matrix, final code/build gates and checkpoint reviews are pending. Native follow-up
must run after the existing endurance, tab-close and stage-59 comparison sequences.
The original 4 ms p95 / 6 ms p99 native targets remain unqualified by this change;
full P6/P11, human input/accessibility and Mac distribution remain open.
""")
(P/'adoption.json').write_text(json.dumps({'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'patch_sha256':sha(patch),'inputs':inputs,'outputs':hashes,'before_files':6210,'expected_after_files':6211},indent=2)+'\n')
o=json.loads((P/'matrix-overlay.json').read_text());o['Replace'].pop(str(original));(P/'final-matrix-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
print('Created owned stage60 with two pinned outputs, specs and scoped report')
