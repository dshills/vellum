from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-span-storage');P=Path('/private/tmp/vellum-macos-span-storage');D=R/'docs/reports/macos-span-storage/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==0 and process['error']is None and process['source_index_stable']
assert review['coverage']['complete'] and review['coverage']['files']==8 and not review['findings'];assert review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==sources
summary=json.loads((P/'final-summary.json').read_text());assert summary['result']=='PASS_SCOPED_PACKED_SPAN_STORAGE' and summary['sources']==sources
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.cpu','.png'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['span_storage_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Reviewed stage60 source/pins,8passing code/buildgates,600stream ownership/reference oracle,48exact softwareframes,2detectedfaults,5unprofiled localcapturepairs while separateendurance active,original/faultsource and V1finalizer syntaxfailure preserved. Preparation unittest usesmockinstallation/stable6210 snapshots; runtimegates6211. Nativebinary excluded with boundhash; no nativegain/physicalmemory/fullP6/P11qualification.'},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':8,'prism_findings':0,'prism_calls':review['coverage']['llmCalls'],'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in['sources','checks']}))
