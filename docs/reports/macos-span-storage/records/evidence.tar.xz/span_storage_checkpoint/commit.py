from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-span-storage');P=Path('/private/tmp/vellum-macos-span-storage');D=R/'docs/reports/macos-span-storage/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode().strip()
q=json.loads((D/'qualification.json').read_text());assert git('rev-parse','HEAD')==q['base_commit'] and q['prism_coverage_complete'] and q['prism_findings']==0
assert all(sha(R/n)==h for n,h in q['sources'].items()) and sha(D/'evidence.tar.xz')==q['archive_sha256']
subprocess.run(['git','add','--',str(D.relative_to(R))],cwd=R,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
expected=set(q['sources'])|{(D/n).relative_to(R).as_posix()for n in['qualification.json','evidence-index.json','evidence.tar.xz']};assert set(git('diff','--cached','--name-only').splitlines())==expected and len(expected)==11
output=subprocess.check_output(['git','commit','-m','perf(render): pack owned span rows per operation'],cwd=R).decode();assert not git('status','--porcelain');commit=git('rev-parse','HEAD');assert git('rev-list','--parents','-n','1','HEAD').split()==[commit,q['base_commit']]
(P/'commit-receipt.json').write_text(json.dumps({'result':'PASS_REVIEWED_SCOPED_COMMIT','commit':commit,'base_commit':q['base_commit'],'source_files':8,'files':11,'archive_sha256':q['archive_sha256'],'scratch_clean':True,'canonical_promoted':False,'output':output},indent=2)+'\n');print(output);print(commit)
