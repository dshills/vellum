from pathlib import Path
import hashlib,io,json,tarfile
ROOT=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-part-snapshots');R=ROOT/'docs/reports/macos-part-snapshots/records'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source-v2.json').read_text())['sources'];old=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert len(sources)==16 and all(sha(ROOT/n)==h for n,h in sources.items())
assert [n for n in sources if sources[n]!=old[n]]==['drivers/cogent/cmd/workbench/document_test.go']
review=json.loads((P/'revision-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['findings'] and not review['unresolved_findings'] and review['files']==sources
for f,h in review['reviewed_artifact_sha256'].items():assert sha(f)==h
r=json.loads((P/'revised-test-race-v1.json').read_text());assert r['exit_code']==0 and r['error'] is None and r['source_delta_stable'];assert all(r['source_delta_after'][n]==h for n,h in sources.items())
c=json.loads((P/'guard-counterfactual-v1.json').read_text());assert c['exit_code']==1 and c['error'] is None and c['source_delta_stable'] and 'exhausted revision admitted valid prepared document (source=true): <nil>' in (P/'guard-counterfactual-v1.stdout').read_text()
base=json.loads((P/'baseline.json').read_text())
prepared={f.relative_to(ROOT/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting'] for f in sorted((ROOT/'drivers/cogent/build'/m).rglob('*')) if f.is_file()};assert prepared==base['prepared'] and len(prepared)==6202
for name in ['native-document-v2','native-calculation-v1','native-editing-v1']:
 t=json.loads((P/(name+'.json')).read_text());assert t['exit_code']==0 and t['error'] is None and t['source_delta_stable'];assert all(t['source_delta_after'][n]==h for n,h in sources.items() if n.endswith('.go') and not n.endswith('_test.go'))
full=json.loads((P/'prism-v2/prism.json').read_text());fix=json.loads((P/'prism-v3/prism.json').read_text());fullprocess=json.loads((P/'prism-v2/process.json').read_text());fixprocess=json.loads((P/'prism-v3/process.json').read_text())
assert full['coverage']['complete'] and full['coverage']['files']==18 and len(full['findings'])==1 and full['findings'][0]['id']=='cbc662f25318e833'
assert fullprocess['exit_code']==1 and fullprocess['source_index_stable'] and fullprocess['error'] is None
assert fix['coverage']['complete'] and fix['coverage']['files']==1 and not fix['findings'] and fixprocess['exit_code']==0 and fixprocess['source_index_stable'] and fixprocess['error'] is None
assert fixprocess['after']=={'drivers/cogent/cmd/workbench/document_test.go':sources['drivers/cogent/cmd/workbench/document_test.go']}
assert all(fullprocess['after'][n]==h for n,h in sources.items() if n!='drivers/cogent/cmd/workbench/document_test.go')
a=json.loads((P/'archive-verified.json').read_text());assert a['archive_sha256']==sha(R/'evidence.tar.xz') and a['index_sha256']==sha(R/'evidence-index.json') and a['archive_index_verified']
selected=['checkpoint-source-v2.json','revision-review.json','revision-review.md','revised-test-race-v1.json','revised-test-race-v1.stdout','revised-test-race-v1.stderr','guard-counterfactual-v1.json','guard-counterfactual-v1.stdout','guard-counterfactual-v1.stderr','counterfactual-overlay.json','document-without-source-revision-guard.go','prism-correction.py','finalize.py']
members={'phase/'+n:(P/n).read_bytes() for n in selected};members.update({'phase/'+f.relative_to(P).as_posix():f.read_bytes() for sub in ['prism-v2','prism-v3'] for f in sorted((P/sub).rglob('*')) if f.is_file()})
members['root/drivers/cogent/cmd/workbench/document_test.go']=(ROOT/'drivers/cogent/cmd/workbench/document_test.go').read_bytes()
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(R/'correction.tar.xz','x:xz') as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(R/'correction-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(R/'correction.tar.xz','r:xz') as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
q={'result':'REVIEWED_MAC_PART_SNAPSHOTS','base_commit':base['commit'],'source':sources,'prepared_files':6202,'prepared_exact':True,'internal_review_sha256':sha(P/'final-source-review.json'),'revision_review_sha256':sha(P/'revision-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_initial_findings':1,'prism_findings':0,'prism_coverage_complete':True,'prism_full_review_files':18,'prism_delta_review_files':1,'prism_initial_sha256':sha(P/'prism-v2/prism.json'),'prism_final_sha256':sha(P/'prism-v3/prism.json'),'finding_resolution':'cbc662f25318e833 ACCEPTED_FIXED; valid decoded revision-exhaustion regression and counterfactual proof','archive_sha256':sha(R/'evidence.tar.xz'),'index_sha256':sha(R/'evidence-index.json'),'archive_members':a['archive_members'],'archive_index_verified':True,'correction_archive_sha256':sha(R/'correction.tar.xz'),'correction_index_sha256':sha(R/'correction-index.json'),'correction_members':len(index),'correction_index_verified':True,'native_million_record_document':True,'native_calculation_sum':597995654,'native_editing_seconds':10,'limits':['Shared component snapshot descriptor24B; owner path arrays3072B; local million-record traversal3.1x slower.','Geometry/reference capture and initial construction stillcopy/scan; legacy table projection admission stilllinear.','No whole-frame/native-memory/fullP6/P11/human/Mac-release acceptance.'],'finalizer_sha256':sha(__file__)}
(R/'checkpoint.json').write_text(json.dumps(q,indent=2)+'\n');print('FINAL verified',a['archive_members'],'original /',len(index),'correction members; zero unresolved findings')
