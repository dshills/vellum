from pathlib import Path
import hashlib,io,json,tarfile
ROOT=Path('/private/tmp/vellum-large-data');PHASE=Path('/private/tmp/vellum-macos-part-snapshots')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources=json.loads((PHASE/'checkpoint-source.json').read_text())['sources'];assert len(sources)==16 and all(sha(ROOT/n)==h for n,h in sources.items())
review=json.loads((PHASE/'final-source-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['findings'] and review['files']==sources
for f,h in review.get('reviewed_artifact_sha256',{}).items():assert sha(f)==h
baseline=json.loads((PHASE/'baseline.json').read_text())
for name in ['final-adapter-race-v1','final-vet-v1']:
 r=json.loads((PHASE/(name+'.json')).read_text());assert r['exit_code']==0 and r['error'] is None and r['source_delta_stable'] and r['source_delta_after']==sources and r['prepared_before']==r['prepared_after']==baseline['prepared']
for name in ['native-document-v2','native-calculation-v1','native-editing-v1']:
 r=json.loads((PHASE/(name+'.json')).read_text());assert r['exit_code']==0 and r['error'] is None and r['source_delta_stable'] and r['prepared_before']==r['prepared_after']==baseline['prepared']
records=ROOT/'docs/reports/macos-part-snapshots/records';records.mkdir()
suffixes={'.go','.py','.txt','.json','.jsonl','.stdout','.stderr','.log','.md','.trace','.pprof'}
members={'phase/'+f.relative_to(PHASE).as_posix():f.read_bytes() for f in sorted(PHASE.rglob('*')) if f.is_file() and f.suffix in suffixes}
members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz') as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
(records/'benchmark-summary.json').write_bytes((PHASE/'benchmark-summary.json').read_bytes())
provider={**sources,**{f'docs/reports/macos-part-snapshots/records/{n}':sha(records/n) for n in ['evidence-index.json','benchmark-summary.json']}}
(PHASE/'prism-source.json').write_text(json.dumps({'sources':provider},indent=2)+'\n')
(PHASE/'archive-verified.json').write_text(json.dumps({'source':sources,'archive_members':len(index),'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),'archive_index_verified':True},indent=2)+'\n');print('Verified',len(index),'archive members; provider18 leaves')
