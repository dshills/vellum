"""Headless clean SDK packaging/relocation only. No native launch/publication."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-sdk-stage0079-abe67c6');HEAD='abe67c625a498d27b78f9719e6038cc1d6c23e88'
GO=Path('/Users/dshills/Development/Go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin/go');PY=Path('/opt/homebrew/bin/python3').resolve();LIB=Path('/private/tmp/vellum-source-built-gpu-276a654/build-target-v1/aarch64-apple-darwin/release/libwgpu_native.a');PROV=W.parent/'macos-source-gpu-sdk-a274e8a/gpu-provenance.json';LIBSHA='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883';GOSHA='9c35eaeb87fd3df884c3540b25f3556902c164d88afe8a88e62ceb819d0da211'
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
PROFILE='(version 1)(allow default)(deny network* (remote ip) (local ip))'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while v:=f.read(1<<20):h.update(v)
 return h.hexdigest()
def git(r,*args):return subprocess.check_output(['git',*args],cwd=r,timeout=30)
def source(r):
 need(git(r,'rev-parse','HEAD').decode().strip()==HEAD and not git(r,'status','--porcelain'),'clean exact checkout')
 names=git(r,'ls-files','-z').decode().split('\0')[:-1];need(len(names)<20000,'bounded source count');files={}
 for name in names:
  p=r/name;need(p.is_file()and not p.is_symlink(),'regular tracked source');files[name]=sha(p)
 deps={n+'/'+p.relative_to(r/'drivers/cogent/build'/n).as_posix():sha(p)for n in['upstream','typesetting']for p in(r/'drivers/cogent/build'/n).rglob('*')if p.is_file()};need(len(deps)==6260 and hashlib.sha256(json.dumps(deps,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba','stage79')
 return {'head':HEAD,'tracked':files,'prepared':deps}
def prepare():
 need(not P.exists()and not(W/'plan.json').exists(),'fresh SDK scope');need(sha(GO)==GOSHA and sha(LIB)==LIBSHA,'exact compiler/archive');a=source(C);need(source(T)==a,'canonical/candidate parity');P.mkdir(mode=0o700)
 files=[Path(__file__),GO,PY,LIB,PROV]+list((T/'scripts').glob('*.py'));pins={str(p):sha(p)for p in files};plan={'source':a,'pins':pins,'output':str(P/'sdk.tar.gz'),'source_commit':HEAD,'compiler':'go1.25.6 darwin/arm64','source_private':True,'network_policy':PROFILE,'scope':'Headless private SDK packaging and existing relocation checker only. No --runtime, public publication, app execution, native input, system settings, signing or acceptance claim. Actual stage79+M1 fixes. All-demo main builds and asset mapping separate followup after successful relocation.','package_argv':[str(PY),'-B',str(T/'scripts/release-sdk.py'),'--output',str(P/'sdk.tar.gz'),'--macos-gpu-library',str(LIB),'--macos-gpu-sha256',LIBSHA,'--macos-gpu-provenance',str(PROV)],'checker_argv_prefix':[str(PY),'-B',str(T/'scripts/check-sdk.py'),'--archive',str(P/'sdk.tar.gz'),'--sha256']};(W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(W/'plan.json'),'tracked_files':len(a['tracked']),'prepared_files':len(a['prepared']),'runtime':False}))
def run():
 need(not(W/'result.json').exists()and not(W/'stop-build').exists(),'fresh run');plan=json.loads((W/'plan.json').read_text());admit=json.loads((W/'admission.json').read_text());need(admit['approved']and admit['plan_sha256']==sha(W/'plan.json'),'exact reviewed plan');d={'result':'INCOMPLETE','source_commit':HEAD,'commands':{},'error':None,'runtime_executed':False,'closed_mac_gates':[],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 env={k:v for k,v in os.environ.items()if k in['HOME','LANG','LC_ALL','LC_CTYPE','TMPDIR','USER']};env.update(PATH=str(GO.parent)+':'+str(PY.parent)+':/usr/bin:/bin:/usr/sbin:/sbin',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOFLAGS='-mod=readonly',GOPROXY='off',GOSUMDB='off',GOMAXPROCS='2',PYTHONDONTWRITEBYTECODE='1')
 def boundary():
  need(not(W/'stop-build').exists(),'stop requested');need(all(sha(p)==h for p,h in plan['pins'].items()),'pinned input drift');need(source(C)==source(T)==plan['source'],'source/prepared identity')
 def command(name,args,timeout):
  boundary();argv=['/usr/bin/sandbox-exec','-p',PROFILE,*args];at=time.monotonic()
  with(W/(name+'.stdout')).open('xb')as o,(W/(name+'.stderr')).open('xb')as e:r=run_child(argv,cwd=T,env=env,stdout=o,stderr=e,timeout=timeout,log_limit_bytes=8<<20)
  receipt={'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-at};d['commands'][name]=receipt;(W/(name+'-command.json')).write_text(json.dumps(receipt,indent=2)+'\n');need(r.returncode==0,'command failed '+name);boundary();print(json.dumps({'command':name,**receipt}),flush=True)
 try:
  command('package',plan['package_argv'],900);digest=sha(P/'sdk.tar.gz');need(not(P/'sdk.tar.gz').is_symlink(),'regular archive');d['archive']={'path':str(P/'sdk.tar.gz'),'bytes':(P/'sdk.tar.gz').stat().st_size,'sha256':digest};command('relocation',plan['checker_argv_prefix']+[digest],1200);observed=json.loads((W/'relocation.stdout').read_text());need(observed['source']['commit']==HEAD and observed['source']['clean'] is True and observed['native_runtime']=='not executed','exact clean SDK non-runtime result');d['relocation']=observed;d['result']='PASS_PRIVATE_SDK_PACKAGE_RELOCATION';d['source_prepared_unchanged']=True
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:(W/'stop-build').touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in['result','error','archive']}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in[['prepare'],['run']],'fixed phase');prepare()if sys.argv[1]=='prepare'else run()
