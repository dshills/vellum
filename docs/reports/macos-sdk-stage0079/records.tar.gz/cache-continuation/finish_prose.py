from pathlib import Path
p=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-sdk-stage0079/README.md');s=p.read_text();old='''| Module group | Main executables |
| --- | ---: |
| Driver default main packages | 15 |
| Eleven runnable example modules | 11 |
| SDK-contract (test-only; race/vet already pass) | 0 |
| Explicit tagged window-cycle helper | 1 |
''';new='''| Group | Modules | Default mains | Additional tagged mains |
| --- | ---: | ---: | ---: |
| Driver | 1 | 15 | 1 |
| Runnable examples | 11 | 11 | 0 |
| SDK-contract (test-only; race/vet already pass) | 1 | 0 | 0 |
| Total | 13 | 26 | 1 |

The thirteen modules are 1 driver + 11 runnable examples + 1 SDK-contract.
Default mains are 15 + 11 = 26; the helper is inside the existing driver module,
so it adds one executable, yielding 27, without adding a fourteenth module.
''';assert old in s;s=s.replace(old,new).replace('One scoped Anthropic Claude Sonnet 5.5 Prism review is planned for\nthis completed SDK documentation checkpoint.','One fresh Anthropic Claude Sonnet 5.5 Prism review covers all four changed\ndocumentation files in one complete chunk (14,898 reviewed bytes). The raw CLI\nexit is 1: one retained medium finding, zero discarded and zero suppressed.\nFinding `c73d91c9d96bc163` requests a clearer module/main reconciliation; the table\nnow states module counts and 26 default + 1 tagged = 27 executable coverage\nexplicitly. Independent internal review closes this documentation finding; no\nimplementation change, repeated compilation or provider rerun is required.');p.write_text(s)
print('Clarified 13 modules/26 default+1 tagged mains and retained actual Prism counts')
