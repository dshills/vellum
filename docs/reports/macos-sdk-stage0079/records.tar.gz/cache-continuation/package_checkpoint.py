from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-sdk-stage0079-abe67c6';T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-sdk-stage0079';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((W/'post-proof.json').read_text());assert proof['passed_owned_commands']==71 and proof['default_mains']==26 and proof['explicit_tagged_helpers']==1
prism=json.loads((W/'prism.json').read_text());assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1 and len(prism['findings'])==1 and prism['findings'][0]['id']=='c73d91c9d96bc163';assert json.loads((W/'internal-prism-disposition.json').read_text())['addressed'];assert json.loads((W/'internal-results-review.json').read_text())['approved'];assert json.loads((W/'internal-prose-review.json').read_text())['approved']
shared=W/'shared';shared.mkdir()
for src,name in [(W.parent/'macos-sdk-native-238b3b6/run.py','owned-executor.py'),(W.parent/'macos-gpu-sdk-stage0077/grouped_cli.py','grouped_cli.py'),(Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),'live_lease.py')]:
 shutil.copyfile(src,shared/name)
sdk=Path(json.loads((W/'consume-plan.json').read_text())['sdk'])
for name,target in [('SDK_MANIFEST.json','sdk-manifest.json'),('THIRD_PARTY_INVENTORY.json','sdk-notice-inventory.json')]:shutil.copyfile(sdk/name,W/target)
checks={'source_commit':proof['source_commit'],'scope':'Private headless SDKpackage/relocation,minGo26default+1taggedmaincompile/metadata,28fontbyte/name/declarationmapping','runtime_app_launched':False,'closed_mac_gates':[],'owned_passed_commands':71,'default_mains':26,'explicit_tagged_helpers':1,'prism_calls':1,'prism_raw_exit_code':1,'prism_retained_medium':1,'prism_addressed':['c73d91c9d96bc163'],'prism_discarded':0,'prism_suppressed':0,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for prefix,root in [('first-attempt',OLD),('cache-continuation',W)]:
 for leaf in sorted(root.rglob('*')):
  assert not leaf.is_symlink(),leaf
  if not leaf.is_file()or '__pycache__'in leaf.parts or 'deliverables'in leaf.relative_to(root).parts or leaf.name.startswith('stop-'):continue
  size=leaf.stat().st_size;assert size<8<<20,(leaf,size);name=prefix+'/'+leaf.relative_to(root).as_posix();files[name]={'bytes':size,'sha256':sha(leaf)};sources[name]=leaf
assert len(files)<500 and sum(x['bytes']for x in files.values())<50<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<10<<20;record={'archive':archive.name,'archive_sha256':sha(archive),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
