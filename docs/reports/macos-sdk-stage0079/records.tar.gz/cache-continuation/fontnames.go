package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	ot "github.com/go-text/typesetting/font/opentype"
	"github.com/go-text/typesetting/font/opentype/tables"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

type input struct {
	File  string `json:"file"`
	SHA   string `json:"sha256"`
	Bytes int64  `json:"bytes"`
}
type face struct {
	Index int               `json:"index"`
	Names map[string]string `json:"names,omitempty"`
	Error string            `json:"error,omitempty"`
}
type row struct {
	File  string `json:"file"`
	SHA   string `json:"sha256"`
	Faces []face `json:"faces,omitempty"`
	Error string `json:"error,omitempty"`
}

func main() {
	if len(os.Args) != 3 {
		panic("SDK root and pinned index required")
	}
	root, err := filepath.Abs(os.Args[1])
	if err != nil {
		panic(err)
	}
	raw, err := os.ReadFile(os.Args[2])
	if err != nil || len(raw) > 1<<20 {
		panic("bounded index")
	}
	var entries []input
	if json.Unmarshal(raw, &entries) != nil || len(entries) != 28 {
		panic("28 admitted SDK fonts")
	}
	out := struct {
		GoVersion string `json:"go_version"`
		Rows      []row  `json:"rows"`
	}{GoVersion: runtime.Version()}
	for _, in := range entries {
		if in.File == "" || filepath.IsAbs(in.File) || strings.Contains(in.File, "..") || in.Bytes < 1 || in.Bytes > 16<<20 {
			panic("admitted relative font path/size")
		}
		path := filepath.Join(root, filepath.FromSlash(in.File))
		st, err := os.Lstat(path)
		if err != nil || !st.Mode().IsRegular() || st.Size() != in.Bytes {
			panic("regular pinned font")
		}
		data, err := os.ReadFile(path)
		if err != nil {
			panic(err)
		}
		sum := sha256.Sum256(data)
		if hex.EncodeToString(sum[:]) != in.SHA {
			panic("font identity drift")
		}
		r := row{File: in.File, SHA: in.SHA}
		loaders, err := ot.NewLoaders(bytes.NewReader(data))
		if err != nil {
			r.Error = err.Error()
		} else {
			if len(loaders) > 64 {
				panic("bounded faces")
			}
			for i, loader := range loaders {
				f := face{Index: i, Names: map[string]string{}}
				table, err := loader.RawTable(ot.MustNewTag("name"))
				if err != nil {
					f.Error = err.Error()
				} else {
					names, _, err := tables.ParseName(table)
					if err != nil {
						f.Error = err.Error()
					} else {
						for _, id := range []tables.NameID{0, 1, 2, 3, 4, 5, 6, 13, 14, 16, 17} {
							f.Names[fmt.Sprint(id)] = names.Name(id)
						}
					}
				}
				r.Faces = append(r.Faces, f)
			}
		}
		out.Rows = append(out.Rows, r)
	}
	if err := json.NewEncoder(os.Stdout).Encode(out); err != nil {
		panic(err)
	}
}
