"""Retained relocated SDK: compile every SDK example/driver main. No launches."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,signal,sys
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('stage79_packaging',W/'run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sys.path.insert(0,str(h.T/'scripts'));s=importlib.util.spec_from_file_location('stage79_checker',h.T/'scripts/check-sdk.py');checker=importlib.util.module_from_spec(s);s.loader.exec_module(checker)
P=h.P;SDKBASE=P/'retained SDK';PLAN=W/'consume-plan.json'
def prepare():
 h.need(not PLAN.exists()and not SDKBASE.exists(),'fresh retained consumer');r=json.loads((W/'result.json').read_text());h.need(r['result']=='PASS_PRIVATE_SDK_PACKAGE_RELOCATION'and r['error']is None,'terminal SDK prerequisite');p=json.loads((W/'plan.json').read_text());h.need(all(h.sha(k)==v for k,v in p['pins'].items())and h.source(h.C)==h.source(h.T)==p['source'],'unchanged producer/source');archive=Path(r['archive']['path']);v=checker.verify_archive(archive,r['archive']['sha256']);sdk=checker.extract_verified(archive,SDKBASE,v);m=v['manifest'];h.need(m['source']=={'commit':h.HEAD,'clean':True},'clean expected SDK');modules=['drivers/cogent']+sorted(str(Path(n).parent)for n in m['files']if n.startswith('examples/')and n.endswith('/go.mod'));h.need(len(modules)==13 and len(set(modules))==13,'13 explicit example/driver modules');pins={str(Path(__file__)):h.sha(__file__),str(W/'result.json'):h.sha(W/'result.json'),**p['pins']};plan={'sdk':str(sdk),'archive':r['archive'],'source_commit':h.HEAD,'pins':pins,'modules':modules,'manifest_sha256':h.sha(sdk/'SDK_MANIFEST.json'),'scope':'13SDK example/driver modules: list actual mains, compile all discovered mains and independently inspect each main GoVersion; no-main modules record zero output (public contract race/vet checked separately). Retain every SDK file/hash unchanged and require replacements within SDK. No native applications or tests launched. No allworkflow/performance/memory/rights qualification.'};PLAN.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(PLAN),'modules':len(modules),'sdk_files':len(m['files']),'sdk':str(sdk)}))
def run():
 h.need(not(W/'consume-result.json').exists()and not(W/'stop-consume').exists(),'fresh consume run');p=json.loads(PLAN.read_text());a=json.loads((W/'consume-admission.json').read_text());h.need(a['approved']and a['plan_sha256']==h.sha(PLAN),'exact consume plan approval');sdk=Path(p['sdk']);manifest=json.loads((sdk/'SDK_MANIFEST.json').read_text());d={'result':'INCOMPLETE','source_commit':h.HEAD,'modules':{},'commands':{},'runtime_executed':False,'error':None,'closed_mac_gates':[]};log=W/'consume';log.mkdir();binary_root=P/'all-main-bin';binary_root.mkdir();expected=dict(manifest['files']);expected['SDK_MANIFEST.json']=p['manifest_sha256']
 def stable():
  if not all(h.sha(k)==v for k,v in p['pins'].items())or h.sha(p['archive']['path'])!=p['archive']['sha256']:return False
  files={leaf.relative_to(sdk).as_posix():h.sha(leaf)for leaf in sdk.rglob('*')if leaf.is_file()and not leaf.is_symlink()};return files==expected and not any(leaf.is_symlink()for leaf in sdk.rglob('*'))
 def command(name,args,cwd,timeout=600):
  env={'PATH':str(h.GO.parent)+':'+str(h.PY.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','LANG':os.environ.get('LANG','en_US.UTF-8')};argv=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*args];r=h.g.execute(argv,cwd,log/name,lambda:(W/'stop-consume').exists(),stable,timeout=timeout,limit=8<<20);d['commands'][name]=r;h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned command '+name);return(log/name/'stdout').read_text()
 def interrupt(signum,frame):raise InterruptedError('consume controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupt)
 try:
  for i,module in enumerate(p['modules']):
   h.need(stable(),'SDK pins before module');cwd=sdk/module;prefix=str(i);graph=checker.decode_objects(command(prefix+'-modules',[str(h.GO),'list','-m','-json','all'],cwd));replacements={}
   for m in graph:
    if m.get('Replace',{}).get('Dir'):
     path=Path(m['Replace']['Dir']).resolve();h.need(path.is_relative_to(sdk),'all replacements within SDK');replacements[m['Path']]=path.relative_to(sdk).as_posix()
   h.need(replacements.get('github.com/dshills/vellum')=='.','selected SDK public root');native={'cogentcore.org/core':'drivers/cogent/build/upstream','github.com/go-text/typesetting':'drivers/cogent/build/typesetting','github.com/oliverbestmann/webgpu/libs-darwin':'drivers/cogent/build/libs-darwin'}
   if any(x['Path']in native for x in graph):h.need(all(replacements.get(k)==v for k,v in native.items()),'selected complete SDK native modules')
   packages=checker.decode_objects(command(prefix+'-list',[str(h.GO),'list','-json','./...'],cwd));mains=[x for x in packages if x.get('Name')=='main'];names=[x['ImportPath'].split('/')[-1]for x in mains];h.need(len(names)==len(set(names)),'unique binary names');out=binary_root/prefix;out.mkdir()
   if mains:command(prefix+'-build',[str(h.GO),'build','-o',str(out)+'/', './...'],cwd,900)
   outputs=sorted(x.name for x in out.iterdir());h.need(outputs==sorted(names),'exact main binary set');records=[]
   for j,x in enumerate(mains):
    binary=out/x['ImportPath'].split('/')[-1];info=json.loads(command(prefix+'-metadata-'+str(j),[str(h.GO),'version','-m','-json',str(binary)],cwd,30));h.need(info['GoVersion']=='go1.25.6'and info['Path']==x['ImportPath'],'actual main compiler/path');records.append({'import':x['ImportPath'],'path':str(binary),'bytes':binary.stat().st_size,'sha256':h.sha(binary),'go_version':info['GoVersion']})
   d['modules'][module]={'main_count':len(records),'binaries':records,'replacements':replacements};print(json.dumps({'module':module,'mains':len(records),'result':'PASS'}),flush=True)
  h.need(stable(),'final SDK integrity');d.update(result='PASS_ALL_LISTED_SDK_MAIN_BUILDS',sdk_files=len(expected)-1,source_prepared_unchanged=h.source(h.C)==h.source(h.T)==json.loads((W/'plan.json').read_text())['source'],main_count=sum(v['main_count']for v in d['modules'].values()));h.need(d['source_prepared_unchanged'],'final source identity')
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:signal.signal(signal.SIGTERM,old);(W/'stop-consume').touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'consume-result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in['result','error','main_count']}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':h.need(sys.argv[1:]in[['prepare'],['run']],'fixed consume phase');prepare()if sys.argv[1]=='prepare'else run()
