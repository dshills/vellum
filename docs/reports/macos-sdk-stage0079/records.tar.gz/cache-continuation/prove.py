from pathlib import Path
import datetime,importlib.util,json
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('sdk_final_proof',W/'run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
p=json.loads((W/'plan.json').read_text());c=json.loads((W/'consume-v2-result.json').read_text());f=json.loads((W/'font-result.json').read_text());r=json.loads((W/'result.json').read_text());assert c['result']=='PASS_ALL_LISTED_SDK_MAIN_BUILDS'and f['result']=='PASS_SCOPED_FONT_BYTE_METADATA_MAPPING'and r['result']=='PASS_PRIVATE_SDK_PACKAGE_RELOCATION';assert h.source(h.C)==h.source(h.T)==p['source'];sdk=Path(json.loads((W/'consume-plan.json').read_text())['sdk']);m=json.loads((sdk/'SDK_MANIFEST.json').read_text());assert h.sha(r['archive']['path'])==r['archive']['sha256'];actual={x.relative_to(sdk).as_posix():h.sha(x)for x in sdk.rglob('*')if x.is_file()};expected={**m['files'],'SDK_MANIFEST.json':h.sha(sdk/'SDK_MANIFEST.json')};assert actual==expected
matching=[];overlays=[]
for name,digest in m['files'].items():
 source=h.T/name
 if source.is_file():
  observed=h.sha(source)
  if observed==digest:matching.append(name)
  else:
   info=m['native_gpu']['go_mod_overlays'].get(name);assert info and info['source_sha256']==observed and info['archived_sha256']==digest,(name,observed,digest);overlays.append(name)
assert m['files']['scripts/child_process.py']==p['source']['tracked']['scripts/child_process.py'];assert m['files']['drivers/cogent/native/dependencies.json']==p['source']['tracked']['drivers/cogent/native/dependencies.json']
allcommands=[]
for filename in ['result.json','consume-result.json','consume-v2-result.json','font-result.json']:
 d=json.loads((W/filename).read_text())
 for name,x in d['commands'].items():
  assert x['exit_code']==0 and x['error']is None and x['logs_complete']and x['pins_stable']and x['owned']['group_absent']and not x['owned']['errors'];allcommands.append({'receipt':filename,'command':name,'group':x['group'],'group_absent':True})
for module in c['modules'].values():
 for binary in module['binaries']:assert h.sha(binary['path'])==binary['sha256']and binary['go_version']=='go1.25.6'
assert h.sha(c['tagged_helper']['path'])==c['tagged_helper']['sha256']
out={'source_commit':h.HEAD,'canonical_clean':True,'candidate_clean':True,'source_prepared_equal_plan':True,'prepared_files':6260,'sdk_files':len(m['files']),'all_sdk_payload_hashes_match':True,'archive':r['archive'],'source_counterparts_equal':len(matching),'declared_go_mod_overlays':len(overlays),'go_mod_overlay_files':overlays,'m1_child_helper_exact':True,'default_mains':c['main_count'],'explicit_tagged_helpers':1,'compiler':'go1.25.6','passed_owned_commands':len(allcommands),'groups':allcommands,'font_files':28,'distinct_font_hashes':28,'darwin_default_font_embeds':12,'other_payload_fonts':16,'runtime_app_launched':False,'closed_mac_gates':[],'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'post-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['groups','go_mod_overlay_files']},indent=2))
