from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/private/tmp/vellum-breadcrumb-controls')
P = Path('/private/tmp/vellum-macos-breadcrumb-controls')

def sha(f):
    return hashlib.sha256(Path(f).read_bytes()).hexdigest()

def read(n):
    return json.loads((P / n).read_text())

base = read('base.json')['commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == base
names = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=R).decode().splitlines()) | set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=R).decode().splitlines())
sources = {n: sha(R / n) for n in sorted(names) if (R / n).is_file()}
assert len(sources) == 11
prepared = {f.relative_to(R / 'drivers/cogent/build').as_posix(): sha(f) for m in ['upstream', 'typesetting'] for f in sorted((R / 'drivers/cogent/build' / m).rglob('*')) if f.is_file()}
assert len(prepared) == 6214 and prepared == read('prepared-baseline.json')
report = 'docs/reports/macos-breadcrumb-controls/README.md'
checks = {}
for name in ['final-portable-race', 'final-portable-vet', 'final-adapter-race', 'final-adapter-vet', 'final-sdk', 'final-native-build']:
    d = read(name + '.json')
    assert d['exit_code'] == 0 and d['error'] is None and d['source_delta_stable']
    assert d['source_commit'] == base and d['prepared_before'] == d['prepared_after'] == prepared
    assert d['producer_sha256'] == sha(P / 'code_run.py')
    assert d['source_delta_before'] == d['source_delta_after'] == sources
    assert d['overlay_inputs_before'] == d['overlay_inputs_after'] == {}
    for channel in ['stdout', 'stderr']:
        assert d[channel + '_sha256'] == sha(P / (name + '.' + channel))
    checks[name] = {'receipt_sha256': sha(P / (name + '.json')), 'argv': d['argv'], 'elapsed_seconds': d['elapsed_seconds']}
assert 'Ran 28 tests' in (P / 'final-sdk.stderr').read_text() and '\nOK' in (P / 'final-sdk.stderr').read_text()
faults = {}
for name, needle in [('negative-count', '65 valid locations admitted'), ('negative-native-path-v2', 'queued old path navigated replacement')]:
    d = read(name + '.json')
    assert d['exit_code'] == 1 and d['error'] is None and d['source_delta_stable']
    assert d['source_commit'] == base and d['prepared_before'] == d['prepared_after'] == prepared
    assert d['overlay_inputs_before'] == d['overlay_inputs_after']
    assert all(d['source_delta_before'][n] == h for n, h in sources.items() if n != report)
    for channel in ['stdout', 'stderr']:
        assert d[channel + '_sha256'] == sha(P / (name + '.' + channel))
    assert needle in (P / (name + '.stdout')).read_text()
    assert '[build failed]' not in (P / (name + '.stdout')).read_text()
    faults[name] = {'receipt_sha256': sha(P / (name + '.json')), 'detected_assertion': needle}
review = read('candidate-review.json')
assert review['result'] == 'APPROVED_SOURCE' and not review['unresolved_findings']
exe = P / 'gallery'
assert exe.is_file()
binary = {'path': str(exe), 'sha256': sha(exe), 'bytes': exe.stat().st_size, 'build_receipt_sha256': sha(P / 'final-native-build.json'), 'launched': False}
(P / 'native-binary.json').write_text(json.dumps(binary, indent=2) + '\n')
before_report = sources[report]
f = R / report
t = f.read_text()
old = 'Final portable/adapter race and vet, SDK exporter regressions and native Gallery\nbuild must pass before commit, followed by internal review and one bounded Prism\nreview using Anthropic Claude Sonnet 5.5. The qualification record binds exact\nfinal source and gate receipts.'
new = 'Final portable/adapter race and vet, all 28 SDK exporter regressions and native\nGallery build pass. Internal final review and one bounded Prism review using\nAnthropic Claude Sonnet 5.5 precede commit. The qualification record binds exact\nfinal source and six gate receipts. This report was updated after the checks;\nall executable source and test bytes remained unchanged.'
assert old in t
f.write_text(t.replace(old, new))
sources[report] = sha(f)
manifest = {'base_commit': base, 'sources': sources}
(P / 'checkpoint-source.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = {**manifest, 'result': 'PASS_SCOPED_BREADCRUMB_COMPONENT', 'checks': checks, 'faults': faults, 'prepared_files': 6214, 'prepared_changed': False, 'sdk_tests': 28, 'software_dpi': [96, 120, 144, 192], 'inert_native_roles_and_owner_guard': True, 'window_created_by_native_fixture': False, 'native_binary': binary, 'report_before_code_checks_sha256': before_report, 'report_updated_after_checks': True, 'concurrent_endurance_scope': 'Separate frozen e7f8e30 process, not breadcrumb qualification. Code checks ran while it was active; no latency claim.', 'live_breadcrumb_sequence_qualified': False, 'physical_input_qualified': False, 'human_voiceover_qualified': False, 'frame_performance_qualified': False, 'full_p6_qualified': False, 'full_p11_qualified': False, 'mac_distribution_qualified': False}
(P / 'final-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS 11 sources/six gates/two actual faults/6214 unchanged; native Gallery built not launched')
