from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-breadcrumb-controls');P=Path('/private/tmp/vellum-macos-breadcrumb-controls');D=R/'docs/reports/macos-breadcrumb-controls/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==1 and process['error']is None and process['source_index_stable']
assert review['coverage']['complete'] and review['coverage']['files']==11 and len(review['findings'])==1 and review['findings'][0]['id']=='4365374625626cda';assert review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
sources=json.loads((P/'corrected-checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==json.loads((P/'prism-reviewed-source.json').read_text())['sources']
summary=json.loads((P/'final-corrected-summary.json').read_text());assert summary['result']=='PASS_SCOPED_BREADCRUMB_COMPONENT' and summary['sources']==sources
correction=json.loads((P/'correction-review.json').read_text());assert correction['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not correction['unresolved_findings'] and correction['sources']==sources
assert process['before']==process['after']==internal['sources']
changes=json.loads((P/'prism-correction.json').read_text())['changes'];assert set(changes)=={'drivers/cogent/breadcrumb_darwin_test.go'}
for n,h in sources.items():
 old=internal['sources'][n];assert sha(P/'prism-v1/source'/n)==old
 if n in changes:assert changes[n]=={'before':old,'after':h}
 else:assert old==h

inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.cpu','.png'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['breadcrumb_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Public controlled Breadcrumb over ordinary managed Toolbar/quietButtons/passivecurrentLabel/decorativeicons. Bounded64path, stableencodedIDs, latestowner/path/disabledqueuedguard, readonly, GalleryandrelocatedSDK. ActualfourDPI softwareinput/identity/frames, narrowHomeEndoverflow, inertCocoaroles/samesizequeuedreorder, two detectedguardfaults; six finalcode/buildgates,6214pinnedleavesunchanged. Reportupdatedafterchecks with unchangedexecutable/testbytes. Initialfixture/compilefailures and consumedfaultsourceversions retained. NativeGallery builtNOTlaunched; separatee7endurance cannot qualifythis component. No live/human/physicalinput/performance/nativeGPUbudgets/fullP6/P11/distribution claim.'},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':11,'prism_findings':1,'prism_unresolved_findings':0,'prism_raw_exit_code':1,'prism_disposition':'FIXED_TEST_CLEANUP','internal_correction_review_sha256':sha(P/'correction-review.json'),'prism_calls':review['coverage']['llmCalls'],'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','prism_files','prism_findings','prism_unresolved_findings','prism_disposition','archive_sha256','archive_members','archive_bytes']}))
