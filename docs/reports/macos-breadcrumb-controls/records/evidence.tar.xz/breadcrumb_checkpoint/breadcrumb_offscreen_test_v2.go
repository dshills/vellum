//go:build offscreen

package cogent

import (
	"bytes"
	"fmt"
	"html"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/ui"
)

func TestBreadcrumbManagedInputIdentityAndFrames(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 192} {
		t.Run(fmt.Sprintf("dpi%.0f", dpi), func(t *testing.T) {
			b := &ui.Breadcrumb{ID: "path", Label: "Project location", Items: []ui.BreadcrumbItem{{ID: "home", Label: "Home"}, {ID: "folder/a", Label: "<b>A & B</b>"}, {ID: "current", Label: "Current"}}}
			calls := 0
			reject := true
			b.Navigate = func(e ui.BreadcrumbEvent) {
				calls++
				if !reject {
					for i, item := range b.Items {
						if item.ID == e.ItemID {
							b.Items = append([]ui.BreadcrumbItem(nil), b.Items[:i+1]...)
							break
						}
					}
				}
			}
			id := ui.BreadcrumbItemID(b.ID, "folder/a")
			view := func() ui.Node {
				n, err := b.View()
				if err != nil {
					panic(err)
				}
				return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Focus: ui.FocusRequest{ID: id, Sequence: 1}, Style: ui.Style{Padding: ui.Some(ui.UniformInsets(12))}, Children: []ui.Node{n}}
			}
			config := manualConfig(t, 7)
			config.LogicalDPI = dpi
			m, a := simpleManual(t, config, view)
			unitSettle(t, m)
			before, item := imageManualElement(t, m, id)
			_, current := imageManualElement(t, m, ui.BreadcrumbItemID(b.ID, "current"))
			if before.FocusedID != id || item.Bounds.Empty() || current.Bounds.Empty() || current.Kind != ui.Label {
				t.Fatal("path geometry/focus", before.FocusedID, item, current)
			}
			widget := findRecord(m.implementation.find("one").state.root, id).widget.(*core.Button)
			if widget.Text != html.EscapeString(b.Items[1].Label) {
				t.Fatal("markup interpreted", widget.Text)
			}
			frame, err := m.Capture(testContext, "one")
			if err != nil {
				t.Fatal(err)
			}
			if err = m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: before.Incarnation, Type: events.KeyChord, Code: key.CodeReturnEnter}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			_, same := imageManualElement(t, m, id)
			if calls != 1 || len(b.Items) != 3 || same.Incarnation != item.Incarnation {
				t.Fatal("rejected navigation changed identity/path", calls, b.Items, same)
			}
			reject = false
			for _, typ := range []events.Types{events.MouseDown, events.MouseUp} {
				if err = m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: before.Incarnation, Target: id, TargetIncarnation: same.Incarnation, Type: typ, Button: events.Left}); err != nil {
					t.Fatal(err)
				}
			}
			unitSettle(t, m)
			_, now := imageManualElement(t, m, id)
			if calls != 2 || len(b.Items) != 2 || now.Kind != ui.Label || now.Incarnation == same.Incarnation {
				t.Fatal("accepted location not passive/current", calls, b.Items, now)
			}
			updated, err := m.Capture(testContext, "one")
			if err != nil || bytes.Equal(frame.Pix, updated.Pix) {
				t.Fatal("accepted navigation did not change completed frame", err)
			}
			if err = m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: before.Incarnation, Target: id, TargetIncarnation: same.Incarnation, Type: events.MouseDown, Button: events.Left}); err == nil {
				t.Fatal("retired button identity admitted")
			}
			if err = a.Do(func() { b.Navigate = nil; _ = a.Invalidate("one") }); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			snap, err := m.Snapshot(testContext)
			if err != nil {
				t.Fatal(err)
			}
			for _, e := range snap.Windows[0].Elements {
				if e.Kind == ui.Button {
					t.Fatal("readonly path has managed button", e)
				}
			}
		})
	}
}
