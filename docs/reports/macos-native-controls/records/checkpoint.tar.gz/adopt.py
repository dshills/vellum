from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=60,capture_output=True,check=True).stdout
base=json.loads((W/'scope.json').read_text())['base'];r=json.loads((W/'native-v4/result.json').read_text());assert r['result']=='FAILED_OR_CANCELED'and r['run']['exit_code']==1 and r['run']['logs_complete']and r['run']['pins_stable']and r['run']['owned']['group_absent']and not r['run']['owned']['errors']
plan=json.loads((W/'native-v4/plan.json').read_text());assert all(sha(p)==z for p,z in plan['pins'].items())
assert all(git(x,'rev-parse','HEAD').decode().strip()==base and not git(x,'status','--porcelain')for x in[C,T])
sdk=Path(plan['sdk']);actual_sdk={p.relative_to(sdk).as_posix():sha(p)for p in sdk.rglob('*')if p.is_file()};assert actual_sdk==plan['sdk_files']
raw=json.loads((W/'native-v4/case/stdout').read_text());assert len(raw['Steps'])==11 and len(raw['Inputs'])==24 and raw['Error']=='rejected-step target not actually focused'and raw['Session']['Closed']and not raw['Session']['Pending']and raw['Session']['LiveWindows']==0
(W/'native-final-boundary.json').write_text(json.dumps({'sdk_unchanged':True,'sdk_files':len(actual_sdk),'canonical_candidate_clean':True,'native_executed':True,'native_result':'FAILED','prefix_source_assertions_only':{'observations':11,'inputs':24},'error':raw['Error'],'closed_mac_gates':[]},indent=2)+'\n')

paths=json.loads((W/'adoption-notes.json').read_text())['source_go_paths']
for n in paths:
 p=W/'candidate'/n;q=T/n
 assert not q.exists()or q.read_bytes()==(C/n).read_bytes();q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for p in(W/'install').rglob('*'):
 if p.is_file():
  q=T/p.relative_to(W/'install');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
p=T/'drivers/cogent/native/patches/popupinspection/README.md';p.write_text('''# Bounded actual popup inspection (stage83)

`Scene.InspectPopups` requires the caller's existing render ownership. It takes
at most64 current popup stage pointers under the stack lock, releases that lock,
and copies completed clipped scene/button bounds. Only the top event-accepting
popup's visible, enabled direct standard buttons are offered as targets.
Background-main, pending/unshown/layout/render, invalid budget and exhausted ID
states refuse safely. Custom/nested menus keep their existing inspectors.

Each real scene/button receives an opaque monotonic incarnation ID in its own
metadata. Owner checks reject copied metadata; saturation refuses rather than
wrapping. There is no historical widget registry. A detached label clones only
its admitted bytes, so a small substring cannot retain a large backing string.
Every visited record is charged before inspection and each label is capped.
The public DesktopSession separately charges generated output identifiers and
fixed records against its remaining shared semantic budget.

Core regressions use real Chooser popup scenes and the software FIFO: transformed
window bounds, visibility, actual click, exactly-once change, fresh reincarnation,
modal/tooltip precedence, budgets, pending geometry, metadata copies, saturation
and independent bounded label backing. Driver tests add same-frame stale-popup
refusal and shared public-output budget controls. Software evidence is distinct
from native execution and physical input. See the native-controls report.
''')
p=T/'drivers/cogent/native/README.md';p.write_text(p.read_text()+'''\nStage83 (`patches/popupinspection`) exposes owner-held bounded detached current
popup geometry and fresh scene/button incarnation IDs. Public DesktopSession
keeps these separate from persistent option semantics, refuses stale/hidden/
disabled targets and charges generated labels/IDs against its shared budget.
See [contract](patches/popupinspection/README.md) and the
[native controls report](../../../docs/reports/macos-native-controls/README.md).
''')
p=T/'specs/desktop-integration.md';p.write_text(p.read_text()+'''\n## Actual popup inspection

`DesktopSnapshot.Popups` describes actual completed current popup scenes in the
active main stage, separately from persistent semantic option nodes. Only the
top event-accepting popup's visible enabled direct standard buttons are targeted.
Bounds are scene-pixel rectangles clipped to the popup/window; the popup origin
is applied exactly once. Returned labels own their admitted bytes.

Popup/item IDs include the completed frame and actual scene/button incarnation.
A closed/reopened or replaced popup cannot reuse authority even if the frame
number is unchanged. Targeted keys still require current actual focus. Popup
inspection shares the8192 semantic-record/8MiB output budget with generated
identifiers and fixed records charged; at most64 popup stages are visited.
Pending/unshown/dirty geometry and exhausted budgets refuse without partial data.
No historical widget registry is retained. Custom/nested menus retain existing
inspectors. Ordinary app routing without a DesktopSession stays unchanged.
''')
p=T/'docs/desktop-integration.md';p.write_text(p.read_text()+'''\nFor actual menus, inspect `snapshot.Popups`, then use the current item's exact
`ID` and center of its clipped `Bounds`. Persistent option semantics in
`Elements` describe model choices and are separate from the open popup's actual
item geometry. Only enabled items of the top interactive popup are targets.
Reacquire a frame/snapshot after each input, including menu navigation. Closed or
replaced popup/button identities cannot be reused, including in the same frame.
Custom/nested menus retain their existing inspectors.

The standard gallery has a runnable bounded integration mode:

```sh
cd drivers/cogent
go run ./cmd/gallery -control-native-check
```

It uses the ordinary public Selector/NumberField constructors and emits one JSON
result after its49-input/21-observation scenario and tracked shutdown. See the
[gallery instructions](../drivers/cogent/cmd/gallery/README.md) and
[current result](reports/macos-native-controls/README.md). This command routes
Go events through the native FIFO; physical/OS input remains separate evidence.
''')
(T/'drivers/cogent/cmd/gallery/README.md').write_text((W/'gallery-readme-draft.md').read_text())
D=T/'docs/reports/macos-native-controls';D.mkdir(parents=True,exist_ok=True)
(D/'README.md').write_text((W/'final-report-draft.md').read_text())
records=D/'records';records.mkdir()
def receipt(name):
 z=json.loads((W/(name+'.json')).read_text());return {k:z.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned','prepared_exact','prepared_files','prepared_sha256']}
summary={'base':base,'native_result':'FAILED','native_failures':{n:json.loads((W/n/'result.json').read_text())for n in ['native-v1','native-v2','native-v3','native-v4']},'final_source_asserted_prefix':{'observations':11,'inputs':24,'numeric_value':42,'numeric_proposals':1},'checks':{n:receipt(n)for n in ['driver-all-v5','owned-core-v2','core-vet-v2','consumer-vet-v5','catalogue-build-v6','gallery-tests-final','prepare-v3','prepare-tests-v3','validation-controls-v1','wake-negative-v1','wake-positive-v1','selector-focus-negative-v1','selector-focus-positive-v1','select-all-negative-v1']},'full_native_validation_passed':False,'physical_input_verified':False,'sdk_refreshed':False,'full_mac_complete':False,'closed_mac_gates':[]}
(records/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraph="""\nThe [popup and Selector integration checkpoint](../docs/reports/macos-native-controls/README.md)
adds stage83 bounded actual-menu inspection, repairs owner wakes starved by modal
menus, and restores actual Selector click focus before its menu opens. Final
Core/driver/gallery race, vet, build and preparation checks pass. Four native
attempts remain failed and sealed: the final source-asserted prefix reaches ten
Selector observations plus one accepted numeric edit (24 inputs/11 observations),
then refuses the next key because Enter cleared numeric focus. No complete native
catalogue, M2/M5 or other Mac gate closes. Next determine the intended numeric
post-commit focus behavior and complete the remaining unchanged domain checks;
physical/OS input, human accessibility and M3–M7 remain open. No SDK refresh or
OS settings change occurs.\n"""
for n in ['specs/macos-delivery.md','specs/macos-completion.md']:
 p=T/n;s=p.read_text().replace('ordinary Selector/NumberField native checks are next.','ordinary Selector/NumberField checks follow in the checkpoint below.');pos=s.index('\n## ',s.index('popup lifecycle prerequisite'));p.write_text(s[:pos]+paragraph+s[pos:])
p=T/'specs/control-acceptance.md';s=p.read_text();s=s.replace('The remaining native catalogue work is:',"""The [popup/Selector integration checkpoint](../docs/reports/macos-native-controls/README.md)
repairs owner wake starvation and actual Selector click focus. Its final native
attempt reaches the source-asserted Selector states and one accepted typed
number, then fails the next focused-key guard after numeric Enter. All four
native attempts remain failed/sealed; no full native subcase closes. The check's
intended 49 inputs/21 observations remain unchanged, with 24/11 actually reached.

The remaining native catalogue work is:""")
s=s.replace('1. In the gallery, exercise ordinary Selector popup and NumberField typed,','1. Resolve numeric post-commit focus semantics in the gallery, then complete\n   ordinary Selector popup and NumberField typed,');p.write_text(s)
status="""\nCurrent result: the last admitted native check is failed, after 24 routed inputs
and 11 observations, because numeric Enter clears focus before the next step.
The command reports this guard failure with a nonzero exit. The complete planned
49-input/21-observation record, numeric rejection/disabled continuation and final
original-window stale-input assertion remain unqualified. See the current result
report; successful compilation or the passing prefix is not a native pass.\n"""
for n in ['drivers/cogent/cmd/gallery/README.md','docs/desktop-integration.md']:
 p=T/n;p.write_text(p.read_text()+status)
(W/'adopted-paths.txt').write_text(git(T,'status','--porcelain','--untracked-files=all').decode());print('Adopted source fixes, stage83 and explicitly failed native report; canonical unchanged.')
