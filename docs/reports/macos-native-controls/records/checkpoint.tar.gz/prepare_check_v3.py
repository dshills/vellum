"""Validate stage83 through actual cache-backed preparation in a private root."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');R=W/'preparation-v3'
s=importlib.util.spec_from_file_location('workspace_prepare_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
h.need(not R.exists()and not(W/'prepare-v3.json').exists(),'fresh preparation')
R.mkdir();shutil.copy2(C/'drivers/cogent/prepare.py',R/'prepare.py');manifest=json.loads((W/'install/drivers/cogent/native/dependencies.json').read_text())
paths=['native/dependencies.json']
for dep in manifest['dependencies']:
 for stage in dep['stages']:
  paths.append(stage['inputs']);paths.extend(e['file']for e in stage['patches'])
  if 'outputs'in stage:paths.append(stage['outputs'])
for n in paths:
 p=W/'install/drivers/cogent'/n
 if not p.exists():p=C/'drivers/cogent'/n
 target=R/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
pins={str(p):h.sha(p)for p in[R/'prepare.py',Path(__file__),Path(h.__file__),h.GUARD,h.GO,*[R/n for n in paths]]}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOTOOLCHAIN':'local','GOWORK':'off','GOENV':'off','GOFLAGS':'-mod=readonly','GOPROXY':'off','GOSUMDB':'off','PYTHONDONTWRITEBYTECODE':'1'}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/opt/homebrew/bin/python3','-B',str(R/'prepare.py')]
r=h.g.execute(av,R,W/'prepare-v3',lambda:(W/'stop-integration').exists(),lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=300,limit=8<<20);r['source_pins']=pins;r['native_executed']=False
if r['exit_code']==0 and r['error']is None:
 vector={m+'/'+p.relative_to(R/'build'/m).as_posix():h.sha(p)for m in ['upstream','typesetting']for p in(R/'build'/m).rglob('*')if p.is_file()}
 expected={m+'/'+p.relative_to(C/'drivers/cogent/build'/m).as_posix():h.sha(p)for m in ['upstream','typesetting']for p in(C/'drivers/cogent/build'/m).rglob('*')if p.is_file()}
 for n,z in json.loads((W/'stage83-patch.json').read_text())['outputs'].items():expected['upstream/'+n]=z
 r['prepared_files']=len(vector);r['prepared_sha256']=hashlib.sha256(json.dumps(vector,sort_keys=True,separators=(',',':')).encode()).hexdigest();r['prepared_exact']=vector==expected
(W/'prepare-v3.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','prepared_files','prepared_sha256','prepared_exact','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['prepared_exact']and r['owned']['group_absent']and not r['owned']['errors']else 1)
