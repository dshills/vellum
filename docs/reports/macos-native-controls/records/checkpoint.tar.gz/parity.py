from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sdk=Path(json.loads((W/'scope.json').read_text())['sdk']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
mapping=json.loads((W/'candidate/overlay.json').read_text())['Replace'];pairs=[];unused=[]
for original,replacement in mapping.items():
 rel=Path(original).relative_to(sdk)
 if rel.as_posix().startswith('examples/'):
  unused.append(rel.as_posix());continue
 p=T/rel
 assert p.is_file()and p.read_bytes()==Path(replacement).read_bytes(),str(rel)
 pairs.append({'path':rel.as_posix(),'sha256':sha(p)})
actual={m+'/'+p.relative_to(T/'drivers/cogent/build'/m).as_posix():sha(p)for m in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/m).rglob('*')if p.is_file()}
expected={m+'/'+p.relative_to(W/'preparation-v3/build'/m).as_posix():sha(p)for m in ['upstream','typesetting']for p in(W/'preparation-v3/build'/m).rglob('*')if p.is_file()}
assert actual==expected and len(actual)==6267
r={'exact':True,'overlay_go_files':pairs,'unused_inherited_workspace_overlays_not_gallery_inputs':unused,'prepared_files':len(actual),'prepared_sha256':hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'current_consumer_native_qualified':False,'last_failed_native_binary':json.loads((W/'native-v4/plan.json').read_text())['binary'],'default_worktree_library_runtime_verified':False}
(W/'prepared-overlay-parity.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exact':True,'mapped_go_files':len(pairs),'prepared_files':len(actual),'prepared_sha256':r['prepared_sha256']}))
