"""Synthetic parser controls only; never native/composition evidence."""
import copy,json,unittest
import validate_refocus as v

def rect(x,y,w,h):return{'Min':{'X':x,'Y':y},'Max':{'X':x+w,'Y':y+h}}
def fixture_snapshot(frame,model,menu=False):
 selected,number,_,_,_,enabled=model
 els=[]
 for id,bounds,value in [('selection',rect(20,20,100,30),{'basic':'Basic','advanced':'Advanced'}[selected]),('number',rect(20,130,200,40),number),('outside',rect(20,230,150,40),None)]:
  els.append({'ID':v.managed(id),'DomainID':id,'Parent':'','Role':'control','Name':id,'Value':value,'Bounds':bounds,'Enabled':enabled if id!='outside'else True,'Focused':False,'Selected':False})
 s={'Frame':frame,'Size':{'X':640,'Y':480},'LogicalDPI':160,'Elements':els,'Popups':[]}
 if menu:
  pid='popup:'+str(frame)+':1'
  s['Popups']=[{'ID':pid,'Kind':'MenuStage','Interactive':True,'Bounds':rect(20,50,140,60),'Items':[{'ID':pid+':'+str(i+2),'Parent':pid,'DomainID':'','Name':name,'Role':'popup-item','Bounds':rect(20,50+30*i,140,30),'Enabled':True,'Focused':False,'Selected':name=={'basic':'Basic','advanced':'Advanced'}[selected]}for i,name in enumerate(['Basic','Advanced'])]}]
 return s

def fixture():
 d={'Event':'vellum.controls-native.result','Result':'PASS_NATIVE_CONTROLS','Error':'','Steps':[],'Inputs':[],'OriginalRefClosed':True,'PostCloseInputError':'closed','Session':{'Started':True,'Closed':True,'Pending':False,'LiveWindows':0,'Issued':300}}
 for i,(label,model)in enumerate(zip(v.LABELS,v.VALUES)):
  d['Steps'].append({'Label':label,'Model':dict(zip(v.MODEL_KEYS,model)),'Snapshot':fixture_snapshot(100+i,model,i in[1,3,5,20])})
 menu_keys=['menu-up','menu-reject-enter','escape-menu','accept-menu-up','accept-menu-enter']
 for i,label in enumerate(v.INPUTS):
  popup=label.startswith('choose-advanced/')or label in menu_keys or label.startswith('outside-cancel/')
  rejected=label.startswith('disabled-target-')
  s=fixture_snapshot(i+1,('basic',25,0,0,0,not rejected),popup)
  typ='MouseDown'if label.endswith('/MouseDown')else'MouseUp'if label.endswith('/MouseUp')else'KeyChord'
  if popup and not label.startswith('outside-cancel/'):
   el=s['Popups'][0]['Items'][1];el['Focused']=True
  else:
   id='outside'if label.startswith('outside-')or label=='tab-to-selector'else'number'if any(x in label for x in ['number','step'])else'selection'
   el=next(e for e in s['Elements']if e['DomainID']==id);el['Focused']=True
  target=''if label.startswith('outside-cancel/')or label=='disabled-ordinary-key'else el['ID']
  b=el['Bounds'];pos={'X':(b['Min']['X']+b['Max']['X'])//2,'Y':(b['Min']['Y']+b['Max']['Y'])//2}
  d['Inputs'].append({'Label':label,'Before':s,'Input':{'Frame':s['Frame'],'Target':target,'Type':typ,'Position':pos},'Rejected':rejected})
 return d

class Controls(unittest.TestCase):
 def test_complete_synthetic_parser_fixture(self):self.assertEqual(v.validate(json.dumps(fixture()).encode())['inputs'],57)
 def bad(self,edit):
  d=fixture();edit(d)
  with self.assertRaises((ValueError,KeyError,TypeError)):v.validate(json.dumps(d).encode())
 def test_missing_step(self):self.bad(lambda d:d['Steps'].pop())
 def test_duplicate_proposal(self):self.bad(lambda d:d['Steps'][10]['Model'].update(NumberRequests=2))
 def test_rejected_value_accepted(self):self.bad(lambda d:d['Steps'][11]['Model'].update(Number=43))
 def test_bool_counter(self):self.bad(lambda d:d['Steps'][2]['Model'].update(SelectionRequests=True))
 def test_fake_persistent_popup_option(self):self.bad(lambda d:d['Inputs'][2]['Input'].update(Target=v.managed('selection')))
 def test_stale_frame(self):self.bad(lambda d:d['Inputs'][0]['Input'].update(Frame=0))
 def test_stale_popup_incarnation(self):self.bad(lambda d:d['Inputs'][2]['Input'].update(Target='popup:3:999:2'))
 def test_outside_pointer_bounds(self):self.bad(lambda d:d['Inputs'][0]['Input'].update(Position={'X':639,'Y':479}))
 def test_hidden_disabled_option(self):self.bad(lambda d:d['Steps'][1]['Snapshot']['Popups'][0]['Items'][1].update(Name='Unavailable'))
 def test_disabled_target_admitted(self):self.bad(lambda d:next(i for i in d['Inputs']if i['Label']=='disabled-target-number').update(Rejected=False))
 def test_session_retention(self):self.bad(lambda d:d['Session'].update(LiveWindows=1))
 def test_closed_window_not_refused(self):self.bad(lambda d:d.update(PostCloseInputError=''))
 def test_missing_authored_refocus(self):self.bad(lambda d:d['Inputs'].remove(next(i for i in d['Inputs']if i['Label']=='number-42/refocus/MouseDown')))
 def test_refocus_wrong_control(self):
  def edit(d):
   i=next(i for i in d['Inputs']if i['Label']=='number-42/refocus/MouseDown');el=next(e for e in i['Before']['Elements']if e['DomainID']=='selection');i['Input'].update(Target=el['ID'],Position={'X':30,'Y':25})
  self.bad(edit)
 def test_multiple_results(self):
  raw=json.dumps(fixture()).encode()
  with self.assertRaises(ValueError):v.validate(raw+b'\n'+raw)
 def test_unknown_console_output(self):
  with self.assertRaises(ValueError):v.validate(json.dumps(fixture()).encode(),b'unknown diagnostic\n')

if __name__=='__main__':unittest.main(verbosity=2)
