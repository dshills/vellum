from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('validation_control_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
pins={str(p):h.sha(p)for p in [Path(__file__),W/'validate.py',W/'validation_controls.py',Path(h.__file__),h.GUARD]}
argv=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/opt/homebrew/bin/python3','-B',str(W/'validation_controls.py')]
r=h.g.execute(argv,W,W/'validation-controls-v1',lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=30,limit=1<<20);r['source_pins']=pins;r['synthetic_only']=True;r['native_ui_executed']=False
(W/'validation-controls-v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and not r['error']and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
