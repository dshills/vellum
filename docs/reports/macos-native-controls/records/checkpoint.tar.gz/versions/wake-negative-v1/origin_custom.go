package cogent

import "cogentcore.org/core/events"

// Original session-only wiring, retained for the negative regression run.
func bindWindowOriginCustom(w *nativeWindow, session *DesktopSession, custom func(*nativeWindow, events.Event)) {
	if session == nil {
		return
	}
	w.body.Scene.SetOriginCustomHandler(func(e events.Event) bool {
		if !session.owns(w, e) {
			return false
		}
		custom(w, e)
		return true
	})
}
