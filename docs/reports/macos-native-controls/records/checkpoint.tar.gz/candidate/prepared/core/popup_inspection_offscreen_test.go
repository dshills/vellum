// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
//go:build offscreen

package core

import (
	"errors"
	"image"
	"math"
	"strings"
	"sync/atomic"
	"testing"
	"unsafe"

	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/styles/states"
)

func inspectPopupFixture(t *testing.T) (*ManualWindow, *Body, *Chooser, *int) {
	t.Helper()
	var chooser *Chooser
	calls := new(int)
	m, body, _ := manualFixture(t, func(b *Body) {
		chooser = NewChooser(b).SetStrings("Basic", "Advanced")
		chooser.OnChange(func(events.Event) { *calls++ })
	})
	drainManual(t, m)
	clickManual(t, m, center(chooser))
	return m, body, chooser, calls
}

func TestPopupInspectionInvisibleItemNotTargetable(t *testing.T) {
	m, body, _, _ := inspectPopupFixture(t)
	rc := m.window.renderContext()
	rc.Lock()
	button := body.Scene.Stage.popups.top().Scene.Children[1].(*Button)
	stored := button.Geom.TotalBBox
	button.SetState(true, states.Invisible)
	button.NeedsRender()
	rc.Unlock()
	drainManual(t, m)
	p := inspectPopupOwned(t, m, body.Scene)
	if stored.Empty() || len(p) != 1 || len(p[0].Items) != 2 || p[0].Items[1].Bounds.Empty() || p[0].Items[1].Enabled {
		t.Fatal("invisible item with retained geometry offered as target", p)
	}
}

func inspectPopupOwned(t *testing.T, m *ManualWindow, sc *Scene) []PopupInspection {
	t.Helper()
	rc := m.window.renderContext()
	rc.Lock()
	defer rc.Unlock()
	p, err := sc.InspectPopups(8192, 8<<20)
	if err != nil {
		t.Fatal(err)
	}
	return p
}

func TestPopupInspectionActualChooserGeometryIdentityAndDetachment(t *testing.T) {
	m, body, chooser, calls := inspectPopupFixture(t)
	p := inspectPopupOwned(t, m, body.Scene)
	if len(p) != 1 || len(p[0].Items) != 2 || !p[0].Interactive || p[0].ID == 0 {
		t.Fatalf("actual chooser popup missing: %+v", p)
	}
	first, second := p[0].Items[0], p[0].Items[1]
	if first.Name != "Basic" || second.Name != "Advanced" || first.ID == second.ID || first.ID == 0 || !first.Selected || !first.Enabled || !second.Enabled {
		t.Fatalf("actual menu state %+v", p)
	}
	stage := body.Scene.Stage.popups.top()
	button := stage.Scene.Children[1].(*Button)
	want := button.Geom.TotalBBox.Add(stage.Scene.SceneGeom.Pos).Intersect(p[0].Bounds)
	if second.Bounds != want || second.Bounds.Empty() || !second.Bounds.In(p[0].Bounds) {
		t.Fatalf("window-coordinate bounds %v want %v", second.Bounds, want)
	}
	p[0].Items[1].Name = "mutated"
	p[0].Items[1].Bounds = image.Rectangle{}
	before := inspectPopupOwned(t, m, body.Scene)
	if before[0].Items[1].Name != "Advanced" || before[0].Items[1].Bounds != want || before[0].ID != p[0].ID || before[0].Items[1].ID != second.ID || *calls != 0 {
		t.Fatal("inspection mutated widgets, identities, or invoked a model callback")
	}
	// Route the actual menu item pointer, not the chooser's persistent AX option.
	clickManual(t, m, second.Bounds.Min.Add(second.Bounds.Size().Div(2)))
	if *calls != 1 || chooser.CurrentIndex != 1 || len(inspectPopupOwned(t, m, body.Scene)) != 0 {
		t.Fatal("actual menu pointer did not commit exactly once and retire popup")
	}
	clickManual(t, m, center(chooser))
	after := inspectPopupOwned(t, m, body.Scene)
	if len(after) != 1 || after[0].ID == before[0].ID || after[0].Items[1].ID == second.ID || !after[0].Items[1].Selected {
		t.Fatal("reopening revived an old popup/button identity")
	}
}

func TestPopupInspectionBudgetPendingAndCoveredLayers(t *testing.T) {
	m, body, _, _ := inspectPopupFixture(t)
	rc := m.window.renderContext()
	rc.Lock()
	for _, budget := range [][2]int{{0, 8 << 20}, {1, 8 << 20}, {8192, 0}, {8193, 8 << 20}} {
		p, err := body.Scene.InspectPopups(budget[0], budget[1])
		if !errors.Is(err, ErrPopupInspectionBudget) || p != nil {
			rc.Unlock()
			t.Fatalf("partial or unbounded snapshot %v %v", p, err)
		}
	}
	active := body.Scene.Stage.popups.top()
	active.Scene.NeedsLayout()
	if p, err := body.Scene.InspectPopups(8192, 8<<20); !errors.Is(err, ErrPopupInspectionPending) || p != nil {
		rc.Unlock()
		t.Fatal("pending popup geometry admitted")
	}
	rc.Unlock()
	drainManual(t, m)
	upper := NewScene("upper-menu")
	NewButton(upper).SetText("Top")
	NewPopupStage(MenuStage, upper, body).Run()
	tip := NewScene("tip")
	NewButton(tip).SetText("Tip")
	NewPopupStage(TooltipStage, tip, body).SetTimeout(0).Run()
	drainManual(t, m)
	p := inspectPopupOwned(t, m, body.Scene)
	if len(p) != 3 || p[0].Interactive || !p[1].Interactive || p[2].Interactive || p[0].Items[0].Enabled || p[2].Items[0].Enabled {
		t.Fatalf("covered or ignored popup offered as target: %+v", p)
	}
	// A same-window modal main stage covers every popup owned by the prior main.
	dialog := NewBody("inspection-dialog").NewDialog(body).SetNewWindow(false).Run()
	drainManual(t, m)
	if p := inspectPopupOwned(t, m, body.Scene); len(p) != 0 {
		t.Fatal("background-main popup leaked through modal scope", p)
	}
	rc.Lock()
	dialog.Scene.Close()
	rc.Unlock()
	drainManual(t, m)
	m.window.SystemWindow.Events().Key(events.KeyChord, 0, key.CodeEscape, 0)
	drainManual(t, m)
}

func TestPopupInspectionIdentityCopyAndSaturation(t *testing.T) {
	a, b := &WidgetBase{}, &WidgetBase{}
	first := popupInspectionID(a)
	b.Properties = a.Properties // even an explicit shared-map copy must fail closed
	second := popupInspectionID(b)
	if first == 0 || second == first || popupInspectionID(b) != second || popupInspectionID(a) == second {
		t.Fatal("copied metadata revived another widget identity")
	}
	var counter atomic.Uint64
	counter.Store(math.MaxUint64 - 1)
	if nextPopupInspectionID(&counter) != math.MaxUint64 || nextPopupInspectionID(&counter) != 0 || counter.Load() != math.MaxUint64 {
		t.Fatal("saturated identity allocator wrapped")
	}
}

// A bounded detached label must own its bytes: an immutable short substring can
// otherwise retain an arbitrarily larger source allocation after popup removal.
func TestPopupInspectionLabelOwnsBoundedBacking(t *testing.T) {
	m, body, _, _ := inspectPopupFixture(t)
	backing := strings.Repeat("x", 4<<20) + "Tiny"
	label := backing[len(backing)-4:]
	rc := m.window.renderContext()
	rc.Lock()
	button := body.Scene.Stage.popups.top().Scene.Children[1].(*Button)
	button.Text = label // test fixture only; preserve the already completed layout
	rc.Unlock()
	p := inspectPopupOwned(t, m, body.Scene)
	got := p[0].Items[1].Name
	if got != label || unsafe.StringData(got) == unsafe.StringData(label) {
		t.Fatal("detached bounded label retains the original backing allocation")
	}
}
