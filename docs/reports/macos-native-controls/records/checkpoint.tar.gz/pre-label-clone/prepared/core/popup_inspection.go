// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT

package core

import (
	"errors"
	"image"
	"math"
	"sync/atomic"

	"cogentcore.org/core/styles/states"
)

var (
	ErrPopupInspectionPending = errors.New("core: popup layout not completed")
	ErrPopupInspectionBudget  = errors.New("core: popup inspection budget exceeded")
)

// PopupInspection is detached diagnostic data from a real current popup Scene.
// Only the top event-accepting popup is Interactive. Items cover direct standard
// Buttons (including Chooser menus); custom/nested menu implementations retain
// their existing inspectors. Bounds are clipped raw window pixels, not DP.
type PopupInspection struct {
	ID          uint64
	Type        StageTypes
	Bounds      image.Rectangle
	Interactive bool
	Items       []PopupItemInspection
}

type PopupItemInspection struct {
	ID                         uint64
	Name                       string
	Bounds                     image.Rectangle
	Enabled, Focused, Selected bool
}

const popupInspectionKey = "core.vellum-popup-inspection"

type popupInspectionIdentity struct {
	owner *WidgetBase
	id    uint64
}

// Only the monotonic counter is global; there is no historical widget registry.
var popupInspectionNext atomic.Uint64

func nextPopupInspectionID(next *atomic.Uint64) uint64 {
	for {
		old := next.Load()
		if old == math.MaxUint64 {
			return 0 // never wrap and revive a stale identity
		}
		if next.CompareAndSwap(old, old+1) {
			return old + 1
		}
	}
}

func popupInspectionID(w *WidgetBase) uint64 {
	if old, ok := w.Properties[popupInspectionKey].(*popupInspectionIdentity); ok && old.owner == w {
		return old.id
	}
	id := nextPopupInspectionID(&popupInspectionNext)
	if id != 0 {
		// Properties are excluded from ordinary cloning; the owner check also
		// fails closed for a manually copied property map or WidgetBase.
		w.SetProperty(popupInspectionKey, &popupInspectionIdentity{owner: w, id: id})
	}
	return id
}

// InspectPopups must run with this Scene's render context already held. It does
// not lock that context recursively or invoke widget/update/style callbacks.
// Stack locks protect only bounded pointer snapshots; no pointers escape here.
// maxRecords (<=8192) charges every popup and visited direct child, even skipped
// non-Buttons. maxBytes (<=8MiB) charges fixed records and copied labels. Callers
// pass the remaining shared budget. Refusal returns no partial snapshot.
func (sc *Scene) InspectPopups(maxRecords, maxBytes int) ([]PopupInspection, error) {
	if maxRecords < 0 || maxRecords > 8192 || maxBytes < 0 || maxBytes > 8<<20 {
		return nil, ErrPopupInspectionBudget
	}
	if sc == nil || sc.Stage == nil || sc.Stage.Mains == nil || sc.renderContext() == nil {
		return nil, ErrPopupInspectionPending
	}
	main := sc.Stage.Mains.top()
	if main == nil || main.Scene == nil || main.renderContext != sc.renderContext() || main.popups == nil {
		return nil, ErrPopupInspectionPending
	}
	stack := main.popups
	stack.Lock()
	if len(stack.stack.Order) > 64 || len(stack.stack.Order) > maxRecords {
		stack.Unlock()
		return nil, ErrPopupInspectionBudget
	}
	stages := make([]*Stage, 0, len(stack.stack.Order))
	for _, kv := range stack.stack.Order {
		stages = append(stages, kv.Value)
	}
	stack.Unlock()
	var active *Stage
	for i := len(stages) - 1; i >= 0; i-- {
		if !stages[i].ignoreEvents {
			active = stages[i]
			break
		}
	}
	window := sc.renderContext().geom.Bounds()
	var out []PopupInspection
	charge := func(bytes int) bool {
		maxRecords--
		maxBytes -= bytes
		return maxRecords >= 0 && maxBytes >= 0
	}
	for _, st := range stages {
		p := st.Scene
		if p == nil || p.This == nil || st.Main != main || p.showIter <= sceneShowIters || !p.hasFlag(sceneHasShown) || p.GlobalLayoutPending() || p.hasFlag(sceneNeedsLayout) || p.hasFlag(sceneNeedsRender) {
			return nil, ErrPopupInspectionPending
		}
		if !charge(128) {
			return nil, ErrPopupInspectionBudget
		}
		v := PopupInspection{ID: popupInspectionID(p.AsWidget()), Type: st.Type, Bounds: p.SceneGeom.Bounds().Intersect(window), Interactive: st == active}
		if v.ID == 0 {
			return nil, ErrPopupInspectionBudget
		}
		for _, child := range p.Children {
			if !charge(128) {
				return nil, ErrPopupInspectionBudget
			}
			button, ok := child.(*Button)
			if !ok || button.This == nil {
				continue
			}
			if len(button.Text) > 1<<20 || len(button.Text) > maxBytes {
				return nil, ErrPopupInspectionBudget
			}
			maxBytes -= len(button.Text)
			id := popupInspectionID(button.AsWidget())
			if id == 0 {
				return nil, ErrPopupInspectionBudget
			}
			bounds := button.Geom.TotalBBox.Add(p.SceneGeom.Pos).Intersect(v.Bounds)
			v.Items = append(v.Items, PopupItemInspection{ID: id, Name: button.Text, Bounds: bounds, Enabled: v.Interactive && button.IsVisible() && !button.IsReadOnly() && !bounds.Empty(), Focused: button.ContainsFocus(), Selected: button.StateIs(states.Selected)})
		}
		out = append(out, v)
	}
	return out, nil
}
