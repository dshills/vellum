from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('adopted_build_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
paths=list((T/'drivers/cogent').glob('*.go'))+list((T/'drivers/cogent/cmd/gallery').glob('*.go'))+list((T/'drivers/cogent/native/patches/popupinspection').rglob('*'))
paths += list((T/'drivers/cogent/build/upstream').rglob('*.go')) + list((T/'drivers/cogent/build/typesetting').rglob('*.go'))
paths=[p for p in paths if p.is_file()]
pins={str(p):h.sha(p)for p in paths};pins[str(Path(__file__))]=h.sha(__file__)
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$'}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),'build','-p=1','-o',str(W/'gallery-controls-adopted-refocus'),'./cmd/gallery']
r=h.g.execute(av,T/'drivers/cogent',W/'adopted-build-refocus',lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=300,limit=8<<20);r['source_pins']=pins;r['native_executed']=False;r['scope']='Actual source worktree native command compiles with its default native library; does not inherit SDK786a runtime qualification.'
(W/'adopted-build-refocus.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['owned']['group_absent']and not r['owned']['errors']else 1)
