from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-native-controls/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((W/'internal-prism-disposition.json').read_text())['approved']
files={}
def add(p,name=None):
 p=Path(p);assert p.is_file()and not p.is_symlink();name=name or p.relative_to(W).as_posix();assert name not in files and not name.startswith('/')and'..'not in Path(name).parts;files[name]=p
for n in ['review-scope-final.json','validate_refocus.py','validation_refocus_controls.py','validation_refocus_check_v2.py','check_v9.py','refocus-check-disposition.json','adopted_build_refocus.py','scope.json','modifier-recovery-scope.json','recovery-scope.json','focus-recovery-scope.json','native.py','native_modifier_recovery.py','native_recovery.py','native_focus_recovery.py','validate.py','validation_controls.py','validation_check.py','check_v5.py','check_v6.py','check_v7.py','check_v8.py','prepare_check_v2.py','prepare_check_v3.py','prepare_tests_v3.py','stage83-patch.json','prepare-checksum-disposition.json','internal-native-source-review.json','internal-native-recovery-review.json','internal-native-focus-review.json','internal-native-modifier-review.json','adopt.py','adoption-notes.json','review-scope.json','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','prepared-overlay-parity.json','native-final-boundary.json','parity-disposition.json','prepare_adopt.py','adopted_build.py','post_adopt_docs.py','archive.py','parity.py','adopted_build_final.py','adopted-build-disposition.json']:
 add(W/n)
for n in ['driver-all-v3','driver-all-v4','catalogue-build-v3','catalogue-build-v4','consumer-vet-v2','consumer-vet-v3','driver-all-v5','owned-core-v2','core-vet-v2','consumer-vet-v4','catalogue-build-v5','consumer-vet-v5','catalogue-build-v6','gallery-tests-final','select-all-negative-v1','prepare-v2','prepare-v3','prepare-tests-v3','validation-controls-v1','wake-negative-v1','wake-positive-v1','selector-focus-negative-v1','selector-focus-positive-v1','adopted-prepare','adopted-build-final','adopted-build','number-refocus-v1','gallery-tests-refocus','consumer-vet-v6','catalogue-build-v7','validation-refocus-controls-v2','adopted-build-refocus']:
 add(W/(n+'.json'))
 for p in(W/n).iterdir():
  if p.is_file():add(p)
for n in ['native-v1','native-v2','native-v3','native-v4']:
 for p in(W/n).rglob('*'):
  if p.is_file():add(p)
for root in ['pre-label-clone','versions','install']:
 for p in(W/root).rglob('*'):
  if p.is_file():add(p)
for n in json.loads((W/'adoption-notes.json').read_text())['source_go_paths']+['prepared/core/popup_inspection.go','prepared/core/popup_inspection_offscreen_test.go','overlay.json']:
 add(W/'candidate'/n)
assert len(files)<=256
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};assert all(z['bytes']<=10<<20 for z in manifest.values())and sum(z['bytes']for z in manifest.values())<=32<<20
assert not(R/'checkpoint.tar.gz').exists()
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as out:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;out.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as check:
 for m in check:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=check.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');r={'members':len(files),'expanded_bytes':sum(z['bytes']for z in manifest.values()),'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'physical_input_verified':False};(R/'archive.json').write_text(json.dumps(r,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
