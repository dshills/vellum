from pathlib import Path
import re
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
p=T/'specs/desktop-integration.md';s=p.read_text();s+='''\n## Owner wakes under popup modality

Exact originating owner wakes bypass popup modality even without DesktopSession,
so posted application work continues while a menu is open. Only the exact driver
wake and this window's session requests are intercepted; unrelated Custom events
retain ordinary popup routing. Launched/unlaunched teardown clears the hook.
''';p.write_text(s)
p=T/'specs/controls.md';s=p.read_text();s+='''\n## Selector click focus

A pointer click on an enabled focusable Selector takes actual quiet keyboard
focus before opening its menu. The menu owns its own item focus; selection or
cancellation leaves keyboard navigation with the originating Selector. Disabled,
read-only or nonfocusable native controls do not acquire focus through this hook.
Taking focus does not itself propose a value or consume the click. Model rejection
continues to restore the controlled selection, including the next real menu.
The native gallery check and actual software FIFO regression separately verify
pointer selection, actual ContainsFocus/public focus, Return reopen and Escape.
''';p.write_text(s)
# Human-facing prose uses normal spacing; do not touch code or receipt values.
for n in ['specs/desktop-integration.md','docs/desktop-integration.md','specs/control-acceptance.md','specs/macos-delivery.md','specs/macos-completion.md','docs/reports/macos-native-controls/README.md','drivers/cogent/cmd/gallery/README.md','drivers/cogent/native/patches/popupinspection/README.md']:
 p=T/n;s=p.read_text();s=re.sub(r'([A-Za-z])(?=\d)',r'\1 ',s) if n.endswith('patches/popupinspection/README.md')else s
 for a,b in [('passes49','passes 49'),('and21','and 21'),('dedicated49','dedicated 49'),('record has49','record has 49'),('their49','their 49'),('its49','its 49'),('a90','a 90'),('and6','and 6'),('a90','a 90'),('shared8192','shared 8192'),('the8192','the 8192'),('at most64','at most 64'),('at most64','at most 64'),('all83','all 83'),('Stage83','Stage 83'),('ControlledGo2/SDK786a','controlled GOMAXPROCS=2 / SDK 786a'),('SDK786a','SDK 786a'),('ordinary49','ordinary 49'),('original49','original 49')]:s=s.replace(a,b)
 p.write_text(s)
