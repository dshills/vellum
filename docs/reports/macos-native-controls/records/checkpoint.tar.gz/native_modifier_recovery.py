"""One fresh bounded native control case, held under the shared desktop lease."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;I=W/'candidate';N=W/'native-v4'
s=importlib.util.spec_from_file_location('control_native_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
import validate
sys.path.insert(0,str(h.T/'scripts'));from child_process import run_child
HEAD='a1f92bb13bdd2e7896aa02b12982fa4a984a8465'
CHECKS={'driver-all-v5':'driver','owned-core-v2':'core','core-vet-v2':'core','consumer-vet-v5':'all','catalogue-build-v6':'all','selector-focus-positive-v1':'driver','gallery-tests-final':'all'}
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def vector(root):
 out={}
 for p in root.rglob('*'):
  h.need(not p.is_symlink(),'regular file vector')
  if p.is_file():out[p.relative_to(root).as_posix()]=h.sha(p)
 return out
def source(root):
 h.need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean base source')
 return{n:h.sha(root/n)for n in git(root,'ls-files','-z').decode().split('\0')[:-1]}
def prepared(root):return{m+'/'+n:z for m in['upstream','typesetting']for n,z in vector(root/'drivers/cogent/build'/m).items()}
def prepare():
 h.need(not N.exists(),'fresh native scope')
 review=json.loads((W/'internal-native-modifier-review.json').read_text());h.need(review['approved']and not review['unresolved_findings'],'source review approved')
 h.need(all(h.sha(p)==z for p,z in review['inputs'].items()),'exact source review')
 for name,scope in CHECKS.items():
  r=json.loads((W/(name+'.json')).read_text());h.need(r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'terminal prerequisite '+name)
  for stream,info in r['logs'].items():
   p=W/name/stream;h.need(p.stat().st_size==info['bytes']and h.sha(p)==info['sha256'],'complete raw prerequisite')
  for p in I.rglob('*'):
   relative=p.relative_to(I).as_posix()
   relevant=scope=='all'or(scope=='core'and relative.startswith('prepared/'))or(scope=='driver'and not relative.startswith('drivers/cogent/cmd/gallery/')and relative!='overlay.json')
   if p.is_file()and relevant:h.need(r['source_pins'].get(str(p))==h.sha(p),'checked current source '+name+str(p))
  if scope=='driver':
   old=W/'versions/native-v3/overlay.json'
   h.need(h.sha(old)==r['source_pins'][str(I/'overlay.json')],'exact original root-driver overlay')
   selected=lambda path:{k:v for k,v in json.loads(path.read_text())['Replace'].items()if '/drivers/cogent/cmd/gallery/'not in k}
   h.need(selected(old)==selected(I/'overlay.json'),'unchanged root-driver overlay mappings')
 for name in ['prepare-v3','prepare-tests-v3','validation-controls-v1']:
  r=json.loads((W/(name+'.json')).read_text());h.need(r['exit_code']==0 and not r['error']and r['owned']['group_absent']and not r['owned']['errors'],'auxiliary prerequisite '+name)
 prep=json.loads((W/'prepare-v3.json').read_text());h.need(prep['prepared_exact']and prep['prepared_files']==6267,'stage83 exact preparation')
 a=source(h.C);h.need(source(h.T)==a,'source parity');b=prepared(h.C);h.need(prepared(h.T)==b and len(b)==6265,'base prepared parity')
 scope=json.loads((W/'modifier-recovery-scope.json').read_text());sdk=Path(scope['sdk']);original=json.loads((W.parent/'macos-native-workspace-594bd37/native-v5/plan.json').read_text())['sdk_files'];h.need(vector(sdk)==original,'retained SDK unchanged')
 overlay=json.loads((I/'overlay.json').read_text())['Replace']
 private=W/'preparation-v3/build'
 for module in['upstream','typesetting']:
  for p in(private/module).rglob('*'):
   if not p.is_file():continue
   q=sdk/'drivers/cogent/build'/module/p.relative_to(private/module);mapped=overlay.get(str(q),str(q));h.need(bool(mapped)and Path(mapped).is_file()and h.sha(mapped)==h.sha(p),'whole prepared overlay parity')
 paths=[p for p in I.rglob('*')if p.is_file()]+[W/n for n in ['modifier-recovery-scope.json','native_modifier_recovery.py','validate.py','validation_controls.py','internal-native-modifier-review.json','validation-controls-v1.json','prepare-v3.json','prepare-tests-v3.json','stage83-patch.json','check_v8.py','prepare_check_v3.py','prepare_tests_v3.py']]+[W/(n+'.json')for n in CHECKS]+[W/'versions/native-v3/overlay.json',Path(h.__file__),h.GUARD,h.GO,h.T/'scripts/child_process.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 p={'head':HEAD,'source':a,'prepared':b,'sdk':str(sdk),'sdk_files':original,'pins':{str(p):h.sha(p)for p in paths},'binary':{'path':str(W/'gallery-native-v6'),'sha256':h.sha(W/'gallery-native-v6')},'launch_deadline_utc':scope['reassess_by_utc'],'watchdog_seconds':120,'stream_limit_bytes':4<<20,'gomaxprocs':'2','runtime_options':{k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']},'scope':'One native CPU-scene controls-gallery process,49 authored Go FIFO inputs/21 actual composition/semantic/geometry/model observations. Pointer/keyboard selector, acceptance/rejection, Escape/outside-release consumption, actual popup incarnations, typed/invalid/clamped numeric edits, disabled/reenabled control behavior and original-window/session cleanup. Fixture setup changes only reject/disabled flags via owning app; input proof uses public DesktopSession. Same reusable gallery controls in compact visible view; no scroll acceptance claimed. No OS input operator/settings/IME/VoiceOver/clipboard, physical input/presentation/performance/full catalogue/Mac/SDK-release qualification. Separate SDK786a library and controlledGo2 configuration. Shared exclusive lease; network and SDK writes denied. Any failure seals scope, no reset/retry/second case. No source/prepared/SDK mutation during execution.'}
 N.mkdir();(N/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(N/'plan.json'),'native_executed':False}))
def run():
 raw=(N/'plan.json').read_bytes();araw=(N/'admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw);stop=N/'stop-live';sdk=Path(p['sdk'])
 h.need(a['approved']and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact native admission')
 h.need(not stop.exists()and not(N/'case').exists()and not(N/'result.json').exists(),'fresh admitted case')
 def stable():return(N/'plan.json').read_bytes()==raw and(N/'admission.json').read_bytes()==araw and all(h.sha(k)==z for k,z in p['pins'].items())and h.sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  h.need(not stop.exists()and stable(),'source/stop boundary')
  h.need(source(h.C)==source(h.T)==p['source']and prepared(h.C)==prepared(h.T)==p['prepared']and vector(sdk)==p['sdk_files'],'whole source/prepared/SDK parity')
  h.need({k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']}==p['runtime_options'],'controlled runtime options')
 result={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('native control controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();h.need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline')
   profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
   argv=['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],'-control-native-check']
   r=g.execute(argv,sdk/'drivers/cogent',N/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);result['run']=r;result['native_executed']=r['created']
   h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'native process/result/cleanup failed')
   result['summary']=validate.validate((N/'case/stdout').read_bytes(),(N/'case/stderr').read_bytes());boundary();h.need(lease.held(),'lease through cleanup');result['result']='PASS_NATIVE_CONTROLS'
 except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(N/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result.get(k)for k in ['result','native_executed','error','summary']}))
 if result['error']:sys.exit(1)
if __name__=='__main__':
 h.need(sys.argv[1:]in[['prepare'],['run']],'fixed native phase')
 prepare()if sys.argv[1]=='prepare'else run()
