from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=W/'preparation-v3';s=importlib.util.spec_from_file_location('prepare_test_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
pins={str(p):h.sha(p)for p in [Path(__file__),T/'prepare_test.py',T/'prepare.py',*[p for p in(T/'native').rglob('*')if p.is_file()]]}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOPROXY':'off','GOSUMDB':'off','PYTHONDONTWRITEBYTECODE':'1'}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/opt/homebrew/bin/python3','-B','-m','unittest','-v','prepare_test']
r=h.g.execute(av,T,W/'prepare-tests-v3',lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=180,limit=8<<20);r['source_pins']=pins;r['native_executed']=False
(W/'prepare-tests-v3.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['owned']['group_absent']and not r['owned']['errors']else 1)
