from pathlib import Path
import json,subprocess,hashlib
R=Path('/private/tmp/vellum-packed-coverage');P=Path(__file__).parent;signatures={}
for mode in ['original','candidate']:
 name='verified-matrix-'+mode;s=(P/'pair-fixture-template.go.txt').read_text();s='\n'.join(line for line in s.splitlines()if 'measured := testing.Benchmark'not in line and 'CAPTURE_ACTUAL_GRID'not in line)+'\n'
 s=s.replace('[]float32{96}','[]float32{96,120,160,240}').replace('[]bool{false}','[]bool{false,true}').replace('[]image.Point{{0, 12}}','[]image.Point{{0, 12}, {31, 0}, {13, 24}}').replace('len(records) != 1','len(records) != 24').replace('/private/tmp/vellum-macos-span-storage/capture-candidate-packet.json',str(P/(name+'-packet.json')))
 f=P/(name+'_test.go');f.write_text(s);overlay=P/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{**(json.loads((P/'original-overlay-base.json').read_text())['Replace'] if mode=='original' else {}),str(R/'drivers/cogent/scene_cost_external_test.go'):str(f)}}))
 run=subprocess.run(['python3',str(P/'code_run.py'),name,'drivers/cogent','go','test','-race','-tags','offscreen','-overlay='+str(overlay),'.','-run','^TestVellumSceneCostActualCapture$','-count=1','-timeout=180s','-v'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=210);(P/(name+'.wrapper.log')).write_bytes(run.stdout);assert run.returncode==0,run.stdout[-2000:]
 records=json.loads((P/(name+'-packet.json')).read_text());assert len(records)==24;signatures[mode]=hashlib.sha256((P/(name+'-packet.json')).read_bytes()).hexdigest();print(name,signatures[mode],flush=True)
assert signatures['original']==signatures['candidate']
(P/'verified-matrix-summary.json').write_text(json.dumps({'result':'PASS_EXACT_SOFTWARE_CAPTURE_MATRIX','records_per_arm':24,'dpi':[96,120,160,240],'variable':[False,True],'per_case_scroll_steps':[[0,12],[31,0],[13,24]],'signatures':signatures,'native_gpu_executed':False,'scope':'Actual retained driver paint batches, original/GPU encoded parts, logical accounting and CPU/software replay pixels; no native GPU execution or latency qualification.'},indent=2)+'\n')
