from pathlib import Path
import difflib,hashlib,json
R=Path('/private/tmp/vellum-packed-coverage');P=Path(__file__).parent
U=R/'drivers/cogent/build/upstream';D=R/'drivers/cogent/native/patches/packedcoverage'
outputs={};patch=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for name,expected in json.loads((D/'original-hashes.json').read_text()).items():
 old=P/'original'/name;data=(U/name).read_bytes();prior=old.read_bytes()if old.exists()else b''
 assert (sha(prior)if old.exists()else None)==expected
 outputs[name]=sha(data)
 patch.extend(difflib.unified_diff(prior.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+name if old.exists()else'/dev/null',tofile='b/'+name))
f=D/'0067-packed-cached-glyph-spans.patch';f.write_text(''.join(patch));(D/'output-hashes.json').write_text(json.dumps(outputs,indent=2)+'\n')
m=R/'drivers/cogent/native/dependencies.json';obj=json.loads(m.read_text());stage=obj['dependencies'][0]['stages'][-1];assert stage['origin'].endswith('/packedcoverage');stage['patches'][0]['sha256']=sha(f.read_bytes());m.write_text(json.dumps(obj,indent=2)+'\n')
print(stage['patches'][0]['sha256'])
