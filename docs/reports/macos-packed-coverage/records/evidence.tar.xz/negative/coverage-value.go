// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package sceneplan

import (
	"image"
	"image/draw"
	"unsafe"
)

// SpanSample is a relative coverage sample. Callers retain ownership of samples;
// successful PackedSpans copies their values and never retains the input slice.
type SpanSample struct {
	Y, X0, X1 int32
	Alpha     uint32
}

// PackedSpans replays at most 256 ascending coverage samples into an empty active
// span stream. It preserves sequential Span admission/charges, row order and
// stream boundaries. False means no mutation: callers must use ordinary Span
// for unsupported/clipped input or to preserve partial budget refusal behavior.
func (b *Builder) PackedSpans(samples []SpanSample, origin image.Point) bool {
	if b.failed || b.stream == nil || !b.stream.rect.Empty() || len(b.stream.rows) != 0 || len(samples) == 0 || len(samples) > 256 || origin.X < 0 || origin.Y < 0 || origin.X > MaxDimension || origin.Y > MaxDimension {
		return false
	}
	rowMin, size, count := 0, 0, 0
	rect := image.Rectangle{}
	lastY := -1
	for _, s := range samples {
		if s.Y < 0 || s.Y > MaxDimension || s.X0 < 0 || s.X1 > MaxDimension || s.X0 >= s.X1 || s.Alpha > 65535 {
			return false
		}
		y, x0, x1 := int(s.Y)+origin.Y, int(s.X0)+origin.X, int(s.X1)+origin.X
		if y < lastY || y >= b.packet.bounds.Dy() || x1 > b.packet.bounds.Dx() {
			return false
		}
		lastY = y
		if s.Alpha == 0 && b.stream.op == draw.Over {
			continue
		}
		if y < rowMin || y >= rowMin+size {
			minY, maxY := y, y+1
			if !rect.Empty() {
				minY = min(minY, rect.Min.Y)
				maxY = max(maxY, rect.Max.Y)
			}
			size = min(b.packet.bounds.Dy(), max(maxY-minY, max(1, size*2)))
			rowMin = min(minY, b.packet.bounds.Dy()-size)
		}
		r := image.Rect(x0, y, x1, y+1)
		if rect.Empty() {
			rect = r
		} else {
			rect = rect.Union(r)
		}
		count++
	}
	if count == 0 {
		return true
	}
	cost := count*int(unsafe.Sizeof(span{})) + size*int(unsafe.Sizeof([]span{}))
	if cost > MaxBytes-b.packet.bytes {
		return false
	}
	if !b.reserve(cost) {
		return false
	}
	// One exact backing replaces construction row growth and the later span copy.
	// Capped row slices cannot overwrite adjacent rows on an ordinary append.
	storage := make([]span, count)
	rows := b.borrowSpanHeaders(size)
	offset, start, row := 0, 0, -1
	for _, s := range samples {
		if s.Alpha == 0 && b.stream.op == draw.Over {
			continue
		}
		y := int(s.Y) + origin.Y
		if row != y {
			if row >= 0 {
				rows[row-rowMin] = storage[start:offset:offset]
			}
			row, start = y, offset
		}
		storage[offset] = span{int(s.X0) + origin.X, int(s.X1) + origin.X, 0}
		offset++
	}
	rows[row-rowMin] = storage[start:offset:offset]
	b.stream.rows, b.streamRowMin, b.stream.rect = rows, rowMin, rect
	b.streamPacked = true
	return true
}

// A later ordinary Span is legal. Detach every packed row before permitting
// scratch retention, whose capacity budget assumes independently owned rows.
func (b *Builder) unpackSpans() {
	for i, row := range b.stream.rows {
		if len(row) == 0 {
			continue
		}
		own := make([]span, len(row))
		copy(own, row)
		b.stream.rows[i] = own
	}
	b.streamPacked = false
}
