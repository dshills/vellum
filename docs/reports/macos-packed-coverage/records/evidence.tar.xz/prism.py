from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-packed-coverage');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'integration-review.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==10
assert all(sha(R/n)==h for n,h in sources.items())
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
out=P/'prism-v1';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Owned patch0067 packs bounded cached glyph coverage into private exact scene span storage. Keep original sequential geometric header/span charges, partial refusal fallback, deferred operation admission and spare header refunds. Empty stream admission <=256 sorted in-bounds samples; no sorting/merging or borrowed cache references. Packed flush detaches headers, never caches flat subrows in separately budgeted row scratch. Later ordinary Span validates/reserves before unpack. Both Seal paths retire references. Existing independent original builder and encoded/pixel oracles, exact caps, budget, source isolation and meaningful fault controls. Source integration internally approved; final software matrix/SDK checks are pending separately. Two unkeyed external alias literals found by vet were corrected with keyed fields and pins reproduced. No native binary/GPU or physical input executed; software allocations only, local elapsed times diagnostic, unchanged native4/6ms targets historically failed. No full Mac/P4/P6/P11 or retained memory/distribution acceptance claim.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'integration-review.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
