from pathlib import Path
import subprocess,json
P=Path(__file__).parent
h=json.loads((P/'verified-sdk-archive.stdout').read_text())['sha256']
cmd=['python3',str(P/'code_run.py'),'verified-sdk-relocation','.','python3','scripts/check-sdk.py','--archive',str(P/'vellum-sdk-verified.tar.gz'),'--sha256',h]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=650);(P/'verified-sdk-relocation.wrapper.log').write_bytes(r.stdout);print('verified-sdk-relocation',r.returncode,flush=True);assert r.returncode==0,r.stdout[-2000:]
r=subprocess.run(['python3',str(P/'relocated_renderer_verified.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=500);(P/'relocated-renderer-verified.wrapper.log').write_bytes(r.stdout);print('relocated-renderer',r.returncode,flush=True);assert r.returncode==0,r.stdout[-2000:]
