from pathlib import Path
r=Path('/private/tmp/vellum-packed-coverage/drivers/cogent/build/upstream')
def change(name, old, new):
    f=r/name;s=f.read_text();assert s.count(old)==1,(name,old);f.write_text(s.replace(old,new))
b='paint/renderers/sceneplan/builder.go'
change(b,'streamValue                        operation','streamValue                        operation\n\tstreamPacked                       bool')
change(b,'construction := o.rows','construction := o.rows\n\tpacked := b.streamPacked\n\tb.streamPacked = false')
start=(r/b).read_text().index('\ttotal := 0\n', (r/b).read_text().index('func (b *Builder) flush'))
end=(r/b).read_text().index('\to.rows = exact',start)
s=(r/b).read_text();old=s[start:end]
new='''\texact := make([][]span, len(o.rows))
\tif packed {
\t\t// Packed construction already owns one exact, detached span backing.
\t\t// Only headers need detaching before their scratch container is cleared.
\t\tcopy(exact, o.rows)
\t} else {
\t\ttotal := 0
\t\tfor _, row := range o.rows { total += len(row) }
\t\tstorage := make([]span, total)
\t\toffset := 0
\t\tfor i, row := range o.rows {
\t\t\tend := offset + len(row)
\t\t\tcopy(storage[offset:end], row)
\t\t\texact[i] = storage[offset:end:end]
\t\t\toffset = end
\t\t}
\t\tfor _, row := range o.rows { b.retainSpanScratch(row) }
\t}
'''
(r/b).write_text(s[:start]+new+s[end:])
change(b,'\tif grow {\n\t\tgrown := b.borrowSpanHeaders(size)','\tif b.streamPacked {\n\t\tb.unpackSpans()\n\t}\n\tif grow {\n\t\tgrown := b.borrowSpanHeaders(size)')
change(b,'b.spanHeaders = [9][][]span{}','b.spanHeaders = [9][][]span{}\n\tb.streamPacked = false')
g='paint/renderers/rasterx/glyph_coverage.go'
change(g,'"cogentcore.org/core/paint/renderers/rasterx/scan"','"cogentcore.org/core/paint/renderers/rasterx/scan"\n\t"cogentcore.org/core/paint/renderers/sceneplan"')
change(g,'type glyphCoverageSpan struct {\n\ty, x0, x1 int32\n\talpha     uint32\n}', 'type glyphCoverageSpan = sceneplan.SpanSample')
change(g,'\t\tspan := rs.Scanner.Spanner.GetSpanFunc()','\t\tif s, ok := rs.Scanner.Spanner.(*sceneSpanner); ok && s.beginSpans() && s.builder.PackedSpans(e.spans, origin) {\n\t\t\trf.Clear()\n\t\t\treturn true\n\t\t}\n\t\tspan := rs.Scanner.Spanner.GetSpanFunc()')
change(g,'span(int(s.y)+origin.Y, int(s.x0)+origin.X, int(s.x1)+origin.X, s.alpha)','span(int(s.Y)+origin.Y, int(s.X0)+origin.X, int(s.X1)+origin.X, s.Alpha)')
a=r/'paint/renderers/rasterx/glyph_coverage_adoption_test.go';a.write_text(a.read_text().replace('.alpha','.Alpha'))
sp='paint/renderers/rasterx/scene_packet.go'
change(sp,'func (s *sceneSpanner) GetSpanFunc() scan.SpanFunc {','func (s *sceneSpanner) beginSpans() bool {')
s=(r/sp).read_text(); start=s.index('func (s *sceneSpanner) beginSpans');end=s.index('// ScenePacket',start);part=s[start:end]
part=part.replace('return func(int, int, int, uint32) {}','return false').replace('return s.builder.Span','return !s.builder.Failed()')
part+='''func (s *sceneSpanner) GetSpanFunc() scan.SpanFunc {
\tif !s.beginSpans() { return func(int, int, int, uint32) {} }
\treturn s.builder.Span
}

'''
(r/sp).write_text(s[:start]+part+s[end:])
