from pathlib import Path
import subprocess
P=Path(__file__).parent
steps=[
 ('verified-driver-race','drivers/cogent',['go','test','-race','-tags','offscreen','./...','-count=1','-timeout=180s']),
 ('verified-driver-vet','drivers/cogent',['go','vet','-tags','offscreen','./...']),
 ('verified-renderer-vet','drivers/cogent/build/upstream',['go','vet','-tags','offscreen','./paint/renderers/sceneplan','./paint/renderers/rasterx','./paint/renderers/gpuscene']),
 ('verified-prepare-tests','drivers/cogent',['python3','prepare_test.py']),
 ('verified-native-compile','drivers/cogent',['go','build','-o',str(P/'vellum-workbench'),'./cmd/workbench']),
]
for name,cwd,argv in steps:
 result=subprocess.run(['python3',str(P/'code_run.py'),name,cwd,*argv],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=650)
 (P/(name+'.wrapper.log')).write_bytes(result.stdout);print(name,result.returncode,flush=True);assert result.returncode==0,result.stdout[-2000:]
