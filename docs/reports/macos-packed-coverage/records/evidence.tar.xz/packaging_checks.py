from pathlib import Path
import subprocess,json
P=Path(__file__).parent
h=json.loads((P/'sdk-archive.stdout').read_text())['sha256']
cmd=['python3',str(P/'code_run.py'),'sdk-relocation','.','python3','scripts/check-sdk.py','--archive',str(P/'vellum-sdk.tar.gz'),'--sha256',h]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=650);(P/'sdk-relocation.wrapper.log').write_bytes(r.stdout);print('sdk-relocation',r.returncode,flush=True);assert r.returncode==0,r.stdout[-2000:]
r=subprocess.run(['python3',str(P/'relocated_renderer.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=500);(P/'relocated-renderer.wrapper.log').write_bytes(r.stdout);print('relocated-renderer',r.returncode,flush=True);assert r.returncode==0,r.stdout[-2000:]
