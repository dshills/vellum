from pathlib import Path
import json,hashlib,subprocess
R=Path('/private/tmp/vellum-packed-coverage');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepared(root):
 return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='cc95afa66ce491fe1f0d9f70fbb126c0e6fb230a'
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines());sources={n:sha(R/n)for n in sorted(names)};assert len(sources)==10
pin=json.loads((R/'drivers/cogent/native/patches/packedcoverage/output-hashes.json').read_text())
expected=prepared(R);before=prepared(C);assert len(expected)==6226 and len(before)==6224
changed={n for n in before.keys()|expected.keys()if before.get(n)!=expected.get(n)};assert changed=={'upstream/'+n for n in pin}
assert all(expected['upstream/'+n]==h for n,h in pin.items())
prep=json.loads((P/'prepare-final-v2.json').read_text());assert prep['exit_code']==0 and prep['error']is None and prep['source_delta_stable'] and prep['prepared_after']==expected and prep['prepared_before']==expected
checks={}
def check(name):
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_commit']==base and d['source_delta_stable'] and not d['live_tests'] and not d['headless_gpu_requested'],name
 assert d['prepared_before']==expected and d['prepared_after']==expected,name
 assert d['overlay_inputs_before']==d['overlay_inputs_after'],name
 for channel in ['stdout','stderr']:assert sha(P/(name+'.'+channel))==d[channel+'_sha256'],name
 # Only the report may be finalized after code checks. No compiled/pin source
 # difference is accepted. Before/after records still must be identical.
 mismatches={n for n,h in sources.items()if d['source_delta_after'].get(n)!=h}
 assert mismatches<={'docs/reports/macos-packed-coverage/README.md'},(name,mismatches)
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'prepared_exact':True,'current_source_matches':sorted(set(sources)-mismatches)}
for name in ['verified-driver-race','verified-driver-vet','verified-renderer-vet','verified-prepare-tests','verified-native-compile','verified-sdk-archive','verified-sdk-relocation','verified-matrix-original','verified-matrix-candidate']:check(name)
pairs=json.loads((P/'paired-verified-summary.json').read_text());assert pairs['pairs']==5 and pairs['packet_bytes_and_pixels_equal'] and not pairs['native_performance_qualified'] and not pairs['profiled']
for mode,rows in pairs['results'].items():
 for row in rows:
  check(f"verified-pair-{row['pair']}-{mode}")
  assert sha(P/f"verified-pair-{row['pair']}-{mode}-packet.json")==row['packet_sha256']
  observed=json.loads((P/f"verified-pair-{row['pair']}-{mode}-packet.json").read_text());assert len(observed)==1 and observed[0]['visible_cells']==400 and observed[0]['cell_pool']==477 and observed[0]['dpi']==96 and observed[0]['variable']is False
original=json.loads((P/'original-overlay-base.json').read_text())['Replace']
for name in pin:
 f=P/'original'/name;target=str(R/'drivers/cogent/build/upstream'/name)
 if f.exists():assert sha(f)==before['upstream/'+name] and original[target]==str(f)
 else:assert original[target]=='' and 'upstream/'+name not in before
negative=json.loads((P/'verified-negative-results.json').read_text());assert len(negative)==6
for name,n in negative.items():
 assert n['intended_failure'] and n['candidate_sha256']==expected[n['source']]
 d=json.loads((P/('verified-negative-'+name+'.json')).read_text());assert d['exit_code']==1 and d['error']is None and d['source_delta_stable'] and d['overlay_inputs_before']==d['overlay_inputs_after'] and d['prepared_before']==expected and d['prepared_after']==expected
 for channel in ['stdout','stderr']:assert sha(P/('verified-negative-'+name+'.'+channel))==d[channel+'_sha256']
 assert n['expected_diagnostic']in(P/('verified-negative-'+name+'.stdout')).read_text() and sha(P/('verified-negative-'+name+'.json'))==n['receipt_sha256']
matrix=json.loads((P/'verified-matrix-summary.json').read_text());assert matrix['result']=='PASS_EXACT_SOFTWARE_CAPTURE_MATRIX' and matrix['records_per_arm']==24 and len(set(matrix['signatures'].values()))==1
for mode,h in matrix['signatures'].items():assert sha(P/('verified-matrix-'+mode+'-packet.json'))==h
sdk=json.loads((P/'verified-sdk-relocation.stdout').read_text());digest=sha(P/'vellum-sdk-verified.tar.gz');assert sdk['archive_sha256']==digest and sdk['native_runtime']=='not executed' and sdk['digest_verified_against_expected']
reloc=json.loads((P/'relocated-renderer-verified.json').read_text());assert reloc['result']=='PASS_RELOCATED_RENDERER_CODE_CHECKS' and reloc['prepared']==expected and reloc['prepared_exact'] and not reloc['native_binary_executed'] and reloc['archive_sha256']==digest
allowed=json.loads((P/'renderer-test-outputs.json').read_text())['nonpinned_generated_test_outputs'];assert len(allowed)==17
assert reloc['producer_sha256']==sha(P/'relocated_renderer_verified.py') and reloc['generated_test_outputs']==allowed
for d in reloc['checks']:
 assert d['exit_code']==0
 for channel in ['stdout','stderr']:assert sha(P/('relocated-renderer-verified-'+d['name']+'.'+channel))==d[channel+'_sha256']
summary={'result':'PASS_SCOPED_PACKED_COVERAGE_SOFTWARE_CHECKS','base_commit':base,'sources':sources,'checks':checks,'prepare_receipt_sha256':sha(P/'prepare-final-v2.json'),'prepared_before':before,'prepared_after':expected,'prepared_changed':sorted(changed),'prepared_files':6226,'negative_controls':negative,'allocation_observation':pairs,'matrix':matrix,'relocated_renderer_sha256':sha(P/'relocated-renderer-verified.json'),'sdk_archive_sha256':digest,'native_binary_sha256':sha(P/'vellum-workbench'),'human_online_live_stop_sha256':sha('/private/tmp/vellum-macos-quiet-current/stop-live'),'excluded_authoring_receipts':['packed-unit-v1','packed-unit-v2','packed-unit-v4','paired-summary.json','driver-race','driver-final-race','renderer-vet','relocated-renderer-clean.json','sdk-archive','sdk-relocation','matrix-summary.json','paired-final-summary.json','negative-results.json'],'native_binary_executed':False,'physical_pointer_qualified':False,'gpu_qualified':False,'native_latency_qualified':False,'retained_memory_qualified':False,'public_distribution_qualified':False,'full_mac_qualified':False,'full_P4_qualified':False,'full_P6_qualified':False,'full_P11_qualified':False,'limits':['Fixed400-cell procedural software capture allocation only; local wall times diagnostic on shared computer, not native frame acceptance.','24 original/candidate matrix observations match encodings/accounting/software pixels; no native GPU execution.','Relocated renderer race/vet uses all6226 exact pinned prepared leaves; its17 known generated PNGs are hash checked and deleted from its own extraction. Main SDK inputs contain none.','Original4ms p95/6ms p99 native targets remain failed at their historical endpoints; quiet matched native comparison still required.']}
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':base,'sources':sources},indent=2)+'\n');(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'sources':len(sources),'positive_receipts':len(checks),'negative_controls':6,'prepared_files':6226}))
