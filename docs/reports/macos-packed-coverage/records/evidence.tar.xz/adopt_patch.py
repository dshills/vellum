from pathlib import Path
import difflib,hashlib,json
R=Path('/private/tmp/vellum-packed-coverage');P=Path(__file__).parent;D=R/'drivers/cogent/native/patches/packedcoverage';D.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
U=R/'drivers/cogent/build/upstream'
files={name:(P/'original'/name if (P/'original'/name).exists() else None,U/name)for name in ['paint/renderers/sceneplan/builder.go','paint/renderers/sceneplan/packed_spans.go','paint/renderers/sceneplan/packed_spans_test.go','paint/renderers/rasterx/glyph_coverage.go','paint/renderers/rasterx/glyph_coverage_adoption_test.go','paint/renderers/rasterx/scene_packet.go']}
inputs={};outputs={};patch=[]
for name,(old,new)in files.items():
 original=old.read_bytes()if old else b'';modified=new.read_bytes();inputs[name]=sha(original)if old else None;outputs[name]=sha(modified)
 patch.extend(difflib.unified_diff(original.decode().splitlines(keepends=True),modified.decode().splitlines(keepends=True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
patchfile=D/'0067-packed-cached-glyph-spans.patch';patchfile.write_text(''.join(patch))
for name,value in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (D/name).write_text(json.dumps(value,indent=2)+'\n')
manifest=R/'drivers/cogent/native/dependencies.json';data=json.loads(manifest.read_text());data['dependencies'][0]['stages'].append({'origin':'drivers/cogent/native/patches/packedcoverage','inputs':'native/patches/packedcoverage/original-hashes.json','outputs':'native/patches/packedcoverage/output-hashes.json','patches':[{'file':'native/patches/packedcoverage/'+patchfile.name,'sha256':sha(patchfile.read_bytes())}]});manifest.write_text(json.dumps(data,indent=2)+'\n')
f=R/'drivers/cogent/prepare_test.py';s=f.read_text();assert s.count('list(range(1, 67))')==1;f.write_text(s.replace('list(range(1, 67))','list(range(1, 68))'))
(D/'README.md').write_text("""# Packed cached glyph spans

Owned patch0067 copies bounded, ascending cached glyph coverage into one exact
Builder-owned span backing. The cache keeps its existing16-byte sample shape,
512-entry/1MiB limits and geometry/collision validation. CPU image rendering
retains the ordinary coverage path. There is no new cache, pool or format.

PackedSpans accepts at most256 samples into an empty active stream and preflights
the original sequential geometric header/span charges. Unsupported/clipped or
under-budget input declines without mutation, letting ordinary Span preserve
partial-refusal behavior. Operation admission and spare-header refunds still
occur at flush. Packed flush detaches headers and transfers owned spans; packed
subrows never enter the separately charged row scratch. A later ordinary Span
validates/reserves before detaching every packed row. Seal retires all state.

The independent pre-reuse builder oracle, boundary/lifecycle checks, original
source overlays, exact encoded/pixel matrix and software allocation comparisons
qualify this source path. Native GPU, ordinary latency and Mac/P6 completion
remain separate acceptance gates.
""")
print(json.dumps({'patch_sha256':sha(patchfile.read_bytes()),'inputs':inputs,'outputs':outputs}))
