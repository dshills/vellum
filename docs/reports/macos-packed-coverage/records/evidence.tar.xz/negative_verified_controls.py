from pathlib import Path
import json,subprocess,hashlib
R=Path('/private/tmp/vellum-packed-coverage');P=Path(__file__).parent;N=P/'verified-negative';N.mkdir(exist_ok=False)
U=R/'drivers/cogent/build/upstream/paint/renderers/sceneplan'
cases={
 'coverage-value':('packed_spans.go','storage[offset] = span{int(s.X0) + origin.X, int(s.X1) + origin.X, s.Alpha}','storage[offset] = span{int(s.X0) + origin.X, int(s.X1) + origin.X, 0}','^TestVellumPackedSpansOriginalAdmissionEncoding$','span state or admission differs'),
 'nonempty-stream':('packed_spans.go','!b.stream.rect.Empty() || len(b.stream.rows) != 0 || ','','^TestVellumPackedSpansOriginalAdmissionEncoding$','span state or admission differs'),
 'unpack-before-budget':('builder.go','if !b.reserve(int(unsafe.Sizeof(span{})) + (size-len(rows))*int(unsafe.Sizeof([]span{}))) {','if b.streamPacked { b.unpackSpans() }; if !b.reserve(int(unsafe.Sizeof(span{})) + (size-len(rows))*int(unsafe.Sizeof([]span{}))) {','^TestVellumPackedSpansOwnershipAndOrdinaryNoops$','refused append detached before reservation'),
 'packed-row-scratch':('builder.go','copy(exact, o.rows)','copy(exact, o.rows); for _,row:=range o.rows { b.retainSpanScratch(row) }','^TestVellumPackedSpansOwnershipAndOrdinaryNoops$','packed subrows entered scratch'),
 'header-charge':('packed_spans.go','size*int(unsafe.Sizeof([]span{}))','(size-1)*int(unsafe.Sizeof([]span{}))','^TestVellumPackedSpansPeakBudgetAndOperationRefusal$','span state or admission differs'),
 'uncapped-rows':('packed_spans.go','storage[start:offset:offset]','storage[start:offset]','^TestVellumPackedSpansOwnershipAndOrdinaryNoops$','surplus packed span capacity'),
}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();results={}
for name,(leaf,old,new,test,message)in cases.items():
 source=U/leaf;candidate=source.read_text();assert candidate.count(old)==(2 if name=='uncapped-rows'else 1),(name,candidate.count(old))
 fault=candidate.replace(old,new);f=N/(name+'.go');f.write_text(fault);overlay=N/(name+'.json');overlay.write_text(json.dumps({'Replace':{str(source):str(f)}}))
 argv=['python3',str(P/'code_run.py'),'verified-negative-'+name,'drivers/cogent/build/upstream','go','test','-race','-tags','offscreen','-overlay='+str(overlay),'./paint/renderers/sceneplan','-run',test,'-count=1','-timeout=60s','-v']
 run=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100);(P/('verified-negative-'+name+'.wrapper.log')).write_bytes(run.stdout)
 receipt=json.loads((P/('verified-negative-'+name+'.json')).read_text());out=(P/('verified-negative-'+name+'.stdout')).read_text()
 intended=run.returncode==1 and receipt['exit_code']==1 and receipt['error']is None and receipt['source_delta_stable'] and receipt['prepared_before']==receipt['prepared_after'] and receipt['overlay_inputs_before']==receipt['overlay_inputs_after'] and message in out and '[build failed]'not in out
 results[name]={'intended_failure':intended,'source':str(source.relative_to(R/'drivers/cogent/build')),'candidate_sha256':sha(source),'fault_sha256':sha(f),'overlay':str(overlay),'test':test,'expected_diagnostic':message,'receipt_sha256':sha(P/('verified-negative-'+name+'.json'))};print(name,intended,flush=True)
(P/'verified-negative-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(v['intended_failure']for v in results.values())
