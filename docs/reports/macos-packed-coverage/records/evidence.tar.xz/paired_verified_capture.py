from pathlib import Path
import json,subprocess,re,statistics,hashlib
R=Path('/private/tmp/vellum-packed-coverage');P=Path(__file__).parent
builder=R/'drivers/cogent/build/upstream/paint/renderers/sceneplan/builder.go';results={mode:[]for mode in ['original','candidate']};signatures=[]
for pair in range(1,6):
 for mode in (['original','candidate']if pair%2 else ['candidate','original']):
  name=f'verified-pair-{pair}-{mode}';f=P/(name+'_test.go');s=(P/'pair-fixture-template.go.txt').read_text().replace('/private/tmp/vellum-macos-span-storage/capture-candidate-packet.json',str(P/(name+'-packet.json')));f.write_text(s)
  overlay=P/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{**(json.loads((P/'original-overlay-base.json').read_text())['Replace'] if mode=='original' else {}),str(R/'drivers/cogent/scene_cost_external_test.go'):str(f)}}))
  result=subprocess.run(['python3',str(P/'code_run.py'),name,'drivers/cogent','go','test','-tags','offscreen','-overlay='+str(overlay),'.','-run','^TestVellumSceneCostActualCapture$','-count=1','-timeout=120s','-v'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=150)
  (P/(name+'.wrapper.log')).write_bytes(result.stdout);assert result.returncode==0,(name,result.stdout[-2000:])
  match=re.search(r'CAPTURE_ACTUAL_GRID\s+(\d+)\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(P/(name+'.stdout')).read_text());assert match
  row=dict(zip(['iterations','ns_per_op','bytes_per_op','allocations_per_op'],map(int,match.groups())));row['pair']=pair;row['packet_sha256']=hashlib.sha256((P/(name+'-packet.json')).read_bytes()).hexdigest();results[mode].append(row);signatures.append(row['packet_sha256']);print(name,row,flush=True)
assert len(set(signatures))==1
summary={'result':'MEASURED_LOCAL_SOFTWARE_ALLOCATION_ONLY','results':results,'medians':{mode:{field:statistics.median([v[field]for v in rows])for field in ['bytes_per_op','allocations_per_op','ns_per_op']}for mode,rows in results.items()},'pairs':5,'packet_bytes_and_pixels_equal':True,'native_performance_qualified':False,'profiled':False,'scope':'400-cell procedural fixed-row DPI96 NotoSans15 retained driver batch, GOMAXPROCS2, repeatedScenePacket. Shared computer: local wall times are diagnostic and do not qualify native frame latency, physical GPU or P6.'}
(P/'paired-verified-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['medians']),flush=True)
