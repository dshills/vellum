"""Independent replay of the sealed structural capture; never launches an app."""
from pathlib import Path
import json, hashlib, datetime, collections, importlib.util, subprocess, sys
sys.dont_write_bytecode = True
q = Path(__file__).resolve().parent
r = Path('/Users/dshills/Development/projects/Vellum')
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([sys.executable, str(q/'verify.py')], check=True)
spec = importlib.util.spec_from_file_location('independent_raster_check', r/'tools/macos-calibration/rastercommands/native_check.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
result = load(q/'result.json'); plan = load(q/'bound-plan.json'); started = load(q/'started.json')
assert (q/'stop-live').exists() and result['outcome'] == 'VALID_NATIVE_RASTER_STRUCTURE'
assert result['release_qualified'] is False and result['gate_changed'] is False
assert all(sha(Path(p)) == h for p,h in plan['pins'].items())
docs = v.base.load(q/'capture/native/stdout'); assert len(docs) == 1
validation = v.validate(docs[0], load(q/'match.json'))
assert validation == load(q/'validation.json') == result['validation']
elapsed = (datetime.datetime.fromisoformat(result['finished_utc'])-datetime.datetime.fromisoformat(started['utc'])).total_seconds()
assert 0 < elapsed < plan['maximum_seconds'] == 30
assert result['geometry_before'] == result['geometry_after']
commands = [(q/'capture/native', result['native'])]
for phase in ['before', 'after']:
    for name, command in result['configuration_'+phase].items():
        commands.append((q/'capture'/phase/name, command))
        assert result['configuration_before'][name]['logs']['stdout'] == result['configuration_after'][name]['logs']['stdout']
assert len(commands) == 9
for folder, command in commands:
    assert command['exit_code'] == 0 and command['error'] is None
    assert command['owned']['terminal'] and command['owned']['group_absent'] and not command['owned']['errors']
    assert command['pins_stable'] and command['logs_complete'] and command['owned_tmp_empty']
    assert not command['observation_errors'] and not command['stop_at_exit']
    owned = load(folder/'owned.json')
    assert all(owned[k] == command[k] for k in ['pid','group','argv','cwd'])
    assert owned['pid'] == command['owned']['pid'] and owned['group'] == command['owned']['group']
    for stream, metadata in command['logs'].items():
        assert (folder/stream).stat().st_size == metadata['bytes'] and sha(folder/stream) == metadata['sha256']
assert result['native']['seconds'] < 20 and result['native']['logs']['stderr']['bytes'] == 0
frames = docs[0]['raster_commands']['Frames']; admitted = [f for f in frames if f['Cohort']]
per_frame=[]
for f in admitted:
    decisions = dict(collections.Counter(i['Decision'] for i in f['Items'] if i['Decision']))
    assert decisions == {'covered-next':4,'cropped-uniform':3,'render-path':4,'render-image':1}
    assert f['OwnedScanner'] and f['Complete']
    paths = [i for i in f['Items'] if i['Decision']=='render-path']
    assert all(not i['HasFill'] and not i['HasStroke'] and i['CropNoPaintCompatible'] and i['PathLength']==20 and i['PathTransform']==dict(XX=1,YX=0,XY=0,YY=1,X0=0,Y0=0) for i in paths)
    images = [i for i in f['Items'] if i['Decision']=='render-image']
    assert len(images)==1 and images[0]['HasUniformRGBA'] and images[0]['Mask'] is False
    per_frame.append({'decisions':decisions,'no_paint_identity_paths':len(paths),'image_rect':images[0]['Rect']})
summary = {'outcome':result['outcome'],'source_checkpoint':'2330a9b','preparation_evidence_checkpoint':'fbedfc8','elapsed_seconds':elapsed,'native_seconds':result['native']['seconds'],'owned_groups_retired':len(commands),'native_stdout_sha256':sha(q/'capture/native/stdout'),'sdk_file_count':8321,'original_native_library_sha256':load(q/'build-identity.json')['original_native_library']['sha256'],'validation':validation,'admitted_frames':per_frame,'all_admitted_scanners_owned':True,'release_qualified':False,'gate_changed':False,'production_repair_adopted':False,'limitations':['Instrumented three-transition structural capture, not a timing distribution or ordinary-build equivalence proof.','Geometry admission is not source/tag attribution. Scalar colors are not GPU readback or displayed-pixel verification.','Branch counts do not measure cropped band writes or CPU cost; process retirement does not prove whole-GPU allocation balance.','Automated command routing only; physical pointer and keyboard input not verified.'],'next_action':'Inspect the existing RenderPath no-paint execution and raster stage boundary using source and focused offscreen evidence before proposing another native performance candidate.'}
if (q/'summary.json').exists(): assert load(q/'summary.json') == summary
else: (q/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'outcome':summary['outcome'],'elapsed_seconds':elapsed,'owned_groups_retired':len(commands),'admitted_frames':len(admitted),'per_frame':per_frame[0],'release_qualified':False}))
