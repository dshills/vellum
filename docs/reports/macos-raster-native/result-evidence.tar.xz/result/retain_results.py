from pathlib import Path
import tarfile,io,json,hashlib
q=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum')
(q/'result-README.md').write_bytes((r/'docs/reports/macos-raster-native/README.md').read_bytes())
paths=[q/n for n in ['result.json','validation.json','started.json','bound-plan.json','summary.json','internal-result-review.json','verify_results.py','review_results.py','retain_results.py','result-README.md','spec-addition.txt']]
paths += [p for sub in ['capture','result-review'] for p in (q/sub).rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts]
paths=sorted(set(paths));index={}
archive=q/'result-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for p in paths:
  data=p.read_bytes();name='result/'+p.relative_to(q).as_posix();h=tarfile.TarInfo(name);h.size=len(data);h.mode=0o644;h.mtime=0;h.uid=h.gid=0;h.uname=h.gname='';t.addfile(h,io.BytesIO(data));index[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as t:
 assert sorted(t.getnames())==sorted(index)
 for m in t:
  data=t.extractfile(m).read();assert len(data)==index[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==index[m.name]['sha256']
(q/'result-evidence-index.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':index,'reused_preparation_archive_sha256':json.loads((q/'preparation-evidence-index.json').read_text())['archive_sha256'],'scope':'One sealed native structural attempt; no binary, cache, credentials or latency qualification.'},indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'members':len(index),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
