from pathlib import Path
import os,sys,json,hashlib,importlib.util,subprocess
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-grid-capture-repair/preflight-v2')
base=Path(__file__).resolve().parent/'preparation-review';base.mkdir(exist_ok=True)
repo=Path('/Users/dshills/Development/projects/Vellum')
sys.path.insert(0,str(repo/'scripts'))
spec=importlib.util.spec_from_file_location('owned','/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sys.path.insert(0,str(repo/'scripts'))
key=os.environ.get('ANTHROPIC_API_KEY');assert key,'existing Anthropic credential missing'
original=g.child_environment
def env(*args,**kwargs):
 e=original(*args,**kwargs)
 if args and args[0] is True:e['ANTHROPIC_API_KEY']=key
 return e
g.child_environment=env
files=['tools/macos-calibration/rastercommands/native_apply.py', 'tools/macos-calibration/rastercommands/native_check.py', 'tools/macos-calibration/rastercommands/native_check_test.py', 'tools/macos-calibration/rastercommands/native_run.py', 'tools/macos-calibration/rastercommands/NATIVE.md', 'tools/macos-calibration/rastercommands/testdata/native_commands.go', 'tools/macos-calibration/rastercommands/testdata/native_commands_test.go', 'tools/macos-calibration/rastercommands/testdata/native_main_darwin.go', 'tools/macos-calibration/rastercommands/testdata/no_probes_darwin.go', 'docs/reports/macos-raster-native/README.md', 'docs/reports/macos-raster-native/renderer.patch', 'specs/macos-completion.md', 'specs/macos-delivery.md', 'specs/macos-release-assessment.md'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(repo/n):sha(repo/n) for n in files};pins[str(Path(__file__).with_name('verify.py'))]=sha(Path(__file__).with_name('verify.py'))
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--paths',','.join(files),'--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--chunk-bytes','240000','--max-diff-bytes','240000','--rules',str(base/'rules.json'),'--format','json','--out',str(base/'prism.json')]
r=g.execute(argv,repo,base/'run',lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=180,limit=2<<20)
(base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exit_code':r['exit_code'],'error':r['error'],'seconds':r['seconds'],'files':files}))
assert r['error'] is None and r['exit_code'] in [0,1] and r['owned']['terminal'] and r['owned']['group_absent']
