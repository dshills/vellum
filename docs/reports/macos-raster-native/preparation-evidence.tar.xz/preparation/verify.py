from pathlib import Path
import json,hashlib,sys,importlib.util,os
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');p=Path('/private/tmp/vellum-raster-native-core');sdk=Path('/private/tmp/vellum-doclinks-sdk-bd3cbc9/retained SDK/vellum-v0.1.0-alpha.2');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());d=load(q/'build-identity.json');assert os.access(q/'framework-v2',os.X_OK) and sha(q/'framework-v2')==d['binary_sha256'];assert all(sha(Path(k))==v for k,v in d['pins'].items());assert sha(Path(d['original_native_library']['path']))==d['original_native_library']['sha256']=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
assert d['private_core_changes']==['paint/renderers/rasterx/renderer.go'];assert all(sha(p/n)==h for n,h in d['private_core_shared_files'].items() if n not in d['private_core_changes']);assert not (p/'paint/pimage/uniform_fill.go').exists()
for name in ['observer-tests','offscreen','go-build']:
 receipt=load(q/(name+'-v2-receipt.json'));run=receipt['run'];assert run['exit_code']==0 and run['error'] is None and run['owned']['terminal'] and run['owned']['group_absent'] and run['pins_stable'] and run['logs_complete']
 for k,v in receipt['inputs'].items():assert sha(Path(k))==v,(name,k)
 for stream,e in run['logs'].items():assert sha(q/(name+'-v2')/stream)==e['sha256']
sys.path.insert(0,str(r/'scripts'));s=importlib.util.spec_from_file_location('native_raster_sdk',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS final native build/originalMetal/noexperiments,5observermethods/fullroutedpixeloracle,source/module/overlay/log/SDK8321pins;classifier3methods18refusals. No native execution or release qualification.')
