from pathlib import Path
import sys,os,json,time,hashlib
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
base=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go']; env=dict(os.environ,GOMAXPROCS='2',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOPROXY='off'); env.pop('GOFLAGS',None)
mode=sys.argv[1]
mod=['-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly']
args={
 'build-v2':base+['build',*mod,'-trimpath','-buildvcs=false','-o','/private/tmp/vellum-ready-native-5482f9b/bin/text-batch','.'],
 'focused':base+['test',*mod,'-race','-tags','offscreen','cogentcore.org/core/paint/renderers/sceneplan','cogentcore.org/core/paint/renderers/rasterx','github.com/dshills/vellum/drivers/cogent','-run','TestMaskResource|TestGlyphMaskResource|TestManagedGridPanePaint','-count=1','-v','-timeout=4m'],
 'full':base+['test',*mod,'-race','-tags','offscreen','github.com/dshills/vellum/drivers/cogent','-count=1','-timeout=8m'],
 'renderers':base+['test',*mod,'-race','-tags','offscreen','cogentcore.org/core/paint/renderers/sceneplan','cogentcore.org/core/paint/renderers/rasterx','cogentcore.org/core/paint/renderers/gpuscene','-count=1','-timeout=4m'],
 'vet':base+['vet',*mod,'-tags','offscreen','github.com/dshills/vellum/drivers/cogent','cogentcore.org/core/paint/renderers/sceneplan','cogentcore.org/core/paint/renderers/rasterx'],
}[mode]
started=time.monotonic()
with (W/(mode+'.stdout')).open('xb') as out,(W/(mode+'.stderr')).open('xb') as err:
 result=run_child(args,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=570)
record={'argv':args,'exit_code':result.returncode,'seconds':time.monotonic()-started};(W/(mode+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);sys.exit(result.returncode)
