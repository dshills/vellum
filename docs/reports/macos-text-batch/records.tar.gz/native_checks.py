from pathlib import Path
import _thread,importlib.util,json,os,sys,threading,time
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;STOP=W/'stop-native-checks';finished=threading.Event()
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
s=importlib.util.spec_from_file_location('live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py');l=importlib.util.module_from_spec(s);s.loader.exec_module(l)
def watch():
 while not finished.wait(.2):
  if STOP.exists():_thread.interrupt_main();return
argv=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go','test','-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly','-race','-tags','offscreen','cogentcore.org/core/paint/renderers/gpuscene','-run','TestVellumGPUSceneNative','-count=1','-v','-timeout=3m']
env=dict(os.environ,GOMAXPROCS='2',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOPROXY='off',VELLUM_GPU_SCENE_TEST='1');start=time.monotonic();d={'argv':argv,'result':'INCOMPLETE'}
try:
 assert not STOP.exists()
 with l.LiveLease():
  threading.Thread(target=watch,daemon=True).start()
  with (W/'native-checks.stdout').open('xb')as out,(W/'native-checks.stderr').open('xb')as err:result=run_child(argv,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=210)
  d.update(result='PASS' if result.returncode==0 else 'FAIL',exit_code=result.returncode)
except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
finally:
 finished.set();STOP.touch();d['seconds']=time.monotonic()-start;(W/'native-checks-command.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d),flush=True);sys.exit(0 if d['result']=='PASS' else 1)
