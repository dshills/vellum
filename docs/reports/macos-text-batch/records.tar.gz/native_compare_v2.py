"""One matched current-vs-workspace native workload, using the existing runner."""
from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,signal,subprocess,sys,threading
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent/'native-v2';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-ready-native-5482f9b');STOP=W/'stop-native'
sys.path.insert(0,str(T/'scripts'))
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('grid_scratch_comparison',T/'scripts/benchmark-grid.py');l=load('live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def require(ok,message):
 if not ok:raise ValueError(message)
def prepared():
 d={}
 for name in ['upstream','typesetting']:
  base=T/'drivers/cogent/build'/name
  for p in base.rglob('*'):
   require(not p.is_symlink(),'prepared symlink')
   if p.is_file():d[name+'/'+p.relative_to(base).as_posix()]=sha(p)
 return {'files':len(d),'sha256':hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
expected_diff=git(T,'diff','HEAD','--binary');source_hashes={n:sha(T/n) for n in ['drivers/cogent/grid_paint.go','drivers/cogent/grid_scroll.go']};pins={str(T/n):h for n,h in source_hashes.items()}
old=json.loads((W.parent.parent/'macos-frame-architecture-ae99e65/native-comparison.json').read_text()); commit=git(C,'rev-parse','HEAD').decode().strip()
binaries={'baseline':old['binaries']['candidate'],'candidate':{'path':str(P/'bin/text-batch'),'sha256':sha(P/'bin/text-batch')}}
d={'result':'INCOMPLETE','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_base':{'commit':commit},'candidate_scope':'Working-tree passive text batching and immutable bitmap-mask resources on 0c59fe0. Baseline reuses the previous verified pane-paint binary whose compiled driver leaves match committed 0c59fe0 and whose prepared stage0078 tree is unchanged. Candidate has stage0079 prepared source; no small-outline span or shader changes. Not a fresh clean historical baseline rebuild.','source_diff_sha256':hashlib.sha256(expected_diff).hexdigest(),'baseline_receipt_sha256':sha(W.parent.parent/'macos-frame-architecture-ae99e65/native-comparison.json'),'compiled_leaves':source_hashes,'binaries':binaries,'runtime_environment':{'GOMAXPROCS':os.environ.get('GOMAXPROCS'),'GOMEMLIMIT':os.environ.get('GOMEMLIMIT')},'runs_per_build':5,'samples_per_run':120,'warmup':128,'gpu_scene':True,'rows':10000,'variable':False,'error':None,'cases':{'baseline':{'runs':[]},'candidate':{'runs':[]}},'native_pointer_tested':False,'scope':'Ordinary native table UI-work experiment only; full table/tree/application/presentation/memory gates stay open.'}
finished=threading.Event()
def watch():
 while not finished.wait(.2):
  if STOP.exists():_thread.interrupt_main();return
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('comparison terminated')))
def boundary():
 require(not STOP.exists(),'stop requested')
 require(git(C,'rev-parse','HEAD').decode().strip()==commit and not git(C,'status','--porcelain'),'canonical clean identity')
 require(git(T,'rev-parse','HEAD').decode().strip()==commit and git(T,'diff','HEAD','--binary')==expected_diff,'candidate source identity')
 require(all(sha(p)==h for p,h in pins.items()),'compiled patch input changed')
 require(all(sha(v['path'])==v['sha256'] for v in binaries.values()),'native executable changed')
try:
 require(not (W/'native-comparison.json').exists() and not STOP.exists(),'fresh comparison')
 boundary();require(commit=='0c59fe0592512b57b2b28c1bda5c7c7cebf316af','baseline commit');changed={n for n in git(C,'diff','--name-only','ae99e65',commit,'--','drivers/cogent').decode().splitlines() if n.endswith('.go') and not n.endswith('_test.go')};require(changed==set(old['compiled_leaves']),'baseline runtime changes');require(all(sha(C/n)==h for n,h in old['compiled_leaves'].items()),'baseline compiled leaves');d['prepared_before']=prepared();require(old['prepared_after']=={'files':6253,'sha256':'a1c33459b8807abafda2a289e5c1ce1cca6dbcac7417231943b2ee306e0c74bf'},'baseline prepared dependencies'); require(d['prepared_before']['files']==6259,'candidate prepared file count');d['system_profiler_scope']='endpoint display inventory; no physical input or presentation timestamp evidence'
 with l.LiveLease():
  d['displays']=b.metadata_command(['system_profiler','SPDisplaysDataType','-json'],15)
  threading.Thread(target=watch,daemon=True).start();runs={'baseline':[],'candidate':[]}
  for repeat in range(5):
   for label in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
    boundary();directory=W/'native'/f'{repeat+1}-{label}'
    data,outcome=b.run_case(Path(binaries[label]['path']),directory,10000,False,120,128,False,180,gpu_scene_rendering=True)
    runs[label].append(data);stats=b.distribution([r['metrics']['ui_work_ns'] for r in data]);alloc=b.distribution([r['go_process_alloc_bytes'] for r in data])
    d['cases'][label]['runs'].append({'directory':str(directory),'exit_code':outcome['exit_code'],'log_sha256':outcome['log_sha256'],'ui_work_ns':stats,'go_process_alloc_bytes':alloc})
    print(json.dumps({'run':repeat+1,'build':label,'p95_ms':stats['p95']/1e6,'alloc_median':alloc['p50']}),flush=True)
   b.compare_geometry(runs['baseline'][-1],runs['candidate'][-1])
  for label in runs:
   d['cases'][label]['timings_ns']=b.summarize(runs[label]);d['cases'][label]['target_met']=b.warm_target_met({label:d['cases'][label]})
  d['diagnostics']={}
  for label in ['baseline','candidate']:
   boundary();directory=W/'source-details'/label
   data,outcome=b.run_case(Path(binaries[label]['path']),directory,10000,False,120,128,False,180,source_details=True,gpu_scene_rendering=True)
   hosts=[r['SceneHost'] for sample in data for r in sample['native_sample'].get('SourceDetails',{}).get('Records',[]) if r.get('SceneHost',{}).get('Available')]
   capture=[h for h in hosts if h['CaptureAttempted']]
   d['diagnostics'][label]={'scope':'Separate source-details diagnostic; never pooled into ordinary latency acceptance','directory':str(directory),'exit_code':outcome['exit_code'],'host_records':len(hosts),'capture_records':len(capture),'accepted_records':sum(h['DrawAccepted'] for h in hosts),'fallback_records':sum(h['Fallback'] for h in hosts),'reuse_records':sum(h['Reused'] for h in hosts),'capture_ns':b.distribution([h['CaptureNS'] for h in capture]),'encode_ns':b.distribution([h['EncodeNS'] for h in capture]),'logical_input_bytes':b.distribution([h['LogicalInputBytes'] for h in capture]),'layout_paint_ns':b.distribution([sample['native_sample']['LayoutPaintNS'] for sample in data])}
   print(json.dumps({'diagnostic':label,**d['diagnostics'][label]}),flush=True)
   require(len(capture)>=120 and all(h['DrawAccepted'] and not h['Fallback'] for h in hosts),'diagnostic GPU route coverage')
  boundary();d['prepared_after']=prepared();require(d['prepared_before']==d['prepared_after'],'prepared tree changed')
  d['result']='MEASURED';d['candidate_target_met']=d['cases']['candidate']['target_met']
except BaseException as e:d['result']='FAILED_OR_CANCELED';d['error']={'type':type(e).__name__,'message':str(e)}
finally:
 finished.set();STOP.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (W/'native-comparison.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'candidate_target_met':d.get('candidate_target_met'),'error':d['error']}),flush=True)
if d['error']:sys.exit(1)
