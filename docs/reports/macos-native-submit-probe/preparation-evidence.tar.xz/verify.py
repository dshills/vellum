from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((q/'build.json').read_text());assert h(q/'native')==b['binary_sha256'];assert h(q/'match.json')==b['match_sha256'];assert (q/'match.json').read_bytes()==(q.parent/'macos-matched-calibration-v3/match.json').read_bytes()
for p in ['tools/macos-calibration','tools/macos-calibration/submit']:
 subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',p,'-p','check_test.py'],cwd=t,check=True)
for p in (t/'tools/macos-calibration/submit').glob('*.py'):compile(p.read_text(),str(p),'exec')
assert (t/'docs/reports/macos-native-submit-probe/source-audit.json').read_bytes()==(q/'source-audit.json').read_bytes()
print('Preparation controls, match reuse, binary and audit identity verified; no live claim.')
