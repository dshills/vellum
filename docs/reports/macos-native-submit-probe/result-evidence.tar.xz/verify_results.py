from pathlib import Path
import json,hashlib,sys,importlib.util,datetime,tarfile
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-native-submit-probe'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
v=module('submit_validator',T/'tools/macos-calibration/submit/check.py');a=module('submit_integrity',P.parent/'macos-release-default-assessment/assessment.py')
plan=load(P/'bound-plan.json');assert all(sha(Path(p))==h for p,h in plan['pins'].items());assert a.sdk_vector()==load(P.parent/'macos-release-default-assessment/plan.json')['sdk']
result=load(P/'result.json');assert result['outcome']=='THREE_VALID_NATIVE_SUBMISSION_PAIRS' and len(result['cases'])==6
match=load(P/'match.json');assert (P/'match.json').read_bytes()==(P.parent/'macos-matched-calibration-v3/match.json').read_bytes()
start=datetime.datetime.fromisoformat(load(P/'started.json')['started_utc']);finish=datetime.datetime.fromisoformat(result['finished_utc']);assert (finish-start).total_seconds()<240
assert [(c['pair'],c['kind']) for c in result['cases']]==[(i,k) for i,order in enumerate(plan['pairs'],1) for k in order]
pairs={};commands=0
for c in result['cases']:
 root=P/f"pair{c['pair']}-{c['kind']}";doc=v.base.native_doc(v.base.load(root/'native/stdout'))
 actual=v.validate(doc,match,c['kind']);assert actual==c['validation']==load(root/'validation.json');assert c['geometry_before']==c['geometry_after']
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,root/folder/key) for key,cmd in c[phase].items())
 for key in c['configuration_before']:assert c['configuration_before'][key]['logs']['stdout']['sha256']==c['configuration_after'][key]['logs']['stdout']['sha256']
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['pins_stable'] and cmd['logs_complete'] and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['logs']['stderr']['bytes']==0
  for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
  commands+=1
 pairs.setdefault(c['pair'],{})[c['kind']]=actual
assert commands==54 and all(set(p)=={'combined','split'} for p in pairs.values())
summary=load(P/'summary.json');assert summary['warmup_states']==768 and summary['measured_states']==720 and summary['retained_zero_startup_feedback']==12
for row in summary['runs']:assert row['metrics']==pairs[row['pair']][row['mode']]
for row in summary['differences_of_run_p95_values']:assert row['split_minus_combined_p95_ms']==pairs[row['pair']]['split']['receipt_to_present_ms']['p95']-pairs[row['pair']]['combined']['receipt_to_present_ms']['p95']
assert not summary['release_gate_changed'] and not summary['framework_qualified'] and not summary['OS_latency_floor_proven']
for name in ['preparation','result']:
 index=R/(name+'-evidence-index.json');archive=R/(name+'-evidence.tar.xz')
 if not index.exists():continue
 idx=load(index);assert sha(archive)==idx['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(idx['files'])
  for n,d in idx['files'].items():b=tf.extractfile(n).read();assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
print('PASS: 3 predeclared native pairs;768 warmups+720 measured;54 owned groups retired;SDK8321/source/binary/match/log pins;strict CPU/GPU/presentation validation;configuration/geometry unchanged;188.417s<240;exact arithmetic;archives verified;no SDK/gate/qualification change')
