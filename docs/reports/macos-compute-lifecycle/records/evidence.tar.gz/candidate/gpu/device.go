// Copyright (c) 2022, Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gpu

import (
	"fmt"
	"sync"

	"cogentcore.org/core/base/errors"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// Device holds Device and associated Queue info.
// A Device is a usable instance of the GPU Adapter hardware.
// Each device has one Queue.
type Device struct {
	// logical device
	Device *wgpu.Device

	// queue for device
	Queue *wgpu.Queue

	// Shared by borrowed Device copies; loss observers never retain GPU resources.
	health *deviceHealth
}

// NewDevice returns a new device for given GPU.
// It gets the Queue for this device.
func NewDevice(gpu *GPU) (*Device, error) {
	health := &deviceHealth{}
	wdev, err := gpu.GPU.RequestDevice(&wgpu.DeviceDescriptor{DeviceLostCallback: health.callback})
	if errors.Log(err) != nil {
		return nil, err
	}
	dev := &Device{Device: wdev, health: health}
	dev.Queue = wdev.GetQueue()
	return dev, nil
}

// NewComputeDevice returns a new device for given GPU,
// for compute functionality, which requests maximum buffer sizes.
// It gets the Queue for this device.
func NewComputeDevice(gpu *GPU) (*Device, error) {
	// we only request max buffer sizes so compute can go as big as it needs to
	limits := wgpu.DefaultLimits()
	// Per https://github.com/cogentcore/core/issues/1362 -- this may cause issues on "downlevel"
	// hardware, so we may need to detect that. OTOH it probably won't be useful for compute anyway,
	// but we can just sort that out later
	// note: on web / chromium / dawn, limited to 10: https://issues.chromium.org/issues/366151398?pli=1
	limits.MaxStorageBuffersPerShaderStage = gpu.Limits.MaxStorageBuffersPerShaderStage
	// fmt.Println("MaxStorageBuffersPerShaderStage:", gpu.Limits.MaxStorageBuffersPerShaderStage)
	// note: these limits are being processed and allow the MaxBufferSize to be the
	// controlling factor -- if we don't set these, then the slrand example doesn't
	// work above a smaller limit.
	// TODO: converting these limits to int may cause issues on 32-bit systems
	limits.MaxUniformBufferBindingSize = uint64(MemSizeAlignDown(int(gpu.Limits.MaxUniformBufferBindingSize), int(gpu.Limits.MinUniformBufferOffsetAlignment)))

	limits.MaxStorageBufferBindingSize = uint64(MemSizeAlignDown(int(gpu.Limits.MaxStorageBufferBindingSize), int(gpu.Limits.MinStorageBufferOffsetAlignment)))
	// note: this limit is not working properly:
	g4 := uint64(0xFFFFFF00)
	limits.MaxBufferSize = uint64(MemSizeAlignDown(int(min(gpu.Limits.MaxBufferSize, g4)), int(gpu.Limits.MinStorageBufferOffsetAlignment)))
	if limits.MaxBufferSize == 0 {
		limits.MaxBufferSize = g4
	}
	// limits.MaxBindGroups = gpu.Limits.MaxBindGroups // note: no point in changing -- web constraint

	if Debug {
		fmt.Printf("Requesting sizes: MaxStorageBufferBindingSize: %X  MaxBufferSize: %X\n", limits.MaxStorageBufferBindingSize, limits.MaxBufferSize)
	}
	health := &deviceHealth{}
	desc := wgpu.DeviceDescriptor{
		DeviceLostCallback: health.callback,
		RequiredLimits:     &limits,
	}
	wdev, err := gpu.GPU.RequestDevice(&desc)
	if errors.Log(err) != nil {
		return nil, err
	}
	dev := &Device{Device: wdev, health: health}
	dev.Queue = wdev.GetQueue()
	return dev, nil
}

// Release is serialized by the resource owner after all users have stopped.
// GetQueue owns a WebGPU reference independently of the device. Complete work
// before releasing both owned handles; no deferred callback retains this Device.
func (dv *Device) Release() {
	device, queue := dv.Device, dv.Queue
	dv.Device, dv.Queue = nil, nil
	if device != nil {
		defer device.Release()
	}
	if queue != nil {
		defer queue.Release()
	}
	if device.IsValid() {
		device.Poll(true, nil)
	}
}

// WaitDoneFunc waits until the device is idle and then calls
// given function, if the device is ready. If it is in some other
// bad state, that generates a panic.
func (dv *Device) WaitDoneFunc(fun func()) {
	dv.Queue.OnSubmittedWorkDone(func(stat wgpu.QueueWorkDoneStatus) {
		if stat == wgpu.QueueWorkDoneStatusSuccess {
			fun()
			return
		}
		panic("Device.WaitDoneFunc: bad queue status: " + stat.String())
	})
}

// WaitDone does a blocking wait until the device is done with current work.
func (dv *Device) WaitDone() {
	if dv.Device == nil {
		return
	}
	dv.Device.Poll(true, nil)
}

// deviceHealth transfers spontaneous device loss without entering native locks.
type deviceHealth struct {
	mu        sync.Mutex
	lost      error
	next      uint64
	observers map[uint64]func(error)
}

func (h *deviceHealth) callback(reason wgpu.DeviceLostReason, message string) {
	if reason == wgpu.DeviceLostReasonDestroyed {
		return
	}
	h.fail(fmt.Errorf("WebGPU device lost (%s): %s", reason, message))
}
func (h *deviceHealth) fail(err error) {
	h.mu.Lock()
	if h.lost != nil {
		h.mu.Unlock()
		return
	}
	h.lost = err
	callbacks := make([]func(error), 0, len(h.observers))
	for _, f := range h.observers {
		callbacks = append(callbacks, f)
	}
	h.observers = nil
	h.mu.Unlock()
	for _, f := range callbacks {
		f(err)
	}
}

// LossError returns the first unexpected loss, including through borrowed copies.
func (dv *Device) LossError() error {
	if dv == nil || dv.health == nil {
		return nil
	}
	dv.health.mu.Lock()
	defer dv.health.mu.Unlock()
	return dv.health.lost
}

// ObserveLoss registers a nonblocking callback. It may run on a foreign GPU
// thread, including before this function returns. Cancel unregisters future
// notifications but cannot recall a callback already copied for delivery.
func (dv *Device) ObserveLoss(f func(error)) func() {
	if dv == nil || dv.health == nil || f == nil {
		return func() {}
	}
	h := dv.health
	h.mu.Lock()
	if h.lost != nil {
		err := h.lost
		h.mu.Unlock()
		f(err)
		return func() {}
	}
	h.next++
	id := h.next
	if h.observers == nil {
		h.observers = map[uint64]func(error){}
	}
	h.observers[id] = f
	h.mu.Unlock()
	return func() { h.mu.Lock(); delete(h.observers, id); h.mu.Unlock() }
}
