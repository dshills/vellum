// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import "fmt"

// prepareComputeRecording publishes only a complete live pair. Factories return
// fresh owned references; caller serializes recording, submission and retirement.
func prepareComputeRecording[C liveOwnedReference, P liveOwnedReference](command func() (C, error), pass func(C) (P, error)) (c C, p P, err error) {
	var zeroC C
	var zeroP P
	succeeded := false
	defer func() {
		if succeeded {
			return
		}
		oldC, oldP := c, p
		c, p = zeroC, zeroP
		retireComputeRecording(oldC, oldP)
	}()
	c, err = command()
	if err != nil {
		return
	}
	if c == zeroC || !c.IsValid() {
		err = fmt.Errorf("gpu: compute command factory returned no live encoder")
		return
	}
	p, err = pass(c)
	if err != nil {
		return
	}
	if p == zeroP || !p.IsValid() {
		err = fmt.Errorf("gpu: compute pass factory returned no live encoder")
		return
	}
	succeeded = true
	return
}

// Discard a pending recording without Finish or Submit, pass before command.
func retireComputeRecording[C ownedReference, P ownedReference](command C, pass P) {
	var zeroC C
	var zeroP P
	if command != zeroC {
		defer command.Release()
	}
	if pass != zeroP {
		pass.Release()
	}
}
