// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"github.com/oliverbestmann/webgpu/wgpu"
	"testing"
)

// Original-compatible owner entry points; no native device or fake handles.
func TestVellumComputeEmptyEndAndRepeatedRetirement(t *testing.T) {
	sy := &ComputeSystem{}
	func() {
		defer func() {
			if value := recover(); value != nil {
				t.Errorf("empty End panicked instead of refusing: %v", value)
			}
		}()
		if err := sy.EndComputePass(); err == nil {
			t.Error("empty submission accepted")
		}
	}()
	func() {
		defer func() {
			if value := recover(); value != nil {
				t.Errorf("empty Release panicked: %v", value)
			}
		}()
		sy.Release()
		sy.Release()
		sy.WaitDone()
	}()
	if sy.ComputeEncoder != nil || sy.CommandEncoder != nil || sy.Device() != nil || sy.GPU() != nil {
		t.Fatal("empty owner retained resources")
	}
}

func TestVellumPartialDeviceReleaseClearsQueueWithoutDevice(t *testing.T) {
	queue := &wgpu.Queue{}
	dev := &Device{Queue: queue}
	dev.Release()
	if dev.Queue != nil || dev.Device != nil {
		t.Fatal("empty device retained independently owned queue")
	}
	dev.Release()
}
