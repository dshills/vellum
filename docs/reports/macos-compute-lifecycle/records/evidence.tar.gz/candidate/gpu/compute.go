// Copyright (c) 2024, Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gpu

import (
	"fmt"
	"math"
	"runtime"
	"sync"

	"cogentcore.org/core/base/errors"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// ComputeSystem manages a system of ComputePipelines that all share
// a common collection of Vars and Values.
type ComputeSystem struct {
	// optional name of this ComputeSystem
	Name string

	// vars represents all the data variables used by the system,
	// with one Var for each resource that is made visible to the shader,
	// indexed by Group (@group) and Binding (@binding).
	// Each Var has Value(s) containing specific instance values.
	// Access through the System.Vars() method.
	vars Vars

	// ComputePipelines by name.
	ComputePipelines map[string]*ComputePipeline

	// ComputeEncoder is the compute specific command encoder for the
	// current [BeginComputePass], and released in [EndComputePass].
	ComputeEncoder *wgpu.ComputePassEncoder

	// CommandEncoder is the command encoder created in
	// [BeginComputePass], and released in [EndComputePass].
	CommandEncoder *wgpu.CommandEncoder

	// logical device for this ComputeSystem, which we own.
	device *Device

	// gpu is our GPU device, which has properties
	// and alignment factors.
	gpu *GPU
}

// NewComputeSystem returns a new ComputeSystem, initialized with
// its own new device that is owned by the system.
func NewComputeSystem(gp *GPU, name string) *ComputeSystem {
	return errors.Log1(NewComputeSystemChecked(gp, name))
}

// System interface:

func (sy *ComputeSystem) Vars() *Vars     { return &sy.vars }
func (sy *ComputeSystem) Device() *Device { return sy.device }
func (sy *ComputeSystem) GPU() *GPU       { return sy.gpu }
func (sy *ComputeSystem) Render() *Render { return nil }

// NewComputeSystemChecked refuses failed private-device admission without
// publishing a partial system. The GPU is borrowed; the new device is owned.
func NewComputeSystemChecked(gp *GPU, name string) (*ComputeSystem, error) {
	if gp == nil || !gp.GPU.IsValid() {
		return nil, fmt.Errorf("gpu: compute system requires a live adapter")
	}
	dev, err := NewComputeDevice(gp)
	if err != nil || dev == nil || !dev.Device.IsValid() || !dev.Queue.IsValid() {
		if dev != nil {
			dev.Release()
		}
		if err == nil {
			err = fmt.Errorf("gpu: compute device admission returned no live pair")
		}
		return nil, err
	}
	sy := &ComputeSystem{Name: name, gpu: gp, device: dev, ComputePipelines: make(map[string]*ComputePipeline)}
	sy.vars.device = *dev
	sy.vars.sys = sy
	return sy, nil
}

// WaitDone waits until this system's private device has completed work.
func (sy *ComputeSystem) WaitDone() {
	if sy.device != nil && sy.device.Device.IsValid() {
		sy.device.WaitDone()
	}
}

// Release requires serialized owner access after all other users have stopped.
// Active recording is abandoned, never submitted. The adapter remains borrowed.
// Detach ownership first so repeated shutdown cannot retire references twice.
func (sy *ComputeSystem) Release() {
	dev, pass, command := sy.device, sy.ComputeEncoder, sy.CommandEncoder
	pipelines, vars := sy.ComputePipelines, sy.vars
	sy.device, sy.ComputeEncoder, sy.CommandEncoder = nil, nil, nil
	sy.ComputePipelines, sy.gpu, sy.vars = nil, nil, Vars{}
	if dev != nil {
		defer dev.Release()
	}
	retireComputeRecording(command, pass)
	if dev != nil && dev.Device.IsValid() {
		dev.WaitDone()
	}
	for _, pl := range pipelines {
		pl.Release()
	}
	vars.Release()
}

// AddComputePipeline adds a new ComputePipeline to the system
func (sy *ComputeSystem) AddComputePipeline(name string) *ComputePipeline {
	pl := NewComputePipeline(name, sy)
	sy.ComputePipelines[pl.Name] = pl
	return pl
}

// Config configures the entire system, after Pipelines and Vars
// have been initialized.  After this point, just need to set
// values for the vars, and then do compute passes.  This should
// not need to be called more than once.
func (sy *ComputeSystem) Config() {
	sy.vars.Config(sy.device)
	if Debug {
		fmt.Printf("%s\n", sy.vars.StringDoc())
	}
	for _, pl := range sy.ComputePipelines {
		pl.Config(true)
	}
}

// NewCommandEncoder returns a new CommandEncoder for encoding
// compute commands.  This is automatically called by
// BeginRenderPass and the result maintained in [CommandEncoder].
func (sy *ComputeSystem) NewCommandEncoder() (*wgpu.CommandEncoder, error) {
	if sy.device == nil || !sy.device.Device.IsValid() || !sy.device.Queue.IsValid() {
		return nil, fmt.Errorf("gpu: compute system has no live device and queue")
	}
	cmd, err := sy.device.Device.TryCreateCommandEncoder(nil)
	if err != nil {
		if cmd != nil {
			cmd.Release()
		}
		return nil, errors.Log(err)
	}
	if !cmd.IsValid() {
		if cmd != nil {
			cmd.Release()
		}
		return nil, fmt.Errorf("gpu: command factory returned no live encoder")
	}
	return cmd, nil
}

// BeginComputePass adds commands to the given command buffer
// to start the compute pass, returning the encoder object
// to which further compute commands should be added.
// Call [EndComputePass] when done.
// If an existing [ComputeSystem.ComputeEncoder] is already set from
// a prior BeginComputePass call, then that is returned, so this
// is safe and efficient to call for every compute shader dispatch,
// where the first call will create and the rest add to the ongoing job.
func (sy *ComputeSystem) BeginComputePass() (*wgpu.ComputePassEncoder, error) {
	if sy.ComputeEncoder != nil || sy.CommandEncoder != nil {
		if sy.ComputeEncoder.IsValid() && sy.CommandEncoder.IsValid() {
			return sy.ComputeEncoder, nil
		}
		command, pass := sy.CommandEncoder, sy.ComputeEncoder
		sy.CommandEncoder, sy.ComputeEncoder = nil, nil
		retireComputeRecording(command, pass)
		return nil, fmt.Errorf("gpu: compute recording contains retired references")
	}
	command, pass, err := prepareComputeRecording(sy.NewCommandEncoder, func(c *wgpu.CommandEncoder) (*wgpu.ComputePassEncoder, error) {
		return c.BeginComputePass(nil), nil
	})
	if err != nil {
		return nil, errors.Log(err)
	}
	sy.CommandEncoder, sy.ComputeEncoder = command, pass
	return pass, nil
}

// EndComputePass submits the current compute commands and retires all recording
// references on success or refusal. The caller must call ce.End before this.
// Copy commands may be inserted after ce.End and before submission.
func (sy *ComputeSystem) EndComputePass() error {
	ce, cmd := sy.ComputeEncoder, sy.CommandEncoder
	livePair := ce.IsValid() && cmd.IsValid()
	sy.ComputeEncoder, sy.CommandEncoder = nil, nil
	defer func() {
		for _, pl := range sy.ComputePipelines {
			pl.releaseOldBindGroups()
		}
	}()
	return errors.Log(submitOwnedPass(cmd, ce, func(c *wgpu.CommandEncoder) (*wgpu.CommandBuffer, error) {
		if !livePair || !c.IsValid() || sy.device == nil || !sy.device.Device.IsValid() || !sy.device.Queue.IsValid() {
			return nil, fmt.Errorf("gpu: compute submission requires live owner references")
		}
		return c.TryFinish(nil)
	}, func(buffer *wgpu.CommandBuffer) { sy.device.Queue.Submit(buffer) }))
}

// NumThreads is the number of threads to use for parallel threading,
// in the [VectorizeFunc] that is used for CPU versions of GPU functions.
// The default of 0 causes the [runtime.GOMAXPROCS] to be used.
var NumThreads = 0

// DefaultNumThreads returns the default number of threads to use:
// NumThreads if non-zero, otherwise [runtime.GOMAXPROCS].
func DefaultNumThreads() int {
	if NumThreads > 0 {
		return NumThreads
	}
	return runtime.GOMAXPROCS(0)
}

// VectorizeFunc runs given GPU kernel function taking a uint32 index
// on the CPU, using given number of threads with goroutines, for n iterations.
// If threads is 0, then GOMAXPROCS is used.
func VectorizeFunc(threads, n int, fun func(idx uint32)) {
	if threads == 0 {
		threads = DefaultNumThreads()
	}
	if threads <= 1 {
		for idx := range n {
			fun(uint32(idx))
		}
		return
	}
	nper := int(math.Ceil(float64(n) / float64(threads)))
	wait := sync.WaitGroup{}
	for start := 0; start < n; start += nper {
		end := start + nper
		if end > n {
			end = n
		}
		wait.Add(1)
		go func() {
			for idx := start; idx < end; idx++ {
				fun(uint32(idx))
			}
			wait.Done()
		}()
	}
	wait.Wait()
}
