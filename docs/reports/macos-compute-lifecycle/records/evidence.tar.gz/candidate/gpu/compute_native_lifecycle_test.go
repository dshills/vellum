// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

//go:build !js

package gpu

import (
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"testing"
)

// Tiny opt-in native ownership check. No windows, surfaces, input, presentation,
// timings or physical-memory assertions. Old wrappers stay live in Go.
func TestVellumComputeNativeOwnership(t *testing.T) {
	if os.Getenv("VELLUM_COMPUTE_GPU_TEST") != "1" {
		t.Skip("explicit headless compute fixture required")
	}
	var gp *GPU
	var borrowed *Device
	defer func() {
		if borrowed != nil {
			borrowed.Release()
		}
		if gp != nil {
			gp.Release()
		}
		ReleaseInstance()
	}()
	var err error
	gp, borrowed, err = NoDisplayGPU()
	if err != nil || gp == nil || borrowed == nil {
		t.Fatal("headless admission", err)
	}
	record := func(fields map[string]any) {
		fields["windows_created"] = 0
		fields["surfaces_created"] = 0
		b, e := json.Marshal(fields)
		if e != nil {
			t.Fatal(e)
		}
		fmt.Printf("VELLUM_COMPUTE_NATIVE %s\n", b)
	}
	t.Run("private_device_and_active_recording", func(t *testing.T) {
		sy := NewComputeSystem(gp, "native ownership")
		if sy == nil {
			t.Fatal("compute admission")
		}
		owned := sy.Device()
		defer func() {
			defer owned.Release()
			// Fallback for the original-regression build: retire recording before
			// its device if the original system leaves it owned after Release.
			defer retireComputeRecording(sy.CommandEncoder, sy.ComputeEncoder)
			sy.Release()
		}()
		device, queue := owned.Device, owned.Queue
		if device == borrowed.Device {
			t.Fatal("private device is shared")
		}
		group := sy.Vars().AddGroup(Storage)
		variable := group.Add("Values", Uint32, 4, ComputeShader)
		group.SetNValues(1)
		pipeline := sy.AddComputePipeline("increment")
		shader := pipeline.AddShader("increment")
		if err := shader.OpenCode(`@group(0) @binding(0) var<storage,read_write> data: array<u32,4>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id: vec3<u32>) { data[id.x] = data[id.x] + 1u; }`); err != nil {
			t.Fatal(err)
		}
		pipeline.AddEntry(shader, ComputeShader, "main")
		sy.Config()
		value := variable.Values.Values[0]
		if err := SetValueFrom(value, []uint32{3, 11, 17, 29}); err != nil {
			t.Fatal(err)
		}
		buffer, staging, module, program := value.buffer, value.readBuffer, shader.module, pipeline.computePipeline
		if !buffer.IsValid() || !staging.IsValid() || !module.IsValid() || !program.IsValid() {
			t.Fatal("native pipeline fixture incomplete")
		}
		for i := 0; i < 8; i++ {
			pass, e := sy.BeginComputePass()
			if e != nil {
				t.Fatal(e)
			}
			command := sy.CommandEncoder
			again, e := sy.BeginComputePass()
			if e != nil || again != pass || sy.CommandEncoder != command {
				t.Fatal("pending pass not reused", e)
			}
			if e := pipeline.Dispatch(pass, 4, 1, 1); e != nil {
				t.Fatal(e)
			}
			pass.End()
			if e := value.GPUToRead(command); e != nil {
				t.Fatal(e)
			}
			if e = sy.EndComputePass(); e != nil {
				t.Fatal(e)
			}
			result := make([]uint32, 4)
			if e := value.ReadSync(); e != nil {
				t.Fatal(e)
			}
			if e := ReadToBytes(value, result); e != nil {
				t.Fatal(e)
			}
			want := []uint32{uint32(4 + i), uint32(12 + i), uint32(18 + i), uint32(30 + i)}
			if !reflect.DeepEqual(result, want) {
				t.Fatal("compute output", result, want)
			}
			if pass.IsValid() || command.IsValid() || sy.ComputeEncoder != nil || sy.CommandEncoder != nil {
				t.Fatal("submitted recording retained references", i)
			}
		}
		sy.WaitDone()
		bindings := pipeline.currentBindGroups
		if len(bindings) != 1 {
			t.Fatal("native binding fixture incomplete")
		}
		active, e := sy.BeginComputePass()
		if e != nil {
			t.Fatal(e)
		}
		pending := sy.CommandEncoder
		sy.Release()
		for _, binding := range bindings {
			if binding.IsValid() {
				t.Fatal("pipeline retained binding")
			}
		}
		if buffer.IsValid() || staging.IsValid() || module.IsValid() || program.IsValid() || value.buffer != nil || value.readBuffer != nil {
			t.Fatal("compute children not retired")
		}
		if active.IsValid() || pending.IsValid() || device.IsValid() || queue.IsValid() || owned.Device != nil || owned.Queue != nil || sy.Device() != nil || sy.GPU() != nil {
			t.Fatal("private compute ownership not retired")
		}
		sy.Release()
		if !gp.GPU.IsValid() || !borrowed.Device.IsValid() || !borrowed.Queue.IsValid() {
			t.Fatal("compute shutdown retired borrowed adapter/device")
		}
		if pass, e := sy.BeginComputePass(); e == nil || pass != nil {
			t.Fatal("retired system admitted recording", e)
		}
		if e := sy.EndComputePass(); e == nil {
			t.Fatal("retired system accepted submission")
		}
		record(map[string]any{"case": "private_device_and_active_recording", "submitted_passes": 8, "computed_words_checked": 32, "retired_child_refs": 5, "retired_recording_refs": 18, "retired_device_refs": 2, "borrowed_owner_live": true})
	})
	t.Run("partial_device_queue", func(t *testing.T) {
		dev, e := NewDevice(gp)
		if e != nil {
			t.Fatal(e)
		}
		defer dev.Release()
		queue, device := dev.Queue, dev.Device
		device.Release() // Keep the independently owned GetQueue reference live.
		if !queue.IsValid() || device.IsValid() {
			t.Fatal("fixture failed partial state")
		}
		dev.Release()
		if queue.IsValid() || dev.Queue != nil || dev.Device != nil {
			t.Fatal("partial device retained queue reference")
		}
		dev.Release()
		record(map[string]any{"case": "partial_device_queue", "retired_queue_refs": 1})
	})
}
