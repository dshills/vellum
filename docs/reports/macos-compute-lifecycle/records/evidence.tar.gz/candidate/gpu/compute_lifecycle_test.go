// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"errors"
	"reflect"
	"testing"
)

type computeReference struct {
	name     string
	valid    bool
	releases int
	events   *[]string
}

func (r *computeReference) IsValid() bool { return r != nil && r.valid }
func (r *computeReference) Release() {
	r.releases++
	r.valid = false
	*r.events = append(*r.events, r.name)
}

func TestVellumComputeRecordingAdmission(t *testing.T) {
	failure := errors.New("injected compute admission refusal")
	for _, scenario := range []string{"command_error", "partial_command", "nil_command", "invalid_command", "pass_error", "partial_pass", "nil_pass", "invalid_pass", "success"} {
		t.Run(scenario, func(t *testing.T) {
			events := []string{}
			c := &computeReference{name: "command", valid: true, events: &events}
			p := &computeReference{name: "pass", valid: true, events: &events}
			called := 0
			gotC, gotP, err := prepareComputeRecording(func() (*computeReference, error) {
				switch scenario {
				case "command_error":
					return nil, failure
				case "partial_command":
					return c, failure
				case "nil_command":
					return nil, nil
				case "invalid_command":
					c.valid = false
				}
				return c, nil
			}, func(*computeReference) (*computeReference, error) {
				called++
				switch scenario {
				case "pass_error":
					return nil, failure
				case "partial_pass":
					return p, failure
				case "nil_pass":
					return nil, nil
				case "invalid_pass":
					p.valid = false
				}
				return p, nil
			})
			if scenario == "success" {
				if err != nil || gotC != c || gotP != p || len(events) != 0 {
					t.Fatal("complete pair not retained", err, events)
				}
				retireComputeRecording(gotC, gotP)
			} else if err == nil || gotC != nil || gotP != nil {
				t.Fatal("partial pair published", err, gotC, gotP)
			}
			want := []string{}
			switch scenario {
			case "partial_command", "invalid_command", "pass_error", "nil_pass":
				want = []string{"command"}
			case "partial_pass", "invalid_pass", "success":
				want = []string{"pass", "command"}
			}
			if !reflect.DeepEqual(events, want) || c.releases > 1 || p.releases > 1 {
				t.Fatal("retirement order/count", events, want)
			}
			if called > 0 && (scenario == "command_error" || scenario == "partial_command" || scenario == "nil_command" || scenario == "invalid_command") {
				t.Fatal("partial command reached pass factory")
			}
		})
	}
}

func TestVellumCheckedComputeConstructorRefusesMissingAdapter(t *testing.T) {
	for _, gp := range []*GPU{nil, {}} {
		sy, err := NewComputeSystemChecked(gp, "refused")
		if err == nil || sy != nil {
			t.Fatal("partial system published", sy, err)
		}
	}
}

func TestVellumComputeAdmissionPanicRetiresAcquiredCommand(t *testing.T) {
	events := []string{}
	c := &computeReference{name: "command", valid: true, events: &events}
	func() {
		defer func() {
			if recover() == nil {
				t.Error("injected panic absent")
			}
		}()
		prepareComputeRecording(func() (*computeReference, error) { return c, nil }, func(*computeReference) (*computeReference, error) { panic("pass factory") })
	}()
	if c.releases != 1 || c.valid {
		t.Fatal("acquired command survived pass factory panic")
	}
}
