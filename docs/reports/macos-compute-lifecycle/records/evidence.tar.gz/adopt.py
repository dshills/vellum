import difflib,hashlib,json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-compute-lifecycle');driver=r/'drivers/cogent';stage=driver/'native/patches/computelifecycle';stage.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={};outputs={};diff=[]
for f in sorted((p/'candidate/gpu').glob('*.go')):
 n='gpu/'+f.name;oldpath=driver/'build/upstream'/n;old=oldpath.read_bytes()if oldpath.is_file()else b'';new=f.read_bytes();inputs[n]=sha(old)if old else None;outputs[n]=sha(new)
 diff.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
name='0050-owned-compute-device-and-recording.patch';data=''.join(diff).encode();(stage/name).write_bytes(data)
for n,v in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (stage/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=driver/'native/dependencies.json';m=json.loads(manifest.read_text());prefix='native/patches/computelifecycle';assert not any(s['inputs']==prefix+'/original-hashes.json'for s in m['dependencies'][0]['stages']);m['dependencies'][0]['stages'].append({'origin':'drivers/cogent/'+prefix,'inputs':prefix+'/original-hashes.json','outputs':prefix+'/output-hashes.json','patches':[{'file':prefix+'/'+name,'sha256':sha(data)}]});manifest.write_text(json.dumps(m,indent=2)+'\n')
f=driver/'prepare_test.py';s=f.read_text();assert s.count('list(range(1, 50))')==1;f.write_text(s.replace('list(range(1, 50))','list(range(1, 51))'))
(stage/'README.md').write_text('''# Compute device and recording ownership

Patch 0050 closes ComputeSystem's private device and queue at shutdown while
preserving the borrowed GPU adapter. Serialized Release detaches owner fields,
abandons pending recording, completes prior work, retires pipelines/values and
then retires the device. Empty/repeated shutdown is safe. GraphicsSystem retains
its separate borrowed-device contract.

NewComputeSystemChecked refuses missing/invalid adapters and incomplete device
admission. The legacy constructor logs a refusal and returns nil. Pass admission
publishes only a complete live pair; a partial or refused factory result retires
acquired references. The pinned native BeginComputePass has no Try API and can
panic. Acquired command cleanup unwinds then, but native panics are not converted
to returned errors. No broad panic/resource-recovery guarantee is added.

EndComputePass still requires caller End. It detaches recording, releases the pass
before Finish, and uses patch48's submission helper to retire command/buffer on
success or refusal. Old bind groups retire on both paths. Abandoned recordings
are never submitted. Device.Release detaches and releases Queue independently of
Device, polling only a live device; a partial queue cannot survive an early return.

Original-compatible empty-End/Release and partial-device tests fail on the prior
implementation. Nine counted admission scenarios and panic unwind verify cleanup.
Opt-in tiny headless checks exercise real shader output, submitted/abandoned
recordings, private device retirement, child resources and borrowed-owner liveness.
Those checks do not qualify native/GPU heap reclamation, physical device loss,
window presentation, sustained workloads or performance. Modified upstream notices
remain BSD-style; new tests/helper are MIT. Inputs/outputs and patch are hash-pinned.
''')
f=r/'specs/gpu-frame-lifecycle.md';s=f.read_text();s+='''
## Private compute-system ownership

A ComputeSystem borrows its GPU adapter and owns its separately requested device
and queue. NewComputeSystemChecked returns no partial system on adapter/device
refusal; the legacy constructor logs and returns nil. Owner-serialized shutdown
first detaches all system state, abandons pending recording, completes prior work,
retires pipelines/values and then releases the private device/queue. Empty and
repeated shutdown are safe. GraphicsSystem still borrows its renderer's device.

Compute recording admits a complete live command/pass pair. Partial/refused
factories retire acquired references. The pinned native BeginComputePass can
panic; cleanup unwinds but does not convert that panic to a returned error.
Submission requires caller End, detaches the recording, releases pass before
Finish and retires command/buffer on success/refusal. Failure never reaches the
queue, and old bind groups retire on both paths. Shutdown never submits pending
recording. No broad panic recovery or concurrent-owner contract is added.

Device.Release clears ownership before cleanup and releases its independently
owned GetQueue reference even when the device is missing/invalid. Polling requires
a live device. Wrapper retirement and small headless shader-output checks remain
separate from GPU/native heap reclamation, physical device loss, presentation,
sustained performance and full Mac acceptance.
''';f.write_text(s)
f=r/'specs/macos-completion.md';s=f.read_text();s+='''
Private compute-system retirement now releases its owned device/queue, pending
recording and child resources while preserving the borrowed adapter. Checked
admission and complete recording cleanup extend the [GPU ownership contract](gpu-frame-lifecycle.md).
Offscreen failure fixtures and tiny headless shader execution qualify only their
observed scope; physical memory, sustained performance and window checks remain
open. Storage-value staging/map batch integrity is a separate follow-up audit.
''';f.write_text(s)
(p/'stage-source.json').write_text(json.dumps({'inputs':inputs,'outputs':outputs,'patch_sha256':sha(data)},indent=2)+'\n')
print(json.dumps({'outputs':len(outputs),'expected_prepared_files':6191,'patch_sha256':sha(data)}))
