import hashlib,json,tarfile,io
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-compute-lifecycle');out=r/'docs/reports/macos-compute-lifecycle';records=out/'records'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
source=read('source-final.json');v1=read('source-v1.json');pr=read('prism-v1/prism.json');proc=read('prism-v1/process.json')
assert proc['source_index_stable'] and proc['before']==proc['after']==read('source-prism.json')['sources'] and proc['exit_code']==1 and proc['error']is None
assert pr['coverage']['complete'] and pr['coverage']['files']==6 and pr['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert len(pr['findings'])==1 and pr['findings'][0]['id']=='431ef9dfb1485c78'
assert all(sha(r/n)==h for n,h in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()};assert len(prepared)==6191
for n,h in source['decoded_output_sha256'].items():assert prepared['upstream/'+n]==h
review=read('source-review-final.json');assert review['files']==source['sources'] and review['source_manifest_sha256']==sha(p/'source-final.json') and review['decoded_output_sha256']==source['decoded_output_sha256']
receipts={}
for f in sorted(p.glob('*.json')):
 q=json.loads(f.read_text())
 if 'argv' not in q:continue
 assert q['source_commit']==source['base_commit'] and q['error']is None and q['source_delta_stable'] and q['overlay_inputs_before']==q['overlay_inputs_after']
 for channel in ['stdout','stderr']:assert sha(p/(f.stem+'.'+channel))==q[channel+'_sha256']
 receipts[f.stem]={'exit_code':q['exit_code'],'receipt_sha256':sha(f),'stdout_sha256':q['stdout_sha256'],'stderr_sha256':q['stderr_sha256']}
 if not f.stem.startswith('owned-prepare'):assert q['prepared_before']==q['prepared_after']
final_names=['gpu-offscreen-race-v2','driver-offscreen-race-v2','prepare-tests-v2','compute-headless-owned-v2','native-build-v3']
for n in final_names:
 q=read(n+'.json');assert q['exit_code']==0 and q['source_delta_before']==q['source_delta_after']==source['sources'] and q['prepared_before']==q['prepared_after']==prepared and not q['overlay_inputs_before']
q=read('gpu-vet.json');assert q['exit_code']==0 and q['source_delta_before']==v1['sources'];assert all(source['decoded_output_sha256'][n]==h for n,h in v1['decoded_output_sha256'].items()if n!='gpu/compute_native_lifecycle_test.go')
observations=[]
for line in(p/'compute-headless-owned-v2.stdout').read_text().splitlines():
 if line.startswith('VELLUM_COMPUTE_NATIVE '):observations.append(json.loads(line.split(' ',1)[1]))
assert len(observations)==2 and observations[0]['submitted_passes']==8 and observations[0]['computed_words_checked']==32 and observations[0]['retired_child_refs']==5 and observations[0]['retired_device_refs']==2 and observations[0]['retired_recording_refs']==18 and observations[1]['retired_queue_refs']==1
assert all(o['windows_created']==o['surfaces_created']==0 for o in observations)
assert receipts['compute-original-regression-v2']['exit_code']==1 and receipts['compute-headless-original-owned']['exit_code']==1
q={'result':'PASS_PRIVATE_COMPUTE_OWNERSHIP','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'decoded_outputs':source['decoded_output_sha256'],'receipts':receipts,'source_review_sha256':sha(p/'source-review-final.json'),'native_build_sha256':sha(p/'window-cycle-smoke-owned-v2'),'prism_source':read('source-prism.json')['sources'],'prism_raw_exit_code':1,'prism_findings':1,'prism_findings_resolved':True,'prism_resolution':'431ef9dfb1485c78: both intentionally excluded static pin maps are in the full staged checkpoint; source review replays exact6outputs and preparation11tests passes. No missing file.','post_prism_delta':'Ordered fixture failure teardown only; three root leaves (patch/output pin/native manifest hash) updated. All five other decoded sources byte-identical to PrismV1; final internal review and actual headless/race/build checks bind final source.','native_observations':observations,'final_headless_gpu_executed':True,'native_window_executed':False,'physical_gpu_fault':False,'native_memory_qualified':False,'gpu_memory_qualified':False,'sustained_performance_qualified':False,'macos_completion':False,'preferences_changed':False,'live_tests_deferred':True,'limits':'6191 prepared file identities and8selectedrootleaves, not fullcompiler/SDKclosure. Native wrapper invalidation is explicit reference retirement, not native/GPUheap reclamation. Pinned BeginComputePass panics can unwind acquired command cleanup but are not returned errors or broad panic recovery. Vars.Config temporary layout references and Value storage-staging/map integrity remain follow-up audit items. Tests are tiny serialized headless work, not presentation/endurance/performance.','history':'Candidate V1 and owned V1 use separately bound source maps. The original-compatible two tests fail three assertions. The earlier eight-pass empty headless fixture and later32-word shader fixture both fail private-owner retirement. The later baseline overlays only original compute.go in the preceding fixture version atop then-current V1 prepared dependencies and repaired Device cleanup. It does not execute final V2 fixture/prepared bytes or a complete parent checkout. Initial native build omits required tag and fails before compilation. First full-adapter race run fails only sandbox Unix socket admission; final authorized offscreen retry passes.'}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(parents=True,exist_ok=True)
(records/'source-review.json').write_bytes((p/'source-review-final.json').read_bytes())
# Archive bounded provenance, raw receipts, test and preparation producers; no binaries/caches.
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name not in ['window-cycle-smoke-owned','window-cycle-smoke-owned-v2'] and f.suffix not in ['.tar','.gz'] and '__pycache__'not in f.parts:
  files.append(f)
index={f.relative_to(p).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as archive:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(p).as_posix());info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
(out/'README.md').write_text('''# Mac compute ownership

ComputeSystem owned a separately requested GPU device but did not release it at
shutdown. A refused command Finish also left its command reference live. Patch50
now detaches owner state, abandons pending recording, retires child resources and
releases the private device and independently owned queue. The borrowed adapter
remains live. Empty/repeated shutdown and absent-pass submission are safe.

Checked construction and pass admission publish complete live state. Submission
uses the same ownership helper as graphics: pass before Finish, buffer before
command, cleanup on success or refusal, and old bind-group retirement on both
paths. Caller End and serialized ownership remain required. The pinned native
BeginComputePass has no Try API and can panic; acquired-command cleanup unwinds
without converting that native panic to an error or promising broad recovery.

## Verification

Two original-compatible offscreen tests fail three assertions in the original
compute/device files: empty End and Release panic, and a missing device retains
its queue field. The repaired code passes nine counted admission scenarios,
pass-factory panic unwind and existing submission failure kernels. Final GPU and
gpudraw suites pass three race repetitions. The complete final offscreen adapter
race suite, eleven preparation tests and native-window consumer compilation pass.
Vet passed before the fixture-only teardown correction; production sources are
byte-identical afterward. The first adapter run failed only because the sandbox
refused a temporary Unix socket; an authorized final retry passes. A native build
attempt without the required fixture tag fails before compilation; it is retained
as a failed attempt, with no executable/native acceptance claim.

The final real headless GPU fixture runs eight four-integer shader dispatches and
checks all 32 output values through storage readback. Eighteen recording wrappers,
five child references and the private device/queue are invalid after retirement.
An active recording is abandoned and both borrowed adapter/device remain live.
A separate actual partial-device case retires its still-live queue. Held Go
wrappers establish explicit reference retirement. Original compute.go overlaid
on the then-current prepared dependency fails private-owner retirement with the
same 32-word shader workload in the preceding fixture version. Current device
cleanup and test helpers remain in that baseline; it is not the final fixture
version/prepared map or a complete parent-checkout execution. Earlier empty-pass
headless observations remain separately bound historical checks.

## Review and evidence

Internal review checks all eight selected repository leaves, the static pin maps,
patch replay and six decoded outputs. Prism ran once with Anthropic Claude Sonnet
5.5, six-file coverage, two chunks, 16,176 input/5,073 output tokens and raw exit 1.
Its single medium finding flags hash files absent from the selected provider
payload. Both files are included in the full staged checkpoint; internal replay
and eleven preparation tests verify them. The finding is resolved without a
second provider call. Internal review then corrected fixture-only failure teardown
order; the final patch/hash registration and native/race/build checks bind that
delta. All decoded production sources remain identical to the Prism input.

[Checkpoint](records/checkpoint.json) binds the source/evidence reviews and the
[archive](records/evidence.tar.gz) with its [member index](records/evidence-index.json).
The archive includes failed attempts and separate source versions, raw receipts,
logs and producers. Binaries/caches are excluded. All6191 prepared file identities
are bound; this is not a complete compiler/SDK closure. No desktop windows,
surfaces, input, settings changes or presentation tests ran. Physical GPU faults,
native/GPU heap reclamation, sustained performance and Mac completion remain open.
Vars.Config temporary binding layouts and storage-value staging/map integrity
remain follow-up audit items; this checkpoint does not qualify those paths.
''')
print(json.dumps({'qualification_sha256':sha(p/'qualification.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared),'report_sha256':sha(out/'README.md')}))
