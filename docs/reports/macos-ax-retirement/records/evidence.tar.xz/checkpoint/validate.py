"""Source-bound code-only qualification; no live or endurance qualification."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-ax-retirement')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
manifest=json.loads((P/'checkpoint-source.json').read_text());sources=manifest['sources']
assert manifest['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='b462643c58da8b7a592296ad724572185c844011'
assert len(sources)==12 and all(sha(R/n)==h for n,h in sources.items())
prepared=json.loads((P/'prepared-baseline.json').read_text())
actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
assert len(prepared)==6204 and actual==prepared
checks={}
for name in ['retirement-targeted','retirement-native-contracts','retirement-vet','retirement-full-adapter-race','retirement-native-build','retirement-native-vet','original-bind-overlay-oracle']:
    j=json.loads((P/(name+'.json')).read_text())
    assert j['exit_code']==(1 if name=='original-bind-overlay-oracle'else 0)and j['error']is None and j['live_tests']is False
    assert j['source_commit']==manifest['base_commit']and j['source_delta_stable']and j['prepared_before']==j['prepared_after']==prepared
    assert j['producer_sha256']==sha(P/'code_run.py')and j['overlay_inputs_before']==j['overlay_inputs_after']
    for n,h in j['source_delta_after'].items():
        if Path(n).suffix=='.go':assert sha(R/n)==h
    for n,h in j['overlay_inputs_after'].items():assert sha(n)==h
    for channel in ['stdout','stderr']:assert j[channel+'_sha256']==sha(P/(name+'.'+channel))
    checks[name]={'receipt_sha256':sha(P/(name+'.json')),'argv':j['argv'],'exit_code':j['exit_code'],'elapsed_seconds':j['elapsed_seconds']}
assert 'retired bridge republished window registry entry true false'in(P/'original-bind-overlay-oracle.stdout').read_text()
old=subprocess.check_output(['git','show',manifest['base_commit']+':drivers/cogent/accessibility.go'],cwd=R).decode()
current=(R/'drivers/cogent/accessibility.go').read_text()
def bounds(s):
    a=s.index('func (b *accessibilityBridge) bind(window string) {');return a,s.index('\nfunc (b *accessibilityBridge) close()',a)
a,z=bounds(current);oa,oz=bounds(old)
assert (P/'original-bind-overlay.go').read_text()==current[:a]+old[oa:oz]+current[z:]
summary={'result':'PASS_SCOPED_ACCESSIBILITY_RETIREMENT_ORDERING_AND_DIAGNOSTICS','base_commit':manifest['base_commit'],'sources':sources,'checks':checks,'original_bind_oracle_failed_at_registry_assertion':True,'prepared_files':6204,'prepared_changed':False,'native_build_sha256':sha(P/'window-cycle'),'native_build_launched':False,'live_checks_run':False,'live_testing_paused':True,'prior_endurance_failure_trigger_known':False,'fresh_endurance_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'producer_sha256':sha(__file__)}
with(P/'final-summary.json').open('x')as f:f.write(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['sources','checks']},indent=2))
