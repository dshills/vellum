import hashlib,json,subprocess,sys,time
from pathlib import Path
scratch=Path('/private/tmp/vellum-large-data');canonical=Path('/Users/dshills/Development/projects/Vellum');phase=Path('/private/tmp/vellum-macos-ax-retirement');out=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-ax-retirement')
sys.path.insert(0,str(scratch/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):
 result=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert result.returncode==0,result.stderr;return result.stdout.decode().strip()
checkpoint=json.loads((scratch/'docs/reports/macos-ax-retirement/records/qualification.json').read_text());base=checkpoint['base_commit'];assert checkpoint['result']=='REVIEWED_ACCESSIBILITY_RETIREMENT_ORDERING'and checkpoint['internal_implementation_review']=='APPROVED_SOURCE'and not checkpoint['fresh_endurance_qualified']and not checkpoint['live_checks_run']and not checkpoint['prepared_changed']
assert not git(scratch,'status','--porcelain')and not git(canonical,'status','--porcelain');assert git(canonical,'rev-parse','HEAD')==base
commit=git(scratch,'rev-parse','HEAD');assert git(scratch,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
expected={n:sha(scratch/n)for n in git(scratch,'ls-files','-z').split('\0')if n};assert all(expected.get(n)==h for n,h in checkpoint['sources'].items())
prepared_expected=json.loads((phase/'prepared-baseline.json').read_text())
prepared_before={f.relative_to(canonical/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((canonical/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert prepared_before==prepared_expected
out.mkdir(exist_ok=False,parents=True);start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'tracked_files':len(expected),'scope':'Accessibility retired-bind registry repair and copied first-close requestdiagnostics; sevenimplementation/testfiles internallyreviewed betweenPrismcheckpoints. Final full offscreen adapterrace99.27s, targeted/nativeharnessrace/vets/nativebuild pass; original-bind oraclefails. Nativebinarynotlaunched, priorendurancecauseunknown and fullP6/P11/human/physical gatesopen. All6204preparedbytesexact; livecheckspaused.'}
try:
 git(canonical,'fetch',str(scratch),commit);assert git(canonical,'rev-parse','FETCH_HEAD')==commit;git(canonical,'merge','--ff-only','FETCH_HEAD')
 prepared_after={f.relative_to(canonical/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((canonical/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
 record.update({'tracked_exact':all(sha(canonical/n)==h for n,h in expected.items()),'prepared_exact':prepared_after==prepared_expected,'prepared_files':len(prepared_after),'canonical_clean':not git(canonical,'status','--porcelain'),'scratch_clean':not git(scratch,'status','--porcelain'),'archive_sha256':sha(canonical/'docs/reports/macos-ax-retirement/records/evidence.tar.xz')})
 assert len(prepared_after)==6204 and all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean'])and record['archive_sha256']==checkpoint['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(canonical,'rev-parse','HEAD');record['observed_status']=git(canonical,'status','--porcelain');(out/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n');(out/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
