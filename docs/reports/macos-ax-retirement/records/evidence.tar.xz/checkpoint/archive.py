from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-ax-retirement');D=R/'docs/reports/macos-ax-retirement/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((P/'final-summary.json').read_text());assert s['result']=='PASS_SCOPED_ACCESSIBILITY_RETIREMENT_ORDERING_AND_DIAGNOSTICS'and s['producer_sha256']==sha(P/'validate.py')and not s['fresh_endurance_qualified']
review=json.loads((P/'internal-source-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and not review['findings']
assert len(review['sources'])==7 and all(sha(R/n)==h==s['sources'][n]for n,h in review['sources'].items())
assert len(s['sources'])==12 and all(sha(R/n)==h for n,h in s['sources'].items())
assert all(sha(P/(n+'.json'))==j['receipt_sha256']for n,j in s['checks'].items())
allowed={'.json','.stdout','.stderr','.py','.md','.go','.txt'}
inputs={'checkpoint/'+f.relative_to(P).as_posix():f for f in sorted(P.rglob('*'))if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed}
inputs.update({'reviewed_source/'+n:R/n for n in s['sources']})
D.mkdir(parents=True,exist_ok=True);index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
    for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
    assert set(tar.getnames())==set(index)
    for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
q={**{k:v for k,v in s.items()if k not in ['checks','producer_sha256']},'result':'REVIEWED_ACCESSIBILITY_RETIREMENT_ORDERING','internal_implementation_review':'APPROVED_SOURCE','internal_reviewed_implementation_files':7,'editorial_and_evidence_verification':'Parent source-bound validator and archive integrity checks','prism_run':False,'prism_note':'Internal correction between significant Prism checkpoints; prior checkpoint b462643 was Prism-reviewed. No provider review is claimed for this delta.','archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Verified registry resurrection repair, copied first-close errors and code-only regressions. Original and original-bind overlay failures retained. Native binary excluded, hash retained. No live/endurance/fullframework qualification.'},indent=2)+'\n')
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
