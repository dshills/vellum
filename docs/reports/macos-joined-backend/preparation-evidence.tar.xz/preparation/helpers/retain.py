from pathlib import Path
import io,tarfile,hashlib,json,sys
x=Path(__file__).resolve().parent;q=x/'prepared';mode=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if mode=='preparation':
 paths=[p for p in q.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts and not any(part in ['capture','result-review','__pycache__'] for part in p.relative_to(q).parts) and p.name!='framework' and not p.name.endswith('.tar.xz') and not p.name.endswith('evidence-index.json')]
 paths+=[p for p in x.glob('*.py') if p.name not in ['install.py','install_preparation.py','publish_preparation.py']]
else:
 paths=[q/n for n in ['result.json','validation.json','result-summary.json','started.json','bound-plan.json','preparation-commit.json','result-internal-review.json'] if (q/n).is_file()]
 paths+=[p for folder in ['capture','result-review'] for p in (q/folder).rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts]
 paths+=[p for p in x.glob('*results*.py')]+[x/'retain.py']
archive=q/(mode+'-evidence.tar.xz');members={}
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in sorted(set(paths)):
  data=p.read_bytes();name=mode+'/'+('artifacts/'+p.relative_to(q).as_posix() if p.is_relative_to(q) else 'helpers/'+p.name);info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);info.mtime=info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(data));members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as tar:
 assert sorted(tar.getnames())==sorted(members)
 for m in tar:
  b=tar.extractfile(m).read();assert len(b)==members[m.name]['bytes'] and hashlib.sha256(b).hexdigest()==members[m.name]['sha256']
(q/(mode+'-evidence-index.json')).write_text(json.dumps({'archive_sha256':sha(archive),'files':members,'scope':'Local checkpoint only; private diagnostic. No native executable/library, full SDK, cache or credential. Review dispositions and all owned run logs retained.'},indent=2)+'\n');print(json.dumps({'members':len(members),'bytes':archive.stat().st_size,'sha256':sha(archive)}))
