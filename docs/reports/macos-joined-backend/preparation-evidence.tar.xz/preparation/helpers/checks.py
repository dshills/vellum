from pathlib import Path
import sys,importlib.util,json,hashlib,subprocess
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');code=r/'tools/macos-calibration/joinedbackend';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=q.parent.parent/'macos-joined-timing'
# Exact reused race-tested journal, renderer, and original routed fixture.
core=Path('/private/tmp/vellum-joined-backend-core');prior=Path('/private/tmp/vellum-joined-timing-core')
for name in ['renderer.go','vellum_raster_clock.go','vellum_raster_clock_test.go']:assert (core/'paint/renderers/rasterx'/name).read_bytes()==(prior/'paint/renderers/rasterx'/name).read_bytes()
assert (q/'fixture_test.go').read_bytes()==(old/'fixture_test.go').read_bytes()
for name in ['desktop_session.go','desktop_measurement.go','frame_trace.go']:assert (q/name).read_bytes()==(old/name).read_bytes()
run=subprocess.run([sys.executable,'-m','unittest','-v','check_test'],cwd=code,text=True,capture_output=True);(q/'classifier.stdout').write_text(run.stdout);(q/'classifier.stderr').write_text(run.stderr);assert run.returncode==0
(q/'offscreen-checks.json').write_text(json.dumps({'classifier_methods':6,'negative_mutations':19,'result':'PASS','prior_race_recorder':'Same renderer/journal/test byte-for-byte as ffb7aea; prior5 race methods reused','fixture_and_3_source_detail_overlays':'Byte-identical to prior checkpoint','features_and_gate_unchanged':True},indent=2)+'\n');print(run.stderr)
