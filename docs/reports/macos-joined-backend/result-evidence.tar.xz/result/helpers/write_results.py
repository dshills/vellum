from pathlib import Path
import json,shutil
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-joined-backend';v=json.loads((q/'result-summary.json').read_text());p=v['p95_ticket_disjoint_ms'];t=v['p95_rank_ticket'];assert v['outcome']=='VALID_JOINED_CPU_BACKEND_TIMING_CAPTURE'
text=f'''# Joined CPU/native backend timing: native result

The single approved capture passes complete joined accounting in **{v['elapsed_seconds']:.3f}s**
overall /{v['native_seconds']:.3f}s native. The original Cogent/WebGPU design continues.
Instrumented receipt-to-actual-presentation p95 is **{v['receipt_to_shown_ms']['p95']:.3f}ms**;
{v['observations_over33_3ms']}of120measured observations exceed33.3ms. No production repair or ordinary
release qualification follows, and the gate remains unchanged.

## Actual p95-ranked input

Nearest rank114of120 selects accepted revision{t['accepted_revision']}, scope{t['scope']},
opaque tag{t['opaque_tag']}, generation{t['generation']}, drawable{t['drawable_id']}. The parts below
are contiguous intervals of that same input; they are not independent quantiles.

| Part | Elapsed |
| --- | ---: |
| Receipt to raster start | {p['receipt_to_raster']:.3f}ms |
| Raster | {p['raster']:.3f}ms |
| Raster end to upload start | {p['raster_to_upload']:.3f}ms |
| Native upload | {p['upload']:.3f}ms |
| Upload end to acquisition | {p['upload_to_acquire']:.3f}ms |
| Acquisition to first render commit | {p['acquire_to_first_submit']:.3f}ms |
| First render commit to first GPU start | {p['first_submit_to_first_gpu']:.3f}ms |
| First-to-final render GPU span | {p['render_gpu_span']:.3f}ms |
| Final render GPU end to shown | {p['last_render_gpu_to_shown']:.3f}ms |
| **Receipt to shown** | **{v['p95_ticket_total_ms']:.3f}ms** |

The GPU span includes gaps and overlap between five render buffers, not summed
GPU busy time. The present request occurs **{-v['p95_ticket_present_request_minus_render_gpu_end_ms']:.3f}ms before**
final render GPU end on this input. Its separate present command reaches GPU end
{v['p95_ticket_final_present_command']['render_gpu_end_to_present_gpu_end_ms']*1000:.3f}µs after final render GPU end; **{v['p95_ticket_final_present_command']['present_gpu_end_to_shown_ms']:.3f}ms** then remains
until actual presentation. The completed-handler CPU observation is a distinct
clock event, not GPU completion itself or optical input-to-photon timing.

This localizes the dominant remainder beyond the recorded GPU commands. It does
not isolate compositor, driver, display synchronization or scanout, prove a fixed
frame penalty, or establish a WebGPU-versus-direct-Metal cause. More immediate
present requests or faster shaders are not justified as fixes by this capture.
A next hypothesis should concern present/display scheduling within the current
backend, using a bounded control; this result grants no new live attempt.

## Accounting, checks and review

All248inputs (128warmup/120measured) join the existing absolute raster/upload
records to actual native drawable feedback and complete command histories.
There are{v['backend_records']}backend records: five render buffers plus one present buffer per
cohort frame, and {v['startup_backend_commands']}commands/{v['startup_backend_presents']}presents explicitly retained before the first input.
The{v['raster_records']}raster and{v['native_upload_records']}upload records retain8and6startup records respectively.
No unmatched late submissions or overwritten records are accepted. Full clocks,
command IDs, actual p95 ticket and parent validations remain in indexed evidence.

Nine owned command groups retire. Native stderr is empty; configuration, geometry,
compiled source/binary/native/module/overlay pins and all8,321SDKfiles verify
unchanged. The native archive combines the exact reviewed upload and backend
observers in fresh copies without changing allocation/cache/render/pacing policy.
The archive is not installed into the SDK or packaged app. An initial build chose
an incomplete offline cache and stopped before compilation; the corrected build
and all logs are retained.

Six focused classifier methods/19negative mutations pass, including a render with
an unrelated intercohort present. The original routed complete-pixel/state fixture
passes with the raster clock; prior five recorder race methods are reused by
byte-identical source comparison. Fresh native/Go builds, exact recipe reproduction
and full log/pin/ownership verification pass. Prism Anthropic Claude Sonnet5.5
review of13preparation files identified the command-ownership gap; it is fixed.
The six-file follow-up's conditional registration concern is dispositioned against
the actual explicit-path import graph. Complete reviews, source audit and
regression evidence are retained in the preparation archive.

The [protocol](../../../tools/macos-calibration/joinedbackend/PLAN.md) and
[preparation checks](preparation-checks.json) describe this private diagnostic.
Preparation source checkpoint is `{v['source_checkpoint'][:7]}`. Extra observers perturb
execution; there is no overhead calibration, shipping-binary equivalence,
physical input, displayed-pixel readback, whole-GPU allocation balance or release
acceptance. Do not interpret differences from earlier captures as a speedup or
regression. Features/defaults/SDK/app and33.3ms gate remain unchanged; M3–M7 open.
The desktop attempt is finished and no native job remains active.
'''
(d/'README.md').write_text(text);shutil.copy2(q/'result-summary.json',d/'result-summary.json');shutil.copy2(x/'verify_results.py',d/'execution-sources/verify_results.py.txt')
spec_path=r/'specs/macos-release-assessment.md';spec_path.write_text(spec_path.read_text()+f'''\nThe [same-input backend result](../docs/reports/macos-joined-backend/README.md)
passes248joins in{v['elapsed_seconds']:.3f}s/9owned groups. Instrumented p95={v['receipt_to_shown_ms']['p95']:.3f}ms,
{v['observations_over33_3ms']}/120over33.3. Actual rank ticket: render GPU span{p['render_gpu_span']:.3f}ms,
final render GPU end→shown{p['last_render_gpu_to_shown']:.3f}ms; present requested
{-v['p95_ticket_present_request_minus_render_gpu_end_ms']:.3f}ms before that GPU end. Separate present GPU end→shown
{v['p95_ticket_final_present_command']['present_gpu_end_to_shown_ms']:.3f}ms localizes the remainder beyond recorded commands, without compositor-only,
fixed-frame or WebGPU-cause claims. All startup/command/source/SDK/config/log
accounting retained. Original design/SDK/app/defaults/features and33.3ms gate
unchanged; M3–M7 open, no repair or ordinary qualification. Approved live scope
consumed; no new native attempt authorized by this result.\n''')
(q/'result-internal-review.json').write_text(json.dumps({'result':'PASS','checks':['Independently replayed both inherited classifiers and new same-input ownership/partition checks from raw capture','Actual rank ticket retained; disjoint interval sum closes; quantiles never added','Present request signed and already before GPU end; separate present-command GPU end verified','All9 groups retired, native stderr empty, source/log/configuration/geometry/SDK8321 stable','No uncalibrated cross-build speedup, causal GPU/driver/compositor assertion or release waiver'],'next':'Bound a present/display scheduling hypothesis within the existing backend; no unapproved live retry','unresolved_findings':[]},indent=2)+'\n')
