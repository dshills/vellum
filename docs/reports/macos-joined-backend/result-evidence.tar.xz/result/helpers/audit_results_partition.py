from pathlib import Path
import json
q=Path(__file__).resolve().parent/'prepared';v=json.loads((q/'result-summary.json').read_text());r=v['p95_rank_ticket'];h=r['raw_host_clocks'];commands=r['backend_commands'];render=[c for c in commands if c['kind']==0]
points=[h[k] for k in ['receipt','raster_begin','raster_end','upload_begin','upload_end','acquired']]+[render[0]['commit_start'],min(c['gpu_start'] for c in render),max(c['gpu_end'] for c in render),h['shown']]
assert all(a<=b for a,b in zip(points,points[1:]));deltas=[(b-a)*1e9 for a,b in zip(points,points[1:])];assert abs(sum(deltas)-r['receipt_to_shown_ns'])<=1000
# Present request is intentionally not another additive table boundary.
present=commands[-1];assert present['present_request']<points[-2] and present['kind']==2
(q/'partition-audit.json').write_text(json.dumps({'result':'PASS','event_timestamps':points,'adjacent_deltas_ns':deltas,'sum_ns':sum(deltas),'receipt_to_shown_ns':r['receipt_to_shown_ns'],'residual_ns':sum(deltas)-r['receipt_to_shown_ns'],'present_request_side_observation':present['present_request'],'explanation':'Table differences between adjacent monotonic endpoints are disjoint. Per-buffer CPU/GPU activities may overlap inside them. The signed present-request offset is not included in the partition.'},indent=2)+'\n');print('PASS independent raw endpoint partition, separate signed request observation')
