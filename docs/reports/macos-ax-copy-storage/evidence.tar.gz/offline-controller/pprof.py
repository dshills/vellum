"""Eight bounded offline differential allocation-profile reads; no app execution."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent/'macos-ax-copy-native-3a14e53';sys.path.insert(0,str(N));import run as r
P=r.P;O=Path('/private/tmp/vellum-ax-copy-native-analysis-3a14e53');TOOL=Path('/private/tmp/vellum-profile-pprof-tool-1ba954c')
def main():
 r.need(not O.exists(),'new offline output');d=r.read(P/'native-receipt.json');r.need(d['result']=='PASS_NATIVE_AX_COPY_COMPARISON'and(P/'stop-live').exists()and r.read(P/'tools-complete.json')['all_tools_terminal'],'native campaign sealed and terminal');source=r.read(P/'source.json');r.need(r.identity(r.T)==r.identity(r.C)==source,'current source');tool=r.read(TOOL/'receipt.json');r.need(tool['success']and tool['exit_code']==0 and r.sha(TOOL/'pprof')==tool['binary']['sha256']=='680f7524939a4304ebe6684eea798330b2bcf9f1523ee5aaa332cd080d8966aa','verified local tool');r.need(all(r.sha(p)==h for p,h in tool['bundled_main_pprof_objfile_source'].items()),'selected installed Go tool source pins')
 build=r.read(P/'build-receipt.json');binaries={c['case']:c['binary']for c in build['cases']};profiles={}
 for entry in d['cases']:
  r.terminal(entry['run'])
  if entry['case']['kind']=='allocation':profiles[entry['case']['flavor']]=r.profile_files(P,entry['case']['flavor']);r.need(profiles[entry['case']['flavor']]==entry['validation']['profile_files'],'profile receipt matches')
 r.need(set(profiles)=={'baseline','candidate'},'four profiles');paths=[Path(__file__),N/'common.py',N/'run.py',N/'readiness.json',P/'source.json',P/'native-receipt.json',P/'tools-complete.json',P/'build-receipt.json',TOOL/'receipt.json',TOOL/'pprof']+[Path(x['path'])for values in profiles.values()for x in values.values()]+[Path(b['path'])for b in binaries.values()];pins={str(p.resolve()):r.sha(p)for p in paths};stable=lambda:all(r.sha(p)==h for p,h in pins.items());(W/'pprof-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');O.mkdir(mode=0o700);(O/'runs').mkdir();result=dict(result='INCOMPLETE',source_commit=r.HEAD,tool=tool['binary'],profiles=profiles,commands=[],native_application_binary_executed=False,network_requested=False,full_macos_qualified=False,error=None)
 try:
  for flavor in['baseline','candidate']:
   for metric in['alloc_space','alloc_objects']:
    for cumulative in[False,True]:
     name=flavor+'-'+metric+('-cum'if cumulative else'-flat');argv=[str(TOOL/'pprof'),'-symbolize=none','-nodecount=100','-top','-sample_index='+metric,'-base='+profiles[flavor]['before']['path']]+(['-cum']if cumulative else[])+[binaries[flavor]['path'],profiles[flavor]['after']['path']];run=r.g.execute(argv,O,O/'runs'/name,lambda:False,stable,timeout=45,limit=4<<20);result['commands'].append(dict(name=name,run=run));r.terminal(run);print(json.dumps(dict(command=name,result='COMPLETE')),flush=True)
  r.need(stable()and r.identity(r.T)==r.identity(r.C)==source,'final source/inputs');result.update(result='PASS_OFFLINE_DIFFERENTIAL_ALLOCATIONS',source_stable=True,pins_stable=True)
 except BaseException as e:result['error']=dict(type=type(e).__name__,message=str(e))
 finally:
  with(W/'pprof.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
  print(json.dumps({k:v for k,v in result.items()if k not in['commands','profiles']}),flush=True)
 r.need(result['error']is None,'offline profile analysis failed')
if __name__=='__main__':main()
