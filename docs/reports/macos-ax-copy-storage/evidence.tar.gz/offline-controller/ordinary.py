"""Revalidate raw completed native cohorts and report unchanged frame targets."""
from pathlib import Path
import hashlib,importlib.util,json,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent/'macos-ax-copy-native-3a14e53';sys.path.insert(0,str(N));import run as r
P=r.P

def main():
 d=r.read(P/'native-receipt.json');r.need(d['result']=='PASS_NATIVE_AX_COPY_COMPARISON'and d['local_stop_present']and(P/'stop-live').exists()and r.read(P/'tools-complete.json')['all_tools_terminal'],'sealed terminal native comparison')
 source=r.read(P/'source.json');r.need(r.identity(r.T)==r.identity(r.C)==source,'current source parity');groups={};profiles={};pair_samples={};pairs=[];inputs={str(P/'native-receipt.json'):r.sha(P/'native-receipt.json'),str(P/'source.json'):r.sha(P/'source.json'),str(N/'run.py'):r.sha(N/'run.py')}
 for entry in d['cases']:
  c=entry['case'];run=entry['run'];r.terminal(run);out=P/'runs'/c['label'];r.need(r.read(out/'receipt.json')==entry,'per-case receipt agrees');r.need(entry['error']is None and r.sha(out/'stdout')==run['logs']['stdout']['sha256']and r.sha(out/'stderr')==run['logs']['stderr']['sha256'],'raw terminal integrity');inputs[str(out/'stdout')]=r.sha(out/'stdout');inputs[str(out/'receipt.json')]=r.sha(out/'receipt.json');records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()]
  if c['kind']=='ax':ax=r.validate_ax(records);continue
  samples=r.perf_records(records,variable=c['variable'],gpu=c['gpu'],allocated=c['kind']=='allocation',samples=c['samples']);native=records[1]['native_window']
  if c['pair']in pair_samples:
   old,n,oldlabel=pair_samples.pop(c['pair']);pairs.append(dict(pair=c['pair'],cases=[oldlabel,c['label']],**r.match_pair(old,samples,n,native)))
  else:pair_samples[c['pair']]=(samples,native,c['label'])
  if c['kind']=='allocation':profiles[c['flavor']]=r.profile_files(P,c['flavor']);continue
  values=[x['metrics']['ui_work_ns']for x in samples];stats=r.benchmark.distribution(values);groups.setdefault(c['group'],{}).setdefault(c['flavor'],[]).append(dict(repeat=c['repeat'],label=c['label'],statistics=stats,phases=r.benchmark.summarize([samples]),over_p95_4ms=stats['p95']>4000000,over_p99_6ms=stats['p99']>6000000))
 r.need(len(d['cases'])==43 and len(pairs)==21 and not pair_samples and len(groups)==4,'full native plan');summary={}
 for name,flavors in groups.items():
  r.need(set(flavors)=={'baseline','candidate'}and all(len(v)==5 for v in flavors.values()),'five cohort pairs')
  sums={k:dict(median_p95_ns=statistics.median(x['statistics']['p95']for x in v),median_p99_ns=statistics.median(x['statistics']['p99']for x in v),p95_failures=sum(x['over_p95_4ms']for x in v),p99_failures=sum(x['over_p99_6ms']for x in v))for k,v in flavors.items()}
  old={x['repeat']:x for x in flavors['baseline']};new={x['repeat']:x for x in flavors['candidate']};sums['paired_p95_ratios']={str(i):new[i]['statistics']['p95']/old[i]['statistics']['p95']for i in range(1,6)};sums['median_p95_ratio']=sums['candidate']['median_p95_ns']/sums['baseline']['median_p95_ns'];summary[name]=sums
 result=dict(result='PASS_REVALIDATED_NATIVE_AX_COPY_COHORTS',source_commit=r.HEAD,baseline='explicit exact prior-copy compiler overlay; all other current source unchanged',AX=ax,groups=groups,summary=summary,profiles=profiles,pairs=pairs,ordinary_processes=40,ordinary_samples=4800,ordinary_geometry_pairs=2400,allocation_processes=2,allocation_samples=1024,allocation_geometry_pairs=512,targets_ns=dict(p95=4000000,p99=6000000),all_ordinary_targets_pass=all(x['baseline']['p95_failures']==x['baseline']['p99_failures']==x['candidate']['p95_failures']==x['candidate']['p99_failures']==0 for x in summary.values()),gpu_execution_verified=False,native_memory_qualified=False,physical_input_verified=False,human_accessibility_verified=False,full_macos_qualified=False,inputs=inputs)
 with(W/'ordinary.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(result=result['result'],AX=ax,summary=summary,all_ordinary_targets_pass=result['all_ordinary_targets_pass'])),flush=True)
if __name__=='__main__':main()
