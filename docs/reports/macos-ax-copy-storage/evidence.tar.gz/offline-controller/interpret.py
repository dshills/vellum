"""Retain exact reported profile totals, without treating estimates as native memory."""
from pathlib import Path
import json,re,hashlib
W=Path(__file__).resolve().parent;O=Path('/private/tmp/vellum-ax-copy-native-analysis-3a14e53');profiles={};inputs={}
for flavor in['baseline','candidate']:
 values={}
 for metric in['alloc_space','alloc_objects']:
  p=O/'runs'/(flavor+'-'+metric+'-flat')/'stdout';text=p.read_text();inputs[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest();m=re.search(r'of ([0-9.]+)(MB)? total',text);assert m;values[metric]=dict(reported_total=float(m[1])if metric=='alloc_space'else int(m[1]),reported_unit=m[2]or'objects',raw_total_line=next(x for x in text.splitlines()if' total'in x))
  c=O/'runs'/(flavor+'-'+metric+'-cum')/'stdout';lines=c.read_text().splitlines();inputs[str(c)]=hashlib.sha256(c.read_bytes()).hexdigest();values[metric]['selected_cumulative_rows']=[line for line in lines if any(n in line for n in['.syncAccessibility','.cloneAccessibilityNode','.prepareGridPublicationSnapshotForSemantic','.detachAccessibilityNodes'])]
 profiles[flavor]=values
ratios={m:profiles['candidate'][m]['reported_total']/profiles['baseline'][m]['reported_total']for m in['alloc_space','alloc_objects']};ordinary=json.loads((W/'ordinary.json').read_text());inputs[str(W/'ordinary.json')]=hashlib.sha256((W/'ordinary.json').read_bytes()).hexdigest();worse={k:sum(x>1 for x in v['paired_p95_ratios'].values())for k,v in ordinary['summary'].items()}
result=dict(status='SCOPED_NATIVE_CORRECTNESS_AND_ALLOCATION_OBSERVATIONS_NO_LATENCY_WIN',profile_totals=profiles,reported_candidate_baseline_ratios=ratios,ordinary_paired_p95_candidate_higher=worse,p95_failures={f:sum(v[f]['p95_failures']for v in ordinary['summary'].values())for f in['baseline','candidate']},p99_failures={f:sum(v[f]['p99_failures']for v in ordinary['summary'].values())for f in['baseline','candidate']},limits=['one allocation-profile process per implementation; process-wide after-minus-before sampled estimates include observers/other goroutines','reportedMB numbers rounded by pprof; object totals also sampled estimates,not exact allocations','cumulative rows overlap; missing rows below top100/threshold are not zero','no retained/native/GPU/private memory or causal native frame improvement proven','CPUfixed p95 candidate higher inall5pairs; othergroups mixed; no broad no-regression claim','4ms/6ms and fullMac remain open'],inputs=inputs)
(W/'interpretation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['profile_totals','inputs']}))
