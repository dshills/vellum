# Archive reviewed native correctness and mixed/failed latency observations.
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;N=W.parent/'macos-ax-copy-native-3a14e53';A=W.parent/'macos-ax-copy-native-analysis-3a14e53';S=W.parent/'macos-ax-copy-buffers/checkpoint-3a14e53';P=Path('/private/tmp/vellum-ax-copy-native-3a14e53');O=Path('/private/tmp/vellum-ax-copy-native-analysis-3a14e53');T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'docs/reports/macos-ax-copy-storage';TOOL=Path('/private/tmp/vellum-profile-pprof-tool-1ba954c')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']and r['report_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'accepted results/producer')
d=read(P/'native-receipt.json');a=read(A/'ordinary.json');pp=read(A/'pprof.json');interpretation=read(A/'interpretation.json');built=read(P/'build-receipt.json');need(d['result']=='PASS_NATIVE_AX_COPY_COMPARISON'and a['result']=='PASS_REVALIDATED_NATIVE_AX_COPY_COHORTS'and pp['result']=='PASS_OFFLINE_DIFFERENTIAL_ALLOCATIONS'and(P/'stop-live').exists()and read(P/'tools-complete.json')['all_tools_terminal']and read(A/'tools-complete.json')['all_tools_terminal'],'sealed native/offline results')
members={}
def add(label,root,exclude=()):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'evidence symlink')
  if p.is_file()and'__pycache__'not in p.parts and not any(x in p.relative_to(root).parts for x in exclude):members[label+p.relative_to(root).as_posix()]=p
add('native-controller/',N);add('offline-controller/',A);add('native-checks/',P,exclude=('bin',));add('offline-checks/',O);add('source-checkpoint/',S)
members['review/result-review.json']=W/'result-review.json';members['producer/report.py']=Path(__file__);members['producer/README.template.md']=W/'README.template.md'
for n in['child_process.py','sdk_environment.py','benchmark-grid.py']:members['helpers/'+n]=T/'scripts'/n
members['helpers/owned-runner.py']=W.parent/'macos-sdk-native-238b3b6/run.py';members['helpers/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py');members['helpers/prism-retirement.py']=Path('/private/tmp/vellum-native-attestation-probe-20261016/run-verifier.py')
for n in['receipt.json','metadata.stdout','metadata.stderr','help.stdout','help.stderr','build.stdout','build.stderr']:members['pprof-tool/'+n]=TOOL/n
members['pprof-tool/build-producer.py']=W.parent/'macos-grid-profile/build-pprof.py'
for n in['drivers/cogent/driver.go','drivers/cogent/frame_metrics.go','drivers/cogent/accessibility.go','drivers/cogent/accessibility_grid_publication.go','drivers/cogent/accessibility_pending.go','drivers/cogent/accessibility_darwin.m','drivers/cogent/grid_retained.go','examples/loadedgrid/main.go','examples/loadedgrid/perf.go','examples/loadedgrid/perf_runtime.go','examples/loadedgrid/perf_profile.go','examples/loadedgrid/accessibility_smoke.go','.github/workflows/framework.yml','scripts/check.sh']:members['runtime-source/'+n]=T/n
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<400 and expanded<32<<20,'bounded evidence');D.mkdir()
tool=read(TOOL/'receipt.json');manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},count=len(members),expanded_bytes=expanded,excluded_artifacts=dict(native_binaries={c['case']:c['binary']for c in built['cases']},pprof_binary=tool['binary']))
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,p in members.items():
    data=p.read_bytes();need(hashlib.sha256(data).hexdigest()==manifest['files'][n]['sha256'],'archive input drift');entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive member integrity')
result=dict(status='REVIEWED_AX_COPY_STORAGE_AND_NATIVE_COMPARISON',source_commit='3a14e53777072caf19f5bcf4ce3e27f12c1e8a9a',source_checkpoint_commit=read(S/'controller/commit-receipt.json'),native=d,ordinary=a,offline_profiles=pp,interpretation=interpretation,build=dict(result=built['result'],cases=built['cases'],source_commit=built['source_commit']),result_review_sha256=sha(W/'result-review.json'),evidence=dict(sha256=sha(D/'evidence.tar.gz'),bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded),source_checkpoint_provider_calls=1,evidence_phase_provider_calls=0,production_source_changed_in_evidence_phase=False,ordinary_performance_qualified=False,native_gpu_memory_qualified=False,physical_input_verified=False,public_distribution=False,full_macos_qualified=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');rows=[]
for name,v in a['summary'].items():
 old,new=v['baseline'],v['candidate'];higher=interpretation['ordinary_paired_p95_candidate_higher'][name]
 rows.append(f"| {name} | {old['median_p95_ns']/1e6:.3f} | {new['median_p95_ns']/1e6:.3f} | {old['p95_failures']}/5 / {new['p95_failures']}/5 | {old['p99_failures']}/5 / {new['p99_failures']}/5 | {higher}/5 |")
text=(W/'README.template.md').read_text();need(text.count('@@TABLE@@')==1,'table placeholder');(D/'README.md').write_text(text.replace('@@TABLE@@','\n'.join(rows)))
for name in['docs/implementation.md','specs/macos-completion.md']:
 p=T/name;link='reports/macos-ax-copy-storage/README.md'if name.startswith('docs/')else'../docs/reports/macos-ax-copy-storage/README.md'
 paragraph=("\n\n## Detached accessibility storage and native evidence\n\n"+f"The [copy-storage checkpoint]({link}) retains source `3a14e53`, exact legacy/\n"+"ownership/allocation regressions, one Anthropic Prism review and actual Cocoa\ngrid identity/action/closure acceptance. Fresh native runs complete 4,800\nordinary samples and 2,400 full geometry pairs. All 20 candidate p95 and 19 p99\nprocesses miss 4/6 ms; fixed-row CPU p95 is higher in all five pairs. One paired\nallocation diagnostic estimates fewer Go objects, but establishes no native\nlatency gain, broad no-regression or native/retained memory acceptance. P6/P11\nand full Mac, physical/human and distribution/release gates remain open.\n")
 p.write_text(p.read_text()+paragraph)
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Detached accessibility storage and native comparison](macos-ax-copy-storage/README.md): scoped Cocoa correctness and allocation evidence; unchanged frame targets remain failed.\n')
print(json.dumps(dict(result='AX_COPY_NATIVE_REPORT_GENERATED',files=7,members=len(members),expanded_bytes=expanded,archive_bytes=(D/'evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'evidence.tar.gz'))))
