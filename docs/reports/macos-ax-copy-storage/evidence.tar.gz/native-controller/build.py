"""Fresh matched native builds, one exact prior-copy overlay and one committed copy."""
from pathlib import Path
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
def main():
 need(not P.exists(),'new build/campaign root');source=identity(T);need(identity(C)==source,'source parity');frozen=W.parent/'macos-ax-copy-buffers/original.go.txt';old=run_child(['git','show','5ba6e86be606efb34c5a223c47db6753714fc69e:'+FIELD],cwd=T,capture_output=True,check=True,timeout=20).stdout
 need(frozen.read_bytes()==old and sha(frozen)=='6be79cc84a47d8a133f38f28a8114565380ab17abefc94b9a7152bbd36c8cc98','exact prior source overlay');P.mkdir(mode=0o700);(P/'bin').mkdir();(P/'builds').mkdir();(P/'profiles').mkdir();(P/'source.json').write_text(json.dumps(source,indent=2)+'\n');(P/'baseline.go.txt').write_bytes(old);(P/'overlay.json').write_text(json.dumps({'Replace':{str(T/FIELD):str(P/'baseline.go.txt')}},indent=2)+'\n')
 baseline=dict(commit_metadata=HEAD,files={**source['files'],FIELD:sha(P/'baseline.go.txt')},prepared=source['prepared'],scope='Compiler overlay of exact prior5ba6e86 copy file; all other current files unchanged. Not a clean historical executable.')
 (P/'baseline-source.json').write_text(json.dumps(baseline,indent=2)+'\n')
 pins={str(T/n):h for n,h in source['files'].items()};pins.update({str(T/'drivers/cogent/build'/n):h for n,h in source['prepared'].items()})
 for p in[W/'build.py',W/'common.py',guard_path,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',P/'baseline.go.txt',P/'overlay.json',P/'source.json',P/'baseline-source.json']:pins[str(p)]=sha(p)
 stable=lambda:all(sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,native_runtime_executed=False,cases=[],error=None)
 try:
  for case in['baseline','candidate']:
   binary=P/'bin'/case;argv=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','build'];argv+=['-overlay',str(P/'overlay.json')]if case=='baseline'else[];argv+=['-trimpath','-o',str(binary),'.'];commands=[]
   for name,args,cwd in[('build',argv,T/'examples/loadedgrid'),('metadata',['/opt/homebrew/bin/go','version','-m',str(binary)],P)]:
    run=g.execute(args,cwd,P/'builds'/(case+'-'+name),lambda:False,stable,timeout=240,limit=4<<20);commands.append(dict(name=name,run=run));terminal(run)
   d['cases'].append(dict(case=case,binary=dict(path=str(binary),sha256=sha(binary),bytes=binary.stat().st_size),commands=commands,compiler_overlay=case=='baseline'))
  need(identity(T)==identity(C)==source and stable(),'final source/pin parity');d.update(result='PASS_MATCHED_NATIVE_COMPILE_ONLY',source_stable=True,prepared_stable=True,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  with(P/'build-receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k!='inputs'}),flush=True)
if __name__=='__main__':main()
