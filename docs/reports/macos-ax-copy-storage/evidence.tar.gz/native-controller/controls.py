"""Bounded no-native controller/validation refusal checks."""
from pathlib import Path
import copy,json,sys
sys.dont_write_bytecode=True
import run as m
root=m.P/'controller-controls';root.mkdir(mode=0o700);results=[]
def refused(name,fn):
 try:fn()
 except(ValueError,KeyError,TypeError):results.append(dict(case=name,refused=True));return
 raise AssertionError('accepted invalid '+name)
for name in['normal','seal-failure','existing-receipt','existing-runs','sealed','profile-collision']:(root/name).mkdir()
d=m.finalize(root/'normal',dict(error=None,native_runtime_executed=False));m.need(d['result']=='PASS_NATIVE_AX_COPY_COMPARISON'and not d['finalization_errors'],'normal finalization')
touch=Path.touch
try:
 def bad(self,*a,**kw):
  if self==root/'seal-failure/stop-live':raise OSError('injected seal failure')
  return touch(self,*a,**kw)
 Path.touch=bad;d=m.finalize(root/'seal-failure',dict(error=None,native_runtime_executed=False));m.need(d['result']=='FAILED_OR_CANCELED_NATIVE_AX_COPY_COMPARISON'and m.read(root/'seal-failure/native-receipt.json')==d and d['finalization_errors'][0]['stage']=='seal-stop','receipt despite sealing failure')
finally:Path.touch=touch
p=root/'existing-receipt/native-receipt.json';p.write_text('prior terminal\n');d=m.finalize(root/'existing-receipt',dict(error=None,native_runtime_executed=False));m.need(p.read_text()=='prior terminal\n'and d['finalization_errors'][0]['stage']=='exclusive-receipt','prior receipt preserved')
(root/'existing-runs/runs').mkdir();(root/'sealed/stop-live').touch();(root/'profile-collision/profiles').mkdir();(root/'profile-collision/profiles/baseline.before.pprof').write_bytes(b'collision')
for name in['existing-receipt','existing-runs','sealed','profile-collision']:refused('fresh-'+name,lambda name=name:m.fresh(root/name))
ax=[dict(event='grid.accessibility.pass',rows=1000000,visible_minimum=400,overlap_objects_reused=2268,replacement_objects_retired=459,native_press_admitted=True),dict(event='grid.accessibility.closed',attachment_query_refused=True,geometry_persistence_disabled_in_fixture=True)];m.validate_ax(ax)
for name,index,key,value in[('AX rows',0,'rows',True),('AX minimum',0,'visible_minimum',399),('AX reuse',0,'overlap_objects_reused',399),('AX retire',0,'replacement_objects_retired',True),('AX press',0,'native_press_admitted',False),('AX closed',1,'attachment_query_refused',False),('AX persistence',1,'geometry_persistence_disabled_in_fixture',False)]:
 bad=copy.deepcopy(ax);bad[index][key]=value;refused(name,lambda bad=bad:m.validate_ax(bad))
refused('AX missing close',lambda:m.validate_ax(ax[:1]));refused('AX duplicate stage',lambda:m.validate_ax(ax+ax[:1]))
fixture=Path('/private/tmp/vellum-tile-binning-native-75-continuation/runs/candidate-gpu-fixed-r5-1000000/stdout');records=[json.loads(x)for x in fixture.read_bytes().splitlines()];samples=m.perf_records(records,variable=False,gpu=True,allocated=False,samples=120);native=records[1]['native_window'];m.match_pair(samples,samples,native,native)
for name,mutate in[('ordinary allocation mode',lambda r:[x.update(alloc_profile=True)for x in r]),('ordinary CPU profile',lambda r:[x.update(cpu_profile=True)for x in r]),('missing callback',lambda r:r[-1].update(callbacks=119)),('warmup callback',lambda r:r[1].update(warm_callbacks=127)),('duplicate ticket',lambda r:r[3].update(tag=1))]:
 bad=copy.deepcopy(records);mutate(bad);refused(name,lambda bad=bad:m.perf_records(bad,variable=False,gpu=True,allocated=False,samples=120))
bad=copy.deepcopy(samples);bad[0]['geometry']['bounds']['Min']['X']+=1;refused('full paired bounds',lambda:m.match_pair(samples,bad,native,native));other=copy.deepcopy(native);other['window_logical_dpi']+=1;refused('native endpoints',lambda:m.match_pair(samples,samples,native,other))
plan=m.plan_cases();m.need(len({x['label']for x in plan})==43 and sum(x['kind']=='ordinary'for x in plan)==40 and sum(x['kind']=='allocation'for x in plan)==2,'fixed unique plan');counts={}
for case in plan:
 if case['kind']!='ax':counts[case['pair']]=counts.get(case['pair'],0)+1
m.need(len(counts)==21 and set(counts.values())=={2},'exact bounded pairs')
result=dict(result='PASS_NON_NATIVE_AX_COPY_CONTROLLER_CONTROLS',producer_sha256=m.sha(__file__),runner_sha256=m.sha(m.W/'run.py'),native_runtime_executed=False,finalization_cases=3,refusals=len(results),results=results,positive_fixtures=dict(AX='synthetic schema only,not native evidence',ordinary=dict(path=str(fixture),sha256=m.sha(fixture))),planned_native_roots=43,planned_ordinary_pairs=20)
(m.W/'controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='results'}))
