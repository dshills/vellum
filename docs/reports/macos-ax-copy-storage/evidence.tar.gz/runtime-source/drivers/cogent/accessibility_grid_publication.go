package cogent

import (
	"image"

	"github.com/dshills/vellum/virtual"
)

// The native action may already be queued when render withdraws geometry but
// before the owner publishes pending. Check readiness again at owner delivery.
func guardGridAccessibility(g *gridBinding, nodes []accessibilityNode, handlers map[string]accessibilityHandler) {
	for _, node := range nodes {
		if handler := handlers[node.ID]; handler != nil {
			generation, incarnation := node.GridGeneration, node.GridIncarnation
			pending, cell := node.GridPending, node.Role == "grid-cell"
			handlers[node.ID] = func(action accessibilityAction) bool {
				if pending || !g.eligible() {
					return false
				}
				state, err := g.model.State()
				if err != nil {
					return false
				}
				if state.Generation != generation {
					// Cell refs already reported this typed refusal before the
					// publication guard was added. Preserve that error callback.
					if cell {
						g.fail(virtual.ErrGridStale)
					}
					return false
				}
				m := g.currentMeasurement()
				if m == nil || m.Generation != generation || m.Incarnation != incarnation || m.CellIncarnation != g.epoch {
					return false
				}
				if !currentGridAccessibilityEditor(g, m) {
					return false
				}
				if state.Stamp != m.Stamp || state.Viewport != m.Viewport {
					return false
				}
				return handler(action)
			}
		}
	}
}

// Private marked previews can change the owner-held field cache without a new
// portable grid generation. They also revoke actions from the older frame.
func currentGridAccessibilityEditor(g *gridBinding, m *GridInspection) bool {
	edit := gridEditingRecord(g.r)
	if (edit == nil) != (m.Editor == nil) {
		return false
	}
	if edit == nil {
		return true
	}
	return g.editing != nil && m.Editor.ID == edit.node.ID && m.Editor.Session == g.editing.session && edit.control.fieldState != nil && edit.control.fieldState.Text == m.Editor.Text
}

// stampGridAccessibility runs on the owner. The frame was copied by render;
// a pending layout never reads live widget rectangles or accepts old actions.
func stampGridAccessibility(r *record, nodes []accessibilityNode) {
	if len(nodes) == 0 {
		return
	}
	g := r.control.grid
	m := g.currentMeasurement()
	pending := m == nil || !g.live() || !g.projectionReady || m.Incarnation != g.incarnation || m.CellIncarnation != g.epoch
	if !pending {
		edit := gridEditingRecord(r)
		if !currentGridAccessibilityEditor(g, m) {
			pending = true
		} else if edit != nil {
			for _, node := range nodes {
				if node.ID == accessibilityManagedID(edit.node.ID) && (node.Value != m.Editor.Text || node.Focused != m.Editor.Focused) {
					pending = true
				}
			}
		}
	}
	frames := map[string][4]float32{}
	if !pending {
		put := func(id string, rect image.Rectangle) {
			frames[id] = [4]float32{float32(rect.Min.X), float32(rect.Min.Y), float32(rect.Dx()), float32(rect.Dy())}
		}
		put(nodes[0].ID, m.Bounds)
		rows := map[string]image.Rectangle{}
		for _, c := range m.Cells {
			put(accessibilityManagedID(c.ID), c.Bounds)
			rows[c.RowKey] = rows[c.RowKey].Union(c.Bounds)
		}
		for key, bounds := range rows {
			put(accessibilityRowID(r.node.ID, key), bounds)
		}
		for _, h := range m.Headers {
			put(accessibilityManagedID(h.ID), h.Bounds)
		}
		if m.Editor != nil {
			put(accessibilityManagedID(m.Editor.ID), m.Editor.Bounds)
		}
		// An editor mounted after capture also needs a completed frame. Avoid
		// combining current semantics with an earlier editor's geometry.
		for _, node := range nodes {
			if _, ok := frames[node.ID]; !ok {
				pending = true
				break
			}
		}
	}
	for i := range nodes {
		n := &nodes[i]
		n.GridScope = nodes[0].ID
		n.GridIncarnation = g.incarnation
		n.GridPending = pending
		n.GridTargetGeneration = g.projection.State.Generation
		n.GridGeneration = 0
		if !pending {
			n.GridGeneration = m.Generation
			frame := frames[n.ID]
			n.GridFrame = &frame
		}
	}
}

func cloneAccessibilityNodes(nodes []accessibilityNode) []accessibilityNode {
	if len(nodes) == 0 {
		return nil
	}
	out := make([]accessibilityNode, len(nodes))
	copy(out, nodes)
	detachAccessibilityNodes(out)
	return out
}

// detachAccessibilityNodes owns the supplied records and detaches their mutable
// fields. Storage belongs to this snapshot only: later copies cannot overwrite
// it. Count optional fields first so sparse records do not retain unused slots.
// Each action slice is capacity-limited to keep appends away from its neighbors.
func detachAccessibilityNodes(nodes []accessibilityNode) {
	var actions, frames, selections, expanded, minimums, maximums int
	for _, n := range nodes {
		actions += len(n.Actions)
		if n.GridFrame != nil {
			frames++
		}
		if n.TextSelection != nil {
			selections++
		}
		if n.Expanded != nil {
			expanded++
		}
		if n.Min != nil {
			minimums++
		}
		if n.Max != nil {
			maximums++
		}
	}
	actionStorage := make([]string, actions)
	frameStorage := make([][4]float32, frames)
	selectionStorage := make([][2]int, selections)
	expandedStorage := make([]bool, expanded)
	minimumStorage := make([]float32, minimums)
	maximumStorage := make([]float32, maximums)
	for i := range nodes {
		n := &nodes[i]
		count := len(n.Actions)
		copy(actionStorage, n.Actions)
		n.Actions = actionStorage[:count:count]
		actionStorage = actionStorage[count:]
		if n.GridFrame != nil {
			frameStorage[0] = *n.GridFrame
			n.GridFrame = &frameStorage[0]
			frameStorage = frameStorage[1:]
		}
		if n.TextSelection != nil {
			selectionStorage[0] = *n.TextSelection
			n.TextSelection = &selectionStorage[0]
			selectionStorage = selectionStorage[1:]
		}
		if n.Expanded != nil {
			expandedStorage[0] = *n.Expanded
			n.Expanded = &expandedStorage[0]
			expandedStorage = expandedStorage[1:]
		}
		if n.Min != nil {
			minimumStorage[0] = *n.Min
			n.Min = &minimumStorage[0]
			minimumStorage = minimumStorage[1:]
		}
		if n.Max != nil {
			maximumStorage[0] = *n.Max
			n.Max = &maximumStorage[0]
			maximumStorage = maximumStorage[1:]
		}
	}
}

// prepareGridPublication retains one completed subtree per currently visible
// grid, scoped by binding incarnation and parent. It never retains handlers or
// a grid/model pointer. Actual removal drops the cache immediately.
func (b *accessibilityBridge) prepareGridPublication(nodes []accessibilityNode, handlers map[string]accessibilityHandler) ([]accessibilityNode, map[string]accessibilityHandler) {
	return b.prepareGridPublicationSnapshot(nodes, handlers, false)
}

// owned admits only freshly created snapshot containers whose caller relinquishes
// them. Borrowed callers still receive separate output and handler containers.
func (b *accessibilityBridge) prepareGridPublicationSnapshot(nodes []accessibilityNode, handlers map[string]accessibilityHandler, owned bool) ([]accessibilityNode, map[string]accessibilityHandler) {
	return b.prepareGridPublicationSnapshotForSemantic(nodes, handlers, owned, "")
}

// completedSemantic is supplied only after successful full encoding of ready
// builtin-valued nodes. Install its identity atomically with the detached cache;
// a direct preparation between this call and final publication must revoke it.
func (b *accessibilityBridge) prepareGridPublicationSnapshotForSemantic(nodes []accessibilityNode, handlers map[string]accessibilityHandler, owned bool, completedSemantic string) ([]accessibilityNode, map[string]accessibilityHandler) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed.Load() {
		return nil, nil
	}
	// Direct preparation can change the cache independently of lastSnapshot.
	// Only a subsequent successful ready publication can certify reuse again.
	b.completedSnapshot = ""
	// Group input indices, rather than repeatedly copying large node records
	// while each scope grows. Completed cache records are still fully detached.
	scopes := map[string][]int{}
	for index, node := range nodes {
		if node.GridScope != "" {
			scopes[node.GridScope] = append(scopes[node.GridScope], index)
		}
	}
	cache := map[string][]accessibilityNode{}
	replacements := map[string][]accessibilityNode{}
	actions := handlers
	if !owned {
		actions = make(map[string]accessibilityHandler, len(handlers))
		for id, handler := range handlers {
			actions[id] = handler
		}
	}
	for scope, indices := range scopes {
		host := nodes[indices[0]]
		if host.ID != scope {
			continue // Framework traversal always emits the table host first.
		}
		if !host.GridPending {
			group := make([]accessibilityNode, len(indices))
			for i, index := range indices {
				group[i] = nodes[index]
				group[i].activationGuard = nil // Completed caches retain no owner/model closures.
			}
			detachAccessibilityNodes(group)
			cache[scope] = group
			continue
		}
		previous := b.gridPublications[scope]
		retained := nodes[indices[0] : indices[0]+1]
		if len(previous) > 0 && previous[0].GridIncarnation == host.GridIncarnation && previous[0].Parent == host.Parent && previous[0].Role == host.Role {
			cache[scope] = previous
			retained = previous
		}
		retained = cloneAccessibilityNodes(retained)
		for i := range retained {
			n := &retained[i]
			n.GridPending = true
			n.GridTargetGeneration = host.GridTargetGeneration
			n.Disabled, n.Focused = true, false
			n.Actions = []string{}
			n.TextClient, n.TextSelection, n.TextFocus = 0, nil, 0
			delete(actions, n.ID)
		}
		// Descriptor labels/help remain current even while cell data are read-only.
		retained[0].Name, retained[0].Help = host.Name, host.Help
		for _, index := range indices {
			delete(actions, nodes[index].ID)
		}
		replacements[scope] = retained
	}
	if owned && len(replacements) == 0 {
		b.gridPublications = cache
		b.completedSnapshot = completedSemantic
		return nodes, actions
	}
	out := make([]accessibilityNode, 0, len(nodes))
	for _, node := range nodes {
		if replacement, pending := replacements[node.GridScope]; pending {
			if node.ID == node.GridScope {
				out = append(out, replacement...)
			}
			continue
		}
		out = append(out, node)
	}
	b.gridPublications = cache
	b.completedSnapshot = completedSemantic
	return out, actions
}

// sameCompletedGridMetadata runs under b.mu after full semantic equality and
// builtin-value checks. The JSON wire omits pressFocusID, so compare that owner
// metadata too. Values must also retain their exact builtin type/value (JSON can
// encode int(1) and float64(1) identically). Interleaved scopes keep their order.
func (b *accessibilityBridge) sameCompletedGridMetadata(nodes []accessibilityNode) bool {
	offsets := make(map[string]int)
	for _, node := range nodes {
		if node.GridScope == "" {
			continue
		}
		previous := b.gridPublications[node.GridScope]
		index := offsets[node.GridScope]
		if index >= len(previous) || previous[index].ID != node.ID || previous[index].pressFocusID != node.pressFocusID || previous[index].Value != node.Value {
			return false
		}
		offsets[node.GridScope] = index + 1
	}
	if len(offsets) != len(b.gridPublications) {
		return false
	}
	for scope, count := range offsets {
		if count != len(b.gridPublications[scope]) {
			return false
		}
	}
	return true
}
