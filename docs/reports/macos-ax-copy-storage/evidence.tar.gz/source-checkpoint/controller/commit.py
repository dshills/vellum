"""Commit exact reviewed accessibility snapshot-copy source and integrate canonical."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');CHECKS=Path('/private/tmp/vellum-ax-copy-buffers-checks-v1')
spec=importlib.util.spec_from_file_location('ax_copy_commit_guard',W.parent/'macos-grid-native-stacks/commit-pending.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W
original_env=m.child_environment;m.child_environment=lambda runtime=False:{**original_env(runtime),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
sha=m.sha;read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def prepared(root):return {p.relative_to(root/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in(root/'drivers/cogent/build'/module).rglob('*')if p.is_file()}
def main():
 output=W/'commit-receipt.json';need(not output.exists(),'exclusive receipt');d=dict(result='INCOMPLETE',producer_sha256=sha(__file__),mutations=[],error=None)
 try:
  b=read(W/'final-binding.json');r=read(W/'final-review.json');need(r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'final review pins')
  d['before']=dict(candidate=m.observation(T),canonical=m.observation(C));admit=dict(candidate=m.git_admission(T),canonical=m.git_admission(C));d['git_admission']=admit
  need(d['before']['candidate']['head']==d['before']['canonical']['head']==b['base_commit'],'base heads');need(d['before']['candidate']['branch']=='codex/macos-native-results'and d['before']['canonical']['branch']=='codex/foundation-completion','branches');need(m.clean(C)and not m.git(T,'diff','--name-only')and not m.git(T,'ls-files','--others','--exclude-standard'),'external changes')
  need(set(m.git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources']),'staged names');need(all(sha(T/p)==h and hashlib.sha256(m.git(T,'show',':'+p)).hexdigest()==h for p,h in b['sources'].items()),'staged/current bytes');need(hashlib.sha256(m.git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256'],'staged diff')
  source=read(W/'full-source-final.json');need(len(source['files'])==4669 and all(sha(T/p)==h for p,h in source['files'].items()),'full source endpoint');need(len(source['prepared'])==6246 and prepared(T)==prepared(C)==source['prepared'],'prepared parity')
  need(read(CHECKS/'receipt.json')['result']=='PASS_NON_NATIVE_AX_COPY_CHECKS'and read(CHECKS/'counterfactual.json')['result']=='PASS_COUNTERFACTUAL_ALLOCATION_REGRESSION','passing affected checks')
  need(read(CHECKS/'delta.json')['result']=='PASS_POST_PROVIDER_TEST_ONLY_DELTA'and read(Path('/private/tmp/vellum-ax-copy-native-candidate-5ba6e86/receipt.json'))['result']=='PASS_NATIVE_CANDIDATE_COMPILE_ONLY','passing final delta and native compilation')
  need(read(W/'provider-disposition.json')['accepted']and read(W/'prism/receipt.json')['provider']=='anthropic'and read(W/'prism/receipt.json')['model']=='claude-sonnet-5-5','accepted selected provider checkpoint')
  message=W/'commit-message.txt'
  with message.open('x')as out:out.write('perf(a11y): batch detached snapshot field storage\n\nCopy accessibility records into snapshot-owned typed field slices instead of allocating each optional field separately. Keep Actions slices capacity-limited, exact nil-action baseline semantics, arbitrary Value admission and pending/completed cache lifecycle. No cross-snapshot storage reuse.\n\nAdd frozen legacy copy, bit-preservation, alias/append isolation and constant allocation regressions; verify the allocation bound fails on exact prior source. Affected driver root-package offscreen race tests, vet and local copy/publication benchmarks pass. Reviewed internally and once with Prism Anthropic Claude Sonnet5.5. Native performance, memory budgets and full Mac qualification remain open.\n')
  need(m.git_admission(T)==admit['candidate']and m.git_admission(C)==admit['canonical'],'Git admission unchanged');m.mutation(T,'source-commit',['git','commit','--file',str(message)],d)
  commit=m.git(T,'rev-parse','HEAD').decode().strip();need(m.clean(T)and m.git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit'],'candidate committed');need(set(m.git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources']),'committed names')
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==admit['canonical'],'canonical admission');m.mutation(C,'source-fast-forward',['git','merge','--ff-only',commit],d)
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==commit,'canonical head')
  files=m.git(T,'ls-files','-z').decode().split('\0')[:-1];need(len(files)==4669 and all(sha(T/p)==sha(C/p)for p in files),'tracked parity');need(prepared(T)==prepared(C)==source['prepared'],'prepared parity');need(m.clean(T)and m.clean(C),'clean endpoints')
  d.update(result='REVIEWED_ACCESSIBILITY_COPY_SOURCE_COMMITTED_AND_INTEGRATED',commit=commit,parent=b['base_commit'],source_files=len(files),prepared_files=len(source['prepared']),both_clean=True,canonical_promoted=True,binding_sha256=sha(W/'final-binding.json'),review_sha256=sha(W/'final-review.json'),provider_calls=1,native_candidate_executed=False,native_frame_gain_qualified=False,full_macos_qualified=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  failed=False
  for label,root in [('candidate',T),('canonical',C)]:
   try:d[label+'_terminal']=m.observation(root)
   except BaseException as e:failed=True;d[label+'_observation_error']=dict(type=type(e).__name__,message=str(e))
  if failed:d.update(result='FAILED_TERMINAL_OBSERVATION',both_clean=False)
  with output.open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps(d),flush=True)
  if failed and d['error']is None:raise RuntimeError('terminal observation failed')
if __name__=='__main__':main()
