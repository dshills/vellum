from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
b=read(W/'binding.json');changed='drivers/cogent/accessibility_snapshot_copy_offscreen_test.go'
assert git('rev-parse','HEAD').decode().strip()==b['base_commit']and set(git('diff','--cached','--name-only').decode().splitlines())==set(b['sources'])
assert all(hashlib.sha256(git('show',':'+p)).hexdigest()==h for p,h in b['sources'].items())
assert git('diff','--name-only').decode().splitlines()==[changed]and not git('ls-files','--others','--exclude-standard')
assert all(sha(T/p)==h for p,h in b['sources'].items()if p!=changed)
subprocess.run(['git','add','--',changed],cwd=T,check=True,timeout=20);payload=git('diff','--cached','--binary');(W/'final-staged.diff').write_bytes(payload)
out=dict(base_commit=b['base_commit'],sources={p:sha(T/p)for p in b['sources']},staged_diff_sha256=hashlib.sha256(payload).hexdigest(),staged_diff_bytes=len(payload),prior_provider_binding_sha256=sha(W/'binding.json'),post_provider_delta='Test-only explicit zero-action multi-node cases; production unchanged.')
(W/'final-binding.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
