"""Require the new allocation regression to fail on the exact prior copy source."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-ax-copy-buffers-checks-v1')
spec=importlib.util.spec_from_file_location('owned_copy_counterfactual',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
read=lambda p:json.loads(Path(p).read_bytes());pins=read(W/'source-v1.json')
for p in [Path(__file__).resolve(),W/'counterfactual-overlay.json',W/'counterfactual-test.go.txt',W/'original.go.txt',W.parent/'macos-sdk-native-238b3b6/run.py']:pins[str(p)]=g.sha(p)
assert read(P/'receipt.json')['result']=='PASS_NON_NATIVE_AX_COPY_CHECKS'
run=g.execute(['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','test','-overlay',str(W/'counterfactual-overlay.json'),'-tags','offscreen','-run','^TestAccessibilitySnapshotCopyAllocationBound$','-count=1','.'],T/'drivers/cogent',P/'counterfactual',lambda:False,lambda:all(g.sha(p)==h for p,h in pins.items()),timeout=180,limit=4<<20)
stdout=(P/'counterfactual/stdout').read_text();expected=run['exit_code']==1 and 'allocations exceed one node slice and six field slices'in stdout and 'FAIL: TestAccessibilitySnapshotCopyAllocationBound'in stdout
ok=expected and run['error']is None and run['logs_complete']and run['pins_stable']and not run['observation_errors']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
d=dict(result='PASS_COUNTERFACTUAL_ALLOCATION_REGRESSION'if ok else'FAIL_COUNTERFACTUAL',inputs=pins,run=run,expected_test_failure=expected,native_runtime_executed=False);(P/'counterfactual.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert ok
bench=g.execute(['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','test','-overlay',str(W/'counterfactual-overlay.json'),'-tags','offscreen','-run','^$','-bench','^BenchmarkAccessibilityGridPublicationPrepare$','-benchmem','-benchtime=300ms','-count=5','.'],T/'drivers/cogent',P/'baseline-bench',lambda:False,lambda:all(g.sha(p)==h for p,h in pins.items()),timeout=180,limit=4<<20)
ok=bench['exit_code']==0 and bench['error']is None and bench['logs_complete']and bench['pins_stable']and not bench['observation_errors']and bench['owned']['terminal']and bench['owned']['group_absent']and not bench['owned']['errors'];(P/'baseline-bench.json').write_text(json.dumps(dict(result='PASS_PRIOR_PUBLICATION_BENCHMARK'if ok else'FAIL_PRIOR_PUBLICATION_BENCHMARK',inputs=pins,run=bench,native_runtime_executed=False),indent=2)+'\n');assert ok
