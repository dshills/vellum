"""Non-native source-pinned AX copy checks with owned child cleanup."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-ax-copy-buffers-checks-v1')
spec=importlib.util.spec_from_file_location('owned_runner',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sha=g.sha;read=lambda p:json.loads(Path(p).read_bytes())
def main():
 pins=read(W/'source-v1.json');pins[str(Path(__file__).resolve())]=sha(__file__);pins[str(W.parent/'macos-sdk-native-238b3b6/run.py')]=sha(W.parent/'macos-sdk-native-238b3b6/run.py');stable=lambda:all(sha(p)==h for p,h in pins.items())
 g.need(not P.exists(),'fresh checks');P.mkdir(mode=0o700);d=dict(result='INCOMPLETE',native_runtime_executed=False,inputs=pins,commands=[])
 try:
  commands=[('race',['test','-tags','offscreen','-race','-count=1','-timeout=5m','.'],420),('vet',['vet','-tags','offscreen','.'],180),('bench',['test','-tags','offscreen','-run','^$','-bench','BenchmarkAccessibility(SnapshotCopy|GridPublicationPrepare)$','-benchmem','-benchtime=300ms','-count=5','.'],180)]
  for name,args,timeout in commands:
   run=g.execute(['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go',*args],T/'drivers/cogent',P/name,lambda:False,stable,timeout=timeout,limit=8<<20);d['commands'].append(dict(name=name,run=run))
   (P/(name+'.json')).write_text(json.dumps(run,indent=2)+'\n')
   g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and not run['observation_errors']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'terminal '+name)
  d['result']='PASS_NON_NATIVE_AX_COPY_CHECKS'
 finally:
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
if __name__=='__main__':main()
