"""Stage only the bounded accessibility copy implementation, regression and contract."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');BASE='5ba6e86be606efb34c5a223c47db6753714fc69e'
paths=['drivers/cogent/accessibility_grid_publication.go','drivers/cogent/accessibility_snapshot_copy_offscreen_test.go','specs/accessibility.md'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines())==set(paths)
assert all((T/p).is_file()and not(T/p).is_symlink()for p in paths)
subprocess.run(['git','add','--',*paths],cwd=T,check=True,timeout=20)
assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard')
payload=git('diff','--cached','--binary');(W/'staged.diff').write_bytes(payload)
b=dict(base_commit=BASE,sources={p:sha(T/p)for p in paths},staged_diff_bytes=len(payload),staged_diff_sha256=hashlib.sha256(payload).hexdigest());(W/'binding.json').write_text(json.dumps(b,indent=2)+'\n');print(json.dumps(b))
