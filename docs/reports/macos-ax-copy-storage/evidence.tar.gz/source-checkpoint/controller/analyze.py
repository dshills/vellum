from pathlib import Path
import hashlib,json,re,statistics
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-ax-copy-buffers-checks-v1');read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(P/'receipt.json')['result']=='PASS_NON_NATIVE_AX_COPY_CHECKS'and read(P/'counterfactual.json')['result']=='PASS_COUNTERFACTUAL_ALLOCATION_REGRESSION'and read(P/'baseline-bench.json')['result']=='PASS_PRIOR_PUBLICATION_BENCHMARK'
def rows(path):
 groups={}
 for line in path.read_text().splitlines():
  if not line.startswith('Benchmark'):continue
  name,iterations,ns,nsunit,bytes_,bunit,alloc,aunit=line.split();assert nsunit=='ns/op'and bunit=='B/op'and aunit=='allocs/op';groups.setdefault(name,[]).append(dict(iterations=int(iterations),ns_per_op=float(ns),bytes_per_op=float(bytes_),allocs_per_op=float(alloc)))
 assert all(len(v)==5 for v in groups.values());return groups
candidate=rows(P/'bench/stdout');baseline=rows(P/'baseline-bench/stdout');assert len(candidate)==4 and len(baseline)==2
summary=lambda records:{k:statistics.median(r[k]for r in records)for k in['ns_per_op','bytes_per_op','allocs_per_op']}
comparisons={}
for name,records in candidate.items():
 if 'SnapshotCopy/batch-'in name:prior=next(v for k,v in candidate.items()if 'SnapshotCopy/legacy-'in k)
 elif 'GridPublicationPrepare/'in name:prior=baseline[name]
 else:continue
 old,new=summary(prior),summary(records);comparisons[name]=dict(prior_median=old,candidate_median=new,ratio={k:new[k]/old[k]for k in old})
source=read(W/'full-source-during-checks.json');assert all(sha(T/p)==h for p,h in source['files'].items());prepared={p.relative_to(T/'drivers/cogent/build').as_posix():sha(p)for module in['upstream','typesetting']for p in(T/'drivers/cogent/build'/module).rglob('*')if p.is_file()};assert prepared==source['prepared']
result=dict(result='PASS_LOCAL_ALLOCATION_AND_LEGACY_CONTROLS',candidate_rows=candidate,baseline_publication_rows=baseline,comparisons=comparisons,source_endpoint_stable=True,prepared_endpoint_stable=True,source_files=len(source['files']),prepared_files=len(prepared),native_runtime_executed=False,full_macos_qualified=False,limits=['sequential local microbenchmarks; median of five observations, no statistical/native frame claim','synthetic 400-node copy fixture populates all optional pointers; ready publication fixture has400cells+host','benchmark labels report14 CPUs despite child GOMAXPROCS2 request; retain actual label and no exclusive-core claim','allocated bytes slightly increase for all-fields copy; no retained or native/GPU memory reduction claimed'])
(W/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(result=result['result'],comparisons=comparisons)))
