"""Compile the exact staged AX copy candidate; do not execute a native app."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-ax-copy-native-candidate-5ba6e86')
spec=importlib.util.spec_from_file_location('owned_ax_copy_build',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);read=lambda p:json.loads(Path(p).read_bytes())
source=read(W/'full-source-during-checks.json');pins={str(T/p):h for p,h in source['files'].items()};pins.update({str(T/'drivers/cogent/build'/p):h for p,h in source['prepared'].items()});pins[str(Path(__file__).resolve())]=g.sha(__file__);pins[str(W.parent/'macos-sdk-native-238b3b6/run.py')]=g.sha(W.parent/'macos-sdk-native-238b3b6/run.py');stable=lambda:all(g.sha(p)==h for p,h in pins.items())
assert not P.exists()and stable();P.mkdir(mode=0o700);d=dict(result='INCOMPLETE',base_commit=source['base_commit'],source_identity='exact staged three-file candidate; not yet committed',source_sha256=g.sha(W/'full-source-during-checks.json'),inputs=pins,native_runtime_executed=False,commands=[])
try:
 for name,args,cwd in [('build',['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','build','-trimpath','-o',str(P/'loadedgrid'),'.'],T/'examples/loadedgrid'),('metadata',['/opt/homebrew/bin/go','version','-m',str(P/'loadedgrid')],P)]:
  run=g.execute(args,cwd,P/name,lambda:False,stable,timeout=240,limit=4<<20);d['commands'].append(dict(name=name,run=run));g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and not run['observation_errors']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'terminal '+name)
 d.update(result='PASS_NATIVE_CANDIDATE_COMPILE_ONLY',binary=dict(path=str(P/'loadedgrid'),bytes=(P/'loadedgrid').stat().st_size,sha256=g.sha(P/'loadedgrid')))
finally:
 (P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='inputs'}),flush=True)
