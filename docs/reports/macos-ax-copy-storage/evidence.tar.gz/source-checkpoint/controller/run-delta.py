"""Post-provider test-only regression addition; no production source delta."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-ax-copy-buffers-checks-v1')
spec=importlib.util.spec_from_file_location('owned_ax_copy_delta',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);read=lambda p:json.loads(Path(p).read_bytes());source=read(W/'full-source-final.json');pins={str(T/p):h for p,h in source['files'].items()};pins.update({str(T/'drivers/cogent/build'/p):h for p,h in source['prepared'].items()});pins[str(Path(__file__).resolve())]=g.sha(__file__);stable=lambda:all(g.sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',source_sha256=g.sha(W/'full-source-final.json'),native_runtime_executed=False,commands=[])
try:
 for name,args in [('delta-race',['test','-race','-tags','offscreen','-run','^TestAccessibilitySnapshotCopy','-count=1','-timeout=60s','.']),('delta-vet',['vet','-tags','offscreen','.'])]:
  run=g.execute(['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go',*args],T/'drivers/cogent',P/name,lambda:False,stable,timeout=120,limit=4<<20);d['commands'].append(dict(name=name,run=run));g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and not run['observation_errors']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'terminal '+name)
 d['result']='PASS_POST_PROVIDER_TEST_ONLY_DELTA'
finally:
 (P/'delta.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
