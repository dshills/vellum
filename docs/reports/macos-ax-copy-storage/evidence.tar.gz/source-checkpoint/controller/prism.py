"""One provider checkpoint for the exact internally reviewed accessibility snapshot-copy endpoint."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,importlib.util
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');O=W/'prism'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
b=read(W/'binding.json');r=read(W/'preprism-review.json');assert r['prism_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
assert all(sha(T/p)==h for p,h in b['sources'].items())and not git('diff','--name-only')
payload=git('diff','--cached','--binary');assert hashlib.sha256(payload).hexdigest()==b['staged_diff_sha256']and len(payload)==b['staged_diff_bytes']<40000
O.mkdir(mode=0o700);(O/'payload.diff').write_bytes(payload)
rules={'focus':[
'Review actionable correctness in batched accessibility snapshot field copies. The change is confined to detached Go field storage; no native JSON protocol, action admission, callback generation or pending/completed lifecycle change is intended.',
'cloneAccessibilityNodes allocates a new node slice then exact-counted local typed field slices. Ready scoped cache groups also detach their own fields after copying indexed nodes. Every copy has fresh storage, no cross-snapshot pool/reuse. Each Actions slice capacity equals length; nil Actions normalize to nonnil empty exactly as the frozen prior clone. Pending baseline explicitly restores nil actions for exact null wire semantics. Optional pointers remain nil or become independently copied pointees, preserving exact floating-point bits.',
'Arbitrary Value remains shallow as before; custom/mutable values retain the existing non-immutable publication route. Cache construction still clears activationGuard; pending baseline clears activationGuard/pressFocusID. Pending scopes clone detached completed nodes, revoke handlers/actions/focus/editing and preserve correct generations/frames. Removal/bridge closure still clears retained state. Inspect bounds, aliasing and mutation isolation rather than proposing shared mutable caches.',
'Tests include the exact frozen prior clone oracle, nil/empty/sparse fields, Unicode, float bits, deliberately aliased source pointers, cross-node and source/output/later-copy mutations, Actions append isolation, constant allocation bound, and an overlay counterfactual where the new allocation bound fails against exact prior source. Existing complete affected root-package offscreen race tests and vet cover pending/completed, action revocation, duplicate readiness, arbitrary Value and lifecycle. Copy/publication benchmarks are local observations; no native latency, memory-budget, speedup or full Mac qualification is claimed.'
]}
(O/'rules.json').write_text(json.dumps(rules,indent=2)+'\n')
binary=Path('/Users/dshills/Development/Go/bin/prism');old=Path('/private/tmp/vellum-native-attestation-probe-20261016');assert sha(binary)==read(old/'prism-staged-v3/receipt.json')['binary_sha256']
spec=importlib.util.spec_from_file_location('ax_copy_prism_retirement',old/'run-verifier.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
argv=[str(binary),'review','staged','--paths',','.join(b['sources']),'--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','40000','--max-diff-bytes','40000','--rules',str(O/'rules.json'),'--format','json','--out',str(O/'prism.json')]
env=os.environ.copy();env.update(GOENV='off',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod',GOCACHE='/Users/dshills/Library/Caches/go-build',GOPATH='/Users/dshills/Development/Go',GOPROXY='off',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly -p=1',GOMAXPROCS='2',PYTHONDONTWRITEBYTECODE='1')
d=dict(argv=argv,provider='anthropic',model='claude-sonnet-5-5',binary_sha256=sha(binary),binding_sha256=sha(W/'binding.json'),source_review_sha256=sha(W/'preprism-review.json'),producer_sha256=sha(__file__),payload_sha256=sha(O/'payload.diff'),payload_bytes=len(payload),files=len(b['sources']),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=None);errors=[];child=None;start=time.monotonic()
try:
 with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:
  child=subprocess.Popen(argv,cwd=T,env=env,stdout=out,stderr=err,start_new_session=True);d['owned_pid']=child.pid
  while child.poll()is None:
   if time.monotonic()-start>240:raise TimeoutError('Prism watchdog')
   if(O/'stdout').stat().st_size>8<<20 or(O/'stderr').stat().st_size>8<<20:raise RuntimeError('Prism output bound')
   time.sleep(.1)
  d['exit_code']=child.wait()
except BaseException as e:errors.append(type(e).__name__+': '+str(e))
finally:
 d.update(runner.retire_owned(child,errors));after=runner.attempt(errors,'terminal staged diff',lambda:git('diff','--cached','--binary'))
 source_stable=runner.attempt(errors,'terminal source hashes',lambda:all(sha(T/p)==h for p,h in b['sources'].items()))
 binary_stable=runner.attempt(errors,'terminal Prism binary',lambda:sha(binary)==d['binary_sha256'])
 log_bound=runner.attempt(errors,'terminal log bounds',lambda:all((O/n).stat().st_size<=8<<20 for n in ['stdout','stderr']))
 if log_bound is False:errors.append('terminal Prism log byte limit exceeded')
 artifacts={n:runner.attempt(errors,'terminal artifact '+n,lambda n=n:sha(O/n)if(O/n).exists()else None)for n in ['prism.json','stdout','stderr']}
 d.update(errors=errors,seconds=time.monotonic()-start,sources_stable=source_stable is True,staged_diff_stable=after is not None and hashlib.sha256(after).hexdigest()==b['staged_diff_sha256'],binary_stable=binary_stable is True,terminal_logs_within_bound=log_bound is True,artifacts=artifacts)
 (O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:d[k]for k in ['exit_code','errors','seconds','sources_stable','staged_diff_stable','owned_group_absent','artifacts']}));assert d['exit_code']in[0,1]and not errors and d['sources_stable']and d['staged_diff_stable']and d['binary_stable']and d['owned_group_absent']and d['terminal_logs_within_bound']
