"""Build the installed Go distribution's bundled pprof command, offline."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
W=Path(__file__).resolve().parent;T=Path('/Users/dshills/Development/projects/Vellum');O=Path('/private/tmp/vellum-profile-pprof-tool-1ba954c');O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};root=Path(subprocess.check_output(['go','env','GOROOT'],env=env,text=True,timeout=10).strip())
sources={str(p):sha(p)for sub in ['src/cmd/pprof','src/cmd/vendor/github.com/google/pprof','src/cmd/internal/objfile']for p in(root/sub).rglob('*')if p.is_file()};assert sources
argv=['go','build','-p=1','-trimpath','-o',str(O/'pprof'),'cmd/pprof'];started=time.monotonic()
with(O/'build.stdout').open('xb')as out,(O/'build.stderr').open('xb')as err:result=run_child(argv,cwd=T,env=env,stdout=out,stderr=err,timeout=180,log_limit_bytes=4<<20)
record={'argv':argv,'cwd':str(T),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started,'bundled_main_pprof_objfile_source':sources,'source_stable':all(sha(p)==h for p,h in sources.items()),'framework_native_application_executed':False,'network_requested':False,'producer_sha256':sha(__file__)}
if result.returncode==0:
 binary=O/'pprof';record['binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary)}
 for name,args in [('metadata',['go','version','-m',str(binary)]),('help',[str(binary),'-help'])]:
  with(O/(name+'.stdout')).open('xb')as out,(O/(name+'.stderr')).open('xb')as err:r=run_child(args,cwd=T,env=env,stdout=out,stderr=err,timeout=20,log_limit_bytes=2<<20)
  record[name+'_exit_code']=r.returncode
 text=(O/'help.stdout').read_text()+(O/'help.stderr').read_text();assert all(s in text for s in ['symbolize','sample_index','nodecount','unit','cum','top'])
record['logs']={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in O.iterdir()if p.is_file()and p.name!='pprof'};record['success']=result.returncode==0 and record['source_stable'];(O/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items()if k not in ['bundled_main_pprof_objfile_source','logs']}));assert record['success']
