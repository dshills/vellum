import hashlib,json,re,sys
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-notification-runtime');sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
result={}
for name,tag in [('default',None),('offscreen','offscreen'),('offscreen_opt_in','offscreen,vellum_native_checks'),('opt_in','vellum_native_checks')]:
 argv=['go','list','-json','-export']+(['-tags='+tag]if tag else [])+['.']
 r=run_child(argv,cwd=root/'drivers/cogent',env=env,capture_output=True,timeout=120);assert r.returncode==0,r.stderr.decode()
 data=json.loads(r.stdout);archive=Path(data['Export']);nm=run_child(['go','tool','nm',str(archive)],env=env,capture_output=True,timeout=60);assert nm.returncode==0,nm.stderr.decode()
 symbols=sorted(n for n in ["NativeNotificationCheckBundle","InspectNativeNotifications","nativeNotificationCheckValidate","nativeNotificationCheckFixture","decodeNativeNotificationInventory","vellumNotificationCheck","vellumNotificationCheckBundle","vellumNotificationCheckValidate","vellumNotificationCheckFixture"] if n in nm.stdout.decode())
 diag_go='notification_checks_darwin.go' in data.get('CgoFiles',[]);diag_c='notification_checks_darwin.m' in data.get('MFiles',[]);macro='-DVELLUM_NATIVE_CHECKS' in data.get('CgoCFLAGS',[])
 result[name]={'argv':argv,'cgo_files':data.get('CgoFiles',[]),'objective_c_files':data.get('MFiles',[]),'cgo_flags':data.get('CgoCFLAGS',[]),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'diagnostic_symbols':symbols,'probe_go':diag_go,'probe_objc':diag_c,'macro':macro}
 if tag=='vellum_native_checks':assert diag_go and diag_c and macro and len(symbols)==9,result[name]
 else:assert not diag_go and not diag_c and not macro and not symbols,result[name]
(phase/'isolation-result.json').write_text(json.dumps({'result':'PASS_DEFAULT_OFFSCREEN_OPT_IN_ISOLATION','modes':result},indent=2)+'\n');print('PASS_DEFAULT_OFFSCREEN_OPT_IN_ISOLATION')
