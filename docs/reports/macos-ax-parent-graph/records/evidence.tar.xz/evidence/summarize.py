"""Summarize complete matched observations without assigning frame gains."""
from pathlib import Path
import hashlib,json,statistics
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={"scope":"Foundation JSON parse and complete native snapshot validation only", "comparisons":{}}
for phase,file,candidate in [("v1","benchmarks.json","candidate"),("v2","benchmarks-v2.json","candidate-v2")]:
    data=json.loads((P/file).read_text())
    assert data["result"]=="PASS_SCOPED_LOCAL_VALIDATION_BENCHMARKS"
    cases={}
    for name in data["records"][0]["values"]:
        groups={}
        for variant in ["baseline",candidate]:
            records=[r for r in data["records"] if r["variant"]==variant]
            assert sorted(r["run"] for r in records)==[1,2,3,4,5]
            values=[r["values"][name]["ns_per_op"]/1e6 for r in records]
            groups[variant]={"observations_ms_per_op":values,"median":statistics.median(values),"min":min(values),"max":max(values)}
        cases[name]=groups
    result["comparisons"][phase]={"benchmark_receipt_sha256":sha(P/file),"cases":cases}
result["native_allocation_bytes_qualified"]=False
result["ordinary_frame_gain_qualified"]=False
with(P/"summary.json").open("x") as out:out.write(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
