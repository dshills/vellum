"""Freeze baseline bytes and copy prepared dependencies for isolated AX work."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
C=Path('/Users/dshills/Development/projects/Vellum')
R=Path('/private/tmp/vellum-ax-graph');P=Path(__file__).resolve().parent
BASE='cebae61a01b9ca1d5f71beacd9d60ad5fd853fa7'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C).decode().strip()==BASE
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==BASE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=C).strip()
names=subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')
tracked={n:sha(C/n)for n in names if n};assert len(tracked)==4485
prepared={f.relative_to(C/'drivers/cogent/build').as_posix():sha(f)
    for m in ['upstream','typesetting']for f in sorted((C/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
assert len(prepared)==6229
for m in ['upstream','typesetting']:
    shutil.copytree(C/'drivers/cogent/build'/m,R/'drivers/cogent/build'/m)
assert prepared=={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)
    for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
baseline=P/'baseline/accessibility_darwin.m';baseline.parent.mkdir(exist_ok=True)
with baseline.open('xb')as out:out.write((C/'drivers/cogent/accessibility_darwin.m').read_bytes())
record={'base_commit':BASE,'tracked':tracked,'prepared':prepared,'baseline_native_sha256':sha(baseline),
    'producer_sha256':sha(Path(__file__)),'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'native_application_executed':False,'canonical_source_changed':False}
with(P/'baseline.json').open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
print('Frozen clean baseline:4485tracked/6229prepared; copied isolated dependencies.')
