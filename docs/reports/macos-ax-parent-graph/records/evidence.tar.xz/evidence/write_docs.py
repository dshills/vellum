"""Write checkpoint prose only after all selected evidence is terminal and valid."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['test-baseline','test-candidate-v2','candidate-v2-race','candidate-v2-vet','build-native-smoke']:
    d=read(P/(name+'.json'));assert d['exit_code']==0 and d['error']is None and d['source_stable']
assert read(P/'native-smoke.json')['result']=='PASS_SCOPED_NATIVE_AX_SMOKE'
assert read(P/'negative-control-v2.json')['result']=='PASS_INTENDED_NEGATIVE_CONTROLS'
summary=read(P/'summary.json')['comparisons']
contract='''

## Native parent graph validation

The Mac snapshot preflight validates the complete immutable parent graph before
retained elements, publication epochs, focus, geometry or notifications change.
After the existing ID/parent/scalar checks, a snapshot-local set holds every
nonempty referenced parent ID. Traversal starts only at node keys still in that
set. An active-path set detects cycles; a successful root or completed tail
retires its active IDs from the remaining set. Missing traversed nodes refuse
immediately. The remaining set must be empty at the end, including missing
parents referenced solely by skipped leaves. Empty snapshots and forests remain
valid. No recursion, persistent traversal cache or mutation of the input map is
introduced; temporary set references are bounded by the input node count.

Every known referenced vertex is walked and retired at most once. This bounds
graph traversal to a linear number of expected constant-time hash operations;
it is not an unconditional elapsed-time or native-byte allocation guarantee.
String hashing/comparison, Foundation parsing and other field checks still cost
work. Unreferenced leaves receive no traversal-state entry.

Scope admission keeps the designated `ID == grid_scope` host, its allowed role,
self-scope, incarnation, target/completed generations, pending state and geometry
rules. A host may have no parent or an unscoped parent. Each scoped non-host
requires a direct parent in the same scope; ordinary nodes cannot have scoped
parents. In a finite parent-complete acyclic graph these local rules force each
scoped chain to reach its designated host, so no separate per-node ancestor set
is required. A non-host with a table/outline/canvas role is still a non-host.

The [parent graph checkpoint](../docs/reports/macos-ax-parent-graph/README.md)
retains independent ancestor-oracle tests, actual Foundation comparisons,
negative controls, matched topology benchmarks and a scoped live Cocoa smoke.
Validation work is outside `FrameMetrics.TotalUIWork`; these results cannot be
subtracted from the framework's unchanged frame-time targets.
'''
f=R/'specs/accessibility.md';f.write_text(f.read_text()+contract)
completion='''

## Native accessibility parent graph checkpoint

The [parent graph checkpoint](../docs/reports/macos-ax-parent-graph/README.md)
replaces repeated full ancestor walks with two bounded snapshot-local sets.
Independent original-rule oracles agree with both baseline and revised native
Foundation validation across 17,066 parent/scope cases, shuffled deep trees and
atomic refusals. The complete offscreen race suite and vet pass; an actual Cocoa
smoke exercises native semantics/actions, geometry, focus, virtual paging, modal
routing and the workbench bridge on the revised source.

Five alternating optimized benchmark pairs retain large deep-chain reductions
without the first candidate's wide-tree regression. Whole-validation observations
include JSON parsing; the wide-case ranges overlap, and the 451-node fixture
shows a modest local reduction. This work is outside exact TotalUIWork timing
and does not qualify the failed 4/6 ms ordinary targets, native/GPU memory,
current-source endurance, successful overnight, physical input, human IME/
VoiceOver, distribution or full Mac completion. The earlier failed soak remains
failed and retained.
'''
f=R/'specs/macos-completion.md';f.write_text(f.read_text()+completion)
cases=summary['v2']['cases'];rows=[]
for name in ['UIntFields','Graph/deep64','Graph/deep256','Graph/deep1024','Graph/wide1024']:
    a=cases['BenchmarkNativeAccessibilitySnapshot'+name]['baseline']
    b=cases['BenchmarkNativeAccessibilitySnapshot'+name]['candidate-v2']
    label='451-node grid topology'if name=='UIntFields'else name.removeprefix('Graph/')
    rows.append(f"| {label} | {a['median']:.6f} [{a['min']:.6f}, {a['max']:.6f}] | {b['median']:.6f} [{b['min']:.6f}, {b['max']:.6f}] |")
report='''# Native accessibility parent graph checkpoint

Mac snapshot validation now proves parent completeness and acyclicity once per
snapshot, using two local sets, instead of allocating an ancestor set and
rewalking each node's chain. It keeps all existing field/scope admission rules
and the preflight-before-mutation transaction boundary. See the
[contract](../../../specs/accessibility.md#native-parent-graph-validation).

## Correctness and lifecycle

The new Darwin test uses an independent Go oracle with the original separate
ancestor sets and literal host membership. Actual baseline and revised Foundation
validation agree on 1,441 exhaustive parent graphs (146 accepted/1,295 refused)
and 15,625 exhaustive parent/scope graphs (83 accepted/15,542 refused). Other
fields are fixed valid values; existing envelope/integer suites continue to
cover those validators. Corpus SHA-256 values are respectively
`bc97bdddad84841f51f2a955c1a299877d3cc42aada8d23e3752b398b0e0bfcb`
and `f36790b1b98954df3ee4ab753e7c2a5b339e81f0b1891e4595591800de71407b`.

Seeded random and 1,024-node deep trees pass four input-order shuffles each;
missing parents, cycles and a scoped non-host with a host-like role are checked.
Five actual higher-generation refused native transactions preserve the previous
published generation and exposed element records, including identity, geometry,
value, focus and liveness. These observations do not directly inspect every
private text-cache/hierarchy field; the unchanged transaction ordering provides
the broader source argument. All traversal references remain invocation-local.

Deliberate guard omissions prove the oracle detects admission defects: the first
candidate's missing whole-graph and same-scope-parent controls compile but fail
the intended assertion; the final candidate's missing unresolved-parent refusal
also compiles and fails that assertion. Exact candidate bytes are restored after
each control. Full current-source offscreen `go test -race -p=1 -count=1
-tags=offscreen ./...` and `go vet -p=1 -tags=offscreen ./...` pass in the adapter
module. Native/dependency deprecation and duplicate-linker warnings are retained.

## Matched local performance

Two unchanged test bodies are compiled as optimized baseline/final executables
from base `cebae61`, with the identical 6,229 prepared dependency leaves. Each of
five alternating AB/BA pairs launches fresh sequential processes, explicitly uses
two Go benchmark CPUs, and takes 50 iterations per case. Medians and full observed
process-value ranges below are milliseconds per operation. No heavy test job or
owned native UI overlaps these selected runs; interleaving does not establish
continuous global host isolation.

| Fixture | Original median [min, max] | Revised median [min, max] |
| --- | ---: | ---: |
'''+ '\n'.join(rows)+'''

Each operation includes CGo entry, Foundation JSON parsing and complete native
snapshot validation. It excludes native commit, rendering and a real window.
The 451-node fixture is a representative topology, not a captured render
snapshot. The wide-case ranges overlap; its small median difference is not a
material performance claim. Deep-chain savings address the repeated traversal
visible in source. Go `B/op` and allocation counts exclude native/Foundation
allocations and cannot establish a native-memory budget.

The first candidate passed correctness but regressed wide1024 from 2.203794 to
3.063945 ms median (~39%); it was rejected. Its full runs, code, reviews and
controls remain retained. The final design skips traversal state for leaves.
A prior baseline pilot exited zero but its producer refused a CPU suffix of 14
instead of the expected 2. That failed producer run is preserved and excluded;
selected campaigns explicitly set `-test.cpu=2`. The suffix's original cause is
unassigned.

## Live scope and remaining gates

One existing `cmd/accessibility-smoke` executable built from the final native
source runs successfully in a real Cocoa application. It queries the reachable
native tree, roles/labels/values/hit testing, controlled actions and disabled
refusal, keyboard routing/focus, virtual table/outline paging/disclosure,
modal isolation and the live workbench bridge. Keyboard events are injected
through the toolkit; this is automated native routing, not physical input or
human VoiceOver acceptance. The controller observes a terminal zero exit and
owned process-group absence, exact source/binary/log stability, the shared native
lease and human-return markers. It does not inventory all OS native resources.
No OS input source, VoiceOver, clipboard or preferences are changed.

The baseline build/test and final build/test/race/vet/native build/run pin their
actual source delta, baseline manifest, command, terminal status and raw logs.
The 4,485 tracked baseline files and 6,229 prepared dependency leaves are checked
before/after code checks and the native run. The final code endpoint matches the
reviewed bytes; subsequent changes are documentation/evidence only. Earlier
candidate results are historical and explicitly separate.

Snapshot validation is outside the exact `FrameMetrics.TotalUIWork` interval.
These measurements do not establish a whole-frame or ordinary P6 improvement;
the 4 ms p95/6 ms p99 targets remain failed. Current-source endurance, a successful
overnight soak, native/GPU allocation and app-wide wake/present budgets, physical
pointer/display checks, human IME/VoiceOver, interoperability and distribution
remain open. The earlier failed overnight result stays failed. Full Mac and
public release acceptance are not granted.

The raw evidence, producers/dependencies, original and intermediate source,
checks, failed pilot, both benchmark campaigns and internal/provider reviews are
indexed in `records/archive-index.json` and stored in `records/evidence.tar.xz`.
Private executable identities are retained in receipts; executable files are
not shipped in the evidence archive. `records/qualification.json` binds this
scoped checkpoint to its exact reviewed sources and archive.
'''
f=R/'docs/reports/macos-ax-parent-graph/README.md';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(report)
f=R/'docs/reports/README.md';f.write_text(f.read_text()+'\n- [Native accessibility parent graph](macos-ax-parent-graph/README.md): bounded shared parent validation, independent oracle coverage, matched topology observations and scoped live Cocoa routing.\n')
files=['drivers/cogent/accessibility_darwin.m','drivers/cogent/accessibility_graph_darwin_test.go','specs/accessibility.md','specs/macos-completion.md','docs/reports/README.md','docs/reports/macos-ax-parent-graph/README.md']
with(P/'checkpoint-sources.json').open('x')as out:out.write(json.dumps({n:sha(R/n)for n in files},indent=2)+'\n')
