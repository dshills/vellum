"""Seal the exact reviewed scoped graph checkpoint, including rejected variants."""
from pathlib import Path
import datetime,hashlib,io,json,re,statistics,subprocess,tarfile
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
D=R/'docs/reports/macos-ax-parent-graph/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
review=read(P/'checkpoint-source-review.json');sources=review['sources']
assert review['prism_ready']and not review['unresolved_findings']
assert all(sha(R/n)==h for n,h in sources.items())
assert all(sha(P/n)==h for n,h in review['reviewed_producers'].items())
execution=read(P/'prism-execution.json');prism=read(P/'prism.json');resolution=read(P/'provider-resolution.json')
assert execution['exit_code']in [0,1]and execution['error']is None and execution['sources_stable']and execution['staged_sources_stable']and execution['staged_diff_stable']
assert execution['sources']==execution['staged_sources']==sources
assert execution['review_sha256']==sha(P/'checkpoint-source-review.json')and execution['producer_sha256']==sha(P/'prism_run.py')
assert execution['staged_diff_sha256']==sha(P/'prism-staged.diff')==hashlib.sha256(subprocess.check_output(['git','diff','--cached','--binary'],cwd=R,timeout=10)).hexdigest()
for ch in ['json','stdout','stderr']:assert execution[ch+'_sha256']==sha(P/('prism.'+ch))
coverage=prism['coverage']
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]and coverage['complete']and coverage['files']==len(sources)
assert coverage['llmCalls']==coverage['chunks']==1 and not any([coverage['excluded'],coverage['skipped'],coverage['truncatedBytes']])
counts={k:len(prism[k])for k in ['findings','discarded','suppressed']}
assert resolution['all_findings_triaged']and not resolution['unresolved_blocking_findings']and resolution['source_changed']is False
assert resolution['observed_finding_counts']==counts and resolution['prism_report_sha256']==sha(P/'prism.json')and resolution['prism_execution_sha256']==sha(P/'prism-execution.json')
checks={}
for n in ['build-baseline','test-baseline','build-candidate','test-candidate','candidate-race','candidate-vet','build-candidate-v2','test-candidate-v2','candidate-v2-race','candidate-v2-vet','build-native-smoke']:
    d=read(P/(n+'.json'));assert d['exit_code']==0 and d['error']is None and d['source_stable']
    assert d['baseline_manifest_sha256']==sha(P/'baseline.json')and d['prepared_files']==6229
    for ch in ['stdout','stderr']:assert d['logs'][ch]['sha256']==sha(P/(n+'.'+ch))
    if n in ['build-candidate-v2','test-candidate-v2','candidate-v2-race','candidate-v2-vet','build-native-smoke']:
        assert d['source_delta']=={k:v for k,v in sources.items()if k.startswith('drivers/')}
    if 'binary'in d:
        f=Path(d['binary']['path']);assert sha(f)==d['binary']['sha256']and f.stat().st_size==d['binary']['bytes']
    checks[n]={'receipt_sha256':sha(P/(n+'.json')),'elapsed_seconds':d['elapsed_seconds'],'exit_code':0}
summary=read(P/'summary.json')
for phase,filename,prefix in [('v1','benchmarks.json','bench-'),('v2','benchmarks-v2.json','v2-bench-')]:
    data=read(P/filename);assert data['result']=='PASS_SCOPED_LOCAL_VALIDATION_BENCHMARKS'and len(data['records'])==10
    assert summary['comparisons'][phase]['benchmark_receipt_sha256']==sha(P/filename)
    for row in data['records']:
        name=f"{prefix}{row['run']}-{row['variant']}";d=read(P/(name+'.json'))
        assert row['receipt_sha256']==sha(P/(name+'.json'))and d['result']=='TERMINAL_INERT_BENCHMARK_OK'and d['exit_code']==0 and d['error']is None
        for ch in ['stdout','stderr']:assert d['logs'][ch]['sha256']==sha(P/(name+'.'+ch))
        assert '-test.cpu=2'in d['argv']and '-test.benchtime=50x'in d['argv']
        parsed={}
        for line in(P/(name+'.stdout')).read_text().splitlines():
            match=re.fullmatch(r'(Benchmark\S+)-2\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line.strip())
            if match:
                key,count,ns,gb,ga=match.groups();assert count=='50'and key not in parsed
                parsed[key]={'ns_per_op':float(ns),'go_bytes_per_op':int(gb),'go_allocs_per_op':int(ga)}
        assert parsed==row['values']and len(parsed)==5
    for name,variants in summary['comparisons'][phase]['cases'].items():
        for variant,stats in variants.items():
            values=[r['values'][name]['ns_per_op']/1e6 for r in data['records']if r['variant']==variant]
            assert len(values)==5 and values==stats['observations_ms_per_op']and statistics.median(values)==stats['median']and min(values)==stats['min']and max(values)==stats['max']
for filename in ['negative-controls.json','negative-control-v2.json']:
    controls=read(P/filename);assert controls['result']=='PASS_INTENDED_NEGATIVE_CONTROLS'and controls['candidate_restored']
    for row in controls['controls']:
        root=P/'controls'/row['variant'];assert read(root/'result.json')==row
        assert row['compile_exit_code']==0 and row['test_exit_code']==1 and row['error']is None and row['intended_oracle_assertion_failed']and row['candidate_restored']
        for name,log in row['logs'].items():assert sha(root/name)==log['sha256']
        assert sha(root/'control.test')==row['binary']['sha256']
native=read(P/'native-smoke.json');assert native['result']=='PASS_SCOPED_NATIVE_AX_SMOKE'and native['exit_code']==0 and native['error']is None
assert all(native[k]for k in ['source_stable','artifacts_stable','direct_child_terminal','group_absence_confirmed','semantic_pass','logs_complete','shared_lease_held_through_cleanup'])and not native['cleanup_errors']and not native['stop_markers_at_exit']
assert native['source_delta']==read(P/'build-native-smoke.json')['source_delta']
for name,h in native['pins'].items():assert sha(P/name)==h
for ch in ['stdout','stderr']:assert native['logs'][ch]['sha256']==sha(P/('native-smoke.'+ch))
selected={}
for f in sorted(P.rglob('*')):
    if not f.is_file()or '__pycache__'in f.parts or f.suffix=='.test'or f.name=='native-smoke':continue
    assert not f.is_symlink();selected['evidence/'+f.relative_to(P).as_posix()]=f
for n in sources:selected['final-sources/'+n]=R/n
assert len(selected)<300 and sum(f.stat().st_size for f in selected.values())<16<<20
D.mkdir(parents=True,exist_ok=True);archive=D/'evidence.tar.xz';index=[]
with tarfile.open(archive,'x:xz',preset=3)as out:
    for name,f in sorted(selected.items()):
        data=f.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;out.addfile(entry,io.BytesIO(data))
        index.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:xz')as stored:
    members=stored.getmembers();assert len(members)==len(index)
    for member,row in zip(members,index):assert member.isfile()and member.name==row['path']and member.size==row['bytes']and hashlib.sha256(stored.extractfile(member).read()).hexdigest()==row['sha256']
with(D/'archive-index.json').open('x')as out:out.write(json.dumps({'members':index,'executable_binaries_included':False,'uncompressed_bytes':sum(r['bytes']for r in index)},indent=2)+'\n')
qualification={'schema':'vellum-macos-ax-parent-graph-v1','result':'PASS_SCOPED_NATIVE_PARENT_GRAPH_CHECKPOINT',
    'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':read(P/'baseline.json')['base_commit'],
    'checkpoint_sources':sources,'baseline_tracked_files':4485,'prepared_files':6229,'checks':checks,
    'native_smoke_receipt_sha256':sha(P/'native-smoke.json'),'summary_sha256':sha(P/'summary.json'),
    'internal_source_review_sha256':sha(P/'checkpoint-source-review.json'),'provider_resolution_sha256':sha(P/'provider-resolution.json'),
    'provider_review':{'execution_sha256':sha(P/'prism-execution.json'),'coverage':coverage,**counts},
    'archive_sha256':sha(archive),'archive_index_sha256':sha(D/'archive-index.json'),'seal_producer_sha256':sha(Path(__file__)),
    'original_overnight_qualified':False,'ordinary_frame_gain_qualified':False,'ordinary_warm_targets_qualified':False,
    'native_memory_qualified':False,'physical_pointer_qualified':False,'human_voiceover_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False}
with(D/'qualification.json').open('x')as out:out.write(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'result':qualification['result'],'archive_members':len(index),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive)}))
