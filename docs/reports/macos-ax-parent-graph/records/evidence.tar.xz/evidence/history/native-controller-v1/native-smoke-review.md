Native smoke is not execution-ready. Two fixes are required: bind the actual reviewed source/dependency/prerequisite artifact vector, and make cleanup steps independent so group-kill failure cannot skip direct kill/reap and pipe closure.

The V2 ten-run/fifty-row benchmark receipt/log/statistic bindings match. Wide ranges overlap; deep-chain results remain inert Foundation validation observations. The final-remainder control producer restores exact bytes and requires its intended independent oracle failure, but the reviewer did not execute it.
