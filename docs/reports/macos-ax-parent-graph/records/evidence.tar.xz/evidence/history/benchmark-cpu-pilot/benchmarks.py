"""Interleaved optimized Foundation-only observations; no native window."""
from pathlib import Path
import datetime,hashlib,json,re,sys,time
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
sys.path.insert(0,str(R/'scripts'))
sys.path.insert(0,'/private/tmp/vellum-macos-post-loop-native')
from child_process import run_child
from sdk_environment import child_environment
from live_lease import LiveLease
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
markers=[Path('/private/tmp/vellum-macos-listbox/stop-live'),P/'stop-live']
env=child_environment();env.update(GOMAXPROCS='2',GOPROXY='off')
sources={'producer':sha(Path(__file__)),'native':sha(R/'drivers/cogent/accessibility_darwin.m'),
    'tests':sha(R/'drivers/cogent/accessibility_graph_darwin_test.go'),
    'original_native':sha(P/'baseline/accessibility_darwin.m'),'baseline_manifest':sha(P/'baseline.json')}
builds={name:read(P/('build-'+name+'.json'))for name in ['baseline','candidate']}
pins={name:{'receipt_sha256':sha(P/('build-'+name+'.json')),'binary':builds[name]['binary']}for name in builds}
for name,build in builds.items():
    assert build['exit_code']==0 and build['error']is None and build['source_stable']
    assert build['baseline_manifest_sha256']==sha(P/'baseline.json') and build['prepared_files']==6229
    assert set(build['source_delta'])==({'drivers/cogent/accessibility_graph_darwin_test.go'}if name=='baseline'else
        {'drivers/cogent/accessibility_darwin.m','drivers/cogent/accessibility_graph_darwin_test.go'})
    assert build['source_delta']['drivers/cogent/accessibility_graph_darwin_test.go']==sources['tests']
    assert sha(P/(name+'.test'))==build['binary']['sha256']
assert 'drivers/cogent/accessibility_darwin.m'not in builds['baseline']['source_delta']
assert builds['candidate']['source_delta']['drivers/cogent/accessibility_darwin.m']==sources['native']
assert sources['original_native']==read(P/'baseline.json')['baseline_native_sha256']
for name in ['test-baseline','test-candidate','candidate-race','candidate-vet']:
    check=read(P/(name+'.json'))
    assert check['exit_code']==0 and check['error']is None and check['source_stable']
    for channel in ['stdout','stderr']:
        assert check['logs'][channel]['sha256']==sha(P/(name+'.'+channel))
controls=read(P/'negative-controls.json')
assert controls['result']=='PASS_INTENDED_NEGATIVE_CONTROLS' and controls['candidate_restored']
# Each invocation is a new process. AB/BA alternation reduces a fixed ordering
# bias but is not continuous host isolation or a native whole-frame comparison.
plan=[(run,variant)for run in range(5)for variant in (['baseline','candidate']if run%2==0 else['candidate','baseline'])]
records=[]
with LiveLease()as lease:
    for run,variant in plan:
        assert lease.held() and not any(marker.exists()for marker in markers)
        binary=P/(variant+'.test');build=pins[variant]
        assert sha(binary)==build['binary']['sha256']
        assert sha(P/('build-'+variant+'.json'))==build['receipt_sha256']
        name=f'bench-{run+1}-{variant}'
        argv=[str(binary),'-test.run=^$','-test.bench=^BenchmarkNativeAccessibilitySnapshot(UIntFields|Graph)$',
              '-test.benchtime=50x','-test.count=1','-test.timeout=90s']
        record={'argv':argv,'variant':variant,'run':run+1,'sources':sources,'build':build,
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'shared_lease_held':True,'native_window_executed':False,'exit_code':None,'error':None}
        start=time.monotonic()
        try:
            with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
                record['exit_code']=run_child(argv,cwd=R/'drivers/cogent',env=env,stdout=out,stderr=err,
                    timeout=100,log_limit_bytes=2<<20).returncode
        except BaseException as error:
            record['error']={'type':type(error).__name__,'message':str(error)}
        record.update(elapsed_seconds=time.monotonic()-start,terminal_observation_errors=[])
        def observe(key,operation):
            try:
                record[key]=operation()
            except BaseException as error:
                detail={'observation':key,'type':type(error).__name__,'message':str(error)}
                record[key]=None;record['terminal_observation_errors'].append(detail)
                if record['error']is None:record['error']=detail
        observe('binary_stable',lambda:sha(binary)==build['binary']['sha256']and binary.stat().st_size==build['binary']['bytes'])
        observe('build_receipt_stable',lambda:sha(P/('build-'+variant+'.json'))==build['receipt_sha256'])
        observe('sources_stable',lambda:sha(Path(__file__))==sources['producer']and
            sha(R/'drivers/cogent/accessibility_darwin.m')==sources['native']and
            sha(R/'drivers/cogent/accessibility_graph_darwin_test.go')==sources['tests']and
            sha(P/'baseline/accessibility_darwin.m')==sources['original_native']and
            sha(P/'baseline.json')==sources['baseline_manifest'])
        observe('stop_markers_at_exit',lambda:[str(marker)for marker in markers if marker.exists()])
        observe('logs',lambda:{ch:{'bytes':(P/(name+'.'+ch)).stat().st_size,'sha256':sha(P/(name+'.'+ch))}for ch in ['stdout','stderr']})
        record['result']='TERMINAL_INERT_BENCHMARK_OK'if record['exit_code']==0 and record['error']is None and record['binary_stable']and record['build_receipt_stable']and record['sources_stable']and not record['stop_markers_at_exit']else'FAILED_INERT_BENCHMARK'
        with(P/(name+'.json')).open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
        print(json.dumps({k:record[k]for k in ['variant','run','exit_code','error','elapsed_seconds']}),flush=True)
        assert record['result']=='TERMINAL_INERT_BENCHMARK_OK'
        raw=(P/(name+'.stdout')).read_text()
        pattern=r'^(Benchmark\S+)-2\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$'
        values={}
        for line in raw.splitlines():
            match=re.fullmatch(pattern,line.strip())
            if match:
                key,count,ns,go_bytes,go_allocs=match.groups()
                assert key not in values and int(count)==50
                values[key]={'ns_per_op':float(ns),'go_bytes_per_op':int(go_bytes),'go_allocs_per_op':int(go_allocs)}
        expected={'BenchmarkNativeAccessibilitySnapshotUIntFields',*[f'BenchmarkNativeAccessibilitySnapshotGraph/{n}'for n in ['deep64','deep256','deep1024','wide1024']]}
        assert set(values)==expected and raw.rstrip().endswith('PASS')
        records.append({'variant':variant,'run':run+1,'receipt_sha256':sha(P/(name+'.json')),'values':values})
with(P/'benchmarks.json').open('x')as out:
    out.write(json.dumps({'result':'PASS_SCOPED_LOCAL_VALIDATION_BENCHMARKS','records':records,'sources':sources,
        'native_window_executed':False,'ordinary_ui_work_gain_qualified':False,'native_memory_qualified':False,
        'limits':['Each operation includes Foundation JSON parsing and complete snapshot validation; no native commit/window.',
            'Go allocation counters exclude Foundation/native allocations.',
            'Interleaving does not prove host isolation; no ordinary P6 or causal whole-frame gain.']},indent=2)+'\n')
