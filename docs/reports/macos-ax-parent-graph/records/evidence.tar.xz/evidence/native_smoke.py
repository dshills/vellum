"""Owned English-only Cocoa AX smoke, stopped on actual human-return markers."""
from pathlib import Path
import datetime,hashlib,json,os,selectors,subprocess,sys,time
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
markers=[Path('/private/tmp/vellum-macos-listbox/stop-live'),P/'stop-live']
historical=Path('/private/tmp/vellum-macos-quiet-current/stop-live')
historical_sha='db5c4df12d8f08cedc63b39d7998a963aa1ca313aaa3b5a434ad64836064164f'
def need(condition,message):
    if not condition:raise RuntimeError(message)
def stopped():return [str(p)for p in markers if p.exists()]
def group_absent(pid):
    try:os.killpg(pid,0)
    except ProcessLookupError:return True
    return False
review=read(P/'native-smoke-review.json')
need(review['execution_ready']and not review['unresolved_findings'],'native controller review')
need(sha(Path(__file__))==review['producer_sha256'],'reviewed producer changed')
dependency_manifest=read(P/'dependencies/manifest.json')
dependencies={row['copy']:sha(P/row['copy'])for row in dependency_manifest.values()}
need(dependencies==review['dependencies'],'reviewed dependencies changed')
need(all(dependencies[row['copy']]==row['sha256']for row in dependency_manifest.values()),'dependency manifest drift')
sys.path.insert(0,str(P/'dependencies'))
from child_process import terminate_owned_group
from sdk_environment import child_environment
from live_lease import LiveLease
baseline=read(P/'baseline.json');build=read(P/'build-native-smoke.json');binary=P/'native-smoke'
need(build['exit_code']==0 and build['error']is None and build['source_stable'],'native build refused')
need(build['baseline_manifest_sha256']==sha(P/'baseline.json'),'native build baseline')
need(build['binary']['path']==str(binary),'native build binary path')
need(set(build['source_delta'])=={'drivers/cogent/accessibility_darwin.m','drivers/cogent/accessibility_graph_darwin_test.go'},'allowed native source delta')
need(build['source_delta']==review['sources'],'reviewed native source delta changed')
expected={**baseline['tracked'],**build['source_delta']}
def identity():
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,timeout=10).decode().strip()
    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=R,timeout=10).decode().split('\0')
    untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R,timeout=10).decode().split('\0')
    actual={n:sha(R/n)for n in tracked+untracked if n}
    prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)
        for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
    return head==baseline['base_commit']and actual==expected and prepared==baseline['prepared']
pinned_names=['native_smoke.py','native-smoke-review.json','build-native-smoke.json','build-native-smoke.stdout','build-native-smoke.stderr','baseline.json','live-authorization.json','dependencies/manifest.json',*dependencies]
for name in ['candidate-v2-race','candidate-v2-vet','test-candidate-v2']:
    check=read(P/(name+'.json'));need(check['exit_code']==0 and check['error']is None and check['source_stable'],'source checks incomplete')
    need(check['source_delta']==build['source_delta'],'check/build source delta')
    pinned_names.append(name+'.json')
    for ch in ['stdout','stderr']:
        filename=name+'.'+ch;need(sha(P/filename)==check['logs'][ch]['sha256'],'prerequisite log drift');pinned_names.append(filename)
for ch in ['stdout','stderr']:need(sha(P/('build-native-smoke.'+ch))==build['logs'][ch]['sha256'],'native build log drift')
controls=read(P/'negative-control-v2.json');need(controls['result']=='PASS_INTENDED_NEGATIVE_CONTROLS'and controls['candidate_restored'],'control incomplete')
need(len(controls['controls'])==1,'remainder control count')
control=controls['controls'][0];control_root='controls/v2-missing-final-remainder/'
need(control==read(P/(control_root+'result.json')),'control receipt drift')
need(control['candidate_sha256']==build['source_delta']['drivers/cogent/accessibility_darwin.m']and control['test_source_sha256']==build['source_delta']['drivers/cogent/accessibility_graph_darwin_test.go'],'control/source binding')
need(control['compile_exit_code']==0 and control['test_exit_code']==1 and control['error']is None and control['intended_oracle_assertion_failed']and control['candidate_restored'],'intended control incomplete')
pinned_names+=['negative-control-v2.json',control_root+'result.json']
for name,row in control['logs'].items():
    filename=control_root+name;need(sha(P/filename)==row['sha256'],'control log drift');pinned_names.append(filename)
pins={name:sha(P/name)for name in pinned_names}
def stable():
    return all(sha(P/n)==h for n,h in pins.items())and sha(binary)==build['binary']['sha256']and binary.stat().st_size==build['binary']['bytes']and sha(historical)==historical_sha
need(not stopped(),'human-return marker')
with LiveLease()as lease:
    need(lease.held()and not stopped()and stable()and identity(),'launch source/artifact/lease/stop admission')
    # The failed predecessor remains failed; only its owned process group must
    # be absent for independent follow-up scheduling. No prior result is erased.
    need(group_absent(15600),'retired failed predecessor group is present')
    receipt=P/'native-smoke.json'
    with receipt.open('x')as out:out.write('{}\n')
    record={'result':'STARTED_NATIVE_SMOKE','argv':[str(binary)],'source_commit':baseline['base_commit'],
        'source_delta':build['source_delta'],'pins':pins,'build_binary':build['binary'],
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exit_code':None,'error':None,'cleanup_errors':[],'native_application_executed':False,
        'shared_lease_held':lease.held(),'source_stable':False,'artifacts_stable':False,
        'direct_child_terminal':False,'group_absence_confirmed':False,'semantic_pass':False}
    child=None;start=time.monotonic();counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()]
    try:
        with(P/'native-smoke.stdout').open('xb')as out,(P/'native-smoke.stderr').open('xb')as err,selectors.DefaultSelector()as ready:
            need(lease.held()and not stopped()and stable(),'final native admission')
            child=subprocess.Popen([str(binary)],cwd=R/'drivers/cogent',env=child_environment(True),stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
            record.update(pid=child.pid,process_group=child.pid,native_application_executed=True)
            for i,pipe in enumerate([child.stdout,child.stderr]):ready.register(pipe,selectors.EVENT_READ,i)
            with(P/'native-smoke-owned-process.json').open('x')as process_out:process_out.write(json.dumps(record,indent=2)+'\n')
            terminal_at=None
            while ready.get_map()or child.poll()is None:
                need(not stopped(),'human-return marker')
                if time.monotonic()-start>45:raise TimeoutError('native smoke watchdog')
                if child.poll()is not None:
                    if terminal_at is None:terminal_at=time.monotonic()
                    if time.monotonic()-terminal_at>5:raise TimeoutError('pipe writer survived direct child')
                for key,_ in ready.select(.2):
                    raw=os.read(key.fd,64<<10)
                    if not raw:ready.unregister(key.fileobj);continue
                    i=key.data;accepted=min(len(raw),(2<<20)-counts[i])
                    if accepted:
                        stream=[out,err][i];need(stream.write(raw[:accepted])==accepted,'short native log write');stream.flush()
                        counts[i]+=accepted;digests[i].update(raw[:accepted])
                    need(accepted==len(raw),'native log bound')
            record['exit_code']=child.wait(timeout=5)
        events=[]
        for line in(P/'native-smoke.stdout').read_text().splitlines():
            if line.startswith('{'):events.append(json.loads(line))
        passes=[e for e in events if e.get('result')=='PASS'and e.get('native')=='macOS NSAccessibility']
        need(len(passes)==1,'exact native semantic pass record')
        record['semantic_pass']=passes[0].get('voiceover_tested')is False and passes[0].get('preferences_changed')is False
        need(record['semantic_pass'],'native semantics/preferences record')
    except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        def observe(key,operation):
            try:record[key]=operation()
            except BaseException as error:
                record[key]=None;record['cleanup_errors'].append({'stage':key,'type':type(error).__name__,'message':str(error)})
        if child is not None:
            def cleanup(stage,operation):
                try:operation()
                except BaseException as error:record['cleanup_errors'].append({'stage':stage,'type':type(error).__name__,'message':str(error)})
            cleanup('owned-group-retirement',lambda:terminate_owned_group(child))
            if child.poll()is None:cleanup('fallback-direct-kill',child.kill)
            def reap():
                record['exit_code']=child.wait(timeout=5);record['direct_child_terminal']=child.poll()is not None
            cleanup('direct-child-reap',reap)
            for i,pipe in enumerate([child.stdout,child.stderr]):cleanup('pipe-close-'+str(i),pipe.close)
            def absence():
                deadline=time.monotonic()+5
                while not group_absent(child.pid)and time.monotonic()<deadline:time.sleep(.05)
                record['group_absence_confirmed']=group_absent(child.pid)
            cleanup('owned-group-absence',absence)
        observe('source_stable',identity);observe('artifacts_stable',stable);observe('stop_markers_at_exit',stopped)
        observe('logs',lambda:{ch:{'bytes':counts[i],'sha256':sha(P/('native-smoke.'+ch)),'stream_sha256':digests[i].hexdigest()}for i,ch in enumerate(['stdout','stderr'])})
        observe('logs_complete',lambda:all(record['logs'][ch]['sha256']==record['logs'][ch]['stream_sha256']and record['logs'][ch]['bytes']==(P/('native-smoke.'+ch)).stat().st_size for ch in ['stdout','stderr']))
        record.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),shared_lease_held_through_cleanup=lease.held())
        good=record['exit_code']==0 and record['error']is None and not record['cleanup_errors']and record['direct_child_terminal']and record['group_absence_confirmed']and record['semantic_pass']and record['source_stable']and record['artifacts_stable']and record['logs_complete']and not record['stop_markers_at_exit']and lease.held()
        record['result']='PASS_SCOPED_NATIVE_AX_SMOKE'if good else'FAILED_OR_CANCELED_NATIVE_AX_SMOKE'
        receipt.write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps({k:record[k]for k in ['result','exit_code','error','cleanup_errors','elapsed_seconds']}),flush=True)
    need(record['result']=='PASS_SCOPED_NATIVE_AX_SMOKE','native smoke failed')
