Approved source and harness readiness for the corrected inert Foundation benchmark producer. The sole correction adds `-test.cpu=2` while retaining the strict `-2` parser; producer SHA `6a881d6cae479ad730f005df187750cf6052674e9600fc1d1ef03709d229ac61`. No unresolved findings.

The preserved pilot baseline exited 0 but emitted `-14`, and the parser refused it. No candidate ran; the pilot is excluded from the paired comparison. The cause of the CPU setting is unassigned. Corrected execution is pending. Prior review and raw pilot evidence are retained under `history/benchmark-cpu-pilot`.

The original measurement and ownership limits remain: Foundation parsing/validation plus CGo overhead, Go counters exclude native allocations, no whole-frame/P6 qualification, stop sampling between bounded children, and no separate normal-exit descendant-absence proof.
