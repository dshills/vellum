"""Prove corpus catches graph/scope admission defects; restore candidate bytes."""
from pathlib import Path
import hashlib,json,sys,time
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native=R/'drivers/cogent/accessibility_darwin.m'
original=native.read_bytes();original_sha=sha(native)
with(P/'candidate-accessibility_darwin.m').open('xb')as out:out.write(original)
env=child_environment();env.update(GOMAXPROCS='2',GOPROXY='off',
    GOCACHE='/Users/dshills/Library/Caches/go-build',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod',GOPATH='/Users/dshills/Development/Go')
variants=[
    ('missing-graph',b'if(!vellumAXValidParentGraph(nodes))return nil;',b'/* deliberate control: omit graph validation */',
        '^TestNativeAccessibilityGraphExhaustiveParents$'),
    ('missing-scope-parent',b'else if(![parent[@"grid_scope"] isEqual:scope])return nil;',
        b'else if(NO)return nil; /* deliberate control: omit same-scope parent */',
        '^TestNativeAccessibilityGraphExhaustiveScopes$')]
results=[]
try:
    for name,needle,replacement,selection in variants:
        assert native.read_bytes()==original and original.count(needle)==1
        root=P/'controls'/name;root.mkdir(parents=True)
        candidate=original.replace(needle,replacement)
        with(root/'accessibility_darwin.m').open('xb')as out:out.write(candidate)
        native.write_bytes(candidate)
        record={'variant':name,'producer_sha256':sha(Path(__file__)),
            'candidate_sha256':original_sha,'control_native_sha256':sha(native),
            'test_source_sha256':sha(R/'drivers/cogent/accessibility_graph_darwin_test.go'),
            'native_window_executed':False,'compile_exit_code':None,'test_exit_code':None,'error':None}
        start=time.monotonic()
        try:
            binary=root/'control.test'
            build=['go','test','-c','-p=1','-tags=offscreen','-o',str(binary),'.']
            record['build_argv']=build
            with(root/'build.stdout').open('xb')as out,(root/'build.stderr').open('xb')as err:
                record['compile_exit_code']=run_child(build,cwd=R/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=120,log_limit_bytes=2<<20).returncode
            assert record['compile_exit_code']==0
            record['binary']={'sha256':sha(binary),'bytes':binary.stat().st_size}
            argv=[str(binary),'-test.run='+selection,'-test.v','-test.timeout=30s'];record['argv']=argv
            with(root/'test.stdout').open('xb')as out,(root/'test.stderr').open('xb')as err:
                record['test_exit_code']=run_child(argv,cwd=R/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=40,log_limit_bytes=2<<20).returncode
            record['intended_oracle_assertion_failed']=b'graph validation=true, ancestor oracle=false'in(root/'test.stdout').read_bytes()
        except BaseException as error:
            record['error']={'type':type(error).__name__,'message':str(error)}
        finally:
            native.write_bytes(original)
            record.update(elapsed_seconds=time.monotonic()-start,candidate_restored=sha(native)==original_sha,
                logs={f.name:{'bytes':f.stat().st_size,'sha256':sha(f)}for f in root.iterdir()if f.suffix in ['.stdout','.stderr']})
            with(root/'result.json').open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
        print(json.dumps({k:record.get(k)for k in ['variant','compile_exit_code','test_exit_code','intended_oracle_assertion_failed','candidate_restored','error']}),flush=True)
        assert record['error']is None and record['test_exit_code']==1 and record['intended_oracle_assertion_failed']and record['candidate_restored']
        results.append(record)
finally:
    native.write_bytes(original)
    assert sha(native)==original_sha
with(P/'negative-controls.json').open('x')as out:
    out.write(json.dumps({'result':'PASS_INTENDED_NEGATIVE_CONTROLS','controls':results,
        'candidate_restored':True,'canonical_source_changed':False,'native_window_executed':False},indent=2)+'\n')
