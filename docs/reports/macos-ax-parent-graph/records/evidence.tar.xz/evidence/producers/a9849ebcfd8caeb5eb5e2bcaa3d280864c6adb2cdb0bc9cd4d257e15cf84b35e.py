"""Bounded code checks and optimized inert test executables; no UI launch."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-ax-graph')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=json.loads((P/'baseline.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==baseline['base_commit']
def identity():
    changed={n:sha(R/n)for n,h in baseline['tracked'].items()if sha(R/n)!=h}
    for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().split('\0'):
        if n:changed[n]=sha(R/n)
    prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)
        for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
    assert prepared==baseline['prepared']
    return changed
commands={
    'build-baseline':['go','test','-c','-p=1','-tags=offscreen','-o',str(P/'baseline.test'),'.'],
    'test-baseline':[str(P/'baseline.test'),'-test.run=^TestNativeAccessibilityGraph','-test.v','-test.timeout=180s'],
    'candidate-race':['go','test','-race','-p=1','-count=1','-tags=offscreen','./...'],
    'candidate-vet':['go','vet','-p=1','-tags=offscreen','./...'],
    'build-candidate':['go','test','-c','-p=1','-tags=offscreen','-o',str(P/'candidate.test'),'.'],
    'test-candidate':[str(P/'candidate.test'),'-test.run=^TestNativeAccessibilityGraph','-test.v','-test.timeout=180s']}
name=sys.argv[1];argv=commands[name];before=identity()
build_receipt=None
if name.startswith('test-'):
    variant=name.removeprefix('test-');build_path=P/('build-'+variant+'.json')
    build_receipt=json.loads(build_path.read_text())
    binary=P/(variant+'.test')
    assert build_receipt['exit_code']==0 and build_receipt['error']is None and build_receipt['source_stable']
    assert build_receipt['source_delta']==before
    assert sha(binary)==build_receipt['binary']['sha256'] and binary.stat().st_size==build_receipt['binary']['bytes']
if name in ['build-baseline','test-baseline']:
    assert sha(R/'drivers/cogent/accessibility_darwin.m')==baseline['baseline_native_sha256']
env=child_environment();env.update(GOMAXPROCS='2',GOPROXY='off',
    GOCACHE='/Users/dshills/Library/Caches/go-build',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod',GOPATH='/Users/dshills/Development/Go')
record={'argv':argv,'cwd':str(R/'drivers/cogent'),'base_commit':baseline['base_commit'],
    'baseline_manifest_sha256':sha(P/'baseline.json'),'source_delta':before,
    'producer_sha256':sha(Path(__file__)),'prepared_files':len(baseline['prepared']),
    'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'native_window_executed':False,'exit_code':None,'error':None}
if build_receipt is not None:
    record['build_receipt_sha256']=sha(build_path)
    record['executed_binary']=build_receipt['binary']
producer=P/'producers'/(record['producer_sha256']+'.py');producer.parent.mkdir(exist_ok=True)
if not producer.exists():
    with producer.open('xb')as out:out.write(Path(__file__).read_bytes())
start=time.monotonic()
try:
    with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
        record['exit_code']=run_child(argv,cwd=R/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=4<<20).returncode
    if name.startswith('build-')and record['exit_code']==0:
        f=P/(name.removeprefix('build-')+'.test')
        record['binary']={'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)}
except BaseException as error:
    record['error']={'type':type(error).__name__,'message':str(error)}
finally:
    record.update(elapsed_seconds=time.monotonic()-start,source_stable=identity()==before,
        logs={ch:{'bytes':(P/(name+'.'+ch)).stat().st_size,'sha256':sha(P/(name+'.'+ch))}for ch in ['stdout','stderr']})
    if build_receipt is not None:
        record['binary_stable']=sha(binary)==build_receipt['binary']['sha256'] and sha(build_path)==record['build_receipt_sha256']
    with(P/(name+'.json')).open('x')as out:out.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_stable']}),flush=True)
assert record['exit_code']==0 and record['error']is None and record['source_stable']
assert record.get('binary_stable',True)
