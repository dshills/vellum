from pathlib import Path
import hashlib,tarfile,io,json
x=Path(__file__).resolve().parent;q=x/'prepared'
paths=[p for p in q.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts and 'private-core' not in p.relative_to(q).parts and '__pycache__' not in p.relative_to(q).parts and p.name not in ['framework','native','layer-factory-test'] and not p.name.endswith(('.tar.xz','evidence-index.json','.o'))]
paths += list(x.glob('*.py'));archive=q/'preparation-evidence.tar.xz';files={}
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in sorted(set(paths)):
  b=p.read_bytes();name='preparation/'+p.relative_to(x).as_posix();m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o644;m.mtime=m.uid=m.gid=0;m.uname=m.gname='';tar.addfile(m,io.BytesIO(b));files[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with tarfile.open(archive,'r:xz') as tar:
 assert sorted(tar.getnames())==sorted(files)
 for m in tar:
  b=tar.extractfile(m).read();assert len(b)==files[m.name]['bytes'] and hashlib.sha256(b).hexdigest()==files[m.name]['sha256']
index={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'scope':'Physical native-source diagnostic preparation. Exact changes, fullsource hashvectors, actuallinkedmethod, headlessfactory/build/recipe/log/review proofs. No executable, nativearchive, fullCore/SDK/cache/credential. No native application launched.'};(q/'preparation-evidence-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'sha256':index['archive_sha256']}))
