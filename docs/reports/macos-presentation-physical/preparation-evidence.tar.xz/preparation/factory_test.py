from pathlib import Path
import json,sys,hashlib,importlib.util
sys.dont_write_bytecode=True
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');sys.path.insert(0,str(r/'scripts'));sys.path.insert(0,str(x.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('factory_owned',x.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g);source=q/'layer_factory_test.m'
if sys.argv[1]=='build':
 source.write_text('#import '+json.dumps(str(q/'private-core/system/driver/desktop/presentation_darwin.m'))+'\n#import '+json.dumps(str(q/'consumer/control.m'))+'''\n#include <assert.h>
uint64_t vellumGoDrawableAcquired(uint64_t a,uint64_t b,uint64_t c,uint64_t d,int e,double f){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;return 1;}
void vellumGoDrawableUnavailable(uint64_t a,uint64_t b,uint64_t c,uint64_t d,int e,double f){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;}
void vellumGoDrawablePresented(uint64_t a,uint64_t b,uint64_t c,double d){(void)a;(void)b;(void)c;(void)d;}
void vellumGoPresentationReceipt(uint64_t a,uint64_t b,double c){(void)a;(void)b;(void)c;}
uint64_t vellumGoDisplayAcquire(uint64_t a,uint64_t b){(void)a;(void)b;return 1;}
void vellumGoDisplayUnavailable(uint64_t a,uint64_t b){(void)a;(void)b;}
void vellumGoDisplayPresented(uint64_t a,uint64_t b,double c){(void)a;(void)b;(void)c;}
int main(void){@autoreleasepool{
 assert(pc_configure());CAMetalLayer *layer=(CAMetalLayer*)vellumNewPresentationLayer();
 assert([layer isKindOfClass:VellumPresentationLayer.class]);vellumPresentationObserver(layer,7);vellumPresentationFrame(layer,11,13,17,1);
 VellumPresentationStamp stamp=[(VellumPresentationLayer*)layer captureStamp];assert(stamp.token==7&&stamp.tag==11&&stamp.generation==13&&stamp.composition==17&&stamp.armed==1);
 vellumPresentationObserver(layer,0);assert(![(VellumPresentationLayer*)layer captureStamp].token);
 puts("PASS actual physical layer factory/subclass, stamp publication/revocation; no NSApplication/window or drawable acquisition");
}return 0;}
''')
case=sys.argv[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in [source,q/'private-core/system/driver/desktop/presentation_darwin.m',q/'private-core/system/driver/desktop/presentation_darwin.h',q/'consumer/control.m',q/'consumer/control.h']};base=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)']
if case=='build':argv=base+['/usr/bin/clang','-fno-objc-arc','-mmacosx-version-min=14.0','-Wall','-Wextra','-Werror','-framework','Cocoa','-framework','QuartzCore','-framework','Metal',str(source),'-o',str(q/'layer-factory-test')]
else:argv=base+[str(q/'layer-factory-test')];pins[str(q/'layer-factory-test')]=sha(q/'layer-factory-test')
run=g.execute(argv,q,q/('factory-'+case),lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=30,limit=1<<20);(q/('factory-'+case+'-receipt.json')).write_text(json.dumps({'pins':pins,'run':run},indent=2)+'\n');print(json.dumps({k:run[k] for k in ['exit_code','error','seconds']}));assert run['exit_code']==0 and run['error'] is None and run['owned']['terminal'] and run['owned']['group_absent']
