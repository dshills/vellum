"""Install the internally accepted experiment as an owned preparation stage."""
from pathlib import Path
import difflib,hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
review=json.loads((W/'adoption-review.json').read_bytes())
assert review['adoption_ready']and not review['unresolved_findings']and all(sha(p)==h for p,h in review['inputs'].items())
assert git('rev-parse','HEAD').decode().strip()=='25bd4739a82fb7cfbcea95d699c682bafe10b38d'and not git('status','--porcelain')
patchdir=T/'drivers/cogent/native/patches/glyphplacement';patchdir.mkdir()
source={'outline_cache.go':'outline_cache-v2.go','glyph_coverage.go':'glyph_coverage.go','text.go':'text-v4.go','glyph_placement.go':'glyph_placement-v4.go','glyph_placement_vellum_test.go':'glyph_placement_vellum_v7_test.go','glyph_placement_bench_vellum_test.go':'glyph_placement_bench_v2_test.go'}
original={};outputs={};patch=[]
for name,filename in source.items():
 relative='paint/renderers/rasterx/'+name;old=T/'drivers/cogent/build/upstream'/relative;candidate=P/filename
 original[relative]=sha(old)if old.exists()else None;outputs[relative]=sha(candidate)
 patch.extend(difflib.unified_diff(old.read_text().splitlines(keepends=True)if old.exists()else[],candidate.read_text().splitlines(keepends=True),fromfile='a/'+relative if old.exists()else'/dev/null',tofile='b/'+relative))
patchfile=patchdir/'0076-exact-location-glyph-coverage.patch';patchfile.write_text(''.join(patch))
for name,values in [('original-hashes.json',original),('output-hashes.json',outputs)]:(patchdir/name).write_text(json.dumps(values,indent=2)+'\n')
manifest=T/'drivers/cogent/native/dependencies.json';data=json.loads(manifest.read_bytes());data['dependencies'][0]['stages'].append(dict(origin='drivers/cogent/native/patches/glyphplacement',inputs='native/patches/glyphplacement/original-hashes.json',outputs='native/patches/glyphplacement/output-hashes.json',patches=[dict(file='native/patches/glyphplacement/'+patchfile.name,sha256=sha(patchfile))]));manifest.write_text(json.dumps(data,indent=2)+'\n')
test=T/'drivers/cogent/prepare_test.py';s=test.read_text();assert s.count('list(range(1, 76))')==1;test.write_text(s.replace('list(range(1, 76))','list(range(1, 77))'))
(T/'drivers/cogent/grid_glyph_placement_warm_offscreen_test.go').write_bytes((P/'candidate-warm-v2.go.txt').read_bytes())
(patchdir/'README.md').write_bytes((W/'owned-readme.md.txt').read_bytes())
for name,text in [('specs/rendering.md','spec-addition.md.txt'),('drivers/cogent/native/README.md','native-addition.md.txt'),('docs/implementation.md','implementation-addition.md.txt')]:
 p=T/name;p.write_text(p.read_text()+(W/text).read_text())
(W/'adoption.json').write_text(json.dumps(dict(base=git('rev-parse','HEAD').decode().strip(),prepared_modified_directly=False,source=source,outputs=outputs,patch_sha256=sha(patchfile),review_sha256=sha(W/'adoption-review.json')),indent=2)+'\n')
print('Installed owned stage0076 source and regression tests; preparation pending')
