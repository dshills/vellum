"""Prepare the owned stage and check its exact production source, without UI."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-production-25bd473-v2')
spec=importlib.util.spec_from_file_location('owned',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def source():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=T,timeout=20).decode().split('\0')[:-1]
 return {str(T/n):g.sha(T/n)for n in sorted(set(names))if(T/n).is_file()}
def prepared():
 return {str(p):g.sha(p)for name in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/name).rglob('*')if p.is_file()}
P.mkdir(mode=0o700);pins=source();pins[str(Path(__file__).resolve())]=g.sha(__file__);(P/'source.json').write_text(json.dumps(pins,indent=2)+'\n')
stable=lambda:all(g.sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',native_runtime_executed=False,commands=[])
def execute(name,cwd,args,timeout):
 run=g.execute(args,cwd,P/name,lambda:False,stable,timeout=timeout,limit=8<<20)
 d['commands'].append(dict(name=name,run=run));(P/(name+'.json')).write_text(json.dumps(run,indent=2)+'\n')
 print(json.dumps(dict(name=name,exit_code=run['exit_code'],seconds=run['seconds'],error=run['error'])),flush=True)
 g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors'],'terminal '+name)
try:
 previous=Path('/private/tmp/vellum-glyph-placement-production-25bd473')
 old=json.loads((previous/'receipt.json').read_bytes())
 g.need(len(old['commands'])==4 and old['commands'][-1]['name']=='driver-race'and old['commands'][-1]['run']['exit_code']==1,'preserved timed-out initial full run')
 for item in old['commands'][:3]:
  r=item['run'];g.need(r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent'],'unchanged preparation/renderer proof')
 state=prepared();g.need(state==json.loads((previous/'prepared.json').read_bytes()),'unchanged prepared modules')
 (P/'prepared.json').write_text(json.dumps(state,indent=2)+'\n');pins.update(state)
 d['prior_prepare_renderer_proof']=dict(path=str(previous/'receipt.json'),sha256=g.sha(previous/'receipt.json'),overall_prior_result='INCOMPLETE',accepted_commands=[x['name']for x in old['commands'][:3]],later_test_only_delta=True)
 prefix=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go']
 execute('warm-delta',T/'drivers/cogent',prefix+['test','-tags','offscreen','-count=1','-v','-run','^TestVellumGlyphPlacementActualGridWarm$','.'],120)
 execute('driver-race',T/'drivers/cogent',prefix+['test','-tags','offscreen','-race','-count=1','-timeout=5m','.'],420)
 execute('driver-vet',T/'drivers/cogent',prefix+['vet','-tags','offscreen','./...'],180)
 execute('native-compile-only',T/'examples/loadedgrid',prefix+['build','-p=1','-trimpath','-o',str(P/'loadedgrid'),'.'],300)
 d.update(result='PASS_OWNED_STAGE_NON_NATIVE_CHECKS',source_files=len(source()),prepared_files=len(prepared()),binary=dict(path=str(P/'loadedgrid'),bytes=(P/'loadedgrid').stat().st_size,sha256=g.sha(P/'loadedgrid')))
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
