"""Owned, bounded non-native prototype checks with exact source/overlay pins."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');O=P/'checks-v1'
spec=importlib.util.spec_from_file_location('owned',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sha=g.sha
def source():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=T,timeout=20).decode().split('\0')[:-1]
 files={str(T/n):sha(T/n)for n in names}
 for name in ['upstream','typesetting']:
  for p in (T/'drivers/cogent/build'/name).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():files[str(p)]=sha(p)
 assert len(names)==4673 and len(files)==10919
 return files
def main():
 O.mkdir(mode=0o700)
 bench=P/'glyph_placement_bench_vellum_test.go';bench.write_bytes((W/'bench.go.txt').read_bytes())
 overlay=json.loads((P/'overlay.json').read_bytes());overlay['Replace'][str(T/'drivers/cogent/build/upstream/paint/renderers/rasterx'/bench.name)]=str(bench)
 (P/'candidate-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
 baseline=json.loads(json.dumps(overlay));R=T/'drivers/cogent/build/upstream/paint/renderers/rasterx'
 for name in ['outline_cache.go','outline_extrema.go','text.go','glyph_coverage.go']:baseline['Replace'][str(R/name)]=str(P/('original-'+name))
 (P/'blank.go.txt').write_text('package rasterx\n');baseline['Replace'][str(R/'glyph_placement.go')]=str(P/'blank.go.txt')
 (P/'baseline-overlay.json').write_text(json.dumps(baseline,indent=2)+'\n')
 pins=source();pins.update({str(p):sha(p)for p in P.iterdir()if p.is_file()});pins[str(Path(__file__).resolve())]=sha(__file__)
 (O/'source.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(sha(p)==h for p,h in pins.items())
 d=dict(result='INCOMPLETE',native_runtime_executed=False,commands=[])
 try:
  commands=[('candidate-race','candidate', ['test','-race','-p=1','-count=1','./paint/renderers/rasterx'],180),('baseline-bench','baseline',['test','-p=1','-run','^$','-bench','^BenchmarkVellumGlyphPlacementCapture$','-benchmem','-benchtime=300ms','-count=5','./paint/renderers/rasterx'],180),('candidate-bench','candidate',['test','-p=1','-run','^$','-bench','^BenchmarkVellumGlyphPlacementCapture$','-benchmem','-benchtime=300ms','-count=5','./paint/renderers/rasterx'],180)]
  for name,which,args,timeout in commands:
   argv=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go',*args[:1],'-overlay='+str(P/(which+'-overlay.json')),*args[1:]]
   run=g.execute(argv,T/'drivers/cogent/build/upstream',O/name,lambda:False,stable,timeout=timeout,limit=8<<20)
   d['commands'].append(dict(name=name,run=run));(O/(name+'.json')).write_text(json.dumps(run,indent=2)+'\n')
   print(json.dumps(dict(name=name,exit_code=run['exit_code'],seconds=run['seconds'],error=run['error'])),flush=True)
   g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors'],'terminal '+name)
  d['result']='PASS_NON_NATIVE_PROTOTYPE'
 finally:
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
if __name__=='__main__':main()
