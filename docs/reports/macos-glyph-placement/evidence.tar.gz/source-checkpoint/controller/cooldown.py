"""Bound failed placement probes during continuously changing coordinates."""
from pathlib import Path
import json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');R=T/'drivers/cogent/build/upstream/paint/renderers/rasterx'
s=(P/'glyph_placement-v2.go').read_text()
s=s.replace('hits, misses uint64','hits, misses uint64\n\tprobes, wins, skip uint32')
# gofmt aligns fields; require the exact replacement to have succeeded.
if 'probes, wins, skip' not in s:
 s=s.replace('hits, misses uint64\n', 'hits, misses uint64\n\tprobes, wins, skip uint32\n')
assert 'probes, wins, skip' in s
start=s.index('func (rs *Renderer) drawPlacedGlyphCoverage(');end=s.index('// Retrieve only an identity',start)
part=s[start:end].replace('p.misses++\n\t\treturn false','return p.miss()')
part=part.replace('p.hits++\n\tc.hits++','p.hits++\n\tp.observe(true)\n\tc.hits++')
assert 'p.misses++' not in part
s=s[:start]+part+s[end:]
s+='''
const glyphPlacementProbeWindow = uint32(glyphPlacementEntries)
const glyphPlacementCooldown = 32*glyphPlacementProbeWindow

// A full index with fewer than one hit per eight probes is not paying for its
// lookup/admission work. Use the original path for a bounded eligible-glyph
// interval, then probe again so stationary text can regain reuse. These counters
// affect optimization only; original scene work and refusal checks run first.
func (p *glyphPlacementCache) observe(hit bool) {
 if p.count<glyphPlacementEntries{return}
 p.probes++;if hit{p.wins++}
 if p.probes==glyphPlacementProbeWindow{
  if p.wins<glyphPlacementProbeWindow/8{p.skip=glyphPlacementCooldown}
  p.probes=0;p.wins=0
 }
}
func (p *glyphPlacementCache) miss() bool {p.misses++;p.observe(false);return false}
func (rs *Renderer) glyphPlacementActive() bool {
 if rs.glyphCoverage==nil||rs.glyphCoverage.placements==nil{return true}
 p:=rs.glyphCoverage.placements
 if p.skip!=0 {p.skip--;return false}
 return true
}
'''
(P/'glyph_placement-v3.go').write_text(s)
s=(P/'text-v2.go').read_text().replace('coverage && rs.sceneRecord != nil && ctx.Cumulative == math32.Identity2()', 'coverage && rs.sceneRecord != nil && ctx.Cumulative == math32.Identity2() && rs.glyphPlacementActive()')
(P/'text-v3.go').write_text(s)
s=(P/'glyph_placement_vellum_v3_test.go').read_text()
s+='''
func TestVellumGlyphPlacementBoundedProbeCooldown(t *testing.T) {
 p:=&glyphPlacementCache{count:glyphPlacementEntries}
 for range glyphPlacementProbeWindow {p.observe(false)}
 if p.skip!=glyphPlacementCooldown||p.probes!=0||p.wins!=0{t.Fatal("cold probes not bounded")}
 r:=&Renderer{glyphCoverage:&glyphCoverageCache{placements:p}}
 for range glyphPlacementCooldown {if r.glyphPlacementActive(){t.Fatal("cooldown returned early")}}
 if !r.glyphPlacementActive(){t.Fatal("bounded cooldown never resumed")}
 for range glyphPlacementProbeWindow {p.observe(true)}
 if p.skip!=0||p.probes!=0||p.wins!=0{t.Fatal("useful probes disabled")}
 p.count=glyphPlacementEntries-1
 for range glyphPlacementProbeWindow {p.observe(false)}
 if p.skip!=0||p.probes!=0{t.Fatal("cold fill disabled before index was populated")}
}
'''
(P/'glyph_placement_vellum_v4_test.go').write_text(s)
for mode in ['candidate','baseline']:
 src=P/('grid_glyph_placement_warm_offscreen_test.go'if mode=='candidate'else'grid_glyph_placement_warm_baseline_test.go')
 s=src.read_text().replace('\t"cogentcore.org/core/paint/renderers/sceneplan"\n','')
 s=s.replace('if cold == nil {','if cold == nil || packet == nil {')
 warm=P/(mode+'-warm-v2.go.txt');warm.write_text(s)
 o=json.loads((P/(mode+'-v3-overlay.json')).read_bytes())
 o['Replace'][str(T/'drivers/cogent/grid_glyph_placement_warm_offscreen_test.go')]=str(warm)
 if mode=='candidate':
  o['Replace'][str(R/'text.go')]=str(P/'text-v3.go')
  o['Replace'][str(R/'glyph_placement.go')]=str(P/'glyph_placement-v3.go')
 (P/(mode+'-v4-overlay.json')).write_text(json.dumps(o,indent=2)+'\n')
 if mode=='candidate':
  o['Replace'][str(R/'glyph_placement_vellum_test.go')]=str(P/'glyph_placement_vellum_v4_test.go')
  (P/'regression-v4-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
print('Prepared bounded cooldown and corrected warm-grid fixture')
