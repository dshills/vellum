"""Prepare the owned stage and check its exact production source, without UI."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-production-25bd473')
spec=importlib.util.spec_from_file_location('owned',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def source():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=T,timeout=20).decode().split('\0')[:-1]
 return {str(T/n):g.sha(T/n)for n in sorted(set(names))if(T/n).is_file()}
def prepared():
 return {str(p):g.sha(p)for name in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/name).rglob('*')if p.is_file()}
P.mkdir(mode=0o700);pins=source();pins[str(Path(__file__).resolve())]=g.sha(__file__);(P/'source.json').write_text(json.dumps(pins,indent=2)+'\n')
stable=lambda:all(g.sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',native_runtime_executed=False,commands=[])
def execute(name,cwd,args,timeout):
 run=g.execute(args,cwd,P/name,lambda:False,stable,timeout=timeout,limit=8<<20)
 d['commands'].append(dict(name=name,run=run));(P/(name+'.json')).write_text(json.dumps(run,indent=2)+'\n')
 print(json.dumps(dict(name=name,exit_code=run['exit_code'],seconds=run['seconds'],error=run['error'])),flush=True)
 g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors'],'terminal '+name)
try:
 execute('prepare-tests',T/'drivers/cogent',['/usr/bin/env','PYTHONDONTWRITEBYTECODE=1','python3','prepare_test.py'],120)
 execute('prepare',T/'drivers/cogent',['/usr/bin/env','PYTHONDONTWRITEBYTECODE=1','GOPROXY=off','GOSUMDB=off','python3','prepare.py'],180)
 state=prepared();g.need(len(state)==6249,'owned prepared count')
 expected=json.loads((T/'drivers/cogent/native/patches/glyphplacement/output-hashes.json').read_bytes())
 g.need(all(g.sha(T/'drivers/cogent/build/upstream'/p)==h for p,h in expected.items()),'prepared outputs match tested implementation')
 (P/'prepared.json').write_text(json.dumps(state,indent=2)+'\n');pins.update(state)
 prefix=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go']
 execute('renderer-race',T/'drivers/cogent/build/upstream',prefix+['test','-race','-p=1','-count=1','-run','^TestVellum','./paint/renderers/rasterx','./paint/renderers/sceneplan'],240)
 execute('driver-race',T/'drivers/cogent',prefix+['test','-tags','offscreen','-race','-count=1','-timeout=5m','.'],420)
 execute('driver-vet',T/'drivers/cogent',prefix+['vet','-tags','offscreen','./...'],180)
 execute('native-compile-only',T/'examples/loadedgrid',prefix+['build','-p=1','-trimpath','-o',str(P/'loadedgrid'),'.'],300)
 d.update(result='PASS_OWNED_STAGE_NON_NATIVE_CHECKS',source_files=len(source()),prepared_files=len(prepared()),binary=dict(path=str(P/'loadedgrid'),bytes=(P/'loadedgrid').stat().st_size,sha256=g.sha(P/'loadedgrid')))
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
