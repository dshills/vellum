"""Exercise exact provider finalization without provider, Git or native work."""
from pathlib import Path
import ast,contextlib,hashlib,io,json,tempfile,time,types
W=Path(__file__).resolve().parent;producer=W/'prism.py';tree=ast.parse(producer.read_text());index=next(i for i,n in enumerate(tree.body)if isinstance(n,ast.Try));outer=tree.body[index];body=compile(ast.Module(body=outer.finalbody+tree.body[index+1:],type_ignores=[]),str(producer),'exec');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for report in [False,True]:
 with tempfile.TemporaryDirectory(prefix='vellum-prism-finalize-')as temp:
  root=Path(temp);(root/'stdout').write_bytes(b'');(root/'stderr').write_bytes(b'');binary=root/'fake-binary';binary.write_bytes(b'not executable')
  if report:(root/'prism.json').write_text('{"synthetic_report":true}\n')
  stage=b'controlled staged diff';b=dict(sources={},staged_diff_sha256=hashlib.sha256(stage).hexdigest());d=dict(exit_code=1,binary_sha256=sha(binary));errors=[]
  def attempt(errors,label,fn):
   try:return fn()
   except BaseException as e:errors.append(label+': '+str(e));return None
  runner=types.SimpleNamespace(retire_owned=lambda child,errors:dict(owned_group_absent=True),attempt=attempt)
  ns=dict(O=root,T=root,b=b,d=d,errors=errors,runner=runner,child=None,sha=sha,binary=binary,git=lambda *args:stage,time=time,start=time.monotonic(),hashlib=hashlib,json=json)
  caught=None
  try:
   with contextlib.redirect_stdout(io.StringIO()):exec(body,ns)
  except BaseException as e:caught=type(e).__name__
  receipt=json.loads((root/'receipt.json').read_bytes())
  if report:assert caught is None and receipt['errors']==[]and receipt['artifacts']['prism.json']is not None
  else:assert caught=='AssertionError'and 'missing terminal Prism JSON report'in receipt['errors']and receipt['artifacts']['prism.json']is None
  rows.append(dict(report_present=report,expected_outcome=True,caught=caught))
result=dict(result='PASS_EXACT_PRISM_REPORT_EXISTENCE_GUARD',provider_git_or_native_executed=False,producer_sha256=sha(producer),control_producer_sha256=sha(__file__),cases=rows)
with(W/'prism-controls.json').open('x')as output:output.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
