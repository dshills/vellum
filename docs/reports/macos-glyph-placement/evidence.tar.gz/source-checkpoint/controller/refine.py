"""Keep the original bitmap route byte-for-byte before constructing a key."""
from pathlib import Path
import json
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'drivers/cogent/build/upstream/paint/renderers/rasterx'
s=(P/'original-text.go').read_text().replace('\t"image/draw"','\t"image/draw"\n\t"math"')
needle='\n\trs.Path.Clear()\n\tm := ctx.Cumulative'
assert s.count(needle)==1
s=s.replace(needle,'''\n\tcoverage := rs.glyphCoverageEnabled && UseGlyphCache && identity && stroke == nil && rs.scrollRecord == nil && run.Face.SupportsBoundedOutlines() && int(-g.Height.Round())+2*glyphMaskBorder < glyphMinSize
\tvar placement glyphPlacementKey
\t// The bitmap route above retains its original bounds lookup and early return.
\t// Only the admitted small-outline scene route requests a placement identity.
\tif coverage && rs.sceneRecord != nil && ctx.Cumulative == math32.Identity2() {
\t\tif token := rs.staticOutlines().placementIdentity(run.Face.Font,g.GlyphID,outline); token != nil {
\t\t\tplacement = glyphPlacementKey{token,math.Float32bits(scale),math.Float32bits(pos.X),math.Float32bits(pos.Y)}
\t\t\tif rs.drawPlacedGlyphCoverage(fill,placement) { rs.Path.Clear(); return }
\t\t}
\t}
'''+needle)
s=s.replace('rs.glyphCoverageEnabled && UseGlyphCache && identity && stroke == nil && rs.scrollRecord == nil && run.Face.SupportsBoundedOutlines() && int(-g.Height.Round())+2*glyphMaskBorder < glyphMinSize && rs.drawGlyphCoverage(fill)','coverage && rs.drawGlyphCoverageAt(fill,placement)')
(P/'text-v2.go').write_text(s)
s=(P/'glyph_placement.go').read_text().replace('import "image"','import ("image";"github.com/go-text/typesetting/font")')
s+='''
// Retrieve only an identity for the currently live private immutable slice.
// Public/custom outlines and a slice evicted/replaced under the same font/GID
// cannot authorize a placement, even when their segment counts coincide.
func (cache *staticOutlineCache) placementIdentity(f *font.Font,gid font.GID,outline font.GlyphOutline) *outlineIdentity {
 if len(outline.Segments)==0 { return nil }
 cache.mu.Lock();defer cache.mu.Unlock()
 element:=cache.entries[outlineKey{f,gid}];if element==nil{return nil}
 e:=element.Value.(outlineEntry)
 if len(e.outline.Segments)!=len(outline.Segments)||&e.outline.Segments[0]!=&outline.Segments[0]{return nil}
 return e.identity
}
'''
(P/'glyph_placement-v2.go').write_text(s)
s=(W/'regression-v2.go.txt').read_text()
s=s.replace('_,available,valid,first:=c.identitySceneGeometry(face.Font,gid,own,.01,pos)','first:=c.placementIdentity(face.Font,gid,own)').replace('pos:=math32.Vec2(8,24)\n','').replace('if !available || !valid || first==nil','if first==nil')
s=s.replace('_,a,_,id:=c.identitySceneGeometry(face.Font,gid,cloned,.01,pos);a || id!=nil','id:=c.placementIdentity(face.Font,gid,cloned);id!=nil')
s=s.replace('_,a,_,id:=c.identitySceneGeometry(face.Font,gid,own,.01,pos);a || id!=nil','id:=c.placementIdentity(face.Font,gid,own);id!=nil')
s=s.replace('_,a,v,second:=c.identitySceneGeometry(face.Font,gid,replacement,.01,pos)','second:=c.placementIdentity(face.Font,gid,replacement)').replace('if !a || !v || second==nil','if second==nil')
(P/'glyph_placement_vellum_v3_test.go').write_text(s)
bench=(W/'bench.go.txt').read_text().replace('commands:=placementFixture()\n for _,scroll:=range []bool{false,true}', 'for _,mode:=range []string{"fixed","alternating-rows","cold-coordinates"}')
bench=bench.replace('name:="fixed";if scroll { name="alternating-rows" }\n  b.Run(name,func(b *testing.B) {','b.Run(mode,func(b *testing.B) {\n   commands:=placementFixture()')
bench=bench.replace('n:=0;if scroll{n=i%2};if r.ScenePacket','n:=0;if mode=="alternating-rows"{n=i%2};if mode=="cold-coordinates"{for index,item:=range commands[0]{v:=item.(*render.Text);v.Position.Y=float32(24+(index/8)*12)+float32(i%128)*.125}};if r.ScenePacket')
(P/'glyph_placement_bench_v2_test.go').write_text(bench)
for mode in ['candidate','baseline']:
 o=json.loads((P/(mode+'-grid-overlay.json')).read_bytes())
 o['Replace'][str(R/'glyph_placement_bench_vellum_test.go')]=str(P/'glyph_placement_bench_v2_test.go')
 if mode=='candidate':
  o['Replace'][str(R/'outline_extrema.go')]=str(P/'original-outline_extrema.go')
  o['Replace'][str(R/'text.go')]=str(P/'text-v2.go')
  o['Replace'][str(R/'glyph_placement.go')]=str(P/'glyph_placement-v2.go')
 (P/(mode+'-v2-overlay.json')).write_text(json.dumps(o,indent=2)+'\n')
 if mode=='candidate':
  o['Replace'][str(R/'glyph_placement_vellum_test.go')]=str(P/'glyph_placement_vellum_v3_test.go')
  (P/'regression-v3-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
