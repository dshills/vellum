from pathlib import Path
import json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473')
src=(T/'drivers/cogent/grid_tile_binning_offscreen_test.go').read_text()
start=src.index('func TestVellumTileBinningActualGrid')
out=src[:src.index('type tileBinningSource')]
# Reuse the existing encoded GPU software oracle and source types from its test.
a=out.index('func replayEncodedGPU(');out=out[:a]
for line in ['\t"encoding/binary"\n','\t"image/draw"\n','\t"strconv"\n']:out=out.replace(line,'')
out=out.replace('\t"testing"','\t"testing"\n\t"reflect"')
out+='''
// This read-only numeric probe verifies the private optimization was exercised
// across the renderer package boundary without adding a public testing API.
func gridPlacementHits(r *rasterx.Renderer) uint64 {
 coverage:=reflect.ValueOf(r).Elem().FieldByName("glyphCoverage")
 if !coverage.IsValid()||coverage.IsNil(){return 0}
 placements:=coverage.Elem().FieldByName("placements")
 if !placements.IsValid()||placements.IsNil(){return 0}
 return placements.Elem().FieldByName("hits").Uint()
}
const gridPlacementBaseline = false
'''
s=src[start:].replace('func TestVellumTileBinningActualGrid','func TestVellumGlyphPlacementActualGridWarm')
s=s.replace('\t\t\t\tfor frame, step :=','\t\t\t\tvar rs *rasterx.Renderer\n\t\t\t\tt.Cleanup(func(){if rs!=nil{rs.Release()}})\n\t\t\t\tfor frame, step :=',1)
s=s.replace('rs := rasterx.New(math32.FromPoint(scene.SceneGeom.Size)).(*rasterx.Renderer)\n\t\t\t\t\t\tdefer rs.Release()','if rs==nil {rs = rasterx.New(math32.FromPoint(scene.SceneGeom.Size)).(*rasterx.Renderer)}')
s=s.replace('packet := rs.ScenePacket(commands)','beforeHits:=gridPlacementHits(rs)\n\t\t\t\t\t\tcold:=rs.ScenePacket(commands)\n\t\t\t\t\t\tpacket := rs.ScenePacket(commands)\n\t\t\t\t\t\tif dpi==96 && !gridPlacementBaseline && gridPlacementHits(rs)<=beforeHits{t.Fatal("actual grid never reused an exact placement")}\n\t\t\t\t\t\tif cold==nil{t.Fatal("first capture refused")}\n\t\t\t\t\t\tca,coa:=cold.EncodeGPU();wa,woa:=packet.EncodeGPU();if coa!=woa||!reflect.DeepEqual(ca,wa){t.Fatal("warm packet bytes differ")}')
s=s.replace('t.Log("BINNING",','t.Log("PLACEMENT_WARM",')
(P/'grid_glyph_placement_warm_offscreen_test.go').write_text(out+s)
(P/'grid_glyph_placement_warm_baseline_test.go').write_text((out+s).replace('const gridPlacementBaseline = false','const gridPlacementBaseline = true'))
for mode in ['candidate','baseline']:
 o=json.loads((P/(mode+'-v2-overlay.json')).read_bytes())
 file=P/('grid_glyph_placement_warm_offscreen_test.go'if mode=='candidate'else'grid_glyph_placement_warm_baseline_test.go')
 o['Replace'][str(T/'drivers/cogent/grid_glyph_placement_warm_offscreen_test.go')]=str(file)
 (P/(mode+'-v3-overlay.json')).write_text(json.dumps(o,indent=2)+'\n')
print('Prepared retained-renderer warm actual-grid oracle')
