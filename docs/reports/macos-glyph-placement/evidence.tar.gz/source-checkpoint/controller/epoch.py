"""Try one epoch+generation identity layout with unchanged 64-bit entry size."""
from pathlib import Path
import json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');R=T/'drivers/cogent/build/upstream/paint/renderers/rasterx'
s=(P/'original-outline_cache.go').read_text()
s=s.replace('type outlineEntry struct {','// This separate nonzero-sized epoch token retains no font, outline or cache.\n// Per-outline IDs never wrap; zero permanently declines placement reuse.\ntype outlineIdentity struct { marker byte }\n\ntype outlineEntry struct {')
s=s.replace('\textrema outlineExtrema','\textrema outlineExtrema\n\tidentity uint32 // occupies the legacy trailing padding on supported 64-bit targets')
s=s.replace('\tbytes   int\n}', '\tbytes   int\n\tidentity *outlineIdentity\n\tnextIdentity uint32\n}')
assert 'nextIdentity uint32' in s
s=s.replace('cache.entries = make(map[outlineKey]*list.Element)','cache.identity = &outlineIdentity{1}\n\t\tcache.entries = make(map[outlineKey]*list.Element)')
needle='\tcache.entries[key] = cache.lru.PushFront(outlineEntry{'
s=s.replace(needle,'''\t// Exhaustion declines this optimization without changing outline admission.
\tidentity:=uint32(0)
\tif cache.nextIdentity != ^uint32(0) {cache.nextIdentity++;identity=cache.nextIdentity}
'''+needle+'identity: identity, ')
(P/'outline_cache-v2.go').write_text(s)
s=(P/'glyph_placement-v3.go').read_text()
s=s.replace('\toutline     *outlineIdentity','\toutline     *outlineIdentity\n\tgeneration uint32')
s=s.replace('key.outline == nil || e.identity == nil','key.outline == nil || key.generation == 0 || e.identity == nil')
s=s.replace('key.outline == nil || rs.glyphCoverage', 'key.outline == nil || key.generation == 0 || rs.glyphCoverage')
a=s.index('func (cache *staticOutlineCache) placementIdentity(');b=s.index('\nconst glyphPlacementProbeWindow',a)
s=s[:a]+s[a:b].replace(') *outlineIdentity {',') (*outlineIdentity,uint32) {').replace('return nil','return nil,0').replace('return e.identity','return cache.identity,e.identity')+s[b:]
(P/'glyph_placement-v4.go').write_text(s)
s=(P/'text-v3.go').read_text().replace('if token := rs.staticOutlines().placementIdentity(run.Face.Font, g.GlyphID, outline); token != nil {','if token,generation := rs.staticOutlines().placementIdentity(run.Face.Font, g.GlyphID, outline); token != nil && generation != 0 {')
s=s.replace('glyphPlacementKey{token, math.Float32bits(scale),','glyphPlacementKey{token, generation, math.Float32bits(scale),')
(P/'text-v4.go').write_text(s)
s=(P/'glyph_placement_vellum_v5_test.go').read_text().replace('\t"testing"','\t"testing"\n\t"unsafe"')
s=s.replace('first := c.placementIdentity(', 'first,firstID := c.placementIdentity(').replace('second := c.placementIdentity(','second,secondID := c.placementIdentity(')
s=s.replace('first == nil {','first == nil || firstID==0 {').replace('second == nil || first == second','second == nil || secondID==0 || first != second || firstID==secondID')
s=s.replace('id := c.placementIdentity(', 'id,generation := c.placementIdentity(').replace('; id != nil {','; id != nil || generation!=0 {')
s=s.replace('glyphPlacementKey{outline: &outlineIdentity{1}, scale:', 'glyphPlacementKey{outline: &outlineIdentity{1}, generation:1, scale:')
s+='''
func TestVellumGlyphPlacementEpochExhaustionAndLayout(t *testing.T) {
 type legacyOutlineEntry struct {key outlineKey;outline font.GlyphOutline;cost font.GlyphOutlineCost;bytes int;extrema outlineExtrema}
 if unsafe.Sizeof(uintptr(0))==8 && unsafe.Sizeof(outlineEntry{})!=unsafe.Sizeof(legacyOutlineEntry{}){t.Fatal("64-bit outline metadata grew")}
 face:=vellumOutlineFace(t);gid,_:=face.NominalGlyph('A');c:=&staticOutlineCache{nextIdentity:^uint32(0)-1}
 own,ok:=c.ordinary(face,gid);if !ok{t.Fatal("outline")}
 epoch,id:=c.placementIdentity(face.Font,gid,own);if epoch==nil||id!=^uint32(0){t.Fatal("last identity not issued")}
 otherGID,_:=face.NominalGlyph('B');other,_:=c.ordinary(face,otherGID)
 _,exhausted:=c.placementIdentity(face.Font,otherGID,other);if exhausted!=0{t.Fatal("exhaustion wrapped")}
 again,live:=c.placementIdentity(face.Font,gid,own);if again!=epoch||live!=id{t.Fatal("exhaustion revoked live identity")}
 fresh:=&staticOutlineCache{};replacement,_:=fresh.ordinary(face,gid);newEpoch,newID:=fresh.placementIdentity(face.Font,gid,replacement)
 if newEpoch==nil||newEpoch==epoch||newID!=1{t.Fatal("cache epochs alias")}
 r,key,e:=placementUnit(t);key.generation=0
 if r.drawPlacedGlyphCoverage(image.NewUniform(color.White),key){t.Fatal("zero generation reused")}
 r.glyphCoverage.placements=nil;r.glyphCoverage.rememberPlacement(key,e,image.Point{},image.Rectangle{})
 if r.glyphCoverage.placements!=nil{t.Fatal("zero generation learned")}
}
'''
(P/'glyph_placement_vellum_v6_test.go').write_text(s)
for mode in ['candidate','baseline']:
 o=json.loads((P/(mode+'-underfull-overlay.json')).read_bytes())
 if mode=='candidate':
  o['Replace'][str(R/'outline_cache.go')]=str(P/'outline_cache-v2.go')
  o['Replace'][str(R/'text.go')]=str(P/'text-v4.go')
  o['Replace'][str(R/'glyph_placement.go')]=str(P/'glyph_placement-v4.go')
 (P/(mode+'-v5-overlay.json')).write_text(json.dumps(o,indent=2)+'\n')
 if mode=='candidate':
  o['Replace'][str(R/'glyph_placement_vellum_test.go')]=str(P/'glyph_placement_vellum_v6_test.go')
  (P/'regression-v6-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
print('Prepared isolated epoch/generation candidate')
