"""Recompute experiment results directly from terminal raw receipts."""
from pathlib import Path
import hashlib,json,re,statistics
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
def read(p):inputs[str(p)]=sha(p);return json.loads(p.read_bytes())
def text(p):inputs[str(p)]=sha(p);return p.read_text()
for name in ['checks-v8','checks-v9','controls-v3']:
 d=read(P/name/'receipt.json');assert d['result'].startswith('PASS_'),name
 rows=d.get('commands',d.get('controls'))
 pins=read(P/name/'source.json');assert all(sha(p)==h for p,h in pins.items())
 for item in rows:
  r=item['run'];assert r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']and not r['observation_errors']
  for log in ['stdout','stderr']:
   label=item['case']['name']if name=='controls-v3'else item['name'];f=P/name/label/log
   assert f.stat().st_size==r['logs'][log]['bytes']and sha(f)==r['logs'][log]['sha256'];inputs[str(f)]=sha(f)
  if name=='controls-v3':assert item['expected_regression_failed']and r['exit_code']==1
  else:assert r['exit_code']==0
grid={};warm={};synthetic={};A=P/'checks-v8'
for run in ['0-baseline-grid','1-candidate-grid','2-candidate-grid','3-baseline-grid']:
 s=text(A/run/'stdout');groups={};records=[]
 for line in s.splitlines():
  if 'PLACEMENT_BENCH 'in line:
   r=json.loads(line.split('PLACEMENT_BENCH ',1)[1]);groups.setdefault(str((r['dpi'],r['variable'])),[]).append(r)
  if 'PLACEMENT_WARM 'in line:records.append(json.loads(line.split('PLACEMENT_WARM ',1)[1]))
 assert len(groups)==6 and all(len(v)==5 for v in groups.values())and len(records)==24
 grid[run]=groups;warm[run]=records
assert all(v==next(iter(warm.values()))for v in warm.values())
for run in ['baseline-synthetic','candidate-synthetic']:
 s=text(A/run/'stdout');groups={}
 for line in s.splitlines():
  if line.startswith('BenchmarkVellumGlyphPlacement'):
   n,iterations,ns,_,bytesop,_,allocs,*_=line.split();groups.setdefault(n.rsplit('-',1)[0],[]).append(dict(ns=int(ns),bytes=int(bytesop),allocs=int(allocs),iterations=int(iterations)))
 assert len(groups)==4 and all(len(v)==5 for v in groups.values());synthetic[run]=groups
summary=[]
for key in grid['0-baseline-grid']:
 values={}
 for label,runs in [('baseline',['0-baseline-grid','3-baseline-grid']),('candidate',['1-candidate-grid','2-candidate-grid'])]:
  values[label]=[r['ns_op']for run in runs for r in grid[run][key]]
 before,after=(statistics.median(values[n])for n in ['baseline','candidate'])
 summary.append(dict(group=key,baseline_median_ns=before,candidate_median_ns=after,change_percent=(after/before-1)*100,observations_each=10))
micro=[]
for key in synthetic['baseline-synthetic']:
 before,after=(statistics.median([r['ns']for r in synthetic[n][key]])for n in ['baseline-synthetic','candidate-synthetic'])
 micro.append(dict(group=key,baseline_median_ns=before,candidate_median_ns=after,change_percent=(after/before-1)*100,observations_each=5))
d=dict(result='RECOMPUTED_FINAL_EPOCH_EXPERIMENT',native_runtime_executed=False,baseline='Exact prior four-file compiler overlay; not clean historical build',candidate='Epoch/generation implementation compiler overlay; final test-only exhaustion assertion added separately',warm_grid_equal=True,warm_grid_records_per_process=24,grid=summary,synthetic=micro,source_controls=6,controls_expected_failure=True,performance_qualification=False,inputs=inputs)
(W/'analysis.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k]for k in ['result','grid','synthetic','source_controls']}))
