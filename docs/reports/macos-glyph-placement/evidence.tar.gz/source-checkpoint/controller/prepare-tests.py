from pathlib import Path
import json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');R=T/'drivers/cogent/build/upstream/paint/renderers/rasterx'
reg=P/'glyph_placement_vellum_test.go';reg.write_bytes((W/'regression.go.txt').read_bytes())
overlay=json.loads((P/'candidate-overlay.json').read_bytes());overlay['Replace'][str(R/reg.name)]=str(reg)
(P/'regression-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
# The actual grid fixture is copied unchanged from the existing offscreen pixel
# oracle. It produces four retained command batches before timing capture only.
src=(T/'drivers/cogent/grid_tile_binning_offscreen_test.go').read_text()
start=src.index('\tfor _, dpi :=',src.index('func TestVellumTileBinningActualGrid'))
end=src.index('\t\t\t\tfor frame, step :=',start)
setup=src[start:end]
setup=setup.replace('t.Run(fmt.Sprintf("%g/%v", dpi, variable)', 't.Run(fmt.Sprintf("%g/%v", dpi, variable)')
out='''//go:build offscreen
package cogent
import("testing";"fmt";"image";"encoding/json";"cogentcore.org/core/math32";"cogentcore.org/core/paint/render";"cogentcore.org/core/paint/renderers/rasterx";"github.com/dshills/vellum/app";"github.com/dshills/vellum/ui";"github.com/dshills/vellum/virtual")
func TestVellumGlyphPlacementActualGridCaptureBench(t *testing.T) {
'''+setup+'''
 var batches []render.Render
 for frame,step:=range []image.Point{{},{0,12},{96,12},{-96,-12}} {
  if frame>0 {if err=a.Do(func(){if e:=model.Scroll(step.X,step.Y);e!=nil{t.Error(e)};_ = a.Invalidate("one")});err!=nil{t.Fatal(err)}}
  gridFrame(t,m)
  if err=a.Do(func(){scene:=m.implementation.find("one").state.body.Scene;scene.RenderWidget();batches=append(batches,scene.Painter.RenderDone())});err!=nil{t.Fatal(err)}
 }
 for round:=0;round<5;round++ {
  result:=testing.Benchmark(func(b *testing.B){
   r:=rasterx.New(math32.Vec2(1519*dpi/160,1266*dpi/160)).(*rasterx.Renderer);defer r.Release()
   for i:=0;i<8;i++ {if r.ScenePacket(batches[i%len(batches)])==nil{b.Fatal("warmup refused")}}
   b.ReportAllocs();b.ResetTimer()
   for i:=0;i<b.N;i++ {if r.ScenePacket(batches[i%len(batches)])==nil{b.Fatal("capture refused")}}
  })
  record:=map[string]any{"dpi":dpi,"variable":variable,"round":round,"n":result.N,"ns_op":result.NsPerOp(),"bytes_op":result.AllocedBytesPerOp(),"allocs_op":result.AllocsPerOp()}
  line,_:=json.Marshal(record);t.Log("PLACEMENT_BENCH",string(line))
 }
 })
 }
 }
}
'''
grid=P/'grid_glyph_placement_bench_offscreen_test.go';grid.write_text(out)
for mode in ['candidate','baseline']:
 current=json.loads((P/(mode+'-overlay.json')).read_bytes());current['Replace'][str(T/'drivers/cogent'/grid.name)]=str(grid)
 (P/(mode+'-grid-overlay.json')).write_text(json.dumps(current,indent=2)+'\n')
print(reg,grid)
