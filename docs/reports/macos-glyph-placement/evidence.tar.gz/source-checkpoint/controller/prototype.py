"""Exact-location glyph coverage experiment; no repository mutation."""
from pathlib import Path
import hashlib,json
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
W=Path(__file__).resolve().parent
P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473')
P.mkdir(mode=0o700)
R=T/'drivers/cogent/build/upstream/paint/renderers/rasterx'
names=['outline_cache.go','outline_extrema.go','glyph_coverage.go','text.go']
original={n:(R/n).read_text()for n in names}
candidate=dict(original)
s=candidate['outline_cache.go']
s=s.replace('type outlineEntry struct {','// A nonzero-sized token names one owned immutable outline without retaining it.\n// Placement indexes may keep this token after LRU eviction, never its font/slice.\ntype outlineIdentity struct { marker byte }\n\ntype outlineEntry struct {\n\tidentity *outlineIdentity')
s=s.replace('outlineEntry{key: key,','outlineEntry{identity: &outlineIdentity{1}, key: key,')
candidate['outline_cache.go']=s
s=candidate['outline_extrema.go']
start=s.index('func (cache *staticOutlineCache) identitySceneBounds(')
signature=s[start:s.index('\n',start)]
s=s[:start]+signature+'\n\tb, available, valid, _ := cache.identitySceneGeometry(f, gid, outline, scale, pos)\n\treturn b, available, valid\n}\n\n'+s[start:]
start=s.index(signature,start+len(signature)+1)
s=s[:start]+s[start:].replace('identitySceneBounds(', 'identitySceneGeometry(',1).replace('(math32.Box2, bool, bool) {','(math32.Box2, bool, bool, *outlineIdentity) {',1).replace('return math32.Box2{}, false, false','return math32.Box2{}, false, false, nil').replace('return b, true, valid','return b, true, valid, entry.identity')
candidate['outline_extrema.go']=s
s=candidate['glyph_coverage.go']
s=s.replace('type glyphCoverageEntry struct {','type glyphCoverageIdentity struct { marker byte }\n\ntype glyphCoverageEntry struct {\n\tidentity *glyphCoverageIdentity')
s=s.replace('misses       uint64\n}', 'misses       uint64\n\tplacements *glyphPlacementCache\n}')
s=s.replace('e := &glyphCoverageEntry{hash:', 'e := &glyphCoverageEntry{identity: &glyphCoverageIdentity{1}, hash:')
sig='func glyphCoverageGeometry(p Path, bounds, clip image.Rectangle) (image.Point, uint64, bool) {'
s=s.replace(sig, sig+'\n\to,h,_,ok := glyphCoverageGeometryHull(p,bounds,clip)\n\treturn o,h,ok\n}\n\nfunc glyphCoverageGeometryHull(p Path, bounds, clip image.Rectangle) (image.Point, uint64, image.Rectangle, bool) {')
a=s.index('func glyphCoverageGeometryHull(');b=s.index('\nfunc glyphCoverageWalk(',a)
s=s[:a]+s[a:b].replace('return image.Point{}, 0, false','return image.Point{}, 0, image.Rectangle{}, false').replace('return origin, h, true','return origin, h, hull, true')+s[b:]
a=s.index('func (rs *Renderer) drawGlyphCoverage(fill image.Image) bool {');b=s.index('\torigin, hash, ok :=',a)
guard=s[a:b].replace('func (rs *Renderer) drawGlyphCoverage(fill image.Image) bool {','func (rs *Renderer) glyphCoverageReady(fill image.Image) (image.Rectangle, bool) {').replace('return false','return image.Rectangle{}, false')
s=s[:a]+guard+'\treturn bounds,true\n}\n\nfunc (rs *Renderer) drawGlyphCoverage(fill image.Image) bool {\n\treturn rs.drawGlyphCoverageAt(fill, glyphPlacementKey{})\n}\n\nfunc (rs *Renderer) drawGlyphCoverageAt(fill image.Image, key glyphPlacementKey) bool {\n\tbounds, ready := rs.glyphCoverageReady(fill)\n\tif !ready { return false }\n'+s[b:]
s=s.replace('origin, hash, ok := glyphCoverageGeometry(rs.Path, bounds, rs.Scanner.Clip)','origin, hash, hull, ok := glyphCoverageGeometryHull(rs.Path, bounds, rs.Scanner.Clip)')
a=s.index('\trf := &rs.Raster.Filler',s.index('func (rs *Renderer) drawGlyphCoverageAt'));b=s.index('\tcache.misses++',a)
s=s[:a]+'''\trf := &rs.Raster.Filler
\tif e := cache.entries[hash]; e != nil && glyphCoverageMatches(e, rs.Path, origin) {
\t\tcache.hits++
\t\trs.emitGlyphCoverage(e,origin,fill)
\t\tif !rs.recordingFailed() { cache.rememberPlacement(key,e,origin,hull) }
\t\treturn true
\t}
\trf.SetWinding(true)
\trf.SetColor(fill)
'''+s[b:]
s=s.replace('cache.retain(hash, rs.Path, origin, recorder.spans)','cache.retain(hash, rs.Path, origin, recorder.spans)\n\t\tif e:=cache.entries[hash]; e!=nil && glyphCoverageMatches(e,rs.Path,origin) { cache.rememberPlacement(key,e,origin,hull) }')
s+='''
// Emission is shared by the exact-path and exact-location routes. In particular,
// refusal in PackedSpans follows the same original fallback and scanner cleanup.
func (rs *Renderer) emitGlyphCoverage(e *glyphCoverageEntry, origin image.Point, fill image.Image) {
 rf:=&rs.Raster.Filler
 rf.SetWinding(true); rf.SetColor(fill)
 if s,ok:=rs.Scanner.Spanner.(*sceneSpanner); ok && s.beginSpans() && s.builder.PackedSpans(e.spans,origin) { rf.Clear(); return }
 span:=rs.Scanner.Spanner.GetSpanFunc()
 for _,s:=range e.spans { span(int(s.Y)+origin.Y,int(s.X0)+origin.X,int(s.X1)+origin.X,s.Alpha) }
 rf.Clear()
}
'''
candidate['glyph_coverage.go']=s
s=candidate['text.go']
s=s.replace('\t"image/draw"','\t"image/draw"\n\t"math"')
s=s.replace('\tif rs.sceneRecord != nil {\n\t\tif len(outline.Segments)', '\tvar placement glyphPlacementKey\n\tif rs.sceneRecord != nil {\n\t\tif len(outline.Segments)',1)
s=s.replace('bounds, available, valid = rs.staticOutlines().identitySceneBounds(run.Face.Font, g.GlyphID, outline, scale, pos)','var token *outlineIdentity\n\t\t\tbounds, available, valid, token = rs.staticOutlines().identitySceneGeometry(run.Face.Font, g.GlyphID, outline, scale, pos)\n\t\t\tif valid && token != nil { placement = glyphPlacementKey{token, math.Float32bits(scale), math.Float32bits(pos.X), math.Float32bits(pos.Y)} }')
needle='\n\trs.Path.Clear()\n\tm := ctx.Cumulative'
assert s.count(needle)==1
s=s.replace(needle,'''\n\tcoverage := rs.glyphCoverageEnabled && UseGlyphCache && identity && stroke == nil && rs.scrollRecord == nil && run.Face.SupportsBoundedOutlines() && int(-g.Height.Round())+2*glyphMaskBorder < glyphMinSize
\tif coverage && placement.outline != nil && rs.drawPlacedGlyphCoverage(fill,placement) { rs.Path.Clear(); return }
'''+needle)
s=s.replace('rs.glyphCoverageEnabled && UseGlyphCache && identity && stroke == nil && rs.scrollRecord == nil && run.Face.SupportsBoundedOutlines() && int(-g.Height.Round())+2*glyphMaskBorder < glyphMinSize && rs.drawGlyphCoverage(fill)','coverage && rs.drawGlyphCoverageAt(fill,placement)')
candidate['text.go']=s
candidate['glyph_placement.go']='''// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import "image"

const glyphPlacementEntries = 8192

// Exact float32 inputs are required: integer translations at different exponent
// boundaries need not produce identical fixed paths. Identity tokens refer only
// to private immutable outlines and contain no font, slice or renderer reference.
type glyphPlacementKey struct {
 outline *outlineIdentity
 scale, x, y uint32
}
type glyphPlacement struct {
 hash uint64
 coverage *glyphCoverageIdentity
 origin image.Point
 hull image.Rectangle
}
// Fixed-capacity FIFO metadata is allocated lazily for scene captures. Values
// retain only small identity tokens, never coverage arrays, fonts or packets.
// Coverage eviction invalidates placements even if its hash is later reused.
type glyphPlacementCache struct {
 entries map[glyphPlacementKey]glyphPlacement
 queue [glyphPlacementEntries]glyphPlacementKey
 head,count int
 hits,misses uint64
}
func (c *glyphCoverageCache) rememberPlacement(key glyphPlacementKey,e *glyphCoverageEntry,origin image.Point,hull image.Rectangle) {
 if key.outline==nil || e.identity==nil { return }
 if c.placements==nil { c.placements=&glyphPlacementCache{entries:make(map[glyphPlacementKey]glyphPlacement)} }
 p:=c.placements
 if _,ok:=p.entries[key]; !ok {
  if p.count==glyphPlacementEntries { delete(p.entries,p.queue[p.head]);p.head=(p.head+1)%glyphPlacementEntries;p.count-- }
  p.queue[(p.head+p.count)%glyphPlacementEntries]=key;p.count++
 }
 p.entries[key]=glyphPlacement{e.hash,e.identity,origin,hull}
}
func (rs *Renderer) drawPlacedGlyphCoverage(fill image.Image,key glyphPlacementKey) bool {
 if key.outline==nil || rs.glyphCoverage==nil || rs.glyphCoverage.placements==nil { return false }
 c:=rs.glyphCoverage;p:=c.placements
 v,ok:=p.entries[key]
 if !ok { p.misses++;return false }
 e:=c.entries[v.hash]
 if e==nil || e.identity!=v.coverage { p.misses++;return false }
 bounds,ready:=rs.glyphCoverageReady(fill)
 if !ready || !v.hull.In(bounds) || !v.hull.In(rs.Scanner.Clip) { p.misses++;return false }
 p.hits++;c.hits++
 rs.emitGlyphCoverage(e,v.origin,fill)
 return true
}
'''
for n,s in candidate.items():(P/n).write_text(s)
overlay={'Replace':{str(R/n):str(P/n)for n in candidate}}
(P/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
for n,s in original.items():(P/('original-'+n)).write_text(s)
(W/'prototype.json').write_text(json.dumps(dict(base='25bd4739a82fb7cfbcea95d699c682bafe10b38d',prototype=str(P),repository_mutated=False,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in P.iterdir()}),indent=2)+'\n')
print(P)
