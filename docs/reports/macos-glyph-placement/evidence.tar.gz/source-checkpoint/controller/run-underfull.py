"""AB/BA capture comparisons plus retained-renderer grid parity."""
from pathlib import Path
import datetime,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');O=P/'underfull-v1'
spec=importlib.util.spec_from_file_location('owned',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
spec=importlib.util.spec_from_file_location('prototype',W/'run-prototype.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
O.mkdir(mode=0o700);pins=p.source();pins.update({str(x):g.sha(x)for x in P.iterdir()if x.is_file()});pins[str(Path(__file__).resolve())]=g.sha(__file__)
(O/'source.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(g.sha(x)==h for x,h in pins.items());d=dict(result='INCOMPLETE',native_runtime_executed=False,commands=[])
try:
 commands=[]
 for mode in ['baseline','candidate']:
  commands.append((mode+'-bench',mode+'-underfull',T/'drivers/cogent/build/upstream',['test','-p=1','-run','^$','-bench','^BenchmarkVellumGlyphPlacementUnderfullClippedMiss$','-benchmem','-benchtime=300ms','-count=5','./paint/renderers/rasterx'],180))
 for name,overlay,cwd,args,timeout in commands:
  argv=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go',args[0],'-overlay='+str(P/(overlay+'-overlay.json')),*args[1:]]
  run=g.execute(argv,cwd,O/name,lambda:False,stable,timeout=timeout,limit=8<<20)
  d['commands'].append(dict(name=name,run=run));(O/(name+'.json')).write_text(json.dumps(run,indent=2)+'\n')
  print(json.dumps(dict(name=name,exit_code=run['exit_code'],seconds=run['seconds'],error=run['error'])),flush=True)
  g.need(run['error']is None and run['exit_code']==0 and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors'],'terminal '+name)
 d['result']='PASS_REFINED_NON_NATIVE_AB_BA'
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
