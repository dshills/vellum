from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-production-25bd473-v2');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
assert not (W/'binding.json').exists()and not git('diff','--cached','--name-only')
checks=json.loads((P/'receipt.json').read_bytes());assert checks['result']=='PASS_OWNED_STAGE_NON_NATIVE_CHECKS'
for file in ['source.json','prepared.json']:
 assert all(sha(p)==h for p,h in json.loads((P/file).read_bytes()).items())
expected=sorted(['docs/implementation.md','drivers/cogent/native/README.md','drivers/cogent/native/dependencies.json','drivers/cogent/prepare_test.py','specs/rendering.md','drivers/cogent/grid_glyph_placement_warm_offscreen_test.go']+['drivers/cogent/native/patches/glyphplacement/'+name for name in ['0076-exact-location-glyph-coverage.patch','README.md','original-hashes.json','output-hashes.json']])
names=sorted(set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()));assert expected==names
assert git('rev-parse','HEAD').decode().strip()=='25bd4739a82fb7cfbcea95d699c682bafe10b38d'
sources={n:sha(T/n)for n in names};git('add','--',*names)
assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard')
assert all(sha(T/n)==h==hashlib.sha256(git('show',':'+n)).hexdigest()for n,h in sources.items())
git('diff','--cached','--check');diff=git('diff','--cached','--binary');assert len(diff)<80000
(W/'staged.diff').write_bytes(diff)
b=dict(base_commit=git('rev-parse','HEAD').decode().strip(),sources=sources,files=len(names),staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(diff),source_files=4678,prepared_files=6249,checks_sha256=sha(P/'receipt.json'),producer_sha256=sha(__file__))
(W/'binding.json').write_text(json.dumps(b,indent=2)+'\n');print(json.dumps({k:b[k]for k in ['files','staged_diff_bytes','staged_diff_sha256']}))
