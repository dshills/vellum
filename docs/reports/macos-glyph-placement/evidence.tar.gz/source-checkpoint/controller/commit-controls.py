"""Exercise the exact commit finalizer with fake observations; never call Git."""
from pathlib import Path
import ast,contextlib,datetime,hashlib,io,json,tempfile,types
W=Path(__file__).resolve().parent;producer=W/'commit.py';tree=ast.parse(producer.read_text());outer=next(n for n in tree.body if isinstance(n,ast.Try));body=compile(ast.Module(body=outer.finalbody,type_ignores=[]),str(producer),'exec');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
results=[]
for name,fail,existing,prior in [('success',False,False,False),('observation-failure',True,False,False),('exclusive-receipt',False,True,False),('prior-error-preserved',True,False,True)]:
 with tempfile.TemporaryDirectory(prefix='vellum-commit-finalize-')as temp:
  root=Path(temp);target=root/'commit-receipt.json';original=b'immutable existing receipt\n'
  if existing:target.write_bytes(original)
  def observe(path):
   if fail and path=='candidate':raise OSError('injected terminal observation failure')
   return dict(head='synthetic-commit',status='',branch='synthetic')
  d=dict(result='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_PREPARED',both_clean=True,error=dict(type='ValueError',message='original failure')if prior else None)
  ns=dict(W=root,T='candidate',C='canonical',m=types.SimpleNamespace(observation=observe),sha=sha,__file__=str(producer),datetime=datetime,json=json,d=d)
  caught=None
  try:
   with contextlib.redirect_stdout(io.StringIO()):
    if prior:
     try:raise ValueError('original failure')
     finally:exec(body,ns)
    else:exec(body,ns)
  except BaseException as e:caught=dict(type=type(e).__name__,message=str(e))
  if existing:
   assert caught['type']=='FileExistsError'and target.read_bytes()==original
  else:
   saved=json.loads(target.read_bytes());assert saved==d
   if fail:
    assert saved['result']=='FAILED_TERMINAL_OBSERVATION'and saved['both_clean']is False and saved['candidate_observation_error']['type']=='OSError'and saved['pre_terminal_result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_PREPARED'
    assert caught['type']==('ValueError'if prior else'RuntimeError')
    if prior:assert saved['error']==dict(type='ValueError',message='original failure')and caught['message']=='original failure'
   else:assert caught is None and saved['both_clean']is True
  results.append(dict(name=name,pass_=True,caught=caught))
out=dict(result='PASS_EXACT_COMMIT_FINALIZER_CONTROLS',git_or_native_executed=False,producer_sha256=sha(producer),control_producer_sha256=sha(__file__),cases=results)
with(W/'commit-controls.json').open('x')as output:output.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
