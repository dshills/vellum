"""Source fault controls must fail their targeted regression, with owned cleanup."""
from pathlib import Path
import datetime,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-glyph-placement-prototype-25bd473');O=P/'controls-v3'
spec=importlib.util.spec_from_file_location('owned',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
spec=importlib.util.spec_from_file_location('prototype',W/'run-prototype.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
O.mkdir(mode=0o700);pins=p.source();pins.update({str(x):g.sha(x)for x in P.iterdir()if x.is_file()});pins[str(Path(__file__).resolve())]=g.sha(__file__)
(O/'source.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(g.sha(x)==h for x,h in pins.items());d=dict(result='INCOMPLETE',native_runtime_executed=False,controls=[])
try:
 for case in json.loads((P/'controls-v3.json').read_bytes()):
  argv=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','test','-overlay='+case['overlay'],'-p=1','-count=1','-run','^'+case['test']+'$','./paint/renderers/rasterx']
  run=g.execute(argv,T/'drivers/cogent/build/upstream',O/case['name'],lambda:False,stable,timeout=120,limit=4<<20)
  stdout=(O/case['name']/'stdout').read_text();accepted=run['error']is None and run['exit_code']==1 and ('--- FAIL: '+case['test'])in stdout and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
  d['controls'].append(dict(case=case,run=run,expected_regression_failed=accepted));(O/(case['name']+'.json')).write_text(json.dumps(d['controls'][-1],indent=2)+'\n')
  print(json.dumps(dict(name=case['name'],expected_regression_failed=accepted,seconds=run['seconds'])),flush=True);g.need(accepted,'discriminating '+case['name'])
 d['result']='PASS_SIX_DISCRIMINATING_SOURCE_CONTROLS'
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
