// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"testing"
)

func placementFixture() [2]render.Render {
	item := coverageSmallItem()
	var result [2]render.Render
	for frame := range result {
		for row := 0; row < 50; row++ {
			for col := 0; col < 8; col++ {
				v := *item
				v.Context.Bounds.Rect = math32.B2(0, 0, 1519, 1266)
				v.Position = math32.Vec2(float32(10+col*96), float32(24+row*12+frame*12))
				result[frame] = append(result[frame], &v)
			}
		}
	}
	return result
}

func BenchmarkVellumGlyphPlacementCapture(b *testing.B) {
	for _, mode := range []string{"fixed", "alternating-rows", "cold-coordinates"} {
		b.Run(mode, func(b *testing.B) {
			commands := placementFixture()
			r := New(math32.Vec2(1519, 1266)).(*Renderer)
			defer r.Release()
			for i := 0; i < 4; i++ {
				if r.ScenePacket(commands[i%2]) == nil {
					b.Fatal("warmup refused")
				}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				n := 0
				if mode == "alternating-rows" {
					n = i % 2
				}
				if mode == "cold-coordinates" {
					for index, item := range commands[0] {
						v := item.(*render.Text)
						v.Position.Y = float32(24+(index/8)*12) + float32(i%128)*.125
					}
				}
				if r.ScenePacket(commands[n]) == nil {
					b.Fatal("capture refused")
				}
			}
		})
	}
}
