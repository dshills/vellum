// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"cogentcore.org/core/paint/renderers/rasterx/scan"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"golang.org/x/image/math/fixed"
	"image"
)

const glyphCoverageEntries = 512
const glyphCoverageBytes = 1 << 20
const glyphCoveragePathValues = 512
const glyphCoverageSpans = 256

type glyphCoverageSpan = sceneplan.SpanSample
type glyphCoverageIdentity struct{ marker byte }

type glyphCoverageEntry struct {
	identity *glyphCoverageIdentity
	hash     uint64
	path     Path
	spans    []glyphCoverageSpan
	bytes    int
}

// Per-renderer FIFO storage owns only fixed paths and ordered coverage. No font,
// image, spanner, builder or packet is retained. The existing scene owner serializes
// ordinary paint and private capture. Limits cover array backing, not metadata.
type glyphCoverageCache struct {
	entries            map[uint64]*glyphCoverageEntry
	queue              [glyphCoverageEntries]*glyphCoverageEntry
	head, count, bytes int
	hits, misses       uint64
	placements         *glyphPlacementCache
}

func (rs *Renderer) glyphCoverageCache() *glyphCoverageCache {
	if rs.glyphCoverage == nil {
		rs.glyphCoverage = &glyphCoverageCache{}
	}
	return rs.glyphCoverage
}
func (c *glyphCoverageCache) evict() {
	e := c.queue[c.head]
	delete(c.entries, e.hash)
	c.bytes -= e.bytes
	c.queue[c.head] = nil
	c.head = (c.head + 1) % glyphCoverageEntries
	c.count--
}

// Every original float32 operation and ToFixed conversion already ran in Path.
// Fingerprints normalize to the first point's pixel origin so grammar, bounds
// and hashing share one walk. This internal index may collide; retained paths
// and full equality still use the minimum-bound origin. Integer translations
// preserve the key, while fractional coordinate phases remain represented.
// Only exact normalized operation/coordinate equality can authorize reuse.
func glyphCoverageGeometry(p Path, bounds, clip image.Rectangle) (image.Point, uint64, bool) {
	o, h, _, ok := glyphCoverageGeometryHull(p, bounds, clip)
	return o, h, ok
}

func glyphCoverageGeometryHull(p Path, bounds, clip image.Rectangle) (image.Point, uint64, image.Rectangle, bool) {
	if len(p) == 0 || len(p) > glyphCoveragePathValues || bounds.Min != (image.Point{}) || clip.Empty() {
		return image.Point{}, 0, image.Rectangle{}, false
	}
	lo, hi := image.Pt(1<<30, 1<<30), image.Point{}
	points := 0
	anchor := image.Point{}
	h := uint64(14695981039346656037)
	for i := 0; i < len(p); {
		n := 0
		switch PathCommand(p[i]) {
		case PathMoveTo, PathLineTo:
			n = 3
		case PathQuadTo:
			n = 5
		case PathCubicTo:
			n = 7
		case PathClose:
			n = 1
		default:
			return image.Point{}, 0, image.Rectangle{}, false
		}
		if i+n > len(p) {
			return image.Point{}, 0, image.Rectangle{}, false
		}
		h ^= uint64(uint32(p[i]))
		h *= 1099511628211
		for j := i + 1; j < i+n; j += 2 {
			x, y := int(p[j]), int(p[j+1])
			if x < 0 || y < 0 || x > 8192*64 || y > 8192*64 {
				return image.Point{}, 0, image.Rectangle{}, false
			}
			if points == 0 {
				anchor = image.Pt(x/64, y/64)
			}
			h ^= uint64(uint32(p[j] - fixed.Int26_6(anchor.X*64)))
			h *= 1099511628211
			h ^= uint64(uint32(p[j+1] - fixed.Int26_6(anchor.Y*64)))
			h *= 1099511628211
			lo.X = min(lo.X, x)
			lo.Y = min(lo.Y, y)
			hi.X = max(hi.X, x)
			hi.Y = max(hi.Y, y)
			points++
		}
		i += n
	}
	if points == 0 {
		return image.Point{}, 0, image.Rectangle{}, false
	}
	origin := image.Pt(lo.X/64, lo.Y/64)
	// Include a full guard pixel. No target/clip edge may have removed a span.
	hull := image.Rectangle{Min: origin, Max: image.Pt((hi.X+63)/64+1, (hi.Y+63)/64+1)}
	if hull.Dx() > 128 || hull.Dy() > 128 || !hull.In(bounds) || !hull.In(clip) {
		return image.Point{}, 0, image.Rectangle{}, false
	}
	return origin, h, hull, true
}
func glyphCoverageWalk(p Path, origin image.Point, each func(fixed.Int26_6)) {
	for i := 0; i < len(p); {
		each(p[i])
		n := 1
		switch PathCommand(p[i]) {
		case PathMoveTo, PathLineTo:
			n = 3
		case PathQuadTo:
			n = 5
		case PathCubicTo:
			n = 7
		}
		for j := i + 1; j < i+n; j += 2 {
			each(p[j] - fixed.Int26_6(origin.X*64))
			each(p[j+1] - fixed.Int26_6(origin.Y*64))
		}
		i += n
	}
}
func glyphCoverageMatches(e *glyphCoverageEntry, p Path, origin image.Point) bool {
	if len(e.path) != len(p) {
		return false
	}
	for i := 0; i < len(p); {
		if e.path[i] != p[i] {
			return false
		}
		n := 1
		switch PathCommand(p[i]) {
		case PathMoveTo, PathLineTo:
			n = 3
		case PathQuadTo:
			n = 5
		case PathCubicTo:
			n = 7
		}
		for j := i + 1; j < i+n; j += 2 {
			if e.path[j] != p[j]-fixed.Int26_6(origin.X*64) || e.path[j+1] != p[j+1]-fixed.Int26_6(origin.Y*64) {
				return false
			}
		}
		i += n
	}
	return true
}
func (c *glyphCoverageCache) retain(hash uint64, p Path, origin image.Point, spans []glyphCoverageSpan) {
	if len(spans) == 0 || len(spans) > glyphCoverageSpans || c.entries[hash] != nil {
		return
	}
	cost := len(p)*4 + len(spans)*16
	if cost > glyphCoverageBytes {
		return
	}
	for c.count > 0 && (c.count == glyphCoverageEntries || c.bytes+cost > glyphCoverageBytes) {
		c.evict()
	}
	e := &glyphCoverageEntry{identity: &glyphCoverageIdentity{1}, hash: hash, path: make(Path, len(p)), spans: make([]glyphCoverageSpan, len(spans)), bytes: cost}
	i := 0
	glyphCoverageWalk(p, origin, func(v fixed.Int26_6) { e.path[i] = v; i++ })
	copy(e.spans, spans)
	if c.entries == nil {
		c.entries = make(map[uint64]*glyphCoverageEntry)
	}
	c.entries[hash] = e
	c.queue[(c.head+c.count)%glyphCoverageEntries] = e
	c.count++
	c.bytes += cost
}

type glyphCoverageRecorder struct {
	underlying scan.Spanner
	origin     image.Point
	spans      []glyphCoverageSpan
	failed     bool
}

func (r *glyphCoverageRecorder) SetColor(c image.Image) { r.underlying.SetColor(c) }
func (r *glyphCoverageRecorder) GetSpanFunc() scan.SpanFunc {
	original := r.underlying.GetSpanFunc()
	return func(y, x0, x1 int, alpha uint32) {
		original(y, x0, x1, alpha)
		if r.failed {
			return
		}
		y -= r.origin.Y
		x0 -= r.origin.X
		x1 -= r.origin.X
		if len(r.spans) == glyphCoverageSpans || y < 0 || y > 128 || x0 < 0 || x1 > 128 || x0 >= x1 || alpha > 65535 {
			r.failed = true
			return
		}
		r.spans = append(r.spans, glyphCoverageSpan{Y: int32(y), X0: int32(x0), X1: int32(x1), Alpha: alpha})
	}
}

func (rs *Renderer) glyphCoverageReady(fill image.Image) (image.Rectangle, bool) {
	if _, ok := valueUniform(fill); !ok {
		return image.Rectangle{}, false
	}
	// Only the known owned spanners and a clean scanner participate. Custom paint
	// hooks retain their original call path and scan state.
	switch s := rs.Scanner.Spanner.(type) {
	case *scan.ImgSpanner:
		if s != rs.ImgSpanner || rs.sceneRecord != nil {
			return image.Rectangle{}, false
		}
	case *sceneSpanner:
		if rs.sceneRecord == nil || s.builder != rs.sceneRecord {
			return image.Rectangle{}, false
		}
	default:
		return image.Rectangle{}, false
	}
	if len(rs.Scanner.Cell) != 0 || rs.Scanner.Area != 0 || rs.Scanner.Cover != 0 || rs.Scanner.A != (fixed.Point26_6{}) || rs.Scanner.Xi != 0 || rs.Scanner.Yi != 0 || rs.Raster.Filler.A != (fixed.Point26_6{}) || rs.Raster.Filler.First != (fixed.Point26_6{}) || rs.Scanner.MinX != fixed.Int26_6(2147483647) || rs.Scanner.MinY != fixed.Int26_6(2147483647) || rs.Scanner.MaxX != fixed.Int26_6(-2147483647) || rs.Scanner.MaxY != fixed.Int26_6(-2147483647) {
		return image.Rectangle{}, false
	}
	bounds := image.Rectangle{Max: rs.size.ToPointCeil()}
	if rs.Scanner.Width != bounds.Dx() || len(rs.Scanner.CellIndex) != bounds.Dy() || rs.Raster.Filler.Scanner != rs.Scanner {
		return image.Rectangle{}, false
	}
	return bounds, true
}

func (rs *Renderer) drawGlyphCoverage(fill image.Image) bool {
	return rs.drawGlyphCoverageAt(fill, glyphPlacementKey{})
}

func (rs *Renderer) drawGlyphCoverageAt(fill image.Image, key glyphPlacementKey) bool {
	bounds, ready := rs.glyphCoverageReady(fill)
	if !ready {
		return false
	}
	origin, hash, hull, ok := glyphCoverageGeometryHull(rs.Path, bounds, rs.Scanner.Clip)
	if !ok {
		return false
	}
	cache := rs.glyphCoverageCache()
	rf := &rs.Raster.Filler
	if e := cache.entries[hash]; e != nil && glyphCoverageMatches(e, rs.Path, origin) {
		cache.hits++
		rs.emitGlyphCoverage(e, origin, fill)
		if !rs.recordingFailed() {
			cache.rememberPlacement(key, e, origin, hull)
		}
		return true
	}
	rf.SetWinding(true)
	rf.SetColor(fill)
	cache.misses++
	original := rs.Scanner.Spanner
	recorder := &glyphCoverageRecorder{underlying: original, origin: origin}
	rs.Scanner.Spanner = recorder
	// Restore on callback panic/Goexit as well. Abnormal draws retain nothing.
	defer func() { rs.Scanner.Spanner = original }()
	rs.Path.AddTo(rf)
	rf.Draw()
	rf.Clear()
	if !recorder.failed && !rs.recordingFailed() {
		cache.retain(hash, rs.Path, origin, recorder.spans)
		if e := cache.entries[hash]; e != nil && glyphCoverageMatches(e, rs.Path, origin) {
			cache.rememberPlacement(key, e, origin, hull)
		}
	}
	return true
}

// Emission is shared by the exact-path and exact-location routes. In particular,
// refusal in PackedSpans follows the same original fallback and scanner cleanup.
func (rs *Renderer) emitGlyphCoverage(e *glyphCoverageEntry, origin image.Point, fill image.Image) {
	rf := &rs.Raster.Filler
	rf.SetWinding(true)
	rf.SetColor(fill)
	if s, ok := rs.Scanner.Spanner.(*sceneSpanner); ok && s.beginSpans() && s.builder.PackedSpans(e.spans, origin) {
		rf.Clear()
		return
	}
	span := rs.Scanner.Spanner.GetSpanFunc()
	for _, s := range e.spans {
		span(int(s.Y)+origin.Y, int(s.X0)+origin.X, int(s.X1)+origin.X, s.Alpha)
	}
	rf.Clear()
}
