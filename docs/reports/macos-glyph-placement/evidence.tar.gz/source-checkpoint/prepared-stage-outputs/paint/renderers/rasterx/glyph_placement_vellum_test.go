// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"bytes"
	"image"
	"image/color"
	"math"
	"reflect"
	"testing"
	"unsafe"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx/scan"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"github.com/go-text/typesetting/font"
	"golang.org/x/image/math/fixed"
)

func TestVellumGlyphPlacementLiveOutlineIdentity(t *testing.T) {
	face := vellumOutlineFace(t)
	gid, _ := face.NominalGlyph('0')
	c := &staticOutlineCache{}
	own, ok := c.ordinary(face, gid)
	if !ok {
		t.Fatal("outline")
	}
	first, firstID := c.placementIdentity(face.Font, gid, own)
	if first == nil || firstID == 0 {
		t.Fatal("no owned identity")
	}
	cloned := font.GlyphOutline{Segments: append([]font.Segment(nil), own.Segments...)}
	if id, generation := c.placementIdentity(face.Font, gid, cloned); id != nil || generation != 0 {
		t.Fatal("caller outline trusted")
	}
	c.mu.Lock()
	c.evict()
	c.mu.Unlock()
	if id, generation := c.placementIdentity(face.Font, gid, own); id != nil || generation != 0 {
		t.Fatal("evicted outline trusted")
	}
	replacement, ok := c.ordinary(face, gid)
	if !ok {
		t.Fatal("replacement outline")
	}
	second, secondID := c.placementIdentity(face.Font, gid, replacement)
	if second == nil || secondID == 0 || first != second || firstID == secondID {
		t.Fatal("outline identity reused after replacement")
	}
	if id, generation := c.placementIdentity(face.Font, gid, own); id != nil || generation != 0 {
		t.Fatal("old slice trusted under new key")
	}
}

func placementCompare(t *testing.T, r, original *Renderer, commands render.Render) {
	t.Helper()
	a, b := r.ScenePacket(commands), original.vellumFreshScenePacket(commands)
	if (a == nil) != (b == nil) {
		t.Fatal("packet admission differs")
	}
	if a == nil {
		return
	}
	for _, gpu := range []bool{false, true} {
		var x, y *sceneplan.Encoded
		var ok, accepted bool
		if gpu {
			x, ok = a.EncodeGPU()
			y, accepted = b.EncodeGPU()
		} else {
			x, ok = a.Encode()
			y, accepted = b.Encode()
		}
		if ok != accepted || !reflect.DeepEqual(x, y) {
			t.Fatal("packet bytes differ", gpu)
		}
	}
	x, y := image.NewRGBA(a.Bounds()), image.NewRGBA(b.Bounds())
	for i := range x.Pix {
		x.Pix[i] = byte(i*17 + 3)
		y.Pix[i] = x.Pix[i]
	}
	if !a.Replay(x) || !b.Replay(y) || !bytes.Equal(x.Pix, y.Pix) {
		t.Fatal("replay pixels differ")
	}
}

func TestVellumGlyphPlacementExactInputsAndPackets(t *testing.T) {
	r := New(math32.Vec2(8192, 64)).(*Renderer)
	original := New(math32.Vec2(8192, 64)).(*Renderer)
	defer r.Release()
	defer original.Release()
	item := coverageSmallItem()
	item.Context.Bounds.Rect = math32.B2(0, 0, 8192, 64)
	run := item.Text.Lines[0].Runs[0].(*shapedgt.Run)
	size := run.Size
	positions := []math32.Vector2{{X: 8, Y: 24}, {X: 16, Y: 24}, {X: 8.015, Y: 24}, {X: 8.25, Y: 24}, {X: 8.984, Y: 24}, {X: 8, Y: 32}, {X: -1, Y: 24}, {X: 0, Y: 24}, {X: 8000.015, Y: 24}, {X: 8000.25, Y: 24}, {X: 8000.984, Y: 24}}
	for round := 0; round < 2; round++ {
		for _, pos := range positions {
			item.Position = pos
			placementCompare(t, r, original, render.Render{item})
			placementCompare(t, r, original, render.Render{item})
		}
	}
	if r.glyphCoverage == nil || r.glyphCoverage.placements == nil || r.glyphCoverage.placements.hits == 0 {
		t.Fatal("no exact-location reuse")
	}
	hits := r.glyphCoverage.placements.hits
	// Adjacent representable positions must not alias a prior absolute key.
	savedGlyphs := run.Glyphs
	run.Glyphs = run.Glyphs[:1]
	item.Position = math32.Vec2(math.Nextafter32(8, 9), 24)
	placementCompare(t, r, original, render.Render{item})
	if r.glyphCoverage.placements.hits != hits {
		t.Fatal("first glyph position bits were discarded")
	}
	run.Glyphs = savedGlyphs
	for _, changed := range []fixed.Int26_6{size + 1, size - 1, size * 2, size} {
		run.Size = changed
		item.Position = math32.Vec2(8.25, 24)
		placementCompare(t, r, original, render.Render{item})
		placementCompare(t, r, original, render.Render{item})
	}
	run.Size = size
	for _, matrix := range []math32.Matrix2{math32.Translate2D(.25, .5), math32.Scale2D(1.1, .9), math32.Rotate2D(.01), math32.Identity2()} {
		item.Context.Cumulative = matrix
		placementCompare(t, r, original, render.Render{item})
	}
	item.Context.Cumulative = math32.Identity2()
	for _, clip := range []math32.Box2{math32.B2(10, 0, 8192, 64), math32.B2(0, 20, 8192, 64), math32.B2(0, 0, 8192, 64)} {
		item.Context.Bounds.Rect = clip
		item.Text.Color = color.NRGBA{R: 91, G: 17, B: 39, A: 71}
		placementCompare(t, r, original, render.Render{item})
	}
	old := r.glyphCoverage
	r.SetSize(units.UnitDot, math32.Vec2(256, 64))
	original.SetSize(units.UnitDot, math32.Vec2(256, 64))
	if r.glyphCoverage != nil {
		t.Fatal("resize retained placement owner")
	}
	item.Context.Bounds.Rect = math32.B2(0, 0, 256, 64)
	item.Position = math32.Vec2(8, 24)
	placementCompare(t, r, original, render.Render{item})
	if r.glyphCoverage == old {
		t.Fatal("resize reused prior owner")
	}
	r.Release()
	r.Release()
	if r.glyphCoverage != nil || r.outlineCache != nil {
		t.Fatal("release retained owner")
	}
}

func placementUnit(t *testing.T) (*Renderer, glyphPlacementKey, *glyphCoverageEntry) {
	t.Helper()
	r := New(math32.Vec2(256, 64)).(*Renderer)
	t.Cleanup(r.Release)
	r.Scanner.SetClip(r.image.Bounds())
	r.Path = coverageGlyphPath(coverageSmallItem(), math32.Vec2(8, 24))
	key := glyphPlacementKey{outline: &outlineIdentity{1}, generation: 1, scale: 1, x: 2, y: 3}
	fill := image.NewUniform(color.NRGBA{31, 77, 119, 193})
	if !r.drawGlyphCoverageAt(fill, key) {
		t.Fatal("warm draw refused")
	}
	if r.glyphCoverage.placements == nil || r.glyphCoverage.placements.count != 1 {
		t.Fatal("no learned placement")
	}
	v := r.glyphCoverage.placements.entries[key]
	e := r.glyphCoverage.entries[v.hash]
	if e == nil {
		t.Fatal("no live coverage")
	}
	r.Path.Clear()
	return r, key, e
}

func TestVellumGlyphPlacementBoundedFIFOAndStaleCoverage(t *testing.T) {
	r, key, e := placementUnit(t)
	c := r.glyphCoverage
	p := c.placements
	v := p.entries[key]
	for i := 0; i < glyphPlacementEntries+17; i++ {
		k := key
		k.x = uint32(i + 100)
		c.rememberPlacement(k, e, v.origin, v.hull)
		if len(p.entries) > glyphPlacementEntries || p.count != len(p.entries) {
			t.Fatal("unbounded placements")
		}
	}
	if _, ok := p.entries[key]; ok {
		t.Fatal("oldest placement not evicted")
	}
	for _, k := range p.queue {
		if _, ok := p.entries[k]; !ok {
			t.Fatal("FIFO orphan")
		}
	}
	c.rememberPlacement(key, e, v.origin, v.hull)
	count := p.count
	c.rememberPlacement(key, e, v.origin, v.hull)
	if p.count != count {
		t.Fatal("duplicate key consumes FIFO")
	}
	fill := image.NewUniform(color.NRGBA{31, 77, 119, 193})
	// A different entry can reuse a colliding hash; its token must invalidate the
	// old placement without retaining the old path/spans through this metadata.
	replacement := *e
	replacement.identity = &glyphCoverageIdentity{1}
	c.entries[e.hash] = &replacement
	before := bytes.Clone(r.image.Pix)
	if r.drawPlacedGlyphCoverage(fill, key) || !bytes.Equal(before, r.image.Pix) {
		t.Fatal("stale hash placement reused")
	}
	c.entries[e.hash] = e
	c.evict()
	if r.drawPlacedGlyphCoverage(fill, key) {
		t.Fatal("evicted coverage reused")
	}
}

func TestVellumGlyphPlacementCurrentGuards(t *testing.T) {
	changes := map[string]func(*Renderer){
		"width":         func(r *Renderer) { r.Scanner.Width-- },
		"height":        func(r *Renderer) { r.Scanner.CellIndex = r.Scanner.CellIndex[:len(r.Scanner.CellIndex)-1] },
		"scanner-owner": func(r *Renderer) { r.Raster.Filler.Scanner = scan.NewScannerWithRowTracking(r.ImgSpanner, 256, 64) },
		"pending-area":  func(r *Renderer) { r.Scanner.Area = 1 },
		"pending-pen":   func(r *Renderer) { r.Raster.Filler.A.X = 1 },
		"clip":          func(r *Renderer) { r.Scanner.SetClip(image.Rect(10, 20, 256, 64)) },
		"empty-clip":    func(r *Renderer) { r.Scanner.SetClip(image.Rectangle{}) },
		"spanner-owner": func(r *Renderer) { r.Scanner.Spanner = &sceneSpanner{builder: sceneplan.New(r.image.Bounds())} },
	}
	for name, change := range changes {
		t.Run(name, func(t *testing.T) {
			r, key, _ := placementUnit(t)
			change(r)
			before := bytes.Clone(r.image.Pix)
			hits := r.glyphCoverage.hits
			if r.drawPlacedGlyphCoverage(image.NewUniform(color.White), key) || hits != r.glyphCoverage.hits || !bytes.Equal(before, r.image.Pix) {
				t.Fatal("changed guard bypassed")
			}
		})
	}
	r, key, _ := placementUnit(t)
	calls := 0
	if r.drawPlacedGlyphCoverage(image.NewUniform(coveredDrawColor{&calls}), key) || calls != 0 {
		t.Fatal("custom fill called/reused")
	}
	// A successful fast draw follows the original scanner cleanup and recoloring.
	original := New(math32.Vec2(256, 64)).(*Renderer)
	defer original.Release()
	original.Scanner.SetClip(original.image.Bounds())
	coverageSeed(r)
	coverageSeed(original)
	fill := image.NewUniform(color.NRGBA{71, 11, 39, 91})
	if !r.drawPlacedGlyphCoverage(fill, key) {
		t.Fatal("valid fast draw missed")
	}
	coverageReference(original, coverageGlyphPath(coverageSmallItem(), math32.Vec2(8, 24)), fill)
	if !bytes.Equal(r.image.Pix, original.image.Pix) || r.Scanner.Area != 0 || r.Scanner.Cover != 0 || len(r.Scanner.Cell) != 0 {
		t.Fatal("fast pixels/state differ")
	}
}

func TestVellumGlyphPlacementCannotLearnHashCollision(t *testing.T) {
	r, key, e := placementUnit(t)
	c := r.glyphCoverage
	c.placements = nil
	// An occupied fingerprint with a different full path must preserve drawing
	// while refusing to teach the placement index a false identity.
	fake := *e
	fake.path = append(Path(nil), e.path...)
	fake.path[1]++
	fake.identity = &glyphCoverageIdentity{1}
	c.entries[e.hash] = &fake
	r.Path = coverageGlyphPath(coverageSmallItem(), math32.Vec2(8, 24))
	if !r.drawGlyphCoverageAt(image.NewUniform(color.White), key) {
		t.Fatal("collision prevented original draw")
	}
	if c.placements != nil {
		t.Fatal("handled-but-unretained draw learned a placement")
	}
}

func TestVellumGlyphPlacementWarmBudgetBeforeLookup(t *testing.T) {
	item := coverageSmallItem()
	r := New(math32.Vec2(256, 64)).(*Renderer)
	defer r.Release()
	for range 3 {
		if r.ScenePacket(render.Render{item}) == nil {
			t.Fatal("warmup")
		}
	}
	if r.glyphCoverage.placements == nil || r.glyphCoverage.placements.hits == 0 {
		t.Fatal("no warm fast path")
	}
	run := item.Text.Lines[0].Runs[0].(*shapedgt.Run)
	g := &run.Glyphs[0]
	outline, _ := r.staticOutlines().ordinary(run.Face, g.GlyphID)
	before := r.glyphCoverage.placements.hits
	pixels := bytes.Clone(r.image.Pix)
	r.sceneRecord = sceneplan.New(r.image.Bounds())
	r.sceneWork = &sceneWorkBudget{remaining: len(outline.Segments) - 1, outlines: font.NewGlyphOutlineBudget(1<<20, 1<<20)}
	r.GlyphOutline(&item.Context, run, g, outline, image.NewUniform(item.Text.Color), nil, run.GlyphBoundsBox(g), item.Position, true)
	if !r.sceneRecord.Failed() || before != r.glyphCoverage.placements.hits || !bytes.Equal(pixels, r.image.Pix) {
		t.Fatal("warm placement bypassed work")
	}
	r.sceneRecord = nil
	r.sceneWork = nil
}

func TestVellumGlyphPlacementBoundedProbeCooldown(t *testing.T) {
	p := &glyphPlacementCache{count: glyphPlacementEntries}
	for range glyphPlacementProbeWindow {
		p.observe(false)
	}
	if p.skip != glyphPlacementCooldown || p.probes != 0 || p.wins != 0 {
		t.Fatal("cold probes not bounded")
	}
	r := &Renderer{glyphCoverage: &glyphCoverageCache{placements: p}}
	for range glyphPlacementCooldown {
		if r.glyphPlacementActive() {
			t.Fatal("cooldown returned early")
		}
	}
	if !r.glyphPlacementActive() {
		t.Fatal("bounded cooldown never resumed")
	}
	for range glyphPlacementProbeWindow {
		p.observe(true)
	}
	if p.skip != 0 || p.probes != 0 || p.wins != 0 {
		t.Fatal("useful probes disabled")
	}
	p.count = glyphPlacementEntries - 1
	for range glyphPlacementProbeWindow {
		p.observe(false)
	}
	if p.skip != 0 || p.probes != 0 {
		t.Fatal("cold fill disabled before index was populated")
	}
}

func TestVellumGlyphPlacementCooldownThresholdAndRouting(t *testing.T) {
	for _, wins := range []uint32{glyphPlacementProbeWindow/8 - 1, glyphPlacementProbeWindow / 8} {
		p := &glyphPlacementCache{count: glyphPlacementEntries}
		for i := uint32(0); i < glyphPlacementProbeWindow; i++ {
			p.observe(i < wins)
		}
		if (p.skip != 0) != (wins < glyphPlacementProbeWindow/8) {
			t.Fatal("cooldown threshold changed", wins)
		}
	}
	item := coverageSmallItem()
	run := item.Text.Lines[0].Runs[0].(*shapedgt.Run)
	originalGlyphs := run.Glyphs
	run.Glyphs = run.Glyphs[:1]
	defer func() { run.Glyphs = originalGlyphs }()
	item.Context.Bounds.Rect = math32.B2(0, 0, 512, 64)
	r := New(math32.Vec2(512, 64)).(*Renderer)
	defer r.Release()
	original := New(math32.Vec2(512, 64)).(*Renderer)
	defer original.Release()
	for i := 0; i < glyphPlacementEntries; i++ {
		item.Position = math32.Vec2(8+float32(i%2048)*.125, 24+float32(i/2048)*.125)
		if r.ScenePacket(render.Render{item}) == nil {
			t.Fatal("placement fill refused", i)
		}
	}
	p := r.glyphCoverage.placements
	if p == nil || p.count != glyphPlacementEntries {
		t.Fatal("actual index not populated")
	}
	p.skip = 2
	head, count, hits := p.head, p.count, p.hits
	retained := item.Position
	item.Position = math32.Vec2(300, 24)
	placementCompare(t, r, original, render.Render{item})
	if p.skip != 1 || p.head != head || p.count != count || p.hits != hits {
		t.Fatal("cooldown learned or reused a placement")
	}
	item.Position = retained
	placementCompare(t, r, original, render.Render{item})
	if p.skip != 0 || p.head != head || p.hits != hits {
		t.Fatal("cooldown did not preserve original routing")
	}
	placementCompare(t, r, original, render.Render{item})
	if p.hits != hits+1 {
		t.Fatal("exact reuse did not resume after bounded cooldown")
	}
}

func TestVellumGlyphPlacementExactLogicalWorkCharge(t *testing.T) {
	item := coverageSmallItem()
	r := New(math32.Vec2(256, 64)).(*Renderer)
	defer r.Release()
	for range 3 {
		if r.ScenePacket(render.Render{item}) == nil {
			t.Fatal("warmup")
		}
	}
	run := item.Text.Lines[0].Runs[0].(*shapedgt.Run)
	g := &run.Glyphs[0]
	outline, _ := r.staticOutlines().ordinary(run.Face, g.GlyphID)
	scale := math32.FromFixed(run.Size) / float32(run.Face.Upem())
	bounds, ok := originalOutlineBounds(outline, scale, item.Position)
	if !ok {
		t.Fatal("bounds")
	}
	extent := 1 + int(bounds.Size().X) + int(bounds.Size().Y)
	const initial = 1 << 20
	r.sceneRecord = sceneplan.New(r.image.Bounds())
	r.sceneWork = &sceneWorkBudget{remaining: initial, outlines: font.NewGlyphOutlineBudget(1<<20, 1<<20)}
	originalSpanner := r.Scanner.Spanner
	r.Scanner.Spanner = &sceneSpanner{builder: r.sceneRecord}
	defer func() { r.Scanner.Spanner = originalSpanner; r.sceneRecord = nil; r.sceneWork = nil }()
	r.Scanner.SetClip(r.image.Bounds())
	r.GlyphOutline(&item.Context, run, g, outline, image.NewUniform(item.Text.Color), nil, run.GlyphBoundsBox(g), item.Position, true)
	if r.sceneRecord.Failed() || r.sceneWork.remaining != initial-len(outline.Segments)*(1+extent) {
		t.Fatal("original logical work charge differs", r.sceneWork.remaining)
	}
}

func TestVellumGlyphPlacementEpochExhaustionAndLayout(t *testing.T) {
	type legacyOutlineEntry struct {
		key     outlineKey
		outline font.GlyphOutline
		cost    font.GlyphOutlineCost
		bytes   int
		extrema outlineExtrema
	}
	if unsafe.Sizeof(uintptr(0)) == 8 && unsafe.Sizeof(outlineEntry{}) != unsafe.Sizeof(legacyOutlineEntry{}) {
		t.Fatal("64-bit outline metadata grew")
	}
	face := vellumOutlineFace(t)
	gid, _ := face.NominalGlyph('A')
	c := &staticOutlineCache{nextIdentity: ^uint32(0) - 1}
	own, ok := c.ordinary(face, gid)
	if !ok {
		t.Fatal("outline")
	}
	epoch, id := c.placementIdentity(face.Font, gid, own)
	if epoch == nil || id != ^uint32(0) {
		t.Fatal("last identity not issued")
	}
	otherGID, _ := face.NominalGlyph('B')
	other, _ := c.ordinary(face, otherGID)
	_, exhausted := c.placementIdentity(face.Font, otherGID, other)
	if exhausted != 0 || c.nextIdentity != ^uint32(0) {
		t.Fatal("exhaustion wrapped")
	}
	again, live := c.placementIdentity(face.Font, gid, own)
	if again != epoch || live != id {
		t.Fatal("exhaustion revoked live identity")
	}
	fresh := &staticOutlineCache{}
	replacement, _ := fresh.ordinary(face, gid)
	newEpoch, newID := fresh.placementIdentity(face.Font, gid, replacement)
	if newEpoch == nil || newEpoch == epoch || newID != 1 {
		t.Fatal("cache epochs alias")
	}
	r, key, e := placementUnit(t)
	key.generation = 0
	if r.drawPlacedGlyphCoverage(image.NewUniform(color.White), key) {
		t.Fatal("zero generation reused")
	}
	r.glyphCoverage.placements = nil
	r.glyphCoverage.rememberPlacement(key, e, image.Point{}, image.Rectangle{})
	if r.glyphCoverage.placements != nil {
		t.Fatal("zero generation learned")
	}
}
