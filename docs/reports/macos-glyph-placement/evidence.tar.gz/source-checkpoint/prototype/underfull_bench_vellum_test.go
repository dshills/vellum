package rasterx

import (
 "testing"
 "cogentcore.org/core/math32"
 "cogentcore.org/core/paint/render"
 "cogentcore.org/core/text/shaped/shapers/shapedgt"
)

func BenchmarkVellumGlyphPlacementUnderfullClippedMiss(b *testing.B) {
 item:=coverageSmallItem();run:=item.Text.Lines[0].Runs[0].(*shapedgt.Run)
 glyphs:=run.Glyphs;run.Glyphs=run.Glyphs[:1];defer func(){run.Glyphs=glyphs}()
 var commands render.Render
 for row:=0;row<50;row++{for col:=0;col<8;col++{
  v:=*item;v.Context.Bounds.Rect=math32.B2(0,0,1519,1266);v.Position=math32.Vec2(float32(10+col*96),float32(24+row*12));commands=append(commands,&v)
 }}
 r:=New(math32.Vec2(1519,1266)).(*Renderer);defer r.Release()
 for range 3{if r.ScenePacket(commands)==nil{b.Fatal("warmup refused")}}
 // The original 400 exact positions remain present, but every later clip cuts
 // its glyph hull. The index stays underfull and cannot use its saturation
 // cooldown. This is a deliberate repeated guard-miss workload.
 for _,command:=range commands{v:=command.(*render.Text);x,y:=v.Position.X,v.Position.Y;v.Context.Bounds.Rect=math32.B2(x+2,y-8,x+3,y+1)}
 b.ReportAllocs();b.ResetTimer()
 for range b.N{if r.ScenePacket(commands)==nil{b.Fatal("clipped capture refused")}}
}
