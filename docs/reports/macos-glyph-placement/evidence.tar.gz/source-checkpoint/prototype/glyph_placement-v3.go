// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"github.com/go-text/typesetting/font"
	"image"
)

const glyphPlacementEntries = 8192

// Exact float32 inputs are required: integer translations at different exponent
// boundaries need not produce identical fixed paths. Identity tokens refer only
// to private immutable outlines and contain no font, slice or renderer reference.
type glyphPlacementKey struct {
	outline     *outlineIdentity
	scale, x, y uint32
}
type glyphPlacement struct {
	hash     uint64
	coverage *glyphCoverageIdentity
	origin   image.Point
	hull     image.Rectangle
}

// Fixed-capacity FIFO metadata is allocated lazily for scene captures. Values
// retain only small identity tokens, never coverage arrays, fonts or packets.
// Coverage eviction invalidates placements even if its hash is later reused.
type glyphPlacementCache struct {
	entries            map[glyphPlacementKey]glyphPlacement
	queue              [glyphPlacementEntries]glyphPlacementKey
	head, count        int
	hits, misses       uint64
	probes, wins, skip uint32
}

func (c *glyphCoverageCache) rememberPlacement(key glyphPlacementKey, e *glyphCoverageEntry, origin image.Point, hull image.Rectangle) {
	if key.outline == nil || e.identity == nil {
		return
	}
	if c.placements == nil {
		c.placements = &glyphPlacementCache{entries: make(map[glyphPlacementKey]glyphPlacement)}
	}
	p := c.placements
	if _, ok := p.entries[key]; !ok {
		if p.count == glyphPlacementEntries {
			delete(p.entries, p.queue[p.head])
			p.head = (p.head + 1) % glyphPlacementEntries
			p.count--
		}
		p.queue[(p.head+p.count)%glyphPlacementEntries] = key
		p.count++
	}
	p.entries[key] = glyphPlacement{e.hash, e.identity, origin, hull}
}
func (rs *Renderer) drawPlacedGlyphCoverage(fill image.Image, key glyphPlacementKey) bool {
	if key.outline == nil || rs.glyphCoverage == nil || rs.glyphCoverage.placements == nil {
		return false
	}
	c := rs.glyphCoverage
	p := c.placements
	v, ok := p.entries[key]
	if !ok {
		return p.miss()
	}
	e := c.entries[v.hash]
	if e == nil || e.identity != v.coverage {
		return p.miss()
	}
	bounds, ready := rs.glyphCoverageReady(fill)
	if !ready || !v.hull.In(bounds) || !v.hull.In(rs.Scanner.Clip) {
		return p.miss()
	}
	p.hits++
	p.observe(true)
	c.hits++
	rs.emitGlyphCoverage(e, v.origin, fill)
	return true
}

// Retrieve only an identity for the currently live private immutable slice.
// Public/custom outlines and a slice evicted/replaced under the same font/GID
// cannot authorize a placement, even when their segment counts coincide.
func (cache *staticOutlineCache) placementIdentity(f *font.Font, gid font.GID, outline font.GlyphOutline) *outlineIdentity {
	if len(outline.Segments) == 0 {
		return nil
	}
	cache.mu.Lock()
	defer cache.mu.Unlock()
	element := cache.entries[outlineKey{f, gid}]
	if element == nil {
		return nil
	}
	e := element.Value.(outlineEntry)
	if len(e.outline.Segments) != len(outline.Segments) || &e.outline.Segments[0] != &outline.Segments[0] {
		return nil
	}
	return e.identity
}

const glyphPlacementProbeWindow = uint32(glyphPlacementEntries)
const glyphPlacementCooldown = 32 * glyphPlacementProbeWindow

// A full index with fewer than one hit per eight probes is not paying for its
// lookup/admission work. Use the original path for a bounded eligible-glyph
// interval, then probe again so stationary text can regain reuse. These counters
// affect optimization only; original scene work and refusal checks run first.
func (p *glyphPlacementCache) observe(hit bool) {
	if p.count < glyphPlacementEntries {
		return
	}
	p.probes++
	if hit {
		p.wins++
	}
	if p.probes == glyphPlacementProbeWindow {
		if p.wins < glyphPlacementProbeWindow/8 {
			p.skip = glyphPlacementCooldown
		}
		p.probes = 0
		p.wins = 0
	}
}
func (p *glyphPlacementCache) miss() bool { p.misses++; p.observe(false); return false }
func (rs *Renderer) glyphPlacementActive() bool {
	if rs.glyphCoverage == nil || rs.glyphCoverage.placements == nil {
		return true
	}
	p := rs.glyphCoverage.placements
	if p.skip != 0 {
		p.skip--
		return false
	}
	return true
}
