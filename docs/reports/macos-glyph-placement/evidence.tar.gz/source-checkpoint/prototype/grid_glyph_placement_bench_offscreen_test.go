//go:build offscreen

package cogent

import (
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"encoding/json"
	"fmt"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
	"image"
	"testing"
)

func TestVellumGlyphPlacementActualGridCaptureBench(t *testing.T) {
	for _, dpi := range []float32{96, 160, 192} {
		for _, variable := range []bool{false, true} {
			t.Run(fmt.Sprintf("%g/%v", dpi, variable), func(t *testing.T) {
				source := &tileBinningSource{nativeGridSource: nativeGridSource{rows: 1000000, revision: 1}}
				var input virtual.GridSource = source
				if variable {
					input = &tileBinningVariableSource{source}
				}
				columns := make([]virtual.GridColumn, 20)
				for i := range columns {
					columns[i] = virtual.GridColumn{ID: fmt.Sprint("c", i), Title: fmt.Sprint("C", i), Width: 96}
				}
				model, err := virtual.NewGrid(input, columns, virtual.GridConfig{RowHeight: 12, HeaderHeight: 24, FrozenColumns: 2, OverscanRows: 1, OverscanColumns: 1}, virtual.GridViewport{Width: 768, Height: 624})
				if err != nil {
					t.Fatal(err)
				}
				config := manualConfig(t, 7)
				config.LogicalDPI = dpi
				config.Theme.Default.Typography = ui.Some(ui.Typography{Family: "Noto Sans", Size: 15})
				a, err := app.New(app.Config{QueueCapacity: 32})
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(a.Close)
				view := func() ui.Node {
					return ui.Node{ID: "root", Kind: ui.Column, Style: ui.Style{Padding: ui.Some(ui.Insets{}), Gap: ui.Some(float32(0))}, Children: []ui.Node{{ID: "g", Kind: ui.DataGrid, Grid: model, Style: ui.Style{Grow: ui.Some(float32(0)), MinSize: ui.Some(ui.Size{Width: 1299, Height: 1060}), MaxSize: ui.Some(ui.Size{Width: 1299, Height: 1060})}}}}
				}
				if err = a.Open(app.Window{ID: "one", Title: "Grid encoder", Width: 1500 * dpi / 160, Height: 1250 * dpi / 160, View: view}); err != nil {
					t.Fatal(err)
				}
				m, err := NewManual(testContext, a, config)
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(func() {
					if e := m.Close(testContext); e != nil {
						t.Error(e)
					}
				})

				var batches []render.Render
				for frame, step := range []image.Point{{}, {0, 12}, {96, 12}, {-96, -12}} {
					if frame > 0 {
						if err = a.Do(func() {
							if e := model.Scroll(step.X, step.Y); e != nil {
								t.Error(e)
							}
							_ = a.Invalidate("one")
						}); err != nil {
							t.Fatal(err)
						}
					}
					gridFrame(t, m)
					if err = a.Do(func() {
						scene := m.implementation.find("one").state.body.Scene
						scene.RenderWidget()
						batches = append(batches, scene.Painter.RenderDone())
					}); err != nil {
						t.Fatal(err)
					}
				}
				for round := 0; round < 5; round++ {
					result := testing.Benchmark(func(b *testing.B) {
						r := rasterx.New(math32.Vec2(1519*dpi/160, 1266*dpi/160)).(*rasterx.Renderer)
						defer r.Release()
						for i := 0; i < 8; i++ {
							if r.ScenePacket(batches[i%len(batches)]) == nil {
								b.Fatal("warmup refused")
							}
						}
						b.ReportAllocs()
						b.ResetTimer()
						for i := 0; i < b.N; i++ {
							if r.ScenePacket(batches[i%len(batches)]) == nil {
								b.Fatal("capture refused")
							}
						}
					})
					record := map[string]any{"dpi": dpi, "variable": variable, "round": round, "n": result.N, "ns_op": result.NsPerOp(), "bytes_op": result.AllocedBytesPerOp(), "allocs_op": result.AllocsPerOp()}
					line, _ := json.Marshal(record)
					t.Log("PLACEMENT_BENCH", string(line))
				}
			})
		}
	}
}
