// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
 "testing"
 "cogentcore.org/core/math32"
 "cogentcore.org/core/paint/render"
)

func placementFixture() [2]render.Render {
 item:=coverageSmallItem()
 var result [2]render.Render
 for frame:=range result {
  for row:=0;row<50;row++ { for col:=0;col<8;col++ {
   v:=*item
   v.Context.Bounds.Rect=math32.B2(0,0,1519,1266)
   v.Position=math32.Vec2(float32(10+col*96),float32(24+row*12+frame*12))
   result[frame]=append(result[frame],&v)
  } }
 }
 return result
}

func BenchmarkVellumGlyphPlacementCapture(b *testing.B) {
 commands:=placementFixture()
 for _,scroll:=range []bool{false,true} {
  name:="fixed";if scroll { name="alternating-rows" }
  b.Run(name,func(b *testing.B) {
   r:=New(math32.Vec2(1519,1266)).(*Renderer);defer r.Release()
   for i:=0;i<4;i++ { if r.ScenePacket(commands[i%2])==nil { b.Fatal("warmup refused") } }
   b.ReportAllocs();b.ResetTimer()
   for i:=0;i<b.N;i++ { n:=0;if scroll{n=i%2};if r.ScenePacket(commands[n])==nil { b.Fatal("capture refused") } }
  })
 }
}
