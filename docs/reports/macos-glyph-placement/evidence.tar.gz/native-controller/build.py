"""One fresh clean-source native build; no runtime execution."""
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
def main():
 need(not P.exists(),'fresh build root');source=identity(T);need(identity(C)==source,'source parity')
 P.mkdir(mode=0o700);(P/'source.json').write_text(json.dumps(source,indent=2)+'\n')
 pins={str(T/n):h for n,h in source['files'].items()};pins.update({str(T/'drivers/cogent/build'/n):h for n,h in source['prepared'].items()})
 for p in[W/'build.py',W/'common.py',guard_path,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',P/'source.json']:pins[str(p)]=sha(p)
 stable=lambda:all(sha(p)==h for p,h in pins.items())
 d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,commands=[],native_runtime_executed=False,error=None)
 try:
  binary=P/'loadedgrid'
  commands=[('build',['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go','build','-p=1','-trimpath','-o',str(binary),'.'],T/'examples/loadedgrid'),('metadata',['/opt/homebrew/bin/go','version','-m',str(binary)],P)]
  for name,args,cwd in commands:
   run=g.execute(args,cwd,P/name,lambda:False,stable,timeout=300,limit=4<<20);d['commands'].append(dict(name=name,run=run));terminal(run)
  meta=(P/'metadata/stdout').read_text();need('vcs.revision='+HEAD in meta and 'vcs.modified=false' in meta,'clean native build metadata')
  need(identity(T)==identity(C)==source and stable(),'final full source and prepared parity')
  d.update(result='PASS_CLEAN_NATIVE_COMPILE_ONLY',binary=dict(path=str(binary),sha256=sha(binary),bytes=binary.stat().st_size),source_stable=True,prepared_stable=True)
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with(P/'build-receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k!='inputs'}),flush=True)
if __name__=='__main__':main()
