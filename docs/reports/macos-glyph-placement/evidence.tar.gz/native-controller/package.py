"""Make a reviewable report and integrity-checked raw evidence package, without repo mutations."""
from pathlib import Path
import hashlib,json,tarfile
W=Path(__file__).resolve().parent;G=W.parent/'macos-glyph-placement';P=Path('/private/tmp/vellum-glyph-native-2be8e79');O=P/'report';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
commit=read(G/'commit-receipt.json');native=read(W/'analysis.json');checkpoint=read(G/'checkpoint.json')
assert commit['commit']==native['source_commit']=='2be8e790f8d5cdce5e0adac31b2adf5d73a76656'and native['ordinary_samples']==480
assert read(P/'native-receipt.json')['result']=='PASS_SCOPED_CURRENT_NATIVE_SANITY'and(P/'stop-live').exists()
O.mkdir(mode=0o700);sources={}
for prefix,root in [('source-checkpoint',Path(checkpoint['path'])),('native-controller',W),('native',P)]:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(root)
  if '__pycache__'in relative.parts or prefix=='native'and(relative.parts[0]=='report'or p.name=='loadedgrid'):continue
  assert not p.is_symlink();sources[str(Path(prefix)/relative)]=p
for name,p in [('owned-child-helper.py',W.parent/'macos-sdk-native-238b3b6/run.py'),('strict-validators.py',W.parent/'macos-ax-copy-native-3a14e53/run.py'),('live-lease.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'))]:sources['shared/'+name]=p
for name in['child_process.py','sdk_environment.py','benchmark-grid.py']:sources['shared/'+name]=Path('/private/tmp/vellum-macos-native-results-97aee13/scripts')/name
manifest=dict(schema=1,source_commit=commit['commit'],files={n:dict(sha256=sha(p),bytes=p.stat().st_size)for n,p in sorted(sources.items())},excluded_executables=[native['binary'],*checkpoint['excluded_executables']],scope='Source/prototype checks, raw failures and exact reviewed/native evidence. Complete tracked/prepared source identity manifests are included; this is not a portable SDK, toolchain closure or executable distribution.')
(O/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(O/'evidence.tar.gz','w:gz')as output:
 for name,p in sorted(sources.items()):
  assert sha(p)==manifest['files'][name]['sha256'];output.add(p,arcname=name,recursive=False);assert sha(p)==manifest['files'][name]['sha256']
 output.add(O/'evidence.manifest.json',arcname='evidence.manifest.json',recursive=False)
with tarfile.open(O/'evidence.tar.gz','r:gz')as archive:
 expected=set(sources)|{'evidence.manifest.json'};assert set(archive.getnames())==expected and len(archive.getmembers())==len(expected)
 for member in archive:
  assert member.isfile()and not member.issym();data=archive.extractfile(member).read();expected_hash=sha(O/'evidence.manifest.json')if member.name=='evidence.manifest.json'else manifest['files'][member.name]['sha256'];assert hashlib.sha256(data).hexdigest()==expected_hash
offscreen=read(G/'analysis.json');offscreen.pop('inputs')
result=dict(schema=1,source_commit=commit['commit'],source_parent=commit['parent'],source_review_sha256=commit['review_sha256'],source_checkpoint=checkpoint,source_files=4678,prepared_files=6249,owned_stage=76,offscreen=offscreen,production=read(G/'production-analysis.json'),provider=dict(provider='Anthropic',model='claude-sonnet-5-5',calls=1,files=10,bytes=53368,retained_findings=0,discarded_medium='60bf3eeb2dbcce14',disposition='Independently refuted by complete path-input inspection; no source or test changes after provider. Raw finding retained.'),native=native,evidence=dict(manifest_sha256=sha(O/'evidence.manifest.json'),archive_sha256=sha(O/'evidence.tar.gz'),raw_files=len(sources),archive_bytes=(O/'evidence.tar.gz').stat().st_size),full_macos_qualified=False)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
rows='\n'.join('| '+x['case']+' | '+f"{x['ui_work_ns']['p95']/1e6:.3f}"+' | '+f"{x['ui_work_ns']['p99']/1e6:.3f}"+' |'for x in native['cases']if'ui_work_ns'in x)
text='''# Exact small-glyph placement coverage and current native sanity

Source `2be8e790f8d5cdce5e0adac31b2adf5d73a76656` adds owned preparation stage
0076 for bounded renderer-owned small-glyph scene coverage reuse. Scoped
offscreen correctness and current-source native sanity pass. All four native
scroll cases still fail the unchanged 4 ms p95 / 6 ms p99 UI-work targets.
No native performance improvement or broad no-regression is established.

## Source and automated evidence

The shortcut uses an outline-cache epoch, nonwrapping entry ID and exact final
float32 scale/position bits. Live outline ownership, current coverage identity,
clip/scanner/spanner guards and original work charges still apply. Independent
FIFO placement metadata is capped at 8,192 entries and retains no outline/span
arrays; its additional map/metadata storage is separate from the existing
coverage backing budget. Saturated low-hit probes temporarily use the original
path. Underfull clipped misses are not covered by that cooldown. Unsupported
fonts, transforms and other refused cases retain ordinary rendering.
See [the renderer contract](../../../specs/rendering.md) and
[owned stage](../../../drivers/cogent/native/patches/glyphplacement/README.md).

Four A/B/B/A offscreen processes compare the exact prior four-file compiler
overlay with the candidate on otherwise identical source. This baseline is not
a clean historical executable. Each process produces 24 retained-grid records
across fixed/variable rows and DPI96/160/192; all byte/pixel/geometry identities
match. At DPI96, pooled ten-observation capture medians fall from 1.235 to
0.932 ms for fixed rows and 1.963 to 1.768 ms for variable rows (24.6% and 9.9%).
Bitmap routes at DPI160/192 are mixed. Five-observation synthetic cold-coordinate
and underfull clipped-miss medians rise about 2.0% and 2.3%. These are isolated
ScenePacket capture measurements, not native frames, physical GPU work or
memory qualification. CPU labels report 14 despite a GOMAXPROCS2 request;
exclusive-core or complete host isolation is not claimed.

Preparation checks, owned raster/sceneplan race checks, the complete offscreen
driver-root race suite and vet pass. The first full driver attempt times out
at five minutes and remains failed. A test-only revision removes duplicate
full per-pixel GPU integer execution from the new companion test; the original
integer oracle remains unchanged. All 24 companion identities remain equal,
and the final complete driver suite passes in 233.99 seconds. Six intentional
guard-removal source overlays each fail their intended regression. Earlier
failed test/control variants and preparation refusal records remain archived.

Internal reviews precede adoption and commit. One complete Prism call uses
Anthropic `claude-sonnet-5-5` on ten files / 53,368 diff bytes. It retains zero
findings and discards one tentative medium about missing path-key inputs.
That raw concern is independently assessed and refuted against the complete
path-input and supported-font rules. No source/test changes follow the provider
review. The native evidence below has separate internal admission/result review;
it does not trigger another provider call.

## Current native execution

A fresh release binary identifies clean `2be8e79`, with 4,678 tracked and 6,249
prepared files. SHA256 is
`73496fe0ea3410242013839565c55a5546391d015125167d246aea95c9892098`.
Both source checkouts remain clean and byte-identical through completion.
This build is separate from the earlier precommit compile-only binary.

One Cocoa million-row accessibility case passes the 400-visible-cell minimum,
2,268 overlap reuse observations, 459 replacement retirements, native cell
press delivery and closed-attachment refusal. Observations are not counts of
distinct reused objects. Four further processes each complete 128 guarded
warmup events and 120 measured callbacks exactly once, without missing or
pending records. Native endpoints match at 1519×1266 pixels, DPI162/DPR1.

| Million-row case | p95 UI work (ms) | p99 UI work (ms) |
|---|---:|---:|
'''+rows+'''

These are four current-source sanity processes, with no matched baseline and
no complete P6 performance campaign. GPU requests do not establish actual GPU
execution or presentation. Default-DPI native placement-cache hits are not
proven. Endpoint equality does not prove continuous display stability.

The shared live-test lease, universal/local stop guards, 180-second watchdogs,
8 MiB per-stream limits and independent owned-group cleanup cover all five
processes. Each exits zero, reaches both EOFs and has its process group observed
absent before the next dispatch; the campaign is sealed afterward. The controller
passes three finalization and 17 refusal controls. A reused control-output
directory is refused before cases and preserved; a fresh version passes. An
offline analyzer initially addresses the wrong timing nesting and fails before
writing a result. Its corrected version revalidates the same raw logs; no native
process is rerun or relabeled. No other owned builds/profiles overlap ordinary
timings. Complete global host isolation is not proven.

No desktop pointer/key events or input-source, VoiceOver, clipboard or OS
preference changes are made. Fixture geometry persistence is disabled.
Physical workflows, human accessibility, native/GPU memory, sustained frame
targets, P4/P6/P9/P11 and full Mac/release qualification remain open. No public
release, signing, notarization or publishing occurs.

See [structured results](result.json), [raw-file manifest](evidence.manifest.json)
and [raw evidence](evidence.tar.gz). The bundle includes failures, source
identity manifests, controllers, reviews and raw outputs, with executables
excluded and identified by digest. It is not a portable source/toolchain closure.
'''
(O/'README.md').write_text(text)
receipt=dict(report=str(O),files={p.name:dict(sha256=sha(p),bytes=p.stat().st_size)for p in sorted(O.iterdir())})
with(W/'package.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
