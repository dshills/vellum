"""Five current-source sanity launches; no baseline or improvement qualification."""
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
VALIDATOR=W.parent/'macos-ax-copy-native-3a14e53/run.py'
need(sha(VALIDATOR)=='4133c9cec20cca9d773d91384cd8ec51f694032d2666452b3a7c639d7e0e4ede','frozen result validators')
v=module('glyph_native_prior_validators',VALIDATOR)
def fresh(root):
 need(not(root/'native-receipt.json').exists()and not(root/'runs').exists()and not(root/'stop-live').exists(),'fresh unsealed native campaign')
def finalize(root,d):
 d['finalization_errors']=[]
 try:(root/'stop-live').touch()
 except BaseException as e:d['finalization_errors'].append(dict(stage='seal-stop',type=type(e).__name__,message=str(e)))
 d['result']='PASS_SCOPED_CURRENT_NATIVE_SANITY'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_CURRENT_NATIVE_SANITY'
 try:
  with(root/'native-receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 except BaseException as e:
  d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(e).__name__,message=str(e)));d['result']='FAILED_OR_CANCELED_CURRENT_NATIVE_SANITY'
 return d
def plan_cases():
 cases=[dict(label='native-ax',kind='ax',argv=['-accessibility-smoke','-rows=1000000'])]
 for gpu in[False,True]:
  for variable in[False,True]:
   argv=['-perf','-rows=1000000','-perf-samples=120','-perf-warmup=128']+(['-gpu-scene']if gpu else[])+(['-variable-rows']if variable else[])
   cases.append(dict(label=('gpu'if gpu else'cpu')+('-variable'if variable else'-fixed'),kind='ordinary',gpu=gpu,variable=variable,argv=argv))
 return cases
def main():
 fresh(P);review=read(W/'readiness.json');need(review['execution_ready']is True and not review['unresolved_findings'],'internal launch review')
 need(all(sha(p)==h for p,h in review['inputs'].items()),'reviewed input pins')
 build=read(P/'build-receipt.json');need(build['result']=='PASS_CLEAN_NATIVE_COMPILE_ONLY','fresh terminal build');binary=build['binary'];source=read(P/'source.json')
 pins={**build['inputs'],**review['inputs']};stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(P/'stop-live').exists()
 need(stable()and not stopping(),'initial admission')
 d=dict(result='INCOMPLETE',source_commit=HEAD,producer_sha256=sha(__file__),review_sha256=sha(W/'readiness.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False,physical_input_generated=False,settings_changes=False,native_gpu_execution_verified=False,frame_improvement_qualified=False,full_macos_qualified=False,error=None,cases=[])
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping()and identity(T)==identity(C)==source,'lease/source admission');(P/'runs').mkdir();previous=None
   for case in plan_cases():
    need(lease.held()and stable()and not stopping(),'case admission')
    if previous is not None:g.absent(previous)
    need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'fixed binary')
    out=P/'runs'/case['label'];run=g.execute([binary['path'],*case['argv']],T/'examples/loadedgrid',out,stopping,stable,timeout=180,limit=8<<20)
    record=dict(case=case,run=run,error=None);d['cases'].append(record);d['native_runtime_executed']=d['native_runtime_executed']or run['created']
    try:
     terminal(run);previous=run['pid'];records=[json.loads(x)for x in(out/'stdout').read_bytes().splitlines()]
     if case['kind']=='ax':record['validation']=v.validate_ax(records)
     else:
      samples=v.perf_records(records,variable=case['variable'],gpu=case['gpu'],allocated=False,samples=120)
      record['validation']=dict(samples=len(samples),callbacks=records[-1]['callbacks'],native_window=records[1]['native_window'],timings_ns=benchmark.summarize([samples]))
    except BaseException as e:record['error']=dict(type=type(e).__name__,message=str(e));raise
    finally:
     with(out/'receipt.json').open('x')as f:f.write(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(case=case['label'],result='COMPLETED',seconds=run['seconds'])),flush=True)
   need(len(d['cases'])==5 and identity(T)==identity(C)==source and stable()and not stopping(),'final all-case/source check')
   d.update(source_stable=True,prepared_stable=True,lease_held_through_cleanup=lease.held(),ordinary_processes=4,ordinary_samples=480)
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 finally:finalize(P,d);print(json.dumps({k:v for k,v in d.items()if k!='cases'}),flush=True)
 need(d['error']is None and not d['finalization_errors'],'native sanity failed or canceled')
if __name__=='__main__':main()
