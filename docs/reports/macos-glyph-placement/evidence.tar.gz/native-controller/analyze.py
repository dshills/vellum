"""Revalidate terminal current-source native records and explicitly separate open performance gates."""
import datetime,json,sys
sys.dont_write_bytecode=True
import run as m
receipt=m.read(m.P/'native-receipt.json');review=m.read(m.W/'readiness.json');build=m.read(m.P/'build-receipt.json');source=m.read(m.P/'source.json')
m.need(receipt['result']=='PASS_SCOPED_CURRENT_NATIVE_SANITY'and not receipt['error']and not receipt['finalization_errors']and len(receipt['cases'])==5,'terminal native campaign')
m.need((m.P/'stop-live').exists()and m.identity(m.T)==m.identity(m.C)==source,'sealed and clean matching source/prepared vectors')
m.need(m.sha(build['binary']['path'])==build['binary']['sha256'],'retained native executable')
records=[];inputs={str(m.P/'native-receipt.json'):m.sha(m.P/'native-receipt.json'),str(m.W/'readiness.json'):m.sha(m.W/'readiness.json'),str(m.P/'build-receipt.json'):m.sha(m.P/'build-receipt.json'),str(m.P/'source.json'):m.sha(m.P/'source.json'),str(m.W/'analyze.py'):m.sha(m.W/'analyze.py')}
for expected,item in zip(m.plan_cases(),receipt['cases']):
 m.need(item['case']==expected and item['error']is None,'fixed complete native cases');run=item['run'];m.terminal(run);m.g.absent(run['pid'])
 root=m.P/'runs'/expected['label']
 for name in['stdout','stderr']:
  p=root/name;m.need(dict(bytes=p.stat().st_size,sha256=m.sha(p))==run['logs'][name],'raw log identity');inputs[str(p)]=m.sha(p)
 inputs[str(root/'receipt.json')]=m.sha(root/'receipt.json');m.need(m.read(root/'receipt.json')==item,'case receipt parity')
 raw=[json.loads(x)for x in(root/'stdout').read_bytes().splitlines()]
 if expected['kind']=='ax':records.append(dict(case=expected['label'],validation=m.v.validate_ax(raw)))
 else:
  samples=m.v.perf_records(raw,variable=expected['variable'],gpu=expected['gpu'],allocated=False,samples=120)
  m.need(m.benchmark.summarize([samples])==item['validation']['timings_ns'],'independent summary parity')
  metric=m.benchmark.distribution([s['metrics']['ui_work_ns']for s in samples]);phases={key:m.benchmark.distribution([s['metrics'][key]for s in samples])for key in m.benchmark.WORK_PHASES}
  records.append(dict(case=expected['label'],samples=len(samples),completed_callbacks=raw[-1]['callbacks'],native_window=raw[1]['native_window'],ui_work_ns=metric,phases_ns=phases,p95_target_pass=metric['p95']<=4_000_000,p99_target_pass=metric['p99']<=6_000_000))
native=[x['native_window']for x in records if'native_window'in x]
result=dict(schema=1,result='PASS_SCOPED_CURRENT_NATIVE_SANITY',source_commit=m.HEAD,source_files=len(source['files']),prepared_files=len(source['prepared']),source_prepared_canonical_parity=True,review_sha256=m.sha(m.W/'readiness.json'),binary=build['binary'],inputs=inputs,cases=records,ordinary_processes=4,ordinary_samples=480,native_endpoints_equal=all(x==native[0]for x in native),physical_input_verified=False,native_gpu_execution_verified=False,native_placement_cache_hits_verified=False,performance_improvement_qualified=False,no_regression_qualified=False,full_macos_qualified=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with(m.W/'analysis.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in['inputs','cases']}))
for x in records:print(json.dumps(x if'ui_work_ns'not in x else dict(case=x['case'],ui_work_ns=x['ui_work_ns'],p95_target_pass=x['p95_target_pass'],p99_target_pass=x['p99_target_pass'])))
