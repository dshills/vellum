"""Exercise current controller refusals and the inherited strict validators, without native execution."""
import copy,json,sys
sys.dont_write_bytecode=True
import run as m
root=m.P/'controls-v2';root.mkdir(mode=0o700);results=[]
def refused(name,fn):
 try:fn()
 except(ValueError,KeyError,TypeError):results.append(dict(case=name,refused=True));return
 raise AssertionError('accepted invalid '+name)
for name in['normal','seal-failure','existing-receipt','existing-runs','sealed']:(root/name).mkdir()
d=m.finalize(root/'normal',dict(error=None,native_runtime_executed=False));m.need(d['result']=='PASS_SCOPED_CURRENT_NATIVE_SANITY'and not d['finalization_errors'],'normal synthetic finalization')
touch=m.Path.touch
try:
 def bad(self,*a,**kw):
  if self==root/'seal-failure/stop-live':raise OSError('injected seal failure')
  return touch(self,*a,**kw)
 m.Path.touch=bad;d=m.finalize(root/'seal-failure',dict(error=None,native_runtime_executed=False));m.need(d['result']=='FAILED_OR_CANCELED_CURRENT_NATIVE_SANITY'and m.read(root/'seal-failure/native-receipt.json')==d and d['finalization_errors'][0]['stage']=='seal-stop','failure receipt despite sealing error')
finally:m.Path.touch=touch
p=root/'existing-receipt/native-receipt.json';p.write_text('prior terminal\n');d=m.finalize(root/'existing-receipt',dict(error=None,native_runtime_executed=False));m.need(p.read_text()=='prior terminal\n'and d['result']=='FAILED_OR_CANCELED_CURRENT_NATIVE_SANITY'and d['finalization_errors'][0]['stage']=='exclusive-receipt','prior receipt unchanged')
(root/'existing-runs/runs').mkdir();(root/'sealed/stop-live').touch()
for name in['existing-receipt','existing-runs','sealed']:refused('fresh-'+name,lambda name=name:m.fresh(root/name))
ax=[dict(event='grid.accessibility.pass',rows=1000000,visible_minimum=400,overlap_objects_reused=2268,replacement_objects_retired=459,native_press_admitted=True),dict(event='grid.accessibility.closed',attachment_query_refused=True,geometry_persistence_disabled_in_fixture=True)]
m.v.validate_ax(ax)
for name,index,key,value in[('AX rows',0,'rows',True),('AX minimum',0,'visible_minimum',399),('AX reuse',0,'overlap_objects_reused',399),('AX retire',0,'replacement_objects_retired',True),('AX press',0,'native_press_admitted',False),('AX closed',1,'attachment_query_refused',False),('AX persistence',1,'geometry_persistence_disabled_in_fixture',False)]:
 b=copy.deepcopy(ax);b[index][key]=value;refused(name,lambda b=b:m.v.validate_ax(b))
refused('AX missing close',lambda:m.v.validate_ax(ax[:1]));refused('AX duplicate stage',lambda:m.v.validate_ax(ax+ax[:1]))
fixture=m.Path('/private/tmp/vellum-tile-binning-native-75-continuation/runs/candidate-gpu-fixed-r5-1000000/stdout');records=[json.loads(x)for x in fixture.read_bytes().splitlines()]
m.v.perf_records(records,variable=False,gpu=True,allocated=False,samples=120)
for name,mutate in[('ordinary allocation mode',lambda r:[x.update(alloc_profile=True)for x in r]),('ordinary CPU profile',lambda r:[x.update(cpu_profile=True)for x in r]),('missing callback',lambda r:r[-1].update(callbacks=119)),('warmup callback',lambda r:r[1].update(warm_callbacks=127)),('duplicate ticket',lambda r:r[3].update(tag=1))]:
 b=copy.deepcopy(records);mutate(b);refused(name,lambda b=b:m.v.perf_records(b,variable=False,gpu=True,allocated=False,samples=120))
plan=m.plan_cases();m.need(len(plan)==5 and len({x['label']for x in plan})==5 and sum(x['kind']=='ordinary'for x in plan)==4,'bounded five-case plan')
m.need({(x['gpu'],x['variable'])for x in plan if x['kind']=='ordinary'}=={(False,False),(False,True),(True,False),(True,True)},'exact four configurations')
result=dict(result='PASS_NON_NATIVE_CURRENT_SANITY_CONTROLS',native_runtime_executed=False,producer_sha256=m.sha(__file__),runner_sha256=m.sha(m.W/'run.py'),validator_sha256=m.sha(m.VALIDATOR),finalization_cases=3,refusals=len(results),results=results,positive_fixture=dict(path=str(fixture),sha256=m.sha(fixture)),plan=plan)
with(m.W/'controls.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in['results','plan']}))
