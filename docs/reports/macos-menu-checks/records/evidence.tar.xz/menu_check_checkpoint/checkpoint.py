from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-menu-checks')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines());assert len(names)==15,names
sources={n:sha(R/n)for n in sorted(names)};assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='4ddf0783eb9144f6034efb282fb2a8d1a002f557'
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':'4ddf0783eb9144f6034efb282fb2a8d1a002f557','sources':sources},indent=2)+'\n')
d=P/'source';d.mkdir(exist_ok=True)
for n in sources:
 f=d/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((R/n).read_bytes())
subprocess.run(['git','add','--',*sources],cwd=R,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
print('Fifteen source/spec/catalog/report files frozen and staged')
