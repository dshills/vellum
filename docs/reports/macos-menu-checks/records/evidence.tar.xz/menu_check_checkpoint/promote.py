from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-large-data');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-macos-menu-checks');O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-menu-checks')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
q=json.loads((R/'docs/reports/macos-menu-checks/records/qualification.json').read_text());assert q['result']=='REVIEWED_MENU_CHECK_ACTIONS_AND_SEPARATORS'and q['prism_coverage_complete']and q['internal_review']=='APPROVED_SOURCE_AND_EVIDENCE'and not q['live_checks_run']and not q['prepared_changed'];base=q['base_commit']
assert not git(R,'status','--porcelain')and not git(C,'status','--porcelain')and git(C,'rev-parse','HEAD')==base
commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert all(expected.get(n)==h for n,h in q['sources'].items())
reference=json.loads((P/'prepared-baseline.json').read_text());assert len(reference)==6207 and prepared(C)==prepared(R)==reference
O.mkdir(exist_ok=False,parents=True);start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'tracked_files':len(expected),'scope':'Controlled menu boolean actions/passive separators, validation/focus/popup revocation, checked paint/AX/manual values, gallery and contracts. Fifteen-file internal+Anthropic review; code/offscreen race/vet/nativeharness/build checks. No native windows/live/VoiceOver/performance/fullMac qualification; all6207preparedleavesunchanged.'}
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 canonical_names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_exact':set(canonical_names)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_exact':prepared(C)==reference,'prepared_files':len(prepared(C)),'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'archive_sha256':sha(C/'docs/reports/macos-menu-checks/records/evidence.tar.xz')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean'])and record['archive_sha256']==q['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');(O/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
