from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-menu-checks');D=R/'docs/reports/macos-menu-checks/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==0 and process['error']is None and process['source_index_stable'];assert review['coverage']['complete']and review['coverage']['files']==15 and not review['findings'];assert review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert len(sources)==15 and all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not internal['unresolved_findings']and internal['sources']==sources
summary=json.loads((P/'final-summary.json').read_text());assert summary['result']=='PASS_SCOPED_MENU_CHECK_ACTIONS'and not summary['live_checks_run']and summary['negative_controls']==2
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.m','.log','.md','.png'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['menu_check_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Controlled menu check actions/separators: exact source/spec/catalog, software checked/unchecked captures, producers, tests, two faulty regression overlays, final source-bound checks and internal/Anthropic reviews. Gallery binary excluded with hash retained; prepared bytes unchanged. No live or VoiceOver/performance/full Mac qualification.'},indent=2)+'\n')
q={'result':'REVIEWED_MENU_CHECK_ACTIONS_AND_SEPARATORS','base_commit':summary['base_commit'],'sources':sources,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':0,'prism_coverage_complete':True,'prism_files':15,'prism_provider_calls':review['coverage']['llmCalls'],'prism_reported_findings':0,'prism_unresolved_findings':0,'prepared_files':6207,'prepared_changed':False,'negative_controls':2,'gallery_build_sha256':summary['gallery_build_sha256'],'gallery_binary_launched':False,'live_checks_run':False,'native_performance_qualified':False,'fresh_endurance_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
