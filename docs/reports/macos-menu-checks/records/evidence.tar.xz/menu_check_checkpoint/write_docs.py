from pathlib import Path
R=Path('/private/tmp/vellum-large-data')
f=R/'specs/menu-button.md';s=f.read_text().replace('contains 1..64 actions with unique nonempty UTF-8 IDs','contains 1..64 entries with unique nonempty UTF-8 IDs').replace('and\nnonblank UTF-8 labels (at most 4096 bytes); NUL is refused.','and\nnonblank action labels (at most 4096 UTF-8 bytes); NUL is refused.').replace('action using its stable ID; the current Change callback runs on the application','action using its stable ID; check actions also propose Change.Checked. The current Change callback runs on the application').replace('handler or entirely disabled options','handler or no enabled action options').replace('This control supplies a flat in-window action list. Nested menus, separators,\ncheckbox/radio actions and command shortcuts are future API work.','''`Option.Checkable` adds a controlled boolean action. `Checked` is its accepted
state; ordinary actions require Checked=false. Choosing a check action closes
the popup and submits the inverse accepted state in Change.Checked, without
optimistic mutation. The callback may accept, reject or normalize it. Reopening
uses the current descriptor and displays a checkmark only for Checked=true.
Descriptor check-state changes revoke the old menu epoch and queued requests.

`Option.Separator` adds a passive native line. It has its own stable ID, empty
Label and false Disabled/Checkable/Checked fields. It counts toward the 64-entry
bound. Separators have no focus, action, accessible child or manual input target.
Keyboard navigation skips them and disabled actions. A menu containing only
separators/disabled actions remains readable but is unavailable to input/focus.
The separator/check flags are refused on all other kinds' Options.

Check actions publish AXMenuItem with an accepted boolean accessibilityValue
and Checked/Unchecked accessibilityValueDescription. Ordinary menu actions have
no boolean value/description. Inert production Cocoa selector tests verify that
mapping without native attachments/windows; human VoiceOver remains separate.
See [Apple's accessibility value contract](https://developer.apple.com/documentation/appkit/nsaccessibilityprotocol).

This control supplies a flat in-window action list. Nested menus,
radio action groups and command shortcuts are future API work.''')
f.write_text(s)
f=R/'docs/controls.md';s=f.read_text().replace('Use `ui.MenuButton` for a flat list of transient actions.','Use `ui.MenuButton` for a flat list of transient actions, controlled check actions\nand passive separators.')
s+='''

Checkable menu actions receive a proposed boolean along with their stable ID.
Accept it in the application model; reopening displays the accepted checkmark:

```go
ui.Node{ID: "view-options", Kind: ui.MenuButton, Text: "View", Options: []ui.Option{
    {ID: "grid", Label: "Show grid", Checkable: true, Checked: showGrid},
    {ID: "divider", Separator: true},
    {ID: "reset", Label: "Reset view"},
}, Change: func(e ui.ChangeEvent) {
    if e.SelectedID == "grid" { showGrid = e.Checked }
    if e.SelectedID == "reset" { resetView() }
}}
```

The application owns showGrid and resetView. Separator entries require a unique
ID and no other fields. They count toward the 64-entry menu limit but add no
keyboard/accessibility/input target. Checkable/Checked/Separator fields apply only
to MenuButton Options. The gallery's Icons and actions page includes View options.
The [check-action checkpoint](reports/macos-menu-checks/README.md) records the
software routing, visual and inert Cocoa checks; physical input and human
VoiceOver remain separate acceptance work.
''';f.write_text(s)
f=R/'specs/controls.md';s=f.read_text();s+='''

MenuButton Options also support controlled `Checkable`/`Checked` actions and
passive `Separator` entries. Change.Checked proposes the inverse accepted check
state. Ordinary actions only identify their action, and separators have no input
or focus. Other kinds refuse these fields. Full lifetime, bounds and semantics
are specified by the [action-menu contract](menu-button.md).
''';f.write_text(s)
f=R/'ui/controls.go';s=f.read_text().replace('// for Selector/Tabs/RadioGroup/SegmentedControl. SplitPane uses Number for the','// for Selector/Tabs/RadioGroup/SegmentedControl/MenuButton. MenuButton check actions\n// also use Checked for the proposed boolean. SplitPane uses Number for the');f.write_text(s)
f=R/'specs/macos-completion.md';s=f.read_text();s+='''

The [menu check-action checkpoint](../docs/reports/macos-menu-checks/README.md)
adds controlled boolean menu actions and passive separators to the desktop
control catalog. Offscreen real-popup pointer/keyboard, rejected/stale proposal,
visual and inert Cocoa selector checks qualify the tested source behavior.
Internal review and the selected Anthropic Prism checkpoint remain required.
Human screen-reader, physical menu/input and full Mac acceptance remain open;
live tests remain paused while the human uses the machine.
''';f.write_text(s)
d=R/'docs/reports/macos-menu-checks';d.mkdir(exist_ok=False);(d/'records').mkdir()
(d/'README.md').write_text('''# Controlled menu check actions and separators

MenuButton Options now add Checkable/Checked boolean actions and passive
Separator entries. Application-owned Checked is accepted state; choosing an
action submits the inverse state through Change.Checked and closes the popup.
The application can accept, reject or normalize the proposal. Reopening derives
its marker from accepted state. Descriptor/value changes revoke queued requests
through the existing popup epoch and originating-window retirement.

Separators retain unique descriptor IDs, count toward the 64-entry bound, and
render with the existing native separator widget. They have no label, focus,
action callback, accessible child or manual input target. All-separator or
otherwise passive menus cannot enter focus/action input. Other control kinds
refuse the new metadata. Ordinary action-menu behavior remains unchanged.

The managed popup shows a bundled checkmark for accepted true. Its AXMenuItem
publishes an accepted boolean value with Checked/Unchecked value description.
An inert fixture invokes production Cocoa selectors on unattached elements;
it creates no OS window, successful action dispatch or native attachment.
[Apple's accessibility protocol](https://developer.apple.com/documentation/appkit/nsaccessibilityprotocol)
defines these value/description properties. This evidence does not establish
human VoiceOver announcements or physical Mac menu behavior.

## Scoped qualification

Portable validation checks false/true states, malformed separator combinations,
empty/duplicate IDs, other-kind metadata refusal and passive focus exclusion.
An actual manual-backend popup routes keyboard and pointer check actions, skips
separator/disabled entries, preserves rejected accepted values, renders both
check states, and refuses stale queued proposals after descriptor value changes.
Existing flat-menu lifetime, peer-window drain/wake and ordinary action tests
remain in the targeted suite. Software captures were inspected: literal labels,
separator line, disabled checked action and accepted marker render correctly.
Two intentionally broken overlays fail exact proposal/separator assertions.

Final portable/adapter race tests, vet, native tagged build and gallery tests
must pass. Prepared dependencies retain all 6,207 baseline bytes. The new controls
are demonstrated on the gallery's Icons and actions page. The significant
source/spec/report checkpoint requires internal review and Prism using Anthropic
Claude Sonnet 5.5 before commit; indexed evidence preserves producers, captures,
all receipts, negative controls and reviews. Native binaries are built only.

Live tests remain paused while the human uses the computer. Physical input/menu,
human screen-reader, cross-display placement and complete Mac qualification
remain open. Full P6/P11 and current interacting lifecycle acceptance remain open;
this control expansion does not qualify a frame-rate or memory target.
''')
print('Menu specs/catalog/gallery contract and scoped report updated')
