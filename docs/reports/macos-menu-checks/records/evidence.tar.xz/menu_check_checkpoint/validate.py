from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-menu-checks')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
cp=json.loads((P/'checkpoint-source.json').read_text());assert cp['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='4ddf0783eb9144f6034efb282fb2a8d1a002f557';assert len(cp['sources'])==15 and all(sha(R/n)==h for n,h in cp['sources'].items())
prepared=json.loads((P/'menu-routing.json').read_text())['prepared_before'];actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert len(prepared)==6207 and prepared==actual
checks={}
passing=['menu-portable','menu-routing','menu-visual','final-portable-race','final-adapter-race','final-adapter-vet','final-portable-vet','final-gallery-build','final-native-contracts']
faults={'menu-faulty-proposal':'check proposal not accepted once','menu-faulty-separator':'separator admitted a request'}
for name in passing+list(faults):
 j=json.loads((P/(name+'.json')).read_text());assert j['exit_code']==(1 if name in faults else 0)and j['error']is None and not j['live_tests']and not j['headless_gpu_requested']
 assert j['source_commit']==cp['base_commit']and j['source_delta_stable']and j['producer_sha256']==sha(P/'code_run.py')and j['prepared_before']==j['prepared_after']==prepared and j['overlay_inputs_before']==j['overlay_inputs_after']
 for n,h in j['overlay_inputs_after'].items():assert sha(n)==h
 for channel in ['stdout','stderr']:assert j[channel+'_sha256']==sha(P/(name+'.'+channel))
 if name.startswith('final-'):
  assert all(j['source_delta_after'].get(n)==h for n,h in cp['sources'].items())
 if name in faults:assert faults[name]in(P/(name+'.stdout')).read_text()
 checks[name]={'exit_code':j['exit_code'],'elapsed_seconds':j['elapsed_seconds'],'receipt_sha256':sha(P/(name+'.json')),'argv':j['argv']}
assert sha(P/'unchecked.png')!=sha(P/'checked.png')
summary={'result':'PASS_SCOPED_MENU_CHECK_ACTIONS','base_commit':cp['base_commit'],'sources':cp['sources'],'checks':checks,'prepared_files':6207,'prepared_changed':False,'negative_controls':2,'visual_capture_sha256':{n:sha(P/n)for n in ['unchecked.png','checked.png']},'gallery_build_sha256':sha(P/'gallery'),'gallery_binary_launched':False,'live_checks_run':False,'live_testing_paused':True,'physical_input_qualified':False,'human_voiceover_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'native_performance_qualified':False,'producer_sha256':sha(__file__)}
with(P/'final-summary.json').open('x')as f:f.write(json.dumps(summary,indent=2)+'\n')
(P/'prepared-baseline.json').write_text(json.dumps(prepared,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['sources','checks']},indent=2))
