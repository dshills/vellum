from pathlib import Path
import datetime,hashlib,importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('tree_build_base',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
plan=json.loads((W/'implementation-scope.json').read_text());sdk=Path(plan['sdk']);name,kind=sys.argv[1:];h.need(kind in ['virtual','root','driver','driver-all','vet','native-build','native-diag'],'known command')
shutil.copytree(W/'candidate',W/'source-versions'/name)
paths=list((W/'candidate').rglob('*.go'))+[W/'overlay.json',W/'diagnostic-overlay.json',W/'diagnostic-perf.go',Path(__file__)];pins={str(p):h.sha(p)for p in paths}
if kind=='root':args=['test','-race','-count=1','-overlay='+str(W/'overlay.json'),'./...'];cwd=sdk
elif kind=='virtual':args=['test','-race','-count=1','-overlay='+str(W/'overlay.json'),'./virtual'];cwd=sdk
elif kind=='driver-all':args=['test','-race','-count=1','-p=1','-overlay='+str(W/'overlay.json'),'-tags=offscreen','.'];cwd=sdk/'drivers/cogent'
elif kind=='driver':args=['test','-race','-count=1','-p=1','-overlay='+str(W/'overlay.json'),'-tags=offscreen','-run','^(TestTreeRetained|TestManagedTree)','.' ];cwd=sdk/'drivers/cogent'
elif kind=='vet':args=['vet','-overlay='+str(W/'overlay.json'),'-tags=offscreen','./...'];cwd=sdk/'drivers/cogent'
elif kind=='native-diag':args=['build','-p=1','-trimpath','-overlay='+str(W/'diagnostic-overlay.json'),'-o',str(W/'tree-diagnostic'),'.'];cwd=sdk/'examples/loadedtree'
else:args=['build','-p=1','-trimpath','-overlay='+str(W/'overlay.json'),'-o',str(W/'tree-candidate'),'.'];cwd=sdk/'examples/loadedtree'
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','LANG':os.environ.get('LANG','en_US.UTF-8')}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args]
r=h.g.execute(av,cwd,W/name,lambda:(W/'stop-headless').exists(),lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=600,limit=8<<20);r['source_pins']=pins;r['native_ui_executed']=False;(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent'] else 1)
