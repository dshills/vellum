from pathlib import Path
import hashlib,json,sys
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return run_child(['git',*args],cwd=T,capture_output=True,check=True,timeout=30).stdout
mode=sys.argv[1]
if mode=='stage':
 assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()=='e154763b7083d23d0c7b09e2433baa65da5fa9b6'
 assert (W/'stop-native').exists() and json.loads((W/'assessment.json').read_text())['result']=='REJECT_PRIVATE_OVERLAY'
 assert not(W/'review-source-backup.json').exists();backup={};sources={}
 for f in (W/'candidate').rglob('*.go'):
  name=f.relative_to(W/'candidate').as_posix();target=T/name
  if target.exists():
   assert target.read_bytes()==(C/name).read_bytes();copy=W/'review-base'/name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(target.read_bytes());backup[name]={'stored':str(copy),'sha256':sha(copy)}
  else:backup[name]=None
  sources[name]=sha(f)
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
 for f in (W/'final-docs').rglob('*'):
  if f.is_file():target=T/f.relative_to(W/'final-docs');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
 (W/'review-source-backup.json').write_text(json.dumps({'base':'e154763b7083d23d0c7b09e2433baa65da5fa9b6','backup':backup,'candidate':sources},indent=2)+'\n')
 git('add','--',*sources,'docs/reports/macos-tree-local-layout/README.md','specs/macos-delivery.md','specs/macos-completion.md')
 diff=git('diff','--cached','--binary');(W/'prism-staged.diff').write_bytes(diff);print(json.dumps({'bytes':len(diff),'paths':git('diff','--cached','--name-only').decode().splitlines()}))
elif mode=='restore':
 b=json.loads((W/'review-source-backup.json').read_text())
 for name,original in b['backup'].items():
  target=T/name;assert sha(target)==b['candidate'][name],name
  if original is None:target.unlink()
  else:
   copy=Path(original['stored']);assert sha(copy)==original['sha256'];target.write_bytes(copy.read_bytes())
 git('add','-A','--',*b['backup'])
 assert all(n.startswith(('docs/','specs/'))for n in git('diff','--cached','--name-only').decode().splitlines())
 assert not git('diff','--name-only');print(json.dumps({'restored_source_paths':len(b['backup']),'only_docs_staged':True}))
else:raise ValueError('known stage')
