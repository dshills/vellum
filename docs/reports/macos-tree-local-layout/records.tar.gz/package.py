from pathlib import Path
import datetime,hashlib,json,shutil,sys,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-tree-local-layout'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((W/'native-plan.json').read_text());a=json.loads((W/'assessment.json').read_text());assert a['result']=='REJECT_PRIVATE_OVERLAY' and (W/'stop-native').exists()
prism=json.loads((W/'prism.json').read_text());assert prism['coverage']['complete'] and prism['coverage']['llmCalls']==1
assert json.loads((W/'internal-results-review.json').read_text())['approved'];assert json.loads((W/'internal-prism-closure.json').read_text())['approved']
disp=json.loads((W/'prism-disposition.json').read_text());assert sorted(disp['addressed_or_disposed'])==sorted(x['id']for x in prism['findings'])
source=json.loads((W/'review-source-backup.json').read_text())
for name,original in source['backup'].items():
 target=T/name
 assert (not target.exists()) if original is None else sha(target)==original['sha256']
diff=run_child(['git','diff','--cached','--binary'],cwd=T,capture_output=True,check=True,timeout=30).stdout;(W/'final-docs.diff').write_bytes(diff)
names=run_child(['git','diff','--cached','--name-only'],cwd=T,capture_output=True,check=True,timeout=30).stdout.decode().splitlines();assert all(n.startswith(('docs/','specs/'))for n in names)
shared=W/'shared';shared.mkdir();mapping={}
for i,(source,digest)in enumerate(sorted(p['pins'].items())):
 src=Path(source);assert sha(src)==digest;name=f'{i:02d}-'+src.name;shutil.copyfile(src,shared/name);mapping[source]={'stored':name,'sha256':digest}
sdk=Path(p['sdk']);shutil.copyfile(sdk/'SDK_MANIFEST.json',shared/'sdk-manifest.json');assert sha(shared/'sdk-manifest.json')==p['sdk_files']['SDK_MANIFEST.json'];(shared/'sources.json').write_text(json.dumps(mapping,indent=2)+'\n')
checks={'scope':'Rejected private tree retention/local-layout experiment; docs/evidence only','base':p['calling_head'],'sdk_source':p['sdk_source'],'native_runs':22,'ordinary_runs':20,'ordinary_samples':4800,'diagnostic_runs':2,'diagnostic_samples':240,'warmup_per_run':128,'prism_calls':1,'prism_raw_exit_code':json.loads((W/'prism-command.json').read_text())['exit_code'],'prism_findings':[x['id']for x in prism['findings']],'source_restored':True,'runtime_changed':False,'sdk_changed':False,'prepared_changed':False,'closed_mac_gates':[],'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for leaf in sorted(W.rglob('*')):
 assert not leaf.is_symlink(),leaf
 if not leaf.is_file() or '__pycache__'in leaf.parts or 'final-docs'in leaf.parts or leaf.name.startswith('stop-')or leaf.name in ['tree-candidate','tree-diagnostic','report-draft.md']:continue
 assert leaf.stat().st_size<8<<20,(leaf,leaf.stat().st_size);name=leaf.relative_to(W).as_posix();files[name]={'bytes':leaf.stat().st_size,'sha256':sha(leaf)};sources[name]=leaf
assert len(files)<400 and sum(x['bytes']for x in files.values())<64<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<10<<20;record={'archive':archive.name,'archive_sha256':sha(archive),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
