from pathlib import Path
import hashlib,json,sys,time
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
args=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','65000','--max-diff-bytes','70000','--rules',str(W/'prism-rules.json'),'--format','json','--out',str(W/'prism.json')]
diff=run_child(['git','diff','--cached','--binary'],cwd=T,capture_output=True,check=True,timeout=30).stdout
assert diff==(W/'prism-staged.diff').read_bytes() and len(diff)<65000
review=json.loads((W/'internal-results-review.json').read_text());assert review['approved']
started=time.monotonic()
with (W/'prism.stdout').open('xb')as out,(W/'prism.stderr').open('xb')as err:r=run_child(args,cwd=T,timeout=300,stdout=out,stderr=err,log_limit_bytes=2<<20)
d={'argv':args,'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'staged_diff_bytes':len(diff),'exit_code':r.returncode,'seconds':time.monotonic()-started};(W/'prism-command.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
