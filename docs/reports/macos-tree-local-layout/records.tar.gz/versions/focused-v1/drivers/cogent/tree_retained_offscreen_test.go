//go:build offscreen

package cogent

import (
	"bytes"
	"errors"
	"fmt"
	"reflect"
	"testing"

	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/tree"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
)

func TestTreeRetainedLocalMatchesFullLayout(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 162, 192} {
		t.Run(fmt.Sprint(dpi), func(t *testing.T) {
			model := nativeOutline(t, 10000, true)
			config := manualConfig(t, 7)
			config.LogicalDPI = dpi
			m, a := gridManual(t, config, func() ui.Node { return ui.Node{ID: "outline", Kind: ui.DataTree, Tree: model, Grow: true} })
			unitSettle(t, m)
			binding := m.implementation.find("one").state.root.control.outline
			var probe *gridLayoutProbe
			if e := a.Do(func() {
				probe = tree.New[gridLayoutProbe](m.implementation.find("one").state.body)
				probe.SetText("unrelated layout")
				probe.Styler(func(s *styles.Style) { s.Min.Y = units.Dp(20); s.Grow.SetZero() })
				binding.host.Update()
				v, _ := model.State()
				v.Viewport.ScrollY = 72
				_ = model.SetViewport(v.Viewport)
				_ = a.Invalidate("one")
			}); e != nil {
				t.Fatal(e)
			}
			unitSettle(t, m)
			localSeen := false
			for _, dy := range []int{24, 24, -24, 1, 12, -12, 23} {
				keys := map[string]*outlineNativeRow{}
				refs := map[string]virtual.OutlineRef{}
				before := uint64(0)
				if e := a.Do(func() {
					for _, r := range binding.rows {
						keys[r.row.ID] = r
						refs[r.row.ID] = r.row.Ref
					}
					before = binding.localLayouts
					probe.sizeUps = 0
					s, _ := model.State()
					s.Viewport.ScrollY += dy
					if e := model.SetViewport(s.Viewport); e != nil {
						t.Error(e)
					}
					if e := syncTree(binding.r); e != nil {
						t.Error(e)
					}
					if _, e := InspectTree(a, model); !errors.Is(e, ErrTreeLayout) {
						t.Error("old geometry escaped local pending fence", e)
					}
					for _, r := range binding.rows {
						if old := keys[r.row.ID]; old != nil {
							if old != r {
								t.Error("overlapping key lost widget")
							}
							if _, e := model.Row(refs[r.row.ID]); !errors.Is(e, virtual.ErrTreeStale) {
								t.Error("stale generation remains input authority", e)
							}
						}
						if _, e := model.Row(r.row.Ref); e != nil {
							t.Error("current row reference not refreshed", e)
						}
					}
				}); e != nil {
					t.Fatal(e)
				}
				unitSettle(t, m)
				actual, e := m.Capture(testContext, "one")
				if e != nil {
					t.Fatal(e)
				}
				measured := treeInspection(t, a, model)
				if binding.localLayouts > before {
					localSeen = true
					if probe.sizeUps != 0 {
						t.Error("local scroll laid out unrelated sibling")
					}
				}
				if e = a.Do(func() { binding.host.Update() }); e != nil {
					t.Fatal(e)
				}
				unitSettle(t, m)
				full, e := m.Capture(testContext, "one")
				if e != nil {
					t.Fatal(e)
				}
				oracle := treeInspection(t, a, model)
				measured.Frames, oracle.Frames = 0, 0
				measured.LocalLayouts, oracle.LocalLayouts = 0, 0
				if actual.Bounds() != full.Bounds() || !bytes.Equal(actual.Pix, full.Pix) {
					t.Fatalf("scroll%d local/full pixels differ", dy)
				}
				if !reflect.DeepEqual(measured, oracle) {
					t.Fatalf("scroll%d local/full geometry/semantics differ", dy)
				}
				if probe.sizeUps == 0 {
					t.Fatal("full oracle did not exercise global layout")
				}
			}
			if !localSeen {
				t.Fatal("fixture never exercised local path")
			}
		})
	}
}
func TestTreeRetainedIndexPendingSelectionAndStyleFallback(t *testing.T) {
	model := nativeOutline(t, 200, true)
	disabled := false
	help := "initial"
	m, a := gridManual(t, manualConfig(t, 7), func() ui.Node {
		return ui.Node{ID: "outline", Kind: ui.DataTree, Tree: model, Grow: true, Disabled: disabled, Accessibility: ui.Accessibility{Help: help}}
	})
	unitSettle(t, m)
	binding := m.implementation.find("one").state.root.control.outline
	if e := a.Do(func() {
		old := binding.projection
		next := old
		next.State.Viewport.ScrollY += 24
		next.State.Generation++
		if !binding.canLayoutLocally(next) {
			t.Error("ready viewport-only proposal refused")
		}
		for name, mutate := range map[string]func(*virtual.OutlineSnapshot){
			"zero-index": func(s *virtual.OutlineSnapshot) { s.IndexIdentity = virtual.TreeIndexIdentity{} },
			"pending":    func(s *virtual.OutlineSnapshot) { s.State.Pending = true },
			"selection":  func(s *virtual.OutlineSnapshot) { s.State.Selected = "node-2" },
			"width":      func(s *virtual.OutlineSnapshot) { s.State.Viewport.Width++ },
			"rowheight":  func(s *virtual.OutlineSnapshot) { s.State.Config.RowHeight++ },
		} {
			candidate := next
			mutate(&candidate)
			if binding.canLayoutLocally(candidate) {
				t.Error("unsafe proposal admitted", name)
			}
		}
		request, e := model.Prepare(virtual.OutlineChange{Kind: virtual.OutlineKeep})
		if e != nil {
			t.Error(e)
			return
		}
		if e = model.Cancel(request); e != nil {
			t.Error(e)
		}
		binding.r.node.Accessibility.Help = "changed"
		if binding.canLayoutLocally(next) {
			t.Error("changed descriptor style/help admitted")
		}
		binding.r.node.Accessibility.Help = help
		binding.host.Scene.SetProperty(treeFullLayoutProperty, true)
		if binding.canLayoutLocally(next) {
			t.Error("forced full route admitted")
		}
		binding.host.Scene.SetProperty(treeFullLayoutProperty, false)
	}); e != nil {
		t.Fatal(e)
	}
}
