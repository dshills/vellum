"""Reviewed owned executor; scoped tree prototype diagnostics and paired adoption."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
B=W.parent/'macos-tree-boundary-d47e166'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('tree_boundary',B/'run.py');h=b.h;g=b.g;v=b.v
HEAD='e154763b7083d23d0c7b09e2433baa65da5fa9b6'
def clean():
 for root in [h.C,h.T]:h.need(h.git(root,'rev-parse','HEAD').decode().strip()==HEAD and not h.git(root,'status','--porcelain'),'clean exact checkout')
def cases():
 out={}
 for mode in ['cpu','gpu']:
  out[mode+'-diagnostic']={'gpu':mode=='gpu','diagnostic':True,'candidate':True,'samples':120,'nodes':100000,'warmup':128}
 for mode in ['cpu','gpu']:
  for pair in range(1,6):
   for candidate in ([False,True] if pair%2 else [True,False]):
    out[f'{mode}-pair{pair}-'+('candidate' if candidate else 'original')]={'gpu':mode=='gpu','diagnostic':False,'candidate':candidate,'samples':240,'nodes':100000,'warmup':128,'pair':pair}
 return out
CASES=cases()
PREREQUISITES=['driver-v6','root-v1','driver-all-v1','vet-v1','native-build-v1','native-diag-v1']
def prepare():
 h.need(not(W/'native-plan.json').exists(),'fresh native plan');clean()
 q=json.loads((B/'plan.json').read_text());sdk=Path(q['sdk']);h.need(b.vector(sdk)==q['sdk_files'],'unchanged SDK')
 for name in PREREQUISITES:
  r=json.loads((W/(name+'.json')).read_text());h.need(r['exit_code']==0 and r['error']is None and r['logs_complete'] and r['pins_stable'] and r['owned']['group_absent'],'terminal prerequisite '+name)
  checked=list((W/'candidate/virtual').glob('*.go')) if name=='root-v1' else list((W/'candidate').rglob('*.go'))
  h.need(all(r['source_pins'].get(str(f))==h.sha(f) for f in checked),'checked candidate bytes '+name)
 files=list((W/'candidate').rglob('*.go'))+[W/'overlay.json',W/'diagnostic-overlay.json',W/'diagnostic-perf.go',W/'native.py',W/'headless.py',W/'assess.py',W/'implementation-scope.json',*[W/(n+'.json') for n in PREREQUISITES],B/'run.py',B.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py',B/'validate.py',B/'owned-executor.py',h.GUARD,h.T/'scripts/child_process.py',h.T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 binaries={'original':q['binary'],'candidate':{'path':str(W/'tree-candidate'),'sha256':h.sha(W/'tree-candidate')},'diagnostic':{'path':str(W/'tree-diagnostic'),'sha256':h.sha(W/'tree-diagnostic')}}
 scope=json.loads((W/'implementation-scope.json').read_text());h.need(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(scope['reassess_by_utc']),'prototype deadline')
 p={'calling_head':HEAD,'reassess_by_utc':scope['reassess_by_utc'],'sdk_source':h.HEAD,'sdk':str(sdk),'sdk_files':q['sdk_files'],'pins':{str(p):h.sha(p) for p in files},'tail_guard':'Each mode median run-p99 must not increase and count of p99>6ms runs must not increase. Report maxima without pooling. Retention guard: every run remains <=500 materialized/retained rows; candidate median post-GC terminal Go HeapAlloc must not exceed baseline by >1MiB, and no pending private work after completed local passes. These are prototype guards, not M4 closure.','binaries':binaries,'cases':CASES,'scope':'Exactly2candidate diagnostics followed by20ordinary serial interleaved runs. Same unchanged ordinary consumer, Go1.25.6 release build; candidate diagnostic only adds ready local_layouts ordinal. Existing native FIFO scroll routing only; no operator/physical input/preferences. Each run128warm, diagnostics120/ordinary240samples100k-wide68-69clippedrows. Sharedlease/freshstops/watchdog330s/8MiBstreams/groupabsence. Material adoption >=0.4ms lower median run-p95 and>=4/5 improvedpairs each CPU/GPU without tail/correctness/retention regression. All other completion gates remain. No automatic later native campaign.'}
 (W/'native-plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(W/'native-plan.json'),'pins':len(p['pins']),'cases':len(CASES),'native_executed':False}))
def run(name):
 stop=W/('stop-'+name);global_stop=W/'stop-native';plan_raw=(W/'native-plan.json').read_bytes();admission_raw=(W/'native-admission.json').read_bytes();p=json.loads(plan_raw);a=json.loads(admission_raw)
 h.need(a['approved'] and a['plan_sha256']==hashlib.sha256(plan_raw).hexdigest(),'exact reviewed native plan')
 h.need(name in CASES and not stop.exists() and not global_stop.exists() and not(W/(name+'-result.json')).exists(),'fresh scope')
 sdk=Path(p['sdk']);case=CASES[name];key='diagnostic' if case['diagnostic'] else ('candidate' if case['candidate'] else 'original');exe=p['binaries'][key]
 def stable():return (W/'native-plan.json').read_bytes()==plan_raw and (W/'native-admission.json').read_bytes()==admission_raw and all(h.sha(k)==z for k,z in p['pins'].items()) and all(h.sha(x['path'])==x['sha256'] for x in p['binaries'].values())
 def interrupt(signum,frame):raise InterruptedError('native signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupt);d={'case':name,'result':'INCOMPLETE','error':None,'physical_input_generated':False,'full_mac_qualified':False}
 try:
  clean();h.need(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['reassess_by_utc']),'prototype deadline before launch');h.need(stable() and b.vector(sdk)==p['sdk_files'],'native admission inputs')
  for prior in list(CASES)[:list(CASES).index(name)]:
   r=json.loads((W/(prior+'-result.json')).read_text());h.need(r['result']=='PASS_SCOPED_TREE_OBSERVATION' and r['run']['owned']['group_absent'] and (W/('stop-'+prior)).exists(),'sealed successful predecessor')
  args=['-perf','-nodes=100000','-perf-warmup=128',f"-perf-samples={case['samples']}"]+(['-perf-gpu-scene'] if case['gpu'] else [])+(['-perf-source-details'] if case['diagnostic'] else [])
  with g.LiveLease() as lease:
   h.need(lease.held(),'shared lease')
   r=g.execute([exe['path'],*args],sdk/'examples/loadedtree',W/name,lambda:stop.exists() or global_stop.exists(),stable,timeout=330,limit=8<<20);d['run']=r
   h.need(r['created'] and r['exit_code']==0 and r['error']is None and not r['observation_errors'] and r['logs_complete'] and r['pins_stable'] and not r['stop_at_exit'] and r['owned']['terminal'] and r['owned']['group_absent'] and not r['owned']['errors'],'owned terminal native run')
   h.need(not(W/name/'stderr').read_bytes(),'empty native stderr');raw=(W/name/'stdout').read_text();summary=v.validate(raw,case,sdk)
   if case['diagnostic']:
    events=[json.loads(x) for x in raw.splitlines() if x.strip()];count=events[3]['local_layouts'];h.need(type(count)is int and count>0,'positive native local-root use');summary['warm_local_layouts']=count
   clean();h.need(lease.held() and stable() and b.vector(sdk)==p['sdk_files'] and not stop.exists() and not global_stop.exists(),'terminal stable inputs')
   d.update(result='PASS_SCOPED_TREE_OBSERVATION',summary=summary,lease_held_through_cleanup=True)
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});global_stop.touch()
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/(name+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'case':name,'result':d['result'],'error':d['error'],'p95_ns':d.get('summary',{}).get('ui_work_ns',{}).get('p95'),'local_layouts':d.get('summary',{}).get('warm_local_layouts')}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':
 h.need(sys.argv[1:]in [['prepare']]+[['run',n] for n in CASES],'known stage')
 prepare() if sys.argv[1]=='prepare' else run(sys.argv[2])
