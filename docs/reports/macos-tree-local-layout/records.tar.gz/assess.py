from pathlib import Path
import hashlib,json,statistics
W=Path(__file__).resolve().parent
p=json.loads((W/'native-plan.json').read_text());out={'cases':{},'runtime_changed':False,'closed_mac_gates':[]}
def nr(values,percent):
 values=sorted(values);return values[(len(values)*percent+99)//100-1]
def read(name):
 r=json.loads((W/(name+'-result.json')).read_text());assert r['result']=='PASS_SCOPED_TREE_OBSERVATION' and r['run']['owned']['group_absent']
 raw=(W/name/'stdout').read_bytes();events=[json.loads(x)for x in raw.splitlines()if x.strip()];rows=events[4:-1];assert len(rows)==240
 values=[x['frame']['TotalUIWorkNS']for x in rows];s=r['summary'];assert nr(values,95)==s['ui_work_ns']['p95'] and nr(values,99)==s['ui_work_ns']['p99']
 return {'samples':240,'p95_ns':nr(values,95),'p99_ns':nr(values,99),'max_ns':max(values),'alloc_p50_bytes':nr([x['allocation_bytes']for x in rows],50),'malloc_p50':nr([x['mallocs']for x in rows],50),'terminal_heap_bytes':events[-1]['memory']['HeapAlloc'],'phase_geometry':s['phase_geometry'],'log_sha256':hashlib.sha256(raw).hexdigest()}
for mode in ['cpu','gpu']:
 runs={label:[read(f'{mode}-pair{i}-{label}')for i in range(1,6)]for label in ['original','candidate']}
 geometry=all(a['phase_geometry']==b['phase_geometry']for a,b in zip(runs['original'],runs['candidate']));assert geometry
 med={k:statistics.median(x['p95_ns']for x in v)for k,v in runs.items()};tail={k:statistics.median(x['p99_ns']for x in v)for k,v in runs.items()};failed99={k:sum(x['p99_ns']>6000000 for x in v)for k,v in runs.items()};heap={k:statistics.median(x['terminal_heap_bytes']for x in v)for k,v in runs.items()};improved=sum(a['p95_ns']>b['p95_ns']for a,b in zip(runs['original'],runs['candidate']))
 for group in runs.values():
  for x in group:del x['phase_geometry']
 adopted=med['original']-med['candidate']>=400000 and improved>=4 and tail['candidate']<=tail['original'] and failed99['candidate']<=failed99['original'] and heap['candidate']<=heap['original']+(1<<20)
 out['cases'][mode]={'runs':runs,'median_run_p95_ns':med,'median_run_p99_ns':tail,'p99_failed_runs':failed99,'improved_pairs':improved,'median_p95_reduction_ns':med['original']-med['candidate'],'median_terminal_heap_bytes':heap,'geometry_matched':geometry,'adoption_bar_met':adopted,'p95_failed_runs':{k:sum(x['p95_ns']>4000000 for x in v)for k,v in runs.items()},'max_ns':{k:max(x['max_ns']for x in v)for k,v in runs.items()}}
out['adoption_bar_met']=all(x['adoption_bar_met']for x in out['cases'].values());out['result']='ADMIT_FOR_PRODUCTION_CHECKPOINT'if out['adoption_bar_met']else'REJECT_PRIVATE_OVERLAY';out['ordinary_samples_recomputed']=4800;out['scope']='Five240-sampleordinarypairs perCPU/GPU. Nearest-rankperrun, no pooling; original100k-wide68-69clippedrowprototype only. Fulltree/table/generalUI/M4othergatesremain.'
(W/'assessment.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'result':out['result'],'cases':{k:{f:v[f]for f in ['median_run_p95_ns','median_p95_reduction_ns','median_run_p99_ns','improved_pairs','adoption_bar_met']}for k,v in out['cases'].items()}},indent=2))
