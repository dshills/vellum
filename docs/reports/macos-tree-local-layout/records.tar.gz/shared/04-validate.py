"""Pure source-bound validation of routed tree frames; no native execution."""
from pathlib import Path
import hashlib, importlib.util, json, math, statistics
PHASES = ['InputNS', 'OwnerNS', 'ReconcileNS', 'LayoutPaintNS', 'GatherNS', 'RasterUploadNS', 'EncodeSubmitNS']
TIMES = PHASES + ['QueuedNS', 'AcquireNS', 'PresentCallNS', 'TotalUIWorkNS']
def need(value, why):
    if not value:
        raise ValueError(why)
def integer(value, lower=0):
    return type(value) is int and lower <= value < (1 << 63)
def rect(value):
    need(type(value) is dict and set(value) == {'Min', 'Max'}, 'rectangle schema')
    result = tuple(value[p][a] for p in ['Min', 'Max'] for a in ['X', 'Y'])
    need(all(type(x) is int for x in result), 'rectangle integer coordinates')
    return result
def shape(g):
    bounds = rect(g['Bounds'])
    need(bounds[2] > bounds[0] and bounds[3] > bounds[1], 'positive tree bounds')
    need(type(g['Scale']) in [int, float] and math.isfinite(g['Scale']) and g['Scale'] > 0, 'positive finite scale')
    need(all(integer(g[k]) for k in ['ClippedRows', 'MaterializedRows', 'RetainedRows']), 'bounded row counts')
    need(64 <= g['ClippedRows'] <= g['MaterializedRows'] <= 500 and g['RetainedRows'] <= 500, 'nonempty clipped workload and bounded materialization')
    need(all(integer(g['Viewport'][k], 1) for k in ['Width', 'Height']) and integer(g['Viewport']['ScrollY']), 'viewport')
    need(type(g['LayoutSHA256']) is str and len(g['LayoutSHA256']) == 64, 'layout hash')
    return {**{k:g[k] for k in ['Bounds', 'Scale', 'ClippedRows', 'MaterializedRows', 'RetainedRows', 'LayoutSHA256']}, 'Width':g['Viewport']['Width'], 'Height':g['Viewport']['Height']}
def inspected(g, nodes):
    need(g['Window'] == 'perf' and g['ID'] == 'data' and g['Pending'] is False and g['TotalNodes'] == g['VisibleRows'] == nodes, 'completed stored tree')
    need(g['Stamp'] == {'Identity':'tree-perf', 'Revision':1, 'Nodes':nodes} and integer(g['Generation'], 1) and integer(g['Frames'], 1), 'source stamp and generation')
    bounds = rect(g['Bounds']); rectangles=[]; keys=set()
    for row in g['Rows']:
        q=rect(row['Bounds'])
        if q[2] <= q[0] or q[3] <= q[1]:
            continue
        need(row['Key'] not in keys and bounds[0] <= q[0] < q[2] <= bounds[2] and bounds[1] <= q[1] < q[3] <= bounds[3], 'unique contained row')
        keys.add(row['Key']); rectangles.append({'Min':{'X':q[0]-bounds[0], 'Y':q[1]-bounds[1]}, 'Max':{'X':q[2]-bounds[0], 'Y':q[3]-bounds[1]}})
    out={k:g[k] for k in ['Bounds', 'Scale', 'Viewport', 'RetainedRows']}
    out.update(ClippedRows=len(rectangles), MaterializedRows=len(g['Rows']), LayoutSHA256=hashlib.sha256(json.dumps(rectangles,separators=(',',':')).encode()).hexdigest())
    shape(out)
    return out

def load_metrics(sdk):
    spec=importlib.util.spec_from_file_location('current_sdk_metrics',sdk/'scripts/benchmark-grid.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def validate(text, case, sdk):
    metrics=load_metrics(sdk);events=[json.loads(line) for line in text.splitlines() if line.strip()]
    samples=case['samples'];warmup=case['warmup'];nodes=case['nodes'];diagnostic=case['diagnostic'];gpu=case['gpu']
    expected=['tree.perf.setup','tree.perf.geometry','tree.perf.first-scroll','tree.perf.ready']+['tree.perf.sample']*samples+['tree.perf.finished']
    need([x.get('event') for x in events] == expected, 'exact complete tree event order')
    need(all(x['gpu_scene_rendering'] is gpu and x['source_details'] is diagnostic for x in events), 'consistent route and diagnostic request flags')
    setup,geo,first,ready=events[:4];end=events[-1];rows=events[4:-1]
    need(setup['nodes']==nodes and setup['deep'] is False and setup['target_p95_ns']==4_000_000 and setup['go_version']=='go1.25.6', 'exact workload/toolchain/threshold')
    need(setup['build'].get('-race','false')!='true' and setup['build'].get('GOOS')=='darwin' and setup['build'].get('GOARCH')=='arm64', 'ordinary optimized Darwin arm64 build')
    need(setup['font_sha256']==hashlib.sha256((sdk/'drivers/cogent/build/upstream/text/fonts/noto/NotoSans-Regular.ttf').read_bytes()).hexdigest(), 'exact local font bytes')
    initial=geo['initial'];initial_g=inspected(initial,nodes);need(initial['Viewport']['ScrollY']==0,'wide initial offset')
    need(ready['nodes']==nodes and ready['deep'] is False and ready['warmup']==warmup and ready['geometry']==initial_g,'closed warmup geometry')
    first_g=inspected(first['geometry'],nodes)
    need(first['nodes']==nodes and first['deep'] is False and first_g['Viewport']['ScrollY']==12 and shape(first_g)==shape(rows[0]['geometry']), 'first-scroll geometry')
    def frame(f,tag):
        need(f['Tag']==tag and f['Window']=='perf' and f['Generation']==initial['Generation']+tag and f['Completed'] is True and f['Failure']=='', 'ordered completed frame ticket')
        need(all(integer(f[k]) for k in TIMES) and f['TotalUIWorkNS']>0 and f['TotalUIWorkNS']==sum(f[k] for k in PHASES), 'nonnegative integer phase accounting')
        if diagnostic:
            metrics.validate_source_details(f['SourceDetails'],f['RasterUploadNS'])
        else:
            need('SourceDetails' not in f, 'no diagnostic clocks in ordinary frame')
    frame(first['frame'],1);offset=0;layouts={};source_records=[]
    for i,row in enumerate(rows):
        offset+=12 if i%32<16 else -12
        need(row['nodes']==nodes and row['deep'] is False and row['index']==i and row['phase']==i%32 and row['tree_notifications']==1,'one callback per ordered measured input')
        frame(row['frame'],warmup+3+i);g=row['geometry'];current=shape(g)
        need(g['Viewport']['ScrollY']==offset and g['Bounds']==initial_g['Bounds'] and g['Scale']==initial_g['Scale'] and all(g['Viewport'][k]==initial_g['Viewport'][k] for k in ['Width','Height']),'per-event offset and geometry')
        phase=i%32
        need(phase not in layouts or layouts[phase]==current,'repeated phase geometry')
        layouts[phase]=current
        need(all(integer(row[k]) for k in ['allocation_bytes','mallocs','gc_count']),'process allocation counters')
        if diagnostic:
            source_records.extend(row['frame']['SourceDetails']['Records'])
    need(end['nodes']==nodes and end['deep'] is False and end['samples']==samples and end['frame_tickets']==warmup+samples+2 and end['full_p6_qualified'] is False,'terminal recorder counts/scope')
    hosts=[x['SceneHost'] for x in source_records if x['SceneHost']['Available']]
    if diagnostic:
        need(all(any(x['Kind']==1 for x in row['frame']['SourceDetails']['Records']) for row in rows),'main scene source in every diagnostic frame')
        if gpu:
            need(len(hosts)>=samples and all(x['DrawAccepted'] and not x['Fallback'] and not x['Reused'] for x in hosts),'positive fresh GPU route without fallback/reuse')
        else:
            need(not hosts and all(x['RasterAvailable'] and x['CopyAvailable'] for x in source_records if x['Kind']==1),'CPU source route')
    values=[x['frame']['TotalUIWorkNS'] for x in rows];summary={'samples':samples,'nodes':nodes,'deep':False,'diagnostic':diagnostic,'gpu_requested':gpu,'actual_gpu_route_diagnostic_only':bool(hosts),'ui_work_ns':metrics.distribution(values),'phase_ns':{k:metrics.distribution([x['frame'][k] for x in rows]) for k in TIMES if k!='TotalUIWorkNS'},'allocation_bytes':metrics.distribution([x['allocation_bytes'] for x in rows]),'mallocs':metrics.distribution([x['mallocs'] for x in rows]),'clipped_rows_range':[min(x['geometry']['ClippedRows'] for x in rows),max(x['geometry']['ClippedRows'] for x in rows)],'font_sha256':setup['font_sha256'],'phase_geometry':layouts,'ordinary_p95_target_met':None if diagnostic else metrics.distribution(values)['p95']<=4_000_000,'full_tree_qualified':False,'full_p6_qualified':False,'full_mac_qualified':False,'physical_input_qualified':False}
    if diagnostic:
        summary['source_records']=len(source_records);summary['gpu_hosts']=len(hosts);summary['source_ns']={k:metrics.distribution([x[k] for x in source_records]) for k in ['DrawNS','RasterNS','CopyNS']};summary['host_ns']={k:metrics.distribution([x[k] for x in hosts]) for k in metrics.SCENE_HOST_TIMES} if hosts else {};summary['source_image_extents']=sorted({(x['ImageWidth'],x['ImageHeight']) for x in source_records});summary['image_attempts']=sum(x['SetFromGoImageAttempts'] for x in source_records);summary['logical_rgba_bytes']=sum(x['LogicalUploadRGBABytes'] for x in source_records)
    return summary
