"""Four current-SDK tree boundary observations, not a repeated acceptance matrix."""
from pathlib import Path
import datetime, importlib.util, json, signal, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
PRE=W.parent/'macos-sdk-stage0079-abe67c6-cache-v2'
HEAD='d47e1661180a51506b75e35e6ca497feb06bbea7'
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load('tree_sdk_base',PRE/'run.py');g=load('ordinary_tree_executor',W/'owned-executor.py');v=load('tree_validator',W/'validate.py')
CASES={}
for mode,diagnostic in [('ordinary',False),('diagnostic',True)]:
    for gpu in [False,True]:
        name=('gpu' if gpu else 'cpu')+'-'+mode
        count=120 if diagnostic else 240
        CASES[name]={'gpu':gpu,'diagnostic':diagnostic,'nodes':100000,'warmup':128,'samples':count,'args':['-perf','-nodes=100000','-perf-warmup=128',f'-perf-samples={count}']+(['-perf-gpu-scene'] if gpu else [])+(['-perf-source-details'] if diagnostic else [])}
def clean():
    for root in [h.C,h.T]:
        h.need(h.git(root,'rev-parse','HEAD').decode().strip()==HEAD and not h.git(root,'status','--porcelain'),'clean exact calling checkout')
        h.need(all(n.startswith(('docs/','specs/')) for n in h.git(root,'diff','--name-only',h.HEAD,HEAD).decode().splitlines()),'docs-only since SDK source')
def vector(sdk):
    h.need(not any(x.is_symlink() for x in sdk.rglob('*')),'SDK regular files')
    return {x.relative_to(sdk).as_posix():h.sha(x) for x in sdk.rglob('*') if x.is_file()}
def prepare():
    h.need(not(W/'plan.json').exists(),'fresh tree scope');clean()
    q=json.loads((PRE/'consume-plan.json').read_text());sdk=Path(q['sdk']);m=json.loads((sdk/'SDK_MANIFEST.json').read_text());expected={**m['files'],'SDK_MANIFEST.json':q['manifest_sha256']}
    h.need(vector(sdk)==expected,'exact SDK vector');built=json.loads((PRE/'consume-v2-result.json').read_text());h.need(built['result']=='PASS_ALL_LISTED_SDK_MAIN_BUILDS' and built['error'] is None,'terminal SDK compile')
    binaries=built['modules']['examples/loadedtree']['binaries'];h.need(len(binaries)==1,'one tree binary');exe=binaries[0];h.need(exe['go_version']=='go1.25.6' and h.sha(exe['path'])==exe['sha256'],'exact compiled SDK tree binary')
    pins={str(p):h.sha(p) for p in [Path(__file__),W/'validate.py',W/'owned-executor.py',W/'validator-controls.py',W/'validator-controls.json',W/'control-fixture.stdout',PRE/'run.py',PRE/'consume-plan.json',PRE/'consume-v2-result.json',h.GUARD,Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),h.T/'scripts/child_process.py',h.T/'scripts/sdk_environment.py',sdk/'scripts/benchmark-grid.py']}
    p={'source_sdk':h.HEAD,'calling_head':HEAD,'sdk':str(sdk),'sdk_files':expected,'binary':exe,'pins':pins,'cases':CASES,'watchdog_seconds_per_case':330,'environment':'ordinary_environment removes GOMAXPROCS,GOMEMLIMIT,GOFLAGS,GORACE from controlled SDK runtime environment; same policy in both modes. No race/profile/overlay. Directbinary, no network sandbox claim.','scope':'Exactly4sequential runs:2ordinary CPU/GPU100k-wide240samples+128warm each;2separate source-detail diagnostics120samples+128warm each. Functionalcompletion vs p95target separate; ordinary descriptive1processpermode only, not5runrepeat/10k100kwidedeepfulltree/P6/500visible/coldcache/expansionfilter/presentation/physicalinput/nativeGPUmemory/fullMac. Existing native FIFO initialized scroll injection only; no placement operator. Exact SDK/source/binary; no rebuild. Freshstops, sharedlease through ownedgroupabsence, rawlogs8MiBperstream. Stopfailureonfunctional/provenance errors; timingfailures are preserved data. No later campaign automatically admitted.'}
    (W/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(W/'plan.json'),'pins':len(pins),'cases':list(CASES),'native_executed':False}))
def run(name):
    stop=W/('stop-'+name);global_stop=W/'stop-native';h.need(name in CASES and not stop.exists() and not global_stop.exists() and not(W/(name+'-result.json')).exists(),'fresh case scope')
    p=json.loads((W/'plan.json').read_text());a=json.loads((W/'admission.json').read_text());h.need(a['approved'] and a['plan_sha256']==h.sha(W/'plan.json'),'exact reviewed tree plan')
    sdk=Path(p['sdk']);case=p['cases'][name];d={'result':'INCOMPLETE','case':name,'error':None,'source_sdk':p['source_sdk'],'calling_head':HEAD,'physical_input_generated':False,'full_tree_qualified':False,'full_mac_qualified':False}
    def stable():
        return all(h.sha(k)==z for k,z in p['pins'].items()) and h.sha(p['binary']['path'])==p['binary']['sha256'] and vector(sdk)==p['sdk_files']
    def interrupt(signum,frame):
        raise InterruptedError('tree native signal '+str(signum))
    old=signal.signal(signal.SIGTERM,interrupt)
    try:
        clean();h.need(stable(),'tree admission identity')
        for prior in list(CASES)[:list(CASES).index(name)]:
            old_result=json.loads((W/(prior+'-result.json')).read_text());h.need(old_result['result']=='PASS_SCOPED_TREE_FRAME_OBSERVATION' and old_result['run']['owned']['group_absent'] and(W/('stop-'+prior)).exists(),'validated sealed predecessor')
        with g.LiveLease() as lease:
            h.need(lease.held() and stable() and not stop.exists() and not global_stop.exists(),'tree lease')
            r=g.execute([p['binary']['path'],*case['args']],sdk/'examples/loadedtree',W/name,lambda:stop.exists() or global_stop.exists(),stable,timeout=p['watchdog_seconds_per_case'],limit=8<<20);d['run']=r
            h.need(r['created'] and r['exit_code']==0 and r['error'] is None and not r['observation_errors'] and r['logs_complete'] and r['pins_stable'] and not r['stop_at_exit'] and r['owned']['terminal'] and r['owned']['group_absent'] and not r['owned']['errors'],'owned tree completion')
            h.need(not(W/name/'stderr').read_bytes(),'empty tree stderr');summary=v.validate((W/name/'stdout').read_text(),case,sdk)
            clean();h.need(lease.held() and stable() and not stop.exists() and not global_stop.exists(),'tree terminal inputs')
            d.update(result='PASS_SCOPED_TREE_FRAME_OBSERVATION',summary=summary,lease_held_through_cleanup=True)
    except BaseException as e:
        d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});global_stop.touch()
    finally:
        signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/(name+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'case':name,'error':d['error'],'p95_target_met':d.get('summary',{}).get('ordinary_p95_target_met')}),flush=True)
    if d['error']:
        sys.exit(1)
if __name__=='__main__':
    h.need(sys.argv[1:] in [['prepare']]+[['run',n] for n in CASES],'fixed tree phase')
    prepare() if sys.argv[1]=='prepare' else run(sys.argv[2])
