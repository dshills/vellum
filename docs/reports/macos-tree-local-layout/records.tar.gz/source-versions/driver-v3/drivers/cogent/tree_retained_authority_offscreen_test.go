//go:build offscreen

package cogent

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"reflect"
	"testing"

	"cogentcore.org/core/events"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
)

// Unlike the same-host full-layout oracle, this fixture uses the frozen
// pre-prototype visible-index row constructor on an independent owner/model.
func TestTreeRetainedMatchesOriginalConstructor(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 162, 192} {
		t.Run(fmt.Sprint(dpi), func(t *testing.T) {
			models := []*virtual.Outline{nativeOutline(t, 10000, true), nativeOutline(t, 10000, true)}
			var manuals [2]*Manual
			var owners [2]*app.Application
			var bindings [2]*outlineBinding
			for i := range models {
				config := manualConfig(t, 7)
				config.LogicalDPI = dpi
				model := models[i]
				manuals[i], owners[i] = gridManual(t, config, func() ui.Node { return ui.Node{ID: "outline", Kind: ui.DataTree, Tree: model, Grow: true} })
				unitSettle(t, manuals[i])
				bindings[i] = manuals[i].implementation.find("one").state.root.control.outline
			}
			witnessedDifferentConstruction := false
			for _, scroll := range []int{72, 96, 120, 97, 98, 121, 500, 0} {
				var oldSlot *outlineNativeRow
				oldKey := ""
				if err := owners[1].Do(func() { oldSlot = bindings[1].rows[1]; oldKey = oldSlot.row.ID }); err != nil {
					t.Fatal(err)
				}
				for i, model := range models {
					if err := owners[i].Do(func() {
						s, _ := model.State()
						s.Viewport.ScrollY = scroll
						if err := model.SetViewport(s.Viewport); err != nil {
							t.Error(err)
							return
						}
						var err error
						if i == 0 {
							err = syncTree(bindings[i].r)
						} else {
							err = frozenOriginalSyncTree(bindings[i].r)
						}
						if err != nil {
							t.Error(err)
						}
					}); err != nil {
						t.Fatal(err)
					}
					unitSettle(t, manuals[i])
				}
				if bindings[1].rows[1] != oldSlot {
					t.Fatal("frozen oracle did not retain visible-index slot")
				}
				if oldKey != bindings[1].rows[1].row.ID {
					witnessedDifferentConstruction = true
				}
				actual, err := manuals[0].Capture(testContext, "one")
				if err != nil {
					t.Fatal(err)
				}
				original, err := manuals[1].Capture(testContext, "one")
				if err != nil {
					t.Fatal(err)
				}
				if actual.Bounds() != original.Bounds() || !bytes.Equal(actual.Pix, original.Pix) {
					t.Fatalf("scroll%d candidate/original pixels differ", scroll)
				}
				a, b := treeInspection(t, owners[0], models[0]), treeInspection(t, owners[1], models[1])
				a.Incarnation, b.Incarnation = 0, 0
				a.RowIncarnation, b.RowIncarnation = 0, 0
				a.Frames, b.Frames = 0, 0
				a.LocalLayouts, b.LocalLayouts = 0, 0
				if !reflect.DeepEqual(a, b) {
					t.Fatalf("scroll%d independent geometry/semantics differ\n%+v\n%+v", scroll, a, b)
				}
			}
			if !witnessedDifferentConstruction {
				t.Fatal("oracle never reassigned a visible-index row")
			}
		})
	}
}

func TestTreeRetainedCoalescedScrollRevokesAndRestoresAuthority(t *testing.T) {
	for _, action := range []string{"accessibility", "pointer"} {
		t.Run(action, func(t *testing.T) {
			model := nativeOutline(t, 10000, true)
			selections := 0
			config := manualConfig(t, 7)
			config.LogicalDPI = 162
			m, a := gridManual(t, config, func() ui.Node {
				return ui.Node{ID: "outline", Kind: ui.DataTree, Tree: model, Grow: true, TreeChange: func(e ui.TreeEvent) {
					if e.Reason == ui.TreeSelection {
						selections++
					}
				}}
			})
			unitSettle(t, m)
			binding := m.implementation.find("one").state.root.control.outline
			if err := a.Do(func() {
				s, _ := model.State()
				s.Viewport.ScrollY = 72
				_ = model.SetViewport(s.Viewport)
				_ = syncTree(binding.r)
			}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			before := treeInspection(t, a, model)
			point := before.Rows[2].Bounds.Min.Add(image.Pt(30, 2))
			if err := treeInput(t, m, ManualInput{Window: "one", Type: events.MouseDown, Button: events.Left, Position: point}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			bridge := &accessibilityBridge{}
			var stale accessibilityHandler
			if err := a.Do(func() {
				nodes, handlers := accessibilitySnapshot(binding.r, nil)
				ready, actions := bridge.prepareGridPublication(nodes, handlers)
				for _, n := range ready {
					if n.Role == "tree-row" {
						stale = actions[n.ID]
						break
					}
				}
				if stale == nil {
					t.Fatal("missing completed action")
				}
				for range 2 {
					s, _ := model.State()
					s.Viewport.ScrollY += 24
					if err := model.SetViewport(s.Viewport); err != nil {
						t.Fatal(err)
					}
					if err := syncTree(binding.r); err != nil {
						t.Fatal(err)
					}
					if _, err := InspectTree(a, model); !errors.Is(err, ErrTreeLayout) {
						t.Fatal("coalesced geometry escaped pending fence", err)
					}
					if stale(accessibilityAction{Kind: "press"}) {
						t.Fatal("stale AX action accepted during pending scroll")
					}
				}
			}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			after := treeInspection(t, a, model)
			if after.LocalLayouts <= before.LocalLayouts {
				t.Fatal("coalesced scroll never used local layout")
			}
			if binding.layoutPending.Load() || len(binding.layoutDirty) != 0 {
				t.Fatal("completed layout retained pending text work")
			}
			if err := treeInput(t, m, ManualInput{Window: "one", Type: events.MouseUp, Button: events.Left, Position: point}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			if selections != 0 || treeState(t, a, model).Selected != "" {
				t.Fatal("stale pointer release selected a row")
			}
			target := after.Rows[2]
			if action == "accessibility" {
				if err := a.Do(func() {
					if stale(accessibilityAction{Kind: "press"}) {
						t.Fatal("stale AX action revived after local layout")
					}
					nodes, handlers := accessibilitySnapshot(binding.r, nil)
					ready, actions := bridge.prepareGridPublication(nodes, handlers)
					for _, n := range ready {
						if n.GridPending {
							t.Fatal("completed publication still pending")
						}
					}
					fn := actions[accessibilityManagedID(target.ID)]
					if fn == nil || !fn(accessibilityAction{Kind: "press"}) {
						t.Fatal("fresh AX action refused after local layout")
					}
				}); err != nil {
					t.Fatal(err)
				}
			} else {
				point = target.Bounds.Min.Add(image.Pt(30, 2))
				for _, typ := range []events.Types{events.MouseDown, events.MouseUp} {
					if err := treeInput(t, m, ManualInput{Window: "one", Type: typ, Button: events.Left, Position: point}); err != nil {
						t.Fatal(err)
					}
					unitSettle(t, m)
				}
			}
			unitSettle(t, m)
			if selections != 1 || treeState(t, a, model).Selected != target.Key {
				t.Fatal("fresh action did not select exactly once", selections, treeState(t, a, model).Selected, target.Key)
			}
		})
	}
}
