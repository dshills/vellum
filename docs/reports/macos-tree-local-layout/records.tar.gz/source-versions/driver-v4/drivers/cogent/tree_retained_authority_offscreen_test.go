//go:build offscreen

package cogent

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"reflect"
	"testing"

	"cogentcore.org/core/events"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
)

// Unlike the same-host full-layout oracle, this fixture uses the frozen
// pre-prototype visible-index row constructor on an independent owner/model.
func TestTreeRetainedMatchesOriginalConstructor(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 162, 192} {
		t.Run(fmt.Sprint(dpi), func(t *testing.T) {
			// Manual owns a process-global render lease. Run the independent original
			// and candidate fixtures sequentially, preserving the original captures.
			var images []*image.RGBA
			var inspections []TreeInspection
			witnessedDifferentConstruction := false
			for pass := 0; pass < 2; pass++ {
				model := nativeOutline(t, 10000, true)
				config := manualConfig(t, 7)
				config.LogicalDPI = dpi
				m, a := gridManual(t, config, func() ui.Node { return ui.Node{ID: "outline", Kind: ui.DataTree, Tree: model, Grow: true} })
				unitSettle(t, m)
				binding := m.implementation.find("one").state.root.control.outline
				for step, scroll := range []int{72, 96, 120, 97, 98, 121, 500, 0} {
					var oldSlot *outlineNativeRow
					var oldKey string
					if err := a.Do(func() {
						oldSlot = binding.rows[1]
						oldKey = oldSlot.row.ID
						s, _ := model.State()
						s.Viewport.ScrollY = scroll
						if err := model.SetViewport(s.Viewport); err != nil {
							t.Fatal(err)
						}
						var err error
						if pass == 0 {
							err = frozenOriginalSyncTree(binding.r)
						} else {
							err = syncTree(binding.r)
						}
						if err != nil {
							t.Fatal(err)
						}
					}); err != nil {
						t.Fatal(err)
					}
					unitSettle(t, m)
					if pass == 0 {
						if binding.rows[1] != oldSlot {
							t.Fatal("frozen oracle did not retain visible-index slot")
						}
						if oldKey != binding.rows[1].row.ID {
							witnessedDifferentConstruction = true
						}
					}
					capture, err := m.Capture(testContext, "one")
					if err != nil {
						t.Fatal(err)
					}
					inspection := treeInspection(t, a, model)
					inspection.Incarnation = 0
					inspection.RowIncarnation = 0
					inspection.Frames = 0
					inspection.LocalLayouts = 0
					if pass == 0 {
						images = append(images, capture)
						inspections = append(inspections, inspection)
					} else {
						if capture.Bounds() != images[step].Bounds() || !bytes.Equal(capture.Pix, images[step].Pix) {
							t.Fatalf("scroll%d candidate/original pixels differ", scroll)
						}
						if !reflect.DeepEqual(inspection, inspections[step]) {
							t.Fatalf("scroll%d independent geometry/semantics differ", scroll)
						}
					}
				}
				if err := m.Close(testContext); err != nil {
					t.Fatal(err)
				}
			}
			if !witnessedDifferentConstruction {
				t.Fatal("oracle never reassigned a visible-index row")
			}
		})
	}
}

func TestTreeRetainedCoalescedScrollRevokesAndRestoresAuthority(t *testing.T) {
	for _, action := range []string{"accessibility", "pointer"} {
		t.Run(action, func(t *testing.T) {
			model := nativeOutline(t, 10000, true)
			selections := 0
			config := manualConfig(t, 7)
			config.LogicalDPI = 162
			m, a := gridManual(t, config, func() ui.Node {
				return ui.Node{ID: "outline", Kind: ui.DataTree, Tree: model, Grow: true, TreeChange: func(e ui.TreeEvent) {
					if e.Reason == ui.TreeSelection {
						selections++
					}
				}}
			})
			unitSettle(t, m)
			binding := m.implementation.find("one").state.root.control.outline
			if err := a.Do(func() {
				s, _ := model.State()
				s.Viewport.ScrollY = 72
				_ = model.SetViewport(s.Viewport)
				_ = syncTree(binding.r)
			}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			before := treeInspection(t, a, model)
			point := before.Rows[2].Bounds.Min.Add(image.Pt(30, 2))
			if err := treeInput(t, m, ManualInput{Window: "one", Type: events.MouseDown, Button: events.Left, Position: point}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			bridge := &accessibilityBridge{}
			var stale accessibilityHandler
			if err := a.Do(func() {
				nodes, handlers := accessibilitySnapshot(binding.r, nil)
				ready, actions := bridge.prepareGridPublication(nodes, handlers)
				for _, n := range ready {
					if n.Role == "tree-row" {
						stale = actions[n.ID]
						break
					}
				}
				if stale == nil {
					t.Fatal("missing completed action")
				}
				for range 2 {
					s, _ := model.State()
					s.Viewport.ScrollY += 24
					if err := model.SetViewport(s.Viewport); err != nil {
						t.Fatal(err)
					}
					if err := syncTree(binding.r); err != nil {
						t.Fatal(err)
					}
					if _, err := InspectTree(a, model); !errors.Is(err, ErrTreeLayout) {
						t.Fatal("coalesced geometry escaped pending fence", err)
					}
					if stale(accessibilityAction{Kind: "press"}) {
						t.Fatal("stale AX action accepted during pending scroll")
					}
				}
			}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			after := treeInspection(t, a, model)
			if after.LocalLayouts <= before.LocalLayouts {
				t.Fatal("coalesced scroll never used local layout")
			}
			if binding.layoutPending.Load() || len(binding.layoutDirty) != 0 {
				t.Fatal("completed layout retained pending text work")
			}
			if err := treeInput(t, m, ManualInput{Window: "one", Type: events.MouseUp, Button: events.Left, Position: point}); err != nil {
				t.Fatal(err)
			}
			unitSettle(t, m)
			if selections != 0 || treeState(t, a, model).Selected != "" {
				t.Fatal("stale pointer release selected a row")
			}
			target := after.Rows[2]
			if action == "accessibility" {
				if err := a.Do(func() {
					if stale(accessibilityAction{Kind: "press"}) {
						t.Fatal("stale AX action revived after local layout")
					}
					nodes, handlers := accessibilitySnapshot(binding.r, nil)
					ready, actions := bridge.prepareGridPublication(nodes, handlers)
					for _, n := range ready {
						if n.GridPending {
							t.Fatal("completed publication still pending")
						}
					}
					fn := actions[accessibilityManagedID(target.ID)]
					if fn == nil || !fn(accessibilityAction{Kind: "press"}) {
						t.Fatal("fresh AX action refused after local layout")
					}
				}); err != nil {
					t.Fatal(err)
				}
			} else {
				point = target.Bounds.Min.Add(image.Pt(30, 2))
				for _, typ := range []events.Types{events.MouseDown, events.MouseUp} {
					if err := treeInput(t, m, ManualInput{Window: "one", Type: typ, Button: events.Left, Position: point}); err != nil {
						t.Fatal(err)
					}
					unitSettle(t, m)
				}
			}
			unitSettle(t, m)
			if selections != 1 || treeState(t, a, model).Selected != target.Key {
				t.Fatal("fresh action did not select exactly once", selections, treeState(t, a, model).Selected, target.Key)
			}
		})
	}
}
