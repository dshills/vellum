//go:build offscreen

package cogent

import (
	"cogentcore.org/core/core"
	"cogentcore.org/core/styles/states"
	"cogentcore.org/core/tree"
	"html"
	"math"
	"slices"
)

// Frozen pre-prototype sync body: independent visible-index pool construction.
func frozenOriginalSyncTree(r *record) (result error) {
	t := r.control.outline
	defer func() {
		if result != nil && t != nil {
			t.projectionValid.Store(false)
			t.measurement.Store(nil)
		}
	}()
	if t == nil || !t.live() {
		return ErrTreeClosed
	}
	if err := validateNativeTree(r.node); err != nil {
		return err
	}
	snap, err := t.model.Snapshot()
	if err != nil {
		return err
	}
	if err := treeProjectionBudget(r.node.ID, snap); err != nil {
		return err
	}
	if snap.State.Generation != t.projection.State.Generation {
		outlineRegistry.Lock()
		if outlineRegistry.next == math.MaxUint64 {
			outlineRegistry.Unlock()
			return ErrTreeBinding
		}
		outlineRegistry.next++
		t.epoch = outlineRegistry.next
		outlineRegistry.Unlock()
	}
	// State.Pending can change without a new generation. Compare all validated
	// state and bounded rows; a completed owner publication must not schedule
	// another full scene layout when the projection is unchanged.
	dirty := !t.projectionValid.Load() || t.projection.State != snap.State || !slices.Equal(t.projection.Rows, snap.Rows) || t.projectedDisabled != r.control.disabled || t.projectedHelp != r.node.Accessibility.Help
	t.projection = snap
	if len(t.rows) > len(snap.Rows) {
		for _, row := range t.rows[len(snap.Rows):] {
			row.Delete()
		}
		clear(t.rows[len(snap.Rows):])
		t.rows = t.rows[:len(snap.Rows)]
	}
	for len(t.rows) < len(snap.Rows) {
		row := tree.New[outlineNativeRow](t.pane)
		row.binding = t
		row.arrow = core.NewText(row)
		row.label = core.NewText(row)
		installTreeText(row.arrow)
		installTreeText(row.label)
		t.rows = append(t.rows, row)
	}
	for i, row := range snap.Rows {
		native := t.rows[i]
		if native.row != row {
			dirty = true
		}
		native.row = row
		value := ""
		if row.HasChildren {
			value = "▸"
			if row.Expanded {
				value = "▾"
			}
		}
		native.arrow.SetText(value)
		native.label.SetText(html.EscapeString(row.Label))
		native.SetState((row.Clip.Width <= 0 || row.Clip.Height <= 0), states.Invisible)
		native.SetState(row.Selected, states.Selected)
		native.label.SetState(row.Selected, states.Selected)

	}
	value := float32(0)
	if maximum := treeMaxY(snap.State); maximum > 0 {
		value = float32(float64(snap.State.Viewport.ScrollY) / float64(maximum))
	}
	// SetValue requests paint even for an identical value. A native drag may
	// leave a noncanonical value despite an unchanged accepted model pixel.
	if t.vertical.Value != value {
		t.vertical.SetValue(value)
	}
	t.pager[0].SetState(snap.State.Viewport.ScrollY == 0, states.Disabled)
	t.pager[1].SetState(snap.State.Viewport.ScrollY == treeMaxY(snap.State), states.Disabled)
	first, last := 0, 0
	for _, row := range snap.Rows {
		if !(row.Clip.Width <= 0 || row.Clip.Height <= 0) {
			if first == 0 {
				first = row.Index + 1
			}
			last = row.Index + 1
		}
	}
	suffix := ""
	if snap.State.Pending {
		suffix = " · building"
	}
	t.status.SetText(fmtTreeRange(first, last, snap.State.VisibleRows, suffix))
	// One parent update traverses every retained row/text after all placements
	// and states are installed. Updating each row first duplicates updater,
	// style and shaping work and reads the previous parent style unnecessarily.
	if dirty {
		t.host.Update()
	}
	t.projectedDisabled = r.control.disabled
	t.projectedHelp = r.node.Accessibility.Help
	t.projectionValid.Store(true)
	return nil
}
