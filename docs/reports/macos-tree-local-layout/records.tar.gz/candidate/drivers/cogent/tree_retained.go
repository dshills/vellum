package cogent

import (
	"cogentcore.org/core/core"
	"cogentcore.org/core/styles/states"
	"cogentcore.org/core/tree"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
	"html"
	"math"
)

const treeFullLayoutProperty = "vellum.driver.tree_full_layout"

type treeLayoutStamp struct {
	valid         bool
	scene         *core.Scene
	parent        tree.Node
	geom          core.GeomState
	style         ui.Style
	scale         float32
	width, height int
	config        virtual.OutlineConfig
	index         virtual.TreeIndexIdentity
	disabled      bool
	help          string
}

func (t *outlineBinding) layoutStamp() treeLayoutStamp {
	style, err := ui.ResolveStyle(t.r.node, t.r.theme)
	if err != nil || t.host.Scene == nil || t.host.Parent == nil {
		return treeLayoutStamp{}
	}
	s := t.projection.State
	return treeLayoutStamp{true, t.host.Scene, t.host.Parent, t.host.Geom, style, t.host.Styles.UnitContext.Px(1), s.Viewport.Width, s.Viewport.Height, s.Config, t.projection.IndexIdentity, t.r.control.disabled, t.r.node.Accessibility.Help}
}
func (t *outlineBinding) canLayoutLocally(next virtual.OutlineSnapshot) bool {
	if !t.live() || !t.scope || !t.projectionValid.Load() || !t.layout.valid || t.projection.State.Pending || next.State.Pending || next.IndexIdentity.IsZero() || next.IndexIdentity != t.projection.IndexIdentity {
		return false
	}
	if forced, _ := t.host.Scene.Property(treeFullLayoutProperty).(bool); forced {
		return false
	}
	before, after := t.projection.State, next.State
	if before.Viewport.ScrollY == after.Viewport.ScrollY {
		return false
	}
	before.Generation, after.Generation = 0, 0
	before.Viewport.ScrollY, after.Viewport.ScrollY = 0, 0
	if before != after || t.layoutStamp() != t.layout || !validGridScale(t.layout.scale) {
		return false
	}
	if len(t.pane.Children) != len(t.rows) {
		return false
	}
	for _, r := range t.rows {
		if r == nil || r.This != r || r.Scene != t.host.Scene || r.Parent != t.pane || len(r.Children) != 2 || r.Parts != nil || r.arrow == nil || r.label == nil || r.Children[0] != r.arrow || r.Children[1] != r.label {
			return false
		}
		for _, tx := range []*core.Text{r.arrow, r.label} {
			if tx.This != tx || tx.Scene != t.host.Scene || tx.Parent != r || len(tx.Children) != 0 || tx.Parts != nil {
				return false
			}
		}
	}
	return true
}

// Only the current admitted projection is retained. An overlapping key keeps
// its widget; each departing row is used once as an incoming-key donor.
func (t *outlineBinding) retainRows(next virtual.OutlineSnapshot) ([]*outlineNativeRow, []*outlineNativeRow, error) {
	old := make(map[string]*outlineNativeRow, len(t.rows))
	for _, r := range t.rows {
		if r != nil && r.row.ID != "" {
			if old[r.row.ID] != nil {
				return nil, nil, ErrTreeBinding
			}
			old[r.row.ID] = r
		}
	}
	rows := make([]*outlineNativeRow, len(next.Rows))
	used := make(map[*outlineNativeRow]bool, len(t.rows))
	keys := make(map[string]bool, len(next.Rows))
	for i, r := range next.Rows {
		if r.ID == "" || keys[r.ID] {
			return nil, nil, ErrTreeBinding
		}
		keys[r.ID] = true
		if native := old[r.ID]; native != nil {
			rows[i] = native
			used[native] = true
		}
	}
	donors := make([]*outlineNativeRow, 0, len(t.rows))
	for _, r := range t.rows {
		if r != nil && !used[r] {
			donors = append(donors, r)
		}
	}
	head := 0
	for i, r := range rows {
		if r == nil && head < len(donors) {
			rows[i] = donors[head]
			head++
		}
	}
	return rows, donors[head:], nil
}
func (t *outlineBinding) orderRows() {
	managed := make(map[tree.Node]bool, len(t.rows))
	children := make([]tree.Node, 0, len(t.pane.Children))
	for _, r := range t.rows {
		managed[r] = true
		children = append(children, r)
	}
	for _, child := range t.pane.Children {
		if !managed[child] {
			children = append(children, child)
		}
	}
	t.pane.Children = children
}
func treeArrow(row virtual.OutlineRow) string {
	if !row.HasChildren {
		return ""
	}
	if row.Expanded {
		return "▾"
	}
	return "▸"
}
func (t *outlineBinding) installRetainedRows(snap virtual.OutlineSnapshot, local bool) (bool, map[*core.Text]bool, error) {
	rows, retired, err := t.retainRows(snap)
	if err != nil {
		return false, nil, err
	}
	if len(rows) != len(t.rows) || len(retired) != 0 {
		local = false
	}
	for _, r := range retired {
		delete(t.layoutDirty, r.arrow)
		delete(t.layoutDirty, r.label)
		r.Delete()
	}
	t.rows = rows
	styleDirty := make(map[*core.Text]bool)
	for i, row := range snap.Rows {
		native := t.rows[i]
		if native == nil {
			local = false
			native = tree.New[outlineNativeRow](t.pane)
			native.binding = t
			native.arrow = core.NewText(native)
			native.label = core.NewText(native)
			installTreeText(native.arrow)
			installTreeText(native.label)
			t.rows[i] = native
		}
		old := native.row
		oldWidth, oldHeight := gridPhysicalSize(virtual.GridRect{X: old.Rect.X, Y: old.Rect.Y, Width: old.Rect.Width, Height: old.Rect.Height}, t.host.Styles.UnitContext.Px(1))
		width, height := gridPhysicalSize(virtual.GridRect{X: row.Rect.X, Y: row.Rect.Y, Width: row.Rect.Width, Height: row.Rect.Height}, t.host.Styles.UnitContext.Px(1))
		if native.StateIs(states.Selected) != row.Selected || native.StateIs(states.Invisible) != (row.Clip.Width <= 0 || row.Clip.Height <= 0) {
			local = false
		}
		// The new row includes its current generation's input authority even when
		// the key/widget is retained. Never retain a preceding OutlineRef.
		native.row = row
		for tx, value := range map[*core.Text]string{native.arrow: treeArrow(row), native.label: html.EscapeString(row.Label)} {
			changed := tx.Text != value || tx.StateIs(states.Selected) != row.Selected && tx == native.label
			if changed {
				styleDirty[tx] = true
			}
			if changed || oldWidth != width || oldHeight != height || old.Depth != row.Depth || tx.PaintText() == nil {
				if t.layoutDirty == nil {
					t.layoutDirty = make(map[*core.Text]bool)
				}
				t.layoutDirty[tx] = true
			}
			tx.SetText(value)
		}
		native.SetState(row.Clip.Width <= 0 || row.Clip.Height <= 0, states.Invisible)
		native.SetState(row.Selected, states.Selected)
		native.label.SetState(row.Selected, states.Selected)
	}
	t.orderRows()
	return local, styleDirty, nil
}

// LayoutLocal preserves the host's outer allocation. Changed text is sized
// before paint; complete scene repaint retains sibling order and clears old pixels.
func (w *outlineWidget) LayoutLocal() bool {
	t := w.binding
	if t == nil || !t.live() || !t.layout.valid || t.layoutStamp() != t.layout || t.projection.State.Pending {
		if t != nil && t.live() {
			t.layout.valid = false
			t.host.Update()
		}
		return false
	}
	for tx := range t.layoutDirty {
		if tx.This == nil || tx.Scene != w.Scene {
			return false
		}
		tx.SizeUp()
		tx.SizeDown(0)
		tx.SizeFinal()
	}
	clear(t.layoutDirty)
	w.Position()
	w.ApplyScenePos()
	if t.localLayouts < math.MaxUint64 {
		t.localLayouts++
	}
	return true
}
