package virtual

import (
	"encoding/json"
	"errors"
	"testing"
)

func TestOutlineSnapshotAcceptedIndexIdentity(t *testing.T) {
	o := testOutline(t, []TreeNode{{ID: "root"}, {ID: "a", Parent: "root"}, {ID: "b", Parent: "root"}, {ID: "c", Parent: "root"}}, true)
	initial, e := o.Snapshot()
	if e != nil || initial.IndexIdentity.IsZero() {
		t.Fatal(initial, e)
	}
	oldRef := initial.Rows[0].Ref
	v := initial.State.Viewport
	v.ScrollY = 3
	if e = o.SetViewport(v); e != nil {
		t.Fatal(e)
	}
	moved, _ := o.Snapshot()
	if moved.IndexIdentity != initial.IndexIdentity {
		t.Fatal("viewport changed index identity")
	}
	if _, e = o.Row(oldRef); !errors.Is(e, ErrTreeStale) {
		t.Fatal("index identity preserved obsolete input authority", e)
	}
	if e = o.Select("b"); e != nil {
		t.Fatal(e)
	}
	selected, _ := o.Snapshot()
	if selected.IndexIdentity != initial.IndexIdentity {
		t.Fatal("selection changed immutable index")
	}
	request, e := o.Prepare(OutlineChange{Kind: OutlineKeep})
	if e != nil {
		t.Fatal(e)
	}
	pending, _ := o.Snapshot()
	if !pending.State.Pending || pending.IndexIdentity != initial.IndexIdentity {
		t.Fatal("pending discarded accepted index")
	}
	if e = o.Cancel(request); e != nil {
		t.Fatal(e)
	}
	canceled, _ := o.Snapshot()
	if canceled.IndexIdentity != initial.IndexIdentity {
		t.Fatal("cancel changed accepted index")
	}
	ids := map[TreeIndexIdentity]bool{initial.IndexIdentity: true}
	for range 64 {
		old, _ := o.Snapshot()
		applyOutline(t, o, OutlineChange{Kind: OutlineKeep})
		next, _ := o.Snapshot()
		if next.State.Stamp != old.State.Stamp || next.State.VisibleRows != old.State.VisibleRows || next.IndexIdentity.IsZero() || ids[next.IndexIdentity] {
			t.Fatal("equal-stamp/cardinality result reused old index identity")
		}
		ids[next.IndexIdentity] = true
	}
	data, e := json.Marshal(initial)
	if e != nil {
		t.Fatal(e)
	}
	var fields map[string]json.RawMessage
	if e = json.Unmarshal(data, &fields); e != nil || len(fields) != 2 || fields["State"] == nil || fields["Rows"] == nil {
		t.Fatal("process-local identity changed serialized snapshot", string(data), e)
	}
	if !(TreeIndexIdentity{}).IsZero() || !(OutlineSnapshot{}).IndexIdentity.IsZero() {
		t.Fatal("zero identity valid")
	}
}
