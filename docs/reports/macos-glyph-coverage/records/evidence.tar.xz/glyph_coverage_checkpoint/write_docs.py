from pathlib import Path
R=Path('/private/tmp/vellum-large-data');D=R/'docs/reports/macos-glyph-coverage';D.mkdir(exist_ok=False);(D/'records').mkdir()
(D/'README.md').write_text('''# Exact small glyph coverage reuse

Owned Core patch 0056 reuses ordered 16-bit scanner coverage for small static
TrueType fill-only glyphs after the existing Alpha-mask cache declines them.
Exact normalized fixed-path equality includes the original float32 rounding.
The hash only indexes candidates. Existing image and scene spanners still blend
pixels and emit packet operations. Original outline, segment, coordinate and
extent charges run before lookup; a warm cache cannot revive a refused batch.

The per-renderer FIFO retains at most 512 entries and 1 MiB of exact path/span
array backing. Entries contain no font, image, builder or packet references.
Metadata and transient recording are outside this bound. Resize and Release drop
storage. Identity transforms, static bounded outlines, value uniform fills,
clean owned scanners and a guarded hull wholly inside target/clip are required.
Other cases preserve ordinary rendering. Existing owner serialization applies.

## Evidence and limits

The current-source diagnostic captures an actual procedural 10,000-row grid with
400 clipped cells, 2,515 paint commands and 409 text commands. CPU replay matches
all composition pixels. Original profiles identify outline/scanning as substantial
paint work. Candidate replay preserves the same full-image SHA256, 4,392 packet
operations, 2,811,600 packet bytes and 1,685,984 encoded bytes. Diagnostic profiling
ran while the human used the computer and is not a paired benchmark or evidence
of native frame-rate improvement. It does not qualify stored-data workloads.

A separate 48-frame actual-driver software matrix compares all composition pixels,
geometry and cell density across DPI 96/120/144/192, fixed/variable rows and six
mixed-axis scroll steps. Every record matches. Focused tests check cold/warm and
recolored pixels, fractional/negative/large positions, clipped/unsupported
fallback, exact packet encoding, held packet immutability, entry/byte eviction,
detached backing, hash collision, work refusal and scanner ownership.
Four intentionally broken overlays fail their exact assertions. A first aggregate
refusal test incorrectly required zero cache hits before a late budget refusal;
its failure is preserved, and the corrected test compares both routes' refusal,
CPU/scanner fallback and held packet state.

Formal preparation checks all 56 patch numbers, reproduces six reviewed files
exactly and preserves every other baseline dependency leaf (6,204 → 6,207 files).
Final renderer race/vet, adapter race/vet, portable race, preparation tests and
native harness tests/build must pass. The native binary is built but not launched.
The final source/spec/report requires an internal review and a bounded Prism
review using Anthropic Claude Sonnet 5.5 before commit. Raw producers, overlays,
failures, profiles, comparisons, receipts and reviews are retained in the indexed
records archive; binaries are excluded with their hash retained.

The first matrix output accidentally shared a filename with its run receipt;
the receipt replaced pixel records. The corrected V2 matrix uses separate
exclusive filenames. The first adoption script assumed stage count equals patch
count and stopped before manifest mutation; its corrected version checks exact
patch numbers. A native test command used a nonexistent package and was replaced
with the existing harness package. Unkeyed vector test literals were corrected
after vet. Sandbox Unix-socket bind failures are preserved beside authorized
local reruns. None of these original failures qualifies a passing checkpoint.

GPU scene rendering remains opt-in. Default/native 4 ms p95 / 6 ms p99 targets,
full P6/P11, physical displays/input, human accessibility, native/GPU memory and
Mac distribution remain open. The prior interacting lifecycle run failed after
343 completed windows; its initiating close event remains unknown. Live tests
remain paused while the human uses the machine.
''')
with (R/'specs/rendering.md').open('a')as f:f.write('''

## Exact small glyph coverage reuse

After the existing Alpha-mask route declines a small static TrueType fill-only
glyph, ordinary CPU paint and private GPU scene capture may reuse ordered 16-bit
scanner spans. Every original outline/segment/coordinate/extent charge runs before
lookup. Cache warmth preserves refusal and CPU fallback state. Exact normalized
fixed-path equality, including original float32 conversions, authorizes reuse;
a fingerprint alone cannot authorize a hit.

Admission requires identity transform, bounded static outline, value uniform
fill, clean known owned scanner/spanner and a guarded hull wholly inside current
target and nonempty clip. Scroll recording, unsupported fonts/fills/transforms,
clipped boundaries or changed scanner ownership retain ordinary rendering.
Existing span functions blend pixels and emit packets; packet ownership remains
immutable. Entries retain only copied fixed paths and coverage, with no fonts,
images, builders or packets. Existing renderer owner serialization is required.

FIFO storage is bounded by 512 entries and 1 MiB exact path/span backing, at most
512 path values and 256 spans per entry. Bounds exclude metadata/transient record
backing and total process/native/GPU memory. Resize and Release drop storage.
The [coverage checkpoint](../docs/reports/macos-glyph-coverage/README.md) requires
original pixel/packet, budget/fallback, ownership/eviction and actual-driver
software composition parity. Diagnostic offscreen profiling does not establish
native latency acceptance. GPU scene rendering remains opt-in.
''')
with (R/'specs/macos-completion.md').open('a')as f:f.write('''

The [small glyph coverage checkpoint](../docs/reports/macos-glyph-coverage/README.md)
adds bounded per-renderer exact scanner-span reuse to CPU paint and private GPU
capture. Software grid composition matches across 48 frames at four DPI settings;
refusal, packet immutability, eviction and ownership checks preserve original
behavior. This source optimization requires internal and Anthropic Prism review.
It does not establish a native frame-rate gain or close P6/P11. GPU scene rendering
remains opt-in. Live tests remain deferred while the human uses the machine;
current complete lifecycle, physical/human checks and distribution remain open.
''')
print('Renderer spec, Mac status and scoped checkpoint report written')
