// Copyright (c) 2025, Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rasterx

import (
	"fmt"
	"image"
	"image/color"
	"image/draw"
	_ "image/jpeg" // load image formats for users of the API
	_ "image/png"
	"slices"
	"sort"

	"cogentcore.org/core/colors"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/textpos"
	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/font/opentype"
	"github.com/go-text/typesetting/shaping"
	_ "golang.org/x/image/tiff" // load image formats for users of the API
)

// RenderText rasterizes the given Text
func (rs *Renderer) RenderText(txt *render.Text) {
	if rs.recordingFailed() {
		return
	}
	// pr := profile.Start("RenderText")
	rs.TextLinesWithGeometry(&txt.Context, txt.Text, txt.Position, txt.Geometry)
	// pr.End()
}

// TextLines rasterizes the given shaped.Lines.
// The text will be drawn starting at the start pixel position, which specifies the
// left baseline location of the first text item..
func (rs *Renderer) TextLines(ctx *render.Context, lns *shaped.Lines, pos math32.Vector2) {
	if rs.recordingFailed() {
		return
	}
	// Direct callers have no render item. Capture once here; normal replay uses
	// geometry published by NewText/NewTextWithGeometry on the UI owner.
	var geometry *shaped.Interaction
	for _, ln := range lns.Lines {
		if len(ln.Selections) > 0 || len(ln.Highlights) > 0 {
			// Packet replay requires owner-published bounded geometry; never
			// synthesize grapheme/layout work from arbitrary source text here.
			if rs.sceneRecord != nil {
				rs.sceneRecord.Refuse()
				return
			}
			geometry = lns.InteractionLayout()
			break
		}
	}
	rs.TextLinesWithGeometry(ctx, lns, pos, geometry)
}
func (rs *Renderer) TextLinesWithGeometry(ctx *render.Context, lns *shaped.Lines, pos math32.Vector2, geometry *shaped.Interaction) {
	if rs.recordingFailed() {
		return
	}
	m := ctx.Cumulative
	identity := m == math32.Identity2()
	off := pos.Add(lns.Offset)
	rs.Scanner.SetClip(ctx.Bounds.Rect.ToRect())
	// tbb := lns.Bounds.Translate(off)
	// rs.StrokeBounds(ctx, tbb, colors.Red)
	clr := colors.Uniform(lns.Color)
	cellIndex := 0
	for li := range lns.Lines {
		if rs.recordingFailed() {
			return
		}
		var cells []shaped.Cell
		if geometry != nil {
			start := cellIndex
			for cellIndex < len(geometry.Cells) && geometry.Cells[cellIndex].Line == li {
				cellIndex++
			}
			cells = geometry.Cells[start:cellIndex]
		}
		rs.TextLine(ctx, &lns.Lines[li], lns, clr, off, identity, cells, pos)
	}

}

// TextLine rasterizes the given shaped.Line.
func (rs *Renderer) TextLine(ctx *render.Context, ln *shaped.Line, lns *shaped.Lines, clr image.Image, off math32.Vector2, identity bool, cells []shaped.Cell, origin math32.Vector2) {
	if rs.recordingFailed() {
		return
	}
	start := off.Add(ln.Offset)
	off = start
	// tbb := ln.Bounds.Translate(off)
	// rs.StrokeBounds(ctx, tbb, colors.Blue)
	for ri := range ln.Runs {
		if rs.recordingFailed() {
			return
		}
		run := ln.Runs[ri].(*shapedgt.Run)
		if run.Background != nil {
			rs.FillBounds(ctx, run.MaxBounds.Translate(off), run.Background)
		}
		if run.Direction.IsVertical() || run.Math.Path != nil {
			// Keep pre-existing glyph-region behavior for unsupported interaction runs.
			rs.TextLegacyRegionFill(ctx, run, off, lns.HighlightColor, ln.Highlights)
			rs.TextLegacyRegionFill(ctx, run, off, lns.SelectionColor, ln.Selections)
		}
		if run.Direction.IsVertical() {
			off.Y += run.Advance()
		} else {
			off.X += run.Advance()
		}
	}
	rs.TextRegionFill(ctx, cells, origin, lns.HighlightColor, ln.Highlights)
	rs.TextRegionFill(ctx, cells, origin, lns.SelectionColor, ln.Selections)
	off = start
	for ri := range ln.Runs {
		if rs.recordingFailed() {
			return
		}
		run := ln.Runs[ri].(*shapedgt.Run)
		rs.TextRun(ctx, run, ln, lns, clr, off, identity)
		if run.Direction.IsVertical() {
			off.Y += run.Advance()
		} else {
			off.X += run.Advance()
		}
	}
}

// textRegionRects normalizes logical ranges and coalesces physically adjacent
// advance cells with matching vertical bounds. Disjoint bidi fragments stay apart.
func textRegionRects(cells []shaped.Cell, ranges []textpos.Range) []math32.Box2 {
	if len(ranges) == 0 {
		return nil
	}
	normalized := slices.Clone(ranges)
	slices.SortFunc(normalized, func(a, b textpos.Range) int {
		if a.Start != b.Start {
			return a.Start - b.Start
		}
		return a.End - b.End
	})
	merged := normalized[:0]
	for _, r := range normalized {
		if r.Len() <= 0 {
			continue
		}
		if len(merged) > 0 && r.Start <= merged[len(merged)-1].End {
			merged[len(merged)-1].End = max(merged[len(merged)-1].End, r.End)
		} else {
			merged = append(merged, r)
		}
	}
	var rects []math32.Box2
	for _, cell := range cells {
		i := sort.Search(len(merged), func(i int) bool { return merged[i].End > cell.Range.Start })
		if i < len(merged) && merged[i].Start < cell.Range.End {
			rects = append(rects, cell.Rect)
		}
	}
	slices.SortFunc(rects, func(a, b math32.Box2) int {
		for _, pair := range [][2]float32{{a.Min.Y, b.Min.Y}, {a.Max.Y, b.Max.Y}, {a.Min.X, b.Min.X}} {
			if pair[0] < pair[1] {
				return -1
			}
			if pair[0] > pair[1] {
				return 1
			}
		}
		return 0
	})
	out := rects[:0]
	for _, box := range rects {
		if len(out) > 0 {
			last := &out[len(out)-1]
			if last.Min.Y == box.Min.Y && last.Max.Y == box.Max.Y && box.Min.X <= last.Max.X {
				last.Max.X = max(last.Max.X, box.Max.X)
				continue
			}
		}
		out = append(out, box)
	}
	return out
}

// TextRegionFill fills selected advance fragments and avoids offscreen raster work.
func (rs *Renderer) TextRegionFill(ctx *render.Context, cells []shaped.Cell, origin math32.Vector2, fill image.Image, ranges []textpos.Range) {
	if rs.recordingFailed() || fill == nil || len(ranges) == 0 {
		return
	}
	for _, box := range textRegionRects(cells, ranges) {
		if rs.recordingFailed() {
			return
		}
		box = box.Translate(origin)
		corners := []math32.Vector2{box.Min, math32.Vec2(box.Max.X, box.Min.Y), box.Max, math32.Vec2(box.Min.X, box.Max.Y)}
		transformed := math32.Box2{Min: ctx.Cumulative.MulPoint(corners[0]), Max: ctx.Cumulative.MulPoint(corners[0])}
		for _, p := range corners[1:] {
			transformed.ExpandByPoint(ctx.Cumulative.MulPoint(p))
		}
		if !transformed.IntersectsBox(ctx.Bounds.Rect) {
			continue
		}
		rs.FillBounds(ctx, box, fill)
	}
}

// TextLegacyRegionFill retains the earlier renderer behavior for vertical/math runs.
func (rs *Renderer) TextLegacyRegionFill(ctx *render.Context, run *shapedgt.Run, off math32.Vector2, fill image.Image, ranges []textpos.Range) {
	if rs.recordingFailed() || fill == nil {
		return
	}
	for _, sel := range ranges {
		if rs.recordingFailed() {
			return
		}
		selected := sel.Intersect(run.Runes())
		if selected.Len() == 0 {
			continue
		}
		first, last := run.FirstGlyphAt(selected.Start), run.LastGlyphAt(selected.End-1)
		if first >= 0 && last >= first {
			rs.FillBounds(ctx, run.GlyphRegionBounds(first, last).Canon().Translate(off), fill)
		}
	}
}

// TextRun rasterizes the given text run into the output image using the
// font face set in the shaping.
// The text will be drawn starting at the start pixel position.
func (rs *Renderer) TextRun(ctx *render.Context, run *shapedgt.Run, ln *shaped.Line, lns *shaped.Lines, clr image.Image, off math32.Vector2, identity bool) {
	if rs.recordingFailed() {
		return
	}
	// dir := run.Direction
	rbb := run.MaxBounds.Translate(off)
	fill := clr
	if run.FillColor != nil {
		fill = run.FillColor
	}
	stroke := run.StrokeColor
	fsz := math32.FromFixed(run.Size)
	lineW := max(fsz/16, 1) // 1 at 16, bigger if biggerr
	if run.Math.Path != nil {
		rs.Path.Clear()
		PathToRasterx(&rs.Path, run.Math.Path, ctx.Cumulative, off)
		rf := &rs.Raster.Filler
		rf.SetWinding(true)
		rf.SetColor(fill)
		rs.Path.AddTo(rf)
		rf.Draw()
		rf.Clear()
		return
	}

	sty := run.Font.Style(&ctx.Style.Text)
	// https://en.wikipedia.org/wiki/Subscript_and_superscript: latex does -.14 sub, .25 super
	// others often use -.33 and .33
	if sty.Special == rich.Super {
		off.Y -= 0.25 * fsz
	} else if sty.Special == rich.Sub {
		off.Y += 0.14 * fsz
	}

	if run.Decoration.HasFlag(rich.Underline) || run.Decoration.HasFlag(rich.DottedUnderline) {
		dash := []float32{2, 2}
		if run.Decoration.HasFlag(rich.Underline) {
			dash = nil
		}
		if run.Direction.IsVertical() {

		} else {
			dec := off.Y + 3
			rs.StrokeTextLine(ctx, math32.Vec2(rbb.Min.X, dec), math32.Vec2(rbb.Max.X, dec), lineW, fill, dash)
		}
	}
	if run.Decoration.HasFlag(rich.Overline) {
		if run.Direction.IsVertical() {
		} else {
			dec := off.Y - 0.7*rbb.Size().Y
			rs.StrokeTextLine(ctx, math32.Vec2(rbb.Min.X, dec), math32.Vec2(rbb.Max.X, dec), lineW, fill, nil)
		}
	}

	for gi := range run.Glyphs {
		if rs.recordingFailed() {
			return
		}
		g := &run.Glyphs[gi]
		pos := off.Add(math32.Vec2(math32.FromFixed(g.XOffset), -math32.FromFixed(g.YOffset)))
		bb := run.GlyphBoundsBox(g).Translate(off)
		// rs.StrokeBounds(ctx, bb, colors.Yellow)
		if rs.sceneRecord != nil {
			if !rs.sceneTakeWork(1) {
				return
			}
			data, ok := rs.staticOutlines().bounded(run.Face, g.GlyphID, rs.sceneWork.outlines)
			if !ok {
				rs.sceneRecord.Refuse()
				return
			}
			rs.GlyphOutline(ctx, run, g, data, fill, stroke, bb, pos, identity)
		} else if data, ok := run.Face.GlyphDataSVG(g.GlyphID); ok {
			rs.GlyphSVG(ctx, run, g, data.Source, bb, pos, identity)
		} else if data, ok := run.Face.GlyphDataBitmap(g.GlyphID); ok {
			rs.GlyphBitmap(ctx, run, g, data, fill, stroke, bb, pos, identity)
		} else if data, ok := rs.staticOutlines().ordinary(run.Face, g.GlyphID); ok {
			rs.GlyphOutline(ctx, run, g, data, fill, stroke, bb, pos, identity)
		} else {
			fmt.Printf("unrecognized glyph data for glyphID: %v, face: %v\n", g.GlyphID, run.Face.Describe().Family)
		}
		if run.Direction.IsVertical() {
			off.Y -= math32.FromFixed(g.Advance)
		} else {
			off.X += math32.FromFixed(g.Advance)
		}
	}

	if run.Decoration.HasFlag(rich.LineThrough) {
		if run.Direction.IsVertical() {
		} else {
			dec := off.Y - 0.2*rbb.Size().Y
			rs.StrokeTextLine(ctx, math32.Vec2(rbb.Min.X, dec), math32.Vec2(rbb.Max.X, dec), lineW, fill, nil)
		}
	}
}

func (rs *Renderer) GlyphOutline(ctx *render.Context, run *shapedgt.Run, g *shaping.Glyph, outline font.GlyphOutline, fill, stroke image.Image, bb math32.Box2, pos math32.Vector2, identity bool) {
	if rs.recordingFailed() {
		return
	}
	scale := math32.FromFixed(run.Size) / float32(run.Face.Upem())
	x := pos.X // note: has offsets already added
	y := pos.Y
	if len(outline.Segments) == 0 {
		// fmt.Println("nil path:", g.GlyphID)
		return
	}

	wd := math32.FromFixed(g.Width)
	// todo: should be conditional on run.Direction
	xadv := math32.Abs(math32.FromFixed(g.Advance))
	if wd > xadv {
		if run.Font.Style(&ctx.Style.Text).Family == rich.Monospace {
			scale *= 0.95 * xadv / wd
		}
	}

	if rs.scrollRecord != nil && len(outline.Segments) > scrollPlanMaxOps {
		rs.scrollRecord.failed = true
		return
	}
	if rs.sceneRecord != nil {
		if len(outline.Segments) > sceneMaxItems || !rs.sceneTakeWork(len(outline.Segments)) {
			rs.sceneRecord.Refuse()
			return
		}
		// Cached extrema prove the same bounds for the exact identity transform.
		// Cold/unretained/replaced outlines and all other transforms retain the
		// point traversal; every logical outline/work charge still runs above.
		var bounds math32.Box2
		available, valid := false, false
		if identity && ctx.Cumulative == math32.Identity2() {
			bounds, available, valid = rs.staticOutlines().identitySceneBounds(run.Face.Font, g.GlyphID, outline, scale, pos)
		}
		if available {
			if !valid {
				rs.sceneRecord.Refuse()
				return
			}
		} else {
			points := 0
			for _, segment := range outline.Segments {
				var n int
				switch segment.Op {
				case opentype.SegmentOpMoveTo, opentype.SegmentOpLineTo:
					n = 1
				case opentype.SegmentOpQuadTo:
					n = 2
				case opentype.SegmentOpCubeTo:
					n = 3
				default:
					rs.sceneRecord.Refuse()
					return
				}
				for _, arg := range segment.Args[:n] {
					p := math32.Vec2(arg.X*scale+x, -arg.Y*scale+y)
					q := ctx.Cumulative.MulPoint(p)
					if points == 0 {
						bounds = math32.Box2{Min: q, Max: q}
					} else {
						bounds.ExpandByPoint(q)
					}
					points++
					if !scenePoint(p) || !scenePoint(ctx.Cumulative.MulPoint(p)) {
						rs.sceneRecord.Refuse()
						return
					}
				}
			}
		}
		extent := 1 + int(bounds.Size().X) + int(bounds.Size().Y)
		if !rs.sceneWork.product(len(outline.Segments), extent) {
			rs.sceneRecord.Refuse()
			return
		}
	}
	if UseGlyphCache && identity && stroke == nil {
		mask, pi := theGlyphCache.Glyph(run.Face, g, outline, scale, pos)
		if mask != nil {
			rs.GlyphMask(ctx, run, g, fill, stroke, bb, pi, mask)
			return
		}
	}

	rs.Path.Clear()
	m := ctx.Cumulative
	for _, s := range outline.Segments {
		if rs.recordingFailed() {
			return
		}
		p0 := m.MulPoint(math32.Vec2(s.Args[0].X*scale+x, -s.Args[0].Y*scale+y))
		switch s.Op {
		case opentype.SegmentOpMoveTo:
			rs.Path.Start(p0.ToFixed())
		case opentype.SegmentOpLineTo:
			rs.Path.Line(p0.ToFixed())
		case opentype.SegmentOpQuadTo:
			p1 := m.MulPoint(math32.Vec2(s.Args[1].X*scale+x, -s.Args[1].Y*scale+y))
			rs.Path.QuadBezier(p0.ToFixed(), p1.ToFixed())
		case opentype.SegmentOpCubeTo:
			p1 := m.MulPoint(math32.Vec2(s.Args[1].X*scale+x, -s.Args[1].Y*scale+y))
			p2 := m.MulPoint(math32.Vec2(s.Args[2].X*scale+x, -s.Args[2].Y*scale+y))
			rs.Path.CubeBezier(p0.ToFixed(), p1.ToFixed(), p2.ToFixed())
		}
	}
	rs.Path.Stop(true)
	if rs.glyphCoverageEnabled && UseGlyphCache && identity && stroke == nil && rs.scrollRecord == nil && run.Face.SupportsBoundedOutlines() && int(-g.Height.Round())+2*glyphMaskBorder < glyphMinSize && rs.drawGlyphCoverage(fill) {
		rs.Path.Clear()
		return
	}
	if rs.scrollRecord != nil {
		rs.scrollRecord.winding = true
		rs.scrollRecord.addPath(rs.Path, ctx.Bounds.Rect.ToRect(), fill)
		rs.Path.Clear()
		return
	}
	if fill != nil {
		rf := &rs.Raster.Filler
		rf.SetWinding(true)
		rf.SetColor(fill)
		rs.Path.AddTo(rf)
		rf.Draw()
		rf.Clear()
	}

	if stroke != nil {
		sw := math32.FromFixed(run.Size) / 32.0 // scale with font size
		rs.Raster.SetStroke(
			math32.ToFixed(sw),
			math32.ToFixed(10),
			ButtCap, nil, nil, Miter, nil, 0)
		rs.Path.AddTo(rs.Raster)
		rs.Raster.SetColor(stroke)
		rs.Raster.Draw()
		rs.Raster.Clear()
	}
	rs.Path.Clear()
}

func (rs *Renderer) GlyphMask(ctx *render.Context, run *shapedgt.Run, g *shaping.Glyph, fill, stroke image.Image, bb math32.Box2, pos image.Point, mask *image.Alpha) error {
	if rs.recordingFailed() {
		return nil
	}
	if rs.scrollRecord != nil {
		rs.scrollRecord.addMask(mask, pos, ctx.Bounds.Rect.ToRect(), fill)
		return nil
	}
	if rs.sceneRecord != nil {
		dbb := mask.Bounds().Add(pos)
		ibb := dbb.Intersect(ctx.Bounds.Rect.ToRect())
		if !ibb.Empty() {
			// Match the original GlyphMask mask position, including its unusual
			// nonzero-origin behavior, before the owned builder clips it.
			rs.sceneRecord.Draw(ibb, fill, image.Point{}, mask, ibb.Min.Sub(dbb.Min), draw.Over)
		}
		return nil
	}
	mbb := mask.Bounds()
	dbb := mbb.Add(pos)
	ibb := dbb.Intersect(ctx.Bounds.Rect.ToRect())
	if ibb == (image.Rectangle{}) {
		return nil
	}
	mp := ibb.Min.Sub(dbb.Min)
	draw.DrawMask(rs.image, ibb, fill, image.Point{}, mask, mp, draw.Over)
	return nil
}

// StrokeBounds strokes a bounding box in the given color. Useful for debugging.
func (rs *Renderer) StrokeBounds(ctx *render.Context, bb math32.Box2, clr color.Color) {
	rs.Raster.SetStroke(
		math32.ToFixed(1),
		math32.ToFixed(10),
		ButtCap, nil, nil, Miter,
		nil, 0)
	rs.Raster.SetColor(colors.Uniform(clr))
	m := ctx.Cumulative
	rs.Raster.Start(m.MulPoint(math32.Vec2(bb.Min.X, bb.Min.Y)).ToFixed())
	rs.Raster.Line(m.MulPoint(math32.Vec2(bb.Max.X, bb.Min.Y)).ToFixed())
	rs.Raster.Line(m.MulPoint(math32.Vec2(bb.Max.X, bb.Max.Y)).ToFixed())
	rs.Raster.Line(m.MulPoint(math32.Vec2(bb.Min.X, bb.Max.Y)).ToFixed())
	rs.Raster.Stop(true)
	rs.Raster.Draw()
	rs.Raster.Clear()
}

// StrokeTextLine strokes a line for text decoration.
func (rs *Renderer) StrokeTextLine(ctx *render.Context, sp, ep math32.Vector2, width float32, clr image.Image, dash []float32) {
	if rs.recordingFailed() {
		return
	}
	m := ctx.Cumulative
	sp = m.MulPoint(sp)
	ep = m.MulPoint(ep)
	width *= MeanScale(m)
	if rs.sceneRecord != nil {
		if !scenePoint(sp) || !scenePoint(ep) || !sceneScalar(width) || !sceneColorOK(clr) || !rs.sceneTakeWork(1+int(math32.Abs(ep.X-sp.X))+int(math32.Abs(ep.Y-sp.Y))) {
			rs.sceneRecord.Refuse()
			return
		}
	}
	rs.Raster.SetStroke(
		math32.ToFixed(width),
		math32.ToFixed(10),
		ButtCap, nil, nil, Miter,
		dash, 0)
	rs.Raster.SetColor(clr)
	rs.Raster.Start(sp.ToFixed())
	rs.Raster.Line(ep.ToFixed())
	rs.Raster.Stop(false)
	rs.Raster.Draw()
	rs.Raster.Clear()
}

// FillBounds fills a bounding box in the given color.
func (rs *Renderer) FillBounds(ctx *render.Context, bb math32.Box2, clr image.Image) {
	if rs.recordingFailed() {
		return
	}
	if rs.sceneRecord != nil {
		if !sceneBox(bb, ctx.Cumulative, math32.Vector2{}) || !sceneColorOK(clr) {
			rs.sceneRecord.Refuse()
			return
		}
		a, b := ctx.Cumulative.MulPoint(bb.Min), ctx.Cumulative.MulPoint(bb.Max)
		if !rs.sceneTakeWork(4 * (1 + int(math32.Abs(b.X-a.X)) + int(math32.Abs(b.Y-a.Y)))) {
			return
		}
	}
	if rs.scrollRecord != nil {
		var path Path
		m := ctx.Cumulative
		path.Start(m.MulPoint(bb.Min).ToFixed())
		path.Line(m.MulPoint(math32.Vec2(bb.Max.X, bb.Min.Y)).ToFixed())
		path.Line(m.MulPoint(bb.Max).ToFixed())
		path.Line(m.MulPoint(math32.Vec2(bb.Min.X, bb.Max.Y)).ToFixed())
		path.Stop(true)
		rs.scrollRecord.addPath(path, ctx.Bounds.Rect.ToRect(), clr)
		return
	}
	rf := &rs.Raster.Filler
	rf.SetColor(clr)
	m := ctx.Cumulative
	rf.Start(m.MulPoint(math32.Vec2(bb.Min.X, bb.Min.Y)).ToFixed())
	rf.Line(m.MulPoint(math32.Vec2(bb.Max.X, bb.Min.Y)).ToFixed())
	rf.Line(m.MulPoint(math32.Vec2(bb.Max.X, bb.Max.Y)).ToFixed())
	rf.Line(m.MulPoint(math32.Vec2(bb.Min.X, bb.Max.Y)).ToFixed())
	rf.Stop(true)
	rf.Draw()
	rf.Clear()
}
