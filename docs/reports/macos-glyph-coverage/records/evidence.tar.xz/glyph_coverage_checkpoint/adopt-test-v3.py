from pathlib import Path
import json,hashlib,difflib
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-render-probe');D=R/'drivers/cogent/native/patches/glyphcoverage'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
d=json.loads((P/'adoption-inputs.json').read_text());d['overlay_mapping']['paint/renderers/rasterx/glyph_coverage_test.go']=str(P/'glyph_coverage_v3_test.go');d['outputs']['paint/renderers/rasterx/glyph_coverage_test.go']=sha(P/'glyph_coverage_v3_test.go')
# Preserve the initial exact stage that was tested, then regenerate from base for the test-only correction.
for n in ['0056-exact-small-glyph-coverage.patch','output-hashes.json']:(P/('owned-v1-'+n)).write_bytes((D/n).read_bytes())
chunks=[]
for rel,src in d['overlay_mapping'].items():
 target='drivers/cogent/build/upstream/'+rel
 original=d['inputs'][rel]
 # Prepared originals are not tracked; the immutable base overlay producer retained them in staged patch.
 old=''
 if original is not None:
  old=(P/('candidate-v3-'+Path(rel).name)).read_text() # start from candidate then reverse initial diff below instead
  # Read baseline from original patch by reverse-applying inside an isolated temporary directory.
  import tempfile,subprocess
  with tempfile.TemporaryDirectory(dir=P)as temp:
   t=Path(temp)/rel;t.parent.mkdir(parents=True);t.write_bytes((R/target).read_bytes())
   # reverse entire patch requires all six files
   for other in d['overlay_mapping']:
    q=Path(temp)/other;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((R/'drivers/cogent/build/upstream'/other).read_bytes())
   subprocess.run(['patch','--batch','-R','-p1','-i',str(P/'owned-v1-0056-exact-small-glyph-coverage.patch')],cwd=temp,check=True,stdout=subprocess.DEVNULL)
   old=t.read_text();assert hashlib.sha256(old.encode()).hexdigest()==original
 new=Path(src).read_text();chunks.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if original else'/dev/null',tofile='b/'+rel,n=3))
patch=D/'0056-exact-small-glyph-coverage.patch';patch.write_text(''.join(chunks));d['patch_sha256']=sha(patch)
(D/'output-hashes.json').write_text(json.dumps(d['outputs'],indent=2)+'\n')
manifest=R/'drivers/cogent/native/dependencies.json';m=json.loads(manifest.read_text());m['dependencies'][0]['stages'][-1]['patches'][0]['sha256']=sha(patch);manifest.write_text(json.dumps(m,indent=2)+'\n')
(P/'adoption-inputs-v2.json').write_text(json.dumps(d,indent=2)+'\n');print('Stage56 test-only keyed literal correction; five other outputs exact')
