// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"bytes"
	"image"
	"image/color"
	"testing"
	"unsafe"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx/scan"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"github.com/go-text/typesetting/font"
	"golang.org/x/image/math/fixed"
)

func coverageCheckStorage(t *testing.T, c *glyphCoverageCache) {
	t.Helper()
	sum, count := 0, 0
	seen := map[*glyphCoverageEntry]bool{}
	for _, e := range c.queue {
		if e == nil {
			continue
		}
		count++
		if seen[e] || c.entries[e.hash] != e {
			t.Fatal("orphan or duplicate retained entry")
		}
		seen[e] = true
		actual := cap(e.path)*int(unsafe.Sizeof(fixed.Int26_6(0))) + cap(e.spans)*int(unsafe.Sizeof(glyphCoverageSpan{}))
		if actual != e.bytes || cap(e.path) != len(e.path) || cap(e.spans) != len(e.spans) {
			t.Fatal("retained backing charge/capacity differs", actual, e.bytes)
		}
		sum += actual
	}
	if count != c.count || len(c.entries) != c.count || sum != c.bytes || c.count > glyphCoverageEntries || sum > glyphCoverageBytes {
		t.Fatal("coverage storage cap/state", count, c.count, sum, c.bytes)
	}
}
func TestVellumGlyphCoverageBoundedFIFOAndDetachedArrays(t *testing.T) {
	var c glyphCoverageCache
	p := Path{}
	p.Start(fixed.Point26_6{X: 64, Y: 64})
	p.Line(fixed.Point26_6{X: 96, Y: 128})
	p.Stop(true)
	spans := []glyphCoverageSpan{{0, 0, 1, 32769}}
	c.retain(1, p, image.Point{}, spans)
	p[1] = 99
	spans[0].alpha = 1
	if c.entries[1].path[1] != 64 || c.entries[1].spans[0].alpha != 32769 {
		t.Fatal("retained caller arrays")
	}
	for i := 2; i <= glyphCoverageEntries*3; i++ {
		c.retain(uint64(i), p, image.Point{}, spans)
		coverageCheckStorage(t, &c)
	}
	if c.count != glyphCoverageEntries || c.entries[1] != nil || c.entries[uint64(glyphCoverageEntries*3)] == nil {
		t.Fatal("entry bound/FIFO not exercised")
	}
	// Exercise the independent byte limit with maximum admitted array lengths.
	var heavy glyphCoverageCache
	p = nil
	p.Start(fixed.Point26_6{})
	for len(p)+4 <= glyphCoveragePathValues {
		p.Line(fixed.Point26_6{X: 1, Y: 1})
	}
	p.Stop(true)
	spans = make([]glyphCoverageSpan, glyphCoverageSpans)
	for i := 1; i <= glyphCoverageEntries; i++ {
		heavy.retain(uint64(i), p, image.Point{}, spans)
		coverageCheckStorage(t, &heavy)
	}
	if heavy.count >= glyphCoverageEntries || heavy.entries[1] != nil {
		t.Fatal("byte-limit eviction not exercised", heavy.count, heavy.bytes)
	}
}
func TestVellumGlyphCoverageHashCollisionRendersCurrentPath(t *testing.T) {
	item := coverageSmallItem()
	r := New(math32.Vec2(256, 64)).(*Renderer)
	original := New(math32.Vec2(256, 64)).(*Renderer)
	p := coverageGlyphPath(item, math32.Vec2(8, 24))
	fill := image.NewUniform(color.NRGBA{31, 77, 119, 193})
	r.Scanner.SetClip(r.image.Bounds())
	r.Path = append(r.Path, p...)
	if !r.drawGlyphCoverage(fill) {
		t.Fatal("cold fixture did not cache")
	}
	origin, h, ok := glyphCoverageGeometry(p, r.image.Bounds(), r.Scanner.Clip)
	if !ok || r.glyphCoverage.entries[h] == nil {
		t.Fatal("missing geometry fixture")
	}
	// Simulate a colliding key with a real different glyph path/coverage. The hit
	// must compare the whole fixed sequence instead of trusting the fingerprint.
	other := coverageGlyphPath(item, math32.Vec2(8.25, 24))
	r.Path = append(r.Path[:0], other...)
	if !r.drawGlyphCoverage(fill) {
		t.Fatal("second fixture refused")
	}
	_, otherHash, _ := glyphCoverageGeometry(other, r.image.Bounds(), r.Scanner.Clip)
	different := r.glyphCoverage.entries[otherHash]
	if different == nil || otherHash == h {
		t.Fatal("no distinct normalized phase")
	}
	fake := *different
	fake.hash = h
	r.glyphCoverage.entries[h] = &fake
	coverageSeed(r)
	coverageSeed(original)
	original.Scanner.SetClip(original.image.Bounds())
	r.Path = append(r.Path[:0], p...)
	before := r.glyphCoverage.hits
	if !r.drawGlyphCoverage(fill) {
		t.Fatal("collision path refused original draw")
	}
	coverageReference(original, p, fill)
	if r.glyphCoverage.hits != before || !bytes.Equal(r.image.Pix, original.image.Pix) {
		t.Fatal("fingerprint substituted for exact path", origin)
	}
}
func TestVellumGlyphCoverageWarmthCannotBypassWorkOrRefusal(t *testing.T) {
	item := coverageSmallItem()
	r := New(math32.Vec2(256, 64)).(*Renderer)
	for range 3 {
		if r.ScenePacket(render.Render{item}) == nil {
			t.Fatal("warm fixture refused")
		}
	}
	if r.glyphCoverage == nil || r.glyphCoverage.hits == 0 {
		t.Fatal("fixture did not warm coverage")
	}
	beforeHits := r.glyphCoverage.hits
	before := bytes.Clone(r.image.Pix)
	run := item.Text.Lines[0].Runs[0].(*shapedgt.Run)
	g := &run.Glyphs[0]
	outline, ok := run.Face.GlyphDataOutline(g.GlyphID)
	if !ok || len(outline.Segments) < 2 {
		t.Fatal("missing actual outline")
	}
	r.sceneRecord = sceneplan.New(r.image.Bounds())
	r.sceneWork = &sceneWorkBudget{remaining: len(outline.Segments) - 1, outlines: font.NewGlyphOutlineBudget(1<<20, 1<<20)}
	r.GlyphOutline(&item.Context, run, g, outline, image.NewUniform(item.Text.Color), nil, run.GlyphBoundsBox(g), item.Position, true)
	if !r.sceneRecord.Failed() || r.glyphCoverage.hits != beforeHits || !bytes.Equal(r.image.Pix, before) {
		t.Fatal("warm coverage bypassed original segment budget")
	}
	r.sceneRecord = nil
	r.sceneWork = nil
	tooMany := make(render.Render, sceneplan.MaxOps)
	for i := range tooMany {
		tooMany[i] = item
	}
	fresh := New(math32.Vec2(256, 64)).(*Renderer)
	if r.ScenePacket(tooMany) != nil || fresh.vellumFreshScenePacket(tooMany) != nil || r.glyphCoverage.hits != beforeHits {
		t.Fatal("warmth changed aggregate refusal or captured after refusal")
	}
	if !bytes.Equal(r.image.Pix, before) {
		t.Fatal("refused batch changed CPU pixels")
	}
}
func TestVellumGlyphCoverageChangedScannerAndPendingStateRefuse(t *testing.T) {
	item := coverageSmallItem()
	fill := image.NewUniform(color.NRGBA{31, 77, 119, 193})
	for name, change := range map[string]func(*Renderer){
		"width":        func(r *Renderer) { r.Scanner.Width-- },
		"height":       func(r *Renderer) { r.Scanner.CellIndex = r.Scanner.CellIndex[:len(r.Scanner.CellIndex)-1] },
		"filler-owner": func(r *Renderer) { r.Raster.Filler.Scanner = scan.NewScannerWithRowTracking(r.ImgSpanner, 256, 64) },
		"pending-cell": func(r *Renderer) { r.Scanner.Area = 1 },
		"pending-pen":  func(r *Renderer) { r.Raster.Filler.A.X = 1 },
	} {
		t.Run(name, func(t *testing.T) {
			r := New(math32.Vec2(256, 64)).(*Renderer)
			r.Scanner.SetClip(r.image.Bounds())
			r.Path = coverageGlyphPath(item, math32.Vec2(8, 24))
			if !r.drawGlyphCoverage(fill) {
				t.Fatal("warm fixture refused")
			}
			hits := r.glyphCoverage.hits
			before := bytes.Clone(r.image.Pix)
			change(r)
			if r.drawGlyphCoverage(fill) || hits != r.glyphCoverage.hits || !bytes.Equal(before, r.image.Pix) {
				t.Fatal("changed ownership/state reused glyph")
			}
		})
	}
	r := New(math32.Vec2(256, 64)).(*Renderer)
	r.Scanner.SetClip(r.image.Bounds())
	r.Path = coverageGlyphPath(item, math32.Vec2(8, 24))
	r.drawGlyphCoverage(fill)
	old := r.glyphCoverage
	r.SetSize(units.UnitDot, math32.Vec2(257, 65))
	if r.glyphCoverage != nil {
		t.Fatal("resize retained coverage")
	}
	r.Scanner.SetClip(r.image.Bounds())
	r.Path = coverageGlyphPath(item, math32.Vec2(8, 24))
	r.drawGlyphCoverage(fill)
	if r.glyphCoverage == old || r.glyphCoverage == nil {
		t.Fatal("resize did not rebuild isolated cache")
	}
	r.Release()
	r.Release()
	if r.glyphCoverage != nil {
		t.Fatal("retirement retained coverage")
	}
}
