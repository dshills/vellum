// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"bytes"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"github.com/go-text/typesetting/font/opentype"
	"golang.org/x/image/math/fixed"
	"image"
	"image/color"
	"image/draw"
	"reflect"
	"testing"
)

func coverageSmallItem() *render.Text {
	shaper := shapedgt.NewShaperWithFonts(fonts.Embedded)
	uc := units.Context{}
	uc.Defaults()
	ts := text.NewStyle()
	ts.FontSize = units.Dot(8)
	ts.WhiteSpace = text.WrapNever
	ts.ToDots(&uc)
	src := rich.NewText(rich.NewStyle(), []rune("0123456789"))
	runs := shaper.Shape(src, ts)
	lines := &shaped.Lines{Source: src, Color: color.NRGBA{R: 31, G: 77, B: 119, A: 193}, Lines: []shaped.Line{{Runs: runs}}}
	c := &render.Context{}
	c.Init(styles.NewPaint(), &render.Bounds{Rect: math32.B2(0, 0, 256, 64)}, nil)
	return render.NewText(lines, styles.NewPaint(), c, math32.Vec2(8, 24))
}
func coverageGlyphPath(item *render.Text, pos math32.Vector2) Path {
	run := item.Text.Lines[0].Runs[0].(*shapedgt.Run)
	g := run.Glyphs[0]
	outline, _ := run.Face.GlyphDataOutline(g.GlyphID)
	scale := math32.FromFixed(run.Size) / float32(run.Face.Upem())
	var p Path
	for _, s := range outline.Segments {
		point := func(i int) fixed.Point26_6 {
			return math32.Vec2(s.Args[i].X*scale+pos.X, -s.Args[i].Y*scale+pos.Y).ToFixed()
		}
		switch s.Op {
		case opentype.SegmentOpMoveTo:
			p.Start(point(0))
		case opentype.SegmentOpLineTo:
			p.Line(point(0))
		case opentype.SegmentOpQuadTo:
			p.QuadBezier(point(0), point(1))
		case opentype.SegmentOpCubeTo:
			p.CubeBezier(point(0), point(1), point(2))
		}
	}
	p.Stop(true)
	return p
}
func coverageSeed(r *Renderer) {
	for i := range r.image.Pix {
		r.image.Pix[i] = byte(i*31 + 7)
	}
}
func coverageReference(r *Renderer, p Path, fill image.Image) {
	rf := &r.Raster.Filler
	rf.SetWinding(true)
	rf.SetColor(fill)
	p.AddTo(rf)
	rf.Draw()
	rf.Clear()
}
func TestVellumGlyphCoverageActualFixedPathParity(t *testing.T) {
	item := coverageSmallItem()
	r := New(math32.Vec2(8192, 64)).(*Renderer)
	original := New(math32.Vec2(8192, 64)).(*Renderer)
	positions := []math32.Vector2{{8, 24}, {16, 24}, {8, 32}, {8.015, 24}, {8.25, 24}, {8.984, 24}, {-1, 24}, {0, 24}, {8000.015, 24}, {8000.25, 24}, {8000.984, 24}}
	fills := []image.Image{image.NewUniform(color.NRGBA{31, 77, 119, 193}), image.NewUniform(color.RGBA{11, 29, 39, 71})}
	for round := 0; round < 3; round++ {
		for _, pos := range positions {
			for _, fill := range fills {
				coverageSeed(r)
				coverageSeed(original)
				clip := image.Rect(0, 0, 8192, 64)
				r.Scanner.SetClip(clip)
				original.Scanner.SetClip(clip)
				p := coverageGlyphPath(item, pos)
				r.Path = append(r.Path[:0], p...)
				if !r.drawGlyphCoverage(fill) {
					coverageReference(r, p, fill)
				}
				r.Path.Clear()
				coverageReference(original, p, fill)
				if !bytes.Equal(r.image.Pix, original.image.Pix) {
					t.Fatal("cold/warm coverage differs", round, pos)
				}
				if r.Scanner.UseNonZeroWinding != original.Scanner.UseNonZeroWinding || r.Scanner.A != original.Scanner.A || r.Scanner.Area != 0 || r.Scanner.Cover != 0 || len(r.Scanner.Cell) != 0 {
					t.Fatal("scanner state differs", round, pos)
				}
			}
		}
	}
	if r.glyphCoverage == nil || r.glyphCoverage.hits == 0 || r.glyphCoverage.count == 0 {
		t.Fatal("no real hit", r.glyphCoverage)
	}
}
func TestVellumGlyphCoverageClippedAndUnknownFallback(t *testing.T) {
	item := coverageSmallItem()
	r := New(math32.Vec2(256, 64)).(*Renderer)
	original := New(math32.Vec2(256, 64)).(*Renderer)
	p := coverageGlyphPath(item, math32.Vec2(8, 24))
	fill := image.NewUniform(color.NRGBA{31, 77, 119, 193})
	for _, clip := range []image.Rectangle{{}, image.Rect(0, 0, 0, 64), image.Rect(0, 0, 256, 0), image.Rect(10, 0, 256, 64), image.Rect(0, 20, 256, 64)} {
		coverageSeed(r)
		coverageSeed(original)
		r.Scanner.SetClip(clip)
		original.Scanner.SetClip(clip)
		r.Path = append(r.Path[:0], p...)
		if r.drawGlyphCoverage(fill) {
			t.Fatal("boundary/no-clip case unexpectedly cached", clip)
		}
		coverageReference(r, p, fill)
		coverageReference(original, p, fill)
		if !bytes.Equal(r.image.Pix, original.image.Pix) {
			t.Fatal("fallback pixels differ", clip)
		}
	}
	calls := 0
	custom := image.NewUniform(coveredDrawColor{&calls})
	r.Path = append(r.Path[:0], p...)
	r.Scanner.SetClip(r.image.Bounds())
	if r.drawGlyphCoverage(custom) || calls != 0 {
		t.Fatal("unknown fill cache hook", calls)
	}
}
func TestVellumGlyphCoveragePacketMatchesFreshAndHeld(t *testing.T) {
	r := New(math32.Vec2(256, 64)).(*Renderer)
	reference := New(math32.Vec2(256, 64)).(*Renderer)
	item := coverageSmallItem()
	var held *render.Text
	for _, pos := range []math32.Vector2{{8, 24}, {16, 24}, {8.25, 24}, {16.25, 24}, {8, 32}, {-1, 24}} {
		current := *item
		current.Position = pos
		commands := render.Render{&current}
		a, b := r.ScenePacket(commands), reference.vellumFreshScenePacket(commands)
		if a == nil || b == nil {
			t.Fatal("small actual glyph batch refused", pos)
		}
		ea, oka := a.Encode()
		eb, okb := b.Encode()
		if !oka || !okb || !reflect.DeepEqual(ea, eb) {
			t.Fatal("cached packet format/admission differs", pos)
		}
		pa, pb := image.NewRGBA(image.Rect(0, 0, 256, 64)), image.NewRGBA(image.Rect(0, 0, 256, 64))
		for i := range pa.Pix {
			pa.Pix[i] = byte(i * 11)
			pb.Pix[i] = pa.Pix[i]
		}
		if !a.Replay(pa) || !b.Replay(pb) || !bytes.Equal(pa.Pix, pb.Pix) {
			t.Fatal("cached/fresh packet pixels differ", pos)
		}
		if held != nil {
			old := r.ScenePacket(render.Render{held})
			fresh := reference.vellumFreshScenePacket(render.Render{held})
			x, _ := old.Encode()
			y, _ := fresh.Encode()
			if !reflect.DeepEqual(x, y) {
				t.Fatal("later cache work changed prior shape")
			}
		}
		held = &current
	}
	if r.glyphCoverage == nil || r.glyphCoverage.hits == 0 {
		t.Fatal("packet checks never used reuse")
	}
	r.Release()
	if r.glyphCoverage != nil {
		t.Fatal("retirement retained coverage")
	}
	_ = draw.Over
}
