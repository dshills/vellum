from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-render-probe')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
assert len(names)==9,names
sources={n:sha(R/n)for n in sorted(names)}
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources},indent=2)+'\n')
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
print('Nine-file bounded renderer/spec/report checkpoint staged')
