from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-large-data');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-macos-render-probe');O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-glyph-coverage')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
q=json.loads((R/'docs/reports/macos-glyph-coverage/records/qualification.json').read_text());assert q['result']=='REVIEWED_EXACT_GLYPH_COVERAGE'and q['prism_coverage_complete']and q['internal_review']=='APPROVED_SOURCE_AND_EVIDENCE'and not q['live_checks_run'];base=q['base_commit']
assert not git(R,'status','--porcelain')and not git(C,'status','--porcelain');assert git(C,'rev-parse','HEAD')==base
commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert all(expected.get(n)==h for n,h in q['sources'].items())
old=json.loads((P/'prepared-baseline.json').read_text());final=json.loads((P/'prepared-final-v2.json').read_text());assert len(old)==6204 and len(final)==6207 and prepared(C)==old and prepared(R)==final
O.mkdir(exist_ok=False,parents=True);start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'tracked_files':len(expected),'scope':'Owned stage56 exact small glyph coverage with intact pixels/packet/work/refusal; ninefile internal+Anthropic review, offscreen/race/vet/preparation/nativebuild checks. Native binary not launched. No nativeperformance or Mac acceptance; GPU remainsopt-in and live checks paused. Canonical normal prepare upgrades6204to6207 expectedleaves.'}
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
 with(O/'prepare.stdout').open('xb')as so,(O/'prepare.stderr').open('xb')as se:d=run_child(['python3','prepare.py'],cwd=C/'drivers/cogent',env=env,stdout=so,stderr=se,timeout=240)
 record['prepare_exit_code']=d.returncode;assert d.returncode==0
 record.update({'tracked_exact':all(sha(C/n)==h for n,h in expected.items()),'prepared_exact':prepared(C)==final,'prepared_files':len(prepared(C)),'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'archive_sha256':sha(C/'docs/reports/macos-glyph-coverage/records/evidence.tar.xz')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean'])and record['prepared_files']==6207 and record['archive_sha256']==q['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');(O/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
