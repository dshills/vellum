from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-render-probe')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
cp=json.loads((P/'checkpoint-source.json').read_text());assert cp['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='6ec7976d795a9f1017352121f64e58b21a59cff3';assert len(cp['sources'])==9 and all(sha(R/n)==h for n,h in cp['sources'].items())
old=json.loads((P/'prepared-baseline.json').read_text());final=json.loads((P/'prepared-final-v2.json').read_text());first=json.loads((P/'prepared-final.json').read_text());assert len(old)==6204 and len(final)==len(first)==6207
actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert actual==final
adoption=json.loads((P/'adoption-inputs-v2.json').read_text());expected=dict(old)
for n,h in adoption['outputs'].items():expected['upstream/'+n]=h
assert expected==final
checks={}
passing=['coverage-adoption-v2-race','coverage-focused-v3','coverage-existing-parity','source-base-image','source-candidate-profile-v4','matrix-v2-base','matrix-v2-candidate','final-prepare-v2','final-renderer-race-v2','final-renderer-vet-v2','final-adapter-race-v2','final-adapter-vet','final-native-contracts-v2','final-native-build','final-native-vet','final-portable-race-v2','final-preparation-tests-v2']
faults={'faulty-comparison':'fingerprint substituted for exact path','faulty-clip':'boundary/no-clip case unexpectedly cached','faulty-retirement':'resize retained coverage','faulty-work':'warm coverage bypassed original segment budget'}
for name in passing+list(faults):
 j=json.loads((P/(name+'.json')).read_text());assert j['exit_code']==(1 if name in faults else 0)and j['error']is None and not j['live_tests'] and not j['headless_gpu_requested']
 assert j['source_commit']==cp['base_commit']and j['source_delta_stable']and j['producer_sha256']==sha(P/'code_run.py')
 assert j['overlay_inputs_before']==j['overlay_inputs_after']
 for n,h in j['overlay_inputs_after'].items():assert sha(n)==h
 for channel in ['stdout','stderr']:assert j[channel+'_sha256']==sha(P/(name+'.'+channel))
 if name=='final-prepare-v2':assert j['prepared_before']==first and j['prepared_after']==final
 else:assert j['prepared_before']==j['prepared_after'] and j['prepared_after'] in [old,first,final]
 if name in faults:assert faults[name]in(P/(name+'.stdout')).read_text()
 checks[name]={'exit_code':j['exit_code'],'elapsed_seconds':j['elapsed_seconds'],'receipt_sha256':sha(P/(name+'.json')),'argv':j['argv']}
a=json.loads((P/'matrix-v2-base-pixels.json').read_text());b=json.loads((P/'matrix-v2-candidate-pixels.json').read_text());assert len(a)==48 and a==b
base=json.loads((P/'source-observation-base-image.json').read_text());candidate=json.loads((P/'source-observation-candidate-v4.json').read_text());assert base['visible_cells']==candidate['visible_cells']==400
for n in ['source_pixels_sha256','packet_bytes','encoded_bytes','packet_ops','command_types','commands','viewport','image_size']:assert base[n]==candidate[n]
summary={'result':'PASS_SCOPED_EXACT_GLYPH_COVERAGE','base_commit':cp['base_commit'],'sources':cp['sources'],'checks':checks,'prepared_before_files':6204,'prepared_after_files':6207,'six_reviewed_outputs_exact':True,'other_dependency_leaves_unchanged':True,'software_grid_frames_equal':48,'faulty_overlays_fail_intended_assertions':4,'native_build_sha256':sha(P/'window-cycle'),'native_build_launched':False,'live_checks_run':False,'live_testing_paused':True,'native_performance_gain_qualified':False,'fresh_endurance_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'gpu_default_enabled':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'producer_sha256':sha(__file__)}
with(P/'final-summary.json').open('x')as f:f.write(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['sources','checks']},indent=2))
