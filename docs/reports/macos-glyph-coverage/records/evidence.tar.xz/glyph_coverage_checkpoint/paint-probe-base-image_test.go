//go:build offscreen

package cogent

import (
	"bytes"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
	"image"
	"image/color"
	"image/draw"
	"os"
	"runtime/pprof"
	"testing"
	"time"
)

type paintProbeRenderer struct {
	render.Renderer
	last render.Render
}

func (p *paintProbeRenderer) Render(r render.Render) render.Renderer {
	p.last = r.Clone()
	p.Renderer.Render(r)
	return p
}

func paintProbeCovered(a, b *pimage.Params) bool {
	if a == nil || b == nil || a.Cmd != pimage.Draw || b.Cmd != pimage.Draw || a.Op != draw.Src || b.Op != draw.Over || a.Mask != nil || b.Mask != nil || a.Rect.Empty() || a.Rect != b.Rect || a.SourcePos != b.SourcePos {
		return false
	}
	known := func(x image.Image) (*image.Uniform, bool) {
		u, ok := x.(*image.Uniform)
		if !ok || u == nil {
			return nil, false
		}
		switch u.C.(type) {
		case color.RGBA, color.RGBA64, color.NRGBA, color.NRGBA64, color.Alpha, color.Alpha16, color.Gray, color.Gray16:
			return u, true
		}
		return nil, false
	}
	if _, ok := known(a.Source); !ok {
		return false
	}
	u, ok := known(b.Source)
	if !ok {
		return false
	}
	_, _, _, alpha := u.C.RGBA()
	return alpha == 65535
}

func TestCurrentGridPaintCostProbe(t *testing.T) {
	columns := make([]virtual.GridColumn, 20)
	for i := range columns {
		columns[i] = virtual.GridColumn{ID: fmt.Sprintf("c%d", i), Width: 96}
	}
	model, err := virtual.NewGrid(&nativeGridSource{rows: 10000, revision: 1}, columns, virtual.GridConfig{RowHeight: 12, HeaderHeight: 24, FrozenColumns: 2, OverscanRows: 2, OverscanColumns: 1, MaxCells: 4096}, virtual.GridViewport{Width: 768, Height: 624})
	if err != nil {
		t.Fatal(err)
	}
	a, err := app.New(app.Config{QueueCapacity: 64})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(a.Close)
	if err = a.Open(app.Window{
		ID: "one", Title: "Offscreen cost probe", Width: 1500, Height: 1250,
		View: func() ui.Node {
			return ui.Node{
				ID: "root", Kind: ui.Column,
				Style: ui.Style{Padding: ui.Some(ui.Insets{}), Gap: ui.Some(float32(0))},
				Children: []ui.Node{
					{ID: "title", Kind: ui.Label, Text: "Grid paint cost probe"},
					{ID: "data", Kind: ui.DataGrid, Grid: model, Style: ui.Style{
						Grow: ui.Some(float32(0)), MinSize: ui.Some(ui.Size{Width: 1299, Height: 1060}), MaxSize: ui.Some(ui.Size{Width: 1299, Height: 1060}),
					}},
				},
			}
		},
	}); err != nil {
		t.Fatal(err)
	}

	config := manualConfig(t, 7)
	config.LogicalDPI = 96
	config.Theme.Default.Typography = ui.Some(ui.Typography{Family: "Noto Sans", Size: 15})
	manual, err := NewManual(testContext, a, config)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if e := manual.Close(testContext); e != nil {
			t.Error(e)
		}
	})
	unitSettle(t, manual)
	var probe *paintProbeRenderer
	if err = a.Do(func() {
		sc := manual.implementation.find("one").state.body.Scene
		probe = &paintProbeRenderer{Renderer: sc.Renderer}
		sc.Renderer = probe
		_ = model.Scroll(0, 12)
		_ = a.Invalidate("one")
	}); err != nil {
		t.Fatal(err)
	}
	unitSettle(t, manual)
	if len(probe.last) == 0 {
		t.Fatal("no actual source paint captured")
	}
	g := gridInspection(t, a, model)
	visible := 0
	for _, c := range g.Cells {
		if !c.Bounds.Empty() {
			visible++
		}
	}
	if visible != 400 || g.Viewport.Width != 768 || g.Viewport.Height != 624 || g.Viewport.ScrollY != 12 {
		t.Fatalf("unexpected actual fixture cells%d viewport%+v", visible, g.Viewport)
	}
	seed := probe.Renderer.Image().(*image.RGBA)
	r := rasterx.New(math32.FromPoint(seed.Rect.Size())).(*rasterx.Renderer)
	r.Render(probe.last)
	if !bytes.Equal(seed.Pix, r.Image().(*image.RGBA).Pix) {
		t.Fatal("captured batch is not complete current source pixels")
	}
	counts := map[string]int{}
	covered := 0
	for i, x := range probe.last {
		counts[fmt.Sprintf("%T", x)]++
		if a, ok := x.(*pimage.Params); ok && i+1 < len(probe.last) {
			if b, ok := probe.last[i+1].(*pimage.Params); ok && paintProbeCovered(a, b) {
				covered++
			}
		}
	}
	packet := r.ScenePacket(probe.last)
	if packet == nil {
		t.Fatal("current plain grid batch refused GPU packet")
	}
	encoded, ok := packet.Encode()
	if !ok {
		t.Fatal("packet encode refused")
	}
	const rounds = 100
	times := map[string]int64{}
	for _, kind := range []string{} {
		f, e := os.OpenFile("/private/tmp/vellum-macos-render-probe/"+kind+".cpu", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if e != nil {
			t.Fatal(e)
		}
		if e = pprof.StartCPUProfile(f); e != nil {
			f.Close()
			t.Fatal(e)
		}
		start := time.Now()
		for range rounds {
			if kind == "cpu-raster" {
				r.Render(probe.last)
			} else {
				p := r.ScenePacket(probe.last)
				if p == nil {
					t.Fatal("warm capture refused")
				}
				if _, ok = p.Encode(); !ok {
					t.Fatal("warm encode refused")
				}
			}
		}
		times[kind] = time.Since(start).Nanoseconds()
		pprof.StopCPUProfile()
		if e = f.Close(); e != nil {
			t.Fatal(e)
		}
	}
	record := map[string]any{"result": "CAPTURED_CURRENT_OFFSCREEN_GRID_SOURCE", "visible_cells": visible, "viewport": g.Viewport, "image_size": seed.Rect.Size(), "source_pixels_sha256": fmt.Sprintf("%x", sha256.Sum256(seed.Pix)), "commands": len(probe.last), "command_types": counts, "covered_uniform_pairs": covered, "packet_ops": packet.Operations(), "packet_bytes": packet.Bytes(), "encoded_bytes": len(encoded.Ops) + len(encoded.Rows) + len(encoded.Refs) + len(encoded.Data), "packet_independent": packet.Independent(), "rounds_per_diagnostic": rounds, "diagnostic_total_ns": times, "scope": "Current procedural10000-row source,400clipped cells,complete source pixels equal; code-only CPU replay/packet profiles whilehumanuseshost. Not stored-data/native/frame/input/GPU/presentation/latency qualification."}
	f, e := os.OpenFile("/private/tmp/vellum-macos-render-probe/source-observation-base-image.json", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		t.Fatal(e)
	}
	if e = json.NewEncoder(f).Encode(record); e != nil {
		f.Close()
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
	t.Log(record)
}
