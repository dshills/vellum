from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-render-probe');D=R/'drivers/cogent/native/patches/glyphcoverage'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()) == {'drivers/cogent/native/patches/glyphcoverage/'+n for n in ['0056-exact-small-glyph-coverage.patch','original-hashes.json','output-hashes.json']}
assert subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R)==b''
assert json.loads((P/'matrix-comparison.json').read_text())['frames']==48
baseline=json.loads((P/'matrix-v2-candidate.json').read_text())['prepared_before']
assert len(baseline)==6204
(P/'prepared-baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
inputs={};outputs={};chunks=[];mapping={}
for target,source in json.loads((P/'coverage-adoption-v2-overlay.json').read_text())['Replace'].items():
 t=Path(target);s=Path(source);rel=t.relative_to(R/'drivers/cogent/build/upstream').as_posix();old=t.read_text()if t.exists()else'';new=s.read_text()
 inputs[rel]=sha(t)if t.exists()else None;outputs[rel]=sha(s);mapping[rel]=str(s)
 chunks.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if t.exists()else'/dev/null',tofile='b/'+rel,n=3))
D.mkdir(exist_ok=True)
patch=D/'0056-exact-small-glyph-coverage.patch';patch.write_text(''.join(chunks))
for name,data in [('original-hashes',inputs),('output-hashes',outputs)]: (D/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
manifest=R/'drivers/cogent/native/dependencies.json';d=json.loads(manifest.read_text());core=d['dependencies'][0];assert [int(Path(x['file']).name[:4]) for v in core['stages'] for x in v['patches']]==list(range(1,56))
core['stages'].append({'origin':'drivers/cogent/native/patches/glyphcoverage','inputs':'native/patches/glyphcoverage/original-hashes.json','outputs':'native/patches/glyphcoverage/output-hashes.json','patches':[{'file':'native/patches/glyphcoverage/'+patch.name,'sha256':sha(patch)}]})
manifest.write_text(json.dumps(d,indent=2)+'\n')
test=R/'drivers/cogent/prepare_test.py';s=test.read_text();assert s.count('list(range(1, 56))')==1;test.write_text(s.replace('list(range(1, 56))','list(range(1, 57))'))
(D/'README.md').write_text('''# Exact small glyph coverage reuse

Patch 0056 retains ordered 16-bit scanner spans after the existing Alpha glyph
cache declines a small static TrueType fill-only glyph. Original outline,
segment, coordinate and extent work charges run before lookup. Exact fixed-path
geometry, including fractional rounding, authorizes a hit; the fingerprint only
indexes candidates. Original owned spanners perform blending and packet emission.

Admission requires an identity transform, value uniform fill, clean owned scanner,
and a guarded hull fully inside the current target and nonempty clip. Unsupported
fonts, boundary cases, scroll recording and custom spanners retain ordinary routes.
Per renderer FIFO limits are 512 entries and 1 MiB of exact path/span array backing,
with 512 path values and 256 spans per entry. Metadata and transient recording are
outside this bound. Resize and Release drop storage. Entries own no fonts, images,
packets or builders. Existing owner serialization remains required.

Tests compare original pixels and encoded packets, budget refusal/fallback state,
held packet immutability, independent entry/byte eviction, detached backing, hash
collision refusal and scanner ownership. Four deliberately broken overlays prove
specific assertions. A 48-frame actual-driver software grid matrix matches full
composition at four DPI settings and fixed/variable row sizes.

New helper/tests are MIT; modified upstream files preserve their original notices.
Preparation checks original/output bytes and patch SHA256. This stage does not
qualify native frame targets or full Mac acceptance. GPU scene rendering remains
opt-in; live checks are paused while the human uses the computer.
''')
(P/'adoption-inputs.json').write_text(json.dumps({'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'patch_sha256':sha(patch),'inputs':inputs,'outputs':outputs,'overlay_mapping':mapping,'prepared_before_files':6204,'expected_prepared_after_files':6207},indent=2)+'\n')
print('Owned stage 56 created; six exact reviewed outputs; expected prepared count 6207')
