// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"cogentcore.org/core/colors"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/ppath"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx/scan"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/textpos"
	"github.com/go-text/typesetting/font"
	"image"
	"image/draw"
	"math"
	"reflect"
)

type sceneSpanner struct {
	builder *sceneplan.Builder
	source  image.Image
	op      int
}

func (s *sceneSpanner) SetColor(source image.Image) {
	if _, ok := sceneplan.Color(source); !ok {
		s.builder.Refuse()
		return
	}
	s.source = source
}
func (s *sceneSpanner) GetSpanFunc() scan.SpanFunc {
	if s.builder.Failed() {
		return func(int, int, int, uint32) {}
	}
	u, ok := s.source.(*image.Uniform)
	if !ok || u == nil {
		s.builder.Refuse()
		return func(int, int, int, uint32) {}
	}
	s.builder.BeginSpans(colors.AsRGBA(u.C), draw.Op(s.op))
	return s.builder.Span
}

// ScenePacket compiles a whole supplied batch before GPU submission. A supplied
// batch may be a partial widget repaint; Packet.Independent proves a full reset.
// Its scanner/Dasher are private so a refused capture cannot change fallback
// winding, clip, pending cells or pixels. Source/color hooks are preflighted first.
func (rs *Renderer) ScenePacket(commands render.Render) *sceneplan.Packet {
	if rs == nil || rs.image == nil {
		return nil
	}
	b := sceneplan.New(rs.image.Bounds())
	if b.Failed() || len(commands) > sceneplan.MaxOps {
		return nil
	}
	work := &sceneWorkBudget{remaining: sceneMaxWork, outlines: font.NewGlyphOutlineBudget(1<<20, 1<<20)}
	if !work.take(len(commands)) {
		return nil
	}
	for _, item := range commands {
		switch x := item.(type) {
		case *render.ContextPush, *render.ContextPop:
			if reflect.ValueOf(x).IsNil() {
				return nil
			}
		case *pimage.Params:
			if x == nil || x.Cmd != pimage.Draw || !sceneplan.Known(x.Source) || !sceneplan.Known(x.Mask) || sceneplan.Aliases(x.Source, rs.image) || sceneplan.Aliases(x.Mask, rs.image) {
				return nil
			}
		case *render.Path:
			if x == nil || !sceneColorOK(x.Context.Style.Fill.Color) || !sceneColorOK(x.Context.Style.Stroke.Color) || !sceneContextFinite(&x.Context) || !work.path(x.Path, x.Context.Cumulative, math32.Vector2{}, scenePathFactor(&x.Context)) {
				return nil
			}
		case *render.Text:
			if !work.text(x) {
				return nil
			}
		default:
			return nil
		}
	}
	spanner := &sceneSpanner{builder: b, op: int(rs.ImgSpanner.Op)}
	capture := &Renderer{size: rs.size, sceneRecord: b, sceneWork: work, outlineCache: rs.staticOutlines(), glyphCoverage: rs.glyphCoverageCache()}
	capture.Scanner = rs.borrowSceneScanner(spanner)
	defer rs.returnSceneScanner(capture.Scanner)
	capture.Raster = NewDasher(rs.image.Bounds().Dx(), rs.image.Bounds().Dy(), capture.Scanner)
	// NewDasher initializes nonzero winding; restore the captured value afterward.
	capture.Scanner.SetWinding(rs.Scanner.UseNonZeroWinding)
	for _, item := range commands {
		switch x := item.(type) {
		case *pimage.Params:
			b.Draw(x.Rect, x.Source, x.SourcePos, x.Mask, x.MaskPos, x.Op)
		case *render.Path:
			capture.RenderPath(x)
		case *render.Text:
			capture.RenderText(x)
		}
		if b.Failed() {
			return nil
		}
	}
	return b.Seal(capture.Scanner.UseNonZeroWinding)
}
func sceneContextFinite(c *render.Context) bool {
	for _, v := range []float32{c.Cumulative.XX, c.Cumulative.YX, c.Cumulative.XY, c.Cumulative.YY, c.Cumulative.X0, c.Cumulative.Y0, c.Bounds.Rect.Min.X, c.Bounds.Rect.Min.Y, c.Bounds.Rect.Max.X, c.Bounds.Rect.Max.Y, c.Style.Fill.Opacity, c.Style.Stroke.Opacity, c.Style.Stroke.Width.Dots, c.Style.Stroke.MiterLimit} {
		if math.IsNaN(float64(v)) || math.IsInf(float64(v), 0) || math.Abs(float64(v)) > 1<<20 {
			return false
		}
	}
	if len(c.Style.Stroke.Dashes) > 256 {
		return false
	}
	if c.Style.Stroke.Width.Dots < 0 || c.Style.Stroke.MiterLimit < 0 || !sceneScalar(c.Style.Stroke.Width.Dots*MeanScale(c.Cumulative)) || !sceneScalar(c.Style.Stroke.Width.Dots*MeanScale(c.Cumulative)*c.Style.Stroke.MiterLimit) {
		return false
	}
	scale := MeanScale(c.Cumulative)
	for _, v := range c.Style.Stroke.Dashes {
		effective := v * scale
		if !sceneScalar(v) || !sceneScalar(effective) || v < 0 || (v > 0 && effective < 1.0/64) {
			return false
		}
	}
	return true
}

// sceneMaxWork bounds aggregate source traversal and scanner preparation, not
// elapsed time. Packet bytes/spans have their separate Builder limits. Refusal
// selects unchanged CPU rendering; no source/color callbacks run in preflight.
const sceneMaxWork = 8 << 20
const sceneMaxItems = 64 << 10
const sceneMaxCoordinate = 1 << 16

type sceneWorkBudget struct {
	remaining int
	outlines  *font.GlyphOutlineBudget
}

func (w *sceneWorkBudget) take(n int) bool {
	if w == nil || n < 0 || n > w.remaining {
		return false
	}
	w.remaining -= n
	return true
}
func (w *sceneWorkBudget) product(a, b int) bool {
	if a < 0 || b < 0 || (a != 0 && b > w.remaining/a) {
		return false
	}
	return w.take(a * b)
}
func scenePathFactor(c *render.Context) int {
	factor := 1
	if c.Style.HasStroke() {
		scale := MeanScale(c.Cumulative)
		for _, v := range c.Style.Stroke.Dashes {
			if v > 0 {
				factor = max(factor, int(math.Ceil(1/float64(v*scale))))
			}
		}
	}
	return factor
}
func sceneColorOK(source image.Image) bool {
	_, ok := sceneplan.Color(source)
	return source == nil || ok
}
func sceneScalar(v float32) bool {
	return !math.IsNaN(float64(v)) && !math.IsInf(float64(v), 0) && math.Abs(float64(v)) <= sceneMaxCoordinate
}
func scenePoint(p math32.Vector2) bool { return sceneScalar(p.X) && sceneScalar(p.Y) }
func sceneBox(b math32.Box2, m math32.Matrix2, off math32.Vector2) bool {
	for _, p := range []math32.Vector2{b.Min, b.Max, math32.Vec2(b.Min.X, b.Max.Y), math32.Vec2(b.Max.X, b.Min.Y)} {
		if !scenePoint(p) || !scenePoint(m.MulPoint(p.Add(off))) {
			return false
		}
	}
	return true
}
func sceneRanges(rs []textpos.Range) bool {
	for _, r := range rs {
		if r.Start < 0 || r.End < r.Start || r.End > 1<<30 {
			return false
		}
	}
	return true
}
func (w *sceneWorkBudget) path(p ppath.Path, m math32.Matrix2, off math32.Vector2, factor int) bool {
	if len(p) > sceneMaxItems || !w.take(len(p)) {
		return false
	}
	var bounds math32.Box2
	points := 0
	for i := 0; i < len(p); {
		cmd := p[i]
		var n int
		switch cmd {
		case ppath.MoveTo, ppath.LineTo, ppath.Close:
			n = 4
		case ppath.QuadTo:
			n = 6
		case ppath.CubeTo:
			n = 8
		default:
			return false
		}
		if i+n > len(p) || p[i+n-1] != cmd || (i == 0 && cmd != ppath.MoveTo) {
			return false
		}
		for j := i + 1; j < i+n-1; j += 2 {
			v := math32.Vec2(p[j], p[j+1])
			q := m.MulPoint(v).Add(off)
			if !scenePoint(v) || !scenePoint(q) {
				return false
			}
			if points == 0 {
				bounds = math32.Box2{Min: q, Max: q}
			} else {
				bounds.ExpandByPoint(q)
			}
			points++
		}
		i += n
	}
	// Curve/stroke preparation is bounded even for paths mostly outside the clip.
	return w.product(points, factor*(1+int(bounds.Size().X)+int(bounds.Size().Y)))
}
func sceneOutlineFont(face *font.Face) bool { return face.SupportsBoundedOutlines() }
func (w *sceneWorkBudget) text(x *render.Text) bool {
	if x == nil || x.Text == nil || !sceneContextFinite(&x.Context) || !scenePoint(x.Position) || !scenePoint(x.Text.Offset) {
		return false
	}
	lns := x.Text
	if _, ok := sceneplan.Color(image.NewUniform(lns.Color)); !ok {
		return false
	}
	if !sceneColorOK(lns.SelectionColor) || !sceneColorOK(lns.HighlightColor) || len(lns.Lines) > sceneMaxItems || !w.take(len(lns.Lines)) {
		return false
	}
	var cells []shaped.Cell
	if x.Geometry != nil {
		cells = x.Geometry.Cells
		if len(cells) > sceneMaxItems || len(x.Geometry.Carets) > sceneMaxItems || len(x.Geometry.Lines) > sceneMaxItems || !w.take(len(cells)+len(x.Geometry.Carets)+len(x.Geometry.Lines)) {
			return false
		}
		last := -1
		for _, c := range cells {
			if c.Line < last || c.Line < 0 || c.Line >= len(lns.Lines) || !sceneRanges([]textpos.Range{c.Range}) || !sceneBox(c.Rect, x.Context.Cumulative, x.Position) {
				return false
			}
			last = c.Line
		}
	}
	cellAt := 0
	for li := range lns.Lines {
		ln := &lns.Lines[li]
		ranges := len(ln.Selections) + len(ln.Highlights)
		if len(ln.Runs) > sceneMaxItems || ranges > sceneMaxItems || !w.take(len(ln.Runs)+ranges) || !sceneRanges(ln.Selections) || !sceneRanges(ln.Highlights) {
			return false
		}
		off := x.Position.Add(lns.Offset).Add(ln.Offset)
		if !scenePoint(off) || !sceneBox(ln.Bounds, x.Context.Cumulative, off) {
			return false
		}
		start := cellAt
		for cellAt < len(cells) && cells[cellAt].Line == li {
			cellAt++
		}
		if !w.product(cellAt-start, ranges) {
			return false
		}
		for _, raw := range ln.Runs {
			run, ok := raw.(*shapedgt.Run)
			if !ok || run == nil || !sceneColorOK(run.Background) || !sceneColorOK(run.FillColor) || !sceneColorOK(run.StrokeColor) || !sceneBox(run.MaxBounds, x.Context.Cumulative, off) || len(run.Glyphs) > sceneMaxItems || !w.take(len(run.Glyphs)) {
				return false
			}
			if run.Output.Runes.Offset < 0 || run.Output.Runes.Count < 0 || run.Output.Runes.Offset > 1<<30-run.Output.Runes.Count {
				return false
			}
			if !sceneScalar(math32.FromFixed(run.Size)) || run.Size < 0 || !sceneScalar(run.Advance()) {
				return false
			}
			if run.Math.Path != nil {
				if !w.path(run.Math.Path, x.Context.Cumulative, off, 1) {
					return false
				}
			} else if len(run.Glyphs) > 0 && !sceneOutlineFont(run.Face) {
				return false
			}
			if (run.Math.Path != nil || run.Direction.IsVertical()) && !w.product(len(run.Glyphs), ranges) {
				return false
			}
			glyphOff := off
			// The renderer applies super/sub baseline offsets after the run background.
			sty := run.Font.Style(&x.Context.Style.Text)
			if sty.Special == rich.Super {
				glyphOff.Y -= .25 * math32.FromFixed(run.Size)
			} // rich.Super
			if sty.Special == rich.Sub {
				glyphOff.Y += .14 * math32.FromFixed(run.Size)
			} // rich.Sub
			for _, g := range run.Glyphs {
				for _, v := range []float32{math32.FromFixed(g.XOffset), math32.FromFixed(g.YOffset), math32.FromFixed(g.XBearing), math32.FromFixed(g.YBearing), math32.FromFixed(g.Width), math32.FromFixed(g.Height), math32.FromFixed(g.Advance)} {
					if !sceneScalar(v) {
						return false
					}
				}
				pos := glyphOff.Add(math32.Vec2(math32.FromFixed(g.XOffset), -math32.FromFixed(g.YOffset)))
				if !scenePoint(pos) || !scenePoint(x.Context.Cumulative.MulPoint(pos)) || !sceneBox(run.GlyphBoundsBox(&g), x.Context.Cumulative, glyphOff) {
					return false
				}
				if run.Direction.IsVertical() {
					glyphOff.Y -= math32.FromFixed(g.Advance)
				} else {
					glyphOff.X += math32.FromFixed(g.Advance)
				}
				if !scenePoint(glyphOff) {
					return false
				}
			}
			if run.Direction.IsVertical() {
				off.Y += run.Advance()
			} else {
				off.X += run.Advance()
			}
			if !scenePoint(off) {
				return false
			}
		}
	}
	return true
}
func (rs *Renderer) recordingFailed() bool {
	return (rs.scrollRecord != nil && rs.scrollRecord.failed) || (rs.sceneRecord != nil && rs.sceneRecord.Failed())
}
func (rs *Renderer) sceneTakeWork(n int) bool {
	if rs.sceneRecord == nil {
		return true
	}
	if rs.sceneRecord.Failed() || !rs.sceneWork.take(n) {
		rs.sceneRecord.Refuse()
		return false
	}
	return true
}
