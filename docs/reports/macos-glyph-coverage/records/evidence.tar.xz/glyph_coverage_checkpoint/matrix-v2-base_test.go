//go:build offscreen

package cogent

import (
	"cogentcore.org/core/math32"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
	"image"
	"os"
	"testing"
)

func TestCoverageActualGridMatrix(t *testing.T) {
	records := []map[string]any{}
	for _, dpi := range []float32{96, 120, 144, 192} {
		for _, variable := range []bool{false, true} {
			t.Run(fmt.Sprintf("dpi%g-variable%t", dpi, variable), func(t *testing.T) {
				columns := make([]virtual.GridColumn, 20)
				for i := range columns {
					columns[i] = virtual.GridColumn{ID: fmt.Sprintf("c%d", i), Width: 96}
				}
				var src virtual.GridSource = &nativeGridSource{rows: 10000, revision: 1}
				rowHeight := 12
				if variable {
					src = &variableNativeSource{rows: 10000, revision: 1}
					rowHeight = 1
				}
				model, err := virtual.NewGrid(src, columns, virtual.GridConfig{RowHeight: rowHeight, HeaderHeight: 24, FrozenColumns: 2, OverscanRows: 2, OverscanColumns: 1, MaxCells: 4096}, virtual.GridViewport{Width: 768, Height: 624})
				if err != nil {
					t.Fatal(err)
				}
				a, err := app.New(app.Config{QueueCapacity: 64})
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(a.Close)
				if err = a.Open(app.Window{ID: "one", Title: "Software grid matrix", Width: 1500, Height: 1250, View: func() ui.Node {
					return ui.Node{ID: "root", Kind: ui.Column, Style: ui.Style{Padding: ui.Some(ui.Insets{}), Gap: ui.Some(float32(0))}, Children: []ui.Node{{ID: "title", Kind: ui.Label, Text: "Exact coverage grid matrix"}, {ID: "data", Kind: ui.DataGrid, Grid: model, Style: ui.Style{Grow: ui.Some(float32(0)), MinSize: ui.Some(ui.Size{Width: 1299, Height: 1060}), MaxSize: ui.Some(ui.Size{Width: 1299, Height: 1060})}}}}
				}}); err != nil {
					t.Fatal(err)
				}
				config := manualConfig(t, 7)
				config.LogicalDPI = dpi
				config.Theme.Default.Typography = ui.Some(ui.Typography{Family: "Noto Sans", Size: 15})
				manual, err := NewManual(testContext, a, config)
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(func() {
					if e := manual.Close(testContext); e != nil {
						t.Error(e)
					}
				})
				unitSettle(t, manual)
				for frame, step := range []image.Point{{0, 12}, {3, 2}, {-3, -2}, {96, 12}, {-96, -12}, {0, -12}} {
					if err = a.Do(func() {
						if e := model.Scroll(step.X, step.Y); e != nil {
							t.Error(e)
						}
						_ = a.Invalidate("one")
					}); err != nil {
						t.Fatal(err)
					}
					unitSettle(t, manual)
					pixels, err := manual.Capture(testContext, "one")
					if err != nil {
						t.Fatal(err)
					}
					g := gridInspection(t, a, model)
					visible := 0
					for _, c := range g.Cells {
						if !c.Bounds.Empty() {
							visible++
						}
					}
					if visible == 0 || visible > 4096 {
						t.Fatal("bad actual density", visible)
					}
					records = append(records, map[string]any{"dpi": dpi, "variable": variable, "frame": frame, "pixels_sha256": fmt.Sprintf("%x", sha256.Sum256(pixels.Pix)), "image_bounds": pixels.Rect, "grid_bounds": g.Bounds, "scale": g.Scale, "viewport": g.Viewport, "visible_cells": visible, "cell_pool": len(g.Cells)})
				}
			})
		}
	}
	if len(records) != 48 {
		t.Fatal("incomplete software matrix", len(records))
	}
	f, e := os.OpenFile("/private/tmp/vellum-macos-render-probe/matrix-v2-base-pixels.json", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		t.Fatal(e)
	}
	if e = json.NewEncoder(f).Encode(records); e != nil {
		f.Close()
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
	_ = math32.Identity2()
}
