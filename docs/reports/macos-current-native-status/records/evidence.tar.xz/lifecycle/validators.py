"""Load only hash-pinned pure historical predicates, never old producers."""
from pathlib import Path
from types import SimpleNamespace
import ast,base64,datetime,importlib.util,json,math
P=Path(__file__).resolve().parent

def selected(path,names,assigns=()):
    tree=ast.parse(path.read_bytes());parts=[];found=[]
    for node in tree.body:
        if isinstance(node,ast.FunctionDef)and node.name in names:parts.append(node);found.append(node.name)
        elif isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)and node.targets[0].id in assigns:parts.append(node);found.append(node.targets[0].id)
    if sorted(found)!=sorted([*names,*assigns]):raise ValueError('exact unique pure validator definitions')
    return ast.Module(body=parts,type_ignores=[])

def load(sdk,need):
    env={'math':math,'base64':base64}
    path=P/'validator-sources/plan.py';exec(compile(selected(path,{'number','rect','breadcrumb'},{'PLAN'}),str(path),'exec'),env)
    plan=SimpleNamespace(PLAN=env['PLAN'],rect=env['rect'])
    life={'need':need,'math':math,'plan':plan,'CASES':{'same-two':{'cycles':2,'every':1,'same_name':True,'heap_profile':None,'timeout_seconds':300}}}
    path=P/'validator-sources/lifecycle.py';exec(compile(selected(path,{'finite','terminal','composed_payload'}),str(path),'exec'),life)
    path=sdk/'scripts/native_activity.py';spec=importlib.util.spec_from_file_location('m4_current_api_activity',path);activity=importlib.util.module_from_spec(spec);spec.loader.exec_module(activity)
    soak={'datetime':datetime,'math':math,'need':need,'finite':life['finite'],'v':plan,'terminal':life['terminal'],'activity':activity}
    path=P/'validator-sources/payloads.py';exec(compile(selected(path,{'state','frame_contains','soak_payload'}),str(path),'exec'),soak)
    return life['composed_payload'],soak['soak_payload']

def events(data):
    if type(data)is not bytes or len(data)>64<<20:raise ValueError('bounded complete native stdout')
    def pairs(values):
        result={}
        for key,value in values:
            if key in result:raise ValueError('duplicate native JSON key')
            result[key]=value
        return result
    def invalid(value):raise ValueError('nonfinite JSON constant')
    result=[]
    for line in data.splitlines():
        if not line.strip():continue
        if len(result)>=100000:raise ValueError('bounded native event population')
        value=json.loads(line,object_pairs_hook=pairs,parse_constant=invalid)
        if type(value)is not dict:raise ValueError('native event object')
        result.append(value)
    return result
