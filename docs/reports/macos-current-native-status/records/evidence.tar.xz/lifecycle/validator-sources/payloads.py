"""Pure current payload checks; no process, build, window or GPU actions."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,math,re,sys
from cases import CASES
import plan as v
from lifecycle_payload import terminal,composed_payload
R=Path('/private/tmp/vellum-native-activity-current')
sys.path.insert(0,str(R/'scripts'))
def need(value,message):
 if not value:raise ValueError(message)
def finite(value):return type(value)in[int,float]and math.isfinite(value)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
activity=load('current_api_attempt_component',R/'scripts/native_activity.py')
benchmark=load('current_grid_diagnostic_component',R/'scripts/benchmark-grid.py')
def state(s,phase):
 return s['Title']=='Vellum composed idle soak'and s['Key']is False and len(s['Frame'])==4 and all(finite(v)for v in s['Frame'])and s['Frame'][2]>0 and s['Frame'][3]>0 and ((s['Miniaturized']is True and s['OcclusionVisible']is False)if phase=='minimized'else(s['Visible']is True and s['Miniaturized']is False and s['OcclusionVisible']is(phase!='occluded')))
def frame_contains(outer,inner):
 if len(outer)!=4 or len(inner)!=4 or not all(finite(v)for v in outer+inner):return False
 if not all(f[2]>0 and f[3]>0 and finite(f[0]+f[2])and finite(f[1]+f[3])for f in[outer,inner]):return False
 return outer[0]<=inner[0]and outer[1]<=inner[1]and outer[0]+outer[2]>=inner[0]+inner[2]and outer[1]+outer[3]>=inner[1]+inner[3]
def soak_payload(events,cfg,owned_pid):
 duration,quiet,settle,interval,timeout=(cfg[k]for k in ['duration','quiet','settle','interval','timeout_seconds'])
 mode='short'if quiet<60 else'eligible-requested'
 allowed={'vellum.native-action','vellum.composed-cycle','vellum.soak.transition','vellum.soak.phase','vellum.soak.phase-end','vellum.soak.sample','vellum.window-cycle.sample','vellum.window-soak.result'};need(all(e.get('event')in allowed for e in events),'event type')
 actions=[e for e in events if e['event']=='vellum.native-action'];cycles=[e for e in events if e['event']=='vellum.composed-cycle'];results=[e for e in events if e['event']=='vellum.window-soak.result'];memory=[e['sample']for e in events if e['event']=='vellum.window-cycle.sample'];samples=[e for e in events if e['event']=='vellum.soak.sample'];starts=[e for e in events if e['event']=='vellum.soak.phase'];ends=[e for e in events if e['event']=='vellum.soak.phase-end']
 need(len(actions)==33 and len(cycles)==len(results)==1 and all(a['window']=='soak'for a in actions),'native control counts')
 c=cycles[0];aa=c['native_actions'];need(aa==[a['action']for a in actions]and[(a['Target'],a['Kind'],a['Value'])for a in aa]==v.PLAN,'native action plan')
 for a in aa:need(a['OwnerAndNativeCompleted']is True and type(a['Attempts'])is int and type(a['Admissions'])is int and 1<=a['Admissions']<=a['Attempts']and finite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5.25 and a['NativeRole']and'FailureContext'not in a and'AttachmentRetirement'not in a,'completed action')
 need(c['cycle']==1 and c['native_action_plan']==2 and c['native_list_requests']==3 and c['native_canvas_selections']==2 and c['native_color_edits']==2 and c['native_breadcrumb_requests']==2 and c['native_tree_disclosures']==2 and c['tree_accessibility_rows']>0,'composed counts')
 need(all(c[k]is True for k in['native_list_rejected','native_breadcrumb_rejected','native_breadcrumb_truncated','native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])and c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and v.rect(c['root_screen_points'])and v.rect(c['density_clip_screen_points'])and c['full_p11_qualified']is False,'composed publication')
 phases=['visible','occluded','minimized','background'];need([e['phase']for e in starts]==[e['phase']for e in ends]==phases,'four ordered phases')
 need(all(e['event']=='vellum.native-action'for e in events[:33])and events[33]['event']=='vellum.composed-cycle','action prefix')
 cursor=34
 for phase in phases:
  transition=events[cursor];need(transition['event']=='vellum.soak.transition'and transition['phase']==phase and transition['observed']is True and transition['state_accepted']is True and transition['last_query_error']=='','observed accepted transition');cursor+=1
  target,cover=transition['target'],transition['cover'];need(state(target,phase)and cover['Title']=='Vellum cycle survivor','transition windows')
  stamp=datetime.datetime.fromisoformat(transition['observed_utc'].replace('Z','+00:00'));need(stamp.tzinfo is not None and stamp.utcoffset()==datetime.timedelta(0),'transition UTC')
  contains=frame_contains(cover['Frame'],target['Frame']);need(transition['cover_contains_target']is contains,'actual frame containment arithmetic')
  if phase=='occluded':need(contains and cover['Visible']is True and cover['Miniaturized']is False and cover['Opaque']is True and cover['Alpha']==1 and cover['Level']==target['Level']and 0<=cover['OrderedIndex']<target['OrderedIndex'],'opaque front cover contains strict occluded target')
  need(events[cursor]['event']=='vellum.soak.phase'and events[cursor]['phase']==phase,'phase start order');cursor+=1
  while events[cursor]['event']=='vellum.window-cycle.sample':
   need(events[cursor+1]['event']=='vellum.soak.sample'and events[cursor+1]['phase']==phase and events[cursor]['sample']==events[cursor+1]['forced_gc_memory'],'ordered memory/sample pair');cursor+=2
  need(events[cursor]['event']=='vellum.soak.phase-end'and events[cursor]['phase']==phase,'phase end order');cursor+=1
 need(cursor==len(events)-1 and events[cursor]['event']=='vellum.window-soak.result','terminal event order')
 for j,role in[(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton'),(27,'AXList'),(28,'AXList'),(29,'AXList'),(30,'AXButton'),(31,'AXButton')]:need(aa[j]['NativeRole']==role,'action native role')
 need(len(samples)==len(memory)>0 and memory==[s['forced_gc_memory']for s in samples],'sample/memory pairing')
 counts={};cpu={};commits=0;all_eligible=True
 for phase,start,end in zip(phases,starts,ends):
  ss=[s for s in samples if s['phase']==phase];need(ss and [s['sample']for s in ss]==list(range(1,len(ss)+1)),'sample sequence')
  need(start['requested_seconds']==duration/4 and end['samples']==len(ss)and finite(end['elapsed_seconds'])and end['elapsed_seconds']>=duration/4 and finite(end['process_cpu_seconds'])and end['process_cpu_seconds']>=0,'phase duration')
  for s in ss:
   need(state(s['start_state'],phase)and state(s['end_state'],phase),'observed phase state')
   elapsed,wall,used=s['elapsed_seconds'],s['wall_elapsed_seconds'],s['process_cpu_seconds'];need(all(finite(x)for x in[elapsed,wall,used,s['one_cpu_percent']])and elapsed>0 and wall>0 and used>=0,'CPU interval')
   need(abs(s['one_cpu_percent']-100*used/elapsed)<1e-8,'CPU arithmetic')
   eligible=quiet>=60 and elapsed>=60 and elapsed<=quiet+max(1,quiet/10)and abs(wall-elapsed)<=1
   need(s['cpu_60s_interval']is eligible and s['app_originated_wakeups_available']is False and s['present_count_available']is False and s['full_p11_qualified']is False,'measurement scope')
   utc0=datetime.datetime.fromisoformat(s['start_utc'].replace('Z','+00:00'));utc1=datetime.datetime.fromisoformat(s['end_utc'].replace('Z','+00:00'));need(abs((utc1-utc0).total_seconds()-wall)<.001,'wall interval')
   need(type(s['primary_paint_wakes'])is int and s['primary_paint_wakes']>=0,'paint counter')
   if phase=='background':commits+=1
   need(s['background_commits']==commits,'worker completion count')
   all_eligible=all_eligible and eligible
  need(end['background_commits']==commits,'phase worker count');counts[phase]=len(ss);cpu[phase]=[min(s['one_cpu_percent']for s in ss),max(s['one_cpu_percent']for s in ss)]
 need(commits==counts['background']and commits>0,'background work')
 result=results[0];need(events[-1]is result and result['result']=='PASS_NATIVE_WINDOW_SOAK'and result['requested_cycles']==result['completed_cycles']==1 and result['native_action_plan']==2 and result['composed_workspace']is True and result['dense_labels_per_composed_window']==1000 and result['samples']==memory,'final result')
 need(result['soak_config']=={k:int(n*1e9)for k,n in[('Duration',duration),('Quiet',quiet),('Settle',settle),('Interval',interval)]}and result['cooperative_timeout_seconds']==timeout and result['heap_profile_requested']is False,'soak config')
 need(result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20 and all(m['Completed']==0 and 0<m['HeapAlloc']<=512<<20 and 0<m['RSSBytes']<=1<<30 for m in memory),'sampled guards')
 need(all(result[k]is False for k in['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed'])and result['samples_after_forced_gc']is True and result['geometry_persistence_disabled_in_fixture']is True,'final scope');terminal(result['native_cleanup']);need(result['historical_id_tombstones_retained']is False and result['same_name_mode']is False and type(result['same_name_replacements_verified'])is int and result['same_name_replacements_verified']==0,'current lifetime scope')
 summary={'result':'COMPLETE_SCOPED_SOAK_TRACE','mode':mode,'overnight_qualified':False,'duration_requested_seconds':duration,'observed_phase_elapsed_seconds':sum(e['elapsed_seconds']for e in ends),'phase_samples':counts,'quiet_cpu_one_core_percent_ranges':cpu,'eligible_sixty_second_intervals':sum(s['cpu_60s_interval']for s in samples),'all_quiet_intervals_eligible':all_eligible,'sampled_idle_cpu_target_met':all_eligible and all(s['one_cpu_percent']<.5 for s in samples),'primary_paint_wakes_total':sum(s['primary_paint_wakes']for s in samples),'quiet_intervals_with_primary_paints':sum(s['primary_paint_wakes']>0 for s in samples),'background_commits':commits,'native_selector_actions':33,'total_attempts':sum(a['Attempts']for a in aa),'total_admissions':sum(a['Admissions']for a in aa),'native_cleanup':result['native_cleanup'],'owned_group_absence_confirmed':True,'full_idle_budget_qualified':False,'os_application_background_qualified':False,'continuously_observed_window_state_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'native_gpu_memory_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,'limits':['Window states are sampled at interval endpoints. Background names the allocating-worker phase; it does not certify OS application background.','Primary paints and framework API attempts are observed; app-wide OS wakeups and actual presents remain unavailable.','The native PASS labels fixture completion, separate from CPU eligibility and target attainment.','Forced-GC RSS/Go observations remain sampled safety checks, with no native/GPU attribution.']}

 native=[];previous=None
 for sample in samples:
  check=activity.validate_activity(sample,owned_pid);native.append(check)
  value=sample['framework_native_activity']
  if previous is not None:
   need(all(value['start'][key]>=previous['end'][key]for key in ['empty_event_post_attempts','surface_present_attempts']),'cross-interval counters decreased')
   need(activity._stamp(previous['end_read']['end_utc'])<=activity._stamp(value['start_read']['start_utc']),'cross-interval counter read order')
  previous=value
 summary.update(native_activity_samples=len(native),owned_process_id=owned_pid,empty_event_post_attempts_total=sum(x['empty_event_post_attempts_delta']for x in native),surface_present_attempts_total=sum(x['surface_present_attempts_delta']for x in native),actual_wakeups_qualified=False,actual_presentations_qualified=False,framework_api_attempts_available=True)
 return summary

def gpu_payload(text,expected):
 all_runs=re.findall(r'^=== RUN[ \t]+(\S+)$',text,re.M)
 all_passes=re.findall(r'^[ \t]*--- PASS: (\S+) ',text,re.M)
 need(all(name.split('/')[0]in expected for name in all_runs+all_passes),'unexpected native GPU test name')
 runs=[name for name in all_runs if '/'not in name]
 passes=[name for name in all_passes if '/'not in name]
 need(len(runs)==len(expected)and set(runs)==set(expected)and len(passes)==len(expected)and set(passes)==set(expected),'exact native GPU test run/pass set')
 need(sorted(all_runs)==sorted(all_passes),'native GPU subtest completion mismatch')
 need('\nPASS\n'in text and '--- SKIP:'not in text and '--- FAIL:'not in text,'native GPU skip/failure')
 return{'native_gpu_tests':expected,'native_gpu_tests_passed':len(expected),'native_gpu_tests_skipped':0,'physical_input_qualified':False,'performance_target_qualified':False}

def grid_payload(events,cfg):
 need(all(event.get('source_details')is True for event in events),'explicit diagnostic source mode')
 need(all(event.get('cpu_profile',False)is False and event.get('allocation_profile',False)is False and event.get('input_details',False)is False for event in events),'separate diagnostic mode')
 need(events[1].get('warmup')==cfg['warmup'],'configured grid warmup')
 samples=benchmark.validate_records(events,cfg['rows'],False,cfg['samples'],False,allow_source_details=True,gpu_scene_rendering=cfg['gpu_scene'])
 records=[record for sample in samples for record in sample['native_sample']['SourceDetails']['Records']]
 hosts=[record['SceneHost']for record in records if record['SceneHost']['Available']]
 if cfg['gpu_scene']:need(hosts,'GPU scene host observations missing')
 else:need(not hosts,'GPU host observations in CPU route')
 return{'rows':cfg['rows'],'samples':len(samples),'warmup':cfg['warmup'],'gpu_scene_requested':cfg['gpu_scene'],'diagnostic':True,'ordinary_warm_targets_qualified':False,'native_source_records':len(records),'scene_host_records':len(hosts),'scene_draws_accepted':sum(host['DrawAccepted']for host in hosts),'scene_fallbacks':sum(host['Fallback']for host in hosts),'input_write_attempts':sum(host['InputWriteAttempts']for host in hosts),'input_write_errors':sum(host['InputWriteErrors']for host in hosts),'logical_input_bytes':sum(host['LogicalInputBytes']for host in hosts),'queue_submit_attempts':sum(host['QueueSubmitAttempts']for host in hosts),'ui_work_ns':benchmark.distribution([sample['metrics']['ui_work_ns']for sample in samples]),'scene_host_ns':{name:benchmark.distribution([host[name]for host in hosts])for name in benchmark.SCENE_HOST_TIMES}if hosts else{},'native_service_cleanup_qualified':False,'actual_presentations_qualified':False}

def payload(text,cfg,owned_pid,case):
 if cfg['kind']=='gpu':return gpu_payload(text,cfg['expected_tests'])
 events=[]
 for line in text.splitlines():
  if not line.strip():continue
  need(line.startswith('{'),'non-JSON native stdout')
  value=json.loads(line);need(type(value)is dict,'JSON event object');events.append(value)
 need(events,'missing native events')
 if cfg['kind']=='lifecycle':return composed_payload(events,case)
 if cfg['kind']=='soak':return soak_payload(events,cfg,owned_pid)
 if cfg['kind']=='grid':return grid_payload(events,cfg)
 raise ValueError('unknown payload kind')
