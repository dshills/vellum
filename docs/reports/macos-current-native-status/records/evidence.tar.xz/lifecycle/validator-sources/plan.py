"""Independent raw-log validation; never imports a producer or launches native code."""
from pathlib import Path
import base64, datetime, hashlib, json, math, statistics, sys

P=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(name):return json.loads((P/name).read_text())
def require(value,why):
 if not value:raise ValueError(why)
def number(v):return type(v)in[int,float]and math.isfinite(v)
def rect(r):return type(r)is list and len(r)==4 and all(number(v)for v in r)and r[2]>0 and r[3]>0
def breadcrumb(item):return 'workspace-path/breadcrumb/item/'+base64.urlsafe_b64encode(item.encode()).decode().rstrip('=')
PLAN=[('check','set','false'),('switch','press',''),('toggle','press',''),('check','set','true'),('slider','set','37'),('number','increment',''),('radio','set','a'),('segment','set','b'),('selector','set','a'),('button','press',''),('disclosure','collapse',''),('disclosure','expand',''),('tabs','set','about'),('tabs','set','live'),('tabs','set','colors'),('color/color/red','set','12'),('color/color/hex','set','#3567B580'),('tabs','set','live'),('tree:b3V0bGluZQ:row:bjA','press',''),('tree:b3V0bGluZQ:row:bjA','collapse',''),('tree:b3V0bGluZQ:row:bjA','expand',''),('text','set','Cocoa composed edit'),('dialog-open','press',''),('dialog-close','press',''),(breadcrumb('home'),'press',''),(breadcrumb('models'),'press',''),('tabs','set','selections'),('component-list','set','last'),('component-list','set','a'),('component-list','set','last'),('selection-left','press',''),('selection-right','press',''),('tabs','set','live')]

