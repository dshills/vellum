"""Pure raw-log validation of current-source native lifecycle cases."""
from pathlib import Path
import hashlib,json,math,sys
import plan
from cases import CASES,ORDER
P=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def need(value,message):
 if not value:raise ValueError(message)
def finite(value):return type(value)in[int,float]and math.isfinite(value)

def terminal(state):
 need(all(state[k]is True for k in ['MainThread','CleanupObserved','CallbacksStopped']), 'terminal owner cleanup')
 need(state['WindowTitles']==[] and all(type(state[k])is int and state[k]==0 for k in ['NativeOutstanding','AccessibilityWindows','PendingCallbacks','MenuCallbacks','TrayCallbacks']), 'terminal registry cleanup')
 need(type(state['Windows'])is list, 'Cocoa inventory')
 for window in state['Windows']:
  need(window['Title']=='' and all(window[k]is False for k in ['Visible','Miniaturized','Key','OcclusionVisible']), 'inactive untitled Cocoa windows only')
  need(type(window['Frame'])is list and len(window['Frame'])==4 and all(finite(n)for n in window['Frame']) and min(window['Frame'][2:])>=0, 'Cocoa frame')
  need(window['IdentityAvailable']is True and type(window['WindowNumber'])is int and -(1<<63)<=window['WindowNumber']<(1<<63), 'sampled Cocoa identity availability')
  need(all(type(window[k])is str and len(window[k].encode('utf-8'))<=256 for k in ['WindowClass','ContentViewClass']), 'sampled Cocoa class bounds')
 need(all(type(state['FilePanels'][k])is int and state['FilePanels'][k]==0 for k in ['Tracked','Visible','Open','Save']), 'retired file panels')
 need(state['Menu']=={'Owned':False,'OriginalRestored':False,'TargetRetired':True,'OriginalCaptured':False,'Items':[]}, 'retired uncaptured menu; restoration unqualified')
 tray=state['Tray']
 need(all(tray[k]is False for k in ['Present','Visible','Template'])and tray['TargetRetired']is True and tray['Identity']==0 and tray['Items']==[] and all(tray[k]==''for k in ['Title','Tooltip','AccessibilityLabel'])and all(tray[k]==0 for k in ['ImageWidth','ImageHeight','PixelWidth','PixelHeight']), 'retired tray')

def composed_payload(events,case):
 v=plan
 cfg=CASES[case];count=cfg["cycles"];sample_at=[0]+list(range(cfg["every"],count+1,cfg["every"]))
 if sample_at[-1]!=count:sample_at.append(count)
 allowed=['vellum.native-action','vellum.composed-cycle','vellum.window-cycle.sample','vellum.window-cycle.result','vellum.window-lifetime']
 need(all(type(e)is dict and e.get('event')in allowed for e in events),'composed event type')
 cycles=[e for e in events if e['event']=='vellum.composed-cycle'];partials=[e for e in events if e['event']=='vellum.native-action'];results=[e for e in events if e['event']=='vellum.window-cycle.result'];samples=[e['sample']for e in events if e['event']=='vellum.window-cycle.sample']
 need(len(cycles)==count and len(partials)==count*33 and len(results)==1 and len(samples)==len(sample_at),'configured window event counts')
 need([c['cycle']for c in cycles]==list(range(1,count+1)),'cycle sequence')
 expected_order=['vellum.window-cycle.sample']
 for cycle in range(1,count+1):
  expected_order.extend(['vellum.native-action']*33+['vellum.composed-cycle']+(['vellum.window-lifetime']if cfg['same_name']else[]))
  if cycle in sample_at:expected_order.append('vellum.window-cycle.sample')
 expected_order.append('vellum.window-cycle.result')
 need([e['event']for e in events]==expected_order,'ordered action/cycle/sample events')
 for index,c in enumerate(cycles):
  need(c['native_action_plan']==2,'action plan version')
  need(all(c[k]is True for k in ['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible','native_list_rejected','native_breadcrumb_rejected','native_breadcrumb_truncated']),'composed owner publication predicates')
  need(c['native_list_requests']==3 and c['native_canvas_selections']==2 and c['native_color_edits']==2 and c['native_breadcrumb_requests']==2 and c['native_tree_disclosures']==2 and c['tree_accessibility_rows']>0,'control completion counts')
  need(c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and c['full_p11_qualified']is False and v.rect(c['root_screen_points'])and v.rect(c['density_clip_screen_points']),'dense workload/geometry')
  actions=c['native_actions'];need([(a['Target'],a['Kind'],a['Value'])for a in actions]==v.PLAN,'exact 33-action plan')
  pp=partials[index*33:(index+1)*33];need([p['action']for p in pp]==actions and all(p['window']==('native-cycle-reused'if cfg['same_name']else f'native-cycle-{index:04d}')for p in pp),'partial/full action consistency')
  for a in actions:
   need(type(a['Attempts'])is int and type(a['Admissions'])is int and 1<=a['Admissions']<=a['Attempts'],'admission counts')
   need(a['OwnerAndNativeCompleted']is True and type(a['NativeRole'])is str and a['NativeRole']and 'AttachmentRetirement'not in a and 'FailureContext'not in a and finite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5.25,'native completion/action wall guard')
  for j,role in [(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton'),(27,'AXList'),(28,'AXList'),(29,'AXList'),(30,'AXButton'),(31,'AXButton')]:need(actions[j]['NativeRole']==role,'required native role')
 result=results[0];need(events[-1]is result and result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['requested_cycles']==result['completed_cycles']==count and result['native_action_plan']==2,'terminal composed result')
 need(result['composed_workspace']is True and result['dense_labels_per_composed_window']==1000 and result['cooperative_timeout_seconds']==cfg['timeout_seconds'] and result['heap_profile_requested']is bool(cfg['heap_profile']),'terminal workload')
 need(all(result[k]is False for k in ['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed']),'scope flags')
 need(all(result[k]is True for k in ['samples_after_forced_gc','geometry_persistence_disabled_in_fixture']),'sample scope')
 need(samples==result['samples']and [s['Completed']for s in samples]==sample_at,'sample sequence')
 need(result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20,'memory safety guards')
 for s in samples:need(all(type(s[k])is int and s[k]>0 for k in ['HeapAlloc','RSSBytes','Goroutines'])and s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 and finite(s['ElapsedSeconds'])and s['ElapsedSeconds']>0,'sample values')
 need(all(a['ElapsedSeconds']<=b['ElapsedSeconds']for a,b in zip(samples,samples[1:])),'sample time ordering')
 need(result['historical_id_tombstones_retained']is False and result['same_name_mode']is cfg['same_name']and type(result['same_name_replacements_verified'])is int and result['same_name_replacements_verified']==(count-1 if cfg['same_name']else 0),'current lifetime contract')
 lifetimes=[e for e in events if e['event']=='vellum.window-lifetime']
 need(len(lifetimes)==(count if cfg['same_name']else 0),'lifetime event count')
 for index,event in enumerate(lifetimes):
  expected={'event':'vellum.window-lifetime','cycle':index+1,'window':'native-cycle-reused','prior_opening_checked':index>0,'old_references_refused':index>0,'old_native_resources_retired':index>0,'old_callbacks_absent_after_owner_barrier':index>0,'current_opening_retired':True,'current_native_resources_retired':True,'full_p11_qualified':False}
  need(event==expected and type(event['cycle'])is int and all(type(event[k])is bool for k in expected if type(expected[k])is bool),'exact sampled lifetime predicates')
 terminal(result['native_cleanup'])
 return {'cycles':count,'actions':count*33,'steps_per_cycle':33,'same_name':cfg['same_name'],'sampled_replacements_verified':result['same_name_replacements_verified'],'total_attempts':sum(a['Attempts']for c in cycles for a in c['native_actions']),'total_admissions':sum(a['Admissions']for c in cycles for a in c['native_actions']),'native_cleanup':result['native_cleanup'],'hidden_inactive_untitled_native_windows':len(result['native_cleanup']['Windows']),'zero_cocoa_windows_qualified':False,'menu_restoration_qualified':False,'sampled_go_heap_bytes':[min(s['HeapAlloc']for s in samples),max(s['HeapAlloc']for s in samples)],'sampled_rss_bytes':[min(s['RSSBytes']for s in samples),max(s['RSSBytes']for s in samples)],'queue_admissions_are_not_accepted_callbacks':True,'retry_cause_observed':False}

def validate(case):
 need(case in ORDER,'configured case')
 receipt=read(P/(case+'.json'));owned=read(P/(case+'-owned-process.json'))
 config=read(P/'native-configuration.json');review=read(P/'native-review.json')
 manifest=read(P/'binaries.json');build=read(P/'window.json');entry=manifest['outputs']['window']
 need(review['execution_ready']is True and review['unresolved_findings']==[], 'reviewed native execution')
 need(all(sha(P/name)==digest for name,digest in review['sources'].items()), 'review source identity')
 need(config['case_order']==ORDER and config['cases']==CASES and config['runtime_authorized']is True, 'closed configuration')
 need(all(sha(P/name)==digest for name,digest in config['inputs'].items()), 'configuration identity')
 need(receipt['schema']=='vellum-post-loop-native-run-v1'and receipt['case']==case and receipt['result']=='TERMINAL_NATIVE_CASE_OK', 'terminal native receipt')
 need(receipt['exit_code']==0 and receipt['error']is None and receipt['stop_reason']is None and receipt['cleanup_errors']==[] and receipt['stop_markers_at_exit']==[], 'native terminal errors')
 need(all(receipt[k]is True for k in ['direct_child_terminal','group_absence_confirmed','source_stable','artifacts_stable','logs_complete','native_application_executed','profile_ok']), 'terminal process observations')
 need(type(receipt['pid'])is int and receipt['pid']>0 and receipt['pid']==receipt['process_group']==owned['pid']==owned['process_group'], 'created process identity')
 need(owned['result']=='STARTED_NATIVE_CASE'and owned['native_application_executed']is True, 'launch receipt')
 need(receipt['native_lease']=={'path':'/private/tmp/vellum-macos-live-oct15.lock','acquired':True,'held_through_cleanup':True}, 'exclusive lease through cleanup')
 need(manifest['source_commit']==manifest['source_identity']['commit']==config['source_commit']==receipt['source_commit']=='ddd23c6ea06ef7baf1014a08c61d01601c059f36', 'current source commit')
 need(manifest['source_identity']==read(P/'source-identity.json') and len(manifest['source_identity']['tracked'])==4566 and len(manifest['source_identity']['prepared'])==6230, 'complete source association')
 for key,name in [('producer_sha256','run_native.py'),('review_sha256','native-review.json'),('configuration_sha256','native-configuration.json'),('binaries_manifest_sha256','binaries.json')]:
  need(receipt[key]==owned[key]==sha(P/name), 'receipt identity '+name)
 required=set(review['sources'])|{'native-review.json','native-configuration.json','binaries.json','window.json','window-go-version.txt','live-authorization.json'}
 need(receipt['pins']==owned['pins'] and set(receipt['pins'])==required and all(sha(P/name)==digest for name,digest in receipt['pins'].items()), 'complete launch input pins')
 need(receipt['build_receipt_sha256']==owned['build_receipt_sha256']==entry['build_receipt_sha256']==sha(P/'window.json'), 'build receipt')
 need(build['producer_sha256']==sha(P/'build.py')and build['result']=='PASS_CURRENT_SOURCE_NATIVE_COMPILE' and build['exit_code']==0 and build['error']is None and build['identity_stable']is True and build['identity_before']==build['identity_after']==manifest['source_identity'], 'compiled source association')
 need(entry['binary']==build['binary'] and entry['binary']['path']==str(P/'outputs/window')and receipt['binary_sha256']==owned['binary_sha256']==entry['binary']['sha256']==sha(P/'outputs/window')and entry['binary']['bytes']==(P/'outputs/window').stat().st_size, 'executed binary')
 need(entry['build_metadata_sha256']==build['metadata_sha256']==sha(P/'window-go-version.txt'), 'build metadata')
 for channel in ['stdout','stderr']:
  need(build['logs'][channel]['sha256']==sha(P/('window.'+channel)), 'build log '+channel)
  log=receipt['logs'][channel];path=P/(case+'.'+channel)
  need(log['sha256']==log['stream_sha256']==sha(path)and log['bytes']==path.stat().st_size, 'complete run log '+channel)
 need(receipt['argv']==owned['argv']==[entry['binary']['path'],*CASES[case]['args']] and receipt['watchdog_seconds']==owned['watchdog_seconds']==CASES[case]['watchdog_seconds'], 'fixed native invocation')
 need(receipt['cwd']==owned['cwd']==build['cwd']==str(Path('/Users/dshills/Development/projects/Vellum/drivers/cogent')), 'fixed native working directory')
 need(receipt['profile']is None, 'no diagnostic profile requested')
 need(receipt['predecessor']==owned['predecessor']=={'scheduling_policy':'independent_current_source_lifecycle_campaign','historical_failed_soak_not_qualified':True}, 'independent scheduling scope')
 expected_prior=set(ORDER[:ORDER.index(case)])
 need(set(receipt['prior_cases'])==expected_prior and receipt['prior_cases']==owned['prior_cases'], 'prior case set')
 for prior,item in receipt['prior_cases'].items():
  old=read(P/(prior+'.json'));saved=read(P/(prior+'-validation.json'))
  need(item['validation_sha256']==sha(P/(prior+'-validation.json'))and saved['result']=='PASS_SCOPED_NATIVE_CASE'and saved['run_receipt_sha256']==sha(P/(prior+'.json'))and item['fresh_group_absence']['observed_group']==old['process_group']and item['fresh_group_absence']['members']==[], 'validated retired prior case')
 group=receipt['group_observation']
 need(group['observed_group']==receipt['pid']and group['members']==[]and group['argv']==['ps','-axo','pid=,pgid=,stat=']and group['stdout_bytes']>0 and len(group['stdout_sha256'])==64, 'retired owned group observation')
 events=[]
 for line in (P/(case+'.stdout')).read_text().splitlines():
  if not line.strip():continue
  need(line.startswith('{'), 'non-JSON stdout')
  events.append(json.loads(line))
 details=composed_payload(events,case)
 return {'result':'PASS_SCOPED_NATIVE_CASE','case':case,'validator_sha256':sha(__file__),'run_receipt_sha256':sha(P/(case+'.json')),'review_sha256':sha(P/'native-review.json'),'configuration_sha256':sha(P/'native-configuration.json'),'source_commit':manifest['source_commit'],'binary_sha256':entry['binary']['sha256'],'raw_events':len(events),'elapsed_seconds':receipt['elapsed_seconds'],'physical_pointer_qualified':False,'continuous_lifetime_coverage':False,'cocoa_deallocation_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,**details}

if __name__=='__main__':
 case=sys.argv[1]
 try:result=validate(case)
 except Exception as error:result={'result':'FAILED_VALIDATION','error':{'type':type(error).__name__,'message':str(error)},'validator_sha256':sha(__file__)}
 with(P/(case+'-validation.json')).open('x')as stream:json.dump(result,stream,indent=2);stream.write('\n')
 print(json.dumps(result))
 sys.exit(1 if result['result']=='FAILED_VALIDATION'else 0)

