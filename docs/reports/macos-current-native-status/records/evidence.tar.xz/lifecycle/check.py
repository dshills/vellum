"""Headless checks only; never runs the window-cycle native main."""
from pathlib import Path
import importlib.util,json,signal,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('short_m4_controller',P/'controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);c=m.c
h=c.load('existing_m4_headless_guard',P.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py')
stopped=[False]
def flag(signum,frame):stopped[0]=True

def profile():return h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in[c.C,c.T,c.SDK,c.CORE_DATA,P/'reuse',P/'validator-sources'])
def logs(r,out):
    pins={}
    for channel,info in r['logs'].items():
        path=out/channel;c.need(path.stat().st_size==info['bytes']and c.sha(path)==info['sha256'],'complete raw headless logs');pins[str(path)]=c.sha(path)
    path=out/'owned.json';c.need(path.is_file()and not path.is_symlink(),'owned identity record');pins[str(path)]=c.sha(path)
    return pins

def phase(name):
    c.need(name in [m.CONTROLS,*m.PHASES],'fixed headless phase');b=m.configure();plan=m.input_plan(b);c.boundary(plan);c.B.mkdir(exist_ok=True)
    out=c.B/name;c.need(not out.exists()and not(c.B/(name+'.json')).exists(),'fresh check output')
    cwd=c.SDK/'drivers/cogent'
    if name==m.CONTROLS:command=[str(m.PYTHON),'-B','-m','unittest','-v','tests','finalize_metadata_test'];cwd=P
    else:
        if name=='settings':args=['test','-race','-count=1','-p=1','-tags=offscreen','-timeout=90s','./internal/nativefixture']
        elif name=='fixture-tests':args=['test','-v','-race','-count=1','-p=1','-tags=vellum_native_checks','-timeout=90s','./cmd/window-cycle-smoke']
        elif name=='vet':args=['vet','-p=1','-tags=vellum_native_checks','./cmd/window-cycle-smoke']
        else:args=['build','-p=1','-tags=vellum_native_checks','-o',str(c.B/'window-cycle-smoke'),'./cmd/window-cycle-smoke']
        command=['/bin/sh',str(c.HELPER),*args]
    pins={**plan['pins'],**{str(c.SDK/n):v for n,v in b['sdk_files'].items()},**{str(p):c.sha(p)for p in[c.GO,c.HELPER,m.PYTHON,Path(h.__file__),h.GUARD]}}
    stop=lambda:stopped[0]or(P/'stop-checks').exists();stable=lambda:all(c.sha(k)==v for k,v in pins.items())and not stop()
    c.need(out.parent.is_dir()and not out.exists(),'fresh existing headless log parent')
    r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile(),*command],cwd,out,stop,stable,timeout=120,limit=8<<20)
    r.update(direct_sdk_fixture_test=name=='fixture-tests',fixture_test_source_sha256=m.FIXTURE_TEST_SHA if name=='fixture-tests'else None,source_pins=pins,binding_sha256=c.sha(P/'binding.json'),native_fixture_executed=False,boundary_stable=False)
    try:c.boundary(plan);r['boundary_stable']=True
    except BaseException as e:r['boundary_error']={'type':type(e).__name__,'message':str(e)}
    if name=='compile'and c.passed(r)and r['boundary_stable']:
        r['binary']=c.file_record(c.B/'window-cycle-smoke',256<<20)
        r['metadata']=h.g.execute(['/usr/bin/sandbox-exec','-p',profile(),str(c.GO),'version','-m',r['binary']['path']],cwd,c.B/'metadata',stop,stable,timeout=120,limit=2<<20)
        try:c.boundary(plan)
        except BaseException as e:r['boundary_stable']=False;r['metadata_boundary_error']={'type':type(e).__name__,'message':str(e)}
    c.write(c.B/(name+'.json'),r);print(json.dumps({k:r[k]for k in ['exit_code','error','owned','boundary_stable']}))
    c.need(c.passed(r)and r['boundary_stable'],'headless phase failed')
    if name=='compile':c.need(c.passed(r['metadata']),'actual optimized build metadata failed')

def local_replacements(text,cwd):
    replacements={};dep=None
    for line in text.splitlines():
        if line.startswith('\tdep\t'):
            fields=line.split('\t');c.need(len(fields)>=4,'module metadata dep fields');dep=fields[2]
        elif line.startswith('\t=>\t'):
            fields=line.split('\t')
            c.need(dep is not None and dep not in replacements and len(fields)>=4 and fields[3]=='(devel)','unique attached local replacement')
            replacements[dep]=(cwd/fields[2]).resolve();dep=None
        else:dep=None
    return replacements

def finalize():
    b=m.configure();plan=m.input_plan(b);c.boundary(plan);c.need(not(c.B/'checks.json').exists(),'fresh summary')
    pins={};compiled=None
    for name in [m.CONTROLS,*m.PHASES]:
        path=c.B/(name+'.json');r=c.read(path)
        c.need(c.passed(r)and r['boundary_stable']is True and r['binding_sha256']==c.sha(P/'binding.json')and all(c.sha(k)==v for k,v in r['source_pins'].items()),'actual complete bound check '+name)
        c.need(r['direct_sdk_fixture_test']is(name=='fixture-tests')and r['fixture_test_source_sha256']==(m.FIXTURE_TEST_SHA if name=='fixture-tests'else None),'direct bound SDK fixture test source')
        pins.update(r['source_pins']);pins[str(path)]=c.sha(path);pins.update(logs(r,c.B/name))
        if name=='compile':compiled=r
    c.need(c.passed(compiled['metadata']),'genuine metadata');pins.update(logs(compiled['metadata'],c.B/'metadata'))
    text=(c.B/'metadata/stdout').read_text();settings={}
    for line in text.splitlines():
        if line.startswith('\tbuild\t'):
            key,_,value=line[len('\tbuild\t'):].partition('=');c.need(key not in settings,'duplicate build setting');settings[key]=value
    c.need(text.splitlines()[0].endswith(': go1.25.6')and settings.get('GOOS')=='darwin'and settings.get('GOARCH')=='arm64'and settings.get('CGO_ENABLED')=='1'and settings.get('-race')!='true'and 'offscreen'not in settings.get('-tags','')and 'vellum_native_checks'in settings.get('-tags','').split(',')and '-N'not in settings.get('-gcflags','')and '-l'not in settings.get('-gcflags',''),'optimized tagged native metadata')
    cwd=c.SDK/'drivers/cogent';c.need(Path(compiled['cwd'])==cwd,'actual SDK compilation cwd')
    replacements=local_replacements(text,cwd)
    expected={'cogentcore.org/core':c.SDK/'drivers/cogent/build/upstream','github.com/dshills/vellum':c.SDK,'github.com/go-text/typesetting':c.SDK/'drivers/cogent/build/typesetting',**{'github.com/oliverbestmann/webgpu/libs-'+osname:c.SDK/'drivers/cogent/build'/('libs-'+osname)for osname in ['android','darwin','ios','linux','windows']}}
    c.need(all(replacements.get(name)==root.resolve()for name,root in expected.items())and all(root==c.SDK or c.SDK in root.parents for root in replacements.values()),'actual SDK-only Core/typesetting/root/linker sources')
    binary=compiled['binary'];c.need(c.sha(binary['path'])==binary['sha256'],'binary changed');pins[binary['path']]=binary['sha256'];binary={**binary,'settings':settings}
    c.write(c.B/'checks.json',{'head':m.HEAD,'binding_sha256':c.sha(P/'binding.json'),'phases':[m.CONTROLS,*m.PHASES],'binary':binary,'inputs':pins,'direct_sdk_fixture_test':{'sdk_relative_target':m.FIXTURE_TEST_REL,'sha256':m.FIXTURE_TEST_SHA},'native_fixture_executed':False,'native_execution_ready':False})

if __name__=='__main__':
    previous={sig:signal.signal(sig,flag)for sig in [signal.SIGINT,signal.SIGTERM]}
    try:
        if sys.argv[1:]==['finalize']:finalize()
        elif len(sys.argv)==2:phase(sys.argv[1])
        else:raise ValueError('fixed headless phase')
    finally:
        for sig,handler in previous.items():signal.signal(sig,handler)
