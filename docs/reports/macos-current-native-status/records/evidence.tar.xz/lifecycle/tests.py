"""Synthetic/controller and retained-parser controls, not current native evidence."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy,datetime,hashlib,importlib.util,json,os,tempfile,unittest
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('m4_controls_controller',P/'controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);c=m.c

def old_events(scope):return [json.loads(line)for line in(P.parent/scope/'native/stdout').read_bytes().splitlines()if line.strip()]
def validators():
    m.configure()
    v=c.load('controlled_pure_predicates',P/'validators.py');return v.load(m.SDK,c.need)
def receipt(data):return {'created':True,'exit_code':0,'error':None,'observation_errors':[],'logs_complete':True,'pins_stable':True,'stop_at_exit':False,'owned':{'terminal':True,'group_absent':True,'errors':[]},'logs':{'stdout':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},'stderr':{'bytes':0,'sha256':hashlib.sha256(b'').hexdigest()}}}
class FakeHost:
    def __init__(self,failure=None):self.failure=failure;self.calls=[];self.finished=False;self.count=0
    def check_launch(self):pass
    def geometry(self):
        self.count+=1
        if self.failure=='geometry'and self.count==2:raise ValueError('geometry cleanup failed')
        return {'synthetic':True}
    def native(self,case,out):
        self.calls.append(case['id']);out.mkdir();data=b'{"synthetic_only":true}\n';(out/'stdout').write_bytes(data);(out/'stderr').write_bytes(b'');r=receipt(data)
        if self.failure=='native':r['exit_code']=1
        return r
    def validate(self,case,out,r):
        if self.failure=='validation':raise ValueError('synthetic validation refusal')
        return {'synthetic_only':True}
    def finish(self):self.finished=True

class Controls(unittest.TestCase):
    def test_retained_two_cycle_and_short_soak_records_are_parser_controls_only(self):
        life,soak=validators();v=life(old_events('macos-sdk-m4-preflight-f875857-v2'),'same-two');self.assertEqual(v['cycles'],2);self.assertEqual(v['actions'],66)
        old=c.read(P.parent/'macos-sdk-idle-preflight-f875857/result.json');s=soak(old_events('macos-sdk-idle-preflight-f875857'),m.SOAK,old['run']['pid']);self.assertEqual(s['eligible_sixty_second_intervals'],0);self.assertFalse(s['full_idle_budget_qualified']);self.assertFalse(s['actual_presentations_qualified'])
    def test_terminal_retains_all_classes_without_TUINS_whitelist(self):
        life,_=validators();events=old_events('macos-sdk-m4-preflight-f875857-v2');windows=events[-1]['native_cleanup']['Windows'];extra=copy.deepcopy(windows[0]);extra.update(WindowClass='VellumUnclassifiedWindow',ContentViewClass='VellumUnclassifiedView',WindowNumber=-1);windows.append(extra)
        result=life(events,'same-two');self.assertEqual(len(result['native_cleanup']['Windows']),len(windows));self.assertEqual(result['hidden_inactive_untitled_native_windows'],len(windows))
        windows[-1]['Visible']=True
        with self.assertRaises(ValueError):life(events,'same-two')
    def test_short_soak_refuses_wrong_owned_PID_and_incorrect_occlusion(self):
        _,soak=validators();events=old_events('macos-sdk-idle-preflight-f875857');pid=c.read(P.parent/'macos-sdk-idle-preflight-f875857/result.json')['run']['pid']
        with self.assertRaises(ValueError):soak(events,m.SOAK,pid+1)
        changed=copy.deepcopy(events);next(e for e in changed if e['event']=='vellum.soak.transition'and e['phase']=='occluded')['target']['OcclusionVisible']=True
        with self.assertRaises(ValueError):soak(changed,m.SOAK,pid)
    def test_expired_launch_window_does_not_cancel_an_active_owned_child(self):
        host=object.__new__(m.Host);host.plan={};host.runtime_pins={};host.lease=SimpleNamespace(held=lambda:True);host.signaled=[False];now=datetime.datetime.now(datetime.timezone.utc);host.start=now-datetime.timedelta(minutes=1);host.deadline=now-datetime.timedelta(seconds=1)
        with patch.object(c,'stable',return_value=True):self.assertTrue(host.inputs_stable());self.assertFalse(host.stopping());self.assertFalse(host.launch_stable())
    def test_signal_during_final_hash_scan_refuses_launch(self):
        host=object.__new__(m.Host);host.plan={};host.runtime_pins={};host.lease=SimpleNamespace(held=lambda:True);host.signaled=[False];now=datetime.datetime.now(datetime.timezone.utc);host.start=now-datetime.timedelta(seconds=1);host.deadline=now+datetime.timedelta(minutes=1)
        def scanned(plan):host.signaled[0]=True;return True
        with patch.object(c,'stable',scanned):self.assertFalse(host.launch_stable())
    def test_executor_rechecks_launch_hook_immediately_before_Popen(self):
        g=c.load('controlled_launch_executor',P/'reuse/executor.py');calls=[]
        def launch():calls.append(True);return len(calls)==1
        with tempfile.TemporaryDirectory()as root,patch.object(g.subprocess,'Popen')as popen:
            r=g.execute(['/not-executed'],P,Path(root)/'out',lambda:False,lambda:True,timeout=120,launch_stable=launch,stream_limits=(64<<20,4<<20))
            self.assertEqual(len(calls),2);popen.assert_not_called();self.assertFalse(r['created']);self.assertIsNotNone(r['error'])
    def test_asymmetric_stream_cap_refuses_overflow_using_fake_process_and_real_pipes(self):
        # Popen/retirement are mocked; no process is created, killed or inspected.
        g=c.load('controlled_stream_executor',P/'reuse/executor.py');pipes=[]
        for data in [b'ab',b'cdef']:
            read,write=os.pipe();os.write(write,data);os.close(write);pipes.append(os.fdopen(read,'rb',buffering=0))
        child=SimpleNamespace(pid=123456789,stdout=pipes[0],stderr=pipes[1],poll=lambda:0,wait=lambda timeout:0)
        retired={'created':True,'terminal':True,'group_absent':True,'exit_code':0,'errors':[]}
        try:
            with tempfile.TemporaryDirectory()as root,patch.object(g.subprocess,'Popen',return_value=child),patch.object(g,'retire',return_value=retired):
                out=Path(root)/'out';r=g.execute(['/synthetic-no-process'],P,out,lambda:False,lambda:True,timeout=120,stream_limits=(2,3))
                self.assertIsNotNone(r['error']);self.assertIn('log byte bound',r['error']['message']);self.assertEqual((out/'stderr').read_bytes(),b'cde');self.assertFalse(r['logs_complete'])
        finally:
            for pipe in pipes:pipe.close()
    def test_failures_preserve_raw_and_seal_campaign_without_later_case(self):
        for failure in ['native','validation','geometry']:
            with self.subTest(failure=failure),tempfile.TemporaryDirectory()as root:
                host=FakeHost(failure);path=Path(root);r=m.execute_cases({'cases':m.CASES},host,path);self.assertEqual(r['result'],'FAILED_OR_CANCELED');self.assertEqual(len(host.calls),1);self.assertTrue(host.finished)
                first=path/m.CASES[0]['id'];self.assertTrue((first/'sealed').exists());self.assertIn('retained_streams',c.read(first/'result.json'));self.assertFalse((path/m.CASES[1]['id']).exists());self.assertTrue((path/'result.json').exists());self.assertTrue((path/'stop-live').exists())
    def test_signal_during_final_boundary_refuses_success_without_launch_expiry(self):
        host=object.__new__(m.Host);host.plan={};host.runtime_pins={};host.lease=SimpleNamespace(held=lambda:True);host.signaled=[False]
        def boundary(plan):host.signaled[0]=True
        with patch.object(c,'boundary',boundary),patch.object(c,'stable',return_value=True):
            with self.assertRaisesRegex(ValueError,'canceled or changed'):host.finish()
    def test_final_observation_failure_still_preserves_campaign_and_stop(self):
        with tempfile.TemporaryDirectory()as root:
            host=FakeHost();host.finish=lambda:(_ for _ in()).throw(ValueError('final observation failed'))
            path=Path(root);r=m.execute_cases({'cases':m.CASES[:1]},host,path)
            self.assertEqual(r['result'],'FAILED_OR_CANCELED');self.assertIn('final_boundary_error',r)
            self.assertTrue((path/'result.json').exists());self.assertTrue((path/'stop-live').exists());self.assertTrue((path/m.CASES[0]['id']/'sealed').exists())
    def test_signal_handler_only_sets_flag(self):
        state=[False];handler=c.cancellation_handler(state);handler(2,None);handler(15,None);self.assertEqual(state,[True])

if __name__=='__main__':unittest.main(verbosity=2)
