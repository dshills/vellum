"""Two existing M4 preflights, direct child policy; no execution on import."""
from pathlib import Path
import collections,datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;X=P.parent
spec=importlib.util.spec_from_file_location('m4_reused_boundary',P/'reuse/primary.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.P=P;c.X=X;c.B=P/'builds';c.HELPER=X/'macos-app-examples/go-check';c.GUARD=X/'macos-sdk-native-238b3b6/run.py';c.SDK=P/'UNBOUND_SDK';c.HEAD=None;c.BINDING=None
SDK=P/'UNBOUND_SDK'
HEAD=None
INTERPRETER=c.read(P/'interpreter.json')
PYTHON=Path(INTERPRETER['path'])
CONTROLS='controls'
FIXTURE_TEST_REL='drivers/cogent/cmd/window-cycle-smoke/diagnostics_test.go'
FIXTURE_TEST_SHA='c970d1dd73e062bf7170f7e82f04d2545b84d8c05333a0f71f8a8d2b956cd0f1'
HUMAN_RETURN=P/'human-return'
SOAK={'duration':40,'quiet':1,'settle':1,'interval':5,'timeout_seconds':100}
CASES=[{'id':'same-two','argv':['-composed','-same-name','-cycles=2','-sample-every=1','-timeout=300s'],'watchdog_seconds':360},
       {'id':'short-four-state','argv':['-composed','-cycles=1','-sample-every=1','-timeout=100s','-soak=40s','-soak-quiet=1s','-soak-settle=1s','-soak-interval=5s'],'watchdog_seconds':480}]
PHASES=['settings','fixture-tests','vet','compile']

def configure():
    global SDK, HEAD
    c.need(sys.version_info>=(3,11)and Path(sys.executable).resolve()==PYTHON and c.sha(PYTHON)==INTERPRETER['sha256']and list(sys.version_info[:3])==INTERPRETER['version'],'fixed modern diagnostic interpreter')
    b=c.configure_binding();HEAD,SDK=c.HEAD,c.SDK
    record=c.read(P/'source-inputs.json');c.need(all(c.sha(k)==v for k,v in record['inputs'].items()),'reviewed source/provenance inputs')
    for rel in ['drivers/cogent/cmd/window-cycle-smoke/main.go','drivers/cogent/cmd/window-cycle-smoke/soak.go','drivers/cogent/cmd/window-cycle-smoke/interactions.go','drivers/cogent/internal/nativefixture/geometry.go','drivers/cogent/internal/nativefixture/geometry_test.go','drivers/cogent/native_window_snapshot.h','drivers/cogent/native_services_checks_darwin.m']:
        c.need(b['sdk_files'][rel]==c.sha(c.T/rel),'public helper/shared guard/native census differs from current SDK')
    contract=c.read(P/'fixture-test-contract.json');target=SDK/FIXTURE_TEST_REL;historical=Path(contract['preserved_corrected_test'])
    c.need(contract['sdk_relative_target']==FIXTURE_TEST_REL and contract['required_sha256']==FIXTURE_TEST_SHA,'fixed corrected SDK fixture contract')
    c.need(b['sdk_files'][FIXTURE_TEST_REL]==FIXTURE_TEST_SHA and c.sha(target)==FIXTURE_TEST_SHA and c.sha(c.T/FIXTURE_TEST_REL)==FIXTURE_TEST_SHA and c.sha(historical)==FIXTURE_TEST_SHA and target.read_bytes()==historical.read_bytes(),'exact reviewed corrected test shipped in fresh SDK/current source; no overlay fallback')
    return b

def source_files():
    files=[f for d in ['reuse','validator-sources']for f in(P/d).rglob('*')if f.is_file()or f.is_symlink()]
    files += [P/n for n in ['controller.py','check.py','tests.py','validators.py','README.md','headless-plan.json','source-inputs.json','finalize_metadata_test.py','interpreter.json','fixture-test-contract.json','binding-contract.json','refresh-baseline.json']]
    c.need(all(f.is_file()and not f.is_symlink()and f.stat().st_size<4<<20 for f in files),'fixed regular source files')
    return {str(f):c.sha(f)for f in files}

def approval():
    r=c.read(P/'source-controller-review.json')
    c.need(r['approved']is True and r['source_controller_ready']is True and r['unresolved_findings']==[]and all(c.sha(k)==v for k,v in r['inputs'].items()),'independent source/controller/controls approval')
    c.need(all(str(P/n)in r['inputs']for n in['controller.py','check.py','tests.py','validators.py','reuse/executor.py','interpreter.json','reuse/primary.py','fixture-test-contract.json','binding-contract.json']),'actual reviewed execution sources')
    c.need(str(PYTHON)in r['inputs']and r['inputs'][str(PYTHON)]==INTERPRETER['sha256'],'reviewed exact interpreter binary')
    return r

def input_plan(b):
    r=approval()
    runtime=[c.GO,c.HELPER,c.LEASE,PYTHON,c.T/'scripts/child_process.py',c.T/'scripts/sdk_environment.py',c.T/'scripts/native_archive.py']
    c.need(all(p.is_file()and not p.is_symlink()for p in runtime),'regular fixed runtime helpers')
    runtime_pins={str(p):c.sha(p)for p in runtime}
    return {'head':HEAD,'source':b['source'],'prepared':b['prepared'],'sdk':b['sdk_files'],'pins':{str(P/'binding.json'):c.sha(P/'binding.json'),**b['association_inputs'],**runtime_pins,**source_files(),str(P/'source-controller-review.json'):c.sha(P/'source-controller-review.json'),**r['inputs']}}

def bounded(path,limit):
    archive=c.load('m4_regular_input',c.T/'scripts/native_archive.py');stream,before=archive.regular_stream(path,limit)
    with stream:
        data=stream.read(before.st_size+1);c.need(len(data)==before.st_size,'short/growing native stream');archive.unchanged(stream,before)
    after=path.lstat();c.need((after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)==(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns),'native stream path changed')
    return data

def validate(case,output,receipt):
    raw={name:bounded(output/name,limit)for name,limit in [('stdout',64<<20),('stderr',4<<20)]}
    for name,data in raw.items():c.need({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==receipt['logs'][name],'validated raw bytes differ from owned complete log')
    c.need(not raw['stderr'],'native stderr requires review')
    module=c.load('m4_pure_validators',P/'validators.py');life,soak=module.load(c.SDK,c.need);events=module.events(raw['stdout'])
    value=life(events,'same-two')if case['id']=='same-two'else soak(events,SOAK,receipt['pid'])
    windows=value['native_cleanup']['Windows'];value['all_cocoa_windows']=windows;value['all_cocoa_window_count']=len(windows)
    value['cocoa_classes_sampled']=dict(collections.Counter(w['WindowClass']for w in windows))
    value['no_class_whitelist_or_window_exclusion']=True
    return value

class Host:
    def __init__(self,plan,start,deadline,lease,signaled):
        self.plan=plan;self.start=start;self.deadline=deadline;self.lease=lease;self.signaled=signaled
        self.g=c.load('m4_reused_owned_executor',P/'reuse/executor.py')
        self.runtime_pins={str(P/n):c.sha(P/n)for n in ['plan.json','controller-review.json','native-admission.json']}
    def runtime_stable(self):return all(c.sha(k)==v for k,v in self.runtime_pins.items())
    def stopping(self):return self.signaled[0]or HUMAN_RETURN.exists()or(P/'stop-live').exists()or not self.lease.held()
    def inputs_stable(self):return c.stable(self.plan)and self.runtime_stable()and self.lease.held()
    def launch_stable(self):
        # Expiry gates new launches only. The live child has its monotonic watchdog.
        return self.inputs_stable()and not self.stopping()and self.start<=datetime.datetime.now(datetime.timezone.utc)<self.deadline
    def check_launch(self):
        c.need(not self.stopping()and self.runtime_stable(),'live stop/lease/runtime guard');c.boundary(self.plan)
        c.need(self.launch_stable(),'post-scan launch deadline/stop/pins/lease')
    def finish(self):
        c.need(self.lease.held()and self.runtime_stable(),'lease/runtime through cleanup');c.boundary(self.plan)
        c.need(self.inputs_stable()and not self.stopping(),'canceled or changed during final observation')
    def geometry(self):return c.geometry_state()
    def native(self,case,out):
        self.check_launch()
        r=self.g.execute([self.plan['binary']['path'],*case['argv']],c.SDK/'drivers/cogent',out,self.stopping,self.inputs_stable,timeout=case['watchdog_seconds'],launch_stable=self.launch_stable,stream_limits=(64<<20,4<<20))
        c.write(out.parent/'native-command.json',r);return r
    def validate(self,case,out,r):return validate(case,out,r)

def execute_cases(plan,host,root):
    result={'result':'INCOMPLETE','cases':{},'completed':[],'native_executed':False,'error':None,'full_m4_qualified':False,'full_idle_qualified':False,'native_deallocation_qualified':False,'full_mac_qualified':False}
    try:
        for case in plan['cases']:
            host.check_launch();d={'result':'INCOMPLETE','error':None};result['cases'][case['id']]=d;directory=root/case['id'];directory.mkdir(mode=0o700);before=None
            try:
                before=host.geometry();d['geometry_before']=before;d['run']=host.native(case,directory/'native');result['native_executed']|=d['run']['created']
                c.need(c.passed(d['run']),'owned direct M4 child failed/canceled')
                d['validation']=host.validate(case,directory/'native',d['run']);d['result']='PASS_SCOPED_EXISTING_M4_PREFLIGHT'
            except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
            finally:
                try:d['geometry_after']=host.geometry();c.need(before==d['geometry_after'],'Core geometry changed')
                except BaseException as e:d.update(result='FAILED_OR_CANCELED',geometry_error={'type':type(e).__name__,'message':str(e)})
                try:
                    if d.get('run',{}).get('created'):
                        d['retained_streams']={name:c.file_record(directory/'native'/name,limit)for name,limit in [('stdout',64<<20),('stderr',4<<20)]}
                        c.need(all({k:info[k]for k in ['bytes','sha256']}==d['run']['logs'][name]for name,info in d['retained_streams'].items()),'raw stream changed during cleanup')
                except BaseException as e:d.update(result='FAILED_OR_CANCELED',stream_error={'type':type(e).__name__,'message':str(e)})
                (directory/'sealed').touch();c.write(directory/'result.json',d);c.need(d['result']=='PASS_SCOPED_EXISTING_M4_PREFLIGHT','first failure stops later case')
            result['completed'].append(case['id'])
        result['result']='PASS_TWO_SCOPED_M4_SHORT_PREFLIGHTS'
    except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
    finally:
        try:host.finish()
        except BaseException as e:result.update(result='FAILED_OR_CANCELED',final_boundary_error={'type':type(e).__name__,'message':str(e)})
        (root/'stop-live').touch();c.write(root/'result.json',result)
    return result

def admission(plan,review,record,now):
    c.need(plan['head']==HEAD and plan['cases']==CASES and plan['native_execution_ready']is False,'fixed unready short M4 plan')
    c.need(review['approved']is True and review['controller_ready']is True and review['unresolved_findings']==[]and review['plan_sha256']==c.sha(P/'plan.json')and all(c.sha(k)==v for k,v in review['inputs'].items()),'exact independently reviewed plan')
    c.need(record['execution_ready']is True and record['plan_sha256']==c.sha(P/'plan.json')and record['review_sha256']==c.sha(P/'controller-review.json'),'separate native admission')
    auth=record['human_authorization'];c.need(auth['desktop_available']is True and type(auth['message'])is str and 0<len(auth['message'])<=4096,'fresh explicit human availability')
    start=datetime.datetime.fromisoformat(record['not_before_utc']);end=datetime.datetime.fromisoformat(record['last_launch_utc'])
    c.need(start.tzinfo is not None and end.tzinfo is not None and start<=now<end and datetime.timedelta(0)<end-start<=datetime.timedelta(minutes=30),'fresh bounded prelaunch window')
    return start,end

def prepare():
    c.need(not(P/'plan.json').exists(),'fresh M4 plan');b=configure();plan=input_plan(b)
    summary=c.read(c.B/'checks.json');c.need(summary['head']==HEAD and summary['binding_sha256']==c.sha(P/'binding.json')and summary['phases']==[CONTROLS,*PHASES],'complete actual headless phases')
    for file,digest in summary['inputs'].items():c.need(c.sha(file)==digest,'headless proof drift');plan['pins'][file]=digest
    plan['pins'][str(c.B/'checks.json')]=c.sha(c.B/'checks.json');plan.update(cases=CASES,binary=summary['binary'],native_execution_ready=False,direct_native_policy='Existing reviewed RSS-compatible direct policy: no enforced IP/source/settings write denial. Process-local shared saver guard plus observed whole boundaries/geometry; no file permissions or OS settings changed.',scope='Exactly two short native M4 fixture preflights; no10min/1000cycles/8h/fullidle/nativeGPU/deallocation/fullMac qualification.')
    c.boundary(plan);c.write(P/'plan.json',plan);print(json.dumps({'plan_sha256':c.sha(P/'plan.json'),'native_execution_ready':False,'native_executed':False}))

def run():
    c.need(not any((P/n).exists()for n in ['started.json','result.json','stop-live','human-return']),'fresh unattempted scope')
    configure();plan=c.read(P/'plan.json');review=c.read(P/'controller-review.json');record=c.read(P/'native-admission.json');start,end=admission(plan,review,record,datetime.datetime.now(datetime.timezone.utc))
    lease_module=c.load('m4_shared_lease',c.LEASE);signaled=[False];previous={}
    try:
        for sig in [signal.SIGINT,signal.SIGTERM]:previous[sig]=signal.signal(sig,c.cancellation_handler(signaled))
        with lease_module.LiveLease()as lease:
            host=None
            try:
                host=Host(plan,start,end,lease,signaled);host.check_launch();c.write(P/'started.json',{'head':HEAD,'admission_sha256':c.sha(P/'native-admission.json'),'review_sha256':c.sha(P/'controller-review.json'),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});result=execute_cases(plan,host,P)
            except BaseException as e:
                if not(P/'result.json').exists():
                    result={'result':'FAILED_OR_CANCELED','native_executed':False,'cases':{},'completed':[],'full_m4_qualified':False,'error':{'type':type(e).__name__,'message':str(e)}}
                    try:
                        if host is not None:host.finish()
                    except BaseException as final:result['final_boundary_error']={'type':type(final).__name__,'message':str(final)}
                    (P/'stop-live').touch();c.write(P/'result.json',result)
                raise
            print(json.dumps({'result':result['result'],'native_executed':result['native_executed'],'full_m4_qualified':False}));c.need(result['result']=='PASS_TWO_SCOPED_M4_SHORT_PREFLIGHTS','M4 preflight failed')
    finally:
        for sig,handler in previous.items():signal.signal(sig,handler)

if __name__=='__main__':
    c.need(sys.argv[1:]in [['prepare'],['run']],'fixed phase');prepare()if sys.argv[1]=='prepare'else run()
