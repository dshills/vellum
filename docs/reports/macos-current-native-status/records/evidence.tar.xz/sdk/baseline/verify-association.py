from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
X=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts');W=X/'macos-sdk-post103';b=json.loads((W/'binding.json').read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
# Root supplies the independently observed actual binding/archive/manifest hashes and file count after genuine retention.
assert len(sys.argv)==5,'binding-sha256 archive-sha256 manifest-sha256 sdk-file-count required'
binding_expected,archive_expected,manifest_expected,count_raw=sys.argv[1:]
assert all(len(v)==64 and set(v)<=set('0123456789abcdef') for v in [binding_expected,archive_expected,manifest_expected])
assert count_raw.isdecimal() and 0<int(count_raw)<20000
file_count_expected=int(count_raw)
assert sha(W/'binding.json')==binding_expected
commit=read(X/'macos-busy-completion-integrated/commit-result.json');assert commit['head']==b['head']and commit['source_files']==b['source']and commit['prepared_files']==b['prepared']
plan=read(W/'plan.json');r=read(W/'result.json');admit=read(W/'admission.json');retained=read(W/'retention.json')
assert plan['source']=={'head':b['head'],'tracked':b['source'],'prepared':b['prepared']}and plan['source_commit']==r['source_commit']==b['head']
assert admit['approved']is True and admit['plan_sha256']==sha(W/'plan.json')
assert all(sha(k)==v for k,v in b['association_inputs'].items())
assert all(Path(k).is_file()and not Path(k).is_symlink()and sha(k)==v for k,v in plan['pins'].items())
source_proof={}
for root in [Path(b['canonical']),Path(b['candidate'])]:
 git=lambda *args:subprocess.check_output(['git',*args],cwd=root,timeout=30)
 assert git('rev-parse','HEAD').decode().strip()==b['head']and not git('status','--porcelain','-z')
 names=git('ls-files','-z').decode().split('\0')[:-1];assert 0<len(names)<20000
 actual={}
 for name in names:
  p=root/name;assert p.is_file()and not p.is_symlink()
  current=p.parent
  while current!=root:assert not current.is_symlink();current=current.parent
  actual[name]=sha(p)
 assert actual==b['source']
 prepared={}
 for name in ['upstream','typesetting']:
  base=root/'drivers/cogent/build'/name
  for p in base.rglob('*'):
   assert not p.is_symlink()
   if p.is_file():prepared[name+'/'+p.relative_to(base).as_posix()]=sha(p)
 assert prepared==b['prepared']
 source_proof[str(root)]={'head':b['head'],'clean':True,'tracked':len(actual),'prepared':len(prepared)}
assert r['result']=='PASS_PRIVATE_SDK_PACKAGE_RELOCATION'and r['error']is None and r['runtime_executed']is False and r['source_prepared_unchanged']is True
receipts={}
for name in ['package','relocation']:
 rr=read(W/(name+'-command.json'));assert r['commands'][name]==rr
 assert rr['created']and rr['exit_code']==0 and rr['error']is None and not rr['observation_errors'] and rr['logs_complete']and rr['pins_stable']and not rr['stop_at_exit']and rr['owned']['terminal']and rr['owned']['group_absent']and not rr['owned']['errors']
 for channel,record in rr['logs'].items():
  p=W/name/channel;assert p.stat().st_size==record['bytes']and sha(p)==record['sha256']
 receipts[name]={'receipt_sha256':sha(W/(name+'-command.json')),'seconds':rr['seconds'],'terminal':True,'owned_group_absent':True,'logs_verified':True}
assert read(W/'relocation/stdout')==r['relocation']
S=Path(b['sdk']);manifest=read(S/'SDK_MANIFEST.json');assert manifest['source']=={'clean':True,'commit':b['head']}and manifest['private_build']is True
assert {k:v for k,v in b['sdk_files'].items()if k!='SDK_MANIFEST.json'}==manifest['files']
files={}
for p in S.rglob('*'):
 assert not p.is_symlink()
 if p.is_file():files[p.relative_to(S).as_posix()]=sha(p)
assert files==b['sdk_files']==retained['files']and len(files)==retained['files_count']==file_count_expected
assert retained['sdk']==str(S)and retained['head']==b['head']and retained['sdk_manifest_sha256']==sha(S/'SDK_MANIFEST.json')and retained['checker_result_sha256']==sha(W/'result.json')and retained['native_executed']is False
archive=Path(r['archive']['path']);expected=archive_expected;assert sha(archive)==retained['archive_sha256']==r['archive']['sha256']==expected
# Public archive verification is byte/schema validation only; no extraction or Go checker rerun.
T=Path(b['candidate']);sys.path.insert(0,str(T/'scripts'));sp=importlib.util.spec_from_file_location('association_archive_checker',T/'scripts/check-sdk.py');checker=importlib.util.module_from_spec(sp);sp.loader.exec_module(checker)
verified=checker.verify_archive(archive,expected);assert verified['manifest']==manifest
import io,tarfile
with tarfile.open(fileobj=io.BytesIO(verified['_archive_bytes']),mode='r:gz') as tf:
 archived_manifest=tf.extractfile(verified['prefix']+'/SDK_MANIFEST.json').read()
assert archived_manifest==(S/'SDK_MANIFEST.json').read_bytes()
assert sha(S/'SDK_MANIFEST.json')==manifest_expected
assert sha(Path(b['go']['path']))==b['go']['sha256']=='9c35eaeb87fd3df884c3540b25f3556902c164d88afe8a88e62ceb819d0da211'
assert sha(S/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
for n in ['scripts/check-presentation.py','scripts/distribution-inventory.py','scripts/child_process.py','scripts/sdk_environment.py']:
 assert sha(S/n)==sha(T/n)==sha(Path(b['canonical'])/n)
out={'schema':1,'result':'PASS_INDEPENDENT_ACTUAL_POST103_SDK_ASSOCIATION','approved':True,'head':b['head'],'binding_sha256':sha(W/'binding.json'),'archive_sha256':expected,'sdk_manifest_sha256':sha(S/'SDK_MANIFEST.json'),'retention_sha256':sha(W/'retention.json'),'source_and_prepared':source_proof,'retained_sdk_files':len(files),'complete_archive_payload_and_manifest_verified':True,'complete_retained_file_map_matches_archive_manifest_and_binding':True,'all9association_inputs_and49plan_pins_match':len(b['association_inputs'])==9 and len(plan['pins'])==49,'owned_receipts':receipts,'current_SDK_validation_collector_and_process_scripts_match_C_T':True,'compiler_and_owned_native_archive_hashes_match':True,'findings':[],'native_admission':False,'native_executed':False,'Go_or_checker_processes_rerun':False,'binding_mutated':False,'archived_manifest_raw_bytes_match_retained_manifest':True,'scope':'Read-only actual source/archive/payload/receipt association. Existing full relocation checker outcomes verified from genuine retained receipts and raw logs; only public byte/schema archive verification called. Not public distribution approval or runtime/performance qualification.'}
(W/'association-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'review_sha256':sha(W/'association-review.json'),'sdk_files':len(files),'source':len(b['source']),'prepared':len(b['prepared']),'pins':len(plan['pins'])}))
