# Post empty-publication SDK templates — not executed

These three scripts minimally adapt the existing source103 private SDK package,
retention and independent association flow. No final HEAD/vector, binding, plan,
admission, package, retention or result is fabricated here. Do not import or run
these scripts before the final source checkpoint and independent execution review.

Only root supplies the genuine final clean commit receipt at
`artifacts/macos-empty-inactive-publication-integrated/commit-result.json` after
the joint review and separate commits. Its exact `head`, `source_files` and
`prepared_files` drive source validation; no source counts or expected final hash
are guessed. The fresh temporary root is
`/private/tmp/vellum-empty-publication-sdk-<actual7>`.

`build.py prepare` delegates to the unchanged reviewed SDK79 package controller,
overriding its source vector function with complete clean C/T/root-receipt parity.
It pins the three adapted scripts and actual commit receipt alongside the public
producer/checker scripts, fixed Go1.25.6 and owned source-built native archive.
`build.py run` still requires separately approved exact `plan.json`; it invokes
the unchanged public release producer and full relocation checker without
`--runtime`. No native application is launched.

After genuine package/relocation success, `retain.py` uses the current public
archive verifier/extractor, checks every retained manifest payload byte and clean
source identity, then writes the actual retention/binding records. The subsequent
association script requires root-observed binding/archive/manifest digests and
file count as arguments, rechecks full C/T source/prepared parity, genuine owned
receipts/log hashes, all retained SDK files and archive/manifest bytes, and the
pinned compiler/native archive. It reports observed pin counts rather than
reusing historical source103 counts. The successful association record is not
created by this preparation.

`baseline/` preserves the exact three original scripts. `template-delta.patch`
shows every edit: scope/commit/temp-root labels, association-checker plan pin and
removal of stale hardcoded association/pin-count metadata. The public producer,
relocation checker, ownership executor and source validation logic remain as in
the source103 template. `source-template-review.json` records syntax parsing and
source-level observations only; it is not execution admission or SDK evidence.

Before execution, root must freeze final source, review actual templates and
commit receipt, prepare the genuine plan, and obtain its separate headless
admission. Current103 SDKs/evidence remain untouched. No runtime, performance,
M4/M6/full-Mac, publication, signing or rights closure is asserted.
