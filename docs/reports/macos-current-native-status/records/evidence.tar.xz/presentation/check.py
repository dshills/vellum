"""Version existing headless controls/Go build checks; never launch a native app.

No binding is needed for synthetic controls. Every genuine Go phase requires the
root-supplied final clean source/fresh-SDK association in binding.json.
"""
from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current_presentation_controller',P/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
s=importlib.util.spec_from_file_location('existing_headless_guard',P.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
stopped=[False]
def flag(signum,frame):stopped[0]=True

def controls():
    c.need(not(P/'controls.json').exists(),'fresh synthetic controls')
    files=[P/n for n in['controller.py','tests.py','check.py','finalize_metadata_test.py','README.md','comparison-baseline.json','refresh-baseline.json']]+[c.T/n for n in['scripts/check-presentation.py','scripts/native_archive.py','scripts/child_process.py','scripts/sdk_environment.py','examples/loadedgrid/main.go','examples/loadedtree/main.go']]+[Path(h.__file__),h.GUARD,Path('/usr/bin/python3')]
    pins={str(f):c.sha(f)for f in files}
    pins.update(c.previous_evidence())
    env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'PYTHONDONTWRITEBYTECODE':'1'}
    profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in[c.C,c.T,c.OLD,c.PREVIOUS,c.FAILED,c.PRIOR,c.OLDER,c.LEGACY])
    stop=lambda:stopped[0]or(P/'stop-controls').exists()
    stable=lambda:all(c.sha(k)==v for k,v in pins.items())and not stop()
    r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/usr/bin/python3','-B',str(P/'tests.py')],P,P/'controls',stop,stable,timeout=60,limit=2<<20)
    r.update(source_pins=pins,native_executed=False,synthetic_only=True)
    c.write(P/'controls.json',r);print(json.dumps({k:r[k]for k in['exit_code','error','seconds','logs_complete','pins_stable','owned']}))
    c.need(c.passed(r),'synthetic controls failed; retain raw evidence')

def binding_plan(b):
    return {'head':c.HEAD,'source':b['source'],'prepared':b['prepared'],'sdk':b['sdk_files'],'pins':{str(P/'binding.json'):c.sha(P/'binding.json'),**b['association_inputs']}}

def go_check(name):
    c.need(name in['grid','tree','vet-grid','vet-tree','compile-grid','compile-tree','validator-tests'],'fixed known Go phase')
    b=c.configure_binding();plan=binding_plan(b);c.boundary(plan)
    out=c.B/name;c.B.mkdir(exist_ok=True)
    c.need(not(c.B/(name+'.json')).exists()and not out.exists(),'fresh bound check output')
    kind='tree'if name.endswith('tree')else'grid';cwd=c.SDK/'examples'/('loaded'+kind)
    if name in['grid','tree']:args=['test','-v','-race','-count=1','-p=1','-tags=offscreen','-timeout=4m','./...']
    elif name.startswith('vet'):args=['vet','-p=1','-tags=offscreen','./...']
    elif name.startswith('compile'):args=['build','-p=1','-o',str(c.B/('native-'+kind)),'.']
    else:args=None;cwd=c.SDK
    pins={str(c.SDK/n):v for n,v in b['sdk_files'].items()}
    pins.update(plan['pins']);pins.update({str(p):c.sha(p)for p in[P/'controller.py',P/'check.py',c.HELPER,c.GO,Path(h.__file__),h.GUARD]})
    profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in[c.C,c.T,c.SDK,c.CORE_DATA,c.OLD,c.PREVIOUS,c.FAILED,c.PRIOR,c.OLDER,c.LEGACY])
    stop=lambda:stopped[0]or(P/'stop-checks').exists()
    stable=lambda:all(c.sha(k)==v for k,v in pins.items())and not stop()
    command=['/bin/sh',str(c.HELPER),*args]if args is not None else['/usr/bin/python3','-B',str(c.SDK/'scripts/check_presentation_test.py'),'-v']
    r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,*command],cwd,out,stop,stable,timeout=330,limit=16<<20)
    r.update(source_pins=pins,binding_sha256=c.sha(P/'binding.json'),native_executed=False,actual_native_feedback=False,boundary_stable=False)
    try:c.boundary(plan);r['boundary_stable']=True
    except BaseException as error:r['boundary_error']={'type':type(error).__name__,'message':str(error)}
    if name.startswith('compile')and c.passed(r):
        binary=c.B/('native-'+kind);r['binary']=c.file_record(binary,256<<20)
        metadata=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,str(c.GO),'version','-m',str(binary)],cwd,c.B/(name+'-metadata'),stop,stable,timeout=60,limit=2<<20)
        r['build_metadata']=metadata
        if c.passed(metadata):(c.B/(name+'-build-info.txt')).write_bytes((c.B/(name+'-metadata')/'stdout').read_bytes())
    c.write(c.B/(name+'.json'),r);print(json.dumps({k:r[k]for k in['exit_code','error','seconds','logs_complete','pins_stable','owned','boundary_stable']}))
    c.need(c.passed(r)and r['boundary_stable'],'bound Go check failed')
    if name.startswith('compile'):c.need(c.passed(r['build_metadata']),'optimized build metadata failed')

def local_replacements(text,cwd):
    replacements={};dep=None
    for line in text.splitlines():
        if line.startswith('\tdep\t'):
            fields=line.split('\t');c.need(len(fields)>=4,'module metadata dep fields');dep=fields[2]
        elif line.startswith('\t=>\t'):
            fields=line.split('\t')
            c.need(dep is not None and dep not in replacements and len(fields)>=4 and fields[3]=='(devel)','unique attached local replacement')
            replacements[dep]=(cwd/fields[2]).resolve();dep=None
        else:dep=None
    return replacements

def finalize():
    b=c.configure_binding();plan=binding_plan(b);c.boundary(plan);entries={}
    c.need(not(c.B/'clean-native-builds.json').exists(),'fresh compiled-binary summary')
    for kind in['grid','tree']:
        name='compile-'+kind;path=c.B/(name+'.json');r=c.read(path)
        c.need(c.passed(r)and r['boundary_stable']and r['binding_sha256']==c.sha(P/'binding.json')and c.passed(r['build_metadata']),'genuine passing bound builds')
        c.need(all(c.sha(k)==v for k,v in r['source_pins'].items()),'bound build source drift')
        for stream,info in r['logs'].items():
            f=c.B/name/stream;c.need(c.sha(f)==info['sha256']and f.stat().st_size==info['bytes'],'raw compile log')
        for stream,info in r['build_metadata']['logs'].items():
            f=c.B/(name+'-metadata')/stream;c.need(c.sha(f)==info['sha256']and f.stat().st_size==info['bytes'],'raw optimized metadata log')
        metadata=c.B/(name+'-build-info.txt');c.need(c.sha(metadata)==r['build_metadata']['logs']['stdout']['sha256'],'metadata copy differs from executed Go output');text=metadata.read_text();settings={}
        for line in text.splitlines():
            if line.startswith('\tbuild\t'):
                key,_,value=line[len('\tbuild\t'):].partition('=');settings[key]=value
        c.need(text.splitlines()[0].endswith(': go1.25.6')and settings.get('GOOS')=='darwin'and settings.get('GOARCH')=='arm64'and settings.get('CGO_ENABLED')=='1'and settings.get('-race')!='true'and 'offscreen'not in settings.get('-tags',''),'optimized current compiler/native build settings')
        c.need('-N'not in settings.get('-gcflags','')and '-l'not in settings.get('-gcflags',''),'optimization disabled')
        c.need(Path(r['cwd']).resolve()==(c.SDK/'examples'/('loaded'+kind)).resolve(),'actual build working directory')
        replacements=local_replacements(text,Path(r['cwd']))
        for module,rel in [('cogentcore.org/core','drivers/cogent/build/upstream'),('github.com/dshills/vellum','.'),('github.com/dshills/vellum/drivers/cogent','drivers/cogent')]:
            c.need(replacements.get(module)==(c.SDK/rel).resolve(),'SDK module replacement missing '+module)
        binary=Path(r['binary']['path']);c.need(c.sha(binary)==r['binary']['sha256'],'compiled binary changed')
        entries[kind]={**r['binary'],'build_receipt':str(path),'build_receipt_sha256':c.sha(path),'build_metadata_sha256':c.sha(metadata),'compiler':'go1.25.6','build_settings':settings,'source_association':'Complete final clean source/prepared/fresh private SDK vectors and genuine compiler/owned-build receipts; external SDK source has no required VCS stamp.'}
    c.write(c.B/'clean-native-builds.json',{'source_commit':c.HEAD,'binding_sha256':c.sha(P/'binding.json'),'source_files':len(b['source']),'source_sha256':c.digest(b['source']),'prepared_files':len(b['prepared']),'prepared_sha256':c.digest(b['prepared']),'sdk_sha256':c.digest(b['sdk_files']),'native_executed':False,'native_launch_admitted':False,'binaries':entries})


if __name__=='__main__':
    previous={sig:signal.signal(sig,flag)for sig in[signal.SIGTERM,signal.SIGINT]}
    try:
        if sys.argv[1:]in[[],['controls']]:controls()
        elif sys.argv[1:]==['finalize-builds']:finalize()
        elif len(sys.argv)==2:go_check(sys.argv[1])
        else:raise ValueError('fixed headless phase')
    finally:
        for sig,handler in previous.items():signal.signal(sig,handler)
