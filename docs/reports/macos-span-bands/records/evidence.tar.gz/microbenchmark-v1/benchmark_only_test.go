package sceneplan
import("image";"image/color";"image/draw";"testing")
var rowBandBenchmarkSink *Packet

func BenchmarkVellumScenePlanSpanBandsTallTarget(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		builder := New(image.Rect(0, 0, 128, 4096))
		for path := 0; path < 400; path++ {
			builder.BeginSpans(color.RGBA{13, 31, 59, 255}, draw.Over)
			for row := 0; row < 12; row++ {
				builder.Span(1024+path%50*12+row, 0, 128, 65535)
			}
		}
		rowBandBenchmarkSink = builder.Seal(false)
		if rowBandBenchmarkSink == nil {
			b.Fatal("valid tall-target fixture refused")
		}
	}
}
