// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package sceneplan

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"unsafe"
)

// Builder is an originating-render-context-only construction object. Seal drops
// every borrowed lookup; retained packets hold only copied value colors/bytes.
type Builder struct {
	packet Packet
	failed bool
	masks  map[*image.Alpha]*image.Alpha
	stream *operation
}

func New(bounds image.Rectangle) *Builder {
	b := &Builder{packet: Packet{bounds: bounds, bytes: int(unsafe.Sizeof(Packet{}))}}
	if bounds.Min != (image.Point{}) || bounds.Empty() || bounds.Dx() > MaxDimension || bounds.Dy() > MaxDimension || bounds.Dx()*bounds.Dy() > MaxPixels {
		b.failed = true
	}
	return b
}
func (b *Builder) Failed() bool { return b.failed }
func (b *Builder) Refuse()      { b.failed = true }
func (b *Builder) reserve(n int) bool {
	if b.failed || n < 0 || n > MaxBytes-b.packet.bytes {
		b.failed = true
		return false
	}
	b.packet.bytes += n
	return true
}
func Color(source image.Image) ([4]uint32, bool) {
	var out [4]uint32
	u, ok := source.(*image.Uniform)
	if !ok || u == nil {
		return out, false
	}
	switch u.C.(type) {
	case color.RGBA, color.RGBA64, color.NRGBA, color.NRGBA64, color.Alpha, color.Alpha16, color.Gray, color.Gray16:
	default:
		return out, false
	}
	out[0], out[1], out[2], out[3] = u.C.RGBA()
	return out, true
}
func (b *Builder) add(o operation) {
	if b.failed || o.rect.Empty() {
		return
	}
	if len(b.packet.ops) == MaxOps || !b.reserve(int(unsafe.Sizeof(operation{}))) {
		b.failed = true
		return
	}
	if len(b.packet.ops) == 0 && o.rect == b.packet.bounds && (o.kind == Uniform && (o.op == draw.Src || o.color[3] == 65535)) {
		b.packet.independent = true
	}
	b.packet.ops = append(b.packet.ops, o)
}
func (b *Builder) flush() {
	if b.stream == nil {
		return
	}
	o := *b.stream
	b.stream = nil
	if o.rect.Empty() {
		return
	}
	b.packet.bytes -= (len(o.rows) - o.rect.Dy()) * int(unsafe.Sizeof([]span{}))
	o.rows = o.rows[o.rect.Min.Y:o.rect.Max.Y]
	// Compact each row to exactly its retained capacity; replacement transients
	// and the construction row index are accounted separately from owned packets.
	exact := make([][]span, len(o.rows))
	for i, row := range o.rows {
		exact[i] = make([]span, len(row))
		copy(exact[i], row)
	}
	o.rows = exact
	b.add(o)
}
func (b *Builder) BeginSpans(c color.RGBA, op draw.Op) {
	b.flush()
	if b.failed {
		return
	}
	if op != draw.Src && op != draw.Over {
		b.Refuse()
		return
	}
	r, g, bl, a := c.RGBA()
	if !b.reserve(b.packet.bounds.Dy() * int(unsafe.Sizeof([]span{}))) {
		return
	}
	b.stream = &operation{kind: Spans, op: op, color: [4]uint32{r, g, bl, a}, rows: make([][]span, b.packet.bounds.Dy())}
}
func (b *Builder) Span(y, x0, x1 int, alpha uint32) {
	if b.failed || b.stream == nil {
		return
	}
	if alpha > 65535 {
		b.failed = true
		return
	}
	if y < 0 || y >= b.packet.bounds.Dy() {
		return
	}
	x0 = max(0, x0)
	x1 = min(b.packet.bounds.Dx(), x1)
	if x0 >= x1 || alpha == 0 && b.stream.op == draw.Over {
		return
	}
	if !b.reserve(int(unsafe.Sizeof(span{}))) {
		return
	}
	b.stream.rows[y] = append(b.stream.rows[y], span{x0, x1, alpha})
	r := image.Rect(x0, y, x1, y+1)
	if b.stream.rect.Empty() {
		b.stream.rect = r
	} else {
		b.stream.rect = b.stream.rect.Union(r)
	}
}
func (b *Builder) ownMask(mask *image.Alpha) *image.Alpha {
	if mask == nil || !validAlpha(mask) {
		b.failed = true
		return nil
	}
	r := mask.Bounds()
	prior := b.masks[mask]
	if prior != nil && prior.Rect.Size() == r.Size() {
		same := true
		for y := 0; y < r.Dy(); y++ {
			if !bytes.Equal(prior.Pix[y*prior.Stride:][:r.Dx()], mask.Pix[mask.PixOffset(r.Min.X, r.Min.Y+y):][:r.Dx()]) {
				same = false
				break
			}
		}
		if same {
			return prior
		}
	}
	if !b.reserve(r.Dx()*r.Dy() + int(unsafe.Sizeof(image.Alpha{}))) {
		return nil
	}
	own := image.NewAlpha(image.Rectangle{Max: r.Size()})
	for y := 0; y < r.Dy(); y++ {
		copy(own.Pix[y*own.Stride:], mask.Pix[mask.PixOffset(r.Min.X, r.Min.Y+y):][:r.Dx()])
	}
	if b.masks == nil {
		b.masks = make(map[*image.Alpha]*image.Alpha)
	}
	b.masks[mask] = own
	return own
}
func validRect(r image.Rectangle) bool {
	return !r.Empty() && r.Dx() <= MaxDimension && r.Dy() <= MaxDimension && r.Min.X >= -1<<20 && r.Min.Y >= -1<<20 && r.Max.X <= 1<<20 && r.Max.Y <= 1<<20
}
func validImageLayout(r image.Rectangle, stride, length, bpp int) bool {
	if !validRect(r) || stride < r.Dx()*bpp || length < r.Dx()*bpp {
		return false
	}
	return r.Dy() == 1 || stride <= (length-r.Dx()*bpp)/(r.Dy()-1)
}
func validAlpha(a *image.Alpha) bool { return validImageLayout(a.Rect, a.Stride, len(a.Pix), 1) }
func validRGBA(a *image.RGBA) bool   { return validImageLayout(a.Rect, a.Stride, len(a.Pix), 4) }

// Known performs no image/color callback. It is also usable for full-source
// preflight before scanner or glyph-cache work begins.
func Known(source image.Image) bool {
	if _, ok := Color(source); ok {
		return true
	}
	switch s := source.(type) {
	case *image.RGBA:
		return s != nil && validRGBA(s)
	case *image.Alpha:
		return s != nil && validAlpha(s)
	}
	return source == nil
}
func overlaps(a, b []byte) bool {
	if len(a) == 0 || len(b) == 0 {
		return false
	}
	ap, bp := uintptr(unsafe.Pointer(unsafe.SliceData(a))), uintptr(unsafe.Pointer(unsafe.SliceData(b)))
	return ap < bp+uintptr(len(b)) && bp < ap+uintptr(len(a))
}
func Aliases(source image.Image, dst *image.RGBA) bool {
	if dst == nil {
		return false
	}
	switch s := source.(type) {
	case *image.RGBA:
		return s != nil && overlaps(s.Pix, dst.Pix)
	case *image.Alpha:
		return s != nil && overlaps(s.Pix, dst.Pix)
	}
	return false
}

// Draw preserves image/draw clipping and source/mask positions. Only uniform or
// RGBA sources and Alpha masks are currently accepted; unknown inputs refuse.
func (b *Builder) Draw(rect image.Rectangle, source image.Image, sp image.Point, mask image.Image, mp image.Point, op draw.Op) {
	b.flush()
	if sp.X < -1<<20 || sp.X > 1<<20 || sp.Y < -1<<20 || sp.Y > 1<<20 || mp.X < -1<<20 || mp.X > 1<<20 || mp.Y < -1<<20 || mp.Y > 1<<20 {
		b.failed = true
		return
	}
	if b.failed || (op != draw.Src && op != draw.Over) {
		b.failed = true
		return
	}
	if source == nil {
		if mask != nil {
			b.failed = true
		}
		return
	}
	if rect == (image.Rectangle{}) {
		rect = b.packet.bounds
	}
	original := rect
	rect = rect.Intersect(b.packet.bounds)
	if !validRect(original) {
		b.failed = true
		return
	}
	c, uniform := Color(source)
	var rgba *image.RGBA
	if !uniform {
		var ok bool
		rgba, ok = source.(*image.RGBA)
		if !ok || rgba == nil || !validRGBA(rgba) {
			b.failed = true
			return
		}
		rect = rect.Intersect(rgba.Rect.Add(original.Min.Sub(sp)))
	}
	var alpha *image.Alpha
	if mask != nil {
		var ok bool
		alpha, ok = mask.(*image.Alpha)
		if !ok || alpha == nil || !validAlpha(alpha) {
			b.failed = true
			return
		}
		rect = rect.Intersect(alpha.Rect.Add(original.Min.Sub(mp)))
	}
	if rect.Empty() {
		return
	}
	o := operation{rect: rect, kind: Uniform, color: c, op: op}
	if alpha != nil {
		own := b.ownMask(alpha)
		if own == nil {
			return
		}
		o.mask = own
		o.maskPos = mp.Add(rect.Min.Sub(original.Min)).Sub(alpha.Rect.Min)
		o.kind = Mask
	}
	if !uniform {
		if !b.reserve(rect.Dx()*rect.Dy()*4 + int(unsafe.Sizeof(image.RGBA{}))) {
			return
		}
		own := image.NewRGBA(image.Rectangle{Max: rect.Size()})
		sourcePoint := sp.Add(rect.Min.Sub(original.Min))
		for y := 0; y < rect.Dy(); y++ {
			copy(own.Pix[y*own.Stride:], rgba.Pix[rgba.PixOffset(sourcePoint.X, sourcePoint.Y+y):][:rect.Dx()*4])
		}
		o.image = own
		o.kind = Pixels
	}
	b.add(o)
}
func (b *Builder) Seal(winding bool) *Packet {
	b.flush()
	b.masks = nil
	if b.failed {
		return nil
	}
	exact := make([]operation, len(b.packet.ops))
	copy(exact, b.packet.ops)
	b.packet.ops = exact
	b.packet.winding = winding
	packet := b.packet
	b.packet = Packet{}
	b.failed = true // construction callbacks cannot mutate the sealed result
	return &packet
}
