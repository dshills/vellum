"""One bounded inert Go check between recorded native quiet intervals."""
from pathlib import Path
import datetime,hashlib,json,sys,time,subprocess
R=Path('/private/tmp/vellum-native-idle');P=Path(__file__).resolve().parent
S=Path('/private/tmp/vellum-macos-soak-cover')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
name=sys.argv[1];assert name in ['ingress-race-v1','ingress-race-stress-v1','regenerate-v1','no-join-control-v1','ingress-vet-v1','smoke-build-v1']
argv=['go','test','-race','-p=1','-count='+('50' if name=='ingress-race-stress-v1' else '1'),'-timeout=45s','./system/driver/base','./system/driver/desktop','-run','^TestVellum(MacIngress|MainQueueStop|MainQueueFailure|NativeEventLifecycle)']
if name=='regenerate-v1':argv=['python3','prepare.py']
if name=='no-join-control-v1':argv=['go','test','-race','-p=1','-count=1','-timeout=15s','-overlay='+str(P/'no_join_overlay.json'),'./system/driver/desktop','-run','^TestVellumMacIngressWaitFailureJoinsBeforeCleanup$']
if name=='ingress-vet-v1':argv=['go','vet','-p=1','./system/driver/base','./system/driver/desktop']
if name=='smoke-build-v1':argv=['go','build','-p=1','-trimpath','-o',str(P/'mainqueue-smoke'),'./cmd/mainqueue-smoke']
now=datetime.datetime.now(datetime.timezone.utc)
raw=(S/'soak-overnight.stdout').read_bytes();events=[json.loads(x)for x in raw.splitlines()]
last=[e for e in events if e.get('event')=='vellum.soak.sample'][-1]
end=datetime.datetime.fromisoformat(last['end_utc'].replace('Z','+00:00'))
next_start=end+datetime.timedelta(seconds=240)
assert last['phase']=='visible' and last['cpu_60s_interval'] and last['elapsed_seconds']>=60
assert 0<=(now-end).total_seconds()<90 and (next_start-now).total_seconds()>150,'outside admitted between-interval gap'
assert not(S/'soak-overnight.json').exists()
assert not any((Path('/private/tmp')/('vellum-macos-'+n)/'stop-live').exists()for n in ['listbox','composed-endurance','composed-soak','post-glyph-native','soak-occlusion','soak-cover'])
owned=json.loads((R/'drivers/cogent/native/patches/nativeidle/output-hashes.json').read_text())
def sources():
 selected={str(Path('drivers/cogent/build/upstream')/n):hashlib.sha256((R/'drivers/cogent/build/upstream'/n).read_bytes()).hexdigest()for n in owned}
 changed=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
 selected.update({n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in changed if (R/n).is_file()})
 return selected
env={**child_environment(runtime=False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off'}
record={'schema':'vellum-inert-gap-check-v1','producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'argv':argv,'cwd':str(R/('drivers/cogent' if name in ['regenerate-v1','smoke-build-v1'] else 'drivers/cogent/build/upstream')),'started_utc':now.isoformat(),'prior_quiet_sample':last,'next_expected_quiet_start':next_start.isoformat(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_before':sources(),'overlay_inputs':{str(f):hashlib.sha256(f.read_bytes()).hexdigest()for f in [P/'no_join_overlay.json',P/'no_join_mutant.go']}if name=='no-join-control-v1' else {},'native_or_gpu_context_requested':False,'exit_code':None,'error':None}
start=time.monotonic()
try:
 with(P/(name+'.stdout')).open('xb')as so,(P/(name+'.stderr')).open('xb')as se:
  record['exit_code']=run_child(argv,cwd=record['cwd'],env=env,stdout=so,stderr=se,timeout=90,log_limit_bytes=2<<20).returncode
except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 record.update({'elapsed_seconds':time.monotonic()-start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_after':sources()})
 record['source_stable']=record['source_before']==record['source_after']
 record['finished_before_next_quiet']=datetime.datetime.now(datetime.timezone.utc)<next_start
 for channel in ['stdout','stderr']:
  file=P/(name+'.'+channel);record[channel+'_sha256']=hashlib.sha256(file.read_bytes()).hexdigest()if file.exists()else None
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k]for k in ['started_utc','finished_utc','elapsed_seconds','exit_code','error','source_stable','finished_before_next_quiet']}))
expected_failure=name=='no-join-control-v1'
if expected_failure:
 assert record['exit_code']==1 and b'native loop returned before its ingress wake retired' in (P/(name+'.stdout')).read_bytes()
if (record['exit_code']!=0 and not expected_failure) or record['error']or not record['source_stable']or not record['finished_before_next_quiet']:sys.exit(1)
