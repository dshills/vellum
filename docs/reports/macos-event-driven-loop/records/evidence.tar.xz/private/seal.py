"""Seal the source-only event-loop checkpoint, including failed historical checks."""
from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-native-idle');D=R/'docs/reports/macos-event-driven-loop/records'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((P/'checkpoint-review-v2.json').read_text());provider=json.loads((P/'prism.json').read_text());execution=json.loads((P/'prism-execution.json').read_text())
assert review['prism_ready']and not review['unresolved_findings']
assert execution['exit_code']==0 and execution['error']is None and execution['sources_stable']
assert execution['sources']==review['sources']and all(sha(R/n)==h for n,h in review['sources'].items())
coverage=provider['coverage'];assert coverage['complete']and coverage['files']==11 and coverage['llmCalls']==coverage['chunks']==1
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert not any([provider['findings'],provider['discarded'],provider['suppressed'],coverage['excluded'],coverage['skipped'],coverage['truncatedBytes']])
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(review['sources'])
outputs=json.loads((R/'drivers/cogent/native/patches/nativeidle/output-hashes.json').read_text())
checks={}
for name in ['regenerate-v2','ingress-race-final-v1','ingress-vet-v2','smoke-build-v2','preparation-tests-v1']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_stable']and d['finished_before_next_quiet']
 assert all(d['source_before']['drivers/cogent/build/upstream/'+n]==h for n,h in outputs.items())
 assert all(sha(P/(name+'.'+c))==d[c+'_sha256']for c in ['stdout','stderr'])
 assert sha(P/'producers'/(d['producer_sha256']+'.py'))==d['producer_sha256']
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'elapsed_seconds':d['elapsed_seconds'],'exit_code':0,'source_stable':True,'finished_before_next_expected_quiet':True}
assert '-count=50'in json.loads((P/'ingress-race-final-v1.json').read_text())['argv']
negative=json.loads((P/'no-join-control-v1.json').read_text());assert negative['exit_code']==1 and negative['error']is None and b'native loop returned before its ingress wake retired'in(P/'no-join-control-v1.stdout').read_bytes()
oldvet=json.loads((P/'ingress-vet-v1.json').read_text());assert oldvet['exit_code']==1 and b'unkeyed fields'in(P/'ingress-vet-v1.stderr').read_bytes()
association=json.loads((P/'final-source-association.json').read_text());assert len(association['prepared'])==6229
assert all(association['prepared']['upstream/'+n]==h for n,h in outputs.items())
assert sha(Path(association['binary']['path']))==association['binary']['sha256']
assert association['binary']==json.loads((P/'smoke-build-v2.json').read_text())['binary']
assert not association['native_executed']
selected=[]
for f in sorted(P.rglob('*')):
 if not f.is_file()or'__pycache__'in f.parts:continue
 if f.suffix in ['.py','.json','.stdout','.stderr','.go']:
  assert not f.is_symlink();selected.append(f)
assert len(selected)<=100 and sum(f.stat().st_size for f in selected)<8<<20
D.mkdir(parents=True,exist_ok=True)
archive=D/'evidence.tar.xz';assert not archive.exists()
index=[]
with tarfile.open(archive,'x:xz',preset=3)as out:
 for f in selected:
  name='private/'+f.relative_to(P).as_posix();data=f.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0
  out.addfile(entry,io.BytesIO(data));index.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:xz')as source:
 members=source.getmembers();assert len(members)==len(index)
 for member,expected in zip(members,index):
  assert member.isfile()and member.name==expected['path']and member.size==expected['bytes']
  assert hashlib.sha256(source.extractfile(member).read()).hexdigest()==expected['sha256']
(D/'archive-index.json').write_text(json.dumps({'members':index,'executable_binaries_included':False,'uncompressed_bytes':sum(x['bytes']for x in index)},indent=2)+'\n')
q={'schema':'vellum-macos-event-driven-loop-qualification-v1','result':'PASS_SCOPED_SOURCE_CHECKPOINT_NATIVE_PENDING','sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':association['source_commit'],'checkpoint_sources':review['sources'],'prepared_outputs':outputs,'prepared_file_count':6229,'source_association_sha256':sha(P/'final-source-association.json'),'binary':association['binary'],'checks':checks,'provider_review':{'execution_sha256':sha(P/'prism-execution.json'),'exit_code':0,'coverage':coverage,'returned_findings':0,'discarded_findings':0,'suppressed_findings':0},'internal_review_sha256':sha(P/'checkpoint-review-v2.json'),'negative_control':{'exit_code':1,'intended_shutdown_assertion_failed':True},'historical_vet_failure_preserved':True,'producer_preservation':'First two exact executed versions reconstructed and SHA256-verified against original receipts; later versions saved before execution. See producer-index.json.','archive_sha256':sha(archive),'archive_index_sha256':sha(D/'archive-index.json'),'seal_producer_sha256':sha(Path(__file__)),'native_executed':False,'idle_budget_qualified':False,'full_mac_qualified':False,'limits':['Focused inert regressions, vet, preparation and build; not a complete repository suite.','Timing-gap receipts do not certify global machine inactivity.','Ongoing overnight native source/executable remains frozen and separate.','No native startup/window/event/stop qualification or measured idle benefit for this new source.']}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({'result':q['result'],'archive_members':len(index),'archive_bytes':archive.stat().st_size,'uncompressed_bytes':sum(x['bytes']for x in index),'archive_sha256':q['archive_sha256']}))
