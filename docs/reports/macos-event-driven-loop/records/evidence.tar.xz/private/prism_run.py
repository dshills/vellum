"""One authorized Anthropic checkpoint; preserve actual process/report results."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-native-idle');P=Path(__file__).resolve().parent
review=json.loads((P/'checkpoint-review-v2.json').read_text())
assert review['unresolved_findings']==[]
assert review.get('prism_ready') is True,review.get('result')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(R/n)==h for n,h in review['sources'].items())
assert not any((P/('prism.'+suffix)).exists()for suffix in ['json','stdout','stderr'])
argv=['prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--baseline','none','--min-severity','low','--fail-on','medium','--no-auto-exclude','--chunk-bytes','48000','--max-diff-bytes','250000','--format','json','--out',str(P/'prism.json')]
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
record={'schema':'vellum-native-idle-prism-execution-v1','argv':argv,'cwd':str(R),'producer_sha256':sha(Path(__file__)),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_sha256':sha(P/'checkpoint-review-v2.json'),'sources':review['sources'],'exit_code':None,'error':None}
start=time.monotonic()
try:
 with(P/'prism.stdout').open('xb')as so,(P/'prism.stderr').open('xb')as se:
  record['exit_code']=run_child(argv,cwd=R,stdout=so,stderr=se,timeout=600).returncode
except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record['sources_stable']=all(sha(R/n)==h for n,h in review['sources'].items())
 for suffix in ['json','stdout','stderr']:
  f=P/('prism.'+suffix);record[suffix+'_sha256']=sha(f)if f.exists()else None
 (P/'prism-execution.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','sources_stable']}))
if record['exit_code']not in [0,1]or record['error']or not record['sources_stable']:sys.exit(1)
