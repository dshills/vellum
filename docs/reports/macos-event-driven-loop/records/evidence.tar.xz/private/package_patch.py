"""Freeze current reviewed prepared edits as an owned reproducible stage."""
from pathlib import Path
import difflib,hashlib,json
R=Path('/private/tmp/vellum-native-idle')
B=Path('/private/tmp/vellum-soak-cover/drivers/cogent/build/upstream')
N=R/'drivers/cogent/build/upstream'
P=R/'drivers/cogent/native/patches/nativeidle'
files=['system/driver/base/app.go','system/driver/base/helpers.go','system/driver/desktop/app.go','system/driver/desktop/desktop_darwin.go','system/driver/desktop/native_idle.go','system/driver/desktop/native_idle_vellum_test.go']
review=json.loads(Path('/private/tmp/vellum-macos-native-idle/implementation-review-v2.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings']
assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==h for name,h in review['sources'].items())
inputs={};outputs={};diff=[]
for name in files:
 old=(B/name).read_bytes() if (B/name).exists() else b''
 new=(N/name).read_bytes()
 inputs[name]=hashlib.sha256(old).hexdigest() if (B/name).exists() else None
 outputs[name]=hashlib.sha256(new).hexdigest()
 diff.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name if inputs[name] else '/dev/null',tofile='b/'+name))
(P/'original-hashes.json').write_text(json.dumps(inputs,indent=2)+'\n')
(P/'output-hashes.json').write_text(json.dumps(outputs,indent=2)+'\n')
patch=P/'0069-macos-event-driven-main-loop.patch'
patch.write_text(''.join(diff))
m=R/'drivers/cogent/native/dependencies.json';data=json.loads(m.read_text())
stage=data['dependencies'][0]['stages'][-1]
assert stage['origin']=='drivers/cogent/native/patches/nativeidle'
prior=P/Path(stage['patches'][0]['file']).name
stage['patches']=[{'file':'native/patches/nativeidle/'+patch.name,'sha256':hashlib.sha256(patch.read_bytes()).hexdigest()}]
m.write_text(json.dumps(data,indent=2)+'\n')
if prior!=patch:prior.unlink()
print(json.dumps({'patch':str(patch),'bytes':patch.stat().st_size,'outputs':outputs},indent=2))
