// Copyright 2026 Vellum contributors. All rights reserved.
// Use of this source code is governed by the MIT license in the Vellum repository.

package desktop

import "cogentcore.org/core/system/driver/base"

// macMainIngress publishes a received public rendezvous before posting its wake.
// A wake before an unbuffered send can be consumed before the sender is ready.
// One ready slot plus one pump-local packet bound additional retained calls;
// a call already received by main belongs to ExecuteMain, not this ingress.
type macMainIngress struct {
	ready chan base.FuncRun
	done  chan struct{}
}

func newMacMainIngress() *macMainIngress {
	return &macMainIngress{ready: make(chan base.FuncRun, 1), done: make(chan struct{})}
}

// runMacMainLoop is native-thread-only. wait must process a posted native event
// even when that event arrived before wait was called. It has no polling timer.
func (a *App) runMacMainLoop(queue <-chan base.FuncRun, stopped <-chan struct{}, wait, wake func()) {
	pump := newMacMainIngress()
	// This inner defer runs before MainLoop's native cleanup, including on panic
	// and Goexit. Never join while holding native-event, main-queue or App locks.
	defer func() {
		a.StopMain()
		// negative control: omitted join
	}()
	go pump.run(a, queue, stopped, wake)
	for {
		select {
		case <-stopped:
			return
		case call := <-pump.ready:
			if !a.ExecuteMain(call) {
				return
			}
		default:
			wait()
		}
	}
}

func (p *macMainIngress) run(a *App, queue <-chan base.FuncRun, stopped <-chan struct{}, wake func()) {
	var local base.FuncRun
	owned := false
	defer close(p.done)
	defer func() {
		// Also retire accepted ownership when the native post panics. Such a
		// backend failure remains fail-stop: the panic is not swallowed and no
		// native-cleanup guarantee is made for a fatal worker-thread panic.
		a.StopMain()
		if owned {
			a.ExecuteMain(local) // immutable stopped state: refusal only
			local = base.FuncRun{}
		}
		for {
			select {
			case call := <-p.ready:
				a.ExecuteMain(call)
			default:
				return
			}
		}
	}()
	for {
		// The explicit check prevents an unbounded public drain if stop and a
		// busy sender are both selectable. A concurrent rendezvous is refused.
		select {
		case <-stopped:
			wake()
			return
		default:
		}
		select {
		case <-stopped:
			wake()
			return
		case local = <-queue:
			owned = true
		}
		select {
		case <-stopped:
			wake()
			return
		default:
		}
		select {
		case <-stopped:
			wake()
			return
		case p.ready <- local:
			owned = false
			local = base.FuncRun{} // do not pin a caller capture while idle
			wake()
		}
	}
}
