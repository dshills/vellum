"""Recover earlier exact producers only when recorded SHA256 proves identity."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;D=P/'producers';D.mkdir(exist_ok=True)
current=(P/'gap_check.py').read_text();sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
common=current
common='\n'.join(line for line in common.split('\n')if not line.startswith("if name=='"))
common=common.replace("name in ['ingress-race-v1','ingress-race-stress-v1','regenerate-v1','no-join-control-v1','ingress-vet-v1','smoke-build-v1']","name in ['ingress-race-v1','ingress-race-stress-v1']")
common=common.replace("str(R/('drivers/cogent' if name in ['regenerate-v1','smoke-build-v1'] else 'drivers/cogent/build/upstream'))","str(R/'drivers/cogent/build/upstream')")
start=common.index('def sources():');end=common.index('\nenv=',start)
common=common[:start]+"def sources():return {n:hashlib.sha256((R/'drivers/cogent/build/upstream'/n).read_bytes()).hexdigest()for n in owned}"+common[end:]
common=common.replace("'overlay_inputs':{str(f):hashlib.sha256(f.read_bytes()).hexdigest()for f in [P/'no_join_overlay.json',P/'no_join_mutant.go']}if name=='no-join-control-v1' else {},",'')
start=common.index("expected_failure=name==")
common=common[:start]+"if record['exit_code']!=0 or record['error']or not record['source_stable']or not record['finished_before_next_quiet']:sys.exit(1)\n"
v2=common
v1=v2.replace("name in ['ingress-race-v1','ingress-race-stress-v1']","name=='ingress-race-v1'").replace("'-count='+('50' if name=='ingress-race-stress-v1' else '1')","'-count=1'")
records=[]
for name,source,method in [('ingress-race-v1',v1,'reconstructed by reversing known source edits; exact executed SHA256 required'),('ingress-race-stress-v1',v2,'reconstructed by reversing known source edits; exact executed SHA256 required'),('regenerate-v1',current,'current executed version retained'),('no-join-control-v1',current,'current executed version retained'),('ingress-vet-v1',current,'current executed version retained'),('smoke-build-v1',current,'current executed version retained')]:
 receipt=json.loads((P/(name+'.json')).read_text());actual=sha(source);expected=receipt['producer_sha256']
 if actual!=expected:raise ValueError((name,actual,expected))
 dest=D/(actual+'.py')
 if dest.exists():assert dest.read_text()==source
 else:dest.write_text(source)
 records.append({'run':name,'producer':str(dest.relative_to(P)),'sha256':actual,'preservation_method':method,'matches_recorded_executed_producer':True})
(P/'producer-index.json').write_text(json.dumps({'schema':'vellum-executed-producer-preservation-v1','records':records},indent=2)+'\n')
print(json.dumps(records,indent=2))
