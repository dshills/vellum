"""Exact-source bindings for current private SDK consumption checks."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-current-sdk-2010a33');HEAD='2010a33cf874a85d8ff755dbaa43512d1569230c'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
guard_path=W.parent/'macos-sdk-native-238b3b6/run.py';need(sha(guard_path)=='e76238012be63f58cbc5923e27f6fc227a3aca8443d85d64f466c0675382c7ac','owned child guard identity');g=module('current_sdk_owned_guard',guard_path)
from child_process import run_child
from sdk_environment import child_environment

def identity(root):
 def git(*args):return run_child(['git',*args],cwd=root,env=child_environment(False),capture_output=True,check=True,timeout=20).stdout
 need(git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-z'),'clean current source');files={};prepared={}
 for name in git('ls-files','-z').decode().split('\0')[:-1]:
  p=root/name;need(p.is_file()and not p.is_symlink(),'tracked regular source');files[name]=sha(p)
 for name in['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/name).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 need(len(files)==4687 and len(prepared)==6249,'exact source/prepared counts');return dict(commit=HEAD,files=files,prepared=prepared)

def source_pins(source):
 return {**{str(T/n):h for n,h in source['files'].items()},**{str(T/'drivers/cogent/build'/n):h for n,h in source['prepared'].items()}}
def terminal(run):
 need(run['created']and run['error']is None and not run['observation_errors']and run['exit_code']==0 and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit'],'successful terminal owned command')
def tool_argv(*args):
 return ['/usr/bin/env','GOCACHE=/Users/dshills/Library/Caches/go-build','GOMODCACHE=/Users/dshills/Development/Go/pkg/mod','GOPATH=/Users/dshills/Development/Go','PYTHONDONTWRITEBYTECODE=1',*map(str,args)]
