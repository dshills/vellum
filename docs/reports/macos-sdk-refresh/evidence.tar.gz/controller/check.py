"""Run the production private packager/checker on the exact current source."""
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
def main():
 need(sys.argv[1:]in[['package'],['relocate']],'fixed check action');action=sys.argv[1];source=identity(T);need(identity(C)==source,'canonical source/prepared parity')
 if action=='package':
  need(not P.exists(),'fresh package destination');P.mkdir(mode=0o700);(P/'source.json').write_text(json.dumps(source,indent=2)+'\n')
 else:
  prior=read(P/'package/receipt.json');need(prior['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK'and read(P/'source.json')==source,'successful exact package prerequisite')
 archive=P/'sdk.tar.gz';out=P/action;need(not out.exists(),'fresh command destination');pins=source_pins(source)
 for p in[W/'check.py',W/'common.py',guard_path,P/'source.json']:pins[str(p)]=sha(p)
 if action=='relocate':
  digest=prior['archive']['sha256'];need(sha(archive)==digest,'producer-bound archive');pins[str(archive)]=digest;pins[str(P/'package/receipt.json')]=sha(P/'package/receipt.json')
 args=tool_argv(sys.executable,T/'scripts/release-sdk.py','--output',archive)if action=='package'else tool_argv(sys.executable,T/'scripts/check-sdk.py','--archive',archive,'--sha256',digest)
 d=dict(result='INCOMPLETE',case=action,source_commit=HEAD,inputs=pins,commands=[],error=None,native_runtime_executed=False,public_distribution=False,network_profile='Production SDK children retain fixed public Go proxy/SumDB with verified cache. No offline/no-network claim.',nested_command_scope='Production CLI nested commands keep their own declared deadlines and cleanup; outer receipt observes only its directly owned command group.')
 try:
  run=g.execute(args,T,out,lambda:False,lambda:all(sha(p)==h for p,h in pins.items()),timeout=660 if action=='package'else 1500,limit=8<<20);d['commands'].append(run);terminal(run)
  value=read(out/'stdout');d['validation']=value
  if action=='package':need(value['private_build']is True and value['sha256']==sha(archive),'private package output')
  else:need(value['event']=='vellum.sdk.relocated'and value['digest_verified_against_expected']is True and value['archive_sha256']==digest and value['source']==dict(commit=HEAD,clean=True)and value['path_contains_spaces']is True and value['native_runtime']=='not executed'and value['independent_authenticity_verified']is False,'trusted private relocation checks')
  need(identity(T)==identity(C)==source,'terminal full source/prepared parity');d.update(result='PASS_CURRENT_PRIVATE_SDK_CHECK',source_stable=True,canonical_stable=True,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)))
 except BaseException as e:d.update(result='FAILED_CURRENT_PRIVATE_SDK_CHECK',error=dict(type=type(e).__name__,message=str(e)));raise
 finally:
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k not in['inputs','commands']}),flush=True)
if __name__=='__main__':main()
