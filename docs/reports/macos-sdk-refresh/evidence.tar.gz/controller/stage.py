"""Stage only the reviewed report and three documentation index/status updates."""
from pathlib import Path
import hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-current-sdk-2010a33');HEAD='2010a33cf874a85d8ff755dbaa43512d1569230c'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'binding.json').exists()
assert git(T,'rev-parse','HEAD').decode().strip()==HEAD==git(C,'rev-parse','HEAD').decode().strip()and not git(C,'status','--porcelain','-z')
names=['docs/implementation.md','specs/macos-completion.md','docs/reports/README.md']+['docs/reports/macos-sdk-refresh/'+n for n in['README.md','result.json','evidence.manifest.json','evidence.tar.gz']]
assert not git(T,'diff','--cached','--name-only')and set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(names)
source=json.loads((P/'source.json').read_bytes())
for name,h in source['files'].items():
 if name not in names:assert sha(T/name)==h
links=[]
for name in [n for n in names if n.endswith('.md')]:
 p=T/name
 for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  if '://'in target or target.startswith('#'):continue
  path=target.split('#',1)[0];assert(p.parent/path).exists(),(name,target);links.append(dict(file=name,target=target))
git(T,'add','--',*names);git(T,'diff','--cached','--check');assert not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(names)
diff=git(T,'diff','--cached','--binary');(W/'staged.diff').write_bytes(diff);sources={n:sha(T/n)for n in names}
b=dict(base_commit=HEAD,sources=sources,staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(diff),staged_files=7,source_files=4691,prepared_files=6249,native_runtime_source=HEAD,sdk_source_commit=HEAD,native_rerun=False,documentation_only=True)
with(W/'binding.json').open('x')as f:f.write(json.dumps(b,indent=2)+'\n')
with(W/'doc-checks.json').open('x')as f:f.write(json.dumps(dict(result='PASS_DOCUMENT_LINKS_AND_STAGED_WHITESPACE',relative_links=len(links),links=links,native_runtime_executed=False),indent=2)+'\n')
print(json.dumps(b))
