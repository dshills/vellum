"""One owned native hello run from the exact current relocated private SDK."""
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
import demos
R=P/'native-smoke';STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
def fresh(root):need(not any((root/n).exists()for n in['receipt.json','run','stop-live']),'fresh unsealed native smoke')
def sdk_valid(provenance):
 sdk=Path(provenance['sdk_root']);manifest=read(sdk/'SDK_MANIFEST.json');need(manifest['source']==dict(clean=True,commit=HEAD)and manifest['private_build']is True,'exact private SDK source');need(sha(sdk/'SDK_MANIFEST.json')==provenance['manifest_sha256'],'SDK manifest identity')
 need(demos.snapshot(sdk,dict(manifest=manifest))==provenance['sdk_files'],'all SDK bytes stable');binary=provenance['binary'];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'hello executable identity')
def main():
 need(len(sys.argv)==1,'no runtime overrides');fresh(R);review=read(W/'native-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'native readiness review');pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(R/'stop-live').exists();provenance=read(R/'provenance.json');source=read(P/'source.json');need(stable()and not stopping(),'initial admission');d=dict(result='INCOMPLETE',source_commit=HEAD,producer_sha256=sha(__file__),review_sha256=sha(W/'native-readiness.json'),provenance_sha256=sha(R/'provenance.json'),native_runtime_executed=False,physical_input_generated=False,settings_changes=False,public_distribution=False,full_macos_qualified=False,error=None)
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping()and identity(T)==identity(C)==source,'lease and current source admission');sdk_valid(provenance)
   run=g.execute(provenance['argv'],Path(provenance['sdk_root'])/'examples/hello',R/'run',stopping,stable,timeout=45,limit=8<<20);d['run']=run;d['native_runtime_executed']=run['created'];terminal(run);d['native_record']=g.validate_record((R/'run/stdout').read_bytes());sdk_valid(provenance)
   need(identity(T)==identity(C)==source and stable()and not stopping(),'terminal source and input stability');d.update(source_stable=True,sdk_stable=True,pins_stable=True,lease_held_through_cleanup=lease.held())
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 finally:
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();g.finalize(R,d);print(json.dumps({k:v for k,v in d.items()if k!='run'}),flush=True)
 need(d['error']is None and not d['finalization_errors'],'native smoke failed or canceled')
if __name__=='__main__':main()
