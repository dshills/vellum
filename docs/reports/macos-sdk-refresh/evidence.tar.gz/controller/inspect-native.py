"""Reconcile the completed SDK native hello without another launch."""
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
import native as m
r=read(m.R/'receipt.json');review=read(W/'native-readiness.json');provenance=read(m.R/'provenance.json');source=read(P/'source.json');need(r['result']=='PASS_SCOPED_PRIVATE_SDK_NATIVE_SMOKE'and r['error']is None and not r['finalization_errors']and(m.R/'stop-live').is_file(),'sealed successful smoke');need(r['source_commit']==HEAD and r['provenance_sha256']==sha(m.R/'provenance.json')and r['review_sha256']==sha(W/'native-readiness.json'),'native provenance');need(all(sha(p)==h for p,h in review['inputs'].items()),'all reviewed inputs stable');need(identity(T)==identity(C)==source,'full source/prepared parity');m.sdk_valid(provenance)
run=r['run'];terminal(run);g.absent(run['pid']);inputs={str(p):sha(p)for p in[m.R/'receipt.json',m.R/'provenance.json',m.R/'run/owned.json',W/'native-readiness.json',W/'inspect-native.py',W/'native.py',W/'analysis.json',P/'source.json']}
for n in['stdout','stderr']:
 p=m.R/'run'/n;need(dict(bytes=p.stat().st_size,sha256=sha(p))==run['logs'][n],'native raw log identity');inputs[str(p)]=sha(p)
record=g.validate_record((m.R/'run/stdout').read_bytes());need(record==r['native_record'],'raw record parity');need(r['source_stable']and r['sdk_stable']and r['pins_stable']and r['lease_held_through_cleanup'],'terminal observations');d=dict(result='RECONCILED_CURRENT_PRIVATE_SDK_NATIVE_SMOKE',source_commit=HEAD,inputs=inputs,binary=provenance['binary'],archive=provenance['archive'],sdk_root=provenance['sdk_root'],native_record=record,native_processes=1,source_prepared_sdk_stable=True,direct_owned_group_absent=True,physical_input_generated=False,settings_changes=False,ordinary_frame_performance_qualified=False,native_memory_qualified=False,public_distribution=False,independent_authenticity_verified=False,full_macos_qualified=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with(W/'native-analysis.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items()if k!='inputs'}))
