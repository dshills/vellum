"""Bind the already compiled relocated hello for one separately reviewed native smoke."""
import json,sys
sys.dont_write_bytecode=True
from common import *
import demos
analysis=read(W/'analysis.json');need(analysis['status']=='CURRENT_PRIVATE_SDK_AND_ENTRYPOINTS_RECONCILED','all current SDK checks reconciled');source=read(P/'source.json');need(identity(T)==identity(C)==source,'current clean source parity');r=read(P/'demos/receipt.json');sdk=Path(r['sdk_root']);archive=P/'sdk.tar.gz';verified=demos.checker.verify_archive(archive,analysis['archive']['sha256']);snapshot=demos.snapshot(sdk,verified);hello=analysis['compiled']['hello'];need(sha(hello['binary']['path'])==hello['binary']['sha256'],'retained hello binary')
root=P/'native-smoke';need(not root.exists(),'fresh native preparation root');root.mkdir(mode=0o700)
d=dict(source_commit=HEAD,sdk_root=str(sdk),archive=analysis['archive'],manifest_sha256=sha(sdk/'SDK_MANIFEST.json'),sdk_files=snapshot,binary=hello['binary'],binary_metadata_sha256=sha(P/'demos/hello/metadata/stdout'),source_sha256=sha(P/'source.json'),sdk_analysis_sha256=sha(W/'analysis.json'),native_runtime_executed=False,physical_input_generated=False,settings_changes=False,planned_processes=1,argv=[hello['binary']['path'],'--benchmark','--idle=1s','--samples=3'],watchdog_seconds=45)
with(root/'provenance.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items()if k!='sdk_files'}))
