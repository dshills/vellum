"""Package accepted current SDK checks and native smoke as seven documentation leaves."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-current-sdk-2010a33');D=T/'docs/reports/macos-sdk-refresh';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']and r['report_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'accepted results and report producer')
a=read(W/'analysis.json');n=read(W/'native-analysis.json');d=read(P/'native-smoke/receipt.json');need(a['status']=='CURRENT_PRIVATE_SDK_AND_ENTRYPOINTS_RECONCILED'and n['result']=='RECONCILED_CURRENT_PRIVATE_SDK_NATIVE_SMOKE'and d['result']=='PASS_SCOPED_PRIVATE_SDK_NATIVE_SMOKE'and(P/'native-smoke/stop-live').is_file(),'accepted sealed evidence');need(not D.exists(),'fresh report destination');members={}
def add(label,root,exclude=()):
 need(root.is_dir(),'existing evidence root')
 for p in sorted(root.rglob('*')):
  relative=p.relative_to(root);need(not p.is_symlink(),'evidence symlink')
  if p.is_file()and'__pycache__'not in relative.parts and not any(part in exclude or part.startswith('checkpoint-')for part in relative.parts):members[label+relative.as_posix()]=p
add('controller/',W,exclude=('deliverables',));members['checks/source.json']=P/'source.json'
for name in['package','relocate','native-smoke','native-controller-controls']:add('checks/'+name+'/',P/name)
add('checks/demos/',P/'demos',exclude=('relocated SDK applications','compiled applications'))
for name in['child_process.py','sdk_environment.py','release-sdk.py','check-sdk.py','new-app.py']:members['source-helpers/'+name]=T/'scripts'/name
members['source-helpers/owned-runner.py']=W.parent/'macos-sdk-native-238b3b6/run.py';members['source-helpers/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
for name in['examples/hello/main.go','examples/hello/model.go','examples/hello/go.mod','drivers/cogent/native/dependencies.json','release/version.json']:members['runtime-source/'+name]=T/name
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<600 and expanded<96<<20,'bounded evidence')
rows=[]
for name,item in a['compiled'].items():rows.append(f"| {name} | `{item['example']}` | `{item['target']}` | `{item['tags'] or 'default'}` |")
table='| Entrypoint | Example module | Main package | Tags |\n|---|---|---|---|\n'+'\n'.join(rows)
v=n['native_record'];native=(f"One exact relocated hello executable (`{n['binary']['sha256']}`) opens its own window, verifies the first rectangle-center pixel through the public GPU canvas snapshot path, completes three further successful readbacks and closes cleanly. Source remains `{a['source_commit']}`. Snapshot dimensions are {v['width']}×{v['height']} pixels. The recorded application-entry-to-verified-image interval is {v['startup_to_verified_gpu_ns']/1e6:.3f} ms; the three synchronous readback durations are "+', '.join(f'{x/1e6:.3f} ms'for x in v['render_readback_ns'])+". These are single-fixture observations, with no startup, ordinary-frame, presentation or memory-budget qualification. The first image has a pixel assertion; the three later snapshots assert successful readback.")
text=(W/'README.template.md').read_text()
for token,replacement in [('@@ENTRYPOINTS@@',table),('@@NATIVE@@',native)]:need(text.count(token)==1,'one template token');text=text.replace(token,replacement)
need('@@'not in text,'resolved report template');D.mkdir();manifest=dict(files={k:dict(bytes=p.stat().st_size,sha256=sha(p))for k,p in members.items()},count=len(members),expanded_bytes=expanded,excluded_artifacts=dict(private_sdk=a['archive'],compiled_executables={k:x['binary']for k,x in a['compiled'].items()},extracted_sdk_source='Exact source is in the separately retained private SDK archive; all 7,422 leaf hashes remain in evidence.'))
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in members.items():
    data=p.read_bytes();need(hashlib.sha256(data).hexdigest()==manifest['files'][name]['sha256'],'archive input identity');entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive integrity')
result=dict(status='REVIEWED_CURRENT_PRIVATE_SDK_AND_NATIVE_HELLO',sdk_source_commit=a['source_commit'],analysis=a,native_analysis=n,native=d,delivery=read(W/'delivery.json'),result_review_sha256=sha(W/'result-review.json'),evidence=dict(sha256=sha(D/'evidence.tar.gz'),bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded),evidence_phase_provider_calls=0,production_source_changed=False,public_distribution=False,full_macos_qualified=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');(D/'README.md').write_text(text)
paragraph='''\nThe [current private SDK refresh](@@LINK@@) binds clean `2010a33` to\n7,421 hashed files including stage 0076 and current intrinsic grid sizing.\nThe relocated generated consumer passes race/vet/build and public API contracts\npass race/vet. Nine application roots and four actual replay/workspace command\nentrypoints compile from a second SDK extraction, with 65 direct Go commands.\nOne separately admitted SDK hello run verifies its initial rectangle pixel,\nthree further readbacks and owned shutdown. Other demo runtimes, ordinary frame\nand memory/endurance budgets, physical/human workflows, native component/rights\nclosure and public distribution remain open.\n\n'''
p=T/'docs/implementation.md';p.write_text(p.read_text()+'\n## Current private SDK and relocated consumers\n'+paragraph.replace('@@LINK@@','reports/macos-sdk-refresh/README.md'))
p=T/'specs/macos-completion.md';s=p.read_text();marker='## Latest unattended evidence\n';need(s.count(marker)==1,'one latest-evidence section');p.write_text(s.replace(marker,marker+paragraph.replace('@@LINK@@','../docs/reports/macos-sdk-refresh/README.md')))
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Current private SDK and relocated consumers](macos-sdk-refresh/README.md): source `2010a33` archive/consumer checks, thirteen compiled entrypoints and one separately reviewed native SDK hello.\n')
print(json.dumps(dict(result='CURRENT_SDK_REPORT_GENERATED',files=7,members=len(members),expanded_bytes=expanded,archive_bytes=(D/'evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'evidence.tar.gz'))))
