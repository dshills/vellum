"""Check new-controller output admission and unchanged native record validation without GUI."""
import json,sys
sys.dont_write_bytecode=True
from common import *
import native as m
root=P/'native-controller-controls';need(not root.exists(),'fresh control root');root.mkdir(mode=0o700);cases=[]
def refused(name,fn):
 try:fn()
 except ValueError:cases.append(name);return
 raise AssertionError('accepted invalid '+name)
for name in['fresh','receipt','run','stop']: (root/name).mkdir()
m.fresh(root/'fresh');(root/'receipt/receipt.json').write_text('prior');(root/'run/run').mkdir();(root/'stop/stop-live').touch()
for name in['receipt','run','stop']:refused('output-'+name,lambda name=name:m.fresh(root/name))
r=dict(event='vellum.native.ready',geometry_persistence_disabled_in_fixture=True,startup_to_verified_gpu_ns=1,heap_alloc_bytes=1,width=1,height=1,render_readback_ns=[1,2,3],go_version='go1.test');valid=json.dumps(r).encode();need(g.validate_record(valid)==r,'valid record')
for name,payload in[('duplicate',valid+b'\n'+valid),('missing',b'{}'),('persistence',json.dumps({**r,'geometry_persistence_disabled_in_fixture':False}).encode()),('bool width',json.dumps({**r,'width':True}).encode()),('sample count',json.dumps({**r,'render_readback_ns':[1,2]}).encode()),('zero duration',json.dumps({**r,'render_readback_ns':[1,2,0]}).encode())]:refused(name,lambda payload=payload:g.validate_record(payload))
d=dict(result='PASS_NON_NATIVE_SDK_SMOKE_CONTROLS',native_runtime_executed=False,refusals=cases,positive_fresh=True,positive_record=True,inputs={str(p):sha(p)for p in[W/'native.py',W/'native-controls.py',W/'common.py',guard_path]})
with(W/'native-controls.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
