"""Compile nine real app roots and four declared commands from an extracted SDK."""
import datetime,json,sys
sys.dont_write_bytecode=True
from common import *
checker=module('current_sdk_archive_checker',T/'scripts/check-sdk.py')
APPS=['drawing','editor','grid','hello','imaging','loadedgrid','loadedtree','placement','viewport3d']
TARGETS=[(n,n,'.',None)for n in APPS]+[('workspace','replay','./cmd/workspace',None),('workspace-smoke','replay','./cmd/workspace-smoke','vellum_native_checks'),('managed-replay','replay','./cmd/native','offscreen'),('workspace-replay','replay','./cmd/workspace-replay','offscreen')]
def snapshot(sdk,verified):
 actual={};expected={**verified['manifest']['files'],'SDK_MANIFEST.json':sha(sdk/'SDK_MANIFEST.json')}
 for p in sdk.rglob('*'):
  need(not p.is_symlink(),'SDK symlink')
  if p.is_file():actual[p.relative_to(sdk).as_posix()]=sha(p)
 need(actual==expected,'exact SDK leaf bytes');return actual

def main():
 source=read(P/'source.json');need(identity(T)==identity(C)==source,'clean source/prepared parity');prior=read(P/'relocate/receipt.json');need(prior['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK','relocation prerequisite');digest=read(P/'package/receipt.json')['archive']['sha256'];archive=P/'sdk.tar.gz';need(sha(archive)==digest,'private producer digest')
 verified=checker.verify_archive(archive,digest);out=P/'demos';need(not out.exists(),'fresh demos destination');out.mkdir(mode=0o700);sdk=checker.extract_verified(archive,out/'relocated SDK applications',verified);before=snapshot(sdk,verified)
 need(sorted(p.parent.name for p in(sdk/'examples').glob('*/go.mod'))==sorted(APPS+['replay','sdk-contract']),'shipped example modules');(out/'manifest.json').write_text(json.dumps(verified['manifest'],indent=2)+'\n');(out/'sdk-files.json').write_text(json.dumps(before,indent=2)+'\n');binaries=out/'compiled applications';binaries.mkdir()
 pins={**source_pins(source),**{str(sdk/n):h for n,h in before.items()}}
 for p in[W/'demos.py',W/'common.py',guard_path,archive,P/'source.json',P/'package/receipt.json',P/'relocate/receipt.json',out/'manifest.json',out/'sdk-files.json']:pins[str(p)]=sha(p)
 stable=lambda:all(sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',source_commit=HEAD,sdk_root=str(sdk),archive_sha256=digest,inputs=pins,entrypoints=[],native_runtime_executed=False,public_distribution=False,error=None)
 try:
  for name,example,target,tags in TARGETS:
   need(stable(),'entrypoint inputs');cwd=sdk/'examples'/example;binary=binaries/name;opts=['-tags='+tags]if tags else[];expected_path='github.com/dshills/vellum/examples/'+example+(target[1:]if target!='.'else'')
   record=dict(name=name,example=example,target=target,tags=tags,expected_import_path=expected_path,commands=[],complete=False);d['entrypoints'].append(record)
   commands=[('modules',['go','list','-m','-json','all']),('package',['go','list','-json',*opts,target]),('verify',['go','mod','verify']),('build',['go','build','-p=1','-trimpath',*opts,'-o',str(binary),target]),('metadata',['go','version','-m',str(binary)])]
   for label,args in commands:
    job=out/name/label;job.parent.mkdir(exist_ok=True);run=g.execute(tool_argv(*args),cwd,job,lambda:False,stable,timeout=240,limit=8<<20);record['commands'].append(dict(name=label,run=run));terminal(run)
    if label=='modules':record['origins']=checker.check_origin(checker.decode_objects((job/'stdout').read_text()),sdk,verified['manifest']['release']['module'])
    if label=='package':
     info=read(job/'stdout');need(info['Name']=='main'and info['ImportPath']==expected_path and Path(info['Dir']).resolve().is_relative_to(sdk.resolve()),'real main package '+name);record['package']=dict(name=info['Name'],import_path=info['ImportPath'],directory=info['Dir'])
    if label=='metadata':need('\tpath\t'+expected_path+'\n'in(job/'stdout').read_text(),'actual executable identity '+name)
   need(snapshot(sdk,verified)==before,'SDK unchanged after entrypoint');record.update(complete=True,binary=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary)));print(json.dumps(dict(entrypoint=name,result='COMPILED_FROM_RELOCATED_PRIVATE_SDK',native_runtime_executed=False)),flush=True)
  need(len(d['entrypoints'])==13 and stable()and identity(T)==identity(C)==source,'all exact entrypoints and source parity');d.update(result='ALL_CURRENT_SDK_ENTRYPOINTS_COMPILE',native_applications=9,replay_commands=4,source_stable=True,canonical_stable=True,sdk_stable=True,archive_stable=True)
 except BaseException as e:d.update(result='FAILED_CURRENT_SDK_ENTRYPOINTS',error=dict(type=type(e).__name__,message=str(e)));raise
 finally:
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k not in['inputs','entrypoints']}),flush=True)
if __name__=='__main__':main()
