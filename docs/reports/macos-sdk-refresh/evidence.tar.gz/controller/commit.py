"""Commit the exact internally reviewed seven-file evidence checkpoint and fast-forward the clean canonical checkout."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-current-sdk-2010a33')
spec=importlib.util.spec_from_file_location('current_sdk_report_commit_guard',W.parent/'macos-grid-native-stacks/commit-pending.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W
sha=m.sha;git=m.git
def prepared(root):
 out={}
 for module in['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/module).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():out[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 return out
assert not(W/'commit-receipt.json').exists()
d=dict(result='INCOMPLETE',mutations=[],error=None,native_runtime_executed_by_committer=False)
try:
 b=json.loads((W/'binding.json').read_bytes());r=json.loads((W/'final-review.json').read_bytes());assert r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
 assert git(T,'rev-parse','HEAD').decode().strip()==b['base_commit']==git(C,'rev-parse','HEAD').decode().strip()
 assert git(T,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/macos-native-results'and git(C,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/foundation-completion'
 assert m.clean(C)and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
 assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources'])and len(b['sources'])==7
 assert all(sha(T/p)==h for p,h in b['sources'].items())and hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256']
 native_source=json.loads((P/'source.json').read_bytes());assert prepared(T)==prepared(C)==native_source['prepared']and len(native_source['prepared'])==6249
 for name,h in native_source['files'].items():
  if name not in b['sources']:assert sha(T/name)==h
 admissions={name:m.git_admission(root)for name,root in[('candidate',T),('canonical',C)]};d['git_admission']=admissions
 message=W/'commit-message.txt';message.write_text('docs(sdk): record current package consumers and native hello\n\nBind private alpha.2 SDK source 2010a33 to 7,421 hashed files, exact selected/notice coverage, relocated generated consumer and API contract checks, and 13 actual main entrypoints built through 65 direct Go commands. Retain one separately admitted native hello with its pixel-checked initial snapshot, three further readbacks and owned shutdown.\n\nInternally reviewed results, archive integrity, current source/SDK identity and exact seven-document commit. No runtime source change, additional provider call, performance or public-distribution qualification. Direct CLI/nested cleanup scope and full Mac limits remain explicit.\n')
 assert m.git_admission(T)==admissions['candidate']and m.git_admission(C)==admissions['canonical']
 m.mutation(T,'evidence-commit',['git','commit','--file',str(message)],d)
 commit=git(T,'rev-parse','HEAD').decode().strip();assert git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit']and m.clean(T)
 assert set(git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources'])
 assert m.clean(C)and git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==admissions['canonical']
 m.mutation(C,'canonical-fast-forward',['git','merge','--ff-only',commit],d)
 names=git(T,'ls-files','-z').decode().split('\0')[:-1];assert len(names)==b['source_files']==4691
 assert all(sha(T/name)==sha(C/name)for name in names)and prepared(T)==prepared(C)==native_source['prepared']
 assert m.clean(T)and m.clean(C)and git(C,'rev-parse','HEAD').decode().strip()==commit
 d.update(result='REVIEWED_NATIVE_EVIDENCE_COMMITTED_AND_CANONICAL_PROMOTED',commit=commit,parent=b['base_commit'],native_runtime_source=b['native_runtime_source'],both_clean=True,canonical_promoted=True,source_files=len(names),prepared_files=6249,review_sha256=sha(W/'final-review.json'),binding_sha256=sha(W/'binding.json'))
except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['producer_sha256']=sha(__file__);observation_failed=False
 for name,root in[('canonical',C),('candidate',T)]:
  try:d[name+'_observation']=m.observation(root)
  except BaseException as e:d[name+'_observation_error']=dict(type=type(e).__name__,message=str(e));observation_failed=True
 if observation_failed:d.update(pre_terminal_result=d['result'],result='FAILED_TERMINAL_OBSERVATION',both_clean=False,canonical_promoted_unverified=True)
 with(W/'commit-receipt.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:v for k,v in d.items()if k!='git_admission'}),flush=True)
 if observation_failed and d['error']is None:raise RuntimeError('terminal checkout observation failed; see exclusive receipt')
