"""Reconcile archive content, source provenance and actual compiled SDK entrypoints."""
import datetime,json,sys,tarfile
sys.dont_write_bytecode=True
from common import *
import demos
producer=module('current_sdk_selection',T/'scripts/release-sdk.py');checker=demos.checker
source=read(P/'source.json');need(identity(T)==identity(C)==source,'current clean source/prepared parity');inputs={str(p):sha(p)for p in[W/'inspect.py',W/'common.py',W/'check.py',W/'demos.py',P/'source.json']};checks={}
for name in['package','relocate']:
 root=P/name;r=read(root/'receipt.json');need(r['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK'and r['error']is None and r['source_stable']and r['canonical_stable']and r['source_commit']==HEAD,'successful '+name);need(len(r['commands'])==1,'one production command');run=r['commands'][0];terminal(run);g.absent(run['pid']);need(all(sha(p)==h for p,h in r['inputs'].items()),'check input identity')
 for n in['stdout','stderr']:
  p=root/n;need(dict(bytes=p.stat().st_size,sha256=sha(p))==run['logs'][n],'raw '+name+'/'+n);inputs[str(p)]=sha(p)
 need(read(root/'stdout')==r['validation'],'CLI validation parity');inputs[str(root/'receipt.json')]=sha(root/'receipt.json');inputs[str(root/'owned.json')]=sha(root/'owned.json');checks[name]=dict(validation=r['validation'],seconds=run['seconds'])
archive=P/'sdk.tar.gz';digest=checks['package']['validation']['sha256'];verified=checker.verify_archive(archive,digest);manifest=verified['manifest'];actual=manifest['files'];prefix=verified['prefix']+'/'
need(manifest['private_build']is True and manifest['source']==dict(clean=True,commit=HEAD)and manifest['untracked_files']==[]and manifest['release']['module']=='github.com/dshills/vellum','private committed namespace');expected={n:sha(p)for n,p in producer.source_files(T)};need(all(actual.get(n)==h for n,h in expected.items()),'every selected source byte')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();need(all(m.isfile()for m in members)and len(members)==len(actual)+1,'exact regular SDK members');inventory=json.load(tar.extractfile(prefix+'THIRD_PARTY_INVENTORY.json'))
generated={'PRIVATE_BUILD.txt','THIRD_PARTY_INVENTORY.json'}
for item in inventory['modules']:
 for notice in item['license_files']:
  name='THIRD_PARTY_NOTICES/'+notice['notice'];need(actual[name]==notice['sha256'],'notice association');generated.add(name)
need(set(actual)==set(expected)|generated and not set(expected)&generated,'exact source and generated SDK sets');need(checks['relocate']['validation']['verified_files']==len(actual)and checks['relocate']['validation']['archive_sha256']==digest,'relocation exact archive')
r=read(P/'demos/receipt.json');need(r['result']=='ALL_CURRENT_SDK_ENTRYPOINTS_COMPILE'and r['error']is None and r['source_commit']==HEAD and r['archive_sha256']==digest and len(r['entrypoints'])==13 and all(r[x]is True for x in['source_stable','canonical_stable','sdk_stable','archive_stable']),'all documented entrypoints');need(all(sha(p)==h for p,h in r['inputs'].items()),'all demo inputs stable');sdk=Path(r['sdk_root']);need(' 'in str(sdk)and demos.snapshot(sdk,verified)==read(P/'demos/sdk-files.json'),'independent SDK bytes');compiled={};command_count=0
for expected_target,record in zip(demos.TARGETS,r['entrypoints']):
 name,example,target,tags=expected_target;need((record['name'],record['example'],record['target'],record['tags'])==expected_target and record['complete']is True,'exact main target');need([x['name']for x in record['commands']]==['modules','package','verify','build','metadata'],'complete entrypoint commands');need(record['origins']==checks['relocate']['validation']['replacements_within_sdk'],'SDK module origins')
 for cmd in record['commands']:
  run=cmd['run'];terminal(run);g.absent(run['pid']);root=P/'demos'/name/cmd['name'];need(Path(run['cwd']).resolve().is_relative_to(sdk.resolve()),'SDK command working directory');command_count+=1
  for n in['stdout','stderr']:
   p=root/n;need(dict(bytes=p.stat().st_size,sha256=sha(p))==run['logs'][n],'raw demo log');inputs[str(p)]=sha(p)
  inputs[str(root/'owned.json')]=sha(root/'owned.json')
  if cmd['name']=='modules':need(checker.check_origin(checker.decode_objects((root/'stdout').read_text()),sdk,manifest['release']['module'])==record['origins'],'raw origins parity')
  if cmd['name']=='package':
   info=read(root/'stdout');need(info['Name']=='main'and info['ImportPath']==record['expected_import_path']and Path(info['Dir']).resolve().is_relative_to(sdk.resolve()),'actual main identity')
  if cmd['name']=='metadata':need('\tpath\t'+record['expected_import_path']+'\n'in(root/'stdout').read_text(),'actual binary metadata')
 binary=record['binary'];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'compiled SDK binary');compiled[name]=dict(example=example,target=target,tags=tags,import_path=record['expected_import_path'],origins=record['origins'],binary=binary)
need(command_count==65,'65directGo commands');metadata=read(T/'drivers/cogent/native/dependencies.json');last=metadata['dependencies'][0]['stages'][-1];patches=last['patches'];need(len(patches)==1 and Path(patches[0]['file']).name.startswith('0076-'),'owned stage0076')
for item in patches:need(actual['drivers/cogent/'+item['file']]==item['sha256'],'owned patch shipped')
outputs=read(T/'drivers/cogent/native/patches/glyphplacement/output-hashes.json')
for n,h in outputs.items():need(actual['drivers/cogent/build/upstream/'+n]==h==source['prepared']['upstream/'+n],'stage0076 prepared output')
for n in['drivers/cogent/grid_retained.go','drivers/cogent/grid_intrinsic_size_offscreen_test.go']:need(actual[n]==source['files'][n],'current intrinsic sizing shipped')
for p in[P/'demos/receipt.json',P/'demos/manifest.json',P/'demos/sdk-files.json',archive]:inputs[str(p)]=sha(p)
d=dict(status='CURRENT_PRIVATE_SDK_AND_ENTRYPOINTS_RECONCILED',source_commit=HEAD,source_files=len(source['files']),prepared_files=len(source['prepared']),inputs=inputs,archive=dict(path=str(archive),sha256=digest,bytes=archive.stat().st_size,manifest_files=len(actual),regular_members=len(members),selected_source_files=len(expected),generated_files=len(generated),private_build=True,version=manifest['release']['version'],namespace=manifest['release']['module']),inventory=dict(modules=len(inventory['modules']),distribution_audit=inventory['distribution_audit'],scope=inventory['scope']),checks=checks,compiled=compiled,compiled_native_applications=9,compiled_replay_commands=4,direct_demo_commands=65,latest_owned_stage='0076',current_intrinsic_source_included=True,native_runtime_executed=False,public_distribution=False,independent_authenticity_verified=False,full_macos_qualified=False,network_profile='Production controlled fixed public proxy/SumDB and verified external module cache; no offline/no-network claim.',nested_scope='Package/relocation direct CLI groups observed absent. Nested production CLI commands use their own deadlines/cleanup; absence of each detached nested group is not independently observed. All65direct demo Go groups are observed absent.',completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with(W/'analysis.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items()if k not in['inputs','compiled','checks']}))
