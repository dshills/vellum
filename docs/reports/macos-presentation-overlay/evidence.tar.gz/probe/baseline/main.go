package main
/*
#cgo CFLAGS: -x objective-c
int c_marker(void);
int m_marker(void);
*/
import "C"
import "fmt"
func main() { fmt.Printf("%d %d %d\n", int(C.c_marker()), int(C.m_marker()), 41) }
