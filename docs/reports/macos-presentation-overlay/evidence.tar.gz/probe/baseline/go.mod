module example.test/native-overlay

go 1.25.6
