int c_marker(void) { return 22; }
