"""One bounded owned Cocoa fixture, serialized against ordinary benchmarks."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,signal,subprocess,sys,time
R=Path('/private/tmp/vellum-native-breadcrumb');P=Path('/private/tmp/vellum-macos-breadcrumb-native');Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
name=sys.argv[1];binary=P/(sys.argv[2]if len(sys.argv)>2 else 'breadcrumb-smoke')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def source():
 names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'delta':{n:sha(R/n)for n in names if(R/n).is_file()},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
def stop():
 if(Q/'stop-live').exists()or(P/'stop-live').exists():raise InterruptedError('human returned; stop live Cocoa check')
stop();before=source();assert len(before['prepared'])==6216
lock=(Q/'native-live.lock').open('a+');locked=False;child=None;start=time.monotonic()
d={'argv':[str(binary)],'mode':'native_cocoa','source_before':before,'producer_sha256':sha(__file__),'executable_sha256':sha(binary),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':75,'exit_code':None,'error':None,'preferences_changed':False,'clipboard_access':False}
try:
 while not locked:
  stop()
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);locked=True
  except BlockingIOError:
   if time.monotonic()-start>90:raise TimeoutError('live-test lock wait expired')
   time.sleep(.25)
 launch=time.monotonic()
 with(P/(name+'.stdout')).open('xb')as so,(P/(name+'.stderr')).open('xb')as se:
  child=subprocess.Popen([str(binary)],cwd=R/'drivers/cogent',env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
  (P/(name+'.owned-process.json')).write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'owner_pid':os.getpid(),'executable_sha256':d['executable_sha256']}))
  while child.poll()is None:
   stop()
   if time.monotonic()-launch>75:raise TimeoutError('native Cocoa fixture watchdog expired')
   if(P/(name+'.stdout')).stat().st_size+(P/(name+'.stderr')).stat().st_size>1<<20:raise ValueError('native fixture output exceeded1MiB')
   time.sleep(.05)
  d['exit_code']=child.returncode
except BaseException as exc:d['error']={'type':type(exc).__name__,'message':str(exc)}
finally:
 if child is not None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait(timeout=5);d['exit_code']=child.returncode
 d['owned_group_retired']=child is not None;d['source_after']=source();d['source_stable']=before==d['source_after']
 if locked:fcntl.flock(lock,fcntl.LOCK_UN)
 lock.close();d['elapsed_seconds']=time.monotonic()-start
 for channel in ['stdout','stderr']:
  f=P/(name+'.'+channel);d[channel+'_sha256']=sha(f)if f.exists()else None
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['source_before','source_after']}),flush=True)
sys.exit(0 if d['exit_code']==0 and d['error']is None and d['source_stable']else 1)
