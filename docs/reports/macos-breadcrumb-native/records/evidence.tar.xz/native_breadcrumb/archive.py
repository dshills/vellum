from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-native-breadcrumb');P=Path('/private/tmp/vellum-macos-breadcrumb-native');D=R/'docs/reports/macos-breadcrumb-native/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
summary=json.loads((P/'final-summary.json').read_text());sources=summary['sources'];assert len(sources)==6 and all(sha(R/n)==v for n,v in sources.items())
internal=json.loads((P/'internal-final-review.json').read_text());assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==sources
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==0 and not process['error'] and process['source_index_stable'] and process['before']==process['after']==sources
assert review['coverage']['complete'] and review['coverage']['files']==6 and not review['findings'] and review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.cpu','.png'}
for folder,prefix in [(P,'native_breadcrumb')]:
 for f in sorted(folder.rglob('*')):
  if f.is_file() and not f.is_symlink() and '__pycache__'not in f.parts and f.suffix in allowed:inputs[prefix+'/'+f.relative_to(folder).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile() and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Actual Cocoa Breadcrumb selector consumer; final12stagepositive, current-rolefaultcaught, path-onlyguardfaultnondetect retained, correctedfailureadmissionreport and actualmissingIDrefusal0. Legacycurrent-role/path observations bind prior failure-report bytes. Owned75s/1MiBflock/stop/kill-reap wrapper,6216 unchanged source leaves. Nativebinaries excluded with hashes. No physicalinput/humanVoiceOver/latency/memory/fullMac/P6/P11 qualification.'},indent=2)+'\n')
q={**summary,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','internal_review_sha256':sha(P/'internal-final-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_files':6,'prism_findings':0,'prism_unresolved_findings':0,'prism_raw_exit_code':0,'prism_calls':review['coverage']['llmCalls'],'archive_sha256':sha(archive),'archive_members':len(index),'archive_bytes':archive.stat().st_size,'canonical_promoted':False}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','prism_files','prism_findings','archive_sha256','archive_members','archive_bytes']}))
