from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-native-breadcrumb');P=Path('/private/tmp/vellum-macos-breadcrumb-native')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
old=json.loads((P/'checkpoint-source-v1.json').read_text());old_summary=json.loads((P/'final-summary-v1.json').read_text())
# Only failed-step admission reporting changed among the four command files.
old_native=old['sources']['drivers/cogent/cmd/breadcrumb-smoke/main_native.go']
old_stdout=json.loads((P/'native-positive.json').read_text())['stdout_sha256']
report=R/'docs/reports/macos-breadcrumb-native/README.md';s=report.read_text().replace('in one owned 720×480 window.','in one owned window with requested logical size 720×480.')
s=s.replace('The owned wrapper holds', 'Internal review corrected a failed stale-stage report that always recorded one\nadmission. The final consumer derives the count from the actual admission result.\nIts rebuilt positive again passes all 12 stages with identical observation bytes.\nAn actual missing-ID selector refuses admission; the corrected failed stale stage\nrecords zero and the app completes native cleanup. The first report-fault overlay\nfailed compilation from an unused target and never launched a native app; its\ncorrected version is the observed refusal. Earlier positive/path-only/current-role\nreceipts retain their initial source version and are not relabeled as corrected.\n\nThe owned wrapper holds')
report.write_text(s)
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines());assert len(names)==6
sources={n:sha(R/n)for n in sorted(names)};code={n:h for n,h in sources.items()if n.startswith('drivers/')};assert len(code)==4
assert all(h==old['sources'][n]for n,h in code.items()if n!='drivers/cogent/cmd/breadcrumb-smoke/main_native.go')
prepared=json.loads((P/'native-build.json').read_text())['prepared_after'];assert len(prepared)==6216
corrected_checks={}
for name in ['corrected-native-build','corrected-native-vet','report-fault-build-v2']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and not d['error']and d['source_delta_stable']and d['prepared_before']==d['prepared_after']==prepared
 assert all(d['source_delta_before'][n]==d['source_delta_after'][n]==h for n,h in code.items())and d['overlay_inputs_before']==d['overlay_inputs_after']
 for ch in ['stdout','stderr']:assert sha(P/(name+'.'+ch))==d[ch+'_sha256']
 corrected_checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'argv':d['argv']}
observed={}
for name,binary,build in [('native-positive-corrected','breadcrumb-smoke-corrected','corrected-native-build'),('native-report-fault-v2','breadcrumb-fault-report-v2','report-fault-build-v2')]:
 d=json.loads((P/(name+'.json')).read_text());assert not d['error']and d['owned_group_retired']and d['source_stable']and d['source_before']['prepared']==d['source_after']['prepared']==prepared
 assert all(d['source_before']['delta'][n]==d['source_after']['delta'][n]==h for n,h in code.items())and d['executable_sha256']==sha(P/binary)
 for ch in ['stdout','stderr']:assert sha(P/(name+'.'+ch))==d[ch+'_sha256']
 events=[json.loads(l)for l in(P/(name+'.stdout')).read_text().splitlines()if l.startswith('{')];steps=[e for e in events if e.get('event')=='vellum.breadcrumb.step'];final=events[-1];c=final['native_cleanup']
 assert c['MainThread']and c['CleanupObserved']and c['CallbacksStopped']and c['NativeOutstanding']==c['AccessibilityWindows']==c['PendingCallbacks']==0 and not c['WindowTitles']
 if name=='native-positive-corrected':
  assert d['exit_code']==0 and len(steps)==12 and all(s['passed']for s in steps)and final['result']=='PASS_NATIVE_BREADCRUMB'and d['stdout_sha256']==old_stdout
  assert events[-2]['requests']==3
 else:
  failure=next(s for s in steps if s['stage']=='stale-path');assert d['exit_code']==1 and failure['admissions']==0 and not failure['passed']and final['result']=='FAILED_NATIVE_BREADCRUMB'
  assert 'stale path fixture had no native admission'in(P/(name+'.stderr')).read_text()
 binding={'binary_sha256':sha(P/binary),'build_receipt_sha256':sha(P/(build+'.json')),'run_receipt_sha256':sha(P/(name+'.json')),'build_argv':json.loads((P/(build+'.json')).read_text())['argv'],'binding_created_after_observed_execution':True}
 (P/(name+'-build-binding.json')).write_text(json.dumps(binding,indent=2)+'\n')
 observed[name]={'receipt_sha256':sha(P/(name+'.json')),'executable_sha256':d['executable_sha256'],'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'stages':len(steps),'cleanup_complete':True}
manifest={'base_commit':old['base_commit'],'sources':sources};(P/'checkpoint-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
q={**old_summary,**manifest,'result':'PASS_SCOPED_NATIVE_BREADCRUMB','legacy_source_map_sha256':sha(P/'checkpoint-source-v1.json'),'legacy_summary_sha256':sha(P/'final-summary-v1.json'),'legacy_native_main_sha256':old_native,'final_native_main_sha256':code['drivers/cogent/cmd/breadcrumb-smoke/main_native.go'],'correction':'Failure-only stale admission reporting now derives actual bool. Final rebuilt positive has identical12stage observation bytes. Earlier role/path faults bind initial consumer source; corrected real missing-ID refusal records0.','corrected_checks':corrected_checks,'corrected_native_observations':observed,'initial_report_fault_compile_only_excluded':True}
(P/'final-summary.json').write_text(json.dumps(q,indent=2)+'\n');print('PASS final6sources; corrected12Cocoastages identical, actualrefusalreport0; all legacy scopes preserved')
