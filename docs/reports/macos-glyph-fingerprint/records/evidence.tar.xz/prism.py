from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-scene-profile');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==10
assert all(sha(R/n)==h for n,h in sources.items())
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
out=P/'prism-v1';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Owned patch0068 fuses glyph coverage geometry validation and internal FNV fingerprint into one traversal, keyed relative to FIRST VALIDATED coordinate pixel origin. Signed first-point-relative words can be negative. Geometry grammar/ranges/hull MIN origin/clip guard and full MIN-normalized cache-path equality remain unchanged. Hash is private candidate index, values deliberately differ from old min-origin fingerprint. No added retained state/cache/budget exemptions, no public format/API change. Original geometry/admission/origin and exact corruption oracles retained; obsolete oldhash equality intentionally replaced by independent callback-walker newkey oracle. Tests4096phase/fourtranslations/leadingClose-nonMove/malformed/refusal/collision;5actual400-cell software pairs preserveexact encoded/accounting/pixels and10937allocs, diagnosticsharedcomputer medians2.407vs2.242ms only. Source/pin internalapproved;6227regenerationexact. Matrix and fullrenderer/adapter/SDK tests pending. All five guard-removal faults trigger intended assertions; one classifier searched wrong collisiontoken, rawtest itself failed intended message and corrected classification retained. No native application/GPU/performance/endurance launch, historical4/6ms targets remainfailed; no fullP4/P6/P11/Mac or memory/rights claims. Review10 current owned patch/pin/prepare/docs/spec leaves.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'source-review.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
