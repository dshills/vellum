from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-scene-profile');P=Path(__file__).resolve().parent;N=P/'negative';N.mkdir(exist_ok=False)
U=R/'drivers/cogent/build/upstream/paint/renderers/rasterx';source=U/'glyph_coverage.go'
cases={
 'absolute-anchor':('anchor = image.Pt(x/64, y/64)','anchor = image.Point{}','^TestVellumGlyphFingerprintTranslationAndFractionalPhases$','phase oracle'),
 'last-point-anchor':('if points == 0 {\n\t\t\t\tanchor','if true {\n\t\t\t\tanchor','^TestVellumGlyphLookupDirectLoopMatchesWalker$','first-point fingerprint differs'),
 'lost-phase':('p[j] - fixed.Int26_6(anchor.X*64)','fixed.Int26_6((int(p[j])/64-anchor.X)*64)','^TestVellumGlyphFingerprintTranslationAndFractionalPhases$','phase oracle'),
 'clipped-hit':(' || !hull.In(clip)','', '^TestVellumGlyphFingerprintRefusalMatchesOriginal$','admission/origin differs'),
 'collision-authority':(' && glyphCoverageMatches(e, rs.Path, origin)','', '^TestVellumGlyphCoverageHashCollisionRendersCurrentPath$','collision')}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();results={}
for name,(old,new,test,message)in cases.items():
 candidate=source.read_text();assert candidate.count(old)==1,(name,candidate.count(old))
 f=N/(name+'.go');f.write_text(candidate.replace(old,new));overlay=N/(name+'.json');overlay.write_text(json.dumps({'Replace':{str(source):str(f)}}))
 run=subprocess.run(['python3',str(P/'code_run.py'),'negative-'+name,'drivers/cogent','go','test','-race','-tags','offscreen','-overlay='+str(overlay),'cogentcore.org/core/paint/renderers/rasterx','-run',test,'-count=1','-timeout=60s','-v'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100)
 (P/('negative-'+name+'.wrapper.log')).write_bytes(run.stdout)
 d=json.loads((P/('negative-'+name+'.json')).read_text());out=(P/('negative-'+name+'.stdout')).read_text()
 intended=run.returncode==1 and d['exit_code']==1 and d['error']is None and d['source_delta_stable']and d['prepared_before']==d['prepared_after']and d['overlay_inputs_before']==d['overlay_inputs_after'] and message in out and '[build failed]'not in out
 results[name]={'intended_failure':intended,'candidate_sha256':sha(source),'fault_sha256':sha(f),'test':test,'expected_diagnostic':message,'receipt_sha256':sha(P/('negative-'+name+'.json'))};print(name,intended,flush=True)
(P/'negative-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(v['intended_failure']for v in results.values())
