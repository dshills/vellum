from pathlib import Path
import hashlib,json,statistics,subprocess
R=Path('/private/tmp/vellum-scene-profile');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in (root/'drivers/cogent/build'/module).rglob('*')if f.is_file()}
review=json.loads((P/'source-review.json').read_text());sources=review['sources'];assert review['result']=='APPROVED_SOURCE'and not review['unresolved_findings']and len(sources)==10
assert all(sha(R/n)==h for n,h in sources.items())
a,b=prepared(C),prepared(R);assert len(a)==6226 and len(b)==6227
D=R/'drivers/cogent/native/patches/glyphfingerprint';outputs=json.loads((D/'output-hashes.json').read_text());inputs=json.loads((D/'original-hashes.json').read_text())
assert {n for n in set(a)|set(b)if a.get(n)!=b.get(n)}=={'upstream/'+n for n in outputs}
for n,h in outputs.items():assert b['upstream/'+n]==h and a.get('upstream/'+n)==inputs[n]
checks={}
def check(name,expected_exit=0,baseline=False,needed=()):
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==expected_exit and d['error']is None and d['source_delta_stable']and d['prepared_before']==d['prepared_after']==(a if baseline else b) and d['overlay_inputs_before']==d['overlay_inputs_after']and not d['live_tests'] and not d['headless_gpu_requested']
 assert all(d['source_delta_before'][n]==d['source_delta_after'][n]==sources[n]for n in needed)
 assert all(d[k+'_sha256']==sha(P/(name+'.'+k))for k in ['stdout','stderr'])
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':expected_exit,'elapsed_seconds':d['elapsed_seconds'],'current_sources_matched':list(needed),'prepared_files':len(a if baseline else b),'source_and_prepared_stable':True}
 return d
check('profile-baseline-v1',baseline=True)
for name in ['fused-unit-v2','pin-reproduce']:check(name)
for name in ['driver-race','driver-vet','prepare-tests','native-compile','sdk-archive','sdk-relocation','matrix-original','matrix-candidate']:check(name,needed=sources)
paired=json.loads((P/'paired-summary.json').read_text());assert paired['pairs']==5 and paired['packet_bytes_and_pixels_equal']and not paired['native_performance_qualified']
for mode in ['original','candidate']:
 for pair in range(1,6):check(f'pair-{pair}-{mode}')
negative=json.loads((P/'negative-qualified.json').read_text());assert negative['result']=='PASS_FIVE_TARGETED_ASSERTION_FAILURES'and len(negative['controls'])==5
for name,row in negative['controls'].items():
 assert row['intended_failure']and row['candidate_sha256']==outputs['paint/renderers/rasterx/glyph_coverage.go']
 check('negative-'+name,1,needed=sources)
 assert row['expected_diagnostic']in(P/('negative-'+name+'.stdout')).read_text()
matrix=json.loads((P/'matrix-summary.json').read_text());assert matrix['records_per_arm']==24 and matrix['signatures']['original']==matrix['signatures']['candidate']and not matrix['native_gpu_executed']
for mode in ['original','candidate']:
 data=P/('matrix-'+mode+'-packet.json');assert sha(data)==matrix['signatures'][mode]and len(json.loads(data.read_text()))==24
profile_record=json.loads((P/'profile-packet.json').read_text());assert len(profile_record)==1 and profile_record[0]['visible_cells']==400 and profile_record[0]['cell_pool']==477
assert sha(P/'profile-packet.json')==sha(P/'pair-1-candidate-packet.json')
relocated=json.loads((P/'relocated-renderer.json').read_text());assert relocated['result']=='PASS_RELOCATED_RENDERER_CODE_CHECKS'and relocated['prepared_exact']and relocated['prepared']==b and len(relocated['generated_test_outputs'])==17
for row in relocated['checks']:
 assert row['exit_code']==0
 for stream in ['stdout','stderr']:assert sha(P/('relocated-renderer-'+row['name']+'.'+stream))==row[stream+'_sha256']
sdk=json.loads((P/'sdk-relocation.stdout').read_text());assert sdk['native_runtime']=='not executed'and sdk['archive_sha256']==sha(P/'vellum-sdk.tar.gz')and sdk['digest_verified_against_expected']and relocated['archive_sha256']==sdk['archive_sha256']
prism=json.loads((P/'prism-v1/prism.json').read_text());proc=json.loads((P/'prism-v1/process.json').read_text());assert proc['sources']==sources and proc['source_index_stable']and proc['exit_code']==0 and proc['error']is None and prism['coverage']['complete']and not prism['findings']
summary={'result':'PASS_SCOPED_ONE_PASS_FINGERPRINT_CHECKS','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sources':sources,'prepared_before':a,'prepared_after':b,'checks':checks,'original_prepared_files':6226,'candidate_prepared_files':6227,'declared_prepared_changes':outputs,'profile_cpu_sha256':sha(P/'capture.cpu'),'profile_fixture_sha256':sha(P/'capture_profile_test.go'),'profile_scope':'1000 repeated warmed ScenePacket captures from the actual400-visible/477-pool fixed-row96DPI NotoSans15 grid; CPU samples only','profile_geometry_flat_percent':13.36,'profile_matches_flat_percent':7.76,'paired_summary_sha256':sha(P/'paired-summary.json'),'local_diagnostic_medians':paired['medians'],'packet_signature':sha(P/'pair-1-candidate-packet.json'),'matrix_records_per_arm':24,'matrix_signature':matrix['signatures']['candidate'],'fault_controls':5,'fault_controls_sha256':sha(P/'negative-qualified.json'),'relocated_renderer_sha256':sha(P/'relocated-renderer.json'),'sdk_sha256':sdk['archive_sha256'],'sdk_verified_files':sdk['verified_files'],'native_binary_sha256':sha(P/'vellum-workbench'),'internal_source_review_sha256':sha(P/'source-review.json'),'human_online_live_stop_sha256':sha('/private/tmp/vellum-macos-quiet-current/stop-live'),'offscreen_test_executables_ran':True,'native_application_executed':False,'gpu_qualified':False,'native_latency_qualified':False,'retained_memory_qualified':False,'full_mac_qualified':False,'full_P4_qualified':False,'full_P6_qualified':False,'full_P11_qualified':False,'excluded_attempts':{'fused-unit-v1':'initial focused vector before independent helper/new phase and refusal tests; superseded by v2','negative-classifier-v1':'collision test failed at intended exact-equality assertion, but classifier searched wrong token; raw source/result preserved, corrected qualification checks exact diagnostic'},'limits':['First-point fingerprint is internal candidate index; min-origin replay and full exact match remain required','Local software elapsed medians are diagnostic on shared computer, not native/whole-frame qualification','No native app/GPU/physical/human/endurance test; failed4/6ms native targets and fullMac/rights gates remain open']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k]for k in ['result','original_prepared_files','candidate_prepared_files','matrix_records_per_arm','fault_controls','sdk_verified_files']}))
