from pathlib import Path
import difflib,hashlib,json
R=Path('/private/tmp/vellum-scene-profile');P=Path(__file__).resolve().parent;U=R/'drivers/cogent/build/upstream';D=R/'drivers/cogent/native/patches/glyphfingerprint';D.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();inputs={};outputs={};patch=[]
files={'paint/renderers/rasterx/glyph_coverage.go':P/'glyph_coverage-original.go.txt','paint/renderers/rasterx/glyph_lookup_vellum_test.go':P/'glyph_lookup-original_test.go.txt','paint/renderers/rasterx/glyph_fingerprint_vellum_test.go':None}
for name,old in files.items():
 prior=old.read_bytes()if old else b'';new=(U/name).read_bytes();inputs[name]=sha(prior)if old else None;outputs[name]=sha(new)
 patch.extend(difflib.unified_diff(prior.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name if old else'/dev/null',tofile='b/'+name))
f=D/'0068-single-pass-glyph-fingerprint.patch';f.write_text(''.join(patch))
for name,value in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (D/name).write_text(json.dumps(value,indent=2)+'\n')
m=R/'drivers/cogent/native/dependencies.json';obj=json.loads(m.read_text());assert obj['dependencies'][0]['stages'][-1]['origin'].endswith('/packedcoverage');obj['dependencies'][0]['stages'].append({'origin':'drivers/cogent/native/patches/glyphfingerprint','inputs':'native/patches/glyphfingerprint/original-hashes.json','outputs':'native/patches/glyphfingerprint/output-hashes.json','patches':[{'file':'native/patches/glyphfingerprint/'+f.name,'sha256':sha(f.read_bytes())}]});m.write_text(json.dumps(obj,indent=2)+'\n')
t=R/'drivers/cogent/prepare_test.py';s=t.read_text();assert s.count('list(range(1, 68))')==1;t.write_text(s.replace('list(range(1, 68))','list(range(1, 69))'))
(D/'README.md').write_text('''# One-pass glyph fingerprint

Owned patch 0068 combines fixed-path grammar/coordinate/bounds validation and
internal FNV candidate indexing in one walk. Fingerprints normalize coordinates
to the first validated point pixel origin, preserving integer translations and
fractional phases. Signed relative words may be negative. The returned minimum
origin, guarded hull and full minimum-normalized path comparison stay unchanged.
No new cache, retained metadata, storage bound, packet format or work exemption
is introduced. Hash values are private bucket indices, not persisted identities.

The original geometry-admission/origin and full-equality oracles remain. The old
minimum-origin hash assertion is deliberately superseded by an independent
first-point callback-walker oracle, 4,096 fractional phases, integer translations,
permissive private grammar, malformed/refused inputs and forced collisions.
Actual software grid encoded/accounting/pixel parity, failure controls, pinned
preparation and SDK checks are required. Local software elapsed times are
diagnostic while the human is online; native frame targets remain unqualified.
''')
print(json.dumps({'patch_sha256':sha(f.read_bytes()),'prepared_files':sum(1 for name in ['upstream','typesetting']for f in (R/'drivers/cogent/build'/name).rglob('*')if f.is_file())}))
