from pathlib import Path
import hashlib,json
R=Path('/private/tmp/vellum-scene-profile');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=json.loads((P/'negative-results.json').read_text());(P/'negative-results-v1.json').write_text(json.dumps(prior,indent=2)+'\n')
current={}
for name,row in prior.items():
 d=json.loads((P/('negative-'+name+'.json')).read_text());out=(P/('negative-'+name+'.stdout')).read_text();message='fingerprint substituted for exact path'if name=='collision-authority'else row['expected_diagnostic']
 assert d['exit_code']==1 and d['error']is None and d['source_delta_stable']and d['prepared_before']==d['prepared_after']and d['overlay_inputs_before']==d['overlay_inputs_after']and message in out and '[build failed]'not in out
 assert row['receipt_sha256']==sha(P/('negative-'+name+'.json'))and row['candidate_sha256']==sha(R/'drivers/cogent/build/upstream/paint/renderers/rasterx/glyph_coverage.go')
 current[name]={**row,'intended_failure':True,'expected_diagnostic':message}
(P/'negative-qualified.json').write_text(json.dumps({'result':'PASS_FIVE_TARGETED_ASSERTION_FAILURES','controls':current,'classifier_correction':'Initial collision classifier searched for collision; the actual intended assertion is fingerprint substituted for exact path. Raw test did fail as intended. Original classifier output retained; no source/product correction required.','native_binary_executed':False},indent=2)+'\n')
print('PASS_FIVE_TARGETED_ASSERTION_FAILURES')
