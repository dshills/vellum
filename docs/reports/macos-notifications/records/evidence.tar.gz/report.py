"""Bind implementation and offscreen receipts; never claim notification delivery."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-notifications')
report=r/'docs/reports/macos-notifications';records=report/'records'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
src=json.loads((p/'source-v1.json').read_text());files=src['sources']
assert len(files)==15 and all(sha(r/n)==h for n,h in files.items())
review=json.loads((p/'source-review-v1.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings'] and review['files']==files
prepared=json.loads((p/'prepared-identity.json').read_text())['files']
actual={f.relative_to(r/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
assert len(actual)==6174 and actual==prepared
names=['root-final','root-vet','driver-final','driver-vet','native-build-final','sdk-final-authorized','sdk-vet','sdk-package','sdk-check','build-metadata','native-load-commands']
process={}
for n in names:
 d=json.loads((p/(n+'.json')).read_text());assert d['exit_code']==0 and d['error'] is None and d['live_tests'] is False,n
 for stream in ['stdout','stderr']:assert sha(p/(n+'.'+stream))==d[stream+'_sha256']
 process[n]=d
sdk=json.loads((p/'sdk-identity.json').read_text());manifest=json.loads((p/'private-sdk-manifest.json').read_text());check=json.loads((p/'sdk-check.stdout').read_text())
assert sdk['verified_manifest_files']==6943 and sdk['source_freeze_all_match'] and all(manifest['files'][n]==h for n,h in files.items())
assert sha(p/'private-sdk.tar.gz')==sdk['sha256']==check['archive_sha256'] and check['verified_files']==6943 and check['digest_verified_against_expected'] and check['path_contains_spaces']
assert check['native_runtime']=='not executed' and check['public_distribution_audit']=='not certified'
prism=json.loads((p/'prism-v1/prism.json').read_text());pp=json.loads((p/'prism-v1/process.json').read_text());coverage=prism['coverage']
assert pp['exit_code']==0 and pp['error'] is None and pp['source_index_stable'] and pp['before']==files and pp['after']==files and pp['prism_sha256']==sha(p/'prism-v1/prism.json')
assert not prism['findings'] and coverage['complete'] and coverage['files']==15 and coverage['chunks']>0 and not coverage['excluded'] and not coverage['skipped'] and coverage['truncatedBytes']==0
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
promotion=json.loads((p/'promotion-provenance.json').read_text());assert promotion['result']=='EXACT_REVIEWED_CONTROL_FLOW_ADAPTATION' and promotion['producer_sha256']==sha(p/'promote.py')
q={'result':'PASS_OFFSCREEN_MAC_NOTIFICATIONS','base_commit':src['base_commit'],'source':files,'prepared':prepared,'process':process,'sdk':sdk,'sdk_check':check,'prism_findings':0,'prism_findings_resolved':True,'prism_coverage':coverage,'source_review_sha256':sha(p/'source-review-v1.json'),'native_binary_sha256':sha(p/'workbench-final'),'notification_center_access':False,'live_tests':False,'whole_macos_completion':False,'performance_acceptance':False,'distribution_audit':'pending'}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(parents=True,exist_ok=False)
excluded={'workbench','workbench-final','private-sdk.tar.gz'}
members={f.relative_to(p).as_posix():{'size':f.stat().st_size,'sha256':sha(f)}for f in sorted(p.rglob('*'))if f.is_file() and f.name not in excluded and '__pycache__' not in f.parts}
a=records/'evidence.tar.gz'
with a.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0)as z,tarfile.open(fileobj=z,mode='w',format=tarfile.PAX_FORMAT)as t:
 for n in members:
  b=(p/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;i.uid=i.gid=0;i.uname=i.gname='';t.addfile(i,io.BytesIO(b))
(records/'archive-index.json').write_text(json.dumps({'schema':1,'members':members,'archive_sha256':sha(a),'excluded_binary_and_sdk_payloads':sorted(excluded)},indent=2)+'\n')
checkpoint={'result':q['result'],'base_commit':q['base_commit'],'qualification_sha256':sha(p/'qualification.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':0,'prism_findings_resolved':True,'archive':{'sha256':sha(a),'members':len(members)},'notification_center_access':False,'live_tests':False,'macos_completion':False}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
(report/'README.md').write_text(f'''# Mac local notifications checkpoint

Optional `app.NotificationServices` and `Application.Notifications()` add current
permission/alert/sound snapshots, explicit alert/sound authorization, immediate
local delivery and targeted withdrawal in Mac app bundles. Notify never requests
permission. Denied/undetermined authorization returns ErrNotificationPermission.
Only explicit RequestNotificationPermission can prompt. Sound defaults off.

Reserved native IDs, bounded UTF-8 content, distinct withdrawal batches, shared
eight-credit dispatch, copied/pooled payloads and context/shutdown checks follow
the [contract](../../../specs/notifications.md). Success means accepted delivery
or dispatched removal; actual presentation/removal, ordering and rollback are
separate. The center delegate is unchanged. Delivered items may outlive the app.

Seven new tests cover root bounds/IDs/optional compatibility, independent public
consumer permission/replacement/withdrawal, context preflight, required typed
settings, actual native parsing/content/request objects, detached producers,
injected settings normalization and the actual C-to-Go permission error.
No test accesses UNUserNotificationCenter, prompts, delivers/withdraws, opens UI,
plays sound or changes OS settings. Full root/native offscreen race, root/driver/
consumer vet, public consumer race and final native compilation pass.

Initial ARC switch/block-lifetime compile failures are preserved and corrected
with per-case scopes. An initial full public consumer run failed on sandboxed
private Unix-socket binding; its authorized retry passes. Duplicate-libobjc
warnings remain. Go 1.27.2/macOS 26.0 minimum/SDK 27.0 describe local compilation,
without runtime or older-Mac acceptance.

Private SDK verification covers all 6943 files, all 15 source hashes and digest
`{sdk['sha256']}`. Relocation with spaces, in-SDK replacements, module integrity,
generated consumer race/vet/build and public scenarios pass; runtime is not
executed and distribution is not certified. All 6174 prepared files remain
unchanged from the preceding committed tray checkpoint; dependency pins/patches
are unchanged.

Internal source review approves all 15 frozen files. One Anthropic Claude
Sonnet 5.5 Prism review has complete 15-file/{coverage['chunks']}-chunk coverage,
raw exit0 and zero findings. Promotion preserves the previously reviewed
clean/base/sole-child/ff-only/source+prepared guards with mechanical phase/base/
result/prose substitutions; their provenance is retained.

The computer-free constraint persists. Packaged authorization/denial, real
presentation/sound/replacement/removal, concurrent ordering, foreground/delegate
interoperation and restart remain live checks. Full Mac/P10, input/accessibility,
sustained performance and public distribution remain open.

[Checkpoint](records/checkpoint.json), [raw evidence](records/evidence.tar.gz)
and [member index](records/archive-index.json) bind this offscreen scope.
''')
print(json.dumps({'result':q['result'],'members':len(members),'archive_sha256':sha(a),'report_sha256':sha(report/'README.md'),'checkpoint_sha256':sha(records/'checkpoint.json')}))
