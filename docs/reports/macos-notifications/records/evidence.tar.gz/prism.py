import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-notifications');sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
out=phase/'prism-v1';out.mkdir(exist_ok=False)
files=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root).decode().splitlines();assert len(files)==15
assert set(files)==set(json.loads((phase/'source-v1.json').read_text())['sources'])
before={name:hashlib.sha256((root/name).read_bytes()).hexdigest()for name in files};diff=subprocess.check_output(['git','diff','--cached','--binary','--']+files,cwd=root)
assert before==json.loads((phase/'source-v1.json').read_text())['sources']
(out/'inputs.json').write_text(json.dumps({'files':before,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Fifteen staged Mac notification source/test/contract/development files only. Runtime logs, binaries, host artifacts and raw review histories excluded.'},indent=2)+'\n');(out/'staged.diff.txt').write_bytes(diff)
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(files),'--out',str(out/'prism.json')];start=time.monotonic();error=None
with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:
 try:result=run_child(argv,cwd=root,stdout=so,stderr=se,timeout=480);code=result.returncode
 except Exception as exc:code=125;error={'type':type(exc).__name__,'message':str(exc)}
after={name:hashlib.sha256((root/name).read_bytes()).hexdigest()for name in files};afterdiff=subprocess.check_output(['git','diff','--cached','--binary','--']+files,cwd=root)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'before':before,'after':after,'source_index_stable':before==after and diff==afterdiff,'prism_sha256':hashlib.sha256((out/'prism.json').read_bytes()).hexdigest()if(out/'prism.json').exists()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');(out/'producer.py.txt').write_bytes(Path(__file__).read_bytes());print('PRISM',code,'stable',record['source_index_stable'],'seconds',round(record['elapsed_seconds'],1));sys.exit(code)
