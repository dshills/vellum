from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
name=sys.argv[1];assert name=='validation-final-v2'
s=importlib.util.spec_from_file_location('validation_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
pins={str(p):h.sha(p)for p in[W/'validate.py',W/'validation_controls.py',Path(__file__),h.GUARD,Path(h.__file__)]}
r=h.g.execute(['/usr/bin/python3','-B',str(W/'validation_controls.py')],W,W/name,lambda:False,lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=30,limit=1<<20);r['source_pins']=pins;r['native_executed']=False
(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');h.need(r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors'],'validator checks');print(json.dumps({'exit_code':r['exit_code'],'seconds':r['seconds'],'synthetic_checks':24,'native_executed':False}))
