from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def git(*args):return run_child(['git',*args],cwd=T,timeout=30,capture_output=True,check=True).stdout
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=['drivers/cogent/cmd/gallery/'+n for n in ['main.go','choice_catalogue.go','choice_catalogue_test.go','choice_catalogue_offscreen_test.go','README.md']]+['specs/'+n for n in ['macos-delivery.md','macos-completion.md','control-acceptance.md']]+['docs/desktop-integration.md','docs/reports/macos-choice-catalogue/README.md','docs/reports/macos-choice-catalogue/records/results.json']
assert json.loads((W/'review-paths.json').read_bytes())==paths and not(W/'review-scope.json').exists()
assert json.loads((W/'result.json').read_bytes())['result']=='PASS_NATIVE_CHOICES'
git('add','--',*paths);git('diff','--cached','--check');assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)and not git('diff','--name-only')
diff=git('diff','--cached','--binary');assert 0<len(diff)<100000
r={'base_commit':git('rev-parse','HEAD').decode().strip(),'paths':paths,'files':{n:sha(T/n)for n in paths},'staged_diff_bytes':len(diff),'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'native_result':'PASS_NATIVE_CHOICES'}
(W/'review-scope.json').write_text(json.dumps(r,indent=2)+'\n');(W/'staged.diff').write_bytes(diff);print(json.dumps({k:r[k]for k in ['staged_diff_bytes','staged_diff_sha256']}))
