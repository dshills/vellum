from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert read(W/'internal-prism-disposition.json')['approved']and not read(W/'internal-prism-disposition.json')['unresolved_findings']
prism=read(W/'prism.json');assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1 and prism['coverage']['files']==11 and prism['coverage']['bytes']==51880
name='docs/reports/macos-choice-catalogue/README.md';p=T/name;provider=read(W/'review-scope.json');assert sha(p)==provider['files'][name]==sha(W/'versions/provider-reviewed-README.md')
s=p.read_text();marker='## Limits and next work';assert marker in s
s=s.replace(marker,'''Prism reviewed all 11 staged files (51,880 bytes) in one Anthropic Claude Sonnet
5.5 call, with no excluded/skipped/truncated input or suppressed findings. The
raw CLI exits 1 with one medium diagnostic finding; one further medium comment
is discarded by Prism's quoted-evidence matching. Both raw comments are retained
and independently assessed. The retained lookup-error condition cannot occur:
the same detached snapshot's full ID set is checked before the later subset
lookups, with no intervening mutation. Ordinary gallery rejection flags remain
false and are toggled only by catalogue checks/tests; the discarded comment
does not establish a normal-mode regression. No source change or provider rerun
is needed. This factual README-only addition receives final internal review;
the original provider payload/scope and reviewed README are preserved separately.

'''+marker,1);p.write_text(s)
run_child(['git','add','--',name],cwd=T,timeout=30,check=True)
diff=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,check=True,capture_output=True).stdout
r={**provider,'files':{n:sha(T/n)for n in provider['paths']},'staged_diff_bytes':len(diff),'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'provider_staged_diff_sha256':provider['staged_diff_sha256'],'post_provider_changed_paths':[name]}
assert all(r['files'][n]==z for n,z in provider['files'].items()if n!=name)
(W/'final-scope.json').write_text(json.dumps(r,indent=2)+'\n');(W/'final-staged.diff').write_bytes(diff);print(json.dumps({'bytes':len(diff),'sha256':r['staged_diff_sha256']}))
