"""One native choices case; exact review/plan, shared lease, bounded owner, terminal seal."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('choices_boundaries',W.parent/'macos-control-refocus-4d0b5f7/run.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
h=b.h;g=b.g;sha=b.sha;need=b.need;read=b.read;C=b.C;T=b.T;SDK=b.SDK
sys.path.insert(0,str(W));import validate as validator
HEAD='500cf8016e114b3ef3fba029c9cd086592bc3224'
CHANGED=['drivers/cogent/cmd/gallery/main.go']
NEW=['drivers/cogent/cmd/gallery/'+n for n in ['choice_catalogue.go','choice_catalogue_offscreen_test.go','choice_catalogue_test.go']]
def source():
 need(b.git(C,'rev-parse','HEAD').decode().strip()==HEAD and not b.git(C,'status','--porcelain'),'clean canonical500cf80')
 names=b.git(C,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5378,'canonical tracked count');return{n:sha(C/n)for n in names}
def candidate():
 need(b.git(T,'rev-parse','HEAD').decode().strip()==HEAD and b.git(T,'diff','--name-only').decode().splitlines()==CHANGED,'exact candidate tracked delta')
 need(set(b.git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(NEW)and not b.git(T,'diff','--cached','--name-only'),'exact three new consumer/tests')
 names=b.git(T,'ls-files','-z').decode().split('\0')[:-1]+NEW;return{n:sha(T/n)for n in names}
def baseline():
 a=source();t=candidate();need(set(t)==set(a)|set(NEW)and all(t[n]==z for n,z in a.items()if n not in CHANGED),'unchanged other tracked source')
 p=b.prepared(C);need(len(p)==6267 and b.prepared(T)==p,'same complete stage83')
 sdk=read(W.parent/'macos-native-workspace-594bd37/native-v5/plan.json')['sdk_files'];need(b.vector(SDK)==sdk,'retained SDK unchanged')
 mapping=read(W/'overlay.json')['Replace']
 for original,replacement in mapping.items():
  rel=Path(original).relative_to(SDK)
  if rel.as_posix().startswith('examples/'):continue
  need(Path(replacement).read_bytes()==(T/rel).read_bytes(),'current overlay '+str(rel))
 for n,z in p.items():
  q=SDK/'drivers/cogent/build'/n;need(sha(mapping.get(str(q),str(q)))==z,'whole prepared overlay')
 return a,t,p,sdk
def prepare():
 need(not(W/'plan.json').exists()and not(W/'case').exists(),'fresh choices scope');a,t,p,sdk=baseline();review=read(W/'internal-source-review.json')
 need(review['approved']and not review['unresolved_findings']and all(sha(k)==z for k,z in review['inputs'].items()),'exact source/controller review')
 pins={}
 for name in ['gallery-final','vet-final','build-final','validation-final-v2']:
  r=read(W/(name+'.json'));need(b.passing(r),'owned prerequisite '+name);need(all(sha(k)==z for k,z in r['source_pins'].items()),'source pins '+name)
  pins.update(r['source_pins']);pins[str(W/(name+'.json'))]=sha(W/(name+'.json'))
  for stream,info in r['logs'].items():
   q=W/name/stream;need(q.stat().st_size==info['bytes']and sha(q)==info['sha256'],'raw prerequisite');pins[str(q)]=sha(q)
 paths=[Path(__file__),W/'validate.py',W/'validation_controls.py',W/'internal-source-review.json',Path(b.__file__),Path(h.__file__),h.GUARD,h.GO,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(q):sha(q)for q in paths});now=datetime.datetime.now(datetime.timezone.utc);binary=read(W/'build-final.json')['binary'];need(sha(binary['path'])==binary['sha256'],'exact fresh native binary')
 plan={'head':HEAD,'canonical_source':a,'candidate_source':t,'prepared':p,'sdk':str(SDK),'sdk_files':sdk,'pins':pins,'binary':binary,'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'runtime_options':{k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']},'watchdog_seconds':120,'stream_limit_bytes':4<<20,'scope':'One fresh30-input23-observation choice catalogue. Public gallery factories and DesktopSession Go FIFO: checkbox/switch/toggle pointer+keyboard, radio/segments shared selection/rejection/disabled skip+refusal, Slider keyboard/rejection/min/max/bounded once-per-Change proposal, progress numeric semantics/layout and status, ordinary action once, original ref and terminal session closure. Independent literal validator and24synthetic controls; controlled GOMAXPROCS2, SDK786a CPU scene, current Go500cf80 plus four consumer/test files. No Slider drag/pixels/presentation/physical OS input/IME/VoiceOver/display/performance/Cocoa-deallocation/full catalogue/M2-M7 acceptance. Shared lease, exact source/prepared/SDK/pin boundaries, no network or SDK writes, bounded owned group cleanup, single attempt then terminal seal. No OS prefs/input/clipboard changes, no operator/sealed-placement retries, SDK refresh or public release.'}
 (W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(W/'plan.json'),'native_executed':False}))
def run():
 raw=(W/'plan.json').read_bytes();araw=(W/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(araw);stop=W/'stop-live';need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact plan admission');need(not stop.exists()and not(W/'case').exists()and not(W/'result.json').exists(),'one fresh case')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==araw and all(sha(k)==z for k,z in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  need(not stop.exists()and stable(),'stable inputs/no stop');need(baseline()==(p['canonical_source'],p['candidate_source'],p['prepared'],p['sdk_files']),'whole source/prepared/SDK boundary');need({k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']}==p['runtime_options'],'runtime options')
 d={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('choices controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline');profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(SDK))+'))'
   r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],'-choice-native-check'],SDK/'drivers/cogent',W/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);d['run']=r;d['native_executed']=r['created'];need(b.passing(r),'owned native result');d['summary']=validator.validate((W/'case/stdout').read_bytes(),(W/'case/stderr').read_bytes());boundary();need(lease.held(),'lease through cleanup');d['result']='PASS_NATIVE_CHOICES'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error','summary']}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in[['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
