from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
read=lambda p:json.loads(Path(p).read_bytes())
r=read(W/'result.json');assert r['result']=='PASS_NATIVE_CHOICES'and r['summary']['inputs']==30 and r['summary']['observations']==23
report=T/'docs/reports/macos-choice-catalogue';(report/'records').mkdir(parents=True,exist_ok=False)
(report/'README.md').write_text('''# Native choices, toggles and progress publication

The standard gallery now offers `-choice-native-check`: **30 public Go FIFO
inputs and 23 independently expected observations** pass on this Mac. It reuses
the ordinary gallery's public `ui.Node` factories for Checkbox, Switch,
ToggleButton, RadioGroup, SegmentedControl, Slider and three progress kinds.
Applications consume the existing public Go APIs; no new driver API or dependency
patch is introduced. This is one named native catalogue record, not full M2/M5
or Mac completion.

The record checks pointer and Space activation, ancestor disabling/refusal and
re-enabling, actual keyboard focus, exclusive shared choice state, disabled
option skipping, rejected selection restoration, and no duplicate proposal when
Space accepts the already selected segment. Slider keys test accepted/rejected
changes, Home/End bounds and progress/status publication at zero and full scale.
The final ordinary action fires once. Closing the original window invalidates
its reference; later input is refused, and the public session closes with no
pending request or live window. The owned process group is confirmed absent.

The Slider sends one Change proposal per attempted step: Right at 100 proposes
the clamped value 100 once. It therefore ends with five numeric callbacks,
including the rejected increment. Choice Space on the selected option emits no
additional proposal. These distinct existing contracts were authored from source
before native execution; the expected native record was not changed after a run.

## Checks and review

The complete gallery race suite, gallery vet and native build pass on the final
four Go files. An independent public Manual consumer tests geometry, keyboard
focus order, shared selection, rejected changes, progress values and a disabled/
re-enabled round trip. These software checks are separate from native evidence.
The unchanged root driver's complete race suite qualified at base `500cf80` is
reused only for identical affected driver bytes; it is not claimed as a new run.

The external native validator checks all 30 ordered packet identities/types/key
runes, current frames, actual focused keyboard targets and measured pointer
bounds, all 23 literal models/callback counts, group-qualified option identities,
effective enabled flags, controlled semantics, progress/status and closure.
Twenty-four synthetic positive/negative validator controls pass. Synthetic data
is not native proof. Internal source/controller, exact-plan admission and final
evidence reviews accompany one scoped Prism Anthropic Claude Sonnet 5.5 review.

Earlier headless failures remain retained: an initial wrong state type prevented
compilation; an output-directory collision produced an unqualified build without
a receipt; software routing caught missing Space runes before any native launch.
An initial validator test process passed all tests but sandbox restrictions
prevented process-group observation; its distinct owned rerun passes. Only the
final current-source receipts and complete native record qualify this checkpoint.

## Limits and next work

This is controlled GOMAXPROCS=2, Go1.25.6 Darwin/ARM64, CPU-scene native routing
over the retained source-built archive `786aaad8...`. All 6267 stage83 prepared
files and all 7880 retained SDK files remain unchanged. It does not qualify a
refreshed SDK, another native archive/configuration or production performance.

Progress bars/ring/gauge, icon/label and composed chrome are checked for numeric
semantics and fully visible layout; this new native record does not assert their
pixels or display presentation. Slider pointer dragging remains separate. Go
FIFO input does not verify physical/OS pointer and keyboard, IME, VoiceOver,
display transitions or Cocoa deallocation. No OS settings/input sources/clipboard
change, SDK refresh or public release is performed. Full M2 and M3–M7 remain open.

Continue native list/menu, tabs/disclosure/scroll/split, text/modal and composite
control scenarios against the [acceptance map](../../../specs/control-acceptance.md),
then the unchanged performance/resource/platform/SDK gates in the
[delivery plan](../../../specs/macos-delivery.md). Use the
[gallery instructions](../../../drivers/cogent/cmd/gallery/README.md) to run it.
The [bounded archive](records/checkpoint.tar.gz) and [member manifest](records/manifest.json)
retain complete qualifying logs and earlier failures without binaries or fonts.
''')
checks={}
for n in ['gallery-final','vet-final','build-final','validation-final-v2']:
 q=W/(n+'.json');c=read(q);checks[n]={'receipt_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),**{k:c[k]for k in ['exit_code','seconds','logs_complete','pins_stable']},'owned_group_absent':c['owned']['group_absent']}
summary={'base_commit':'500cf8016e114b3ef3fba029c9cd086592bc3224','native':r,'checks':checks,'prepared_files':6267,'sdk_files':7880,'sdk_unchanged':True,'physical_input_verified':False,'slider_drag_verified':False,'progress_pixels_verified':False,'closed_full_mac_gates':[],'goal_complete':False}
(report/'records/results.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraph='''The [choice catalogue checkpoint](../docs/reports/macos-choice-catalogue/README.md)
adds a complete 30-input/23-observation native record for Checkbox, Switch,
ToggleButton, RadioGroup, SegmentedControl and Slider keyboard behavior. Shared
state, rejected changes, disabled skipping/refusal, focus and exactly-once
callbacks pass. ProgressBar/Ring/Gauge and status publish expected values and
fully visible geometry; native progress pixels and Slider drag are not claimed.
Original-reference/session/process retirement passes. This advances named
catalogue coverage in controlled Go2/SDK786a CPU-scene routing; remaining catalogue,
full M2/M5, physical/human input and M3–M7 remain open. No SDK refresh occurs.

'''
for name,marker in [('macos-delivery.md','## Finish line'),('macos-completion.md','## M1 SDK command ownership'),('control-acceptance.md','The remaining native catalogue work is:')]:
 p=T/'specs'/name;s=p.read_text();assert marker in s;s=s.replace(marker,paragraph+marker,1);p.write_text(s)
p=T/'drivers/cogent/cmd/gallery/README.md';s=p.read_text();s+='''
## Native choice catalogue

```sh
go run ./cmd/gallery -choice-native-check
```

This independent mode uses the same ordinary public constructors in a compact
900x700 requested window. It routes 30 inputs and checks 23 observations, then
closes its original window and emits one JSON result. The 90-second deadline,
6-second worker join, nonzero failures and disabled geometry persistence match
the other catalogue mode. These modes and `-exit-after` are mutually exclusive.

Checkbox, Switch and ToggleButton receive pointer/Space input. RadioGroup and
SegmentedControl share selection, skip disabled options and restore rejected
requests. Slider keyboard changes drive progress/status values. Right at its
maximum sends one clamped Change proposal; selected-choice Space sends none.
Final native routing passes with exact callback counts and terminal cleanup.
Progress checks cover semantics/layout, not native pixels; Slider drag and
physical/OS input remain separate. See the [result](../../../../docs/reports/macos-choice-catalogue/README.md).
''';p.write_text(s)
p=T/'docs/desktop-integration.md';s=p.read_text();s+='''

The gallery's `-choice-native-check` is a separate bounded mode for shared
choices, toggles and Slider keyboard input: 30 routed inputs/23 observations pass
with callback/rejection/disabled/focus/closure checks. Progress/status publication
uses numeric semantics and measured layout, not native pixel validation. It
uses the same public API and current exact group-qualified option identities;
repeated option DomainIDs across groups are not input capabilities. See the
[native choice result](reports/macos-choice-catalogue/README.md). Physical/OS input,
Slider drag, presentation and full Mac gates remain open.
''';p.write_text(s)
paths=['drivers/cogent/cmd/gallery/'+n for n in ['main.go','choice_catalogue.go','choice_catalogue_test.go','choice_catalogue_offscreen_test.go','README.md']]+['specs/'+n for n in ['macos-delivery.md','macos-completion.md','control-acceptance.md']]+['docs/desktop-integration.md','docs/reports/macos-choice-catalogue/README.md','docs/reports/macos-choice-catalogue/records/results.json']
(W/'review-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'paths':len(paths),'native':r['summary']}))
