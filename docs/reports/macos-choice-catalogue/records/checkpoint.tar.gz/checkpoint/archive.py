from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-choice-catalogue/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
review=read(W/'internal-prism-disposition.json');assert review['approved']and not review['unresolved_findings']
files={}
def add(p,n):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in files and not n.startswith('/')and '..'not in Path(n).parts;files[n]=p
for name in ['gallery','vet','build','gallery-v2','vet-v2','build-v2','gallery-v3','routing-v1','routing-v2','gallery-final','vet-final','build-final','validation-final','validation-final-v2']:
 q=W/(name+'.json')
 if q.is_file():add(q,'checks/'+name+'.json')
 # Strict log whitelist: build-v2 once wrote a binary into a log directory.
 for stream in ['stdout','stderr','owned.json']:
  q=W/name/stream
  if q.is_file():add(q,'checks/'+name+'/'+stream)
for p in sorted((W/'versions').iterdir()):add(p,'versions/'+p.name)
for n in ['run.py','check.py','check_validation.py','validate.py','validation_controls.py','overlay.json','machine.json','build-v2-status.json','internal-source-review.json','plan.json','admission.json','result.json','stop-live','finish_docs.py','revise_docs.py','stage.py','review-paths.json','review-scope.json','staged.diff','finalize_provider_docs.py','final-scope.json','final-staged.diff','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','archive.py','ready_commit.py','post_promotion.py']:
 add(W/n,'checkpoint/'+n)
for n in ['stdout','stderr','owned.json']:add(W/'case'/n,'native/'+n)
for n in read(W/'final-scope.json')['paths']:add(T/n,'source/'+n)
origins={n:str(p)for n,p in sorted(files.items())};(W/'member-origins.json').write_text(json.dumps(origins,indent=2)+'\n');add(W/'member-origins.json','checkpoint/member-origins.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(x['bytes']for x in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(x['bytes']<=10<<20 for x in manifest.values())
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as out:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;out.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as check:
 for m in check:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=check.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
prism=read(W/'prism.json');command=read(W/'prism-command.json')
r={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'native_record':'PASS30/23','physical_input_verified':False,'full_mac_complete':False,'provider_review':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':prism['coverage']['llmCalls'],'files':len(read(W/'review-scope.json')['paths']),'complete':prism['coverage']['complete'],'exit_code':command['exit_code'],'retained_findings':len(prism['findings']),'internal_disposition_approved':review['approved']}};(R/'archive.json').write_text(json.dumps(r,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
