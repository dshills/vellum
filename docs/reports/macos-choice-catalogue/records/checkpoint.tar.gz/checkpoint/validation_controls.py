"""Synthetic parser controls only. No native execution or product acceptance."""
import copy,json,unittest
import validate as v
def snapshot(frame,w):
 els=[]
 for i,(id,role)in enumerate(v.ROLES.items()):
  els.append({'ID':v.managed(id),'DomainID':id,'Parent':'','Role':role,'Name':id,'Bounds':{'Min':{'X':20,'Y':10+30*i},'Max':{'X':200,'Y':35+30*i}},'Enabled':w[0]if id in ['radio-preset','segmented-preset','slider']else True,'Focused':False,'Selected':False,'Value':None})
 by={e['DomainID']:e for e in els}
 for id,value in [('enable',w[0]),('snapping',w[1]),('pinned',w[2])]:by[id]['Value']=value
 for group in ['radio-preset','segmented-preset']:
  by[group]['Value']={'basic':'Basic','advanced':'Advanced'}[w[3]]
  for opt in ['basic','advanced','unavailable']:
   els.append({'ID':v.option(group,opt),'DomainID':opt,'Parent':v.managed(group),'Role':'option','Name':opt,'Bounds':copy.deepcopy(by[group]['Bounds']),'Enabled':w[0]and opt!='unavailable','Focused':False,'Selected':opt==w[3],'Value':opt==w[3]})
 for id in ['slider','progress','progress-ring','progress-gauge']:by[id]['Value']=w[4]if id=='slider'else w[4]/100
 by['choice-status']['Value']=f'Preset {w[3]} / level {w[4]:g}'
 return {'Frame':frame,'Size':{'X':900,'Y':700},'LogicalDPI':160,'Elements':els,'Popups':None}
def fixture():
 d={'Event':'vellum.choices-native.result','Result':'PASS_NATIVE_CHOICES','Error':'','Steps':[],'Inputs':[],'OriginalRefClosed':True,'PostCloseInputError':'closed','Session':{'Started':True,'Closed':True,'Pending':False,'LiveWindows':0,'Issued':200}}
 for i,(label,w)in enumerate(zip(v.LABELS,v.VALUES)):
  s=snapshot(100+i,w)
  if i==16:next(e for e in s['Elements']if e['DomainID']=='slider')['Focused']=True
  d['Steps'].append({'Label':label,'Model':dict(zip(v.KEYS,w)),'Snapshot':s})
 for i,(label,target,typ,code,rejected)in enumerate(v.PACKETS):
  w=v.VALUES[1]if label in ['disabled-slider','disabled-radio']else v.VALUES[0];s=snapshot(i+1,w);el=next((e for e in s['Elements']if e['ID']==target),None)
  pos={'X':0,'Y':0}
  if el:
   el['Focused']=True;b=el['Bounds'];pos={'X':(b['Min']['X']+b['Max']['X'])//2,'Y':(b['Min']['Y']+b['Max']['Y'])//2}
  d['Inputs'].append({'Label':label,'Before':s,'Rejected':rejected,'Input':{'Frame':s['Frame'],'Target':target,'Type':typ,'Code':code,'Rune':32 if code=='Spacebar'else 0,'Modifiers':'','Button':'Left'if typ.startswith('Mouse')or rejected else 'NoButton','Position':pos,'Delta':{'X':0,'Y':0}}})
 return d
class Controls(unittest.TestCase):
 def bad(self,fn):
  d=fixture();fn(d)
  with self.assertRaises((ValueError,TypeError,KeyError)):v.validate(json.dumps(d).encode())
 def test_positive(self):self.assertEqual(v.validate(json.dumps(fixture()).encode())['inputs'],30)
 def test_missing_step(self):self.bad(lambda d:d['Steps'].pop())
 def test_missing_input(self):self.bad(lambda d:d['Inputs'].pop())
 def test_duplicate_proposal(self):self.bad(lambda d:d['Steps'][-1]['Model'].update(NumberRequests=6))
 def test_rejected_number_accepted(self):self.bad(lambda d:d['Steps'][18]['Model'].update(Number=27))
 def test_rejected_choice_accepted(self):self.bad(lambda d:d['Steps'][10]['Model'].update(Selected='advanced'))
 def test_bool_counter(self):self.bad(lambda d:d['Steps'][0]['Model'].update(OutsideClicks=False))
 def test_bool_number(self):self.bad(lambda d:d['Steps'][0]['Model'].update(Number=True))
 def test_nan_number(self):self.bad(lambda d:d['Steps'][0]['Model'].update(Number=float('nan')))
 def test_disabled_admitted(self):self.bad(lambda d:d['Inputs'][1].update(Rejected=False))
 def test_space_rune_absent(self):self.bad(lambda d:d['Inputs'][0]['Input'].update(Rune=0))
 def test_unfocused_key(self):self.bad(lambda d:next(e for e in d['Inputs'][0]['Before']['Elements']if e['DomainID']=='enable').update(Focused=False))
 def test_wrong_option_group(self):self.bad(lambda d:d['Inputs'][12]['Input'].update(Target=v.option('segmented-preset','advanced')))
 def test_wrong_parent(self):self.bad(lambda d:next(e for e in d['Steps'][0]['Snapshot']['Elements']if e['ID']==v.option('radio-preset','basic')).update(Parent=v.managed('segmented-preset')))
 def test_stale_frame(self):self.bad(lambda d:d['Inputs'][0]['Input'].update(Frame=0))
 def test_outside_pointer(self):self.bad(lambda d:d['Inputs'][4]['Input'].update(Position={'X':899,'Y':699}))
 def test_progress_wrong(self):self.bad(lambda d:next(e for e in d['Steps'][-1]['Snapshot']['Elements']if e['DomainID']=='progress-ring').update(Value=0))
 def test_status_wrong(self):self.bad(lambda d:next(e for e in d['Steps'][-1]['Snapshot']['Elements']if e['DomainID']=='choice-status').update(Value='wrong'))
 def test_duplicate_identity(self):self.bad(lambda d:d['Steps'][0]['Snapshot']['Elements'].append(copy.deepcopy(d['Steps'][0]['Snapshot']['Elements'][0])))
 def test_option_disabled_lost(self):self.bad(lambda d:next(e for e in d['Steps'][0]['Snapshot']['Elements']if e['ID']==v.option('segmented-preset','unavailable')).update(Enabled=True))
 def test_session_leak(self):self.bad(lambda d:d['Session'].update(LiveWindows=1))
 def test_stale_closed_admitted(self):self.bad(lambda d:d.update(PostCloseInputError=''))
 def test_two_results(self):
  raw=json.dumps(fixture()).encode()
  with self.assertRaises(ValueError):v.validate(raw+b'\n'+raw)
 def test_unknown_output(self):
  with self.assertRaises(ValueError):v.validate(json.dumps(fixture()).encode(),b'unknown\n')
if __name__=='__main__':unittest.main(verbosity=2)
