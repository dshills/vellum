"""Package scoped checks and current native preflight without widening acceptance."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-composed-controls');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE'and len(sources)==17 and not review['unresolved_findings']and all(sha(R/n)==h for n,h in sources.items())
prepared=json.loads((P/'native-build-v4.json').read_text())['prepared_after']
actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
assert len(prepared)==6227 and prepared==actual
checks=[]
expected={
 'adapter-race-final':['go','test','-race','-count=1','-tags','offscreen','./...'],
 'adapter-vet-final':['go','vet','-tags','offscreen','./...'],
 'native-harness-final':['go','test','-race','-count=1','-tags=vellum_native_checks','./cmd/window-cycle-smoke'],
 'native-boolean-v2':['go','test','-race','-count=1','-tags=vellum_native_checks','-run','^TestNative(WindowSnapshotBooleanWire|ServiceSnapshotRejectsPartialDecode)$','.'],
 'native-build-v4':['go','build','-tags=vellum_native_checks','-o',str(P/'window-cycle-v4'),'./cmd/window-cycle-smoke'],
 'native-vet-v2':['go','vet','-tags=vellum_native_checks','./cmd/window-cycle-smoke'],
 'native-root-vet':['go','vet','-tags=vellum_native_checks','.'],
}
for name,argv in expected.items():
 d=json.loads((P/(name+'.json')).read_text())
 assert d['argv']==argv and d['cwd']==str(R/'drivers/cogent')and d['producer_sha256']==sha(P/'code_run.py')and d['exit_code']==0 and d['error']is None and d['source_delta_stable']and d['source_delta_before']==d['source_delta_after']and d['prepared_before']==prepared==d['prepared_after']and d['overlay_inputs_before']==d['overlay_inputs_after']=={}
 assert d['live_tests']is False and d['headless_gpu_requested']is False
 for ch in['stdout','stderr']:assert d[ch+'_sha256']==sha(P/(name+'.'+ch))
 differences=[n for n,h in sources.items()if d['source_delta_before'].get(n)!=h]
 if name.startswith('adapter-'):
  for n in differences:
   assert n.endswith('.md')or 'offscreen'in(R/n).read_text().splitlines()[0]and '!offscreen'in(R/n).read_text().splitlines()[0]
 else:assert not differences
 checks.append({'name':name,'receipt_sha256':sha(P/(name+'.json')),'argv':argv,'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'later_changed_or_added_excluded_native_or_document_leaves':differences,'scope':'Offscreen compiled sources unchanged; later native-only/test-only or report edits excluded by explicit !offscreen tags.'if differences else'Exact current 17-source delta.'})
v=json.loads((P/'composed-preflight-v2-validation.json').read_text());assert v['result']=='PASS_FIVE_COMPOSED_CONTROLS_PREFLIGHT'and v['cycles']==5 and v['actions']==165
assert v['validator_sha256']==sha(P/'validate_live.py')
vr=json.loads((P/'validator-review.json').read_text());hr=json.loads((P/'harness-review.json').read_text())
assert not vr['unresolved_findings']and not hr['unresolved_findings']
failed=json.loads((P/'composed-preflight.json').read_text());assert failed['exit_code']==1 and failed['direct_child_terminal']and failed['group_absence_confirmed']and failed['inputs_stable']and failed['binary_stable']and failed['logs_complete']
for ch in['stdout','stderr']:assert failed['logs'][ch]['sha256']==sha(P/('composed-preflight.'+ch))
assert 'cannot unmarshal number' in(P/'composed-preflight.stderr').read_text()
summary={'result':'PASS_SCOPED_COMPOSED_CONTROLS_PREFLIGHT_CHECKPOINT','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources,'checks':checks,'prepared_files':6227,'prepared_map_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'source_review_sha256':sha(P/'source-review.json'),'harness_review_sha256':sha(P/'harness-review.json'),'validator_review_sha256':sha(P/'validator-review.json'),'preflight':v,'preflight_validation_sha256':sha(P/'composed-preflight-v2-validation.json'),'failed_native_attempt':{'name':'composed-preflight','receipt_sha256':sha(P/'composed-preflight.json'),'result':'FAILED_ZERO_COMPLETED_CYCLES','cause':'Native-check window OcclusionVisible boxed as an integer NSNumber; Go bool decode refused.','owned_direct_child_terminal':True,'owned_group_absence_confirmed':True,'cleanup_snapshot_qualified':False},'failed_inert_attempts':[{'name':n,'receipt_sha256':sha(P/(n+'.json')),'qualification':'Failed because the unrelated-mask fixture used the actual visible bit; not an isolating original-regression result.'}for n in['native-boolean-final','native-boolean-original']],'original_failure_evidence':'Actual first native preflight refused numeric OcclusionVisible before any completed cycles. Inert overlay attempt is not an original-regression qualification.','native_application_executed':True,'native_selector_actions_qualified':165,'automated_manual_key_pointer_routing_qualified':True,'physical_input_qualified':False,'native_focus_reveal_qualified':False,'zero_cocoa_windows_qualified':False,'menu_restoration_qualified':False,'human_voiceover_qualified':False,'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'sustained_latency_qualified':False,'current_1000_cycle_campaign_qualified':False,'full_P4_qualified':False,'full_P6_qualified':False,'full_P9_qualified':False,'full_P11_qualified':False,'full_mac_qualified':False,'os_input_sources_changed':False,'voiceover_changed':False,'clipboard_access':False,'os_preferences_changed':False,'cross_window_palette_drop_qualified':False}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k]for k in['result','prepared_files','native_selector_actions_qualified','current_1000_cycle_campaign_qualified','full_mac_qualified']}))
