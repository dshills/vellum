from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-composed-controls');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==17
assert all(sha(R/n)==h for n,h in sources.items())
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
out=P/'prism-v1';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Add bounded ListBox and named managed Canvas2D to the existing Mac all-component lifecycle fixture through current public UI APIs; independent per-window scene/options/counters. Version2 plan33 exact owner/native actions includes controlled list accept/reject/repeat and current scoped named-object canvas selection with stable native identity and advancing generations. Actual Manual layout test routes keys and measured pointer presses, preserving previous density/history/breadcrumb/color checks. Native-check snapshot fixes boxed C-comparison numeric JSON for Go bool and refuses partial decoded cleanup states; inert production-helper wire tests cover occlusion masks0/1/2/3 and malformed field types. All17source/doc/spec/test leaves internally approved. Offscreen full race/vet compiled sources unchanged by later explicitly native-only leaves, current native harness+snapshot race/vet/build pass. A corrected five-window native preflight is separately validated before sealing. This is scoped framework acceptance fixture and diagnostic repair, no public API changes. Do not infer physical input, focus/reveal, human VoiceOver, native/GPU allocation, sustained4/6ms targets, full1000campaign or completeMac/P11. Prior failed zero-cycle numeric JSON native attempt and two non-isolating bad-mask inert probes retained. New evidence records sealed after provider review.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'source-review.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
