# Composed ListBox and Canvas2D coverage

The all-component lifecycle fixture's catalog predated two accepted kinds:
ListBox and managed Canvas2D. The existing custom GPU canvas remains part of the
Workspace. A new Selections page adds an eight-option bounded ListBox and a
separate two-object named canvas, with independent models/counters per window.

Action plan version 2 extends the prior 26 steps to 33. After entering the page,
three ListBox requests accept the last ID, reject the first and repeat the last.
Each requires the exact owner callback count and unchanged accepted selection
for refusal/repetition. The native host and eight uniquely identified rows must
agree, including the disabled row and a nonempty bounded visible subset.

Two canvas presses require the selected object in the intended native parent
and publication scope. The host and both named children must share a current
nonpending generation, positive incarnation, finite clipped geometry and correct
roles/names/selection. Native identities/incarnation persist as generation
advances. Returning to Workspace preserves the original tree/density/teardown
requirements. Neither host selection nor these selectors prove physical pointer
delivery, scrolling or native focus reveal.

Acceptance requires source/prepared/binary-bound raw native observations,
callback and publication predicates, failed/partial attempts, reviews and owned
process cleanup in [records](records/qualification.json). Automated evidence must
separate inert harness predicates, actual Manual key/pointer routing, native Cocoa
selectors, and the 1000-cycle target. Five cycles would prove 165 actions, not
the complete campaign. Old 24/26-step results retain their exact scope.

No input-source, VoiceOver, clipboard or OS preferences are changed. Dense-label
definition/visibility and sampled safety bounds remain separate from the stated
physical workload, native/GPU allocation budgets, pacing/latency, overnight soak
and full P11/Mac qualification. The lifecycle duration is diagnostic wall time.
