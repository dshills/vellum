from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
R=Path('/private/tmp/vellum-composed-controls');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-composed-controls/records'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((P/'summary.json').read_text());review=json.loads((P/'checkpoint-review.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());prism=json.loads((P/'prism-v1/prism.json').read_text());coverage=prism['coverage']
assert s['result']=='PASS_SCOPED_COMPOSED_CONTROLS_PREFLIGHT_CHECKPOINT'and review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==s['sources']and not review['unresolved_findings']and all(sha(R/n)==h for n,h in s['sources'].items())
assert process['exit_code']==0 and process['error']is None and process['source_index_stable']and process['sources']==s['sources']and not prism['findings']and not prism['discarded']and not prism['suppressed']
assert coverage['complete']and coverage['files']==17 and coverage['chunks']==coverage['llmCalls']==4 and coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]and not coverage['excluded']and not coverage['skipped']and coverage['truncatedBytes']==0
assert json.loads((P/'composed-preflight-v2-validation.json').read_text())==s['preflight']and s['preflight']['actions']==165 and not s['current_1000_cycle_campaign_qualified']and not s['full_mac_qualified']
omitted={f.name:{'sha256':sha(f),'bytes':f.stat().st_size,'reason':'Private compiled output; observed paths, hashes and invocation receipts retained. Only v2 (failed native attempt) and v4 (successful preflight) executed.'}for f in sorted(P.glob('window-cycle-*'))if f.is_file()}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[f for f in sorted(P.rglob('*'))if f.is_file()and'__pycache__'not in f.parts and f.relative_to(P).as_posix()not in omitted]
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files};assert len(members)==len(files)
D.mkdir(exist_ok=False);archive=D/'evidence.tar.xz'
with archive.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted,'excluded_directories':['__pycache__']};(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**s,'checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_process_sha256':sha(P/'prism-v1/process.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_coverage_complete':True,'prism_files':17,'prism_llm_calls':4,'prism_findings':0,'prism_unresolved_findings':0,'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');subprocess.run(['git','add','--',str(D)],cwd=R,check=True)
print(json.dumps({k:q[k]for k in['result','archive_members','archive_bytes','archive_sha256','prism_findings']}))
