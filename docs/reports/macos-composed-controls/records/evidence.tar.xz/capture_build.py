"""Observe a successful private output after compilation, before native launch.

This is a local output association, not independent/hermetic compiler attestation.
"""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
R=Path('/private/tmp/vellum-composed-controls');P=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
mode=sys.argv[1];assert mode in ['preflight','full']
name='native-build-v4'if mode=='preflight'else'native-build-committed';binary=P/('window-cycle-v4'if mode=='preflight'else'window-cycle-committed')
b=json.loads((P/(name+'.json')).read_text());review=json.loads((P/'source-review.json').read_text())
assert review['result']=='APPROVED_SOURCE'and not review['unresolved_findings']and all(sha(R/n)==h for n,h in review['sources'].items())
assert b['argv']==['go','build','-tags=vellum_native_checks','-o',str(binary),'./cmd/window-cycle-smoke']and b['cwd']==str(R/'drivers/cogent')and b['producer_sha256']==sha(P/'code_run.py')
assert b['exit_code']==0 and b['error']is None and b['source_delta_stable']and b['overlay_inputs_before']==b['overlay_inputs_after']=={} and b['prepared_before']==b['prepared_after']and len(b['prepared_before'])==6227
assert b['source_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()and all(sha(R/n)==h for n,h in b['source_delta_before'].items())
assert all(sha(P/(name+'.'+ch))==b[ch+'_sha256']for ch in ['stdout','stderr'])
artifact={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'capture_producer_sha256':sha(__file__),'build_receipt_sha256':sha(P/(name+'.json')),'source_review_sha256':sha(P/'source-review.json'),'reviewed_sources':review['sources'],'binary':str(binary),'binary_sha256':sha(binary),'binary_bytes':binary.stat().st_size,'scope':'Observed after a recorded successful build and before launch; not independent compiler/cache closure or loaded executable attestation.'}
with(P/('binary-'+mode+'.json')).open('x')as f:f.write(json.dumps(artifact,indent=2)+'\n')
print(json.dumps({k:artifact[k]for k in ['binary_sha256','binary_bytes','source_review_sha256']}))
