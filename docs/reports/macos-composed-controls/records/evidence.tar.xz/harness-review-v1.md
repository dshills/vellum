# Composed controls harness review

NEEDS_FIX. Bind the binary path/SHA/size to an exact successful build context, including cwd/producer/empty overlays/source commit/log hashes. Preserve a terminal FAILED receipt if cleanup, process observation or identity checks fail; validate ps stderr and complete numeric output before claiming group absence.

The source fixture is approved separately. No native launch, tests, builds or provider calls were performed.
