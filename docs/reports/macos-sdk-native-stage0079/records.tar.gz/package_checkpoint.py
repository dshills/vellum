from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-sdk-native-stage0079';p=json.loads((W/'post-proof.json').read_text());assert p['result']=='PASS_FOUR_NATIVE_SDK_SOURCE_ASSERTION_CASES';assert json.loads((W/'internal-results-review.json').read_text())['approved'];assert json.loads((W/'internal-prose-review.json').read_text())['approved'];shared=W/'shared';shared.mkdir()
for source,name in [(W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py','headless-base.py'),(W.parent/'macos-sdk-native-238b3b6/run.py','owned-executor.py'),(W.parent/'macos-gpu-sdk-stage0077/validators.py','validators.py'),(Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),'live_lease.py'),(T/'scripts/child_process.py','child_process.py'),(T/'scripts/sdk_environment.py','sdk_environment.py')]:shutil.copyfile(source,shared/name)
(W/'final-checks.json').write_text(json.dumps({'source_sdk':p['source_sdk'],'documentation_head_at_execution':p['documentation_head'],'case_count':4,'all_passed':True,'all_groups_absent':True,'all_inputs_unchanged':True,'race':False,'prism_calls':0,'review':'Internalplan/results/prose/archive; unchangedSDKruntimeimplementation andprecedingSDKcheckpointalreadyPrismreviewed.','closed_mac_gates':[],'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');files={};sources={}
for leaf in sorted(W.rglob('*')):
 assert not leaf.is_symlink(),leaf
 if not leaf.is_file()or '__pycache__'in leaf.parts or leaf.name.startswith('stop-'):continue
 name=leaf.relative_to(W).as_posix();data=leaf.read_bytes();assert len(data)<4<<20,(name,len(data));files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};sources[name]=leaf
assert len(files)<60 and sum(x['bytes']for x in files.values())<5<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
record={'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
