from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

T = Path('/private/tmp/vellum-macos-native-results-97aee13')
W = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(T / 'scripts'))
from child_process import run_child
from sdk_environment import child_environment

go = Path('/Users/dshills/Development/Go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin/go')
env = child_environment()
env.update(GOTOOLCHAIN='local', GOPROXY='off', GOMODCACHE='/Users/dshills/Development/Go/pkg/mod', GOMAXPROCS='2')
mode = sys.argv[1]
modfile = '/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod'
common = ['-p=2', '-modfile=' + modfile, '-mod=readonly']
cases = {
    'root-race': (T, ['test', '-p=2', '-race', './...', '-count=1', '-timeout=4m']),
    'root-vet': (T, ['vet', '-p=2', './...']),
    'contract-race': (T / 'examples/sdk-contract', ['test', '-p=2', '-race', './...', '-count=1', '-timeout=3m']),
    'contract-vet': (T / 'examples/sdk-contract', ['vet', '-p=2', './...']),
    'driver-race': (T / 'examples/loadedgrid', ['test', *common, '-race', '-tags=offscreen', 'github.com/dshills/vellum/drivers/cogent/...', '-count=1', '-timeout=7m']),
    'driver-vet': (T / 'examples/loadedgrid', ['vet', *common, '-tags=offscreen', 'github.com/dshills/vellum/drivers/cogent/...']),
    'native-build': (T / 'examples/loadedgrid', ['build', *common, '-trimpath', '-buildvcs=false', '-o', '/private/tmp/vellum-ready-native-5482f9b/bin/minimum-go-loadedgrid', '.']),
}
cwd, tail = cases[mode]
args = [str(go), *tail]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=T).decode().strip()
assert head == '340faf06781ac85d0ed11643fb5fce2ce85c67f1'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=T)
pins = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [go, T / 'go.mod', T / 'drivers/cogent/go.mod', Path(modfile), Path(modfile).with_suffix('.sum')]}
started = time.monotonic()
exit_code = 1
error = None
try:
    with (W / (mode + '.stdout')).open('xb') as out, (W / (mode + '.stderr')).open('xb') as err:
        result = run_child(args, cwd=cwd, env=env, stdout=out, stderr=err, timeout=480, log_limit_bytes=2 << 20)
    exit_code = result.returncode
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in pins.items())
except BaseException as failure:
    exit_code = 1
    error = {'type': type(failure).__name__, 'message': str(failure)}
receipt = {'argv': args, 'cwd': str(cwd), 'source_base': head, 'pins': pins, 'exit_code': exit_code, 'error': error, 'seconds': time.monotonic() - started, 'native_runtime_executed': False, 'environment': {k: env.get(k) for k in ['GOTOOLCHAIN', 'GOPROXY', 'GOMAXPROCS', 'CGO_ENABLED', 'GOENV', 'GOWORK', 'GOFLAGS']}, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
receipt['logs'] = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in [W / (mode + '.stdout'), W / (mode + '.stderr')] if p.exists()}
if mode == 'native-build' and exit_code == 0:
    binary = Path('/private/tmp/vellum-ready-native-5482f9b/bin/minimum-go-loadedgrid')
    receipt['binary'] = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
(W / (mode + '-command.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['source_base', 'exit_code', 'seconds', 'native_runtime_executed']}), flush=True)
if exit_code:
    print((W / (mode + '.stderr')).read_text()[-4000:], flush=True)
sys.exit(exit_code)
