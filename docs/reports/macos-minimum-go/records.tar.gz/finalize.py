from pathlib import Path
import datetime, hashlib, json, subprocess

T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
W = Path(__file__).resolve().parent
head = '340faf06781ac85d0ed11643fb5fce2ce85c67f1'
expected = {'files': 6260, 'sha256': '1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'}
cases = ['root-race', 'root-vet', 'contract-race', 'contract-vet', 'driver-race', 'driver-vet', 'native-build']
results = {}
for mode in cases:
    d = json.loads((W / (mode + '-command.json')).read_text())
    assert d['source_base'] == head and d['exit_code'] == 0 and not d['native_runtime_executed']
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in d['pins'].items())
    results[mode] = {'exit_code': 0, 'seconds': d['seconds']}

trees = {}
for root in [C, T]:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == head
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
    files = {n + '/' + p.relative_to(root / 'drivers/cogent/build' / n).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for n in ['upstream', 'typesetting'] for p in (root / 'drivers/cogent/build' / n).rglob('*') if p.is_file()}
    prepared = {'files': len(files), 'sha256': hashlib.sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}
    assert prepared == expected, (root, prepared)
    trees[str(root)] = {'clean': True, 'head': head, 'prepared': prepared}

lib = Path('/private/tmp/vellum-gpu-sdk-stage0077/relocated SDK/vellum-v0.1.0-alpha.2/drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')
assert lib.is_file(), lib
libhash = hashlib.sha256(lib.read_bytes()).hexdigest()
assert libhash == '786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
binary = json.loads((W / 'native-build-command.json').read_text())['binary']
assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest() == binary['sha256']
metadata = (W / 'native-build-metadata.stdout').read_text()
assert metadata.splitlines()[0].endswith(': go1.25.6')
assert '\tbuild\tGOARCH=arm64' in metadata and '\tbuild\tGOOS=darwin' in metadata
result = {'result': 'PASS_SCOPED_MINIMUM_GO_SOURCE_COMPATIBILITY', 'source_base': head, 'toolchain': 'go1.25.6 darwin/arm64', 'cases': results, 'trees_after': trees, 'static_library': {'path': str(lib), 'bytes': lib.stat().st_size, 'sha256': libhash}, 'binary': binary, 'native_runtime_executed': False, 'runtime_changed': False, 'closed_full_mac_gates': [], 'limits': 'Source/framework/driver/public-contract compatibility only. No regenerated SDK, all-demo runtime, GUI, performance, memory/endurance, rights, signing or public-release qualification.', 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(W / 'assessment.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['result', 'source_base', 'toolchain', 'cases', 'native_runtime_executed']}))
