from pathlib import Path
import os,sys,json,hashlib,time
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
go='/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go';env=child_environment();env.update(GOTOOLCHAIN='go1.25.6',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod')
args=[go,'version'];start=time.monotonic()
with (W/'download.stdout').open('xb') as out,(W/'download.stderr').open('xb') as err:
 r=run_child(args,cwd=W,env=env,stdout=out,stderr=err,timeout=180,log_limit_bytes=2<<20)
d={'argv':args,'bootstrap_sha256':hashlib.sha256(Path(go).read_bytes()).hexdigest(),'toolchain':'go1.25.6','GOSUMDB':env['GOSUMDB'],'GOPROXY':env['GOPROXY'],'exit_code':r.returncode,'seconds':time.monotonic()-start};(W/'download-command.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));print((W/'download.stdout').read_text());print((W/'download.stderr').read_text());sys.exit(r.returncode)
