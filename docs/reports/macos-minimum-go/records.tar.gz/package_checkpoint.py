from pathlib import Path
import hashlib, json, subprocess, tarfile

T = Path('/private/tmp/vellum-macos-native-results-97aee13')
W = Path(__file__).resolve().parent
F = T / 'docs/reports/macos-minimum-go'
d = json.loads((W / 'assessment.json').read_text())
assert d['result'] == 'PASS_SCOPED_MINIMUM_GO_SOURCE_COMPATIBILITY'
assert json.loads((W / 'internal-results-review.json').read_text())['approved']
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--', 'drivers/cogent', 'examples', 'go.mod', 'go.sum'], cwd=T)
assert not subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'drivers/cogent', 'examples'], cwd=T)
files = {}
for leaf in sorted(W.rglob('*')):
    assert not leaf.is_symlink()
    if not leaf.is_file() or '__pycache__' in leaf.parts:
        continue
    data = leaf.read_bytes()
    assert len(data) < 2 << 20
    files[leaf.relative_to(W).as_posix()] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
assert len(files) < 80 and sum(v['bytes'] for v in files.values()) < 3 << 20
archive = F / 'records.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for name in files:
        tar.add(W / name, arcname=name, recursive=False)
record = {'archive': archive.name, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': files}
(F / 'records.json').write_text(json.dumps(record, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files)
    for member in members:
        assert member.isfile() and member.name in files
        data = tar.extractfile(member).read()
        assert len(data) == files[member.name]['bytes'] and hashlib.sha256(data).hexdigest() == files[member.name]['sha256']
print(json.dumps({'archive': str(archive), 'members': len(files), 'bytes': archive.stat().st_size, 'sha256': record['archive_sha256']}))
