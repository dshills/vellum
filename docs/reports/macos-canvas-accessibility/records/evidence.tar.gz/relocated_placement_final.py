from pathlib import Path
import importlib.util,sys,hashlib,json,time,subprocess
R=Path('/private/tmp/vellum-canvas-accessibility');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
spec=importlib.util.spec_from_file_location('sdkcheck',R/'scripts/check-sdk.py');sdkcheck=importlib.util.module_from_spec(spec);spec.loader.exec_module(sdkcheck)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
archive=P/'vellum-sdk-final.tar.gz';digest='7a909857234c72613b681517052991940b3fc5839332836af6923ba2973d1a3d'
verified=sdkcheck.verify_archive(archive,digest);sdk=sdkcheck.extract_verified(archive,P/'relocated SDK final with spaces',verified)
selected=['ui/canvas_objects.go','canvas/canvas.go','drivers/cogent/canvas_accessibility.go','drivers/cogent/manual_offscreen.go','examples/placement/main.go','examples/placement/routing_offscreen_test.go','examples/sdk-contract/canvas_objects_test.go']
sources={n:sha(R/n)for n in selected};assert all(sha(sdk/n)==h for n,h in sources.items())
env={**child_environment(),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2'}
record={'archive_sha256':sha(archive),'producer_sha256':sha(__file__),'sources':sources,'relocated':str(sdk),'checks':[],'native_binary_executed':False};start=time.monotonic()
try:
 for name,argv in [('race',['go','test','-race','-tags','offscreen','./...','-count=1','-timeout=120s']),('vet',['go','vet','-tags','offscreen','./...']),('native-compile',['go','build','-o',str(P/'placement-final-relocated.bin'),'.'])]:
  with(P/('relocated-placement-final-'+name+'.stdout')).open('xb')as so,(P/('relocated-placement-final-'+name+'.stderr')).open('xb')as se:
   result=run_child(argv,cwd=sdk/'examples/placement',env=env,stdout=so,stderr=se,timeout=180)
  record['checks'].append({'name':name,'argv':argv,'exit_code':result.returncode,'stdout_sha256':sha(P/('relocated-placement-final-'+name+'.stdout')),'stderr_sha256':sha(P/('relocated-placement-final-'+name+'.stderr'))});assert result.returncode==0
 record['binary_sha256']=sha(P/'placement-final-relocated.bin');record['result']='PASS_RELOCATED_PLACEMENT_CODE_CHECKS'
finally:
 record['elapsed_seconds']=time.monotonic()-start;(P/'relocated-placement-final.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
