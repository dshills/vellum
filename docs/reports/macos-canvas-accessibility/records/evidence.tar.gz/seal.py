from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path('/private/tmp/vellum-canvas-accessibility');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-canvas-accessibility/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];summary=json.loads((P/'summary.json').read_text());review=json.loads((P/'checkpoint-review.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE' and review['sources']==sources and not review['unresolved_findings']
assert summary['sources']==sources and summary['result']=='PASS_SCOPED_CANVAS_SOFTWARE_CHECKS' and all(sha(R/n)==h for n,h in sources.items())
prism=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());coverage=prism['coverage'];adjudication=json.loads((P/'prism-adjudication.json').read_text())
assert process['exit_code']in [0,1] and process['error']is None and process['source_index_stable'] and process['sources']==summary['raw_prism_sources'] and process['review_sha256']==sha(P/'pre-prism-checkpoint-review.json')
assert adjudication['sources']==sources and not adjudication['unresolved_findings']
fix_sources={n:h for n,h in sources.items()if process['sources'][n]!=h}
assert set(fix_sources)=={'drivers/cogent/accessibility.go','drivers/cogent/canvas_accessibility.go','drivers/cogent/canvas_accessibility_offscreen_test.go'}
fix_review=json.loads((P/'post-prism-fix-review.json').read_text());assert fix_review['result']=='APPROVED_SOURCE' and fix_review['sources']==sources
assert {f['id']for f in prism['findings']}=={f['id']for f in adjudication['findings']}
assert coverage['complete'] and coverage['files']==len(sources) and not coverage['skipped'] and coverage['truncatedBytes']==0
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
D.mkdir(exist_ok=False)
omitted={}
for name in ['vellum-workbench','vellum-placement','placement-relocated.bin','placement-final-relocated.bin','vellum-sdk.tar.gz','vellum-sdk-final.tar.gz']:
 f=P/name
 if f.is_file():omitted[name]={'sha256':sha(f),'bytes':f.stat().st_size,'reason':'Private SDK or compiled Mac binary; code checks only, binary not launched, hash retained instead of executable.'}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[f for f in sorted(P.rglob('*'))if f.is_file() and f.relative_to(P).parts[0]not in ['relocated SDK with spaces','relocated SDK final with spaces'] and f.relative_to(P).as_posix()not in omitted and '__pycache__'not in f.parts]
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
archive=D/'evidence.tar.gz'
with archive.open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted,'excluded_directories':{'relocated SDK with spaces':'Superseded verified SDK extraction; archive hash and checks retained.','relocated SDK final with spaces':'Final verified SDK extraction; archive hash, source matches and checks retained instead of a second distribution.'}}
(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**summary,'result':'PASS_SCOPED_CANVAS_SOFTWARE_CHECKPOINT','checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_llm_calls':coverage['llmCalls'],'prism_chunks':coverage['chunks'],'prism_raw_exit_code':process['exit_code'],'prism_findings':len(prism['findings']),'prism_unresolved_findings':0,'prism_adjudication_sha256':sha(P/'prism-adjudication.json'),'prism_coverage_complete':True,'prism_reviewed_sources':process['sources'],'prism_post_review_fix_sources':fix_sources,'post_prism_fix_review_sha256':sha(P/'post-prism-fix-review.json'),'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
subprocess.run(['git','add','docs/reports/macos-canvas-accessibility/records'],cwd=R,check=True)
print(json.dumps({'result':q['result'],'archive_members':len(members),'archive_bytes':index['archive_bytes'],'archive_sha256':index['archive_sha256'],'prism_findings':q['prism_findings']}))
