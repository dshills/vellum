from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-canvas-accessibility');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-canvas-accessibility')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
q=json.loads((R/'docs/reports/macos-canvas-accessibility/records/qualification.json').read_text());review=json.loads((P/'final-review.json').read_text())
assert q['result']=='PASS_SCOPED_CANVAS_SOFTWARE_CHECKPOINT' and review['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not review['unresolved_findings']
assert all(not q[k]for k in ['native_binary_executed','full_mac_qualified','physical_pointer_qualified','gpu_qualified','full_P3_qualified','full_P9_qualified','full_P11_qualified','performance_qualified','public_distribution_qualified'])
assert q['prism_unresolved_findings']==0 and q['prism_coverage_complete']
base=q['base_commit'];commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
assert not git(R,'status','--porcelain') and not git(C,'status','--porcelain') and git(C,'rev-parse','HEAD')==base
changed=set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())
expected_changed=set(q['sources'])|{'docs/reports/macos-canvas-accessibility/records/'+n for n in ['qualification.json','evidence.tar.gz','archive-index.json']};assert changed==expected_changed
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/name.decode();assert kind=='blob' and path.is_file() and not path.is_symlink();data=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert all(expected[n]==h for n,h in q['sources'].items()) and review['sources']=={n:expected[n]for n in expected_changed}
wanted=prepared(R);assert len(wanted)==6223 and prepared(C)==wanted
marker=Path('/private/tmp/vellum-macos-quiet-current/stop-live');assert marker.is_file() and sha(marker)==q['human_online_live_stop_sha256'];marker_hash=sha(marker)
O.mkdir(parents=True,exist_ok=True);reservation=O/'canonical-promotion.json';reservation.open('x').close()
record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'changed_files':sorted(changed),'scope':'Named retained Canvas2D object semantics, completed geometry and exact selection; no live native launch or full Mac/P3 qualification.'};start=time.monotonic()
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 actual=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_files':len(expected),'tracked_exact':set(actual)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_files':6223,'prepared_exact':prepared(C)==wanted,'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'archive_sha256':sha(C/'docs/reports/macos-canvas-accessibility/records/evidence.tar.gz'),'final_review_sha256':sha(P/'final-review.json'),'human_online_live_stop_preserved':sha(marker)==marker_hash})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean','human_online_live_stop_preserved'])and record['archive_sha256']==q['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
except BaseException as error:
 record['result']='FAILED_CANONICAL_PROMOTION';record['error']={'type':type(error).__name__,'message':str(error)};raise
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');reservation.write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
