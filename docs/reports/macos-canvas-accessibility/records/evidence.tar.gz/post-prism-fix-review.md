APPROVED_SOURCE — CANVAS-AX-04 is fixed in the exact three-file delta; final evidence remains pending.

Host Value now derives only from a qualifying completed detached picture, and is empty without one. Existing pending cache replacement still restores prior completed values. New permanent regressions cover selected startup without any paint/cache and an ownership-parent mismatch that cannot reuse the old cache.

The source map binds all 34 final files and preserves the original 34-file provider vector separately. Raw Prism did not review the three new versions; this is an internal source review. Original raw exit 1/finding and interim NEEDS_FIX record remain preserved. No tests/builds/native/providers or repository edits were performed by reviewer.
