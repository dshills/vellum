from pathlib import Path
import json,hashlib
r=Path('/private/tmp/vellum-canvas-accessibility');p=Path(__file__).parent/'negative';p.mkdir(exist_ok=False)
cases={
 'capture-epoch':('drivers/cogent/canvas_accessibility.go', [('epoch := b.window.canvasEpoch.Load()',''),('b.window.canvasEpoch.Load() == epoch && ','')],'^TestCanvasQueuedActionsKeepOrigin/capture-aba$','stale queued action changed selection'),
 'model-guard':('drivers/cogent/canvas_accessibility.go', [('view := b.model.View\n\tview.Width, view.Height = f.geometry.View.Width, f.geometry.View.Height',''),('return view == f.geometry.View && b.model.Selected == f.picture.selected && slices.Equal(b.model.Objects, f.picture.objects) && slices.Equal(b.r.node.CanvasObjects, f.picture.semantics)','return true')],'^TestCanvasQueuedActionsKeepOrigin/changed-object$','stale queued action changed selection'),
 'snapshot-copy':('drivers/cogent/manual_offscreen.go',[('captured.Canvases = cloneManualCanvases(captured.Canvases)','')],'^TestReviewerCanvasSnapshotDetachesBothLevels$','aliases retained snapshot'),
 'transfer-withdrawal':('drivers/cogent/data_geometry.go',[('withdrawCanvasGeometry(r.control.placement)','')],'^TestCanvasRetainedAncestorMoveWithdrawsCompletedFrame$','retained ancestor move kept old completion'),
}
manifest={}
for name,(path,edits,test,diagnostic) in cases.items():
 source=(r/path).read_text()
 for old,new in edits:
  assert source.count(old)==1,(name,old);source=source.replace(old,new)
 target=p/(name+'.go');target.write_text(source)
 overlay=p/(name+'.json');overlay.write_text(json.dumps({'Replace':{str(r/path):str(target)}}))
 manifest[name]={'source':path,'candidate_sha256':hashlib.sha256((r/path).read_bytes()).hexdigest(),'fault_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'overlay':str(overlay),'test':test,'expected_diagnostic':diagnostic}
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
