APPROVED_SOURCE — no new implementation defects; V2's three fixes remain unchanged.

The added source covers actual queued bridge admission, same-generation production capture/loss ABA, retained ancestor/dialog/Workbench withdrawal, ancestor scroll clipping and inert Cocoa role/hit/pending/retirement transactions. Public example/SDK tests use the exported API; qualification limits are explicit.

Source-only scope: broad gates, frozen-record compatibility, SDK relocation and guard-removal fault receipts remain pending evidence. Final report assertions must be reconciled with those completed receipts. Name the field ui.Node.CanvasObjects rather than package shorthand ui.CanvasObjects before finalizing docs. No test/build/native/UI/provider was executed and no repository file changed by reviewer. Exact 34-source binding is in implementation-review-v3.json.
