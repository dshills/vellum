Use an opt-in semantic object list on Canvas2D, keyed by existing Scene.Objects IDs, with literal bounded name/help metadata. Derive geometry and selected state from the scene; keep existing Node.Change as the selection notification. No per-object callbacks or caller-supplied AX rectangles are needed. Nil metadata preserves the current generic canvas.

The important source gaps are specific: placementFrame has no detached-picture identity; its current view comparison cannot detect changed object content. Frames are stored before object drawing. withdrawDataGeometry currently handles only Grid/Tree. Native scoped transactions admit only table/outline hosts.

Reuse the existing GridScope completed/pending transaction with an explicit canvas host role mapped to AXGroup and button-like object children. Extend the scoped-host allowlist narrowly. Pending data remains readable but disabled/actionless/unfocused; ordinary geometry must omit the scoped subtree. Bind frames to the exact detached picture, actual Scene/layout completion, scale/origin and clip, publishing after drawing completes. Extend transfer withdrawal before Workbench/dialog/ancestor parking.

Pointer hit testing, explicit AX ID selection and object keyboard navigation should converge on one owner-held selection commit. AX must not simulate Pick(center), which selects a front overlapping object instead of the requested object. Keep arrow panning/Tab; offer separate documented object-navigation keys. The host remains the one native focus stop; pressFocusID preserves existing Workbench qualification.

Capture admission must retain the object/content epoch as well as binding, window and immutable scope. Recheck under owner delivery before resolving the latest callback. Revoke on capture begin, including begin/end ABA, not only while capture is currently active. Existing bounded PostWindow and activationGuard machinery is suitable; native callbacks must not call Do synchronously.

Publicly mutable Scene.Objects has no replacement revision. Exact snapshot/current comparisons catch ordinary mutation/removal, but an identical remove/readd between observations is unknowable. Define stable-ID reuse as the same entity, or add an explicit owner-managed epoch/mutation seam before promising replacement incarnation safety.

Bound entries by the existing 10,000-object snapshot and aggregate UTF-8 metadata bytes; derive visible children in the same bounded pass. Tests should cover four-DPI completed clipping, overlaps, pending frames, queued action ABA, retained scene transfer, namespaces, callback counts and bounded cleanup, with assertion-sensitive guard faults. Inert Cocoa schema tests precede any actual native/human VoiceOver acceptance.

Exact reviewed source hashes, API details and test recommendations are in design-review.json. Design only; no source edits, tests/builds, native/GPU/UI, provider or network calls were performed.
