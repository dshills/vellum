from pathlib import Path
import json,hashlib,subprocess
R=Path('/private/tmp/vellum-canvas-accessibility');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert base=='81b33aa32c4fc9a147e6ce57dac8001003396168'
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
assert not any(n.startswith('docs/reports/macos-canvas-accessibility/records/')for n in names)
sources={n:sha(R/n)for n in sorted(names)};assert len(sources)==34
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':base,'sources':sources},indent=2)+'\n')
checks={};text_corrections={'README.md','examples/placement/README.md','docs/reports/macos-canvas-accessibility/README.md'}
positive=['canvas-v8','root-race-final','root-vet-final','driver-race-final','driver-vet-final','placement-race-final','placement-vet-final','sdk-contract-race-final','sdk-contract-vet-final','native-compile-final','placement-native-compile-final','workspace-replay-final','sdk-archive-final','sdk-relocation-final']
prepared=None
for name in positive:
 d=json.loads((P/(name+'.json')).read_text())
 assert d['exit_code']==0 and d['error']is None and d['source_delta_stable'] and d['source_commit']==base and not d['live_tests'] and not d['headless_gpu_requested'],name
 assert d['prepared_before']==d['prepared_after'] and len(d['prepared_before'])==6223,name
 if prepared is None:prepared=d['prepared_after']
 assert prepared==d['prepared_after']
 for channel in ['stdout','stderr']:assert sha(P/(name+'.'+channel))==d[channel+'_sha256']
 mismatches={n for n,h in sources.items()if d['source_delta_after'].get(n)!=h};assert mismatches<=text_corrections,(name,mismatches)
 assert not d['overlay_inputs_before'] and not d['overlay_inputs_after']
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'current_sources_matched':[n for n in sources if n not in mismatches],'post_check_prose_field_name_corrections':sorted(mismatches),'source_stable':True}
actual={f.relative_to(C/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((C/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert actual==prepared
negative=json.loads((P/'negative-final-results.json').read_text());assert len(negative)==5
for name,n in negative.items():
 assert n['intended_failure'] and n['candidate_sha256']==sources[n['source']]
 d=json.loads((P/('negative-final-'+name+'.json')).read_text());assert d['exit_code']==1 and d['error']is None and d['source_delta_stable'] and prepared==d['prepared_before']==d['prepared_after'] and d['overlay_inputs_before']==d['overlay_inputs_after'] and d['overlay_inputs_before']
 assert n['expected_diagnostic']in(P/('negative-final-'+name+'.stdout')).read_text() and sha(P/('negative-final-'+name+'.json'))==n['receipt_sha256']
relocated=json.loads((P/'relocated-placement-final.json').read_text());assert relocated['result']=='PASS_RELOCATED_PLACEMENT_CODE_CHECKS' and not relocated['native_binary_executed'] and len(relocated['checks'])==3
assert all(sources[n]==h for n,h in relocated['sources'].items())
for c in relocated['checks']:
 assert c['exit_code']==0
 for channel in ['stdout','stderr']:assert sha(P/('relocated-placement-final-'+c['name']+'.'+channel))==c[channel+'_sha256']
assert relocated['binary_sha256']==sha(P/'placement-final-relocated.bin')
sdk=json.loads((P/'sdk-relocation-final.stdout').read_text());assert sdk['event']=='vellum.sdk.relocated' and sdk['native_runtime']=='not executed' and sdk['digest_verified_against_expected'] and sdk['path_contains_spaces']
assert sdk['archive_sha256']==relocated['archive_sha256']==sha(P/'vellum-sdk-final.tar.gz')
record_sources={n:sha(R/n)for n in ['examples/replay/workspace/records/10000.json','examples/replay/workspace/records/10000.golden.json','examples/replay/workspace/records/1000000.json','examples/replay/workspace/records/1000000.golden.json']};assert all(sha(C/n)==h for n,h in record_sources.items())
assert (P/'workspace-replay-final.stdout').read_text().count('--- PASS: TestFrozenWorkspaceRecordsAcrossBatches/')==6
sdk_sources=json.loads((P/'sdk-final-source-match.json').read_text());assert sdk_sources['result']=='PASS' and sdk_sources['archive_sha256']==sha(P/'vellum-sdk-final.tar.gz') and len(sdk_sources['sources'])==33 and all(sources[n]==h for n,h in sdk_sources['sources'].items())
summary={'result':'PASS_SCOPED_CANVAS_SOFTWARE_CHECKS','base_commit':base,'sources':sources,'checks':checks,'negative_controls':negative,'relocated_placement_receipt_sha256':sha(P/'relocated-placement-final.json'),'sdk_archive_sha256':sha(P/'vellum-sdk-final.tar.gz'),'sdk_final_source_match_sha256':sha(P/'sdk-final-source-match.json'),'prepared_files':6223,'prepared_exact_canonical':True,'frozen_workspace_records':record_sources,'frozen_workspace_runs':6,'owner_batches':[1,7,64],'logical_dpi':[96,120,160,240],'native_binary_sha256':{n:sha(P/n)for n in ['vellum-workbench','vellum-placement','placement-final-relocated.bin']},'excluded_authoring_receipts':['compile-v1','canvas-v1','canvas-v2','canvas-v3','canvas-v4','canvas-v5','canvas-v6'],'source_review_v3_sha256':sha(P/'implementation-review-v3.json'),'post_prism_fix_review_sha256':sha(P/'post-prism-fix-review.json'),'superseded_pre_prism_summary_sha256':sha(P/'pre-prism-summary.json'),'raw_prism_sources':json.loads((P/'prism-v1/process.json').read_text())['sources'],'human_online_live_stop_sha256':sha('/private/tmp/vellum-macos-quiet-current/stop-live'),'native_binary_executed':False,'native_attachment_qualified':False,'physical_pointer_qualified':False,'human_voiceover_qualified':False,'gpu_qualified':False,'performance_qualified':False,'public_distribution_qualified':False,'full_mac_qualified':False,'full_P3_qualified':False,'full_P9_qualified':False,'full_P11_qualified':False,'limits':['Visible opt-in named rectangular Canvas2D objects only; no offscreen paging, multi-selection or GPU MeshCanvas semantics.','Physical pointer, cross-display changes, live native attachment and human VoiceOver require separate live checks.','Private archive verification is self-produced integrity evidence, not independent authenticity or public distribution certification.']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'sources':len(sources),'checks':len(checks),'negative_controls':len(negative),'frozen_workspace_runs':6}))
