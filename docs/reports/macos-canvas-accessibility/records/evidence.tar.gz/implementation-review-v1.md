NEEDS_FIX — three concrete source findings.

1. CANVAS-AX-01: validateCanvasObjects scans/maps Scene.Objects before the 10,000-object cap is checked. Reject the invalid scene before that allocation.
2. CANVAS-AX-02: measured AX children follow metadata order rather than paint order. Reordering labels reverses native overlap hit priority because Cocoa traverses children in reverse. Emit in Scene.Objects order.
3. CANVAS-AX-03: Manual.Snapshot omits deep cloning Canvases/Objects, so callers mutate retained snapshots. Clone both levels.

Detached rendering, after-paint publication, scoped pending data, counter wrap refusal and closure-free completed cache handling otherwise follow the intended design. Regression coverage still needs real queued bridge admission, scope/capture ABA and actual retained transfer hooks, plus inert Cocoa hit/schema checks. The two-test external snapshot/order draft is in reviewer/canvas_snapshot_order_offscreen_test.go and was not executed.

Exact 15-source hashes and the bounded regression plan are in implementation-review-v1.json. Reviewer changed no repository files and ran no tests/builds/native/UI/providers.
