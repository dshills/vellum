NEEDS_FIX — finding 3a141a0dae4de0c9 is partly supported.

The nil dereference is a false positive for admitted records: mandatory ui.ValidateControl/reconcile/mount/sync validation forbids a nil Canvas. No source path installs that invalid descriptor.

The completed-selection concern has a real no-cache boundary. A newly added annotated canvas with a selected object has no completed frame/cache. The host Value reads the live selected name; stamp marks it pending but leaves Value intact, and cache preparation retains that current host fallback. It therefore publishes new selection before any completed paint. A mismatched scope parent has the same fallback. Existing-cache pending data correctly preserve the previous completed selection.

Fix CANVAS-AX-04 by deriving host Value only from a qualifying completed frame, with empty Value otherwise. Keep prior completed-cache replacement unchanged. Add startup/no-cache and ownership-mismatched-cache assertions, then real-paint restoration. The rear-to-front pending-cache proof covers the existing-cache branch only.

Raw Prism exit 1 and the single medium finding are preserved. Exact sources/context/artifacts and claim-by-claim reasoning are in prism-adjudication.json. Reviewer ran no tests/builds/native/providers and edited no repository source.
