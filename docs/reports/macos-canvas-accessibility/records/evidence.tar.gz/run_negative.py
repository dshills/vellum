from pathlib import Path
import json,subprocess,hashlib,sys
p=Path(__file__).parent
manifest=json.loads((p/'negative/manifest.json').read_text());results={}
for name,case in manifest.items():
 argv=['python3',str(p/'code_run.py'),'negative-'+name,'drivers/cogent','go','test','-race','-tags','offscreen','-overlay='+case['overlay'],'.','-run',case['test'],'-count=1','-timeout=45s','-v']
 result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
 (p/('negative-'+name+'.wrapper.log')).write_bytes(result.stdout)
 receipt=json.loads((p/('negative-'+name+'.json')).read_text())
 output=(p/('negative-'+name+'.stdout')).read_text()
 passed=result.returncode==1 and receipt['exit_code']==1 and receipt['error'] is None and receipt['source_delta_stable'] and case['expected_diagnostic'] in output and '[build failed]' not in output
 results[name]={'intended_failure':passed,'exit_code':receipt['exit_code'],'receipt_sha256':hashlib.sha256((p/('negative-'+name+'.json')).read_bytes()).hexdigest(),**case}
 print(name,passed,flush=True)
(p/'negative-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(x['intended_failure']for x in results.values())
