//go:build offscreen

package cogent

import (
 "encoding/json"
 "testing"
 "github.com/dshills/vellum/ui"
)

func TestPrismCanvasValidationAndCompletedSelection(t *testing.T) {
 f:=newCanvasAX(t,7,160)
 invalid:=ui.Node{ID:"drawing",Kind:ui.Canvas2D,CanvasObjects:f.metadata}
 if ui.Validate(invalid)==nil||ui.ValidateControl(invalid)==nil {t.Fatal("missing scene with labels accepted")}
 f.owner.Do(func(){f.model.Selected="rear:/β"});f.refresh(t)
 bridge:=newAccessibilityBridge(f.owner);bridge.bind("one");defer bridge.close()
 publish:=func()[]accessibilityNode{
  f.owner.Do(func(){n,h:=accessibilitySnapshot(f.root(),bridge);bridge.updateOwned(n,h)})
  var out []accessibilityNode
  if err:=json.Unmarshal([]byte(bridge.lastSnapshot),&out);err!=nil{t.Fatal(err)}
  return out
 }
 before:=gridAXByID(t,publish())
 host:=accessibilityManagedID("drawing");rear:=accessibilityManagedID(CanvasObjectID("drawing","rear:/β"));front:=accessibilityManagedID(CanvasObjectID("drawing","front"))
 if before[host].Value!="Rear block"||!before[rear].Selected||before[front].Selected {t.Fatal("completed baseline missing selection")}
 f.owner.Do(func(){f.model.Selected="front"}) // No refresh or repaint.
 pending:=gridAXByID(t,publish())
 if !pending[host].GridPending||pending[host].Value!=before[host].Value||!pending[rear].Selected||pending[front].Selected||!pending[host].Disabled {t.Fatal("pending bridge published unpainted selection",pending[host],pending[rear],pending[front])}
 f.refresh(t)
 ready:=gridAXByID(t,publish())
 if ready[host].GridPending||ready[host].Value!="Front block"||ready[rear].Selected||!ready[front].Selected {t.Fatal("ready bridge did not publish completed selection")}
}
