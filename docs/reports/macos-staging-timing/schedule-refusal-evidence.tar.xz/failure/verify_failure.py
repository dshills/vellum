from pathlib import Path
import json,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
old='/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/stagingreuse/framework/main_darwin.go'
for p,h in load(q/'bound-plan.json')['pins'].items():assert sha(q/'sealed-source-snapshots/main_darwin.go' if p==old else Path(p))==h,(p,h)
d=load(q/'result.json');assert d['outcome']=='BLOCKED_BY_RETAINED_INVALID_CASE' and len(d['cases'])==1 and not (q/'pair1-on').exists();c=d['cases'][0];assert c['kind']=='off' and c['outcome']=='REJECT';groups=0
work=[(c['native'],q/'pair1-off/native')]
for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,q/'pair1-off'/folder/k) for k,cmd in c[phase].items())
for cmd,folder in work:
 assert cmd['error'] is None and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['pins_stable'] and cmd['logs_complete']
 assert cmd['exit_code']==(1 if folder.name=='native' else 0)
 for stream,e in cmd['logs'].items():assert sha(folder/stream)==e['sha256'] and (folder/stream).stat().st_size==e['bytes']
 groups+=1
assert groups==9 and c['geometry_before']==c['geometry_after'];assert all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
raw=load(q/'pair1-off/native/stdout');assert raw['error']=='request deadline lateness over20ms' and raw['lateness_ns']==[2297250,2327834,2439750,2570167,42563959] and len(raw['receipt_lateness_ns'])==4
s=importlib.util.spec_from_file_location('old_timing_sdk',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS retained schedule refusal42.563959ms/fifthrequest,fourwarmup,zero measured,noenabledrun;9ownedgroups/log/sourcehistoricalsnapshot/config/geometry/SDKpins. No timing acceptance.')
