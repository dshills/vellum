from pathlib import Path
import json,hashlib,os,importlib.util,sys
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());d=load(q/'build-identity.json');assert sha(q/'framework')==d['binary_sha256'] and os.access(q/'framework',os.X_OK) and sha(Path(d['native_root'])/'libs-darwin/arm64/libwgpu_native.a')==d['archive_sha256']
for group in ['private_source_pins','tool_source_pins','overlay_pins']:assert all(sha(Path(p))==h for p,h in d[group].items())
r=load(q/'go-build-receipt.json')['run'];assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent'] and r['pins_stable'] and r['logs_complete']
for stream,e in r['logs'].items():assert sha(q/'go-build'/stream)==e['sha256']
proof=load(q.parent/'macos-staging-reuse-v2/summary.json');assert proof['outcome']=='VALID_PRIVATE_STAGING_BYTE_PAIR' and proof['GPU_verified_readbacks']==44 and proof['GPU_verified_bytes']==97912700
s=importlib.util.spec_from_file_location('timing_SDK_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS private library identical to byteproof, Go binary/view/routing/3overlays/source/SDK8321 unchanged; two new wrapper methods; no new native execution/ordinary acceptance')
