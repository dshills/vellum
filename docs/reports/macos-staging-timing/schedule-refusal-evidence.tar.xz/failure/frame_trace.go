package core

import (
	"errors"
	"reflect"
	"sync"
	"sync/atomic"
	"time"

	"cogentcore.org/core/events"
	"cogentcore.org/core/system/composer"
)

var ErrFrameTraceBusy = errors.New("core: traced interaction pending")

// FrameTraceSample is one tagged input and the first composition armed after
// its owner transition/reconciliation. These are elapsed work intervals, not
// OS thread CPU counters or compositor presentation timestamps.
type FrameTraceSample struct {
	Tag, Generation                                         uint64
	QueuedNS, InputNS, OwnerNS, ReconcileNS                 int64
	LayoutPaintNS, GatherNS, RasterUploadNS, EncodeSubmitNS int64
	AcquireNS, PresentCallNS, TotalUIWorkNS                 int64
	Completed                                               bool
	// Unavailable carries checked acquisition evidence only for a failed composition.
	Unavailable   bool `json:",omitempty"`
	Failure       string
	SourceDetails *composer.SourceDetails
}

type frameTracePending struct {
	FrameTraceSample
	event                                                                                         events.Event
	group                                                                                         []events.Event
	groupDone                                                                                     int
	transaction                                                                                   bool
	queued                                                                                        time.Time
	inputDone, ownerExpected, transition, ownerDone, reconciled, armed, rendering, ready, retired bool
	frameGeneration                                                                               uint64 // captured together with frameArmed
	frameArmed                                                                                    bool   // captured at composition start, never inferred at finish
}

// FrameTrace retains at most one interaction and owns no callback. Install it
// explicitly; the ordinary event/render path does no timing when absent.
type FrameTrace struct {
	mu            sync.Mutex
	pending       *frameTracePending
	active        atomic.Uint64
	sourceDetails bool // immutable; the zero value preserves ordinary tracing
}

// NewFrameTraceWithSourceDetails opts into bounded per-source diagnostics.
func NewFrameTraceWithSourceDetails() *FrameTrace { return &FrameTrace{sourceDetails: true} }

func (sc *Scene) SetFrameTrace(trace *FrameTrace) { sc.frameTrace.Store(trace) }
func (sc *Scene) FrameTrace() *FrameTrace         { return sc.frameTrace.Load() }

// A reserved diagnostic FIFO node unwraps only at actual dispatch. The deque
// still sees a DeferredEvent, preserving identity against ordinary compression.
func unwrapFrameTraceEvent(event events.Event) events.Event {
	if reserved, ok := event.(interface{ FrameTraceEvent() events.Event }); ok {
		return reserved.FrameTraceEvent()
	}
	return event
}

func (trace *FrameTrace) Begin(tag uint64, event events.Event) error {
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if tag == 0 || event == nil || reflect.ValueOf(event).Kind() != reflect.Pointer || reflect.ValueOf(event).IsNil() {
		return errors.New("core: invalid traced input")
	}
	if trace.pending != nil {
		return ErrFrameTraceBusy
	}
	trace.pending = &frameTracePending{FrameTraceSample: FrameTraceSample{Tag: tag}, event: event, queued: time.Now()}
	if trace.sourceDetails {
		trace.pending.SourceDetails = &composer.SourceDetails{}
	}
	return nil
}

// BeginGroup traces one bounded originating FIFO input group. Unlike Begin,
// owner/reconcile completion cannot arm this transaction until CommitGroup.
// Callers must supply actual event identities, then close the checked owner
// drain with GroupOwnerWork. No event, callback or generation is manufactured.
func (trace *FrameTrace) BeginGroup(tag uint64, group []events.Event) error {
	if tag == 0 || len(group) == 0 || len(group) > 4 {
		return errors.New("core: invalid traced input group")
	}
	for i, e := range group {
		if e == nil || reflect.ValueOf(e).Kind() != reflect.Pointer || reflect.ValueOf(e).IsNil() {
			return errors.New("core: invalid traced input group")
		}
		for _, earlier := range group[:i] {
			if earlier == e {
				return errors.New("core: duplicate traced input")
			}
		}
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if trace.pending != nil {
		return ErrFrameTraceBusy
	}
	trace.pending = &frameTracePending{FrameTraceSample: FrameTraceSample{Tag: tag}, group: append([]events.Event(nil), group...), transaction: true, ownerExpected: true, queued: time.Now()}
	if trace.sourceDetails {
		trace.pending.SourceDetails = &composer.SourceDetails{}
	}
	return nil
}

// GroupOwnerWork accumulates observed originating owner drains after dispatch
// has begun. Only a drain after the final input closes the owner terminal;
// intermediate work cannot arm a composition or assert an application transition.
func (trace *FrameTrace) GroupOwnerWork(tag uint64, duration int64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.transaction && p.groupDone > 0 && !p.armed {
		p.OwnerNS += duration
		if p.inputDone {
			p.ownerDone = true
		}
	}
}

// CommitGroup arms only a checked reconciled view generation. The caller must
// independently validate accepted application state before committing, while
// holding event/render ownership. A previous composition remains unarmed.
func (trace *FrameTrace) CommitGroup(tag, generation uint64) error {
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if !trace.groupReadyLocked(tag) || generation == 0 {
		return errors.New("core: traced input group is not reconciled")
	}
	p := trace.pending
	p.Generation = generation
	p.transition = true
	p.armed = true
	return nil
}

// GroupReady checks the actual original group/owner/reconcile terminals and
// excludes a known earlier failure or in-flight composition before app-state
// observation. This is not a reservation: CommitGroup rechecks the same gate.
func (trace *FrameTrace) GroupReady(tag uint64) bool {
	if trace == nil || tag == 0 {
		return false
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	return trace.groupReadyLocked(tag)
}
func (trace *FrameTrace) groupReadyLocked(tag uint64) bool {
	p := trace.pending
	return p != nil && p.Tag == tag && p.transaction && p.inputDone && p.ownerDone && p.reconciled && !p.ready && !p.armed && !p.rendering
}

func (trace *FrameTrace) CurrentTag() uint64 {
	if trace == nil {
		return 0
	}
	return trace.active.Load()
}
func (trace *FrameTrace) startEvent(event events.Event) (uint64, time.Time) {
	if trace == nil {
		return 0, time.Time{}
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	p := trace.pending
	if p == nil {
		return 0, time.Time{}
	}
	if p.transaction {
		if p.groupDone >= len(p.group) || p.group[p.groupDone] != event {
			return 0, time.Time{}
		}
	} else if p.event != event {
		return 0, time.Time{}
	}
	start := time.Now()
	if !p.transaction || p.groupDone == 0 {
		p.QueuedNS = start.Sub(p.queued).Nanoseconds()
	}
	trace.active.Store(p.Tag)
	return p.Tag, start
}
func (trace *FrameTrace) endEvent(tag uint64, start time.Time) {
	if tag == 0 {
		return
	}
	trace.active.Store(0)
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		if p.transaction {
			p.InputNS += time.Since(start).Nanoseconds()
			p.groupDone++
			p.inputDone = p.groupDone == len(p.group)
		} else {
			p.InputNS = time.Since(start).Nanoseconds()
			p.inputDone = true
		}
		if !p.ownerExpected {
			p.ownerDone = true
			if !p.ready {
				p.Failure = "traced input did not post owner work"
				p.Unavailable = false
				p.ready = true
			}
		}
	}
}

// ExpectOwner records a handler's checked asynchronous owner-post handshake.
// The caller explicitly closes the owner terminal if posting is refused.
func (trace *FrameTrace) ExpectOwner(tag uint64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.ownerExpected = true
	}
}

// OwnerTag identifies work after original input dispatch has begun. A grouped
// transaction keeps recording intermediate drains until arming; this accounting
// token alone does not imply the complete input or owner terminal.
func (trace *FrameTrace) OwnerTag() uint64 {
	if trace == nil {
		return 0
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil {
		if p.transaction {
			if p.groupDone > 0 && !p.armed && (!p.ready || !p.ownerDone) {
				return p.Tag
			}
		} else if p.inputDone && !p.ownerDone {
			return p.Tag
		}
	}
	return 0
}
func (trace *FrameTrace) Transition(tag, generation uint64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.Generation = generation
		p.transition = true
	}
}
func (trace *FrameTrace) OwnerWork(tag uint64, duration int64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.OwnerNS += duration
		if p.transition {
			p.ownerDone = true
		}
	}
}
func (trace *FrameTrace) ReconcileTag() uint64 {
	if trace == nil {
		return 0
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && !p.ready {
		if p.transaction {
			if p.groupDone > 0 && !p.armed {
				return p.Tag
			}
		} else if p.ownerDone && !p.reconciled {
			return p.Tag
		}
	}
	return 0
}
func (trace *FrameTrace) Reconciled(tag uint64, duration int64) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && !p.ready && (p.transaction && p.groupDone > 0 && !p.armed || !p.transaction && p.ownerDone) {
		p.ReconcileNS += duration
		p.reconciled = true
		if !p.transaction {
			p.armed = true
		}
	}
}
func (trace *FrameTrace) startFrame() uint64 {
	if trace == nil {
		return 0
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && (p.inputDone || p.transaction && p.groupDone > 0) && !p.rendering && !p.ready {
		p.rendering = true
		p.frameArmed = p.armed
		p.frameGeneration = p.Generation
		return p.Tag
	}
	return 0
}
func (trace *FrameTrace) frameWork(tag uint64, layout, gather int64) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && !p.ready {
		p.LayoutPaintNS += layout
		p.GatherNS += gather
	}
}
func (trace *FrameTrace) finishFrame(tag uint64, timing composer.ComposeTiming) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.rendering {
		p.rendering = false
		if p.ready {
			return
		}
		p.RasterUploadNS += timing.RasterUploadNS
		p.EncodeSubmitNS += timing.EncodeSubmitNS
		p.AcquireNS += timing.AcquireNS
		p.PresentCallNS += timing.PresentCallNS
		// Eligibility belongs to the original composition terminal. Diagnostic
		// validation must neither manufacture nor retain an unavailable result.
		unavailable := timing.Unavailable && timing.Supported && !timing.Submitted && timing.Failure != ""
		if trace.sourceDetails {
			if failure := appendFrameSourceDetails(p.SourceDetails, timing.SourceDetails); failure != "" {
				unavailable = false
				if timing.Failure == "" {
					timing.Failure = failure
				}
			}
		}
		submitted := timing.Supported && timing.Submitted && timing.Failure == "" && !timing.Unavailable
		p.Unavailable = unavailable
		p.Completed = p.frameArmed && submitted
		p.Failure = timing.Failure
		if !submitted && p.Failure == "" {
			p.Failure = "composition did not submit a measured frame"
		}
		p.TotalUIWorkNS = frameTraceWorkTotal(p.FrameTraceSample)
		p.ready = p.frameArmed || !submitted
	}
}

// noComposition accounts for an intermediate native update without GPU work.
// A final armed update must compose; an earlier unchanged paint may simply end.
func (trace *FrameTrace) noComposition(tag uint64, layout, gather int64) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.rendering {
		p.rendering = false
		if p.ready {
			return
		}
		p.LayoutPaintNS += layout
		p.GatherNS += gather
		if p.frameArmed {
			p.Failure = "armed frame did not reach composition"
			p.Unavailable = false
			p.ready = true
		}
	}
}

func (trace *FrameTrace) frameFailed(tag uint64, message string) {
	if tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		p.rendering = false
		if !p.ready {
			p.Failure = message
			p.Unavailable = false
			p.ready = true
		}
	}
}
func (trace *FrameTrace) Fail(tag uint64, message string) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && !p.ready {
		p.Failure = message
		p.Unavailable = false
		p.ready = true
	}
}
func frameTraceWorkTotal(s FrameTraceSample) int64 {
	return s.InputNS + s.OwnerNS + s.ReconcileNS + s.LayoutPaintNS + s.GatherNS + s.RasterUploadNS + s.EncodeSubmitNS
}

func (trace *FrameTrace) Take() (FrameTraceSample, bool) {
	if trace == nil {
		return FrameTraceSample{}, false
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.ready && (p.retired || p.inputDone && p.ownerDone && !p.rendering) {
		out := p.FrameTraceSample
		if p.transaction {
			// A failed intermediate composition may precede remaining input/owner work.
			// Retain the final observed stage sum rather than its earlier prefix total.
			out.TotalUIWorkNS = frameTraceWorkTotal(out)
		}
		trace.pending = nil
		return out, true
	}
	return FrameTraceSample{}, false
}

// Retire ends diagnostic ownership after the native window lifetime stops.
// Ordinary cancellation retains the pending ticket through input/owner terminals.
func (trace *FrameTrace) Retire(tag uint64, message string) {
	if trace == nil || tag == 0 {
		return
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag {
		if !p.ready {
			p.Failure = message
			p.Unavailable = false
			p.ready = true
		}
		p.retired = true
	}
}
func (trace *FrameTrace) Pending() bool {
	if trace == nil {
		return false
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	return trace.pending != nil
}

func (w *renderWindow) frameTrace() *FrameTrace {
	if stage := w.mains.windowStage(); stage != nil && stage.Scene != nil {
		return stage.Scene.FrameTrace()
	}
	return nil
}
