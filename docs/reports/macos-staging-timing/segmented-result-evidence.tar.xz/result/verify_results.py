from pathlib import Path
import json,hashlib,importlib.util,sys,datetime,tarfile
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-staging-timing';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=load(q/'bound-plan.json');assert all(sha(Path(p))==h for p,h in plan['pins'].items())
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
v=module('actual_segmented_timing',t/'tools/macos-calibration/stagingreuse/timing_segment_check.py');a=module('timing_sdk_integrity',q.parent/'macos-release-default-assessment/assessment.py');assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
d=load(q/'result.json');assert d['outcome']=='VALID_STAGING_FRAMEWORK_TIMING_PAIR' and d['error'] is None and [c['kind'] for c in d['cases']]==['off','on'];groups=0
for c in d['cases']:
 root=q/('pair1-'+c['kind']);lines=v.base.load(root/'native/stdout');assert len(lines)==1;doc=lines[0];assert v.validate(doc,load(q/'match.json'),c['kind'])==c['validation']==load(root/'validation.json');assert c['geometry_before']==c['geometry_after'];assert all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,root/folder/k) for k,cmd in c[phase].items())
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['pins_stable'] and cmd['logs_complete'] and cmd['logs']['stderr']['bytes']==0
  for stream,e in cmd['logs'].items():assert sha(folder/stream)==e['sha256'] and (folder/stream).stat().st_size==e['bytes']
  groups+=1
assert groups==18;s=load(q/'summary.json');assert s==load(r/'segmented-result-summary.json');assert s['elapsed_seconds']==(datetime.datetime.fromisoformat(d['finished_utc'])-datetime.datetime.fromisoformat(load(q/'started.json')['started_utc'])).total_seconds()<90
for row,c in zip(s['runs'],d['cases']):
 metrics=json.loads(json.dumps(c['validation']));metrics['staging_lifecycle'].pop('leases');metrics['request_schedule_segments'].pop('raw_segments')
 assert row['mode']==c['kind'] and row['metrics']==metrics
for label in ['schedule-refusal','segments-preparation','segmented-result']:
 index=r/(label+'-evidence-index.json');archive=r/(label+'-evidence.tar.xz')
 if not index.exists():continue
 e=load(index);assert sha(archive)==e['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(e['files'])
  for n,h in e['files'].items():b=tf.extractfile(n).read();assert len(b)==h['bytes'] and hashlib.sha256(b).hexdigest()==h['sha256']
print('PASS off/on248requests120measured each,120enabledmeasuredhits;CPU/source/lifetime/presentation joins;18groups;SDK8321/source/log/config/geometrypins;90sbound. Bothpresentationp95>33.3ms, noordinaryacceptance;old42mscauseunproven.')
