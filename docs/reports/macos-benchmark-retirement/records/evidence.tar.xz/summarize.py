from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-benchmark-cleanup');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((P/'baseline.json').read_text());review=json.loads((P/'source-review.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE'and not review['unresolved_findings']and len(sources)==5
assert all(sha(R/n)==h for n,h in sources.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base['base_commit']
assert sha(P/'original-benchmark.py.txt')==base['tracked']['scripts/benchmark-grid.py']
checks={}
for n in ['original-regressions','benchmark-final','benchmark-v2','child-final']:
 d=json.loads((P/(n+'.json')).read_text());assert d['source_stable']and d['source_delta_before']==d['source_delta_after']and d['error']is None
 assert d['source_commit']==base['base_commit']and d['producer_sha256']==sha(P/'check.py')
 assert all(not d[k]for k in['native_application_executed','gpu_requested','prepared_inputs_used'])
 assert all(sha(P/(n+'.'+ext))==d[ext+'_sha256']for ext in['stdout','stderr'])
 checks[n]=d
assert checks['original-regressions']['exit_code']==1 and sha(P/'original-regression-tests.py.txt')==checks['original-regressions']['source_delta_before']['scripts/benchmark-grid_test.py']
assert 'FAILED (failures=2)'in(P/'original-regressions.stderr').read_text()and 'successful benchmark left a live descendant: S'in(P/'original-regressions.stderr').read_text()
assert checks['benchmark-final']['exit_code']==1 and 'FAILED (failures=1)'in(P/'benchmark-final.stderr').read_text()
assert all(sha(P/'intermediate-sources'/n)==h for n,h in checks['benchmark-final']['source_delta_before'].items())
for n in ['benchmark-v2','child-final']:
 assert checks[n]['exit_code']==0 and (P/(n+'.stderr')).read_text().rstrip().endswith('OK')
assert all(sources[n]==h for n,h in checks['benchmark-v2']['source_delta_before'].items())
assert all(sha(R/n)==base['tracked'][n]==h for n,h in review['helper_source_sha256'].items())
for n,h in review['reviewed_artifact_sha256'].items():assert sha(P/n)==h
for n,h in sources.items():
 target=P/'final-sources'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/n).read_bytes());assert sha(target)==h
q={'result':'PASS_SCOPED_BENCHMARK_RETIREMENT_CHECKPOINT','base_commit':base['base_commit'],'source_root':str(R),'sources':sources,'source_review_sha256':sha(P/'source-review.json'),'producer_sha256':sha(__file__),'baseline_sha256':sha(P/'baseline.json'),'test_producer_sha256':sha(P/'check.py'),'original_regressions':{'receipt':'original-regressions.json','receipt_sha256':sha(P/'original-regressions.json'),'tests':2,'failures':2,'exit_code':1,'actual_live_descendant_observed':True,'scope':'Baseline runner and exact retained original test snapshot; final assertion diagnostic formatting differs.'},'intermediate':{'receipt_sha256':sha(P/'benchmark-final.json'),'tests':42,'failures':1,'exit_code':1,'scope':'Exact intermediate two-source snapshot; missing exception message corrected afterward.'},'final_benchmark':{'receipt_sha256':sha(P/'benchmark-v2.json'),'tests':42,'exit_code':0,'compiled_python_sources_exact':True,'source_delta':checks['benchmark-v2']['source_delta_before'],'scope':'Final Python sources; three documentation leaves added/corrected afterward.'},'process_helper':{'receipt_sha256':sha(P/'child-final.json'),'tests':9,'exit_code':0,'unchanged_source_sha256':review['helper_source_sha256'],'scope':'Helper closure unchanged between baseline/intermediate/final; benchmark leaf differed at execution and is not imported by this suite.'},'scope':'Always retire benchmark-owned POSIX process groups after measured work, including direct exit0 plus EOF; reject cleanup errors with diagnostic. Generic child helper and Windows success policy unchanged.','native_application_executed':False,'gpu_requested':False,'prepared_inputs_used':False,'empty_process_group_qualified':False,'native_inventory_qualified':False,'native_performance_qualified':False,'overnight_qualified':False,'physical_input_qualified':False,'full_mac_qualified':False,'limits':['Actual CPU-only Python descendant may be absent or a terminated zombie awaiting OS reap; not an empty Vellum native process group or allocation inventory.','Synthetic valid timing records are regression fixtures, not native frame measurements.','Independent native lifecycle campaign uses frozen c078 source/controller; no checkpoint claim extends to it.']}
(P/'summary.json').open('x').write(json.dumps(q,indent=2)+'\n')
print(json.dumps({'result':q['result'],'sources':len(sources),'benchmark_tests':42,'helper_tests':9,'original_failures':2,'native_application_executed':False}))
