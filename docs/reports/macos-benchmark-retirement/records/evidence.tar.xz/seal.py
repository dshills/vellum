from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
R=Path('/private/tmp/vellum-benchmark-cleanup');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-benchmark-retirement/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((P/'summary.json').read_text());review=json.loads((P/'checkpoint-review.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());prism=json.loads((P/'prism-v1/prism.json').read_text());coverage=prism['coverage']
assert s['result']=='PASS_SCOPED_BENCHMARK_RETIREMENT_CHECKPOINT'and review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==s['sources']and not review['implementation_findings']and len(review['unresolved_findings'])==1 and review['unresolved_findings'][0]['id']=='73100a8c145a4746'and review['unresolved_findings'][0]['status']=='OPEN_PENDING_SEAL'and not review['commit_ready']
assert all(sha(R/n)==h for n,h in s['sources'].items())and len(s['sources'])==5
assert process['exit_code']==1 and process['error']is None and process['source_index_stable']and process['sources']==s['sources']
assert coverage['complete']and coverage['files']==5 and coverage['chunks']==coverage['llmCalls']==1 and coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]and not coverage['excluded']and not coverage['skipped']and coverage['truncatedBytes']==0
assert not prism['discarded']and not prism['suppressed']and len(prism['findings'])==1
finding=prism['findings'][0];assert finding['id']=='73100a8c145a4746'and finding['severity']=='medium'and finding['category']=='docs'and finding['title']=='Report links to qualification records that are not part of the change'
assert not any(s[k]for k in['native_application_executed','gpu_requested','prepared_inputs_used','full_mac_qualified'])
files=[f for f in sorted(P.rglob('*'))if f.is_file()and'__pycache__'not in f.parts]
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files};assert len(members)==len(files)
D.mkdir(exist_ok=False);archive=D/'evidence.tar.xz'
with archive.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'excluded_directories':['__pycache__']};(D/'archive-index.json').open('x').write(json.dumps(index,indent=2)+'\n')
q={**s,'checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_process_sha256':sha(P/'prism-v1/process.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_coverage_complete':True,'prism_files':5,'prism_llm_calls':1,'prism_findings':1,'prism_exit_code':1,'prism_disposition':{'id':finding['id'],'resolution':'ADD_REFERENCED_RECORDS','required_paths':['docs/reports/macos-benchmark-retirement/records/'+n for n in ['qualification.json','archive-index.json','evidence.tar.xz']],'scope':'Missing linked evidence is supplied in the same checkpoint. Independent final review must validate all eight changed leaves and the archive. No clean-provider finding count or exit0 is claimed.'},'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').open('x').write(json.dumps(q,indent=2)+'\n')
assert all((R/n).is_file()for n in q['prism_disposition']['required_paths'])and json.loads((D/'qualification.json').read_text())==q
with tarfile.open(archive,'r:xz')as tar:
 actual={}
 for member in tar.getmembers():
  assert member.isfile()and member.name in members
  data=tar.extractfile(member).read();actual[member.name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert actual==members
subprocess.run(['git','add','--',str(D)],cwd=R,check=True)
print(json.dumps({k:q[k]for k in['result','archive_members','archive_bytes','archive_sha256','prism_findings','prism_exit_code']}))
