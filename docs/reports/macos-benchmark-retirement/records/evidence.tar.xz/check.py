"""Recorded CPU-only regression checks; never launches a Vellum native app."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-benchmark-cleanup');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
name,*argv=sys.argv[1:]
assert argv[:2]in[['python3','scripts/benchmark-grid_test.py'],['python3','scripts/child_process_test.py']]
def delta():
 names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
 return{n:sha(R/n)for n in sorted(names)}
d={'argv':argv,'cwd':str(R),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'source_delta_before':delta(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':sha(__file__),'native_application_executed':False,'gpu_requested':False,'prepared_inputs_used':False,'exit_code':None,'error':None};start=time.monotonic()
try:
 with(P/(name+'.stdout')).open('xb')as so,(P/(name+'.stderr')).open('xb')as se:d['exit_code']=run_child(argv,cwd=R,env=child_environment(),stdout=so,stderr=se,timeout=120).returncode
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)}
finally:
 d.update(elapsed_seconds=time.monotonic()-start,source_delta_after=delta());d['source_stable']=d['source_delta_before']==d['source_delta_after']
 for ch in['stdout','stderr']:d[ch+'_sha256']=sha(P/(name+'.'+ch))
 (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if not k.startswith('source_delta')}))
sys.exit(d['exit_code'] if d['exit_code'] is not None and d['error'] is None and d['source_stable'] else 125)
