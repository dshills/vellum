from pathlib import Path
import hashlib,json,subprocess,sys,time,shutil
R=Path('/private/tmp/vellum-benchmark-cleanup');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent;O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-benchmark-retirement')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def git(root,*args):
 r=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert r.returncode==0,r.stderr;return r.stdout.decode().strip()
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in['upstream','typesetting']for f in(root/'drivers/cogent/build'/m).rglob('*')if f.is_file()}
D=R/'docs/reports/macos-benchmark-retirement/records';q=json.loads((D/'qualification.json').read_text());review=json.loads((P/'final-review.json').read_text());baseline=json.loads((P/'baseline.json').read_text())
assert q['result']=='PASS_SCOPED_BENCHMARK_RETIREMENT_CHECKPOINT'and review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not review['unresolved_findings']and review['commit_ready']
assert q['prism_findings']==1 and q['prism_exit_code']==1 and q['prism_coverage_complete']and q['prism_disposition']['resolution']=='ADD_REFERENCED_RECORDS'
assert all(not q[k]for k in['native_application_executed','gpu_requested','prepared_inputs_used','full_mac_qualified'])
base=q['base_commit'];commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]and git(C,'rev-parse','HEAD')==base and not git(C,'status','--porcelain')and not git(R,'status','--porcelain')
changed=set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines());assert changed==set(q['sources'])|{'docs/reports/macos-benchmark-retirement/records/'+n for n in['qualification.json','archive-index.json','evidence.tar.xz']}
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert review['sources']=={n:expected[n]for n in changed}and all(expected[n]==h for n,h in q['sources'].items())
assert all(sha(C/n)==h for n,h in baseline['tracked'].items())
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/name.decode();assert kind=='blob'and path.is_file()and not path.is_symlink();data=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
prep=prepared(C);native=json.loads(Path('/private/tmp/vellum-macos-composed-endurance/native-build-committed.json').read_text());assert len(prep)==6227 and prep==native['prepared_before']==native['prepared_after']
historical=Path('/private/tmp/vellum-macos-quiet-current/stop-live');historical_hash=sha(historical);assert historical_hash=='db5c4df12d8f08cedc63b39d7998a963aa1ca313aaa3b5a434ad64836064164f'
O.mkdir(parents=True,exist_ok=True);output=O/'canonical-promotion.json';output.open('x').close();start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'changed_files':sorted(changed),'native_application_executed':False,'prepare_run':False,'scope':'Python benchmark cleanup only; active native c078 source/controller unchanged.'}
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 actual=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_files':len(expected),'tracked_exact':set(actual)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_files':6227,'prepared_exact':prepared(C)==prep,'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'heads_exact':git(C,'rev-parse','HEAD')==commit and git(R,'rev-parse','HEAD')==commit,'historical_stop_marker_preserved':sha(historical)==historical_hash,'archive_sha256':sha(C/'docs/reports/macos-benchmark-retirement/records/evidence.tar.xz'),'final_review_sha256':sha(P/'final-review.json')})
 assert all(record[k]for k in['tracked_exact','prepared_exact','canonical_clean','scratch_clean','heads_exact','historical_stop_marker_preserved'])and record['archive_sha256']==q['archive_sha256']
 for f in sorted(P.rglob('*')):
  if not f.is_file()or'__pycache__'in f.parts:continue
  target=O/'private-evidence'/f.relative_to(P);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target);assert sha(target)==sha(f)
 for name in ['qualification.json','archive-index.json','evidence.tar.xz']:shutil.copy2(D/name,O/name);assert sha(O/name)==sha(D/name)
 record['durable_artifacts_exact']=True;record['result']='PASS_CANONICAL_PROMOTION'
except BaseException as e:record['result']='FAILED_CANONICAL_PROMOTION';record['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');output.write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
