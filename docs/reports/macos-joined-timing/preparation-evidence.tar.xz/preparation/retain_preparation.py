from pathlib import Path
import tarfile,io,json,hashlib
q=Path(__file__).resolve().parent
paths=sorted(p for p in q.rglob('*') if p.is_file() and not any(part in ['__pycache__','tmp','capture'] for part in p.relative_to(q).parts) and p.name not in ['framework','framework-v2','preparation-evidence.tar.xz','preparation-evidence-index.json'] and not p.name.startswith('result-evidence'))
files={};archive=q/'preparation-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for p in paths:
  data=p.read_bytes();name='preparation/'+p.relative_to(q).as_posix();m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.mtime=0;m.uid=m.gid=0;m.uname=m.gname='';t.addfile(m,io.BytesIO(data));files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as t:
 assert sorted(t.getnames())==sorted(files)
 for m in t:
  data=t.extractfile(m).read();assert len(data)==files[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==files[m.name]['sha256']
(q/'preparation-evidence-index.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'scope':'Reviewed preparation only. Final v2 compiled inputs; superseded v1 preparation retained, no native attempt yet. No executable/native library/full SDK/cache/credentials included; local checkpoint only.'},indent=2)+'\n')
print(json.dumps({'bytes':archive.stat().st_size,'members':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
