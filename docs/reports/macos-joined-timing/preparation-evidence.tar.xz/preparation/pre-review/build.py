from pathlib import Path
import json,hashlib,sys,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');p=Path('/private/tmp/vellum-joined-timing-core');f=r/'tools/macos-calibration/upload/framework';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sys.path.insert(0,str(r/'scripts'));sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('joined_owned',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
lib=Path('/private/tmp/vellum-upload-probe/libs-darwin/arm64/libwgpu_native.a');identity=json.loads((q.parent/'macos-upload-probe/build-identity.json').read_text());assert sha(lib)==identity['archive_sha256']=='2bece763dbe7d2ec088fa8c69bd6af8944a6633ba4ef4d805f8af9eee7ae359f';assert all(sha(Path(k))==v for k,v in identity['private_source_pins'].items())
pins={str(x):sha(x) for root in [p,f] for x in root.rglob('*') if x.is_file()};pins.update(identity['private_source_pins']);pins[str(lib)]=sha(lib);pins.update({str(q/n):sha(q/n) for n in ['framework.mod','framework.sum','core.mod','core.sum','overlay.json','desktop_session.go','desktop_measurement.go','frame_trace.go','native_main_darwin.go','fixture_test.go','build.py','match.json']})
base=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/bin/sh',str(q.parent/'macos-app-examples/go-check')]
name=sys.argv[1]
if name=='recorder':cwd=p;argv=base+['test','-race','-modfile='+str(q/'core.mod'),'-run','^TestVellumJoinedRaster','-count=1','./paint/renderers/rasterx']
elif name=='pixels':cwd=f;argv=base+['test','-tags=offscreen','-modfile='+str(q/'framework.mod'),'-overlay='+str(q/'overlay.json'),'-run','^TestRoutedStateAndExactPatchPixels$','-count=1','-v','.']
elif name=='native-build':cwd=f;argv=base+['build','-modfile='+str(q/'framework.mod'),'-overlay='+str(q/'overlay.json'),'-ldflags=-buildid='+sha(lib),'-o',str(q/'framework'),'.']
else:raise SystemExit('unknown case')
run=g.execute(argv,cwd,q/name,lambda:False,lambda:all(sha(Path(k))==v for k,v in pins.items()),timeout=180,limit=4<<20);(q/(name+'-receipt.json')).write_text(json.dumps({'inputs':pins,'run':run},indent=2)+'\n');print(json.dumps({name:{k:run[k] for k in ['exit_code','error','seconds']}}));assert run['error'] is None and run['exit_code']==0 and run['owned']['terminal'] and run['owned']['group_absent']
