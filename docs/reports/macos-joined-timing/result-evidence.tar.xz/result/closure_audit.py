"""Independent arithmetic from raw native/Go journals, not stored partition values."""
from pathlib import Path
import json,math
q=Path(__file__).resolve().parent;doc=json.loads((q/'capture/native/stdout').read_text());result=json.loads((q/'result-summary.json').read_text());errors=[];receipt_errors=[];ulps=[]
receipts={(r['Scope'],r['Tag']):r['Received'] for r in doc['before_close']['Inputs']}
for i,m in enumerate(doc['measurements']['Samples']):
 f=m['Frame'];received=receipts[m['Scope'],f['Tag']];hits=[r for r in doc['before_close']['Samples'] if r['Scope']==m['Scope'] and r['Tag']==f['Tag'] and r['Generation']==f['Generation'] and r['Armed']];assert len(hits)==1;feedback=hits[0]
 writes=[r for r in doc['native_upload_trace']['records'] if received<=r['begin'] and r['end']<=feedback['Acquired']];assert len(writes)==1;write=writes[0]
 renders=[r for r in doc['raster_trace']['Records'] if received<=r['Begin'] and r['End']<=write['begin']];assert len(renders)==1;render=renders[0];a=doc['request_schedule_anchors'][i]
 clocks=[a['WakeHost'],a['CheckedHost'],a['PostCheckHost'],received,render['Begin'],render['End'],write['begin'],write['end'],feedback['Acquired'],feedback['Presented']]
 pieces=[(clocks[j+1]-clocks[j])*1e9 for j in range(9)];errors.append(sum(pieces)-(clocks[-1]-clocks[0])*1e9);receipt_errors.append(sum(pieces[3:])-(clocks[-1]-received)*1e9);ulps.extend(math.ulp(x)*1e9 for x in clocks)
audit={'inputs_recomputed':len(errors),'maximum_absolute_wake_closure_ns':max(map(abs,errors)),'maximum_absolute_receipt_closure_ns':max(map(abs,receipt_errors)),'observed_signed_wake_residuals_ns':sorted(set(errors)),'observed_signed_receipt_residuals_ns':sorted(set(receipt_errors)),'native_float_timestamp_ulp_ns':{'min':min(ulps),'max':max(ulps)},'classifier_refusal_tolerance_ns':1000,'interpretation':'The0nsvalue is recomputed from the raw clocks for this dataset, not asserted as universal precision. Native float stamps lie on one binary lattice here and telescope exactly in these calculations. ULP is representation spacing, not clock accuracy; tolerance is a refusal bound, not a reported measurement or calibration.'}
assert len(errors)==248 and audit['maximum_absolute_wake_closure_ns']==result['maximum_wake_partition_closure_error_ns']
(q/'closure-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit))
