from pathlib import Path
import json,hashlib,tarfile,io
q=Path(__file__).resolve().parent
paths=[q/n for n in ['result.json','validation.json','result-summary.json','result-README.md','result-spec-addition.txt','result-internal-review.json','bound-plan.json','started.json','preparation-commit.json','verify_results.py','closure_audit.py','closure-audit.json','review_results.py','retain_results.py']]
paths.extend(p for root in ['capture','result-review'] for p in (q/root).rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts)
files={};archive=q/'result-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for p in sorted(set(paths)):
  data=p.read_bytes();name='result/'+p.relative_to(q).as_posix();m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.uid=m.gid=0;m.mtime=0;m.uname=m.gname='';t.addfile(m,io.BytesIO(data));files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as t:
 assert sorted(t.getnames())==sorted(files)
 for m in t:
  data=t.extractfile(m).read();assert len(data)==files[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==files[m.name]['sha256']
(q/'result-evidence-index.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'reused_preparation_archive_sha256':json.loads((q/'preparation-evidence-index.json').read_text())['archive_sha256'],'scope':'One approved joined native diagnostic, local checkpoint only. Full configured startup/cohort/source/log/ownership/clock evidence; no binary/native library/credentials, ordinary qualification or production repair.'},indent=2)+'\n')
print(json.dumps({'bytes':archive.stat().st_size,'members':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
