// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

// Package sceneplan owns detached, bounded painter-ordered scene operations.
// It has no GPU, font, widget or application references. CPU replay is the
// reconstruction path for explicit snapshots and a later unsupported batch.
package sceneplan

import (
	"encoding/binary"
	"image"
	"image/color"
	"image/draw"
)

const (
	TileSize          = 16
	MaxDimension      = 8192
	MaxPixels         = 16 << 20
	MaxBytes          = 32 << 20
	MaxOps            = 65536
	MaxTileReferences = 2 << 20
	opWords           = 16
)

// Kind selects the reference renderer's arithmetic, not a GPU blend state.
const (
	Uniform uint32 = iota
	Mask
	Pixels
	Spans
)

type operation struct {
	rect    image.Rectangle
	kind    uint32
	op      draw.Op
	color   [4]uint32
	image   *image.RGBA
	mask    *image.Alpha
	maskPos image.Point
	rows    [][]span
}
type span struct {
	x0, x1 int
	alpha  uint32
}

type Packet struct {
	bounds      image.Rectangle
	ops         []operation
	bytes       int
	winding     bool
	independent bool
}

func (p *Packet) Bounds() image.Rectangle { return p.bounds }
func (p *Packet) Bytes() int              { return p.bytes }
func (p *Packet) Operations() int         { return len(p.ops) }
func (p *Packet) Winding() bool           { return p.winding }

// Independent means the accepted first operation replaces every target pixel.
// Nonempty commands alone do not establish a complete frame.
func (p *Packet) Independent() bool { return p.independent }

// Replay applies this packet to an existing image, preserving partial batches.
// The image must have the exact packet bounds; no caller callbacks are invoked.
func (p *Packet) Replay(dst *image.RGBA) bool {
	if p == nil || dst == nil || dst.Bounds() != p.bounds {
		return false
	}
	for _, o := range p.ops {
		c := color.RGBA64{uint16(o.color[0]), uint16(o.color[1]), uint16(o.color[2]), uint16(o.color[3])}
		switch o.kind {
		case Uniform:
			draw.Draw(dst, o.rect, image.NewUniform(c), image.Point{}, o.op)
		case Mask:
			draw.DrawMask(dst, o.rect, image.NewUniform(c), image.Point{}, o.mask, o.maskPos, o.op)
		case Pixels:
			if o.mask == nil {
				draw.Draw(dst, o.rect, o.image, image.Point{}, o.op)
			} else {
				draw.DrawMask(dst, o.rect, o.image, image.Point{}, o.mask, o.maskPos, o.op)
			}
		case Spans:
			for row, spans := range o.rows {
				for _, s := range spans {
					for x := s.x0; x < s.x1; x++ {
						offset := dst.PixOffset(x, o.rect.Min.Y+row)
						alpha := (65535 - o.color[3]*s.alpha/65535) * 257
						for ch := 0; ch < 4; ch++ {
							if o.op == draw.Over {
								dst.Pix[offset+ch] = uint8((uint32(dst.Pix[offset+ch])*alpha + o.color[ch]*s.alpha) / 16776960)
							} else {
								dst.Pix[offset+ch] = uint8(o.color[ch] * s.alpha / 16776960)
							}
						}
					}
				}
			}
		}
	}
	return true
}

// Encoded is a detached packet for one integer compute pass. Rows has two words
// per tile (offset,count); Refs preserves original painter order within tiles.
// Ops has 16 words per operation; Data holds tightly packed masks/pixels/spans.
// All byte slices are owned by this result and have 4-byte alignment.
type Encoded struct {
	Ops, Rows, Refs, Data []byte
	Tiles                 image.Point
}

func appendWord(out []byte, value uint32) []byte { return binary.LittleEndian.AppendUint32(out, value) }
func packMask(dst []byte, mask *image.Alpha) []byte {
	word := uint32(0)
	n := 0
	for y := mask.Rect.Min.Y; y < mask.Rect.Max.Y; y++ {
		for x := mask.Rect.Min.X; x < mask.Rect.Max.X; x++ {
			word |= uint32(mask.Pix[mask.PixOffset(x, y)]) << uint(n*8)
			n++
			if n == 4 {
				dst = appendWord(dst, word)
				word = 0
				n = 0
			}
		}
	}
	if n != 0 {
		dst = appendWord(dst, word)
	}
	return dst
}

// Encode preserves every accepted operation in its original order.
func (p *Packet) Encode() (*Encoded, bool) { return p.encode(false) }

// EncodeGPU omits an owned uniform Src immediately overwritten by an equal
// rectangle opaque uniform Over. Admission still charges every original operation,
// encoded byte and tile reference. Packet replay, accounting and reset proof are
// unchanged; the encoded result owns compact operation IDs and tile references.
func (p *Packet) EncodeGPU() (*Encoded, bool) { return p.encode(true) }

func (p *Packet) coveredClear(i int) bool {
	if i+1 >= len(p.ops) {
		return false
	}
	a, b := p.ops[i], p.ops[i+1]
	return a.kind == Uniform && b.kind == Uniform && a.op == draw.Src && b.op == draw.Over &&
		a.rect == b.rect && b.color[3] == 65535
}

func (p *Packet) encode(compact bool) (*Encoded, bool) {
	if p == nil || len(p.ops) > MaxOps {
		return nil, false
	}
	tiles := image.Pt((p.bounds.Dx()+TileSize-1)/TileSize, (p.bounds.Dy()+TileSize-1)/TileSize)
	counts := make([]int, tiles.X*tiles.Y)
	masks := make(map[*image.Alpha]uint32)
	dataBytes, refs, retainedRefs, retainedOps := 0, 0, 0, 0
	// Validate exact encoded sizes and bin counts before allocating any output.
	for i, o := range p.ops {
		keep := !compact || !p.coveredClear(i)
		if keep {
			retainedOps++
		}
		if o.mask != nil {
			if _, ok := masks[o.mask]; !ok {
				masks[o.mask] = uint32(dataBytes / 4)
				dataBytes += (len(o.mask.Pix) + 3) / 4 * 4
			}
		}
		switch o.kind {
		case Pixels:
			dataBytes += o.rect.Dx() * o.rect.Dy() * 4
		case Spans:
			dataBytes += len(o.rows) * 8
			for _, row := range o.rows {
				dataBytes += len(row) * 12
			}
		}
		for y := o.rect.Min.Y / TileSize; y <= (o.rect.Max.Y-1)/TileSize; y++ {
			for x := o.rect.Min.X / TileSize; x <= (o.rect.Max.X-1)/TileSize; x++ {
				if refs == MaxTileReferences {
					return nil, false
				}
				if keep {
					counts[y*tiles.X+x]++
					retainedRefs++
				}
				refs++
			}
		}
		if len(p.ops)*opWords*4+len(counts)*8+refs*4+dataBytes > MaxBytes {
			return nil, false
		}
	}
	e := &Encoded{Tiles: tiles, Ops: make([]byte, 0, max(4, retainedOps*opWords*4)), Rows: make([]byte, 0, len(counts)*8), Refs: make([]byte, max(4, retainedRefs*4)), Data: make([]byte, 0, max(4, dataBytes))}
	// Once each count has been copied into Rows, its slot becomes fill scratch.
	positions := counts
	offset := 0
	for i, count := range counts {
		positions[i] = offset
		e.Rows = appendWord(e.Rows, uint32(offset))
		e.Rows = appendWord(e.Rows, uint32(count))
		offset += count
	}
	clear(masks)
	encodedIndex := uint32(0)
	for i, o := range p.ops {
		if compact && p.coveredClear(i) {
			continue
		}
		words := [opWords]uint32{uint32(o.rect.Min.X), uint32(o.rect.Min.Y), uint32(o.rect.Max.X), uint32(o.rect.Max.Y), o.color[0], o.color[1], o.color[2], o.color[3], o.kind, uint32(o.op), 0, 0, ^uint32(0), 0, 0, 0}
		if o.mask != nil {
			at, ok := masks[o.mask]
			if !ok {
				at = uint32(len(e.Data) / 4)
				e.Data = packMask(e.Data, o.mask)
				masks[o.mask] = at
			}
			words[12], words[13], words[14], words[15] = at, uint32(o.mask.Stride), uint32(o.maskPos.X), uint32(o.maskPos.Y)
		}
		if o.kind == Pixels {
			words[10], words[11] = uint32(len(e.Data)/4), uint32(o.rect.Dx())
			for y := 0; y < o.image.Rect.Dy(); y++ {
				for x := 0; x < o.image.Rect.Dx(); x++ {
					at := o.image.PixOffset(x, y)
					e.Data = appendWord(e.Data, binary.LittleEndian.Uint32(o.image.Pix[at:at+4]))
				}
			}
		}
		if o.kind == Spans {
			words[10] = uint32(len(e.Data) / 4)
			base := len(e.Data)
			e.Data = append(e.Data, make([]byte, len(o.rows)*8)...)
			for y, row := range o.rows {
				binary.LittleEndian.PutUint32(e.Data[base+y*8:], uint32(len(e.Data)/4))
				binary.LittleEndian.PutUint32(e.Data[base+y*8+4:], uint32(len(row)))
				for _, s := range row {
					e.Data = appendWord(e.Data, uint32(s.x0))
					e.Data = appendWord(e.Data, uint32(s.x1))
					e.Data = appendWord(e.Data, s.alpha)
				}
			}
		}
		for _, w := range words {
			e.Ops = appendWord(e.Ops, w)
		}
		for y := o.rect.Min.Y / TileSize; y <= (o.rect.Max.Y-1)/TileSize; y++ {
			for x := o.rect.Min.X / TileSize; x <= (o.rect.Max.X-1)/TileSize; x++ {
				bin := y*tiles.X + x
				binary.LittleEndian.PutUint32(e.Refs[positions[bin]*4:], encodedIndex)
				positions[bin]++
			}
		}
		encodedIndex++
	}
	if len(e.Ops) == 0 {
		e.Ops = e.Ops[:4]
	}
	if len(e.Data) == 0 {
		e.Data = e.Data[:4]
	}
	return e, true
}
