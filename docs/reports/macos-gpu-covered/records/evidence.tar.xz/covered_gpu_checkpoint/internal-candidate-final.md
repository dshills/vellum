APPROVED_CANDIDATE_SOURCE_AND_EVIDENCE. No unresolved finding in the exact four candidate files.

Original admission charges are preserved, compacted tile counts/IDs remain ordered and dense, and Packet/CPU replay ownership and reset semantics do not change. The adapter only selects EncodeGPU. Inherited original ABI digests, marked-clear expected stream and serialized scalar execution provide distinct references.

Selected parent race/vet receipts pass with 6207 prepared endpoints unchanged. All 48 fixed/variable software grid captures across four DPI values equal original CPU batch pixels and prior full software captures. First 400-visible-cell record reduces 4397 to 3980 encoded operations and 1688088 to 1538904 encoded bytes. Three deliberate alpha/index/budget mutations fail meaningful assertions; the index mutation additionally causes a later invalid-index panic. The initial matrix compilation failure and initial three-target unit version remain separate.

The added explicit native GPU fixture is compiled but unexecuted. Reviewer ran no tested source, build, native/provider operation or mutation. This approval does not establish native frame speed, physical GPU/memory benefit, full P6/P11, default GPU enablement or formal patch adoption. Exact source/evidence hashes and version limits are in internal-candidate-final.json.
