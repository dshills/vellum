from pathlib import Path
import json,hashlib
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-gpu-covered');U=R/'drivers/cogent/build/upstream'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
(P/'prepared-baseline.json').write_text(json.dumps({f.relative_to(R/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()},indent=2)+'\n')
path=U/'paint/renderers/sceneplan/packet.go';s=path.read_text();s=s.replace('func (p *Packet) Encode() (*Encoded, bool) {','''// Encode preserves every accepted operation in its original order.
func (p *Packet) Encode() (*Encoded, bool) { return p.encode(false) }

// EncodeGPU omits an owned uniform Src immediately overwritten by an equal
// rectangle opaque uniform Over. Admission still charges every original operation,
// encoded byte and tile reference. Packet replay, accounting and reset proof are
// unchanged; the encoded result owns compact operation IDs and tile references.
func (p *Packet) EncodeGPU() (*Encoded, bool) { return p.encode(true) }

func (p *Packet) coveredClear(i int) bool {
 if i+1 >= len(p.ops) { return false }
 a, b := p.ops[i], p.ops[i+1]
 return a.kind == Uniform && b.kind == Uniform && a.op == draw.Src && b.op == draw.Over &&
  a.rect == b.rect && b.color[3] == 65535
}

func (p *Packet) encode(compact bool) (*Encoded, bool) {''');s=s.replace('dataBytes, refs := 0, 0','dataBytes, refs, retainedRefs, retainedOps := 0, 0, 0, 0',1);s=s.replace('for _, o := range p.ops {\n\t\tif o.mask != nil {','for i, o := range p.ops {\n\t\tkeep := !compact || !p.coveredClear(i)\n\t\tif keep { retainedOps++ }\n\t\tif o.mask != nil {',1);s=s.replace('counts[y*tiles.X+x]++\n\t\t\t\trefs++','if keep { counts[y*tiles.X+x]++; retainedRefs++ }\n\t\t\t\trefs++',1);s=s.replace('max(4, len(p.ops)*opWords*4)', 'max(4, retainedOps*opWords*4)',1).replace('max(4, refs*4)', 'max(4, retainedRefs*4)',1);s=s.replace('clear(masks)\n\tfor i, o := range p.ops {','clear(masks)\n\tencodedIndex := uint32(0)\n\tfor i, o := range p.ops {\n\t\tif compact && p.coveredClear(i) { continue }',1);s=s.replace('uint32(i))\n\t\t\t\tpositions[bin]++','encodedIndex)\n\t\t\t\tpositions[bin]++',1);s=s.replace('\n\tif len(e.Ops) == 0 {','\n\t\tencodedIndex++\n\t}\n\tif len(e.Ops) == 0 {',1).replace('\n\t}\n\t\tencodedIndex++\n\t}', '\n\t\tencodedIndex++\n\t}',1)
(P/'packet.go').write_text(s)
gpu=U/'paint/renderers/gpuscene/renderer.go';g=gpu.read_text();assert g.count('encoded, ok = packet.Encode()')==1;(P/'gpu-renderer.go').write_text(g.replace('encoded, ok = packet.Encode()','encoded, ok = packet.EncodeGPU()'))
overlay={'Replace':{str(path):str(P/'packet.go'),str(gpu):str(P/'gpu-renderer.go')}}
(P/'candidate-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
s=Path('/private/tmp/vellum-macos-render-probe/code_run.py').read_text().replace("p=Path('/private/tmp/vellum-macos-render-probe')","p=Path('/private/tmp/vellum-macos-gpu-covered')");(P/'code_run.py').write_text(s)
print('Candidate encoding overlay created; baseline leaves',len(json.loads((P/'prepared-baseline.json').read_text())))
