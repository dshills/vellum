//go:build !js

// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package gpuscene

import (
	"bytes"
	"cogentcore.org/core/paint/ppath"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"cogentcore.org/core/text/textpos"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"io/fs"
	"math/rand"
	"os"
	"reflect"
	"testing"
	"time"

	"cogentcore.org/core/gpu"
	"cogentcore.org/core/gpu/gpudraw"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"github.com/oliverbestmann/webgpu/wgpu"
)

// Native checks require explicit admission. Ordinary offscreen tests never open
// a GPU device, change desktop settings, or silently skip an admitted failure.
func nativeDevice(t *testing.T) (*gpu.GPU, *gpu.Device) {
	t.Helper()
	if os.Getenv("VELLUM_GPU_SCENE_TEST") != "1" {
		t.Skip("explicit native GPU admission required")
	}
	gp, dev, err := gpu.NoDisplayGPU()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { dev.Release(); gp.Release() })
	return gp, dev
}
func readTexture(t *testing.T, dev *gpu.Device, tx *gpu.Texture) *image.RGBA {
	t.Helper()
	stride, n, ok := outputLayout(tx.Format.Size)
	if !ok {
		t.Fatal("invalid readback layout")
	}
	buffer, err := dev.Device.TryCreateBuffer(&wgpu.BufferDescriptor{Size: n, Usage: wgpu.BufferUsageCopyDst | wgpu.BufferUsageMapRead})
	if err != nil {
		t.Fatal(err)
	}
	defer buffer.Release()
	encoder, err := dev.Device.TryCreateCommandEncoder(nil)
	if err != nil {
		t.Fatal(err)
	}
	defer encoder.Release()
	if err = tx.CopyToBuffer(encoder, buffer, stride); err != nil {
		t.Fatal(err)
	}
	command, err := encoder.TryFinish(nil)
	if err != nil {
		t.Fatal(err)
	}
	defer command.Release()
	dev.Queue.Submit(command)
	status := make(chan wgpu.MapAsyncStatus, 1)
	if err = buffer.TryMapAsync(wgpu.MapModeRead, 0, n, func(s wgpu.MapAsyncStatus) { status <- s }); err != nil {
		t.Fatal(err)
	}
	dev.Device.Poll(true, nil)
	select {
	case s := <-status:
		if s != wgpu.MapAsyncStatusSuccess {
			t.Fatal("native map failed", s)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("native readback timed out")
	}
	raw := buffer.GetMappedRange(0, uint(n))
	out := image.NewRGBA(image.Rectangle{Max: tx.Format.Size})
	for y := 0; y < out.Rect.Dy(); y++ {
		copy(out.Pix[y*out.Stride:], raw[uint32(y)*stride:][:out.Stride])
	}
	if err = buffer.TryUnmap(); err != nil {
		t.Fatal(err)
	}
	return out
}
func TestVellumGPUSceneNativeIntegerCompositor(t *testing.T) {
	_, dev := nativeDevice(t)
	random := rand.New(rand.NewSource(481))
	for _, size := range []image.Point{{23, 19}, {257, 3}, {64, 32}} {
		t.Run(fmt.Sprint(size), func(t *testing.T) {
			res := &resources{}
			defer res.release()
			reserve := func(n uint64) error {
				if n > 128<<20 {
					return fmt.Errorf("test source budget exceeded")
				}
				return nil
			}
			if err := res.initialize(dev, size, reserve); err != nil {
				t.Fatal(err)
			}
			expected := image.NewRGBA(image.Rectangle{Max: size})
			random.Read(expected.Pix)
			if err := res.seed(expected); err != nil {
				t.Fatal(err)
			}
			for batch := 0; batch < 32; batch++ {
				b := sceneplan.New(expected.Rect)
				if batch%8 == 0 {
					b.Draw(expected.Rect, image.NewUniform(color.RGBA{13, 31, 59, 255}), image.Point{}, nil, image.Point{}, draw.Src)
				}
				for step := 0; step < 9; step++ {
					rect := image.Rect(random.Intn(size.X+4)-2, random.Intn(size.Y+4)-2, random.Intn(size.X+3)+1, random.Intn(size.Y+3)+1)
					if rect.Empty() {
						rect = expected.Rect
					}
					op := draw.Op(step % 2)
					c := image.NewUniform(color.NRGBA64{uint16(random.Uint32()), uint16(random.Uint32()), uint16(random.Uint32()), uint16(random.Uint32())})
					mask := image.NewAlpha(image.Rect(-1, -2, size.X+3, size.Y+4))
					random.Read(mask.Pix)
					pixels := image.NewRGBA(image.Rect(-2, -1, size.X+4, size.Y+3))
					random.Read(pixels.Pix)
					switch step % 3 {
					case 0:
						b.Draw(rect, c, image.Point{}, nil, image.Point{}, op)
					case 1:
						b.Draw(rect, c, image.Point{}, mask, image.Pt(-1, -1), op)
					case 2:
						b.Draw(rect, pixels, image.Pt(-1, -1), mask, image.Pt(0, -1), op)
					}
					b.BeginSpans(color.RGBA{13, 29, 51, 77}, op)
					y := random.Intn(size.Y)
					// Cover overlapping span order and 16-bit edge values.
					for j, a := range []uint32{0, 1, 257, 32768, 65534, 65535} {
						b.Span(y, j, min(size.X, j+7), a)
					}
					// Exercise both ends, gaps and band relocation in one stream.
					b.Span(size.Y-1, 0, size.X, 32768)
					b.Span(0, 1, size.X, 65535)
					b.Span(size.Y/2, 0, size.X-1, 257)
				}
				packet := b.Seal(false)
				if packet == nil {
					t.Fatal("native fixture refused", batch)
				}
				encoded, ok := packet.EncodeGPU()
				if !ok {
					t.Fatal("native fixture encoding refused")
				}
				if err := res.render(encoded, reserve); err != nil {
					t.Fatal(err)
				}
				packet.Replay(expected)
				got := readTexture(t, dev, res.texture)
				if !bytes.Equal(got.Pix, expected.Pix) {
					for i, v := range expected.Pix {
						if got.Pix[i] != v {
							t.Fatalf("exact integer mismatch batch=%d byte=%d GPU=%d CPU=%d", batch, i, got.Pix[i], v)
						}
					}
				}
			}
		})
	}
}

func TestVellumGPUSceneNativeSharedDrawerOrderAndFallback(t *testing.T) {
	gp, dev := nativeDevice(t)
	size := image.Pt(61, 43)
	makeDrawer := func() (*gpudraw.Drawer, *gpu.RenderTexture) {
		rt := gpu.NewRenderTexture(gp, dev, size, 1, gpu.UndefinedType)
		dw := gpudraw.NewDrawer(gp, rt)
		t.Cleanup(func() { dw.Release(); rt.Release() })
		return dw, rt
	}
	dw, target := makeDrawer()
	reference, refTarget := makeDrawer()
	r := New(math32.Vec2(23, 19)).(*Renderer)
	defer r.Release()
	expected := rasterx.New(math32.Vec2(23, 19)).(*rasterx.Renderer)
	clearSource := func(c color.RGBA) render.Render {
		return render.Render{&pimage.Params{Cmd: pimage.Draw, Source: image.NewUniform(c), Op: draw.Src}}
	}
	background := image.NewUniform(color.RGBA{37, 79, 113, 255})
	later := image.NewUniform(color.RGBA{11, 23, 41, 83})
	renderFrame := func(commands render.Render, measured bool) {
		dw.Start()
		reference.Start()
		dw.Copy(image.Point{}, background, image.Rectangle{Max: size}, draw.Src, false)
		reference.Copy(image.Point{}, background, image.Rectangle{Max: size}, draw.Src, false)
		record := r.DrawScene(dw, commands, image.Pt(7, 5), draw.Over, measured)
		if len(commands) != 0 {
			expected.Render(commands)
		}
		reference.Copy(image.Pt(7, 5), expected.Image(), expected.Image().Bounds(), draw.Over, false)
		// A later scrim-like sibling remains after this source in both batches.
		dw.Copy(image.Point{}, later, image.Rect(12, 8, 40, 35), draw.Over, false)
		reference.Copy(image.Point{}, later, image.Rect(12, 8, 40, 35), draw.Over, false)
		dw.End()
		reference.End()
		got, want := readTexture(t, dev, target.CurrentFrame()), readTexture(t, dev, refTarget.CurrentFrame())
		if !bytes.Equal(got.Pix, want.Pix) {
			t.Fatal("shared-device ordered composition differs", r.Stats())
		}
		if r.Stats().CPUFallbacks == 0 && (record.RasterAvailable || record.CopyAvailable) {
			t.Fatal("GPU path claims CPU raster/copy or completion timings")
		}
	}
	renderFrame(clearSource(color.RGBA{23, 47, 71, 139}), false)
	if dw.CanRedraw() {
		t.Fatal("borrowed GPU source was admitted for cached replay")
	}
	if r.Stats().Submitted != 1 || r.Stats().CPUFallbacks != 0 || r.resources.device.Device != dw.System.Device().Device || r.imageExposed || len(r.journal) != 1 {
		t.Fatal("main route did not use deferred same-device GPU paint", r.Stats())
	}
	renderFrame(nil, true)
	if r.Stats().Reused != 1 {
		t.Fatal("unchanged source did not reuse")
	}
	partial := render.Render{&pimage.Params{Cmd: pimage.Draw, Rect: image.Rect(3, 4, 17, 15), Source: image.NewUniform(color.RGBA{11, 29, 59, 103}), Op: draw.Over}}
	renderFrame(partial, true)
	// Unknown paint must reconstruct old accepted history before normal render.
	unknown := &nativeUnknownImage{Image: image.NewUniform(color.RGBA{7, 13, 31, 83})}
	renderFrame(render.Render{&pimage.Params{Cmd: pimage.Draw, Rect: image.Rect(5, 1, 19, 13), Source: unknown, Op: draw.Over}}, false)
	if r.Stats().CPUFallbacks != 1 || len(r.journal) != 0 {
		t.Fatal("unsupported batch did not reconstruct fallback", r.Stats())
	}
	renderFrame(partial, false)
	if r.Stats().Submitted != 3 {
		t.Fatal("accepted packet did not recover after fallback", r.Stats())
	}
	// Retained mutable snapshot stays current and authoritative across GPU paint.
	exposed := r.Image().(*image.RGBA)
	if !bytes.Equal(exposed.Pix, expected.Image().(*image.RGBA).Pix) {
		t.Fatal("snapshot differs")
	}
	exposed.SetRGBA(0, 0, color.RGBA{101, 127, 151, 173})
	expected.Image().(*image.RGBA).SetRGBA(0, 0, color.RGBA{101, 127, 151, 173})
	renderFrame(partial, false)
	if !bytes.Equal(exposed.Pix, expected.Image().(*image.RGBA).Pix) {
		t.Fatal("retained snapshot stopped updating")
	}
	exposed.SetRGBA(1, 1, color.RGBA{31, 43, 53, 255})
	expected.Image().(*image.RGBA).SetRGBA(1, 1, color.RGBA{31, 43, 53, 255})
	renderFrame(nil, false)
	if r.Stats().CPUFallbacks != 2 {
		t.Fatal("empty exposed image reused stale texture", r.Stats())
	}
	if !dw.CanRedraw() {
		t.Fatal("later owned CPU batch was refused for cached replay")
	}
	r.SetSize(units.UnitDot, math32.Vec2(31, 27))
	expected.SetSize(units.UnitDot, math32.Vec2(31, 27))
	if r.imageExposed {
		t.Fatal("resize retained mutable exposure from retired image")
	}
	renderFrame(clearSource(color.RGBA{31, 47, 59, 113}), false)
	if r.Stats().CPUFallbacks != 2 || len(r.journal) != 1 {
		t.Fatal("resize did not restart deferred GPU paint", r.Stats())
	}
	if err := r.lease.WithResources(func(ctx *gpudraw.SceneGPUContext) error {
		if r.resources.device.Device != ctx.Device.Device {
			return fmt.Errorf("drawer device identity mismatch")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	r.Release()
	if budget, err := dw.SceneSourceBudget(); err != nil || budget.Sources != 0 || budget.Bytes != 0 {
		t.Fatal("source retirement retained resources", budget)
	}
}

type nativeUnknownImage struct{ image.Image }

func TestVellumGPUSceneNativeActualTextAndPaths(t *testing.T) {
	_, dev := nativeDevice(t)
	size := image.Pt(240, 80)
	res := &resources{}
	defer res.release()
	reserve := func(n uint64) error {
		if n > 128<<20 {
			return fmt.Errorf("test budget")
		}
		return nil
	}
	if err := res.initialize(dev, size, reserve); err != nil {
		t.Fatal(err)
	}
	rs := rasterx.New(math32.FromPoint(size)).(*rasterx.Renderer)
	shaper := shapedgt.NewShaperWithFonts([]fs.FS{fonts.Default})
	uc := units.Context{}
	uc.Defaults()
	ts := text.NewStyle()
	ts.FontSize = units.Dot(24)
	ts.WhiteSpace = text.WrapNever
	ts.ToDots(&uc)
	source := rich.NewText(rich.NewStyle(), []rune("Ag é שלום"))
	runs := shaper.Shape(source, ts)
	if len(runs) == 0 {
		t.Fatal("default outline text missing")
	}
	for _, transform := range []math32.Matrix2{math32.Identity2(), math32.Translate2D(2, 1).Scale(.9, .9)} {
		for repeat := 0; repeat < 2; repeat++ {
			lines := &shaped.Lines{Source: source, Color: color.NRGBA{20, 40, 100, 230}, Lines: []shaped.Line{{Runs: runs, Offset: math32.Vec2(0, 30), Selections: []textpos.Range{{Start: 1, End: 5}}}}, SelectionColor: image.NewUniform(color.NRGBA{30, 80, 20, 100})}
			ctx := &render.Context{}
			ctx.Init(styles.NewPaint(), &render.Bounds{Rect: math32.B2FromRect(image.Rectangle{Max: size})}, nil)
			txt := render.NewText(lines, styles.NewPaint(), ctx, math32.Vec2(7.25, 2.5))
			txt.Context.Cumulative = transform
			path := ppath.New()
			path.MoveTo(150.25, 13.5)
			path.CubeTo(174.75, 4.5, 192.25, 49.5, 211.5, 37.25)
			path.LineTo(164.25, 51.75)
			path.Close()
			sty := styles.NewPaint()
			sty.Fill.Color = image.NewUniform(color.RGBA{41, 13, 29, 83})
			sty.Stroke.Color = image.NewUniform(color.RGBA{7, 17, 29, 103})
			sty.Stroke.Width = units.Dot(2.5)
			sty.UnitContext = uc
			sty.ToDots()
			pathCtx := &render.Context{}
			pathCtx.Init(sty, &render.Bounds{Rect: math32.B2FromRect(image.Rect(147, 8, 218, 57))}, nil)
			pathCtx.Cumulative = transform
			pt := &render.Path{Path: *path, Context: *pathCtx}
			icon := image.NewRGBA(image.Rect(0, 0, 7, 9))
			draw.Draw(icon, icon.Rect, image.NewUniform(color.NRGBA{180, 20, 30, 180}), image.Point{}, draw.Src)
			commands := render.Render{&pimage.Params{Cmd: pimage.Draw, Rect: image.Rectangle{Max: size}, Source: image.NewUniform(color.RGBA{19, 37, 61, 255}), Op: draw.Src}, pt, txt, pimage.NewDraw(image.Rect(226, 10, 233, 19), icon, nil, image.Point{}, draw.Over)}
			packet := rs.ScenePacket(commands)
			if packet == nil {
				t.Fatal("real outline/path scene refused", transform, repeat)
			}
			encoded, ok := packet.EncodeGPU()
			if !ok {
				t.Fatal("real scene encoding refused")
			}
			warmPacket := rs.ScenePacket(commands)
			if warmPacket == nil {
				t.Fatal("cache warmth changed real scene admission")
			}
			warmEncoded, warmOK := warmPacket.EncodeGPU()
			if !warmOK || !reflect.DeepEqual(encoded, warmEncoded) {
				t.Fatal("cold/warm real scene encoded bytes differ")
			}
			// Submit the warm-cache packet to the actual native compute path.
			encoded = warmEncoded
			if err := res.render(encoded, reserve); err != nil {
				t.Fatal(err)
			}
			rs.Render(commands)
			got := readTexture(t, dev, res.texture)
			if !bytes.Equal(got.Pix, rs.Image().(*image.RGBA).Pix) {
				t.Fatal("actual path/text/selection/icon native bytes differ", transform, repeat)
			}
		}
	}
}

func TestVellumGPUSceneNativeCoveredUniforms(t *testing.T) {
	_, dev := nativeDevice(t)
	size := image.Pt(35, 33)
	res := &resources{}
	defer res.release()
	reserve := func(n uint64) error {
		if n > 128<<20 {
			return fmt.Errorf("test budget")
		}
		return nil
	}
	if err := res.initialize(dev, size, reserve); err != nil {
		t.Fatal(err)
	}
	want := image.NewRGBA(image.Rectangle{Max: size})
	for frame := 0; frame < 12; frame++ {
		b := sceneplan.New(want.Rect)
		rect := image.Rect(frame%7, frame%5, 27, 29)
		if frame == 0 {
			rect = want.Rect
		}
		b.Draw(rect, image.NewUniform(color.RGBA{1, 3, 5, 7}), image.Point{}, nil, image.Point{}, draw.Src)
		b.Draw(rect, image.NewUniform(color.NRGBA64{333, 1777, 6333, 65535}), image.Point{}, nil, image.Point{}, draw.Over)
		b.BeginSpans(color.RGBA{13, 19, 31, 71}, draw.Over)
		b.Span(2, 0, 31, 32767)
		p := b.Seal(frame%2 == 0)
		if p == nil {
			t.Fatal("fixture refused")
		}
		original, ok := p.Encode()
		if !ok {
			t.Fatal("original encoding refused")
		}
		encoded, ok := p.EncodeGPU()
		if !ok || len(encoded.Ops) != len(original.Ops)-64 {
			t.Fatal("covered pair was not compacted")
		}
		if err := res.render(encoded, reserve); err != nil {
			t.Fatal(err)
		}
		p.Replay(want)
		got := readTexture(t, dev, res.texture)
		if !bytes.Equal(got.Pix, want.Pix) {
			t.Fatal("native compacted partial output differs", frame)
		}
	}
}
