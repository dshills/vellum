from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-gpu-covered')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
prepared=json.loads((P/'prepared-final.json').read_text());base=json.loads((P/'prepared-baseline.json').read_text());assert len(prepared)==6208
checks={};code={}
for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()+subprocess.check_output(['git','diff','--name-only'],cwd=R).decode().splitlines():
 if n.startswith('drivers/'):code[n]=sha(R/n)
assert len(code)==6
for name in ['final-prepare-v2','final-renderer-race','final-renderer-vet','final-adapter-race','final-adapter-vet','final-native-contracts','final-native-build','final-native-vet','final-portable-race','final-preparation-tests']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_delta_stable']and not d['live_tests']and not d['headless_gpu_requested'];assert d['prepared_after']==prepared and d['prepared_before']==(base if name=='final-prepare-v2'else prepared);assert all(d['source_delta_after'][n]==h for n,h in code.items());assert d['overlay_inputs_before']==d['overlay_inputs_after']=={}
 for channel in ['stdout','stderr']:assert sha(P/(name+'.'+channel))==d[channel+'_sha256']
 checks[name]={'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'argv':d['argv'],'receipt_sha256':sha(P/(name+'.json'))}
build=json.loads((P/'final-native-build.json').read_text());assert not build['binary_launched']and sha(Path(build['produced_file']))==build['executable_sha256'];assert Path(build['produced_file']).stat().st_size==build['produced_file_bytes']
# Make final report wording match completed, scoped gates before binding review.
f=R/'docs/reports/macos-gpu-covered/README.md';s=f.read_text().replace('Final renderer race/vet, adapter offscreen race/vet, portable race,\npreparation tests and native build must pass. Internal source/evidence review and\none bounded Prism review using Anthropic Claude Sonnet 5.5 precede commit.','Final renderer race/vet, adapter offscreen race/vet, portable race, preparation\ntests, native harness contract tests/vet and native build pass. Internal\nsource/evidence review and one bounded Prism review using Anthropic Claude Sonnet\n5.5 precede commit.');f.write_text(s)
names=sorted(set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()+subprocess.check_output(['git','diff','--name-only'],cwd=R).decode().splitlines()));assert len(names)==9
sources={n:sha(R/n)for n in names};(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources},indent=2)+'\n')
summary={'result':'PASS_SCOPED_COVERED_GPU_ENCODING','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources,'checks':checks,'prepared_before_files':6207,'prepared_after_files':6208,'four_reviewed_outputs_exact':True,'all_other_dependency_leaves_unchanged':True,'software_grid_frames_equal':48,'negative_controls':3,'native_build_sha256':build['executable_sha256'],'native_build_bytes':build['produced_file_bytes'],'native_build_launched':False,'live_checks_run':False,'native_gpu_checks_run':False,'native_performance_gain_qualified':False,'physical_memory_gain_qualified':False,'gpu_default_enabled':False,'full_p6_qualified':False,'full_p11_qualified':False};(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS final10checks;9source/spec/report files bound;no native/live/performance qualification')
