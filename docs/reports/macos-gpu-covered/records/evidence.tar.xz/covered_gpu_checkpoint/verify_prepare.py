from pathlib import Path
import hashlib,json
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-gpu-covered')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
base=json.loads((P/'prepared-baseline.json').read_text());actual={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};ad=json.loads((P/'adoption-inputs.json').read_text());expect=dict(base);expect.update({'upstream/'+n:h for n,h in ad['outputs'].items()});assert len(actual)==6208 and actual==expect
run=json.loads((P/'final-prepare-v2.json').read_text());assert run['exit_code']==0 and run['error']is None and run['source_delta_stable']and run['prepared_before']==base and run['prepared_after']==actual
(P/'prepared-final.json').write_text(json.dumps(actual,indent=2)+'\n');(P/'preparation-comparison.json').write_text(json.dumps({'result':'PASS_EXACT_OWNED_STAGE57','before_files':6207,'after_files':6208,'four_outputs_exact':True,'all_other_dependency_leaves_unchanged':True,'patch_sha256':ad['patch_sha256'],'live_checks_run':False},indent=2)+'\n');print('PASS normal preparation:four exactoutputs,6207to6208,all others unchanged')
