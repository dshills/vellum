from pathlib import Path
import json
P=Path('/private/tmp/vellum-macos-gpu-covered');R=Path('/private/tmp/vellum-large-data');U=R/'drivers/cogent/build/upstream'
o=json.loads((P/'candidate-overlay.json').read_text())
s=(P/'packet.go').read_text()
for name,old,new in [('alpha','b.color[3] == 65535','b.color[3] > 0'),('index','e.Refs[positions[bin]*4:], encodedIndex','e.Refs[positions[bin]*4:], uint32(i)'),('budget','refs++','if keep { refs++ }')]:
 assert s.count(old)==1,(name,s.count(old));f=P/('fault-'+name+'.go');f.write_text(s.replace(old,new));d=json.loads(json.dumps(o));d['Replace'][str(U/'paint/renderers/sceneplan/packet.go')]=str(f);(P/('fault-'+name+'-overlay.json')).write_text(json.dumps(d,indent=2)+'\n')
# No profile/timing claim: this matrix captures actual adapter paint commands and
# compares serialized execution to original CPU pixels, plus full composition.
s=Path('/private/tmp/vellum-macos-render-probe/grid_matrix_test.go').read_text().replace('TestCoverageActualGridMatrix','TestCoveredGPUActualGridMatrix')
s=s.replace('"crypto/sha256"','"crypto/sha256"\n "bytes"\n "encoding/binary"\n "cogentcore.org/core/paint/render"\n "cogentcore.org/core/paint/renderers/rasterx"\n "cogentcore.org/core/paint/renderers/sceneplan"')
s=s.replace('for frame,step:=range', '''var probe *coveredGridProbe
   if err=a.Do(func(){sc:=manual.implementation.find("one").state.body.Scene;probe=&coveredGridProbe{Renderer:sc.Renderer};sc.Renderer=probe});err!=nil{t.Fatal(err)}
   for frame,step:=range''')
s=s.replace('records=append(records,map[string]any{', '''if len(probe.last)==0 {t.Fatal("actual paint batch missing")}
    seed:=probe.Renderer.Image().(*image.RGBA);rs:=rasterx.New(math32.FromPoint(seed.Rect.Size())).(*rasterx.Renderer)
    rs.Render(probe.last);packet:=rs.ScenePacket(probe.last);if packet==nil{t.Fatal("actual batch refused")}
    original,ok:=packet.Encode();if !ok{t.Fatal("original encoded batch refused")};compact,ok:=packet.EncodeGPU();if !ok{t.Fatal("compact encoded batch refused")}
    got:=image.NewRGBA(seed.Rect);replayCoveredGridGPU(t,compact,got);if !bytes.Equal(got.Pix,rs.Image().(*image.RGBA).Pix){t.Fatal("serialized GPU batch differs from actual CPU raster")}
    records=append(records,map[string]any{"original_encoded_ops":len(original.Ops)/64,"compact_encoded_ops":len(compact.Ops)/64,"original_encoded_bytes":len(original.Ops)+len(original.Rows)+len(original.Refs)+len(original.Data),"compact_encoded_bytes":len(compact.Ops)+len(compact.Rows)+len(compact.Refs)+len(compact.Data),"batch_commands":len(probe.last),"batch_pixels_sha256":fmt.Sprintf("%x",sha256.Sum256(got.Pix)),''')
s=s.replace('/private/tmp/vellum-macos-render-probe/MATRIX_NAME.json',str(P/'actual-matrix-pixels.json'))
helper=(P/'covered_encoding_test.go').read_text();decoder=helper[helper.index('func replayEncodedGPU'):helper.index('func TestVellumScenePlanGPUCoveredMixedOracle')];decoder=decoder.replace('replayEncodedGPU','replayCoveredGridGPU').replace('*Encoded','*sceneplan.Encoded').replace('TileSize','sceneplan.TileSize').replace('opWords','16').replace('kind == Spans','kind == sceneplan.Spans').replace('kind == Pixels','kind == sceneplan.Pixels')
s+='\ntype coveredGridProbe struct{render.Renderer;last render.Render}\nfunc(p *coveredGridProbe) Render(r render.Render)render.Renderer{p.last=r.Clone();p.Renderer.Render(r);return p}\n'+decoder
f=P/'actual_matrix_test.go';f.write_text(s);o['Replace'][str(R/'drivers/cogent/covered_gpu_matrix_test.go')]=str(f);(P/'matrix-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
# Native regression is compiled now and deliberately left unexecuted until the
# human authorizes another quiet machine window.
f=U/'paint/renderers/gpuscene/native_test.go';s=f.read_text().replace('packet.Encode()','packet.EncodeGPU()').replace('warmPacket.Encode()','warmPacket.EncodeGPU()')
s+='''
func TestVellumGPUSceneNativeCoveredUniforms(t *testing.T) {
 _,dev:=nativeDevice(t)
 size:=image.Pt(35,33);res:=&resources{};defer res.release()
 reserve:=func(n uint64)error{if n>128<<20{return fmt.Errorf("test budget")};return nil}
 if err:=res.initialize(dev,size,reserve);err!=nil{t.Fatal(err)}
 want:=image.NewRGBA(image.Rectangle{Max:size})
 for frame:=0;frame<12;frame++ {
  b:=sceneplan.New(want.Rect)
  rect:=image.Rect(frame%7,frame%5,27,29)
  if frame==0{rect=want.Rect}
  b.Draw(rect,image.NewUniform(color.RGBA{1,3,5,7}),image.Point{},nil,image.Point{},draw.Src)
  b.Draw(rect,image.NewUniform(color.NRGBA64{333,1777,6333,65535}),image.Point{},nil,image.Point{},draw.Over)
  b.BeginSpans(color.RGBA{13,19,31,71},draw.Over);b.Span(2,0,31,32767)
  p:=b.Seal(frame%2==0);if p==nil{t.Fatal("fixture refused")}
  original,ok:=p.Encode();if !ok{t.Fatal("original encoding refused")};encoded,ok:=p.EncodeGPU()
  if !ok||len(encoded.Ops)!=len(original.Ops)-64{t.Fatal("covered pair was not compacted")}
  if err:=res.render(encoded,reserve);err!=nil{t.Fatal(err)}
  p.Replay(want);got:=readTexture(t,dev,res.texture)
  if !bytes.Equal(got.Pix,want.Pix){t.Fatal("native compacted partial output differs",frame)}
 }
}
'''
(P/'native_test.go').write_text(s)
o=json.loads((P/'candidate-overlay.json').read_text());o['Replace'][str(f)]=str(P/'native_test.go');(P/'candidate-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
print('Three faulty variants, actual-source48frame matrix and gated native regression created')
