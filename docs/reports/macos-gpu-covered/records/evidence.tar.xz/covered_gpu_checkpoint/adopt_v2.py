from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-gpu-covered');D=R/'drivers/cogent/native/patches/gpucovered'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
o=json.loads((P/'candidate-overlay.json').read_text())['Replace'];assert len(o)==4
check=json.loads((P/'candidate-race-v1.json').read_text());assert check['exit_code']==0 and check['overlay_inputs_before']==check['overlay_inputs_after'] and all(sha(f)==check['overlay_inputs_after'][str(f)]for f in o.values())
# Internal review covers the candidate now and must approve final source/evidence
# before provider review and commit; preparation is an authorized reversible edit.
matrix=json.loads((P/'matrix-summary-final.json').read_text());assert matrix['frames']==48 and matrix['current_full_composition_pixels_equal_serialized_compact'] and matrix['negative_controls']==3
baseline=json.loads((P/'prepared-baseline.json').read_text());assert len(baseline)==6207
inputs={};outputs={};chunks=[]
for target,source in o.items():
 t=Path(target);s=Path(source);rel=t.relative_to(R/'drivers/cogent/build/upstream').as_posix();old=t.read_text()if t.exists()else'';new=s.read_text();inputs[rel]=sha(t)if t.exists()else None;outputs[rel]=sha(s)
 chunks.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if t.exists()else'/dev/null',tofile='b/'+rel,n=3))
D.mkdir(exist_ok=False);patch=D/'0057-covered-uniform-gpu-encoding.patch';patch.write_text(''.join(chunks))
for name,data in [('original-hashes',inputs),('output-hashes',outputs)]: (D/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
manifest=R/'drivers/cogent/native/dependencies.json';d=json.loads(manifest.read_text());core=d['dependencies'][0];assert len(core['stages'])==56
core['stages'].append({'origin':'drivers/cogent/native/patches/gpucovered','inputs':'native/patches/gpucovered/original-hashes.json','outputs':'native/patches/gpucovered/output-hashes.json','patches':[{'file':'native/patches/gpucovered/'+patch.name,'sha256':sha(patch)}]});manifest.write_text(json.dumps(d,indent=2)+'\n')
test=R/'drivers/cogent/prepare_test.py';s=test.read_text();assert s.count('list(range(1, 57))')==1;test.write_text(s.replace('list(range(1, 57))','list(range(1, 58))'))
(D/'README.md').write_text('''# Covered uniform GPU encoding

Owned patch 0057 adds Packet.EncodeGPU and uses it in the opt-in GPU scene
adapter. It omits only an owned Uniform Src immediately followed by an equal
clipped-rectangle Uniform Over with 16-bit alpha 65535. The packet still retains
every original operation; all Builder validation, byte charges, original encoded
operation/byte/tile-reference admission, CPU reconstruction and independent-reset
proof remain unchanged. Compacted output owns exact operation IDs and tile lists.
Packet.Encode preserves the original ABI bytes and frozen digest tests.

Independent mixed-stream and tile-outer scalar execution compare serialized output
against original replay. Tests cover masks/pixels/spans, clipping, alpha 65534,
interrupted/unequal rectangles, detached results and original limit boundaries.
Three deliberately faulty overlays fail the alpha, index and refusal assertions.
The actual-driver software matrix compares all pixels in 48 full compositions
across four DPI settings, fixed/variable rows and mixed-axis scrolling. It reduces
193–477 encoded operations and 132,000–216,684 bytes per frame in this fixture.

Existing gated native integer/text regressions use the compact route, and a new
12-frame native test checks full and partial covered fills. These compile but
remain unexecuted while the human uses the machine. No native GPU/latency or
full Mac qualification is inferred. GPU scene rendering remains opt-in.

New tests are MIT; modified upstream files preserve their original notices.
Preparation validates original/output hashes and patch SHA256.
''')
spec=R/'specs/rendering.md';spec.write_text(spec.read_text()+'''

## Covered uniform GPU encoding

The opt-in GPU adapter calls Packet.EncodeGPU. Only a detached Uniform Src
immediately followed by an opaque Uniform Over with the same clipped rectangle
may be omitted from the encoding. All original commands have already passed
Builder validation and snapshotting. Encoding charges the original operation
count, encoded bytes and tile references before allocating compacted output;
compaction cannot revive an originally refused batch. Retained tile rows and
operation IDs describe the emitted stream exactly. Packet operations, Bytes,
Independent, Winding and CPU Replay are unchanged. Packet.Encode retains original
bytes for comparison and other callers.

Scalar tile-outer execution of the serialized ABI checks exact mixed image, mask,
span and uniform pixels. Actual-driver software capture compares 48 complete
composition frames at DPI 96/120/144/192, fixed/variable rows and mixed-axis scroll.
The 400-cell frame removes 417 operations and 149,184 bytes; all frames remove
193–477 operations. These are work/payload reductions, not native frame timings.
Native compute and paired representative latency must be rerun during an
explicit quiet-machine window before this can qualify the unchanged 4/6 ms
targets. See [the scoped report](../docs/reports/macos-gpu-covered/README.md).
''')
mac=R/'specs/macos-completion.md';mac.write_text(mac.read_text()+'''

The owned stage-57 GPU encoder removes validated covered uniform clears while
preserving original admission and packet reconstruction. A 48-frame actual-driver
software matrix matches every full-composition pixel and removes 193–477 encoded
operations per frame. Original limit boundaries, frozen Encode digests, serialized
tile order, detached results and three faulty variants are checked. Gated native
integer/text tests now exercise the compact route, with a dedicated partial-frame
regression; they compile but have not run while the human uses the machine.
This does not qualify native GPU pixels, timing or memory. GPU rendering remains
opt-in, original P6 frame targets still fail, and full P6/P11, fresh complete
retention, physical input/displays, human accessibility and distribution remain
open. [Scoped evidence](../docs/reports/macos-gpu-covered/README.md).
''')
report=R/'docs/reports/macos-gpu-covered';report.mkdir(exist_ok=False);(report/'records').mkdir()
(report/'README.md').write_text('''# Covered uniform GPU encoding

Owned stage 57 preserves the original packet and Builder while omitting covered
uniform Src operations only from the opt-in GPU encoding. An immediately following
opaque uniform Over with the same owned clipped rectangle replaces every affected
pixel. All original operation, byte and tile-reference charges run before output
allocation. CPU reconstruction, packet byte accounting, reset proof and original
Encode bytes stay unchanged. The GPU stream owns compact IDs and tile lists.

## Evidence and limits

A 48-frame current-driver software matrix captures actual procedural 10,000-row
grid paint batches with fixed/variable rows, DPI 96/120/144/192 and six mixed-axis
scroll steps. Scalar execution of the serialized compact GPU ABI matches original
CPU raster and every full-composition pixel. Prior full-composition records also
match. This is an offscreen procedural fixture, not stored-data/native acceptance.
The first 400-cell frame reduces 4,397 → 3,980 encoded operations and 1,688,088 →
1,538,904 bytes. Across all frames it removes 193–477 operations and
132,000–216,684 bytes. Host/native frame times and GPU allocation were not measured.

Focused tests compare original Encode to an independently marked mixed stream,
including masks, pixels and ordered 16-bit spans. They cover clipped/default/full
rectangles, partial alpha, interruptions, unequal rectangles, detached encoding,
held packet state and original retained/encoded byte, operation and tile-reference
limits. Existing original frozen digests remain unchanged. Three faulty overlays
fail the alpha, compact index and original-reference refusal assertions.

Existing gated native integer/text tests switch to EncodeGPU; a new 12-frame
regression checks full and partial covered fills on native compute. They compile
but are deliberately unexecuted while the human uses the computer. No GPU device,
window, input event, preference or clipboard is touched by this checkpoint.
The first matrix failed compilation due to a missing image/draw import; the fixed
V2 and original failure are preserved with their bound source receipts.

Normal preparation must reproduce four reviewed outputs through all 57 patch
numbers, adding one test leaf (6,207 → 6,208) with every other dependency leaf
unchanged. Final renderer race/vet, adapter offscreen race/vet, portable race,
preparation tests and native build must pass. Internal source/evidence review and
one bounded Prism review using Anthropic Claude Sonnet 5.5 precede commit.
Producers, overlays, failures, comparisons and review records are retained in the
indexed records archive; native binaries are excluded with their hash retained.

GPU scene rendering stays opt-in. Native 4 ms p95 / 6 ms p99 targets still fail;
full P6/P11, a fresh complete lifecycle campaign (prior run failed after 343
windows), physical input/displays, human screen-reader work, native/GPU memory and
Mac distribution remain open. Live tests are paused while the human uses the host.
''')
(P/'adoption-inputs.json').write_text(json.dumps({'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'patch_sha256':sha(patch),'inputs':inputs,'outputs':outputs,'overlay_mapping':o,'prepared_before_files':6207,'expected_prepared_after_files':6208},indent=2)+'\n')
print('Owned stage57 created with four reviewed outputs and pinned preparation')
