"""Revalidate every ordinary raw run and retain paired and per-run variation."""
from pathlib import Path
import json
import native_common as c
from payloads import selected,events,benchmark
P=c.P
def main():
 queue=c.read(P/'queue/terminal.json');c.need(queue['result']=='COMPLETED_APPROVED_SEQUENCE'and len(queue['steps'])==166,'all native runs and validators complete')
 validator=c.load('final_raw_validator',P/'validate_native.py')
 runs={};proofs={}
 for case in c.ORDER:
  # Validation root is explicitly bound to each case even in this pure process.
  original=c.R;c.R=c.BASE if c.CASES[case]['target']=='baselinegrid'else c.CANDIDATE
  try:c.need(validator.validate(case)==c.read(P/(case+'-validation.json')),'saved raw validation '+case)
  finally:c.R=original
  cfg=c.CASES[case];proofs[case]=c.sha(P/(case+'-validation.json'))
  if cfg['kind']!='ordinary':continue
  commit=c.read(P/'binaries.json')['outputs'][cfg['target']]['commit']
  samples=selected(events((P/(case+'.stdout')).read_text()),cfg,commit)
  group=f'{"gpu"if cfg["gpu_scene"]else"cpu"}-{ "variable"if cfg["variable"]else"fixed"}-{cfg["rows"]}'
  runs.setdefault(group,{}).setdefault(cfg['arm'],[]).append(samples)
 summaries={};pairs={}
 for group,arms in runs.items():
  c.need(set(arms)=={'baseline','candidate'}and all(len(x)==5 for x in arms.values()),'five complete pairs')
  for a,b in zip(arms['baseline'],arms['candidate']):
   benchmark.compare_geometry(a,b);c.need(all(x['geometry']==y['geometry']for x,y in zip(a,b)),'full paired geometry')
  summaries[group]={arm:dict(timings_ns=benchmark.summarize(values),go_process_alloc_bytes=benchmark.distribution([s['go_process_alloc_bytes']for run in values for s in run]),go_process_mallocs=benchmark.distribution([s['go_process_mallocs']for run in values for s in run]))for arm,values in arms.items()}
  pairs[group]=[dict(pair=i+1,baseline_ui_p95_ns=benchmark.distribution([s['metrics']['ui_work_ns']for s in a])['p95'],candidate_ui_p95_ns=benchmark.distribution([s['metrics']['ui_work_ns']for s in b])['p95'])for i,(a,b)in enumerate(zip(arms['baseline'],arms['candidate']))]
 for gpu in ['cpu','gpu']:
  for height in ['fixed','variable']:
   for arm in ['baseline','candidate']:
    for small,large in zip(runs[f'{gpu}-{height}-10000'][arm],runs[f'{gpu}-{height}-1000000'][arm]):benchmark.compare_geometry(small,large)
 result=dict(result='PASS_MATCHED_ORDINARY_COMPARISON',cases=8,pairs_per_case=5,ordinary_processes=80,ordinary_samples=9600,native_acceptance_processes=3,warm_targets_ns=dict(p95=4000000,p99=6000000),summary=summaries,pairs=pairs,validation_sha256=proofs,queue_sha256=c.sha(P/'queue/terminal.json'),producer_sha256=c.sha(__file__),full_mac_qualified=False,physical_GPU_execution_or_presentation_qualified=False)
 result['all_run_warm_target_met']={arm:all(run['p95']<=4000000 and run['p99']<=6000000 for group in summaries.values()for run in group[arm]['timings_ns']['ui_work_ns']['per_run'])for arm in ['baseline','candidate']}
 with(P/'comparison.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k not in ['summary','pairs','validation_sha256']}))
if __name__=='__main__':main()
