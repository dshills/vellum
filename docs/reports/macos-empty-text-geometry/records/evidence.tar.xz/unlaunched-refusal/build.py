"""Compile clean candidate fixtures without launching native code."""
from pathlib import Path
import datetime,json,sys,time
from identity import *
P=Path(__file__).resolve().parent
sys.path.insert(0,str(CANDIDATE/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
expected=read('/private/tmp/vellum-empty-text-geometry-1ba954c/clean-8dadc48/source-identity.json')
need(current(CANDIDATE,expected),'clean candidate')
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
for name,command,package in [('ax',['go','build','-p=1','-trimpath'],'./cmd/accessibility-smoke'),('nativetests',['go','test','-c','-p=1','-trimpath'],'.')]:
 out=P/('build-'+name);out.mkdir()
 argv=command+['-o',str(out/name),package]
 d=dict(schema='vellum.clean-native-acceptance-build.v1',commit=expected['commit'],argv=argv,cwd=str(CANDIDATE/'drivers/cogent'),producer_sha256=sha(__file__),source_identity_sha256=sha('/private/tmp/vellum-empty-text-geometry-1ba954c/clean-8dadc48/source-identity.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=None,error=None,native_runtime_executed=False)
 start=time.monotonic()
 try:
  with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:d['exit_code']=run_child(argv,cwd=d['cwd'],env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20).returncode
  need(d['exit_code']==0,'compile failed')
  with(out/'go-version.txt').open('xb')as stdout,(out/'go-version.stderr').open('xb')as stderr:r=run_child(['go','version','-m',str(out/name)],env=env,stdout=stdout,stderr=stderr,timeout=30,log_limit_bytes=2<<20)
  need(r.returncode==0 and not(out/'go-version.stderr').read_bytes(),'metadata failed')
  metadata=(out/'go-version.txt').read_text()
  # Go test binaries omit VCS settings; source vector and compiler invocation bind them.
  need('CGO_ENABLED=1'in metadata,'native CGO build')
  if name=='ax':need('vcs.revision='+expected['commit']in metadata and 'vcs.modified=false'in metadata,'clean app metadata')
  d.update(binary=dict(path=str(out/name),bytes=(out/name).stat().st_size,sha256=sha(out/name),executed=False),metadata_sha256=sha(out/'go-version.txt'))
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 d.update(elapsed_seconds=time.monotonic()-start,source_stable=current(CANDIDATE,expected),logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']})
 d['success']=d['exit_code']==0 and d['error']is None and d['source_stable']and 'binary'in d
 with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps(d),flush=True);need(d['success'],'build incomplete')
