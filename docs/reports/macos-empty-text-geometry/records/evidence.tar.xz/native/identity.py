"""Explicit source vectors shared by compile and bounded native comparison."""
from pathlib import Path
import hashlib,json,subprocess
BASE=Path('/Users/dshills/Development/projects/Vellum')
CANDIDATE=Path('/private/tmp/vellum-macos-native-results-97aee13')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=15)
def current(root,expected):
 need(git(root,'rev-parse','HEAD').decode().strip()==expected['commit'],'commit drift')
 need(not git(root,'status','--porcelain','-z'),'working tree drift')
 names=[n for n in git(root,'ls-files','-z').decode().split('\0')if n]
 need(set(names)==set(expected['tracked']),'tracked names drift')
 need(all((root/n).is_file()and not(root/n).is_symlink()and sha(root/n)==h for n,h in expected['tracked'].items()),'tracked bytes drift')
 prepared={}
 for module in ['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/module).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 need(prepared==expected['prepared'],'prepared bytes drift')
 return True
