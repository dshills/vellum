"""Three native acceptance processes, then eighty ordinary paired processes."""
CASES={
 'text-selectors':dict(kind='text-selectors',target='nativetests',args=['-test.v','-test.count=1','-test.run=^(TestNativeAccessibilityTextSelectorsExactUTF16AndStaleGeometry|TestNativeAccessibilityFieldSetBoundsBeforeCStringAdmission|TestNativeAccessibilityEditorSetRejectsNULWithoutTruncatingDocument)$'],watchdog_seconds=90,heap_profile=None),
 'main-and-dialog':dict(kind='ax',target='ax',args=[],watchdog_seconds=90,heap_profile=None),
 'grid-accessibility':dict(kind='grid-ax',target='candidategrid',args=['-accessibility-smoke','-rows=1000000'],watchdog_seconds=120,heap_profile=None),
}
for gpu in [False,True]:
 for variable in [False,True]:
  for rows in [10000,1000000]:
   for pair in range(1,6):
    for arm in (['baseline','candidate']if pair%2 else['candidate','baseline']):
     case=f'{"gpu"if gpu else"cpu"}-{ "variable"if variable else"fixed"}-{rows}-pair{pair}-{arm}'
     args=['-perf',f'-rows={rows}','-perf-samples=120','-perf-warmup=128']
     if variable:args.append('-variable-rows')
     if gpu:args.append('-gpu-scene')
     CASES[case]=dict(kind='ordinary',target=arm+'grid',args=args,watchdog_seconds=180,heap_profile=None,rows=rows,variable=variable,gpu_scene=gpu,samples=120,warmup=128,pair=pair,arm=arm)
ORDER=list(CASES)
BUILD_PLAN={n:dict(cwd='drivers/cogent'if n in ['ax','nativetests']else'examples/loadedgrid')for n in ['ax','nativetests','baselinegrid','candidategrid']}
