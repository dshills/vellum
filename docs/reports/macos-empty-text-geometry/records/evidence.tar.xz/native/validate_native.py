"""Pure receipt and raw payload checks; no UI calls."""
import json,sys
import native_common as c
from payloads import payload
def validate(case):
 cfg=c.CASES[case];configuration=c.config();review=c.approved();manifest,entry=c.compiled(cfg['target'],configuration)
 r=c.read(c.P/(case+'.json'));owned=c.read(c.P/(case+'-owned-process.json'))
 c.need(r['case']==owned['case']==case and r['result']=='TERMINAL_NATIVE_CASE_OK'and owned['result']=='STARTED_NATIVE_CASE','terminal ownership')
 c.need(type(r['exit_code'])is int and r['exit_code']==0 and r['error']is None and r['stop_reason']is None and not r['cleanup_errors']and not r['stop_markers_at_exit'],'successful process')
 c.need(all(r[k]is True for k in ['direct_child_terminal','group_absence_confirmed','source_stable','artifacts_stable','logs_complete','profile_ok','native_application_executed']),'complete observations')
 c.need(type(r['pid'])is int and r['pid']>0 and r['pid']==r['process_group']==owned['pid']==owned['process_group'],'owned PID/PGID')
 c.need(r['native_lease']==dict(path='/private/tmp/vellum-macos-live-oct15.lock',acquired=True,held_through_cleanup=True),'native lease')
 for key,file in [('producer_sha256','run_native.py'),('review_sha256','native-review.json'),('configuration_sha256','native-configuration.json'),('binaries_manifest_sha256','binaries.json')]:c.need(r[key]==owned[key]==c.sha(c.P/file),'launch binding '+file)
 expected=set(review['sources'])|{'native-review.json','native-configuration.json','binaries.json',cfg['target']+'.json',cfg['target']+'-go-version.txt','live-authorization.json'}
 c.need(r['pins']==owned['pins']and set(r['pins'])==expected and all(c.sha(c.P/n)==h for n,h in r['pins'].items()),'all launch pins')
 root=c.BASE if cfg['target']=='baselinegrid'else c.CANDIDATE
 for k,v in dict(argv=[entry['binary']['path'],*cfg['args']],cwd=str(root/c.BUILD_PLAN[cfg['target']]['cwd']),binary_sha256=entry['binary']['sha256'],build_receipt_sha256=entry['build_receipt_sha256'],source_commit=manifest['source_commit'],watchdog_seconds=cfg['watchdog_seconds'],environment_policy=c.environment_descriptor(case)).items():c.need(r[k]==owned[k]==v,'fixed invocation '+k)
 for ch in ['stdout','stderr']:
  path=c.P/(case+'.'+ch);item=r['logs'][ch];c.need(item['sha256']==item['stream_sha256']==c.sha(path)and item['bytes']==path.stat().st_size,'raw log '+ch)
 c.need(r['group_observation']['observed_group']==r['pid']and r['group_observation']['members']==[]and r['profile']is None,'process group/profile')
 details=payload((c.P/(case+'.stdout')).read_text(),cfg,manifest['source_commit'])
 return dict(result='PASS_SCOPED_NATIVE_CASE',case=case,run_receipt_sha256=c.sha(c.P/(case+'.json')),validator_sha256=c.sha(__file__),details=details,native_service_inventory_qualified=False,physical_pointer_qualified=False,full_mac_qualified=False)
if __name__=='__main__':
 try:d=validate(sys.argv[1])
 except Exception as e:d=dict(result='FAILED_VALIDATION',error=dict(type=type(e).__name__,message=str(e)))
 with(c.P/(sys.argv[1]+'-validation.json')).open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps(d));sys.exit(0 if d['result']=='PASS_SCOPED_NATIVE_CASE'else 1)
