"""Build exact committed isolated fixtures; never execute these binaries."""
from pathlib import Path
import datetime,json,sys,time
from identity import *
P=Path(__file__).resolve().parent
C=read('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-acceptance-geometry-isolation/commit.json')
need(C['success']and git(CANDIDATE,'rev-parse','HEAD').decode().strip()==C['commit']and not git(CANDIDATE,'status','--porcelain','-z'),'clean source')
names=[n for n in git(CANDIDATE,'ls-files','-z').decode().split('\0')if n]
source=dict(commit=C['commit'],tracked={n:sha(CANDIDATE/n)for n in names},prepared={p.relative_to(CANDIDATE/'drivers/cogent/build').as_posix():sha(p)for m in ['upstream','typesetting']for p in(CANDIDATE/'drivers/cogent/build'/m).rglob('*')if p.is_file()})
need(len(source['tracked'])==4605 and len(source['prepared'])==6243,'full vectors')
need(all(source['tracked'][n]==h for n,h in C['source_files'].items()),'committed correction')
need(source['prepared']==read('/private/tmp/vellum-grid-cpu-profiles-1ba954c/compile/source-identity.json')['prepared'],'identical prepared baseline')
with(P/'source-identity.json').open('x')as f:f.write(json.dumps(source,indent=2)+'\n')
sys.path.insert(0,str(CANDIDATE/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
for name,cwd,command,package in [('candidategrid','examples/loadedgrid',['go','build','-p=1','-trimpath'],'.'),('ax','drivers/cogent',['go','build','-p=1','-trimpath'],'./cmd/accessibility-smoke'),('nativetests','drivers/cogent',['go','test','-c','-p=1','-trimpath'],'.')]:
 need(current(CANDIDATE,source),'source before compile')
 out=P/('build-'+name);out.mkdir();argv=command+['-o',str(out/name),package]
 d=dict(schema='vellum.clean-isolated-acceptance-build.v1',commit=source['commit'],argv=argv,cwd=str(CANDIDATE/cwd),producer_sha256=sha(__file__),source_identity_sha256=sha(P/'source-identity.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=None,error=None,native_runtime_executed=False)
 start=time.monotonic()
 try:
  with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:d['exit_code']=run_child(argv,cwd=d['cwd'],env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20).returncode
  need(d['exit_code']==0,'compile failed')
  with(out/'go-version.txt').open('xb')as stdout,(out/'go-version.stderr').open('xb')as stderr:r=run_child(['go','version','-m',str(out/name)],env=env,stdout=stdout,stderr=stderr,timeout=30,log_limit_bytes=2<<20)
  need(r.returncode==0 and not(out/'go-version.stderr').read_bytes(),'metadata')
  metadata=(out/'go-version.txt').read_text();need('CGO_ENABLED=1'in metadata,'native CGO')
  if name!='nativetests':need('vcs.revision='+source['commit']in metadata and 'vcs.modified=false'in metadata,'clean native VCS metadata')
  d.update(binary=dict(path=str(out/name),bytes=(out/name).stat().st_size,sha256=sha(out/name),executed=False),metadata_sha256=sha(out/'go-version.txt'))
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 d.update(elapsed_seconds=time.monotonic()-start,source_stable=current(CANDIDATE,source),logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']})
 d['success']=d['exit_code']==0 and d['error']is None and d['source_stable']and 'binary'in d
 with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps(d),flush=True);need(d['success'],'build incomplete')
