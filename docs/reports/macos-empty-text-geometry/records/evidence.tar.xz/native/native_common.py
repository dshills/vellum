"""Immutable per-process root and binary admission; no dynamic global root changes."""
from pathlib import Path
import json,os,subprocess,sys,importlib.util
sys.dont_write_bytecode=True
from identity import *
from cases import CASES,ORDER,BUILD_PLAN
P=Path(__file__).resolve().parent
TARGET=CASES[sys.argv[1]]['target']if len(sys.argv)>1 and sys.argv[1]in CASES else'candidategrid'
R=BASE if TARGET=='baselinegrid'else CANDIDATE
sys.path.insert(0,str(BASE/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
from live_lease import LiveLease
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def current_identity(expected):return current(R,expected)
def group_absent(pid):
 need(type(pid)is int and pid>0,'owned group identity')
 argv=['ps','-axo','pid=,pgid=,stat='];r=run_child(argv,env=child_environment(),capture_output=True,timeout=5)
 need(r.returncode==0 and not r.stderr and r.stdout.strip(),'process observation')
 for line in r.stdout.decode().splitlines():
  fields=line.split();need(len(fields)==3 and fields[0].isdecimal()and fields[1].isdecimal(),'process observation fields')
  need(int(fields[1])!=pid,'owned group remains')
 return dict(observed_group=pid,argv=argv,stdout_sha256=__import__('hashlib').sha256(r.stdout).hexdigest(),stdout_bytes=len(r.stdout),members=[])
def stopping():return[str(p)for p in [P/'stop-live',Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')]if p.exists()]
def config():
 d=read(P/'native-configuration.json');need(d['cases']==CASES and d['case_order']==ORDER and d['build_plan']==BUILD_PLAN,'closed cases')
 need(d['settings_changes']is False and d['runtime_authorized']is True,'scope')
 for p,h in d['inputs'].items():need(sha(p)==h,'input drift '+p)
 return d
def approved():
 d=read(P/'native-review.json');need(d['execution_ready']is True and d['unresolved_findings']==[],'internal review')
 for p,h in d['sources'].items():need(sha(P/p)==h,'review drift '+p)
 return d
def compiled(target,configuration):
 manifest=read(P/'binaries.json');entry=manifest['outputs'][target];receipt=read(P/(target+'.json'))
 source=read(entry['identity_path']);metadata=Path(entry['metadata_path']).read_text()
 need(receipt['success']is True and receipt['exit_code']==0 and receipt['error']is None and receipt['source_stable']is True and receipt['native_runtime_executed']is False,'actual clean build')
 need(source['commit']==receipt['commit']==entry['commit']and receipt['source_identity_sha256']==sha(entry['identity_path']),'build source identity')
 need(len(source['prepared'])==6243 and len(source['tracked'])==(4604 if target=='baselinegrid'else 4605),'source cardinality')
 need(entry['build_receipt_sha256']==sha(P/(target+'.json'))and entry['binary']==receipt['binary'],'build receipt')
 need(entry['build_metadata_sha256']==receipt['metadata_sha256']==sha(entry['metadata_path'])==sha(P/(target+'-go-version.txt')),'metadata identity')
 need('CGO_ENABLED=1'in metadata,'native build settings')
 if target!='nativetests':need('vcs.revision='+source['commit']in metadata and 'vcs.modified=false'in metadata,'native VCS settings')
 binary=entry['binary'];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'binary identity')
 return dict(source_commit=source['commit'],source_identity=source),entry
def built(target,configuration):
 m,e=compiled(target,configuration);current_identity(m['source_identity']);return m,e
def native_environment(case):return{**child_environment(True),'GOMAXPROCS':'2'}
def environment_descriptor(case):return dict(runtime_allowlist=True,GOMAXPROCS=2,OS_preferences_changed=False)
def predecessor(configuration):return dict(prior_campaigns_not_reexecuted=True)
def prior_cases(case):
 index=ORDER.index(case)
 if index==0:return{}
 prior=ORDER[index-1];v=read(P/(prior+'-validation.json'));r=read(P/(prior+'.json'))
 need(v['result']=='PASS_SCOPED_NATIVE_CASE'and v['run_receipt_sha256']==sha(P/(prior+'.json'))and r['result']=='TERMINAL_NATIVE_CASE_OK','prior accepted process')
 return{prior:dict(validation_sha256=sha(P/(prior+'-validation.json')),fresh_group_absence=group_absent(r['pid']))}
