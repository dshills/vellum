"""Freeze the exact compile receipts and helper sources for internal review."""
from pathlib import Path
import json,sys
from identity import *
from cases import *
P=Path(__file__).resolve().parent
origins={
 'baselinegrid':(Path('/private/tmp/vellum-grid-cpu-profiles-1ba954c/compile'),BASE,Path('/private/tmp/vellum-grid-cpu-profiles-1ba954c/compile/source-identity.json')),
 **{n:(P/('build-'+n),CANDIDATE,P/'source-identity.json')for n in ['candidategrid','ax','nativetests']},
}
outputs={};pins={}
for name,(origin,root,identity)in origins.items():
 receipt=read(origin/'receipt.json');source=read(identity);need(current(root,source),'source at admission')
 need(receipt['success']is True and receipt['source_stable']is True and receipt['source_identity_sha256']==sha(identity),'valid build')
 for file,new in [('receipt.json',name+'.json'),('go-version.txt',name+'-go-version.txt')]:
  with(P/new).open('xb')as f:f.write((origin/file).read_bytes())
 for file in origin.iterdir():
  if file.is_file()and file.name!=Path(receipt['binary']['path']).name:pins[str(file)]=sha(file)
 pins[str(identity)]=sha(identity);pins[receipt['binary']['path']]=receipt['binary']['sha256']
 outputs[name]=dict(commit=receipt['commit'],binary=receipt['binary'],build_receipt_sha256=sha(P/(name+'.json')),build_metadata_sha256=receipt['metadata_sha256'],identity_path=str(identity),metadata_path=str(origin/'go-version.txt'))
with(P/'binaries.json').open('x')as f:f.write(json.dumps(dict(outputs=outputs),indent=2)+'\n')
authorization=dict(latest_human='I am out for the day. The machine is yours for testing',native_UI=True,OS_preferences_changes=False,return_marker='/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live',source_scope='native candidate acceptance and ordinary paired CPU/GPU-requested grid comparison')
with(P/'live-authorization.json').open('x')as f:f.write(json.dumps(authorization,indent=2)+'\n')
for file in P.glob('*.py'):pins[str(file)]=sha(file)
for name in ['binaries.json','live-authorization.json']+[n+s for n in origins for s in ['.json','-go-version.txt']]:pins[str(P/name)]=sha(P/name)
for root in [BASE,CANDIDATE]:
 for name in ['scripts/child_process.py','scripts/sdk_environment.py','scripts/benchmark-grid.py']:pins[str(root/name)]=sha(root/name)
for origin in [Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-acceptance-geometry-isolation')]:
 for n in ['binding.json','source-review.json','final-review.json','commit.json','prism-v1/prism.json','prism-v1/receipt.json']:pins[str(origin/n)]=sha(origin/n)
pins['/private/tmp/vellum-empty-text-native-8dadc48/native-review.json']=sha('/private/tmp/vellum-empty-text-native-8dadc48/native-review.json')
configuration=dict(schema='vellum.native-empty-geometry-comparison.v1',runtime_authorized=True,settings_changes=False,cases=CASES,case_order=ORDER,build_plan=BUILD_PLAN,inputs=pins,external_inputs={p:h for p,h in pins.items()if not Path(p).is_relative_to(P)})
with(P/'native-configuration.json').open('x')as f:f.write(json.dumps(configuration,indent=2)+'\n')
print(json.dumps(dict(result='PREPARED_FOR_INTERNAL_REVIEW',cases=len(ORDER),native_acceptance=3,ordinary_processes=80,pins=len(pins),configuration_sha256=sha(P/'native-configuration.json'))))
