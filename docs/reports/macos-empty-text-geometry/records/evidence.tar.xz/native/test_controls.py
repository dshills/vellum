"""Pure controller-boundary controls; no native process admission."""
import json,sys,unittest
from unittest.mock import patch
from pathlib import Path
import native_common as c
import identity
import payloads as p
class Controls(unittest.TestCase):
 def test_closed_order(self):
  self.assertEqual(len(c.ORDER),83);self.assertEqual(len(set(c.ORDER)),83)
  for index in range(3,83,2):
   a,b=[c.CASES[n]for n in c.ORDER[index:index+2]]
   self.assertEqual({a['arm'],b['arm']},{'baseline','candidate'})
   self.assertEqual(a['pair'],b['pair'])
   self.assertEqual([a['arm'],b['arm']],['baseline','candidate']if a['pair']%2 else['candidate','baseline'])
   for x in [a,b]:
    self.assertEqual(x['samples'],120);self.assertEqual(x['warmup'],128)
    self.assertTrue(all('profile'not in v and 'details'not in v for v in x['args']))
 def test_lease_overlap(self):
  with c.LiveLease():
   with self.assertRaisesRegex(RuntimeError,'another Vellum'): 
    with c.LiveLease():pass
 def test_real_stop_marker_is_checked(self):
  marker='/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live'
  with patch.object(Path,'exists',lambda p:str(p)==marker):self.assertIn(marker,c.stopping())
 def test_commit_drift_refused(self):
  with patch.object(identity,'git',return_value=b'wrong\n'):
   with self.assertRaisesRegex(ValueError,'commit drift'):c.current(c.CANDIDATE,dict(commit='right'))
 def test_json_noise_refused(self):
  for text in ['warning\n{}','[]','null','{}\nPASS']:
   with self.subTest(text=text),self.assertRaises((ValueError,json.JSONDecodeError)):p.events(text)
 def test_grid_ax_complete_and_each_boundary(self):
  good=[dict(event='grid.accessibility.pass',rows=1000000,visible_minimum=400,overlap_objects_reused=401,replacement_objects_retired=400,native_press_admitted=True),dict(event='grid.accessibility.closed',attachment_query_refused=True,geometry_persistence_disabled_in_fixture=True)]
  def value(data):return p.payload('\n'.join(json.dumps(x)for x in data),dict(kind='grid-ax'),'unused')
  self.assertFalse(value(good)['physical_input_qualified'])
  for field,bad in [('rows',10000),('visible_minimum',399),('overlap_objects_reused',399),('replacement_objects_retired',399),('native_press_admitted',False)]:
   changed=json.loads(json.dumps(good));changed[0][field]=bad
   with self.subTest(field=field),self.assertRaises(ValueError):value(changed)
  for changed in [good[:1],good+good,good[::-1],[good[0],dict(event='grid.accessibility.closed',attachment_query_refused=False)]]:
   with self.assertRaises(ValueError):value(changed)
  for bad in [False,None,1,'true']:
   changed=json.loads(json.dumps(good));changed[1]['geometry_persistence_disabled_in_fixture']=bad
   with self.subTest(geometry=bad),self.assertRaises(ValueError):value(changed)
 def test_ax_does_not_claim_voiceover_or_preferences(self):
  good=dict(result='PASS',native='macOS NSAccessibility',voiceover_tested=False,preferences_changed=False,geometry_persistence_disabled_in_fixture=True)
  self.assertEqual(p.payload(json.dumps(good),dict(kind='ax'),'unused'),good)
  for field in ['result','native','voiceover_tested','preferences_changed','geometry_persistence_disabled_in_fixture']:
   bad=good.copy();del bad[field]
   with self.subTest(field=field),self.assertRaises(ValueError):p.payload(json.dumps(bad),dict(kind='ax'),'unused')
 def test_empty_timing_is_refused(self):
  with self.assertRaises(ValueError):p.selected([],dict(),'unused')
 def test_geometry_changes_refused(self):
  good=[dict(geometry=dict(cells=400,rows=50,columns=8,scale=1,layout_sha256='a'*64))]
  for field in good[0]['geometry']:
   changed=json.loads(json.dumps(good));changed[0]['geometry'][field]='wrong'
   with self.subTest(field=field),self.assertRaises(ValueError):p.benchmark.compare_geometry(good,changed)
if __name__=='__main__':unittest.main(verbosity=2)
