"""Serialize reviewed acceptance and comparison. No heavy builds during timings."""
from pathlib import Path
import datetime,json,sys,time
import native_common as c
P=Path(__file__).resolve().parent
def main():
 c.config();c.approved();c.need(not c.stopping(),'human return')
 output=P/'queue';output.mkdir();d=dict(result='STARTED',producer_sha256=c.sha(__file__),configuration_sha256=c.sha(P/'native-configuration.json'),review_sha256=c.sha(P/'native-review.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),steps=[],native_processes_launched_directly=False,error=None)
 try:
  for index,case in enumerate(c.ORDER):
   for script in ['run_native.py','validate_native.py']:
    c.config();c.approved();c.need(not c.stopping(),'human return')
    argv=[sys.executable,'-B',str(P/script),case];stem=f'{index:02d}-{script[:-3]}'
    step=dict(case=case,argv=argv,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with(output/(stem+'.stdout')).open('xb')as out,(output/(stem+'.stderr')).open('xb')as err:r=c.run_child(argv,cwd=P,env={**c.child_environment(True),'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,timeout=c.CASES[case]['watchdog_seconds']+120,log_limit_bytes=8<<20)
    step.update(exit_code=r.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),logs={ch:dict(sha256=c.sha(output/(stem+'.'+ch)),bytes=(output/(stem+'.'+ch)).stat().st_size)for ch in ['stdout','stderr']});d['steps'].append(step)
    (output/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(case=case,script=script,exit_code=r.returncode)),flush=True)
    c.need(r.returncode==0,'native command failed: '+case+'/'+script)
  d['result']='COMPLETED_APPROVED_SEQUENCE'
 except BaseException as e:d['result']='FAILED_OR_CANCELED';d['error']=dict(type=type(e).__name__,message=str(e))
 finally:
  d['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with(output/'terminal.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 c.need(d['result']=='COMPLETED_APPROVED_SEQUENCE','queue incomplete')
if __name__=='__main__':main()
