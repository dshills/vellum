"""Actual raw outcomes, ordinary timing only; no GPU execution claim."""
from pathlib import Path
import importlib.util,json
from identity import *
spec=importlib.util.spec_from_file_location('ordinary_grid',BASE/'scripts/benchmark-grid.py');benchmark=importlib.util.module_from_spec(spec);spec.loader.exec_module(benchmark)
def events(text):
 out=[]
 for line in text.splitlines():
  if not line.strip():continue
  x=json.loads(line);need(type(x)is dict,'JSON object stdout');out.append(x)
 return out
def selected(data,cfg,commit):
 need(len(data)==123,'ordinary stages')
 setup=data[0];settings=setup.get('build_settings',{})
 need(settings.get('vcs.revision')==commit and settings.get('vcs.modified')=='false'and settings.get('CGO_ENABLED')=='1'and settings.get('-race','false')!='true','clean actual runtime build')
 need(setup.get('geometry_persistence_disabled_in_fixture')is True,'isolated geometry')
 need(setup.get('requested_font_family')=='Noto Sans'and setup.get('embedded_regular_font_sha256')==sha(BASE/'drivers/cogent/build/upstream/text/fonts/noto/NotoSans-Regular.ttf'),'embedded font')
 need(all(type(x.get('warmup_guard'))is int and x['warmup_guard']==1 for x in data),'warmup guard')
 need(data[1].get('warmup')==data[1].get('warm_callbacks')==128,'exact warmup')
 need(all(x.get(k,False)is False for x in data for k in ['cpu_profile','alloc_profile','source_details','input_details']),'no diagnostics')
 return benchmark.validate_records(data,cfg['rows'],cfg['variable'],120,False,gpu_scene_rendering=cfg['gpu_scene'])
def payload(text,cfg,commit):
 if cfg['kind']=='ordinary':
  samples=selected(events(text),cfg,commit)
  return dict(samples=len(samples),warmup=128,ui_work_ns=benchmark.distribution([s['metrics']['ui_work_ns']for s in samples]),actual_GPU_execution_qualified=False)
 if cfg['kind']=='text-selectors':
  names=['TestNativeAccessibilityTextSelectorsExactUTF16AndStaleGeometry','TestNativeAccessibilityFieldSetBoundsBeforeCStringAdmission','TestNativeAccessibilityEditorSetRejectsNULWithoutTruncatingDocument']
  need(text.splitlines()[-1]=='PASS'and all(text.count('--- PASS: '+n+' ')==1 and text.count('=== RUN   '+n+'\n')==1 for n in names),'all three native selector tests')
  return dict(tests=names,physical_input_qualified=False)
 data=events(text)
 if cfg['kind']=='ax':
  need(len(data)==1 and data[0].get('result')=='PASS'and data[0].get('native')=='macOS NSAccessibility'and data[0].get('voiceover_tested')is False and data[0].get('preferences_changed')is False and data[0].get('geometry_persistence_disabled_in_fixture')is True,'actual isolated AX outcome')
  return data[0]
 need(len(data)==2 and [x.get('event')for x in data]==['grid.accessibility.pass','grid.accessibility.closed'],'grid AX stages')
 a,b=data;need(a.get('rows')==1000000 and a.get('visible_minimum')==400 and a.get('overlap_objects_reused',0)>=400 and a.get('replacement_objects_retired',0)>=400 and a.get('native_press_admitted')is True and b.get('attachment_query_refused')is True and b.get('geometry_persistence_disabled_in_fixture')is True,'grid AX isolated real actions/identities')
 return dict(events=data,physical_input_qualified=False)
