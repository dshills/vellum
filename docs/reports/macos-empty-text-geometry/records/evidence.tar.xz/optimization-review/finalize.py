from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-empty-text-geometry-1ba954c');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();b=json.loads((W/'binding.json').read_bytes());checks={}
for name in ['focused','adapter','native-vet']:
 r=json.loads((P/name/'receipt.json').read_bytes());assert r['exit_code']==0 and r['sources_stable']and not r['native_application_executed']and r['source_files']==b['source_files'];checks[name]={'receipt_sha256':sha(P/name/'receipt.json'),'seconds':r['elapsed_seconds'],'logs':r['logs']}
assert all(sha(T/n)==h for n,h in b['source_files'].items());diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=T);assert hashlib.sha256(diff).hexdigest()==b['staged_diff_sha256'];assert not subprocess.check_output(['git','diff','--name-only'],cwd=T)
b.update(checks=checks,profile_result_archive_manifest_sha256='538dfefab68a445a79e03f13babc7f1b98a5442fea0bab85621869d5866fe65d',source_review_required=True,compile_native_runtime_and_ordinary_comparison_pending=True,producer_sha256=sha(__file__));(W/'final-binding.json').write_text(json.dumps(b,indent=2)+'\n');print(json.dumps({'source_files':len(b['source_files']),'check_receipts':len(checks),'final_binding_sha256':sha(W/'final-binding.json')}))
