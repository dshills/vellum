"""Compile the exact clean committed smoke source; never launch the app."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=json.loads((W/'commit.json').read_text());T=Path(C['root']);O=Path('/private/tmp/vellum-empty-text-geometry-1ba954c')/('clean-'+C['commit'][:7]);O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=15)
assert C['success']and git('rev-parse','HEAD').decode().strip()==C['commit']and not git('status','--porcelain')
names=[p for p in git('ls-files','-z').decode().split('\0')if p];sources={p:sha(T/p)for p in names}
prepared={p.relative_to(T/'drivers/cogent/build').as_posix():sha(p)for name in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/name).rglob('*')if p.is_file()}
assert len(sources)==4605 and len(prepared)==6243
assert all(sources[p]==v for p,v in C['source_files'].items())
before=dict(commit=C['commit'],tracked=sources,prepared=prepared);(O/'source-identity.json').write_text(json.dumps(before,indent=2)+'\n');(O/'build-clean.py').write_bytes(Path(__file__).read_bytes())
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
argv=['go','build','-p=1','-trimpath','-o',str(O/'loadedgrid'),'.'];result=dict(schema='vellum.clean-native-empty-text-geometry-build.v1',commit=C['commit'],argv=argv,cwd=str(T/'examples/loadedgrid'),producer_sha256=sha(__file__),source_identity_sha256=sha(O/'source-identity.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=None,error=None,native_runtime_executed=False)
start=time.monotonic()
try:
 with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:result['exit_code']=run_child(argv,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20).returncode
 if result['exit_code']==0:
  with(O/'go-version.txt').open('xb')as out,(O/'go-version.stderr').open('xb')as err:
   metadata=run_child(['go','version','-m',str(O/'loadedgrid')],env=env,stdout=out,stderr=err,timeout=30,log_limit_bytes=2<<20)
  assert metadata.returncode==0 and not(O/'go-version.stderr').read_bytes()
  text=(O/'go-version.txt').read_text();assert 'vcs.revision='+C['commit']in text and 'vcs.modified=false'in text and 'CGO_ENABLED=1'in text
  result.update(binary=dict(path=str(O/'loadedgrid'),sha256=sha(O/'loadedgrid'),bytes=(O/'loadedgrid').stat().st_size,executed=False),metadata_sha256=sha(O/'go-version.txt'))
except BaseException as error:result['error']={'type':type(error).__name__,'message':str(error)}
result.update(elapsed_seconds=time.monotonic()-start,source_stable=git('rev-parse','HEAD').decode().strip()==C['commit']and not git('status','--porcelain')and all(sha(T/p)==v for p,v in sources.items())and all(sha(T/'drivers/cogent/build'/p)==v for p,v in prepared.items()),logs={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']})
result['success']=result['exit_code']==0 and result['error']is None and result['source_stable']and 'binary'in result
with(O/'receipt.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));assert result['success']
