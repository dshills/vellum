"""Integrate reviewed source after actual native acceptance; retain failed SLOs."""
from pathlib import Path
import datetime,json,subprocess,sys,time
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-empty-text-native-isolated-v2');sys.path.insert(0,str(P))
from identity import BASE as C,CANDIDATE as T,current,sha,read,need,git
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
review=read(P/'result-review.json');need(review['source_integration_ready']is True and review['unresolved_findings']==[],'sealed integration review')
baseline=read('/private/tmp/vellum-grid-cpu-profiles-1ba954c/compile/source-identity.json');candidate=read(P/'source-identity.json');commit=read(W/'commit.json')
need(commit['success']is True and commit['commit']==candidate['commit'],'reviewed commit')
need(current(C,baseline)and current(T,candidate),'clean unchanged source vectors')
q=read(P/'queue/terminal.json');comparison=read(P/'comparison.json')
need(q['result']=='COMPLETED_APPROVED_SEQUENCE'and len(q['steps'])==166 and comparison['ordinary_samples']==9600 and comparison['all_run_warm_target_met']=={'baseline':False,'candidate':False},'actual tests with failed targets retained')
configuration=read(P/'native-configuration.json');anchors={p:h for p,h in configuration['external_inputs'].items()if p.startswith(str(C)+'/')}
need(set(anchors)=={str(C/'scripts'/n)for n in ['child_process.py','sdk_environment.py','benchmark-grid.py']},'native evidence helper anchors')
need(all(sha(p)==h==sha(T/Path(p).relative_to(C))for p,h in anchors.items()),'unchanged native evidence helpers')
subprocess.run(['git','merge-base','--is-ancestor',baseline['commit'],candidate['commit']],cwd=C,check=True)
out=W/'promotion';out.mkdir();d=dict(schema='vellum.tested-source-fast-forward.v1',old_commit=baseline['commit'],new_commit=candidate['commit'],canonical_root=str(C),reviewed_worktree=str(T),result_review_sha256=sha(P/'result-review.json'),comparison_sha256=sha(P/'comparison.json'),queue_sha256=sha(P/'queue/terminal.json'),source_identity_sha256=sha(P/'source-identity.json'),native_helper_anchors=anchors,ordinary_latency_targets_pass=False,causal_gain_qualified=False,full_mac_qualified=False,native_application_executed=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),success=False,error=None)
start=time.monotonic()
try:
 with(out/'merge.stdout').open('xb')as stdout,(out/'merge.stderr').open('xb')as stderr:r=run_child(['git','merge','--ff-only','--no-edit',candidate['commit']],cwd=C,env=child_environment(False),stdout=stdout,stderr=stderr,timeout=30,log_limit_bytes=2<<20)
 d['merge_exit_code']=r.returncode;need(r.returncode==0,'merge failed')
 with(out/'prepare.stdout').open('xb')as stdout,(out/'prepare.stderr').open('xb')as stderr:r=run_child([sys.executable,'-B','drivers/cogent/prepare.py'],cwd=C,env=child_environment(False),stdout=stdout,stderr=stderr,timeout=180,log_limit_bytes=4<<20)
 d['prepare_exit_code']=r.returncode;need(r.returncode==0,'prepare failed')
 need(current(C,candidate)and current(T,candidate),'both final vectors clean and identical')
 d.update(success=True,tracked_files=len(candidate['tracked']),prepared_files=len(candidate['prepared']),canonical_worktree_clean=True,reviewed_worktree_clean=True)
except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
finally:
 d.update(elapsed_seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer_sha256=sha(__file__),logs={p.name:dict(bytes=p.stat().st_size,sha256=sha(p))for p in out.iterdir()if p.is_file()})
 with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps(d))
need(d['success'],'source promotion incomplete')
