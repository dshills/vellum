"""One bounded Anthropic review of the accessibility-fixture geometry isolation checkpoint."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,time
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');O=W/'prism-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.loads((W/'binding.json').read_bytes());b['files']=b['source_files'];b['prism_paths']=list(b['source_files']);b['prism_diff_sha256']=b['staged_diff_sha256'];review=json.loads((W/'source-review.json').read_bytes());assert review['prism_ready']and not review['unresolved_findings'];assert all(sha(T/p)==h for p,h in b['files'].items())
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
assert git('rev-parse','HEAD').decode().strip()==b['base_commit'];assert not git('diff','--name-only')
assert hashlib.sha256(git('diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256']
payload=git('diff','--cached','--binary','--',*b['prism_paths']);assert hashlib.sha256(payload).hexdigest()==b['prism_diff_sha256']and len(payload)==5155
O.mkdir();(O/'payload.diff').write_bytes(payload)
rules={"focus":["Review this three-file fixture isolation correction for actionable lifetime, cleanup or ordering bugs. Both standalone main/modal and stored-grid accessibility acceptance entrypoints set core.DebugSettings.DisableWindowGeometrySaver before creating the app/native windows and restore the previous process-local switch after native teardown.","The prepared core windowgeometry.shouldSave gate refuses both geometry restores and saves while the switch is true. Ordinary runPerf already uses this same pattern. Both acceptance terminal outputs now explicitly report the disabled flag.","No native test has launched at this checkpoint. Preserve that qualification scope; local validation consists of the loadedgrid offscreen race suite and native vet for both affected binaries."]} ;(O/'rules.json').write_text(json.dumps(rules,indent=2)+'\n')
binary=Path('/Users/dshills/Development/Go/bin/prism');old=Path('/private/tmp/vellum-native-attestation-probe-20261016');assert sha(binary)==json.loads((old/'prism-staged-v3/receipt.json').read_bytes())['binary_sha256']
spec=importlib.util.spec_from_file_location('prism_owned_runner',old/'run-verifier.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
argv=[str(binary),'review','staged','--paths',','.join(b['prism_paths']),'--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','24000','--max-diff-bytes','30000','--rules',str(O/'rules.json'),'--format','json','--out',str(O/'prism.json')]
env=os.environ.copy();env.update(GOENV='off',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod',GOCACHE='/Users/dshills/Library/Caches/go-build',GOPATH='/Users/dshills/Development/Go',GOPROXY='off',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly -p=1',GOMAXPROCS='2',PYTHONDONTWRITEBYTECODE='1')
record={'schema':'vellum.mac-accessibility-fixture-isolation-prism.v1','argv':argv,'cwd':str(T),'binary_sha256':sha(binary),'source_review_sha256':sha(W/'source-review.json'),'producer_sha256':sha(__file__),'payload_sha256':sha(O/'payload.diff'),'payload_bytes':len(payload),'files':len(b['prism_paths']),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':None,'native_runtime_executed':False};errors=[];child=None;start=time.monotonic()
try:
 with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:
  child=subprocess.Popen(argv,cwd=T,env=env,stdout=out,stderr=err,start_new_session=True);record['owned_pid']=child.pid
  while child.poll()is None:
   if time.monotonic()-start>240:raise TimeoutError('owned Prism watchdog')
   if(O/'stdout').stat().st_size>8<<20 or(O/'stderr').stat().st_size>8<<20:raise RuntimeError('Prism log limit')
   time.sleep(.1)
  record['exit_code']=child.wait()
except Exception as error:errors.append(type(error).__name__+': '+str(error))
finally:
 record.update(runner.retire_owned(child,errors));after=runner.attempt(errors,'terminal staged diff',lambda:git('diff','--cached','--binary'))
 record.update(errors=errors,elapsed_seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources_stable=all(sha(T/p)==h for p,h in b['files'].items()),staged_diff_stable=after is not None and hashlib.sha256(after).hexdigest()==b['staged_diff_sha256'],binary_stable=sha(binary)==record['binary_sha256'],artifacts={n:sha(O/n)if(O/n).exists()else None for n in ['prism.json','stdout','stderr']})
 (O/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['exit_code','errors','elapsed_seconds','sources_stable','staged_diff_stable','binary_stable','owned_group_absent','files','payload_bytes','artifacts']}));assert record['exit_code']in[0,1]and not errors and record['sources_stable']and record['staged_diff_stable']and record['binary_stable']and record['owned_group_absent']
