from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');O=Path('/private/tmp/vellum-acceptance-geometry-isolation-8dadc48');O.mkdir()
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['drivers/cogent/cmd/accessibility-smoke/main.go','examples/loadedgrid/accessibility_smoke.go','specs/macos-service-performance.md'];before={n:sha(T/n)for n in files}
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2','PYTHONDONTWRITEBYTECODE':'1'}
checks=[('loadedgrid-race','examples/loadedgrid',['go','test','-race','-p=1','-tags=offscreen','-count=1','./...']),('loadedgrid-vet','examples/loadedgrid',['go','vet','-p=1','./...']),('ax-vet','drivers/cogent',['go','vet','-p=1','./cmd/accessibility-smoke'])]
for name,cwd,argv in checks:
 out=O/name;out.mkdir();start=time.monotonic()
 with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:r=run_child(argv,cwd=T/cwd,env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20)
 d=dict(argv=argv,cwd=str(T/cwd),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,exit_code=r.returncode,source_files=before,source_stable=all(sha(T/n)==h for n,h in before.items()),producer_sha256=sha(__file__),native_runtime_executed=False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']})
 (out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['source_files','logs']}),flush=True);assert r.returncode==0 and d['source_stable']
