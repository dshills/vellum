from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');files=['drivers/cogent/cmd/accessibility-smoke/main.go','examples/loadedgrid/accessibility_smoke.go','specs/macos-service-performance.md'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
assert git('rev-parse','HEAD').decode().strip()=='8dadc4838dfc98722c9e2a40f710cc203813bad3'
assert set(git('diff','--name-only').decode().splitlines())==set(files)and not git('diff','--cached','--name-only')
subprocess.run(['gofmt','-w',str(T/files[0]),str(T/files[1])],check=True)
subprocess.run(['git','add','--',*files],cwd=T,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=T,check=True)
payload=git('diff','--cached','--binary');(W/'staged.diff').write_bytes(payload)
prepared={p.relative_to(T/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/module).rglob('*')if p.is_file()}
assert prepared==json.loads(Path('/private/tmp/vellum-empty-text-geometry-1ba954c/clean-8dadc48/source-identity.json').read_text())['prepared']
d=dict(root=str(T),base_commit=git('rev-parse','HEAD').decode().strip(),source_files={n:sha(T/n)for n in files},staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(payload),prepared_files=len(prepared))
(W/'binding.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
