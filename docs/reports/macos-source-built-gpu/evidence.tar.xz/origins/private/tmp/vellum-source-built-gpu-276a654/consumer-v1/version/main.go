package main
import("encoding/json";"os";"github.com/oliverbestmann/webgpu/wgpu")
func main(){v:=uint32(wgpu.GetVersion());if v!=0x1d000101{panic("unexpected static WGPU version")};if err:=json.NewEncoder(os.Stdout).Encode(map[string]uint32{"version":v});err!=nil{panic(err)}}
