"""Bundle the exact reviewed private experiment and prepare eight documentation files."""
from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
R=Path(__file__).resolve().parent;W=R.parent/'macos-source-built-gpu-276a654';P=Path('/private/tmp/vellum-source-built-gpu-276a654');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='276a6543727bf12183c7a0acf52321a2ae82138a'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
approval=read(R/'package-readiness.json');need(approval['execution_ready']is True and not approval['unresolved_findings']and all(sha(p)==h for p,h in approval['inputs'].items()),'separate exact package readiness')
review=read(W/'consumer-v2-result-review.json');need((review.get('results_ready')or review.get('result_accepted')or review.get('result_ready'))and not review['unresolved_findings']and all(sha(p)==h for p,h in review['inputs'].items()),'stable accepted native result')
provider=read(R/'prism/receipt.json');need(provider['result']=='COMPLETE_SCOPED_PROVIDER_REVIEW'and provider['error']is None and not provider['finalization_errors'],'complete provider checkpoint')
raw_provider=read(R/'prism/prism.json');need(sha(R/'prism/prism.json')==provider['report_sha256']and raw_provider['coverage']==provider['coverage'],'exact raw provider report/coverage')
disposition=read(R/'provider-disposition-review.json');counts=dict(retained=len(raw_provider['findings']),discarded=len(raw_provider.get('discarded',[])),suppressed=len(raw_provider.get('suppressed',[])))
need(disposition['reporting_ready']is True and not disposition['unresolved_findings']and all(sha(p)==h for p,h in disposition['inputs'].items()),'stable independent provider disposition')
need(counts==disposition['rawcounts']==dict(retained=0,discarded=1,suppressed=0)and provider['findings']==counts['retained'],'all raw finding buckets accounted')
need(disposition['raw_report_sha256']==sha(R/'prism/prism.json')and disposition['provider_receipt_sha256']==sha(R/'prism/receipt.json'),'disposition binds exact provider endpoint')
raw=raw_provider['discarded'][0];decisions=disposition['dispositions'];need(len(decisions)==1 and decisions[0]['id']==raw['finding']['id']==disposition['findingid']=='f365b143c5ae8014'and decisions[0]['disposition']==disposition['disposition']=='refuted-for-current-acceptance-scope'and decisions[0]['raw_discard_reason']==raw['reason'],'exact raw finding independently resolved without dropping discard reason')
for root in [C,T]:need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20),'clean source before documentation')
need(not(R/'evidence.tar.xz').exists()and not(R/'draft').exists(),'fresh report outputs');files={};omitted={}
def add(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'regular evidence '+str(p));data=p.read_bytes();need(len(data)<=32<<20,'per-file evidence bound');files['origins/'+str(p).lstrip('/')]=data
 need(sum(map(len,files.values()))<=256<<20,'total expanded evidence bound')
def omit(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'regular omitted artifact');omitted[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
for root in [W,R]:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   need(p.suffix in ['.py','.json','.md']or p.parent==R/'prism'and p.name in ['stdout','stderr'],'known controller evidence');add(p)
for p in sorted(P.iterdir()):
 if p.is_file():
  if p.name=='stop-build-v1':need(p.stat().st_size==0,'sealed source-build stop');continue
  if p.name.endswith('.tar.gz'):omit(p)
  else:need(p.suffix in ['.json','.jsonl'],'known source metadata');add(p)
 elif p.name in ['source','cargo-home','target','build-target-v1','consumer-v1','consumer-v2']:continue
 else:
  need(p.name in ['rustc-version','cargo-version','fetch','prepare-deployment-target','prepare-clang-version','prepare-network-denial','prepare-metadata','rust-build-v1','probe-static-arch','probe-dynamic-arch','probe-dynamic-links','probe-dynamic-load-commands','probe-version'],'known command root')
  for f in p.iterdir():need(f.is_file()and f.name in ['stdout','stderr','owned.json'],'bounded command record');add(f)
for variant in ['consumer-v1','consumer-v2']:
 q=P/variant
 for p in sorted(q.iterdir()):
  if p.is_file():
   if p.name in ['version-probe','gpu.test','scene.test']:omit(p)
   elif p.name=='stop-build'or p.name=='stop-native':continue
   else:need(p.name in ['consumer.mod','consumer.sum','version.linkmap','gpu.linkmap','scene.linkmap'],'known consumer file');add(p)
  elif p.name in ['go-cache','go-tmp']:continue
  elif p.name=='libs-darwin':
   add(p/'go.mod');add(p/'libs.go');omit(p/'arm64/libwgpu_native.a')
  elif p.name=='version':add(p/'main.go')
  else:
   need(p.name in ['go-version','go-packages','build-version','build-gpu','build-scene','version-links','version-metadata','version-load-commands','gpu-links','gpu-metadata','gpu-load-commands','scene-links','scene-metadata','scene-load-commands','static-version','native-gpu','native-scene'],'known consumer command')
   for f in p.iterdir():need(f.is_file()and f.name in ['stdout','stderr','owned.json'],'owned consumer command record');add(f)
for name in ['Cargo.toml','Cargo.lock','build.rs','.gitmodules','LICENSE.MIT','LICENSE.APACHE','ffi/wgpu.h','ffi/webgpu-headers/webgpu.h']:add(P/'source'/name)
built=read(W/'build-receipt.json')
for a in built['artifacts']:omit(a['path'])
for a in built['generated_bindings']:add(a['path'])
for p in [R.parent/'macos-sdk-native-238b3b6/run.py',T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]:add(p)
manifest={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(files.items())}
with(R/'evidence.tar.xz').open('xb')as raw:
 with lzma.LZMAFile(raw,'w',preset=7)as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT)as archive:
   for name,data in sorted(files.items()):
    m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.mtime=0;archive.addfile(m,io.BytesIO(data))
need((R/'evidence.tar.xz').stat().st_size<=32<<20,'compressed report bound')
with tarfile.open(R/'evidence.tar.xz','r:xz')as archive:
 need([m.name for m in archive]==sorted(manifest),'exact archive members')
 for member in archive:
  need(member.isfile(),'regular archive member');data=archive.extractfile(member).read();need(len(data)==manifest[member.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256'],'archive roundtrip')
with(R/'evidence.manifest.json').open('x')as out:out.write(json.dumps(manifest,indent=2)+'\n')
native=read(W/'consumer-v2-native.json');result=dict(schema='vellum-private-source-built-gpu-consumer-v1',source_commit=HEAD,wgpu_commit=built['source_commit'],headers_commit='673658bc2bd70ec39fc55ebe6bb0173cf6d0a603',rust_compiler='1.99.0',go_compiler='1.27.2',rust_declared_minimum_macos='11.0',go_consumer_declared_minimum_macos='13.0',runtime_older_macos_qualified=False,abi_constant_checks=dict(size=115,alignment=115,offset=522),rust_compiled_packages=80,rust_compiler_units=103,native=native['validation'],expected_negative_api_stderr=True,rust_stripping_warnings=2,first_consumer_attempt_failed=True,installed_library_changed=False,framework_runtime_source_changed=False,sdk_changed=False,complete_native_component_rights_qualified=False,performance_memory_presentation_physical_macos_qualified=False,release_binary_reproduced=False,result_review_sha256=sha(W/'consumer-v2-result-review.json'),package_readiness_sha256=sha(R/'package-readiness.json'),prism=dict(provider='anthropic',model='claude-sonnet-5-5',calls=1,complete=True,raw_counts=counts,disposition='refuted-for-current-acceptance-scope',finding_id=disposition['findingid'],disposition_review_sha256=sha(R/'provider-disposition-review.json'),report_sha256=provider['report_sha256'],source_association=read(R/'provider-source-association.json'),report_correction=read(R/'report-correction.json'),final_report_producer_sha256=sha(__file__)),archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz'),members=len(manifest),expanded_bytes=sum(v['bytes']for v in manifest.values())),fingerprinted_exclusions=omitted,compiler_caches_and_other_dependency_artifacts_outside_bundle=True)
with(R/'result.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
report='docs/reports/macos-source-built-gpu';text=(R/'README.review.md').read_text().replace('A scoped Prism review using Anthropic Claude Sonnet 5.5 is planned for these producers, controls and claims; its outcome will be recorded separately before commit.','One complete Prism review using Anthropic Claude Sonnet 5.5 covers thirteen submitted producers/controls and these claims. It returns zero retained findings, one raw discarded medium and zero suppressed findings. The discarded state-schema concern was independently examined and refuted as an acceptance defect for this private checkpoint; its original path-filter discard reason and optional schema/control suggestion remain recorded. The payload, raw output and disposition are retained. Only report validation and prose changed afterward, with separate internal review; the executed producers are unchanged.')
text+='\nThe private receipt records `gpu_executed=false` before any test process, `null` after an unconfirmed attempt, and `true` after any confirmed fixture, preserving earlier evidence on a later failure. Campaign success independently requires both complete, terminal, validated cases. This state assessment is source review; no failed-second-process execution control is claimed.\n'
text=text.replace('\n\nThis checkpoint','\n\n[Qualification](result.json) and [the evidence index](evidence.manifest.json) identify [the retained bundle](evidence.tar.xz).\n\nThis checkpoint',1)
new={report+'/README.md':text.encode(),report+'/result.json':(R/'result.json').read_bytes(),report+'/evidence.manifest.json':(R/'evidence.manifest.json').read_bytes(),report+'/evidence.tar.xz':(R/'evidence.tar.xz').read_bytes()}
paragraph='''The [pinned-source GPU consumer checkpoint](reports/macos-source-built-gpu/README.md)
builds the exact WGPU source/header commits with recorded Rust/compiler/features,
then passes private static-only Go consumers and nine headless GPU roots with
23 subtests. Two Rust stripping warnings and the failed initial consumer attempt
remain preserved. The candidate is not adopted into installed libraries or the
SDK; complete component/rights closure, broader native UI/presentation, older
macOS runtime, performance/memory/endurance and full Mac release remain open.
'''
p='docs/implementation.md';new[p]=((T/p).read_text()+'\n'+paragraph).encode()
p='docs/reports/README.md';old=(T/p).read_text();needle='The [implementation status](../implementation.md) describes the current framework.\n';need(old.count(needle)==1,'report index anchor');new[p]=old.replace(needle,needle+'\n- [Pinned-source GPU consumer](macos-source-built-gpu/README.md)\n',1).encode()
p='specs/macos-completion.md';old=(T/p).read_text();needle='## Latest unattended evidence\n';need(old.count(needle)==1,'completion anchor');new[p]=old.replace(needle,needle+'\n'+paragraph.replace('(reports/','(../docs/reports/'),1).encode()
p='specs/release.md';old=(T/p).read_text();needle='## Alpha.2 window lifetime migration\n';need(old.count(needle)==1,'release anchor');new[p]=old.replace(needle,'## Private source-built GPU consumer\n\n'+paragraph.replace('(reports/','(../docs/reports/')+'\n'+needle,1).encode()
D=R/'draft';D.mkdir(mode=0o700)
for name,data in new.items():p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
binding=dict(base_commit=HEAD,draft_root=str(D),sources={name:hashlib.sha256(data).hexdigest()for name,data in new.items()},old={name:sha(T/name)if(T/name).exists()else None for name in new},source_files_after=4712,prepared_files=6249,prism_sha256=sha(R/'prism/prism.json'))
need(all(sha(p)==h for p,h in approval['inputs'].items()),'terminal package inputs unchanged')
with(R/'draft-binding.json').open('x')as out:out.write(json.dumps(binding,indent=2)+'\n')
print(json.dumps(dict(result='PREPARED_SOURCE_BUILT_GPU_CHECKPOINT_DOCS',files=len(new),archive=result['archive'])))
