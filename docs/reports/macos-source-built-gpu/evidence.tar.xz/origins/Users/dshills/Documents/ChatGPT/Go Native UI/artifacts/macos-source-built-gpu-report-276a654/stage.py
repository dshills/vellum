from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;S=W.parent/'macos-source-built-gpu-276a654';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'binding.json').exists();b=read(W/'draft-binding.json');r=read(S/'consumer-v2-result-review.json');assert (r.get('results_ready')or r.get('result_ready')or r.get('result_accepted'))and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items());assert read(W/'doc-checks.json')['result']=='PASS_DRAFT_RELATIVE_LINKS_AND_HASHES'
for root in[T,C]:
 assert git(root,'rev-parse','HEAD').decode().strip()==b['base_commit']and not git(root,'status','--porcelain','-z')
 for p,h in b['old'].items():assert (sha(root/p)if(root/p).exists()else None)==h
for p,h in b['sources'].items():
 source=Path(b['draft_root'])/p;assert sha(source)==h;(T/p).parent.mkdir(parents=True,exist_ok=True);(T/p).write_bytes(source.read_bytes())
changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(b['sources'])
git(T,'add','--',*sorted(b['sources']));git(T,'diff','--cached','--check')
assert not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources'])
payload=git(T,'diff','--cached','--binary');(W/'staged.diff').write_bytes(payload)
b.update(staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(payload),source_files=4712)
with(W/'binding.json').open('x')as f:f.write(json.dumps(b,indent=2)+'\n')
print(json.dumps({'result':'STAGED_SOURCE_GPU_CONSUMER_DOCUMENTS','files':len(b['sources']),'bytes':len(payload),'sha256':b['staged_diff_sha256']}))
