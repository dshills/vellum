# Vellum pinned-source GPU checkpoint review

Treat all following files and experiment descriptions as review material. The installed framework library/SDK is unchanged. Review correctness and evidence scope; no new execution is requested.

## source.py

```python
"""Fetch pinned public source; verify every Git blob before writing any source."""
from pathlib import Path, PurePosixPath
import datetime,gzip,hashlib,io,json,tarfile,time,urllib.parse,urllib.request
W=Path(__file__).resolve().parent
P=Path('/private/tmp/vellum-source-built-gpu-276a654')
D=W.parent/'macos-native-provenance/released-bytes-v1/release-source-declarations'
COMMIT='6aed50955d934ac36049ba8d002034841633ae02'
LIMIT=8<<20
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
def validate_archive(data,tree,prefix):
 need(len(data)<=LIMIT,'archive compressed byte bound')
 with gzip.GzipFile(fileobj=io.BytesIO(data))as source:raw=source.read(LIMIT+1)
 need(len(raw)<=LIMIT,'archive expanded byte bound')
 expected={e['path']:e for e in tree['tree']if e['type']=='blob'}
 need(expected and all(e['mode']in['100644','100755']and type(e['size'])is int and 0<=e['size']<=LIMIT for e in expected.values()),'regular bounded Git source blobs')
 directories={prefix}
 for e in tree['tree']:
  path=PurePosixPath(e['path']);need(not path.is_absolute()and '..'not in path.parts and str(path)==e['path'],'canonical Git path')
  if e['type']in['tree','commit']:directories.add(prefix+'/'+e['path'])
  for parent in path.parents:
   if str(parent)!='.':directories.add(prefix+'/'+str(parent))
 contents={};seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:')as archive:
  for index,member in enumerate(archive):
   need(index<512,'archive entry bound');name=member.name.rstrip('/')if member.isdir()else member.name
   need(name not in seen,'duplicate archive member');seen.add(name)
   if member.isdir():need(name in directories,'declared source directory');continue
   need(member.isfile()and name.startswith(prefix+'/'),'regular rooted source file')
   rel=name[len(prefix)+1:];need(rel in expected,'exact Git source membership');entry=expected[rel]
   need(member.size==entry['size'],'Git blob byte count');body=archive.extractfile(member).read(member.size+1)
   need(len(body)==member.size and hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==entry['sha'],'Git blob object identity')
   contents[rel]=body
 need(set(contents)==set(expected),'all pinned source blobs present')
 return contents

def download(url,destination):
 need(urllib.parse.urlparse(url).netloc=='codeload.github.com','fixed public archive host')
 start=time.monotonic();record=dict(url=url,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=None)
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'Vellum-pinned-source-build'})
  with urllib.request.urlopen(request,timeout=10)as response,destination.open('xb')as output:
   need(urllib.parse.urlparse(response.url).netloc=='codeload.github.com','archive redirect host');count=0
   while True:
    need(time.monotonic()-start<45,'source download deadline');chunk=response.read(64<<10)
    if not chunk:break
    count+=len(chunk);need(count<=LIMIT,'source download byte bound');need(output.write(chunk)==len(chunk),'source download short write')
  record.update(result='PUBLIC_SOURCE_ARCHIVE_FETCHED',bytes=count,sha256=sha(destination.read_bytes()))
 except BaseException as error:record.update(result='FAILED_PUBLIC_SOURCE_FETCH',error=dict(type=type(error).__name__,message=str(error)));raise
 finally:
  record['seconds']=time.monotonic()-start
  with destination.with_suffix(destination.suffix+'.receipt.json').open('x')as output:output.write(json.dumps(record,indent=2)+'\n')
 return record

def write_source(root,contents):
 need(not root.exists(),'fresh source destination');root.mkdir(mode=0o700)
 for name,body in sorted(contents.items()):
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb')as output:need(output.write(body)==len(body),'short source write')
 return {name:dict(bytes=len(body),sha256=sha(body))for name,body in sorted(contents.items())}

def main():
 tree=json.loads((D/'source-tree.json').read_bytes());need(tree['sha']==COMMIT and tree['truncated']is False,'pinned complete source tree')
 need(not(P/'main-source.tar.gz').exists()and not(P/'source').exists()and not(W/'source-receipt.json').exists(),'new one-shot source fetch')
 record=download('https://codeload.github.com/gfx-rs/wgpu-native/tar.gz/'+COMMIT,P/'main-source.tar.gz')
 contents=validate_archive((P/'main-source.tar.gz').read_bytes(),tree,'wgpu-native-'+COMMIT)
 files=write_source(P/'source',contents)
 d=dict(result='EXACT_PINNED_WGPU_SOURCE_BLOBS_VERIFIED',source_commit=COMMIT,download=record,files=files,gitlinks=[e for e in tree['tree']if e['type']=='commit'],native_runtime_executed=False,source_code_executed=False,compiler_provenance_established=False)
 with(W/'source-receipt.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:v for k,v in d.items()if k!='files'}));print(json.dumps(dict(files=len(files),bytes=sum(v['bytes']for v in files.values()))))
if __name__=='__main__':main()

```

## source_controls.py

```python
from pathlib import Path
import gzip,hashlib,importlib.util,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('source_archive_controls',W/'source.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
body=b'fixed source\n';entry=dict(path='src/a.rs',type='blob',mode='100644',size=len(body),sha=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest());tree=dict(tree=[entry]);results=[]
def archive(items):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w')as t:
  for name,data,kind in items:
   info=tarfile.TarInfo(name);info.type=kind;info.size=len(data)if kind==tarfile.REGTYPE else 0;info.linkname='../../escape';t.addfile(info,io.BytesIO(data)if info.size else None)
 return gzip.compress(out.getvalue())
def check(label,data,expected=True):
 try:r=m.validate_archive(data,tree,'root');passed=True
 except ValueError:passed=False
 assert passed==expected,label
 if expected:assert r=={'src/a.rs':body}
 results.append(dict(name=label,pass_=True))
valid=[('root/src/a.rs',body,tarfile.REGTYPE)]
check('exact pinned source',archive(valid))
check('traversal source refused',archive([('root/../../escape',body,tarfile.REGTYPE)]),False)
check('extra source refused',archive(valid+[('root/extra',body,tarfile.REGTYPE)]),False)
check('duplicate source refused',archive(valid+valid),False)
check('changed source refused',archive([('root/src/a.rs',b'x'*len(body),tarfile.REGTYPE)]),False)
check('missing source refused',archive([]),False)
check('source symlink refused',archive([('root/src/a.rs',b'',tarfile.SYMTYPE)]),False)
check('source hardlink refused',archive([('root/src/a.rs',b'',tarfile.LNKTYPE)]),False)
check('absolute source refused',archive([('/root/src/a.rs',body,tarfile.REGTYPE)]),False)
check('expansion bound refuses compressed bomb',gzip.compress(b'x'*(m.LIMIT+1)),False)
r=dict(result='PASS_PINNED_SOURCE_ARCHIVE_CONTROLS',source_code_executed=False,native_runtime_executed=False,controls=results)
with(W/'source-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))

```

## headers.py

```python
"""Bind root/header Git trees to exact commit metadata and verify source ABI bytes."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,re,sys,time,urllib.parse,urllib.request
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('pinned_gpu_source',W/'source.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
P=m.P;need=m.need;sha=m.sha
HEADER='673658bc2bd70ec39fc55ebe6bb0173cf6d0a603'
GO=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu@v1.36.1-0.20261006093257-de8bdd5d5976/wgpu/lib/darwin/arm64')
def fetch_json(repo,kind,revision,name,recursive=False):
 need(repo in['gfx-rs/wgpu-native','webgpu-native/webgpu-headers']and kind in['commits','trees']and re.fullmatch('[a-f0-9]{40}',revision),'fixed public Git metadata')
 url='https://api.github.com/repos/'+repo+'/git/'+kind+'/'+revision+('?recursive=1'if recursive else'')
 start=time.monotonic();request=urllib.request.Request(url,headers={'User-Agent':'Vellum-pinned-source-build','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(request,timeout=15)as response:
  need(urllib.parse.urlparse(response.url).netloc=='api.github.com','public Git metadata redirect');data=response.read((2<<20)+1);need(len(data)<=2<<20,'Git metadata byte bound')
 with(P/name).open('xb')as out:out.write(data)
 value=json.loads(data);need(value['sha']==revision,'exact Git object identity')
 with(P/(name+'.receipt.json')).open('x')as out:out.write(json.dumps(dict(url=url,bytes=len(data),sha256=sha(data),seconds=time.monotonic()-start),indent=2)+'\n')
 return value

def main():
 need(not(W/'headers-receipt.json').exists()and not(P/'source/ffi/webgpu-headers').exists(),'fresh header source')
 root_commit=fetch_json('gfx-rs/wgpu-native','commits',m.COMMIT,'root-commit.json')
 root_tree=fetch_json('gfx-rs/wgpu-native','trees',root_commit['tree']['sha'],'root-tree.json',True)
 need(root_tree['truncated']is False,'complete root Git tree')
 cached=json.loads((m.D/'source-tree.json').read_bytes())
 vector=lambda t:{e['path']:{k:e[k]for k in['mode','type','sha']}for e in t['tree']}
 need(vector(root_tree)==vector(cached),'saved complete root tree matches actual commit tree')
 gitlinks={e['path']:e for e in root_tree['tree']if e['type']=='commit'};need(gitlinks['ffi/webgpu-headers']['sha']==HEADER,'pinned header Gitlink')
 need('url = https://github.com/webgpu-native/webgpu-headers' in(P/'source/.gitmodules').read_text(),'declared header repository')
 header_commit=fetch_json('webgpu-native/webgpu-headers','commits',HEADER,'headers-commit.json')
 header_tree=fetch_json('webgpu-native/webgpu-headers','trees',header_commit['tree']['sha'],'headers-tree.json',True);need(header_tree['truncated']is False,'complete header Git tree')
 downloaded=m.download('https://codeload.github.com/webgpu-native/webgpu-headers/tar.gz/'+HEADER,P/'headers-source.tar.gz')
 contents=m.validate_archive((P/'headers-source.tar.gz').read_bytes(),header_tree,'webgpu-headers-'+HEADER)
 files=m.write_source(P/'source/ffi/webgpu-headers',contents)
 abi={}
 for name,source in [('wgpu.h',P/'source/ffi/wgpu.h'),('webgpu.h',P/'source/ffi/webgpu-headers/webgpu.h')]:
  body=source.read_bytes();need(body==(GO/name).read_bytes(),'byte-identical pinned Go ABI header '+name);abi[name]=dict(bytes=len(body),sha256=sha(body),source=str(source),go_binding_header=str(GO/name))
 r=dict(result='PINNED_ROOT_AND_HEADERS_COMMIT_TREES_AND_GO_ABI_VERIFIED',root_commit=m.COMMIT,root_tree=root_commit['tree']['sha'],headers_commit=HEADER,headers_tree=header_commit['tree']['sha'],files=files,download=downloaded,abi=abi,native_runtime_executed=False,source_code_executed=False,source_build_complete=False,scope='Exact source/blob/header identity only; no compiler, feature closure, binary correspondence or runtime result.')
 with(W/'headers-receipt.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items()if k!='files'}));print(json.dumps(dict(files=len(files))))
if __name__=='__main__':main()

```

## fetch_dependencies.py

```python
"""Isolated locked target dependency fetch; never compile downloaded packages."""
from pathlib import Path
import hashlib,importlib.util,json,sys,tomllib
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('source_gpu_owned_process',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def terminal(run):return run['created']and run['error']is None and run['exit_code']==0 and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
def main():
 need(not(P/'cargo-home').exists()and not(W/'dependency-fetch.json').exists(),'new isolated Cargo fetch')
 need(read(W/'source-receipt.json')['result']=='EXACT_PINNED_WGPU_SOURCE_BLOBS_VERIFIED'and read(W/'headers-receipt.json')['result']=='PINNED_ROOT_AND_HEADERS_COMMIT_TREES_AND_GO_ABI_VERIFIED','pinned source/ABI admitted')
 compiler=Path('/Users/dshills/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin');need(all((compiler/n).is_file()for n in['cargo','rustc','rustdoc']),'explicit installed compiler')
 source={str(p):sha(p)for p in(P/'source').rglob('*')if p.is_file()};pins={**source,str(__file__):sha(__file__),**{str(compiler/n):sha(compiler/n)for n in['cargo','rustc','rustdoc']},**{str(W/n):sha(W/n)for n in['source.py','source-receipt.json','source-controls.json','headers.py','headers-receipt.json']}}
 home=P/'cargo-home';home.mkdir(mode=0o700);inventory=read(W.parent/'macos-source-built-gpu-preflight-30025cc/inventory.json');seeded=[]
 for entry in inventory['registry']:
  for cached in entry['verified_cached_archives'][:1]:
   p=Path(cached['path']);body=p.read_bytes();need(hashlib.sha256(body).hexdigest()==entry['checksum'],'rechecked cached locked archive')
   out=home/'registry/cache'/p.parent.name/p.name;out.parent.mkdir(parents=True,exist_ok=True)
   with out.open('xb')as f:f.write(body)
   seeded.append(dict(path=str(out),sha256=entry['checksum'],bytes=len(body)))
 env=['CARGO_HOME='+str(home),'CARGO_TARGET_DIR='+str(P/'target'),'RUSTC='+str(compiler/'rustc'),'RUSTDOC='+str(compiler/'rustdoc'),'RUSTUP_TOOLCHAIN=1.99.0','CARGO_BUILD_JOBS=2','CARGO_HTTP_TIMEOUT=20','CARGO_NET_RETRY=0','PATH='+str(compiler)+':/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin']
 stopping=lambda:(P/'stop-compile').exists();stable=lambda:all(sha(p)==h for p,h in pins.items())
 d=dict(result='INCOMPLETE',source_code_executed=False,native_runtime_executed=False,compiler_settings_changed=False,seeded=seeded,inputs=pins,commands=[],error=None)
 try:
  for label,args in [('rustc-version',[str(compiler/'rustc'),'--version','--verbose']),('cargo-version',[str(compiler/'cargo'),'--version','--verbose']),('fetch',[str(compiler/'cargo'),'fetch','--locked','--target','aarch64-apple-darwin','--manifest-path',str(P/'source/Cargo.toml')])]:
   run=g.execute(['/usr/bin/env',*env,*args],P/'source',P/label,stopping,stable,timeout=240 if label=='fetch'else 30,limit=8<<20);d['commands'].append(dict(label=label,run=run));need(terminal(run),'bounded exact compiler/fetch command '+label)
  lock=tomllib.loads((P/'source/Cargo.lock').read_text());expected={(v['name'],v['version']):v['checksum']for v in lock['package']if v.get('source','').startswith('registry+')};archives=[]
  for p in(home/'registry/cache').glob('*/*.crate'):
   candidates=[(name,version,checksum)for(name,version),checksum in expected.items()if p.name==name+'-'+version+'.crate'];need(len(candidates)==1,'only locked registry archives')
   name,version,checksum=candidates[0];need(not p.is_symlink()and sha(p)==checksum,'Cargo locked archive checksum');archives.append(dict(name=name,version=version,path=str(p),bytes=p.stat().st_size,sha256=checksum))
  need(stable()and not stopping(),'terminal source/compiler identity');d.update(result='PASS_ISOLATED_LOCKED_TARGET_FETCH_NO_SOURCE_COMPILATION',archives=archives,archive_count=len(archives),archive_bytes=sum(v['bytes']for v in archives),root_source_files=len(source))
 except BaseException as error:d.update(result='FAILED_ISOLATED_LOCKED_TARGET_FETCH',error=dict(type=type(error).__name__,message=str(error)));raise
 finally:
  with(W/'dependency-fetch.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k not in['seeded','inputs','commands','archives']}),flush=True)
if __name__=='__main__':main()

```

## prepare_build.py

```python
"""Prove extracted Cargo source and freeze an explicit source-build recipe."""
from pathlib import Path
import gzip,hashlib,importlib.util,io,json,os,sys,tarfile,tomllib
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654')
s=importlib.util.spec_from_file_location('source_build_fetch_utilities',W/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g=f.g;need=f.need;sha=f.sha;read=f.read
FEATURES=['wgsl','spirv','glsl','dx12','metal','vulkan','gles'];TARGET='aarch64-apple-darwin'
COMPILER=Path('/Users/dshills/.rustup/toolchains/1.99.0-aarch64-apple-darwin')
XCODE=Path('/Applications/Xcode.app/Contents/Developer');TOOLS=XCODE/'Toolchains/XcodeDefault.xctoolchain/usr';SDK=XCODE/'Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk'

def source_tree(root):
 result={}
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'regular extracted source tree')
  if p.is_file():result[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
 return result

def verify_registry_sources(home):
 expected={(p['name'],p['version']):p for p in tomllib.loads((P/'source/Cargo.lock').read_text())['package']if p.get('source','').startswith('registry+')}
 packages=[];pins={}
 for registry in sorted((home/'registry/src').iterdir()):
  need(registry.is_dir()and not registry.is_symlink(),'private source registry directory')
  for package in sorted(registry.iterdir()):
   matches=[p for(name,version),p in expected.items()if package.name==name+'-'+version];need(len(matches)==1 and package.is_dir()and not package.is_symlink(),'exact locked extracted package')
   p=matches[0];archive=home/'registry/cache'/registry.name/(package.name+'.crate');need(archive.stat().st_size<=64<<20 and sha(archive)==p['checksum'],'locked package archive bytes')
   with gzip.GzipFile(fileobj=io.BytesIO(archive.read_bytes()))as source:raw=source.read((256<<20)+1)
   need(len(raw)<=256<<20,'crate expansion bound');members={}
   with tarfile.open(fileobj=io.BytesIO(raw),mode='r:')as contents:
    for index,member in enumerate(contents):
     need(index<20000,'crate member bound')
     if member.isdir():continue
     need(member.isfile()and member.name.startswith(package.name+'/'),'regular rooted package member')
     rel=member.name[len(package.name)+1:];need(rel and '..'not in Path(rel).parts and rel not in members,'canonical unique package source')
     body=contents.extractfile(member).read(member.size+1);need(len(body)==member.size,'exact package member size');members[rel]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
   actual=source_tree(package);relative={str(Path(name).relative_to(package)):v for name,v in actual.items()};extras=set(relative)-set(members)
   need(extras<=set(['.cargo-ok','.cargo-checksum.json']),'only Cargo extraction bookkeeping added')
   need(all(relative.get(name)==value for name,value in members.items()),'every extracted dependency byte equals locked archive')
   if '.cargo-checksum.json'in extras:
    check=read(package/'.cargo-checksum.json');need(check['package']==p['checksum'],'Cargo extraction checksum identity')
   pins.update({name:value['sha256']for name,value in actual.items()});pins[str(archive)]=p['checksum']
   packages.append(dict(name=p['name'],version=p['version'],archive_sha256=p['checksum'],source=str(package),source_files=len(actual),source_bytes=sum(v['bytes']for v in actual.values())))
 return packages,pins

def config_paths():
 paths=set()
 for parent in [P/'source',*(P/'source').parents]:
  for name in ['config','config.toml']:paths.add(parent/'.cargo'/name)
 for name in ['config','config.toml']:paths.add(P/'cargo-home'/name)
 return sorted(paths)

def environment():
 return ['CARGO_HOME='+str(P/'cargo-home'),'CARGO_TARGET_DIR='+str(P/'build-target-v1'),'RUSTC='+str(COMPILER/'bin/rustc'),'RUSTDOC='+str(COMPILER/'bin/rustdoc'),'RUSTUP_TOOLCHAIN=1.99.0','CARGO_BUILD_JOBS=2','CARGO_NET_OFFLINE=true','CARGO_NET_RETRY=0','PATH='+str(COMPILER/'bin')+':/usr/bin:/bin:/usr/sbin:/sbin','DEVELOPER_DIR='+str(XCODE),'SDKROOT='+str(SDK),'CC='+str(TOOLS/'bin/clang'),'CXX='+str(TOOLS/'bin/clang++'),'CLANG_PATH='+str(TOOLS/'bin/clang'),'LIBCLANG_PATH='+str(TOOLS/'lib'),'CARGO_TARGET_AARCH64_APPLE_DARWIN_LINKER='+str(TOOLS/'bin/clang'),'MACOSX_DEPLOYMENT_TARGET=11.0','WGPU_NATIVE_VERSION=v29.0.1.1','RUSTFLAGS=-C link-args=-Wl,-install_name,@rpath/libwgpu_native.dylib']

def main():
 need(not(W/'build-plan.json').exists()and not(P/'build-target-v1').exists(),'fresh build plan and target')
 fetched=read(W/'dependency-fetch.json');need(fetched['result']=='PASS_ISOLATED_LOCKED_TARGET_FETCH_NO_SOURCE_COMPILATION','completed locked fetch')
 rootsource=source_tree(P/'source');need(len(rootsource)==97 and all(sha(p)==h for p,h in fetched['inputs'].items()),'original source/compiler unchanged since fetch')
 packages,pins=verify_registry_sources(P/'cargo-home');pins.update({p:v['sha256']for p,v in rootsource.items()})
 configs=config_paths();need(all(not p.exists()for p in configs),'no ambient Cargo ancestor/private-home configuration')
 for root in [P/'cargo-home/registry/index']:
  for p in root.rglob('*'):
   need(not p.is_symlink(),'registry index input symlink')
   if p.is_file():pins[str(p)]=sha(p)
 tools=[COMPILER/'bin/rustc',COMPILER/'bin/cargo',COMPILER/'bin/rustdoc',COMPILER/'lib/libLLVM.dylib',*list((COMPILER/'lib').glob('librustc_driver-*.dylib')),TOOLS/'bin/clang',TOOLS/'bin/clang++',TOOLS/'lib/libclang.dylib',TOOLS/'bin/ld',Path('/usr/bin/xcrun'),Path('/usr/bin/sandbox-exec'),Path(sys.executable).resolve(),SDK/'SDKSettings.json']
 tools+=list((COMPILER/'lib/rustlib'/TARGET/'lib').glob('*'))
 identities=[]
 for p in tools:
  need(p.is_file(),'installed compiler/SDK input '+str(p));resolved=p.resolve();pins[str(resolved)]=sha(resolved);identities.append(dict(path=str(p),resolved=str(resolved),bytes=resolved.stat().st_size,sha256=sha(resolved)))
 for name in ['source.py','source_controls.py','source-controls.json','source-receipt.json','headers.py','headers-receipt.json','fetch_dependencies.py','dependency-fetch.json','prepare_build.py']:pins[str(W/name)]=sha(W/name)
 stopping=lambda:(P/'stop-compile').exists();stable=lambda:all(sha(p)==h for p,h in pins.items())and all(not p.exists()for p in configs)and all(str(Path(v['path']).resolve())==v['resolved']for v in identities)
 env=environment();commands=[]
 profile='(version 1)(allow default)(deny network*)'
 probe="import errno,json,socket; d={};\ntry:\n s=socket.socket();s.settimeout(1);s.connect(('127.0.0.1',9));d['errno']=0\nexcept OSError as e:d['errno']=e.errno\nprint(json.dumps(d));assert d['errno'] in [errno.EPERM,errno.EACCES]"
 for label,argv in [('deployment-target',['/usr/bin/env',*env,str(COMPILER/'bin/rustc'),'--print=deployment-target','--target='+TARGET]),('clang-version',['/usr/bin/env',*env,str(TOOLS/'bin/clang'),'--version']),('network-denial',['/usr/bin/sandbox-exec','-p',profile,str(Path(sys.executable).resolve()),'-c',probe]),('metadata',['/usr/bin/env',*env,str(COMPILER/'bin/cargo'),'metadata','--format-version=1','--locked','--offline','--filter-platform',TARGET,'--no-default-features','--features',','.join(FEATURES),'--manifest-path',str(P/'source/Cargo.toml')])]:
  run=g.execute(argv,P/'source',P/('prepare-'+label),stopping,stable,timeout=120 if label=='metadata'else 30,limit=8<<20);commands.append(dict(label=label,run=run));need(f.terminal(run),'metadata/probe command '+label)
 metadata=read(P/'prepare-metadata/stdout');root=metadata['resolve']['root'];node=next(n for n in metadata['resolve']['nodes']if n['id']==root);need(set(FEATURES)<=set(node['features']),'resolved root features')
 need((P/'prepare-deployment-target/stdout').read_text().strip()=='MACOSX_DEPLOYMENT_TARGET=11.0','explicit ARM64 deployment target')
 for command in commands:
  for name in ['stdout','stderr','owned.json']:pins[str(P/('prepare-'+command['label'])/name)]=sha(P/('prepare-'+command['label'])/name)
 need(stable()and not stopping()and not(P/'build-target-v1').exists(),'metadata is not a source compilation')
 d=dict(result='EXPLICIT_OFFLINE_SOURCE_BUILD_PLAN_PREPARED',source_commit='6aed50955d934ac36049ba8d002034841633ae02',framework_head='276a6543727bf12183c7a0acf52321a2ae82138a',native_runtime_executed=False,downloaded_source_code_executed=False,compiler='1.99.0',target=TARGET,requested_features=FEATURES,resolved_root_features=node['features'],root_package_id=root,package_sources=packages,source_package_count=len(packages),environment=env,configuration_paths_required_absent=list(map(str,configs)),tool_identities=identities,sdk_settings=read(SDK/'SDKSettings.json'),network_sandbox_profile=profile,network_sandbox_scope='Build descendants denied network operations by sandbox-exec; Cargo additionally --offline. Probe proves denied local TCP connect only; not a record of every attempted network operation.',commands=commands,inputs=pins,build_argv=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env',*env,str(COMPILER/'bin/cargo'),'build','--release','--lib','--locked','--offline','--target',TARGET,'--no-default-features','--features',','.join(FEATURES),'--jobs','2','--message-format=json-render-diagnostics','--manifest-path',str(P/'source/Cargo.toml')],scope='Our explicit source build, not reproduction or attestation of upstream released bytes/compiler. Deployment-target configuration is not runtime qualification on older macOS.')
 with(W/'build-plan.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:d[k]for k in ['result','source_package_count','compiler','target','requested_features','resolved_root_features','scope']}))
if __name__=='__main__':main()

```

## build.py

```python
"""One source build and artifact/version probes; no SDK or native app adoption."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
s=importlib.util.spec_from_file_location('source_gpu_build_utilities',W/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g=f.g;need=f.need;sha=f.sha;read=f.read

def validate_build_messages(messages,plan):
 need(messages and all(isinstance(m,dict)and m.get('reason')in['compiler-artifact','build-script-executed','compiler-message','build-finished']for m in messages),'Cargo JSON message protocol')
 finished=[m for m in messages if m['reason']=='build-finished'];need(len(finished)==1 and finished[0].get('success')is True and messages[-1]is finished[0],'exact successful Cargo terminal message')
 roots=[m for m in messages if m['reason']=='compiler-artifact'and m['package_id']==plan['root_package_id']and set(m['target']['kind'])=={'cdylib','staticlib'}]
 need(len(roots)==1,'one root library artifact');root=roots[0]
 need(set(root['features'])==set(plan['resolved_root_features'])and root['fresh']is False and root['profile']['opt_level']=='3'and root['profile']['test']is False,'fresh release root and exact resolved features')
 expected={str(P/'build-target-v1'/plan['target']/'release'/name)for name in['libwgpu_native.a','libwgpu_native.dylib']};need(set(root['filenames'])==expected,'two exact root output paths')
 return root

def validate_version(value):need(type(value.get('version'))is int and value['version']==0x1d000101,'source-built version API identity')

def finalize(d):
 d['finalization_errors']=[]
 def status():d['result']='PASS_OWN_PINNED_SOURCE_WGPU_BUILD_AND_PROBES'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_PINNED_SOURCE_WGPU_BUILD'
 try:(P/'stop-build-v1').touch();d['local_stop_present']=True
 except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__))
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();status()
 try:print(json.dumps({**{k:v for k,v in d.items()if k not in['run','probes','inputs','messages']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
 except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));status()
 try:
  with(W/'build-receipt.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
 except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));status()
 return d

def main():
 need(len(sys.argv)==1,'no runtime overrides');plan=read(W/'build-plan.json');review=read(W/'build-readiness.json');need(review['execution_ready']is True and not review['unresolved_findings'],'separate source build readiness review')
 need(not any(p.exists()for p in[W/'build-receipt.json',P/'rust-build-v1',P/'stop-build-v1',P/'build-target-v1']),'new one-shot build destinations')
 pins=review['inputs'];configs=list(map(Path,plan['configuration_paths_required_absent']))
 stable=lambda:all(sha(p)==h for p,h in pins.items())and all(not p.exists()for p in configs)and all(str(Path(v['path']).resolve())==v['resolved']for v in plan['tool_identities'])
 last_check=0.;max_bytes=0
 def stopping():
  nonlocal last_check,max_bytes
  if STOP.exists()or(P/'stop-build-v1').exists():return True
  now=time.monotonic()
  if now-last_check>=1:
   last_check=now;size=0
   for p in(P/'build-target-v1').rglob('*'):
    need(not p.is_symlink(),'build target symlink')
    if p.is_file():
     try:size+=p.stat().st_size
     except FileNotFoundError:pass
   max_bytes=max(max_bytes,size);need(size<=4<<30,'four GiB build-target bound')
  return False
 def clean():
  for root in(C,T):
   need(g.run_child(['git','rev-parse','HEAD'],cwd=root,capture_output=True,check=True,timeout=20).stdout.decode().strip()==plan['framework_head']and not g.run_child(['git','status','--porcelain','-z'],cwd=root,capture_output=True,check=True,timeout=20).stdout,'clean framework source boundary')
 d=dict(result='INCOMPLETE',source_commit=plan['source_commit'],framework_head=plan['framework_head'],source_build_attempted=False,native_application_started=False,shipped_library_changed=False,toolchain_defaults_changed=False,release_binary_reproduced=False,upstream_executed_compiler_proven=False,older_macos_runtime_qualified=False,ordinary_performance_qualified=False,producer_sha256=sha(__file__),review_sha256=sha(W/'build-readiness.json'),inputs=pins,run=None,probes=[],error=None)
 try:
  need(stable()and not stopping(),'build admission');clean()
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping(),'shared test-machine lease')
   run=g.execute(plan['build_argv'],P/'source',P/'rust-build-v1',stopping,stable,timeout=1200,limit=16<<20);d['run']=run;d['source_build_attempted']=run['created'];need(f.terminal(run),'bounded successful owned Rust build')
   messages=[json.loads(line)for line in(P/'rust-build-v1/stdout').read_bytes().splitlines()];root=validate_build_messages(messages,plan);d['root_artifact_message']=root
   artifacts=[]
   for name in root['filenames']:
    p=Path(name);need(p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=512<<20,'bounded root artifact');artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)));pins[str(p)]=sha(p)
   generated=[]
   for message in messages:
    if message['reason']=='build-script-executed'and message['package_id']==plan['root_package_id']:
     out=Path(message['out_dir']);need(out.is_relative_to(P/'build-target-v1'),'root generated binding location')
     p=out/'bindings.rs';need(p.is_file()and not p.is_symlink()and 0<p.stat().st_size<8<<20,'bounded generated ABI bindings');generated.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
   need(len(generated)==1,'one generated root ABI binding');d['generated_bindings']=generated;d['artifacts']=artifacts
   d['compiler_artifact_units']=[m for m in messages if m['reason']=='compiler-artifact'];d['build_script_outputs']=[m for m in messages if m['reason']=='build-script-executed']
   dylib=str(P/'build-target-v1'/plan['target']/'release/libwgpu_native.dylib');library=str(P/'build-target-v1'/plan['target']/'release/libwgpu_native.a')
   version_probe="import ctypes,json;lib=ctypes.CDLL("+repr(dylib)+");fn=lib.wgpuGetVersion;fn.argtypes=[];fn.restype=ctypes.c_uint32;print(json.dumps({'version':int(fn())}))"
   commands=[('static-arch',['/usr/bin/lipo','-archs',library]),('dynamic-arch',['/usr/bin/lipo','-archs',dylib]),('dynamic-links',['/usr/bin/otool','-L',dylib]),('dynamic-load-commands',['/usr/bin/otool','-l',dylib]),('version',['/usr/bin/sandbox-exec','-p',plan['network_sandbox_profile'],str(Path(sys.executable).resolve()),'-I','-c',version_probe])]
   for label,argv in commands:
    probe=g.execute(argv,P/'source',P/('probe-'+label),stopping,stable,timeout=45,limit=2<<20);d['probes'].append(dict(label=label,run=probe));need(f.terminal(probe),'bounded artifact probe '+label)
   need((P/'probe-static-arch/stdout').read_text().strip()=='arm64'and(P/'probe-dynamic-arch/stdout').read_text().strip()=='arm64','both artifacts ARM64')
   links=(P/'probe-dynamic-links/stdout').read_text();need('@rpath/libwgpu_native.dylib'in links,'declared dylib install name')
   validate_version(read(P/'probe-version/stdout'));d['native_version_probe_executed']=True
   clean();need(stable()and not stopping()and lease.held(),'terminal source/compiler/artifacts/configuration/lease');d['lease_held_through_cleanup']=True;d['max_observed_target_bytes']=max_bytes
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:finalize(d)
 need(d['error']is None and not d['finalization_errors'],'source build/probes failed or canceled')
if __name__=='__main__':main()

```

## build_controls.py

```python
from pathlib import Path
import copy,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('source_build_validation_controls',W/'build.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=json.loads((W/'build-plan.json').read_bytes());root=dict(reason='compiler-artifact',package_id=p['root_package_id'],target=dict(kind=['cdylib','staticlib']),features=p['resolved_root_features'],fresh=False,profile=dict(opt_level='3',test=False),filenames=[str(m.P/'build-target-v1'/p['target']/'release'/name)for name in['libwgpu_native.a','libwgpu_native.dylib']]);valid=[root,dict(reason='build-finished',success=True)];results=[]
def check(label,fn,pass_=False):
 try:fn();ok=True
 except ValueError:ok=False
 assert ok==pass_,label
 results.append(dict(name=label,pass_=True))
check('fresh root accepted',lambda:m.validate_build_messages(valid,p),True)
for label,path,value in [('cached root refused',['fresh'],True),('missing feature refused',['features'],[]),('debug root refused',['profile','opt_level'],'0'),('test root refused',['profile','test'],True),('wrong artifact directory refused',['filenames'],['/other/libwgpu_native.a']),('wrong root package refused',['package_id'],'foreign')]:
 changed=copy.deepcopy(valid);cursor=changed[0]
 for key in path[:-1]:cursor=cursor[key]
 cursor[path[-1]]=value;check(label,lambda changed=changed:m.validate_build_messages(changed,p))
check('missing terminal refused',lambda:m.validate_build_messages(valid[:-1],p))
check('duplicate terminal refused',lambda:m.validate_build_messages(valid+[valid[-1]],p))
check('failed terminal refused',lambda:m.validate_build_messages([root,dict(reason='build-finished',success=False)],p))
check('duplicate root refused',lambda:m.validate_build_messages([root,root,valid[-1]],p))
check('version accepted',lambda:m.validate_version({'version':0x1d000101}),True)
check('unset version refused',lambda:m.validate_version({'version':0}))
check('string version refused',lambda:m.validate_version({'version':str(0x1d000101)}))
r=dict(result='PASS_SOURCE_BUILD_ARTIFACT_VERSION_CONTROLS',native_application_started=False,controls=results)
with(W/'build-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))

```

## consumer_v2.py

```python
"""Private Go builds against only the exact source-built static archive; never run a GPU."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654');Q=P/'consumer-v2';T=Path('/private/tmp/vellum-macos-native-results-97aee13');UP=T/'drivers/cogent/build/upstream'
s=importlib.util.spec_from_file_location('gpu_source_fetch',W/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g,sha,read,need=f.g,f.sha,f.read,f.need
STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
GO=Path('/opt/homebrew/bin/go').resolve();GOROOT=GO.parent.parent
LIB=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu/libs-darwin@v0.0.0-20260628152755-66a5dfa57f8d')
ROOTS={'gpu':['TestVellumRGBAUploadNativeRows','TestVellumTextureNativeOwnershipAndReadback','TestVellumStorageNativeReadback','TestVellumPipelineNativeOwnership'],'scene':['TestVellumGPUSceneNativeIntegerCompositor','TestVellumGPUSceneNativeSharedDrawerOrderAndFallback','TestVellumGPUSceneNativeActualTextAndPaths','TestVellumGPUSceneNativeCoveredUniforms','TestVellumGPUSceneNativeInputAttemptBytesFailureAndRecovery']}
def stopping():return STOP.exists()or(Q/'stop-build').exists()
def environment():
 return ['GOWORK=off','GOTOOLCHAIN=local','GOENV=off','GOFLAGS=','GOPROXY=off','GOSUMDB=off','GONOPROXY=','GONOSUMDB=','CGO_ENABLED=1','GOOS=darwin','GOARCH=arm64','GOMAXPROCS=2','GOCACHE='+str(Q/'go-cache'),'GOTMPDIR='+str(Q/'go-tmp'),'GOROOT='+str(GOROOT),'CC=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang','CGO_CFLAGS=','CGO_CPPFLAGS=','CGO_CXXFLAGS=','CGO_LDFLAGS=','MACOSX_DEPLOYMENT_TARGET=13.0','DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer','SDKROOT=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk']
def command(args):return ['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/usr/bin/env',*environment(),str(GO),*args]
def json_stream(data):
 out=[];decoder=json.JSONDecoder();index=0
 while index<len(data):
  while index<len(data)and data[index].isspace():index+=1
  if index==len(data):break
  value,index=decoder.raw_decode(data,index);out.append(value)
 return out

def prepare():
 need(not Q.exists()and not(W/'consumer-v2-plan.json').exists(),'new private Go preparation')
 build=read(W/'build-receipt.json');need(build['result']=='PASS_OWN_PINNED_SOURCE_WGPU_BUILD_AND_PROBES'and not build['error']and not build['finalization_errors'],'terminal source-built archive')
 static=[a for a in build['artifacts']if a['path'].endswith('.a')];need(len(static)==1 and sha(static[0]['path'])==static[0]['sha256'],'exact static artifact')
 Q.mkdir(mode=0o700);(Q/'go-tmp').mkdir(mode=0o700);module=Q/'libs-darwin';(module/'arm64').mkdir(parents=True,mode=0o700)
 for name in ['go.mod','libs.go']:(module/name).write_bytes((LIB/name).read_bytes())
 (module/'arm64/libwgpu_native.a').write_bytes(Path(static[0]['path']).read_bytes())
 text=(UP/'go.mod').read_text();old='replace github.com/go-text/typesetting => ../typesetting';need(text.count(old)==1,'exact private typesetting replacement')
 (Q/'consumer.mod').write_text(text.replace(old,'replace github.com/go-text/typesetting => '+str(UP.parent/'typesetting'))+'\nreplace github.com/oliverbestmann/webgpu/libs-darwin => '+str(module)+'\n');(Q/'consumer.sum').write_bytes((UP/'go.sum').read_bytes())
 (Q/'version').mkdir();(Q/'version/main.go').write_text('package main\nimport("encoding/json";"os";"github.com/oliverbestmann/webgpu/wgpu")\nfunc main(){v:=uint32(wgpu.GetVersion());if v!=0x1d000101{panic("unexpected static WGPU version")};if err:=json.NewEncoder(os.Stdout).Encode(map[string]uint32{"version":v});err!=nil{panic(err)}}\n')
 pins=dict(read(W/'build-readiness.json')['inputs']);pins.update({str(W/name):sha(W/name)for name in ['build-receipt.json','consumer_v2.py']})
 for root in [GOROOT,Q/'libs-darwin',Q/'version']:
  for p in root.rglob('*'):
   if p.is_file():pins[str(p)]=sha(p)
 for name in ['consumer.mod','consumer.sum']:pins[str(Q/name)]=sha(Q/name)
 pins['/opt/homebrew/bin/go']=sha('/opt/homebrew/bin/go')
 stable=lambda:all(sha(p)==h for p,h in pins.items());commands=[]
 for label,args in [('go-version',['version']),('go-packages',['list','-mod=readonly','-modfile='+str(Q/'consumer.mod'),'-tags=offscreen','-deps','-test','-json','./gpu','./paint/renderers/gpuscene'])]:
  run=g.execute(command(args),UP,Q/label,stopping,stable,timeout=180,limit=8<<20);commands.append(dict(label=label,run=run));need(f.terminal(run),'owned Go metadata '+label)
 packages=json_stream((Q/'go-packages/stdout').read_text());need(packages and all(not p.get('Incomplete')and not p.get('Error')and not p.get('DepsErrors')for p in packages),'complete Go dependency listing')
 fields=['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles','TestEmbedFiles','XTestEmbedFiles']
 for package in packages:
  directory=Path(package['Dir'])if package.get('Dir')else None
  for field in fields:
   for name in package.get(field,[]):
    p=Path(name)if Path(name).is_absolute()else directory/name
    need(p.is_file(),'listed Go source exists '+str(p));pins[str(p)]=sha(p)
  module_info=package.get('Module')or{};module_info=module_info.get('Replace')or module_info
  if module_info.get('GoMod'):
   p=Path(module_info['GoMod']);need(p.is_file(),'module manifest exists');pins[str(p)]=sha(p)
 jobs=[]
 for label,target in [('version',str(Q/'version/main.go')),('gpu','./gpu'),('scene','./paint/renderers/gpuscene')]:
  binary=Q/(label+'.test'if label!='version'else'version-probe');linkmap=Q/(label+'.linkmap');args=['build']if label=='version'else['test','-c'];args+=['-mod=readonly','-modfile='+str(Q/'consumer.mod'),'-tags=offscreen','-p=2','-buildvcs=true','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',str(binary),target];jobs.append(dict(label=label,argv=command(args),binary=str(binary),linkmap=str(linkmap)))
 plan=dict(result='PREPARED_PRIVATE_STATIC_GO_CONSUMER',inputs=pins,commands=commands,jobs=jobs,go=str(GO),go_version=(Q/'go-version/stdout').read_text().strip(),package_count=len(packages),static_archive=static[0],static_module=str(module),native_application_started=False,gpu_executed=False,shipped_library_changed=False,roots=ROOTS)
 with(W/'consumer-v2-plan.json').open('x')as out:out.write(json.dumps(plan,indent=2)+'\n')
 print(json.dumps({k:v for k,v in plan.items()if k not in['inputs','commands','jobs']}))

def validate_linkmap(data,module):
 if isinstance(data,str):data=data.encode('utf-8')
 need(type(data)is bytes and 0<len(data)<=32<<20,'bounded raw linker map')
 need(data.count(b'# Object files:')==1 and data.count(b'# Sections:')==1,'one ordered linker object table')
 before,after=data.split(b'# Object files:',1);objects,sections=after.split(b'# Sections:',1)
 table=objects.decode('utf-8');lines=[line for line in table.splitlines()if 'libwgpu_native'in line]
 need(lines and all(str(Path(module)/'arm64/libwgpu_native.a')+'('in line for line in lines),'only private static archive native object entries')
 need(b'_wgpuGetVersion'in sections,'native version symbol linked');return len(lines)
def validate_links(text):need('libwgpu_native.dylib'not in text and'libwgpu_native.a'not in text,'no runtime native WGPU library dependency')

def build():
 need(not(W/'consumer-v2-build.json').exists()and not(Q/'stop-build').exists(),'new one-shot private consumer build')
 plan=read(W/'consumer-v2-plan.json');review=read(W/'consumer-v2-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'separate consumer build review');need(str(GO)==plan['go'],'planned Go executable identity');pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());d=dict(result='INCOMPLETE',inputs=pins,commands=[],binaries=[],error=None,finalization_errors=[],native_application_started=False,gpu_executed=False)
 try:
  need(not stopping()and stable(),'consumer admission')
  with g.LiveLease()as lease:
   need(lease.held(),'machine lease')
   for job in plan['jobs']:
    label=job['label'];binary=Path(job['binary']);need(not binary.exists()and not Path(job['linkmap']).exists(),'fresh consumer outputs')
    run=g.execute(job['argv'],UP,Q/('build-'+label),stopping,stable,timeout=600,limit=8<<20);d['commands'].append(dict(label='build-'+label,run=run));need(f.terminal(run),'owned consumer build '+label);need(binary.is_file()and not binary.is_symlink()and 0<binary.stat().st_size<128<<20,'bounded consumer binary');pins[str(binary)]=sha(binary);pins[job['linkmap']]=sha(job['linkmap'])
    for suffix,args in [('links',['/usr/bin/otool','-L',str(binary)]),('metadata',[str(GO),'version','-m',str(binary)]),('load-commands',['/usr/bin/otool','-l',str(binary)])]:
     run=g.execute(args,UP,Q/(label+'-'+suffix),stopping,stable,timeout=30,limit=2<<20);d['commands'].append(dict(label=label+'-'+suffix,run=run));need(f.terminal(run),'consumer probe '+label+' '+suffix)
    validate_links((Q/(label+'-links/stdout')).read_text());need('minos 13.0'in(Q/(label+'-load-commands/stdout')).read_text(),'Go consumer declared minimum macOS13.0');objects=validate_linkmap(Path(job['linkmap']).read_bytes(),plan['static_module']);metadata=(Q/(label+'-metadata/stdout')).read_text();need('=>\t'+plan['static_module']+'\t'in metadata,'private Go replacement embedded');d['binaries'].append(dict(label=label,path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary),native_archive_object_entries=objects))
   run=g.execute(['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)',str(Q/'version-probe')],Q,Q/'static-version',stopping,stable,timeout=30,limit=1<<20);d['commands'].append(dict(label='static-version',run=run));need(f.terminal(run)and read(Q/'static-version/stdout')=={'version':0x1d000101},'Go static library version')
   need(stable()and not stopping()and lease.held(),'terminal consumer closure');d['result']='PASS_PRIVATE_STATIC_GO_BUILD_AND_VERSION_NO_GPU_EXECUTION'
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
 finally:
  try:(Q/'stop-build').touch()
  except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  try:print(json.dumps({**{k:v for k,v in d.items()if k not in['inputs','commands']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
  except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
  try:
   with(W/'consumer-v2-build.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));d['result']='FAILED_PRIVATE_STATIC_GO_BUILD'
 need(d['error']is None and not d['finalization_errors'],'consumer build failed')
if __name__=='__main__':
 need(sys.argv[1:]in[['prepare'],['build']],'fixed phase');prepare()if sys.argv[1]=='prepare'else build()

```

## consumer_v2_controls.py

```python
"""Consumer validators reject dynamic linkage, mixed archives and missing version symbols."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('static_consumer_controls',W/'consumer_v2.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
module='/private/test/libs-darwin';object_line='[ 1] '+module+'/arm64/libwgpu_native.a(wgpu_native.o)\n';positive='# Object files:\n'+object_line+'# Sections:\n_wgpuGetVersion\n';checks=[]
def check(name,fn,reject):
 error=None
 try:fn()
 except ValueError as e:error=str(e)
 ok=bool(error)==reject
 if not ok:raise AssertionError(name)
 checks.append(dict(name=name,pass_=True,rejected=bool(error)))
check('private-static-map-admitted',lambda:c.validate_linkmap(positive,module),False)
for name,body in [('empty-map',''),('missing-version','# Object files:\n'+object_line+'# Sections:\n'),('dynamic-library',positive.replace('libwgpu_native.a(', 'libwgpu_native.dylib(')),('original-archive',positive.replace(module,'/original/module')),('mixed-archive',positive.replace('# Sections:', '[ 2] /other/libwgpu_native.a(native.o)\n# Sections:'))]:check(name,lambda body=body:c.validate_linkmap(body,module),True)
check('system-links-admitted',lambda:c.validate_links('/usr/lib/libSystem.B.dylib'),False)
for name,body in [('runtime-native-dylib','@rpath/libwgpu_native.dylib'),('archive-runtime-entry','/path/libwgpu_native.a')]:check(name,lambda body=body:c.validate_links(body),True)
check('raw-symbol-literals-admitted',lambda:c.validate_linkmap(positive.encode()+b'\xc0\xff',module),False)
check('nonutf8-object-table-rejected',lambda:c.validate_linkmap(positive.replace('# Object files:', '# Object files:\nBAD').encode().replace(b'BAD',b'\xff'),module),True)
check('missing-object-table-rejected',lambda:c.validate_linkmap(b'# Sections:\n_wgpuGetVersion',module),True)
r=dict(result='PASS',producer_sha256=c.sha(W/'consumer_v2.py'),checks=checks)
with(W/'consumer-v2-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(result=r['result'],checks=len(checks))))

```

## native_consumer_v2.py

```python
"""Two explicitly admitted headless GPU consumer fixtures; no native windows or physical input."""
from pathlib import Path
import datetime,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('private_static_gpu_consumer',W/'consumer_v2.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
Q=c.Q;g,sha,read,need=c.g,c.sha,c.read,c.need

def validate(label,stdout):
 text=stdout.decode('utf-8');lines=text.splitlines();runs=[line.split()[2]for line in lines if line.startswith('=== RUN   ')and'/'not in line.split()[2]];passes=[line.split()[2]for line in lines if line.startswith('--- PASS: ')and'/'not in line.split()[2]];expected=c.ROOTS[label]
 need(len(runs)==len(set(runs))==len(expected)and set(runs)==set(expected),'exact native root execution');need(len(passes)==len(set(passes))==len(expected)and set(passes)==set(expected),'exact native root passes');need(text.rstrip().endswith('\nPASS')and not any(marker in text for marker in['--- SKIP:','--- FAIL:','FAIL\n','panic:']),'all admitted tests pass without skip or panic')
 subruns=[line.split()[2]for line in lines if line.startswith('=== RUN   ')and'/'in line.split()[2]];subpasses=[line.split()[2]for line in lines if line.lstrip().startswith('--- PASS: ')and'/'in line.split()[2]]
 need(len(subruns)==len(set(subruns))and sorted(subruns)==sorted(subpasses),'all subtests terminal and unique')
 return dict(roots=sorted(runs),root_count=len(runs),subtests=len(subruns),gpu_execution_and_readback=True,windows_created=0,surfaces_created=0,physical_input_verified=False,performance_qualified=False,native_memory_qualified=False)

def main():
 need(len(sys.argv)==1,'no runtime overrides');review=read(W/'consumer-v2-native-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'independent headless execution readiness');build=read(W/'consumer-v2-build.json');need(build['result']=='PASS_PRIVATE_STATIC_GO_BUILD_AND_VERSION_NO_GPU_EXECUTION'and not build['error']and not build['finalization_errors'],'successful static-only consumer build');need(not(W/'consumer-v2-native.json').exists()and not(Q/'stop-native').exists(),'fresh one-shot consumer native destination')
 pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:c.STOP.exists()or(Q/'stop-native').exists();d=dict(result='INCOMPLETE',inputs=pins,commands=[],validation=[],error=None,finalization_errors=[],shipped_library_changed=False,native_windows_started=False,physical_input_generated=False,native_test_process_started=False,gpu_executed=False)
 try:
  need(stable()and not stopping(),'headless consumer admission')
  with g.LiveLease()as lease:
   need(lease.held(),'exclusive test-machine lease')
   for label in ['gpu','scene']:
    entry=[b for b in build['binaries']if b['label']==label];need(len(entry)==1,'one binary per consumer');binary=entry[0];need(sha(binary['path'])==binary['sha256'],'exact source-linked test binary');env=['GOMAXPROCS=2']+(['VELLUM_TEXTURE_GPU_TEST=1','VELLUM_STORAGE_GPU_TEST=1','VELLUM_PIPELINE_GPU_TEST=1']if label=='gpu'else['VELLUM_GPU_SCENE_TEST=1']);argv=['/usr/bin/env',*env,binary['path'],'-test.v','-test.run=^('+'|'.join(c.ROOTS[label])+')$','-test.count=1','-test.timeout=120s'];out=Q/('native-'+label)
    run=g.execute(argv,Q,out,stopping,stable,timeout=180,limit=8<<20);d['commands'].append(dict(label=label,run=run));d['native_test_process_started']=d['native_test_process_started']or run['created'];d['gpu_executed']=True if d['gpu_executed']is True else None if run['created']else d['gpu_executed'];need(c.f.terminal(run),'owned headless GPU consumer '+label);d['validation'].append(dict(label=label,**validate(label,(out/'stdout').read_bytes())));d['gpu_executed']=True
   need(stable()and not stopping()and lease.held(),'terminal source/linkage/lease');d['lease_held_through_cleanup']=True;d['result']='PASS_SOURCE_BUILT_STATIC_GO_HEADLESS_GPU_CONSUMERS'
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
 finally:
  try:(Q/'stop-native').touch()
  except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  try:print(json.dumps({**{k:v for k,v in d.items()if k not in ['inputs','commands']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
  except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
  try:
   with(W/'consumer-v2-native.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
 need(d['error']is None and not d['finalization_errors'],'native consumer failed')
if __name__=='__main__':main()

```

## native_consumer_v2_controls.py

```python
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('native_consumer_validator',W/'native_consumer_v2.py');n=importlib.util.module_from_spec(s);s.loader.exec_module(n)
lines=[]
for root in n.c.ROOTS['gpu']:lines+=['=== RUN   '+root,'=== RUN   '+root+'/case','    --- PASS: '+root+'/case (0.01s)','--- PASS: '+root+' (0.01s)']
positive='\n'.join(lines)+'\nPASS\n';root=n.c.ROOTS['gpu'][0];cases={'positive':(positive,False),'missing-root':(positive.replace('=== RUN   '+root+'\n',''),True),'duplicate-root':(positive+'=== RUN   '+root+'\n',True),'unrelated-root':('=== RUN   TestOther\n'+positive,True),'skip':(positive+'--- SKIP: skipped\nPASS\n',True),'root-failure':(positive.replace('--- PASS: '+root+' (','--- FAIL: '+root+' ('),True),'missing-subtest-pass':(positive.replace('    --- PASS: '+root+'/case (0.01s)\n',''),True),'duplicate-subtest':(positive.replace('=== RUN   '+root+'/case\n',('=== RUN   '+root+'/case\n')*2),True),'missing-terminal':(positive[:-5],True),'panic':('panic: bad\n'+positive,True)};checks=[]
for name,(body,reject)in cases.items():
 error=None
 try:n.validate('gpu',body.encode())
 except ValueError as e:error=str(e)
 if bool(error)!=reject:raise AssertionError(name)
 checks.append(dict(name=name,pass_=True,rejected=bool(error)))
r=dict(result='PASS',producer_sha256=n.sha(W/'native_consumer_v2.py'),checks=checks)
with(W/'native-consumer-v2-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(result=r['result'],checks=len(checks))))

```

## analyze_build.py

```python
"""Offline inventory of the actual Rust build; package inclusion is not a rights decision."""
from pathlib import Path
import hashlib,json,tomllib
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
d=json.loads((W/'build-receipt.json').read_text());need(d['result']=='PASS_OWN_PINNED_SOURCE_WGPU_BUILD_AND_PROBES'and not d['error']and not d['finalization_errors'],'source build terminal');messages=[json.loads(line)for line in(P/'rust-build-v1/stdout').read_bytes().splitlines()];metadata=json.loads((P/'prepare-metadata/stdout').read_bytes());packages={p['id']:p for p in metadata['packages']};units=[m for m in messages if m['reason']=='compiler-artifact'];ids=sorted({m['package_id']for m in units});need(all(not m['fresh']for m in units),'fresh compiler units');compiled=[]
for identity in ids:
 package=packages[identity];manifest=Path(package['manifest_path']);cargo=tomllib.loads(manifest.read_text());root=manifest.parent;notices=[]
 for pattern in ['LICENSE*','LICENCE*','COPYING*','NOTICE*','UNLICENSE*','Unicode*']:
  for path in root.glob(pattern):
   if path.is_file():notices.append(dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path)))
 compiled.append(dict(id=identity,name=package['name'],version=package['version'],license_expression=package.get('license'),license_file=package.get('license_file'),manifest_sha256=sha(manifest),source=package.get('source'),units=[dict(target=m['target']['name'],kinds=m['target']['kind'],features=m['features'],profile=m['profile'])for m in units if m['package_id']==identity],root_notice_candidates=sorted({v['path']:v for v in notices}.values(),key=lambda n:n['path'])))
bindings=Path(d['generated_bindings'][0]['path']);need(sha(bindings)==d['generated_bindings'][0]['sha256'],'generated bytes');text=bindings.read_text();need(text.count('["Size of ')==115 and text.count('["Alignment of ')==115 and text.count('["Offset of field: ')==522 and 'fn bindgen_test_layout'not in text,'constant ABI block inventory')
compiler_messages=[m['message']for m in messages if m['reason']=='compiler-message'];stderr=(P/'rust-build-v1/stderr').read_text();warnings=[dict(source='Cargo stderr',level='warning',message='stripping debug info with rust-objcopy failed: SIGABRT; dyld could not load @rpath/libLLVM.dylib',occurrence=i+1)for i in range(stderr.count('warning: stripping debug info with `rust-objcopy` failed: signal: 6 (SIGABRT)'))];need(len(warnings)==2 and stderr.count('Library not loaded: @rpath/libLLVM.dylib')==2,'two disclosed objcopy warnings')
loads=(P/'probe-dynamic-load-commands/stdout').read_text();need('minos 11.0'in loads,'declared source-built minimum OS load command')
analysis=dict(result='PASS_OFFLINE_ACTUAL_SOURCE_BUILD_INVENTORY',source_commit=d['source_commit'],framework_head=d['framework_head'],compiler_artifact_units=len(units),build_script_outputs=sum(m['reason']=='build-script-executed'for m in messages),compiled_package_count=len(compiled),compiled_packages=compiled,abi_compile_time_checks=dict(size=115,alignment=115,offset=522,runtime_layout_tests=0),warnings=warnings,artifact_sha256={a['path']:a['sha256']for a in d['artifacts']},minimum_macos_load_command='11.0',licenses_are_inventory_only=True,redistribution_rights_qualified=False,complete_native_component_closure=False,release_binary_reproduced=False,inputs={str(p):sha(p)for p in [Path(__file__),W/'build-receipt.json',P/'rust-build-v1/stdout',P/'rust-build-v1/stderr',P/'prepare-metadata/stdout',bindings,P/'probe-dynamic-load-commands/stdout']})
with(W/'build-analysis.json').open('x')as out:out.write(json.dumps(analysis,indent=2)+'\n')
print(json.dumps({k:v for k,v in analysis.items()if k not in ['compiled_packages','inputs','warnings']},indent=2))

```

## Proposed checkpoint README

# Pinned-source macOS GPU consumer

This checkpoint builds a private WGPU native library from the exact `v29.0.1.1` source commit `6aed50955d934ac36049ba8d002034841633ae02` and header submodule commit `673658bc2bd70ec39fc55ebe6bb0173cf6d0a603`. The downloaded source trees are checked against their Git blob identities before extraction. Both C headers match the headers in Vellum's pinned Go binding byte for byte. The previously authenticated upstream release ZIP retains its separate identity and qualification.

The build uses the installed Rust 1.99.0 compiler, Xcode SDK 27.0, an explicit macOS 11.0 deployment target, a locked dependency graph and the seven explicitly selected upstream default features. Network access is denied to the build and its descendants. Cargo completes one fresh release build, producing ARM64 static and dynamic libraries; the five inspection/version probes pass and `wgpuGetVersion` returns `29.0.1.1`. The archive SHA-256 is `786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883`.

The generated bindings contain 115 size, 115 alignment and 522 field-offset assertions enforced at compilation. These are compile-time constants, not runtime layout tests. The observed Cargo output records 103 compiler units, 18 build-script results and 80 distinct package IDs. The component inventory includes declared license expressions and candidate notice files; it does not complete the native/Rust standard-library or redistribution audit.

The private Go 1.27.2 consumer builds three ARM64 executables using a replacement module containing only the accepted static archive and unchanged Go linkage files. All 13 build/inspection/version commands pass with empty compiler/linker stderr. Each linkmap identifies 141 entries from that archive; none of the executables loads a WGPU dylib. The Go version probe returns `29.0.1.1`.

Two serial headless processes then pass nine existing native GPU test roots and 23 subtests: RGBA upload rows, texture ownership/readback, storage mapping and retry, shader/binding ownership and failure recovery, integer compositing, shared-drawer order/fallback, text/paths, covered clears, and checked input-write refusal/recovery. The invalid shader and three duplicate-binding diagnostics are expected negative cases with checked recovery. Both processes finish with complete streams and recorded process-group absence. These checks create no windows or surfaces and generate no physical input.

The first consumer attempt remains failed. Its version executable compiled, but the validator tried to decode raw literal-string bytes in Apple's linkmap as UTF-8. It stopped before version execution or GPU tests. A separate linker warning showed the Go 1.27 object minimum was macOS 13.0 while that first consumer recipe requested 11.0. The corrected consumer uses a fresh directory and macOS 13.0 target, checks the strict UTF-8 object table separately from the bounded raw symbol data, and inspects each executable's load commands. The Rust archive's 11.0 declaration remains separate; older macOS runtime compatibility is unqualified.

Both Rust `rust-objcopy` warnings are retained: its debug-stripping subprocess could not load `@rpath/libLLVM.dylib` and aborted. Cargo and all artifact probes exited successfully, but this is not a warning-free or proven stripped build. No toolchain defaults or installed libraries were changed. Earlier offline analysis and validator-control mistakes, and the pre-execution receipt-ordering correction, are preserved with dispositions.

Internal reviews precede the source build, consumer builds and headless GPU execution, and independently reconcile terminal results. A scoped Prism review using Anthropic Claude Sonnet 5.5 is planned for these producers, controls and claims; its outcome will be recorded separately before commit. The evidence retains raw streams, owned process-group retirement, input hashes, recipes, controls and failed attempts. Principal executable/library/source-archive bytes are fingerprinted exclusions; compiler caches and remaining dependency artifacts are outside the report bundle. Saved producers retain their original absolute paths and are not portable replay tooling.

The source-built artifacts remain private candidates. No installed Go module library, Vellum runtime source or SDK package is replaced. This establishes the recorded build and consumer results only; it does not reproduce the upstream release binary or establish its executed compiler. Complete component/rights closure, SDK adoption, presentation, physical input/displays, ordinary performance, native/GPU memory, endurance, signing/notarization and full macOS acceptance remain open.

## Evidence packager report.py

```python
"""Bundle the exact reviewed private experiment and prepare eight documentation files."""
from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
R=Path(__file__).resolve().parent;W=R.parent/'macos-source-built-gpu-276a654';P=Path('/private/tmp/vellum-source-built-gpu-276a654');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='276a6543727bf12183c7a0acf52321a2ae82138a'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
review=read(W/'consumer-v2-result-review.json');need((review.get('results_ready')or review.get('result_accepted')or review.get('result_ready'))and not review['unresolved_findings']and all(sha(p)==h for p,h in review['inputs'].items()),'stable accepted native result')
provider=read(R/'prism/receipt.json');need(provider['result']=='COMPLETE_SCOPED_PROVIDER_REVIEW'and provider['error']is None and not provider['finalization_errors']and provider['findings']==0,'complete zero-finding provider checkpoint')
raw_provider=read(R/'prism/prism.json');need(sha(R/'prism/prism.json')==provider['report_sha256']and raw_provider['coverage']==provider['coverage'],'exact raw provider report/coverage');need(not raw_provider['findings']and not raw_provider.get('discarded',[])and not raw_provider.get('suppressed',[])and all(v==0 for v in raw_provider['summary']['counts'].values()),'zero raw findings, discarded and suppressed buckets')
for root in [C,T]:need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20),'clean source before documentation')
need(not(R/'evidence.tar.xz').exists()and not(R/'draft').exists(),'fresh report outputs');files={};omitted={}
def add(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'regular evidence '+str(p));data=p.read_bytes();need(len(data)<=32<<20,'per-file evidence bound');files['origins/'+str(p).lstrip('/')]=data
 need(sum(map(len,files.values()))<=256<<20,'total expanded evidence bound')
def omit(path):
 p=Path(path);need(p.is_file()and not p.is_symlink(),'regular omitted artifact');omitted[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
for root in [W,R]:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   need(p.suffix in ['.py','.json','.md']or p.parent==R/'prism'and p.name in ['stdout','stderr'],'known controller evidence');add(p)
for p in sorted(P.iterdir()):
 if p.is_file():
  if p.name=='stop-build-v1':need(p.stat().st_size==0,'sealed source-build stop');continue
  if p.name.endswith('.tar.gz'):omit(p)
  else:need(p.suffix in ['.json','.jsonl'],'known source metadata');add(p)
 elif p.name in ['source','cargo-home','target','build-target-v1','consumer-v1','consumer-v2']:continue
 else:
  need(p.name in ['rustc-version','cargo-version','fetch','prepare-deployment-target','prepare-clang-version','prepare-network-denial','prepare-metadata','rust-build-v1','probe-static-arch','probe-dynamic-arch','probe-dynamic-links','probe-dynamic-load-commands','probe-version'],'known command root')
  for f in p.iterdir():need(f.is_file()and f.name in ['stdout','stderr','owned.json'],'bounded command record');add(f)
for variant in ['consumer-v1','consumer-v2']:
 q=P/variant
 for p in sorted(q.iterdir()):
  if p.is_file():
   if p.name in ['version-probe','gpu.test','scene.test']:omit(p)
   elif p.name=='stop-build'or p.name=='stop-native':continue
   else:need(p.name in ['consumer.mod','consumer.sum','version.linkmap','gpu.linkmap','scene.linkmap'],'known consumer file');add(p)
  elif p.name in ['go-cache','go-tmp']:continue
  elif p.name=='libs-darwin':
   add(p/'go.mod');add(p/'libs.go');omit(p/'arm64/libwgpu_native.a')
  elif p.name=='version':add(p/'main.go')
  else:
   need(p.name in ['go-version','go-packages','build-version','build-gpu','build-scene','version-links','version-metadata','version-load-commands','gpu-links','gpu-metadata','gpu-load-commands','scene-links','scene-metadata','scene-load-commands','static-version','native-gpu','native-scene'],'known consumer command')
   for f in p.iterdir():need(f.is_file()and f.name in ['stdout','stderr','owned.json'],'owned consumer command record');add(f)
for name in ['Cargo.toml','Cargo.lock','build.rs','.gitmodules','LICENSE.MIT','LICENSE.APACHE','ffi/wgpu.h','ffi/webgpu-headers/webgpu.h']:add(P/'source'/name)
built=read(W/'build-receipt.json')
for a in built['artifacts']:omit(a['path'])
for a in built['generated_bindings']:add(a['path'])
for p in [R.parent/'macos-sdk-native-238b3b6/run.py',T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]:add(p)
manifest={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(files.items())}
with(R/'evidence.tar.xz').open('xb')as raw:
 with lzma.LZMAFile(raw,'w',preset=7)as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT)as archive:
   for name,data in sorted(files.items()):
    m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.mtime=0;archive.addfile(m,io.BytesIO(data))
need((R/'evidence.tar.xz').stat().st_size<=32<<20,'compressed report bound')
with tarfile.open(R/'evidence.tar.xz','r:xz')as archive:
 need([m.name for m in archive]==sorted(manifest),'exact archive members')
 for member in archive:
  need(member.isfile(),'regular archive member');data=archive.extractfile(member).read();need(len(data)==manifest[member.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256'],'archive roundtrip')
with(R/'evidence.manifest.json').open('x')as out:out.write(json.dumps(manifest,indent=2)+'\n')
native=read(W/'consumer-v2-native.json');result=dict(schema='vellum-private-source-built-gpu-consumer-v1',source_commit=HEAD,wgpu_commit=built['source_commit'],headers_commit='673658bc2bd70ec39fc55ebe6bb0173cf6d0a603',rust_compiler='1.99.0',go_compiler='1.27.2',rust_declared_minimum_macos='11.0',go_consumer_declared_minimum_macos='13.0',runtime_older_macos_qualified=False,abi_constant_checks=dict(size=115,alignment=115,offset=522),rust_compiled_packages=80,rust_compiler_units=103,native=native['validation'],expected_negative_api_stderr=True,rust_stripping_warnings=2,first_consumer_attempt_failed=True,installed_library_changed=False,framework_runtime_source_changed=False,sdk_changed=False,complete_native_component_rights_qualified=False,performance_memory_presentation_physical_macos_qualified=False,release_binary_reproduced=False,result_review_sha256=sha(W/'consumer-v2-result-review.json'),prism=dict(provider='anthropic',model='claude-sonnet-5-5',calls=1,complete=True,findings=0,report_sha256=provider['report_sha256']),archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz'),members=len(manifest),expanded_bytes=sum(v['bytes']for v in manifest.values())),fingerprinted_exclusions=omitted,compiler_caches_and_other_dependency_artifacts_outside_bundle=True)
with(R/'result.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
report='docs/reports/macos-source-built-gpu';text=(R/'README.review.md').read_text().replace('A scoped Prism review using Anthropic Claude Sonnet 5.5 is planned for these producers, controls and claims; its outcome will be recorded separately before commit.','One complete Prism review using Anthropic Claude Sonnet 5.5 covers the thirteen submitted producers/controls and these claims, returning zero findings. The payload and coverage record are retained.')
text=text.replace('\n\nThis checkpoint','\n\n[Qualification](result.json) and [the evidence index](evidence.manifest.json) identify [the retained bundle](evidence.tar.xz).\n\nThis checkpoint',1)
new={report+'/README.md':text.encode(),report+'/result.json':(R/'result.json').read_bytes(),report+'/evidence.manifest.json':(R/'evidence.manifest.json').read_bytes(),report+'/evidence.tar.xz':(R/'evidence.tar.xz').read_bytes()}
paragraph='''The [pinned-source GPU consumer checkpoint](reports/macos-source-built-gpu/README.md)
builds the exact WGPU source/header commits with recorded Rust/compiler/features,
then passes private static-only Go consumers and nine headless GPU roots with
23 subtests. Two Rust stripping warnings and the failed initial consumer attempt
remain preserved. The candidate is not adopted into installed libraries or the
SDK; complete component/rights closure, broader native UI/presentation, older
macOS runtime, performance/memory/endurance and full Mac release remain open.
'''
p='docs/implementation.md';new[p]=((T/p).read_text()+'\n'+paragraph).encode()
p='docs/reports/README.md';old=(T/p).read_text();needle='The [implementation status](../implementation.md) describes the current framework.\n';need(old.count(needle)==1,'report index anchor');new[p]=old.replace(needle,needle+'\n- [Pinned-source GPU consumer](macos-source-built-gpu/README.md)\n',1).encode()
p='specs/macos-completion.md';old=(T/p).read_text();needle='## Latest unattended evidence\n';need(old.count(needle)==1,'completion anchor');new[p]=old.replace(needle,needle+'\n'+paragraph.replace('(reports/','(../docs/reports/'),1).encode()
p='specs/release.md';old=(T/p).read_text();needle='## Alpha.2 window lifetime migration\n';need(old.count(needle)==1,'release anchor');new[p]=old.replace(needle,'## Private source-built GPU consumer\n\n'+paragraph.replace('(reports/','(../docs/reports/')+'\n'+needle,1).encode()
D=R/'draft';D.mkdir(mode=0o700)
for name,data in new.items():p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
binding=dict(base_commit=HEAD,draft_root=str(D),sources={name:hashlib.sha256(data).hexdigest()for name,data in new.items()},old={name:sha(T/name)if(T/name).exists()else None for name in new},source_files_after=4712,prepared_files=6249,prism_sha256=sha(R/'prism/prism.json'))
with(R/'draft-binding.json').open('x')as out:out.write(json.dumps(binding,indent=2)+'\n')
print(json.dumps(dict(result='PREPARED_SOURCE_BUILT_GPU_CHECKPOINT_DOCS',files=len(new),archive=result['archive'])))

```
