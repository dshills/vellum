"""One complete Anthropic checkpoint review; provider output is separate from native evidence."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W.parent/'macos-source-built-gpu-276a654';O=W/'prism'
s=importlib.util.spec_from_file_location('source_gpu_prism_ownership',B/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g,sha,read,need=f.g,f.sha,f.read,f.need
binary=Path('/Users/dshills/Development/Go/bin/prism');need(sha(binary)=='5575dd1fc360a719a32f27e49a5a208ba60ff810957e20cf7d19322c54eaf285','pinned Prism binary')
review=read(B/'consumer-v2-result-review.json');need((review.get('results_ready')or review.get('result_accepted')or review.get('result_ready'))and not review['unresolved_findings'],'independent terminal result review')
ready=read(W/'prism-readiness.json');need(ready['execution_ready']and not ready['unresolved_findings'],'separate exact provider payload review');pins=ready['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());payload=W/'prism-payload.md';need(stable()and 0<payload.stat().st_size<80000 and not O.exists(),'new exact provider review');O.mkdir(mode=0o700)
argv=[str(binary),'review','snippet','--path','vellum-source-built-gpu-checkpoint.md','--lang','text','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','5','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','80000','--max-diff-bytes','80000','--rules',str(W/'prism-rules.json'),'--format','json','--out',str(O/'prism.json')]
env=os.environ.copy();env.update(GOENV='off',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly -p=1',GOMAXPROCS='2',PYTHONDONTWRITEBYTECODE='1')
d=dict(result='INCOMPLETE',provider='anthropic',model='claude-sonnet-5-5',argv=argv,payload_bytes=payload.stat().st_size,payload_sha256=sha(payload),producer_sha256=sha(__file__),binary_sha256=sha(binary),readiness_sha256=sha(W/'prism-readiness.json'),error=None,finalization_errors=[],exit_code=None,created=False,owned=None);child=None;start=time.monotonic()
try:
 with payload.open('rb')as source,(O/'stdout').open('xb')as stdout,(O/'stderr').open('xb')as stderr:
  need(stable(),'final provider admission');child=subprocess.Popen(argv,cwd=W,env=env,stdin=source,stdout=stdout,stderr=stderr,start_new_session=True);d.update(created=True,pid=child.pid,group=child.pid)
  with(O/'owned.json').open('x')as out:out.write(json.dumps(dict(pid=child.pid,group=child.pid,argv=argv,payload_sha256=d['payload_sha256']),indent=2)+'\n')
  while child.poll()is None:
   need(time.monotonic()-start<=240,'provider watchdog');need(all((O/n).stat().st_size<=8<<20 for n in ['stdout','stderr']),'provider stream bounds');time.sleep(.1)
  d['exit_code']=child.wait(timeout=5)
except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
finally:
 d['owned']=g.retire(child)
 try:
  need(d['error']is None and d['exit_code']in[0,1]and d['owned']['terminal']and d['owned']['group_absent']and not d['owned']['errors']and stable(),'terminal provider ownership/source');d['logs']={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']};need(all(v['bytes']<=8<<20 for v in d['logs'].values()),'terminal stream bounds');report=read(O/'prism.json');coverage=report['coverage'];need(coverage['complete']is True and coverage['truncatedBytes']==0 and not coverage['skipped']and not coverage['excluded']and coverage['chunks']==1 and coverage['llmCalls']==1 and coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}],'complete exact one-call provider coverage');d.update(result='COMPLETE_SCOPED_PROVIDER_REVIEW',findings=len(report['findings']),coverage=coverage,report_sha256=sha(O/'prism.json'))
 except BaseException as error:
  if d['error']is None:d['error']=dict(type=type(error).__name__,message=str(error))
  d['result']='FAILED_OR_INCOMPLETE_PROVIDER_REVIEW'
 d.update(seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 try:print(json.dumps({**d,'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
 except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));d['result']='FAILED_OR_INCOMPLETE_PROVIDER_REVIEW'
 try:
  with(O/'receipt.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
 except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));d['result']='FAILED_OR_INCOMPLETE_PROVIDER_REVIEW'
need(d['error']is None and not d['finalization_errors'],'provider review failed')
