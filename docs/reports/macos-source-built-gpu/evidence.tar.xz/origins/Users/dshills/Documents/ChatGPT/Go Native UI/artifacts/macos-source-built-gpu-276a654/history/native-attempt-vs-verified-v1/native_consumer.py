"""Two explicitly admitted headless GPU consumer fixtures; no native windows or physical input."""
from pathlib import Path
import datetime,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('private_static_gpu_consumer',W/'consumer.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
Q=c.Q;g,sha,read,need=c.g,c.sha,c.read,c.need

def validate(label,stdout):
 text=stdout.decode('utf-8');lines=text.splitlines();runs=[line.split()[2]for line in lines if line.startswith('=== RUN   ')and'/'not in line.split()[2]];passes=[line.split()[2]for line in lines if line.startswith('--- PASS: ')and'/'not in line.split()[2]];expected=c.ROOTS[label]
 need(len(runs)==len(set(runs))==len(expected)and set(runs)==set(expected),'exact native root execution');need(len(passes)==len(set(passes))==len(expected)and set(passes)==set(expected),'exact native root passes');need(text.rstrip().endswith('\nPASS')and not any(marker in text for marker in['--- SKIP:','--- FAIL:','FAIL\n','panic:']),'all admitted tests pass without skip or panic')
 subruns=[line.split()[2]for line in lines if line.startswith('=== RUN   ')and'/'in line.split()[2]];subpasses=[line.split()[2]for line in lines if line.lstrip().startswith('--- PASS: ')and'/'in line.split()[2]]
 need(len(subruns)==len(set(subruns))and sorted(subruns)==sorted(subpasses),'all subtests terminal and unique')
 return dict(roots=sorted(runs),root_count=len(runs),subtests=len(subruns),gpu_execution_and_readback=True,windows_created=0,surfaces_created=0,physical_input_verified=False,performance_qualified=False,native_memory_qualified=False)

def main():
 need(len(sys.argv)==1,'no runtime overrides');review=read(W/'consumer-native-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'independent headless execution readiness');build=read(W/'consumer-build.json');need(build['result']=='PASS_PRIVATE_STATIC_GO_BUILD_AND_VERSION_NO_GPU_EXECUTION'and not build['error']and not build['finalization_errors'],'successful static-only consumer build');need(not(W/'consumer-native.json').exists()and not(Q/'stop-native').exists(),'fresh one-shot consumer native destination')
 pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:c.STOP.exists()or(Q/'stop-native').exists();d=dict(result='INCOMPLETE',inputs=pins,commands=[],validation=[],error=None,finalization_errors=[],shipped_library_changed=False,native_windows_started=False,physical_input_generated=False,gpu_executed=False)
 try:
  need(stable()and not stopping(),'headless consumer admission')
  with g.LiveLease()as lease:
   need(lease.held(),'exclusive test-machine lease')
   for label in ['gpu','scene']:
    entry=[b for b in build['binaries']if b['label']==label];need(len(entry)==1,'one binary per consumer');binary=entry[0];need(sha(binary['path'])==binary['sha256'],'exact source-linked test binary');env=['GOMAXPROCS=2']+(['VELLUM_TEXTURE_GPU_TEST=1','VELLUM_STORAGE_GPU_TEST=1','VELLUM_PIPELINE_GPU_TEST=1']if label=='gpu'else['VELLUM_GPU_SCENE_TEST=1']);argv=['/usr/bin/env',*env,binary['path'],'-test.v','-test.run=^('+'|'.join(c.ROOTS[label])+')$','-test.count=1','-test.timeout=120s'];out=Q/('native-'+label)
    run=g.execute(argv,Q,out,stopping,stable,timeout=180,limit=8<<20);d['commands'].append(dict(label=label,run=run));d['gpu_executed']=d['gpu_executed']or run['created'];need(c.f.terminal(run),'owned headless GPU consumer '+label);d['validation'].append(dict(label=label,**validate(label,(out/'stdout').read_bytes())))
   need(stable()and not stopping()and lease.held(),'terminal source/linkage/lease');d['lease_held_through_cleanup']=True;d['result']='PASS_SOURCE_BUILT_STATIC_GO_HEADLESS_GPU_CONSUMERS'
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
 finally:
  try:(Q/'stop-native').touch()
  except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  try:print(json.dumps({**{k:v for k,v in d.items()if k not in ['inputs','commands']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
  except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
  try:
   with(W/'consumer-native.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));d['result']='FAILED_OR_CANCELED_HEADLESS_GPU_CONSUMER'
 need(d['error']is None and not d['finalization_errors'],'native consumer failed')
if __name__=='__main__':main()
