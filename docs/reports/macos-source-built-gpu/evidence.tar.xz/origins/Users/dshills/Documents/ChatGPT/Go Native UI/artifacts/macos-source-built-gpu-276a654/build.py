"""One source build and artifact/version probes; no SDK or native app adoption."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
s=importlib.util.spec_from_file_location('source_gpu_build_utilities',W/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g=f.g;need=f.need;sha=f.sha;read=f.read

def validate_build_messages(messages,plan):
 need(messages and all(isinstance(m,dict)and m.get('reason')in['compiler-artifact','build-script-executed','compiler-message','build-finished']for m in messages),'Cargo JSON message protocol')
 finished=[m for m in messages if m['reason']=='build-finished'];need(len(finished)==1 and finished[0].get('success')is True and messages[-1]is finished[0],'exact successful Cargo terminal message')
 roots=[m for m in messages if m['reason']=='compiler-artifact'and m['package_id']==plan['root_package_id']and set(m['target']['kind'])=={'cdylib','staticlib'}]
 need(len(roots)==1,'one root library artifact');root=roots[0]
 need(set(root['features'])==set(plan['resolved_root_features'])and root['fresh']is False and root['profile']['opt_level']=='3'and root['profile']['test']is False,'fresh release root and exact resolved features')
 expected={str(P/'build-target-v1'/plan['target']/'release'/name)for name in['libwgpu_native.a','libwgpu_native.dylib']};need(set(root['filenames'])==expected,'two exact root output paths')
 return root

def validate_version(value):need(type(value.get('version'))is int and value['version']==0x1d000101,'source-built version API identity')

def finalize(d):
 d['finalization_errors']=[]
 def status():d['result']='PASS_OWN_PINNED_SOURCE_WGPU_BUILD_AND_PROBES'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_PINNED_SOURCE_WGPU_BUILD'
 try:(P/'stop-build-v1').touch();d['local_stop_present']=True
 except BaseException as error:d['finalization_errors'].append(dict(stage='seal',type=type(error).__name__))
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();status()
 try:print(json.dumps({**{k:v for k,v in d.items()if k not in['run','probes','inputs','messages']},'result':'PENDING_EXCLUSIVE_RECEIPT'}),flush=True)
 except BaseException as error:d['finalization_errors'].append(dict(stage='report',type=type(error).__name__));status()
 try:
  with(W/'build-receipt.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
 except BaseException as error:d['finalization_errors'].append(dict(stage='exclusive-receipt',type=type(error).__name__));status()
 return d

def main():
 need(len(sys.argv)==1,'no runtime overrides');plan=read(W/'build-plan.json');review=read(W/'build-readiness.json');need(review['execution_ready']is True and not review['unresolved_findings'],'separate source build readiness review')
 need(not any(p.exists()for p in[W/'build-receipt.json',P/'rust-build-v1',P/'stop-build-v1',P/'build-target-v1']),'new one-shot build destinations')
 pins=review['inputs'];configs=list(map(Path,plan['configuration_paths_required_absent']))
 stable=lambda:all(sha(p)==h for p,h in pins.items())and all(not p.exists()for p in configs)and all(str(Path(v['path']).resolve())==v['resolved']for v in plan['tool_identities'])
 last_check=0.;max_bytes=0
 def stopping():
  nonlocal last_check,max_bytes
  if STOP.exists()or(P/'stop-build-v1').exists():return True
  now=time.monotonic()
  if now-last_check>=1:
   last_check=now;size=0
   for p in(P/'build-target-v1').rglob('*'):
    need(not p.is_symlink(),'build target symlink')
    if p.is_file():
     try:size+=p.stat().st_size
     except FileNotFoundError:pass
   max_bytes=max(max_bytes,size);need(size<=4<<30,'four GiB build-target bound')
  return False
 def clean():
  for root in(C,T):
   need(g.run_child(['git','rev-parse','HEAD'],cwd=root,capture_output=True,check=True,timeout=20).stdout.decode().strip()==plan['framework_head']and not g.run_child(['git','status','--porcelain','-z'],cwd=root,capture_output=True,check=True,timeout=20).stdout,'clean framework source boundary')
 d=dict(result='INCOMPLETE',source_commit=plan['source_commit'],framework_head=plan['framework_head'],source_build_attempted=False,native_application_started=False,shipped_library_changed=False,toolchain_defaults_changed=False,release_binary_reproduced=False,upstream_executed_compiler_proven=False,older_macos_runtime_qualified=False,ordinary_performance_qualified=False,producer_sha256=sha(__file__),review_sha256=sha(W/'build-readiness.json'),inputs=pins,run=None,probes=[],error=None)
 try:
  need(stable()and not stopping(),'build admission');clean()
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping(),'shared test-machine lease')
   run=g.execute(plan['build_argv'],P/'source',P/'rust-build-v1',stopping,stable,timeout=1200,limit=16<<20);d['run']=run;d['source_build_attempted']=run['created'];need(f.terminal(run),'bounded successful owned Rust build')
   messages=[json.loads(line)for line in(P/'rust-build-v1/stdout').read_bytes().splitlines()];root=validate_build_messages(messages,plan);d['root_artifact_message']=root
   artifacts=[]
   for name in root['filenames']:
    p=Path(name);need(p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=512<<20,'bounded root artifact');artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)));pins[str(p)]=sha(p)
   generated=[]
   for message in messages:
    if message['reason']=='build-script-executed'and message['package_id']==plan['root_package_id']:
     out=Path(message['out_dir']);need(out.is_relative_to(P/'build-target-v1'),'root generated binding location')
     p=out/'bindings.rs';need(p.is_file()and not p.is_symlink()and 0<p.stat().st_size<8<<20,'bounded generated ABI bindings');generated.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
   need(len(generated)==1,'one generated root ABI binding');d['generated_bindings']=generated;d['artifacts']=artifacts
   d['compiler_artifact_units']=[m for m in messages if m['reason']=='compiler-artifact'];d['build_script_outputs']=[m for m in messages if m['reason']=='build-script-executed']
   dylib=str(P/'build-target-v1'/plan['target']/'release/libwgpu_native.dylib');library=str(P/'build-target-v1'/plan['target']/'release/libwgpu_native.a')
   version_probe="import ctypes,json;lib=ctypes.CDLL("+repr(dylib)+");fn=lib.wgpuGetVersion;fn.argtypes=[];fn.restype=ctypes.c_uint32;print(json.dumps({'version':int(fn())}))"
   commands=[('static-arch',['/usr/bin/lipo','-archs',library]),('dynamic-arch',['/usr/bin/lipo','-archs',dylib]),('dynamic-links',['/usr/bin/otool','-L',dylib]),('dynamic-load-commands',['/usr/bin/otool','-l',dylib]),('version',['/usr/bin/sandbox-exec','-p',plan['network_sandbox_profile'],str(Path(sys.executable).resolve()),'-I','-c',version_probe])]
   for label,argv in commands:
    probe=g.execute(argv,P/'source',P/('probe-'+label),stopping,stable,timeout=45,limit=2<<20);d['probes'].append(dict(label=label,run=probe));need(f.terminal(probe),'bounded artifact probe '+label)
   need((P/'probe-static-arch/stdout').read_text().strip()=='arm64'and(P/'probe-dynamic-arch/stdout').read_text().strip()=='arm64','both artifacts ARM64')
   links=(P/'probe-dynamic-links/stdout').read_text();need('@rpath/libwgpu_native.dylib'in links,'declared dylib install name')
   validate_version(read(P/'probe-version/stdout'));d['native_version_probe_executed']=True
   clean();need(stable()and not stopping()and lease.held(),'terminal source/compiler/artifacts/configuration/lease');d['lease_held_through_cleanup']=True;d['max_observed_target_bytes']=max_bytes
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:finalize(d)
 need(d['error']is None and not d['finalization_errors'],'source build/probes failed or canceled')
if __name__=='__main__':main()
