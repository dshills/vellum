from pathlib import Path
import hashlib,json,re,os
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');b=json.loads((W/'draft-binding.json').read_bytes());D=Path(b['draft_root']);checked=[]
for name,h in b['sources'].items():
 p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 if p.suffix!='.md':continue
 for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  target=match[1].split('#',1)[0]
  if not target or re.match(r'^[a-z]+:',target):continue
  resolved=Path(os.path.normpath(str(Path(name).parent/target)))
  exists=(D/resolved).exists()or(T/resolved).exists()
  assert exists,(name,target)
  checked.append({'source':name,'target':target})
(W/'doc-checks.json').write_text(json.dumps({'result':'PASS_DRAFT_RELATIVE_LINKS_AND_HASHES','relative_links':len(checked),'links':checked},indent=2)+'\n');print(json.dumps({'result':'PASS_DRAFT_RELATIVE_LINKS_AND_HASHES','relative_links':len(checked)}))
