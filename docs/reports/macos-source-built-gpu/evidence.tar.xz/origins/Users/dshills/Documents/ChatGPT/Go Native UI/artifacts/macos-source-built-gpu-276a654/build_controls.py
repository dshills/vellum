from pathlib import Path
import copy,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('source_build_validation_controls',W/'build.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=json.loads((W/'build-plan.json').read_bytes());root=dict(reason='compiler-artifact',package_id=p['root_package_id'],target=dict(kind=['cdylib','staticlib']),features=p['resolved_root_features'],fresh=False,profile=dict(opt_level='3',test=False),filenames=[str(m.P/'build-target-v1'/p['target']/'release'/name)for name in['libwgpu_native.a','libwgpu_native.dylib']]);valid=[root,dict(reason='build-finished',success=True)];results=[]
def check(label,fn,pass_=False):
 try:fn();ok=True
 except ValueError:ok=False
 assert ok==pass_,label
 results.append(dict(name=label,pass_=True))
check('fresh root accepted',lambda:m.validate_build_messages(valid,p),True)
for label,path,value in [('cached root refused',['fresh'],True),('missing feature refused',['features'],[]),('debug root refused',['profile','opt_level'],'0'),('test root refused',['profile','test'],True),('wrong artifact directory refused',['filenames'],['/other/libwgpu_native.a']),('wrong root package refused',['package_id'],'foreign')]:
 changed=copy.deepcopy(valid);cursor=changed[0]
 for key in path[:-1]:cursor=cursor[key]
 cursor[path[-1]]=value;check(label,lambda changed=changed:m.validate_build_messages(changed,p))
check('missing terminal refused',lambda:m.validate_build_messages(valid[:-1],p))
check('duplicate terminal refused',lambda:m.validate_build_messages(valid+[valid[-1]],p))
check('failed terminal refused',lambda:m.validate_build_messages([root,dict(reason='build-finished',success=False)],p))
check('duplicate root refused',lambda:m.validate_build_messages([root,root,valid[-1]],p))
check('version accepted',lambda:m.validate_version({'version':0x1d000101}),True)
check('unset version refused',lambda:m.validate_version({'version':0}))
check('string version refused',lambda:m.validate_version({'version':str(0x1d000101)}))
r=dict(result='PASS_SOURCE_BUILD_ARTIFACT_VERSION_CONTROLS',native_application_started=False,controls=results)
with(W/'build-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
