from pathlib import Path
import gzip,hashlib,importlib.util,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('source_archive_controls',W/'source.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
body=b'fixed source\n';entry=dict(path='src/a.rs',type='blob',mode='100644',size=len(body),sha=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest());tree=dict(tree=[entry]);results=[]
def archive(items):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w')as t:
  for name,data,kind in items:
   info=tarfile.TarInfo(name);info.type=kind;info.size=len(data)if kind==tarfile.REGTYPE else 0;info.linkname='../../escape';t.addfile(info,io.BytesIO(data)if info.size else None)
 return gzip.compress(out.getvalue())
def check(label,data,expected=True):
 try:r=m.validate_archive(data,tree,'root');passed=True
 except ValueError:passed=False
 assert passed==expected,label
 if expected:assert r=={'src/a.rs':body}
 results.append(dict(name=label,pass_=True))
valid=[('root/src/a.rs',body,tarfile.REGTYPE)]
check('exact pinned source',archive(valid))
check('traversal source refused',archive([('root/../../escape',body,tarfile.REGTYPE)]),False)
check('extra source refused',archive(valid+[('root/extra',body,tarfile.REGTYPE)]),False)
check('duplicate source refused',archive(valid+valid),False)
check('changed source refused',archive([('root/src/a.rs',b'x'*len(body),tarfile.REGTYPE)]),False)
check('missing source refused',archive([]),False)
check('source symlink refused',archive([('root/src/a.rs',b'',tarfile.SYMTYPE)]),False)
check('source hardlink refused',archive([('root/src/a.rs',b'',tarfile.LNKTYPE)]),False)
check('absolute source refused',archive([('/root/src/a.rs',body,tarfile.REGTYPE)]),False)
check('expansion bound refuses compressed bomb',gzip.compress(b'x'*(m.LIMIT+1)),False)
r=dict(result='PASS_PINNED_SOURCE_ARCHIVE_CONTROLS',source_code_executed=False,native_runtime_executed=False,controls=results)
with(W/'source-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
