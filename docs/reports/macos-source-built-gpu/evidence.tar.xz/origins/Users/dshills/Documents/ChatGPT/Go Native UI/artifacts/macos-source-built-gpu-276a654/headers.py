"""Bind root/header Git trees to exact commit metadata and verify source ABI bytes."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,re,sys,time,urllib.parse,urllib.request
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('pinned_gpu_source',W/'source.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
P=m.P;need=m.need;sha=m.sha
HEADER='673658bc2bd70ec39fc55ebe6bb0173cf6d0a603'
GO=Path('/Users/dshills/Development/Go/pkg/mod/github.com/oliverbestmann/webgpu@v1.36.1-0.20261006093257-de8bdd5d5976/wgpu/lib/darwin/arm64')
def fetch_json(repo,kind,revision,name,recursive=False):
 need(repo in['gfx-rs/wgpu-native','webgpu-native/webgpu-headers']and kind in['commits','trees']and re.fullmatch('[a-f0-9]{40}',revision),'fixed public Git metadata')
 url='https://api.github.com/repos/'+repo+'/git/'+kind+'/'+revision+('?recursive=1'if recursive else'')
 start=time.monotonic();request=urllib.request.Request(url,headers={'User-Agent':'Vellum-pinned-source-build','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(request,timeout=15)as response:
  need(urllib.parse.urlparse(response.url).netloc=='api.github.com','public Git metadata redirect');data=response.read((2<<20)+1);need(len(data)<=2<<20,'Git metadata byte bound')
 with(P/name).open('xb')as out:out.write(data)
 value=json.loads(data);need(value['sha']==revision,'exact Git object identity')
 with(P/(name+'.receipt.json')).open('x')as out:out.write(json.dumps(dict(url=url,bytes=len(data),sha256=sha(data),seconds=time.monotonic()-start),indent=2)+'\n')
 return value

def main():
 need(not(W/'headers-receipt.json').exists()and not(P/'source/ffi/webgpu-headers').exists(),'fresh header source')
 root_commit=fetch_json('gfx-rs/wgpu-native','commits',m.COMMIT,'root-commit.json')
 root_tree=fetch_json('gfx-rs/wgpu-native','trees',root_commit['tree']['sha'],'root-tree.json',True)
 need(root_tree['truncated']is False,'complete root Git tree')
 cached=json.loads((m.D/'source-tree.json').read_bytes())
 vector=lambda t:{e['path']:{k:e[k]for k in['mode','type','sha']}for e in t['tree']}
 need(vector(root_tree)==vector(cached),'saved complete root tree matches actual commit tree')
 gitlinks={e['path']:e for e in root_tree['tree']if e['type']=='commit'};need(gitlinks['ffi/webgpu-headers']['sha']==HEADER,'pinned header Gitlink')
 need('url = https://github.com/webgpu-native/webgpu-headers' in(P/'source/.gitmodules').read_text(),'declared header repository')
 header_commit=fetch_json('webgpu-native/webgpu-headers','commits',HEADER,'headers-commit.json')
 header_tree=fetch_json('webgpu-native/webgpu-headers','trees',header_commit['tree']['sha'],'headers-tree.json',True);need(header_tree['truncated']is False,'complete header Git tree')
 downloaded=m.download('https://codeload.github.com/webgpu-native/webgpu-headers/tar.gz/'+HEADER,P/'headers-source.tar.gz')
 contents=m.validate_archive((P/'headers-source.tar.gz').read_bytes(),header_tree,'webgpu-headers-'+HEADER)
 files=m.write_source(P/'source/ffi/webgpu-headers',contents)
 abi={}
 for name,source in [('wgpu.h',P/'source/ffi/wgpu.h'),('webgpu.h',P/'source/ffi/webgpu-headers/webgpu.h')]:
  body=source.read_bytes();need(body==(GO/name).read_bytes(),'byte-identical pinned Go ABI header '+name);abi[name]=dict(bytes=len(body),sha256=sha(body),source=str(source),go_binding_header=str(GO/name))
 r=dict(result='PINNED_ROOT_AND_HEADERS_COMMIT_TREES_AND_GO_ABI_VERIFIED',root_commit=m.COMMIT,root_tree=root_commit['tree']['sha'],headers_commit=HEADER,headers_tree=header_commit['tree']['sha'],files=files,download=downloaded,abi=abi,native_runtime_executed=False,source_code_executed=False,source_build_complete=False,scope='Exact source/blob/header identity only; no compiler, feature closure, binary correspondence or runtime result.')
 with(W/'headers-receipt.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items()if k!='files'}));print(json.dumps(dict(files=len(files))))
if __name__=='__main__':main()
