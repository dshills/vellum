"""Consumer validators reject dynamic linkage, mixed archives and missing version symbols."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('static_consumer_controls',W/'consumer_v2.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
module='/private/test/libs-darwin';object_line='[ 1] '+module+'/arm64/libwgpu_native.a(wgpu_native.o)\n';positive='# Object files:\n'+object_line+'# Sections:\n_wgpuGetVersion\n';checks=[]
def check(name,fn,reject):
 error=None
 try:fn()
 except ValueError as e:error=str(e)
 ok=bool(error)==reject
 if not ok:raise AssertionError(name)
 checks.append(dict(name=name,pass_=True,rejected=bool(error)))
check('private-static-map-admitted',lambda:c.validate_linkmap(positive,module),False)
for name,body in [('empty-map',''),('missing-version','# Object files:\n'+object_line+'# Sections:\n'),('dynamic-library',positive.replace('libwgpu_native.a(', 'libwgpu_native.dylib(')),('original-archive',positive.replace(module,'/original/module')),('mixed-archive',positive.replace('# Sections:', '[ 2] /other/libwgpu_native.a(native.o)\n# Sections:'))]:check(name,lambda body=body:c.validate_linkmap(body,module),True)
check('system-links-admitted',lambda:c.validate_links('/usr/lib/libSystem.B.dylib'),False)
for name,body in [('runtime-native-dylib','@rpath/libwgpu_native.dylib'),('archive-runtime-entry','/path/libwgpu_native.a')]:check(name,lambda body=body:c.validate_links(body),True)
check('raw-symbol-literals-admitted',lambda:c.validate_linkmap(positive.encode()+b'\xc0\xff',module),False)
check('nonutf8-object-table-rejected',lambda:c.validate_linkmap(positive.replace('# Object files:', '# Object files:\nBAD').encode().replace(b'BAD',b'\xff'),module),True)
check('missing-object-table-rejected',lambda:c.validate_linkmap(b'# Sections:\n_wgpuGetVersion',module),True)
r=dict(result='PASS',producer_sha256=c.sha(W/'consumer_v2.py'),checks=checks)
with(W/'consumer-v2-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(result=r['result'],checks=len(checks))))
