"""Fetch pinned public source; verify every Git blob before writing any source."""
from pathlib import Path, PurePosixPath
import datetime,gzip,hashlib,io,json,tarfile,time,urllib.parse,urllib.request
W=Path(__file__).resolve().parent
P=Path('/private/tmp/vellum-source-built-gpu-276a654')
D=W.parent/'macos-native-provenance/released-bytes-v1/release-source-declarations'
COMMIT='6aed50955d934ac36049ba8d002034841633ae02'
LIMIT=8<<20
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
def validate_archive(data,tree,prefix):
 need(len(data)<=LIMIT,'archive compressed byte bound')
 with gzip.GzipFile(fileobj=io.BytesIO(data))as source:raw=source.read(LIMIT+1)
 need(len(raw)<=LIMIT,'archive expanded byte bound')
 expected={e['path']:e for e in tree['tree']if e['type']=='blob'}
 need(expected and all(e['mode']in['100644','100755']and type(e['size'])is int and 0<=e['size']<=LIMIT for e in expected.values()),'regular bounded Git source blobs')
 directories={prefix}
 for e in tree['tree']:
  path=PurePosixPath(e['path']);need(not path.is_absolute()and '..'not in path.parts and str(path)==e['path'],'canonical Git path')
  if e['type']in['tree','commit']:directories.add(prefix+'/'+e['path'])
  for parent in path.parents:
   if str(parent)!='.':directories.add(prefix+'/'+str(parent))
 contents={};seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:')as archive:
  for index,member in enumerate(archive):
   need(index<512,'archive entry bound');name=member.name.rstrip('/')if member.isdir()else member.name
   need(name not in seen,'duplicate archive member');seen.add(name)
   if member.isdir():need(name in directories,'declared source directory');continue
   need(member.isfile()and name.startswith(prefix+'/'),'regular rooted source file')
   rel=name[len(prefix)+1:];need(rel in expected,'exact Git source membership');entry=expected[rel]
   need(member.size==entry['size'],'Git blob byte count');body=archive.extractfile(member).read(member.size+1)
   need(len(body)==member.size and hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==entry['sha'],'Git blob object identity')
   contents[rel]=body
 need(set(contents)==set(expected),'all pinned source blobs present')
 return contents

def download(url,destination):
 need(urllib.parse.urlparse(url).netloc=='codeload.github.com','fixed public archive host')
 start=time.monotonic();record=dict(url=url,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=None)
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'Vellum-pinned-source-build'})
  with urllib.request.urlopen(request,timeout=10)as response,destination.open('xb')as output:
   need(urllib.parse.urlparse(response.url).netloc=='codeload.github.com','archive redirect host');count=0
   while True:
    need(time.monotonic()-start<45,'source download deadline');chunk=response.read(64<<10)
    if not chunk:break
    count+=len(chunk);need(count<=LIMIT,'source download byte bound');need(output.write(chunk)==len(chunk),'source download short write')
  record.update(result='PUBLIC_SOURCE_ARCHIVE_FETCHED',bytes=count,sha256=sha(destination.read_bytes()))
 except BaseException as error:record.update(result='FAILED_PUBLIC_SOURCE_FETCH',error=dict(type=type(error).__name__,message=str(error)));raise
 finally:
  record['seconds']=time.monotonic()-start
  with destination.with_suffix(destination.suffix+'.receipt.json').open('x')as output:output.write(json.dumps(record,indent=2)+'\n')
 return record

def write_source(root,contents):
 need(not root.exists(),'fresh source destination');root.mkdir(mode=0o700)
 for name,body in sorted(contents.items()):
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb')as output:need(output.write(body)==len(body),'short source write')
 return {name:dict(bytes=len(body),sha256=sha(body))for name,body in sorted(contents.items())}

def main():
 tree=json.loads((D/'source-tree.json').read_bytes());need(tree['sha']==COMMIT and tree['truncated']is False,'pinned complete source tree')
 need(not(P/'main-source.tar.gz').exists()and not(P/'source').exists()and not(W/'source-receipt.json').exists(),'new one-shot source fetch')
 record=download('https://codeload.github.com/gfx-rs/wgpu-native/tar.gz/'+COMMIT,P/'main-source.tar.gz')
 contents=validate_archive((P/'main-source.tar.gz').read_bytes(),tree,'wgpu-native-'+COMMIT)
 files=write_source(P/'source',contents)
 d=dict(result='EXACT_PINNED_WGPU_SOURCE_BLOBS_VERIFIED',source_commit=COMMIT,download=record,files=files,gitlinks=[e for e in tree['tree']if e['type']=='commit'],native_runtime_executed=False,source_code_executed=False,compiler_provenance_established=False)
 with(W/'source-receipt.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:v for k,v in d.items()if k!='files'}));print(json.dumps(dict(files=len(files),bytes=sum(v['bytes']for v in files.values()))))
if __name__=='__main__':main()
