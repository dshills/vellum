from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('native_consumer_validator',W/'native_consumer.py');n=importlib.util.module_from_spec(s);s.loader.exec_module(n)
lines=[]
for root in n.c.ROOTS['gpu']:lines+=['=== RUN   '+root,'=== RUN   '+root+'/case','    --- PASS: '+root+'/case (0.01s)','--- PASS: '+root+' (0.01s)']
positive='\n'.join(lines)+'\nPASS\n';root=n.c.ROOTS['gpu'][0];cases={'positive':(positive,False),'missing-root':(positive.replace('=== RUN   '+root+'\n',''),True),'duplicate-root':(positive+'=== RUN   '+root+'\n',True),'unrelated-root':('=== RUN   TestOther\n'+positive,True),'skip':(positive+'--- SKIP: skipped\nPASS\n',True),'root-failure':(positive.replace('--- PASS: '+root+' (','--- FAIL: '+root+' ('),True),'missing-subtest-pass':(positive.replace('    --- PASS: '+root+'/case (0.01s)\n',''),True),'duplicate-subtest':(positive.replace('=== RUN   '+root+'/case\n',('=== RUN   '+root+'/case\n')*2),True),'missing-terminal':(positive[:-5],True),'panic':('panic: bad\n'+positive,True)};checks=[]
for name,(body,reject)in cases.items():
 error=None
 try:n.validate('gpu',body.encode())
 except ValueError as e:error=str(e)
 if bool(error)!=reject:raise AssertionError(name)
 checks.append(dict(name=name,pass_=True,rejected=bool(error)))
r=dict(result='PASS',producer_sha256=n.sha(W/'native_consumer.py'),checks=checks)
with(W/'native-consumer-controls.json').open('x')as out:out.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(result=r['result'],checks=len(checks))))
