"""Prove extracted Cargo source and freeze an explicit source-build recipe."""
from pathlib import Path
import gzip,hashlib,importlib.util,io,json,os,sys,tarfile,tomllib
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654')
s=importlib.util.spec_from_file_location('source_build_fetch_utilities',W/'fetch_dependencies.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
g=f.g;need=f.need;sha=f.sha;read=f.read
FEATURES=['wgsl','spirv','glsl','dx12','metal','vulkan','gles'];TARGET='aarch64-apple-darwin'
COMPILER=Path('/Users/dshills/.rustup/toolchains/1.99.0-aarch64-apple-darwin')
XCODE=Path('/Applications/Xcode.app/Contents/Developer');TOOLS=XCODE/'Toolchains/XcodeDefault.xctoolchain/usr';SDK=XCODE/'Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk'

def source_tree(root):
 result={}
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'regular extracted source tree')
  if p.is_file():result[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p))
 return result

def verify_registry_sources(home):
 expected={(p['name'],p['version']):p for p in tomllib.loads((P/'source/Cargo.lock').read_text())['package']if p.get('source','').startswith('registry+')}
 packages=[];pins={}
 for registry in sorted((home/'registry/src').iterdir()):
  need(registry.is_dir()and not registry.is_symlink(),'private source registry directory')
  for package in sorted(registry.iterdir()):
   matches=[p for(name,version),p in expected.items()if package.name==name+'-'+version];need(len(matches)==1 and package.is_dir()and not package.is_symlink(),'exact locked extracted package')
   p=matches[0];archive=home/'registry/cache'/registry.name/(package.name+'.crate');need(archive.stat().st_size<=64<<20 and sha(archive)==p['checksum'],'locked package archive bytes')
   with gzip.GzipFile(fileobj=io.BytesIO(archive.read_bytes()))as source:raw=source.read((256<<20)+1)
   need(len(raw)<=256<<20,'crate expansion bound');members={}
   with tarfile.open(fileobj=io.BytesIO(raw),mode='r:')as contents:
    for index,member in enumerate(contents):
     need(index<20000,'crate member bound')
     if member.isdir():continue
     need(member.isfile()and member.name.startswith(package.name+'/'),'regular rooted package member')
     rel=member.name[len(package.name)+1:];need(rel and '..'not in Path(rel).parts and rel not in members,'canonical unique package source')
     body=contents.extractfile(member).read(member.size+1);need(len(body)==member.size,'exact package member size');members[rel]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
   actual=source_tree(package);relative={str(Path(name).relative_to(package)):v for name,v in actual.items()};extras=set(relative)-set(members)
   need(extras<=set(['.cargo-ok','.cargo-checksum.json']),'only Cargo extraction bookkeeping added')
   need(all(relative.get(name)==value for name,value in members.items()),'every extracted dependency byte equals locked archive')
   if '.cargo-checksum.json'in extras:
    check=read(package/'.cargo-checksum.json');need(check['package']==p['checksum'],'Cargo extraction checksum identity')
   pins.update({name:value['sha256']for name,value in actual.items()});pins[str(archive)]=p['checksum']
   packages.append(dict(name=p['name'],version=p['version'],archive_sha256=p['checksum'],source=str(package),source_files=len(actual),source_bytes=sum(v['bytes']for v in actual.values())))
 return packages,pins

def config_paths():
 paths=set()
 for parent in [P/'source',*(P/'source').parents]:
  for name in ['config','config.toml']:paths.add(parent/'.cargo'/name)
 for name in ['config','config.toml']:paths.add(P/'cargo-home'/name)
 return sorted(paths)

def environment():
 return ['CARGO_HOME='+str(P/'cargo-home'),'CARGO_TARGET_DIR='+str(P/'build-target-v1'),'RUSTC='+str(COMPILER/'bin/rustc'),'RUSTDOC='+str(COMPILER/'bin/rustdoc'),'RUSTUP_TOOLCHAIN=1.99.0','CARGO_BUILD_JOBS=2','CARGO_NET_OFFLINE=true','CARGO_NET_RETRY=0','PATH='+str(COMPILER/'bin')+':/usr/bin:/bin:/usr/sbin:/sbin','DEVELOPER_DIR='+str(XCODE),'SDKROOT='+str(SDK),'CC='+str(TOOLS/'bin/clang'),'CXX='+str(TOOLS/'bin/clang++'),'CLANG_PATH='+str(TOOLS/'bin/clang'),'LIBCLANG_PATH='+str(TOOLS/'lib'),'CARGO_TARGET_AARCH64_APPLE_DARWIN_LINKER='+str(TOOLS/'bin/clang'),'MACOSX_DEPLOYMENT_TARGET=11.0','WGPU_NATIVE_VERSION=v29.0.1.1','RUSTFLAGS=-C link-args=-Wl,-install_name,@rpath/libwgpu_native.dylib']

def main():
 need(not(W/'build-plan.json').exists()and not(P/'build-target-v1').exists(),'fresh build plan and target')
 fetched=read(W/'dependency-fetch.json');need(fetched['result']=='PASS_ISOLATED_LOCKED_TARGET_FETCH_NO_SOURCE_COMPILATION','completed locked fetch')
 rootsource=source_tree(P/'source');need(len(rootsource)==97 and all(sha(p)==h for p,h in fetched['inputs'].items()),'original source/compiler unchanged since fetch')
 packages,pins=verify_registry_sources(P/'cargo-home');pins.update({p:v['sha256']for p,v in rootsource.items()})
 configs=config_paths();need(all(not p.exists()for p in configs),'no ambient Cargo ancestor/private-home configuration')
 for root in [P/'cargo-home/registry/index']:
  for p in root.rglob('*'):
   need(not p.is_symlink(),'registry index input symlink')
   if p.is_file():pins[str(p)]=sha(p)
 tools=[COMPILER/'bin/rustc',COMPILER/'bin/cargo',COMPILER/'bin/rustdoc',COMPILER/'lib/libLLVM.dylib',*list((COMPILER/'lib').glob('librustc_driver-*.dylib')),TOOLS/'bin/clang',TOOLS/'bin/clang++',TOOLS/'lib/libclang.dylib',TOOLS/'bin/ld',Path('/usr/bin/xcrun'),Path('/usr/bin/sandbox-exec'),Path(sys.executable).resolve(),SDK/'SDKSettings.json']
 tools+=list((COMPILER/'lib/rustlib'/TARGET/'lib').glob('*'))
 identities=[]
 for p in tools:
  need(p.is_file(),'installed compiler/SDK input '+str(p));resolved=p.resolve();pins[str(resolved)]=sha(resolved);identities.append(dict(path=str(p),resolved=str(resolved),bytes=resolved.stat().st_size,sha256=sha(resolved)))
 for name in ['source.py','source_controls.py','source-controls.json','source-receipt.json','headers.py','headers-receipt.json','fetch_dependencies.py','dependency-fetch.json','prepare_build.py']:pins[str(W/name)]=sha(W/name)
 stopping=lambda:(P/'stop-compile').exists();stable=lambda:all(sha(p)==h for p,h in pins.items())and all(not p.exists()for p in configs)and all(str(Path(v['path']).resolve())==v['resolved']for v in identities)
 env=environment();commands=[]
 profile='(version 1)(allow default)(deny network*)'
 probe="import errno,json,socket; d={};\ntry:\n s=socket.socket();s.settimeout(1);s.connect(('127.0.0.1',9));d['errno']=0\nexcept OSError as e:d['errno']=e.errno\nprint(json.dumps(d));assert d['errno'] in [errno.EPERM,errno.EACCES]"
 for label,argv in [('deployment-target',['/usr/bin/env',*env,str(COMPILER/'bin/rustc'),'--print=deployment-target','--target='+TARGET]),('clang-version',['/usr/bin/env',*env,str(TOOLS/'bin/clang'),'--version']),('network-denial',['/usr/bin/sandbox-exec','-p',profile,str(Path(sys.executable).resolve()),'-c',probe]),('metadata',['/usr/bin/env',*env,str(COMPILER/'bin/cargo'),'metadata','--format-version=1','--locked','--offline','--filter-platform',TARGET,'--no-default-features','--features',','.join(FEATURES),'--manifest-path',str(P/'source/Cargo.toml')])]:
  run=g.execute(argv,P/'source',P/('prepare-'+label),stopping,stable,timeout=120 if label=='metadata'else 30,limit=8<<20);commands.append(dict(label=label,run=run));need(f.terminal(run),'metadata/probe command '+label)
 metadata=read(P/'prepare-metadata/stdout');root=metadata['resolve']['root'];node=next(n for n in metadata['resolve']['nodes']if n['id']==root);need(set(FEATURES)<=set(node['features']),'resolved root features')
 need((P/'prepare-deployment-target/stdout').read_text().strip()=='MACOSX_DEPLOYMENT_TARGET=11.0','explicit ARM64 deployment target')
 for command in commands:
  for name in ['stdout','stderr','owned.json']:pins[str(P/('prepare-'+command['label'])/name)]=sha(P/('prepare-'+command['label'])/name)
 need(stable()and not stopping()and not(P/'build-target-v1').exists(),'metadata is not a source compilation')
 d=dict(result='EXPLICIT_OFFLINE_SOURCE_BUILD_PLAN_PREPARED',source_commit='6aed50955d934ac36049ba8d002034841633ae02',framework_head='276a6543727bf12183c7a0acf52321a2ae82138a',native_runtime_executed=False,downloaded_source_code_executed=False,compiler='1.99.0',target=TARGET,requested_features=FEATURES,resolved_root_features=node['features'],root_package_id=root,package_sources=packages,source_package_count=len(packages),environment=env,configuration_paths_required_absent=list(map(str,configs)),tool_identities=identities,sdk_settings=read(SDK/'SDKSettings.json'),network_sandbox_profile=profile,network_sandbox_scope='Build descendants denied network operations by sandbox-exec; Cargo additionally --offline. Probe proves denied local TCP connect only; not a record of every attempted network operation.',commands=commands,inputs=pins,build_argv=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env',*env,str(COMPILER/'bin/cargo'),'build','--release','--lib','--locked','--offline','--target',TARGET,'--no-default-features','--features',','.join(FEATURES),'--jobs','2','--message-format=json-render-diagnostics','--manifest-path',str(P/'source/Cargo.toml')],scope='Our explicit source build, not reproduction or attestation of upstream released bytes/compiler. Deployment-target configuration is not runtime qualification on older macOS.')
 with(W/'build-plan.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:d[k]for k in ['result','source_package_count','compiler','target','requested_features','resolved_root_features','scope']}))
if __name__=='__main__':main()
