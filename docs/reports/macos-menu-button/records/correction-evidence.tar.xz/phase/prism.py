"""Authorized bounded Anthropic source/spec/evidence-summary checkpoint review."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-menu-button');out=p/'prism-v1';out.mkdir(exist_ok=False)
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
code=json.loads((p/'implementation-review-v2.json').read_text())['files']
assert all(sha(r/n)==h for n,h in code.items())
names=[*code,'docs/controls.md','specs/controls.md','specs/macos-completion.md','specs/menu-button.md','specs/README.md','docs/reports/macos-menu-button/README.md','docs/reports/macos-menu-button/records/qualification.json','docs/reports/macos-menu-button/records/evidence-index.json']
assert len(names)==24 and len(set(names))==24
files={n:sha(r/n)for n in names}
subprocess.run(['git','add','--',*names],cwd=r,check=True)
diff=subprocess.check_output(['git','diff','--cached','--binary','--',*names],cwd=r)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r).decode().splitlines())==set(names)
(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':files,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Public MenuButton and originating popup lifetime/custom-wake routing, actual tests, specs, catalog, native receipt summary and verified archive index. Executables and archive binary excluded.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(names),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=r,stdout=so,stderr=se,timeout=480).returncode
except BaseException as e:error={'type':type(e).__name__,'message':str(e)}
after={n:sha(r/n)for n in names};afterdiff=subprocess.check_output(['git','diff','--cached','--binary','--',*names],cwd=r)
receipt={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'before':files,'after':after,'source_index_stable':files==after and diff==afterdiff,'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').exists()else None}
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PRISM',code,'stable',receipt['source_index_stable'],'seconds',round(receipt['elapsed_seconds'],1),flush=True)
sys.exit(code if error is None and receipt['source_index_stable'] else 125)
