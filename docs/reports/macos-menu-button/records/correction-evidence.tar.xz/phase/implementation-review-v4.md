# Native menu fixture readiness supplement

APPROVED_SOURCE. Only gallery/menu_smoke.go changes from frozen V3. Open readiness now waits for the chosen item’s positive bounds and matching hit test, keeping the original scope/root checks and all subsequent identity/action assertions. The deadline, polling and timeout failure record remain unchanged. Reversing only these predicate edits reconstructs the V3 hash. Other fifteen leaves are exact V3 bytes.

V3 and earlier failed native readiness receipts remain preserved. This source-only supplement certifies no additional runtime/provider/performance/Mac acceptance and executes nothing.
