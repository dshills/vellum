# Menu stage publication correction

APPROVED_SOURCE. Finding 7827df8e0c43dccb is ACCEPTED_FIXED. Only the active-context property block moved: it now follows successful NewMenuStage creation and precedes s.popup publication. Reversing that movement reconstructs the exact approved V2 source hash. The nil-stage branch never registers the attempted popup. All other fifteen selected leaves remain identical.

V2 and raw Prism exit 1 remain preserved. The separate identity-token evidence naming finding is outside this code-only supplement. No test/native/provider execution, pending receipt success or broader acceptance is certified.
