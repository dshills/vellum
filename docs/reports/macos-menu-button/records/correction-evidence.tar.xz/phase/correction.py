import hashlib,io,json,subprocess,sys,tarfile,time
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-menu-button');rec=r/'docs/reports/macos-menu-button/records';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
code=json.loads((p/'implementation-review-v4.json').read_text())['files'];assert len(code)==16 and all(sha(r/n)==h for n,h in code.items())
q=json.loads((rec/'qualification.json').read_text());assert code==q['code_files']
for n in ['focused-menu-v8','gallery-build-v6','native-menu-v5']:
 d=json.loads((p/(n+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_delta_stable'] and d['prepared_before']==d['prepared_after'];assert all(d['source_delta_before'][name]==h for name,h in code.items()) or n=='focused-menu-v8' and all(d['source_delta_before'][name]==h for name,h in code.items() if name!='drivers/cogent/cmd/gallery/menu_smoke.go')
entries={}
for prefix in ['focused-menu-v8','gallery-build-v5','gallery-build-v6','native-menu-v4','native-menu-v5']:
 for suffix in ['json','stdout','stderr']:entries['phase/'+prefix+'.'+suffix]=p/(prefix+'.'+suffix)
for n in ['implementation-review-v3.json','implementation-review-v3.md','implementation-review-v4.json','implementation-review-v4.md','prism.py','correction.py']:entries['phase/'+n]=p/n
for n in ['prism.json','process.json','inputs.json','stdout.log','stderr.log']:entries['prism-initial/'+n]=p/'prism-v1'/n
for n in ['drivers/cogent/menu_button.go','drivers/cogent/cmd/gallery/menu_smoke.go']:entries['source/'+n+'.txt']=r/n
with tarfile.open(rec/'correction-evidence.tar.xz','w:xz')as t:
 for n,f in sorted(entries.items()):t.add(f,arcname=n,recursive=False)
index={n:sha(f)for n,f in entries.items()}
with tarfile.open(rec/'correction-evidence.tar.xz')as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t.getmembers()if m.isfile()}==index
(rec/'correction-evidence-index.json').write_text(json.dumps({'archive':'correction-evidence.tar.xz','archive_sha256':sha(rec/'correction-evidence.tar.xz'),'verified_members':len(index),'members':index},indent=2)+'\n')
# Narrow provider correction: two changed code leaves and their evidence/report.
names=['drivers/cogent/menu_button.go','drivers/cogent/cmd/gallery/menu_smoke.go','docs/reports/macos-menu-button/README.md','docs/reports/macos-menu-button/records/qualification.json','docs/reports/macos-menu-button/records/correction-evidence-index.json']
files={n:sha(r/n)for n in names};subprocess.run(['git','add','--',*names],cwd=r,check=True)
out=p/'prism-v2';out.mkdir(exist_ok=False);diff=subprocess.check_output(['git','diff','--cached','--binary','--',*names],cwd=r);(out/'staged.diff.txt').write_bytes(diff);(out/'inputs.json').write_text(json.dumps({'files':files,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Final narrow delta from initial24-file full review: stage registration ordering and measured-layout fixture readiness, clarified object identity token and exact test-stage report, verified correction archive index.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(names),'--out',str(out/'prism.json')]
start=time.monotonic();exit_code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:exit_code=run_child(argv,cwd=r,stdout=so,stderr=se,timeout=300).returncode
except BaseException as e:error={'type':type(e).__name__,'message':str(e)}
after={n:sha(r/n)for n in names};afterdiff=subprocess.check_output(['git','diff','--cached','--binary','--',*names],cwd=r)
receipt={'argv':argv,'exit_code':exit_code,'error':error,'elapsed_seconds':time.monotonic()-start,'before':files,'after':after,'source_index_stable':files==after and diff==afterdiff,'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').exists()else None};(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PRISM',exit_code,'stable',receipt['source_index_stable'],'seconds',round(receipt['elapsed_seconds'],1),flush=True)
sys.exit(exit_code if error is None and receipt['source_index_stable'] else 125)
