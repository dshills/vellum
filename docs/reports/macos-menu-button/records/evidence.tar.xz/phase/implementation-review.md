# MenuButton initial implementation review

NEEDS_FIX. Two concrete originating-route issues remain: queued close mutates the original popup Scene/stage without guaranteed original-window RC ownership, and the modal popup lacks Custom forwarding to the driver. See the exact source-bound findings in implementation-review.json.

The bounded 64-action validation, stable IDs, detached options, fresh popup epochs, disabled action checks, private Manual incarnation and popup AX bounds are otherwise coherent within the reviewed scope. Existing focused Manual tests cover several ordinary and stale paths, but explicit owner pumping does not substantiate the missing live wake route or peer-window synchronization. No tests/native/provider/Git execution occurred during review.
