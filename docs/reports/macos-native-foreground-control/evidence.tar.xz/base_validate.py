from pathlib import Path
import importlib.util,sys,json,math
sys.dont_write_bytecode=True
S=Path('/private/tmp/vellum-doclinks-sdk-bd3cbc9/retained SDK/vellum-v0.1.0-alpha.2/scripts/check-presentation.py');s=importlib.util.spec_from_file_location('sdk_math',S);v=importlib.util.module_from_spec(s);sys.modules[s.name]=v;s.loader.exec_module(v)
def check(ok,message):
 if not ok:raise ValueError(message)
def validate(items,mode):
 check(mode in ['raw','provided-link'],'mode')
 configs=[x for x in items if x.get('event')=='config'];headers=[x for x in items if x.get('event')=='reference'];rows=[x for x in items if 'index'in x];closed=[x for x in items if 'closed'in x]
 check(len(configs)==len(headers)==len(closed)==1 and len(rows)+3==len(items),'complete bounded record')
 c,h=configs[0],headers[0];check(c['drawables']==2 and c['vsync'] is True and c['transactions'] is False and c['size']==[1519,1266] and c['scale']>0,'config')
 boundary='before nextDrawable' if mode=='raw' else 'provided-drawable callback;acquisition precedes receipt'
 check(h['mode']==mode and h['receipt_boundary']==boundary and h['warmup']==128 and h['samples']==120 and h['records']==len(rows) and 249<=len(rows)<=512 and closed[0]['closed'] is True,'header/close')
 for i,r in enumerate(rows):
  check(type(r['phase']) is int and r['phase'] in [0,1,2] and r['index']==i,'record identity')
  check(all(type(r[k]) in [int,float] and math.isfinite(r[k]) for k in ['receipt','acquired','target','presentation_target','shown']),'finite clocks')
  check(r['receipt']>0 and r['shown']>=0,'positive receipt/nonnegative feedback')
  if mode=='raw':check(r['acquired']>=r['receipt'] and r['target']==r['presentation_target']==0,'raw boundary')
  else:check(r['acquired']==0 and r['target']>0 and r['presentation_target']>=r['target'],'provided boundary/targets')
  if r['phase']!=0:check(r['shown']>r['receipt'],'cohort feedback missing/nonpositive/backward')
 setup=[r for r in rows if r['phase']==0];warm=[r for r in rows if r['phase']==1];measured=[r for r in rows if r['phase']==2]
 check(len(warm)==128 and len(measured)==120 and rows==setup+warm+measured,'fixed phase population')
 check(any(0<r['shown']<=warm[0]['receipt'] for r in setup),'readiness before cohort')
 population=warm+measured;check(all(a['shown']<b['shown'] for a,b in zip(population,population[1:])),'collapsed/reordered cohort')
 result={'outcome':'VALID_READY_WINDOW_NATIVE_REFERENCE','mode':mode,'receipt_boundary':boundary,'native_OS_floor_proven':False,'framework_release_qualified':False,'setup_count':len(setup),'setup_zero_indices':[r['index'] for r in setup if r['shown']==0],'warmup_count':128,'measured_count':120,'measured_receipt_to_shown_ms':v.stats([(r['shown']-r['receipt'])*1000 for r in measured]),'measured_display_intervals_ms':v.stats([(b['shown']-a['shown'])*1000 for a,b in zip(measured,measured[1:])])}
 if mode=='provided-link':result.update({'callback_to_target_ms':v.stats([(r['presentation_target']-r['receipt'])*1000 for r in measured]),'target_to_shown_ms':v.stats([(r['shown']-r['presentation_target'])*1000 for r in measured])})
 return result
if __name__=='__main__':
 p=Path(sys.argv[1]);check(p.stat().st_size<1<<20,'log bound');items=[json.loads(line,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x))) for line in p.read_text().splitlines()];print(json.dumps(validate(items,sys.argv[2]),indent=2))
