from pathlib import Path
import importlib.util,sys,json,datetime,signal
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;S=P.parent.parent/'macos-release-default-assessment/assessment.py'
s=importlib.util.spec_from_file_location('reused_owned_native',S);a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);a.P=P
s=importlib.util.spec_from_file_location('ready_reference_validator',P/'validate.py');v=importlib.util.module_from_spec(s);sys.modules[s.name]=v;s.loader.exec_module(v)
a.need(not (P/'started.json').exists() and not (P/'stop-live').exists(),'sealed campaign')
plan=json.loads((S.parent/'plan.json').read_text());a.need(a.sdk_vector()==plan['sdk'],'SDK drift')
plan['pins']={str(p):a.sha(p) for p in [P/'native',P/'main.m',P/'run.py',P/'validate.py',P/'validate_test.py',P/'base_validate.py',P/'plan.txt',S,Path(a.g.__file__),a.LEASE]}
a.write(P/'bound-plan.json',{'kind':'foreground-controlled native diagnostic;no framework release qualification','pins':plan['pins'],'modes':['raw','link'],'maximum_seconds':120,'native_watchdog_seconds':15,'samples':120,'warmup':128,'receipt_boundaries':'raw beforeacquire;link atprovidedcallback,afteracquire;do not pool','stop_on_invalid':True})
start=datetime.datetime.now(datetime.timezone.utc);a.write(P/'started.json',{'started_utc':start.isoformat(),'human_authorization':'Yes,test now;up to two quiet minutes','features_frozen':True});deadline=start+datetime.timedelta(seconds=120);stopped=[False];previous={sig:signal.signal(sig,lambda *_:stopped.__setitem__(0,True)) for sig in [signal.SIGINT,signal.SIGTERM]};results=[]
try:
 with a.lease_module.LiveLease() as lease:
  for mode in ['raw','link']:
   root=P/mode;root.mkdir();h=a.Host(plan,root,deadline,lease,stopped);r={'mode':mode}
   try:
    r['geometry_before']=h.geometry();r['configuration_before']=h.probes(root/'before');r['native']=h.command([str(P/'native'),mode],P,root/'native',15);r['configuration_after']=h.probes(root/'after');r['geometry_after']=h.geometry();h.finish()
    a.need(a.c.passed(r['native']) and r['native']['logs']['stderr']['bytes']==0,'native failure/warning;retain raw scope')
    items=[json.loads(line,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x))) for line in (root/'native/stdout').read_text().splitlines()];validation=v.validate(items,'raw' if mode=='raw' else 'provided-link');a.write(root/'validation.json',validation);r['outcome']='VALID_READY_WINDOW_REFERENCE';r['diagnostic_latency_ms']=validation['measured_receipt_to_shown_ms'];r['framework_release_qualified']=False
   except Exception as e:r['outcome']='REJECT';r['error']={'type':type(e).__name__,'message':str(e)}
   a.write(root/'result.json',r);(root/'sealed').touch();results.append(r);print(json.dumps({k:x for k,x in r.items() if k in ['mode','outcome','error','diagnostic_latency_ms']}),flush=True)
   if r['outcome']=='REJECT':break
finally:
 (P/'stop-live').touch();a.write(P/'result.json',{'cases':results,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'framework_release_qualified':False});[signal.signal(sig,handler) for sig,handler in previous.items()]
