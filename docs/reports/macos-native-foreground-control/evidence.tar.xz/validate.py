from pathlib import Path
import importlib.util,sys,math,json
sys.dont_write_bytecode=True
s=importlib.util.spec_from_file_location('frozen_reference_validator',Path(__file__).with_name('base_validate.py'));base=importlib.util.module_from_spec(s);s.loader.exec_module(base)
def validate(items,mode):
 marks=[r for r in items if r.get('event')=='foreground'];base.check(len(marks)==2 and [r['phase'] for r in marks]==['start','end'],'foreground boundary snapshots')
 for r in marks:
  base.check(type(r['pid']) is int and r['pid']>0 and r['front_pid']==r['pid'] and r['active'] is True and r['key'] is True and r['visible'] is True and r['losses']==0,'foreground/key/visibility or notification loss')
  base.check(type(r['clock']) in [float,int] and math.isfinite(r['clock']) and r['clock']>0,'foreground clock')
 base.check(marks[0]['pid']==marks[1]['pid'] and marks[0]['clock']<marks[1]['clock'],'foreground identity/order')
 rows=[r for r in items if 'index' in r]
 base.check(all(marks[0]['clock']<=r['receipt']<=marks[1]['clock'] and r['shown']<=marks[1]['clock'] for r in rows),'foreground bounds')
 result=base.validate([r for r in items if r.get('event')!='foreground'],mode)
 result['foreground_control']={'boundary_snapshots':marks,'resign_or_foreign_activation_notifications':0,'physical_input_verified':False}
 return result
