import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'ready-reference'))
from validate_test import ReferenceControls
sys.path.pop(0)
import importlib.util
s=importlib.util.spec_from_file_location('foreground_validate',Path(__file__).with_name('validate.py'));v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
class ForegroundControls(unittest.TestCase):
 def data(self):
  d=ReferenceControls().data();mark={'event':'foreground','phase':'start','clock':.4,'pid':123,'front_pid':123,'active':True,'key':True,'visible':True,'losses':0};return [mark]+d+[dict(mark,phase='end',clock=10)]
 def test_valid(self):self.assertFalse(v.validate(self.data(),'raw')['foreground_control']['physical_input_verified'])
 def test_background_pid(self):
  d=self.data();d[0]['front_pid']=456
  with self.assertRaises(ValueError):v.validate(d,'raw')
 def test_key_loss(self):
  d=self.data();d[-1]['key']=False
  with self.assertRaises(ValueError):v.validate(d,'raw')
 def test_transient_loss(self):
  d=self.data();d[-1]['losses']=2
  with self.assertRaises(ValueError):v.validate(d,'raw')
 def test_early_capture(self):
  d=self.data();d[0]['clock']=1
  with self.assertRaises(ValueError):v.validate(d,'raw')
 def test_missing_snapshot(self):
  d=self.data();d.pop()
  with self.assertRaises(ValueError):v.validate(d,'raw')
if __name__=='__main__':unittest.main()
