// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
#import <Cocoa/Cocoa.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalDisplayLink.h>
#include <stdatomic.h>
#include <stdio.h>
#include <unistd.h>
typedef struct { int phase,index;double receipt,acquired,target,presentationTarget,shown; } Record;
static Record records[512];static _Atomic(double) shownTimes[512];static _Atomic(int) ready;static int used,cohort;static _Atomic(int) foregroundLosses;
@interface Reference : NSObject <CAMetalDisplayLinkDelegate>
@property(strong) CAMetalLayer *layer;
@property(strong) id<MTLCommandQueue> queue;
@property(strong) NSWindow *window;
@property(strong) CAMetalDisplayLink *link;
@property(strong) dispatch_group_t callbacks;
@property BOOL linked;
@property BOOL finishing;
@property(strong) NSArray *observers;
@property(strong) id workspaceObserver;
- (void)awaitForeground:(double)deadline;
- (void)foregroundSnapshot:(const char *)phase;
- (void)start;
@end
@implementation Reference
- (void)foregroundSnapshot:(const char *)phase {
 printf("{\"event\":\"foreground\",\"phase\":\"%s\",\"clock\":%.9f,\"pid\":%d,\"front_pid\":%d,\"active\":%s,\"key\":%s,\"visible\":%s,\"losses\":%d}\n",phase,CACurrentMediaTime(),getpid(),NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier,NSApp.active?"true":"false",self.window.keyWindow?"true":"false",(self.window.occlusionState&NSWindowOcclusionStateVisible)?"true":"false",atomic_load(&foregroundLosses));fflush(stdout);
}
- (void)awaitForeground:(double)deadline {
 BOOL good=NSApp.active && self.window.keyWindow && (self.window.occlusionState&NSWindowOcclusionStateVisible) && NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier==getpid();
 if(!good){
  if(CACurrentMediaTime()>=deadline){[self foregroundSnapshot:"refused-start"];fprintf(stderr,"foreground readiness deadline; no cohort started\n");_exit(4);}
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW,10*NSEC_PER_MSEC),dispatch_get_main_queue(),^{[self awaitForeground:deadline];});return;
 }
 NSNotificationCenter *center=NSNotificationCenter.defaultCenter;
 id a=[center addObserverForName:NSApplicationDidResignActiveNotification object:NSApp queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note){(void)note;atomic_fetch_add(&foregroundLosses,1);}];
 id w=[center addObserverForName:NSWindowDidResignKeyNotification object:self.window queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note){(void)note;atomic_fetch_add(&foregroundLosses,1);}];
 self.observers=@[a,w];
 self.workspaceObserver=[NSWorkspace.sharedWorkspace.notificationCenter addObserverForName:NSWorkspaceDidActivateApplicationNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note){NSRunningApplication *app=note.userInfo[NSWorkspaceApplicationKey];if(app.processIdentifier!=getpid())atomic_fetch_add(&foregroundLosses,1);}];
 [self foregroundSnapshot:"start"];[self start];
}
- (void)emit:(id<CAMetalDrawable>)drawable record:(int)index {
 int phase=records[index].phase;
 dispatch_group_enter(_callbacks);
 [drawable addPresentedHandler:^(id<MTLDrawable> shown){
  atomic_store(&shownTimes[index],shown.presentedTime);
  if(phase==0 && shown.presentedTime>0)atomic_store(&ready,1);
  dispatch_group_leave(self.callbacks);
 }];
 MTLRenderPassDescriptor *pass=[MTLRenderPassDescriptor renderPassDescriptor];pass.colorAttachments[0].texture=drawable.texture;pass.colorAttachments[0].loadAction=MTLLoadActionClear;pass.colorAttachments[0].storeAction=MTLStoreActionStore;pass.colorAttachments[0].clearColor=MTLClearColorMake(0.2,(index%2)?0.5:0.6,0.75,1);
 id<MTLCommandBuffer> cmd=[_queue commandBuffer];id<MTLRenderCommandEncoder> encoder=[cmd renderCommandEncoderWithDescriptor:pass];[encoder endEncoding];[cmd presentDrawable:drawable];[cmd commit];
}
- (void)finish {
 long timeout=dispatch_group_wait(_callbacks,dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC));
 if(timeout){fprintf(stderr,"reference pending native callbacks at deadline\n");fflush(stderr);_exit(3);}
 printf("{\"event\":\"reference\",\"mode\":\"%s\",\"receipt_boundary\":\"%s\",\"warmup\":128,\"samples\":120,\"records\":%d,\"scope\":\"native clear diagnostic;not framework qualification\"}\n",_linked?"provided-link":"raw",_linked?"provided-drawable callback;acquisition precedes receipt":"before nextDrawable",used);
 for(int i=0;i<used;i++){Record r=records[i];r.shown=atomic_load(&shownTimes[i]);printf("{\"phase\":%d,\"index\":%d,\"receipt\":%.9f,\"acquired\":%.9f,\"target\":%.9f,\"presentation_target\":%.9f,\"shown\":%.9f}\n",r.phase,r.index,r.receipt,r.acquired,r.target,r.presentationTarget,r.shown);}fflush(stdout);
 dispatch_async(dispatch_get_main_queue(),^{[self foregroundSnapshot:"end"];for(id token in self.observers)[NSNotificationCenter.defaultCenter removeObserver:token];self.observers=nil;if(self.workspaceObserver)[NSWorkspace.sharedWorkspace.notificationCenter removeObserver:self.workspaceObserver];self.workspaceObserver=nil;[self.link invalidate];self.link=nil;[self.window close];[NSApp stop:nil];[NSApp postEvent:[NSEvent otherEventWithType:NSEventTypeApplicationDefined location:NSZeroPoint modifierFlags:0 timestamp:0 windowNumber:0 context:nil subtype:0 data1:0 data2:0] atStart:NO];});
}
- (void)start {
 _callbacks=dispatch_group_create();
 printf("{\"event\":\"config\",\"drawables\":%lu,\"vsync\":%s,\"transactions\":%s,\"size\":[%.0f,%.0f],\"scale\":%.3f}\n",(unsigned long)_layer.maximumDrawableCount,_layer.displaySyncEnabled?"true":"false",_layer.presentsWithTransaction?"true":"false",_layer.drawableSize.width,_layer.drawableSize.height,_window.backingScaleFactor);
 if(_linked){
  _link=[[CAMetalDisplayLink alloc]initWithMetalLayer:_layer];_link.preferredFrameLatency=1;_link.delegate=self;[_link addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];
 }else{
  dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE,0),^{
   double startupDeadline=CACurrentMediaTime()+3;
   while(!atomic_load(&ready) && used<64 && CACurrentMediaTime()<startupDeadline){ @autoreleasepool {
    int i=used++;records[i]=(Record){.phase=0,.index=i,.receipt=CACurrentMediaTime()};id<CAMetalDrawable>d=[self.layer nextDrawable];records[i].acquired=CACurrentMediaTime();if(!d){fprintf(stderr,"startup drawable unavailable\n");_exit(2);}[self emit:d record:i];
    if(dispatch_group_wait(self.callbacks,dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC))){fprintf(stderr,"startup callback deadline\n");_exit(2);}
   }}
   if(!atomic_load(&ready)){fprintf(stderr,"window never produced positive startup feedback\n");_exit(2);}
   for(int tag=0;tag<248;tag++){ @autoreleasepool {
    int i=used++;records[i]=(Record){.phase=tag<128?1:2,.index=i,.receipt=CACurrentMediaTime()};id<CAMetalDrawable>d=[self.layer nextDrawable];records[i].acquired=CACurrentMediaTime();if(!d){fprintf(stderr,"cohort drawable unavailable\n");_exit(2);}[self emit:d record:i];
   }}
   [self finish];
  });
 }
}
- (void)metalDisplayLink:(CAMetalDisplayLink *)link needsUpdate:(CAMetalDisplayLinkUpdate *)update {
 if(_finishing)return;
 if(used>=512){fprintf(stderr,"bounded reference record limit\n");_exit(2);}
 int i=used++;BOOL warmed=atomic_load(&ready);int phase=warmed?(cohort<128?1:2):0;if(warmed)cohort++;
 records[i]=(Record){.phase=phase,.index=i,.receipt=CACurrentMediaTime(),.target=update.targetTimestamp,.presentationTarget=update.targetPresentationTimestamp};
 [self emit:update.drawable record:i];
 if(cohort==248){_finishing=YES;link.paused=YES;dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE,0),^{[self finish];});}
}
@end
int main(int argc,const char **argv){@autoreleasepool{
 if(argc!=2 || (strcmp(argv[1],"raw") && strcmp(argv[1],"link"))){fprintf(stderr,"raw|link\n");return 2;}
 NSApplication *app=NSApplication.sharedApplication;[app setActivationPolicy:NSApplicationActivationPolicyRegular];
 Reference *driver=[Reference new];driver.linked=!strcmp(argv[1],"link");
 NSWindow *window=[[NSWindow alloc]initWithContentRect:NSMakeRect(50,50,1519,1266) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:NO];window.releasedWhenClosed=NO;window.title=@"Vellum ready-window Metal reference";driver.window=window;
 id<MTLDevice>device=MTLCreateSystemDefaultDevice();driver.queue=[device newCommandQueue];CAMetalLayer *layer=CAMetalLayer.layer;driver.layer=layer;layer.device=device;layer.pixelFormat=MTLPixelFormatBGRA8Unorm;layer.maximumDrawableCount=2;layer.displaySyncEnabled=YES;layer.presentsWithTransaction=NO;layer.allowsNextDrawableTimeout=YES;layer.framebufferOnly=YES;layer.drawableSize=CGSizeMake(1519,1266);window.contentView.wantsLayer=YES;window.contentView.layer=layer;[app finishLaunching];[window makeKeyAndOrderFront:nil];[app activateIgnoringOtherApps:YES];dispatch_async(dispatch_get_main_queue(),^{[driver awaitForeground:CACurrentMediaTime()+1];});[app run];printf("{\"closed\":true}\n");
}return 0;}
