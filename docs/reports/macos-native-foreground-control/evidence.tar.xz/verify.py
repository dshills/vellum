from pathlib import Path
import json,hashlib,importlib.util,sys,tarfile,re
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
R=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-native-foreground-control')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
v=module('reference_validator',P/'validate.py')
a=module('reference_sdk_audit',P.parent.parent/'macos-release-default-assessment/assessment.py')
sdk=a.sdk_vector();assert sdk==load(P.parent.parent/'macos-release-default-assessment/plan.json')['sdk']
plan=load(P/'bound-plan.json');assert all(sha(Path(p))==h for p,h in plan['pins'].items())
result=load(P/'result.json');summary=load(R/'summary.json');assert len(result['cases'])==2
assert summary['native_commands']==2 and summary['probe_commands']==16 and summary['all_groups_retired']
assert not summary['framework_release_qualified'] and not summary['native_OS_floor_proven'] and not summary['policy_changed'] and summary['foreground_boundary_control_valid'] and not summary['physical_input_verified']
commands=0
for case in result['cases']:
 mode=case['mode'];root=P/mode;rows=[json.loads(s) for s in (root/'native/stdout').read_text().splitlines()]
 validation=v.validate(rows,'raw' if mode=='raw' else 'provided-link');assert validation==load(root/'validation.json')==summary['modes'][mode]['metrics']
 assert validation['warmup_count']==128 and validation['measured_count']==120 and validation['setup_count']==(2 if mode=='raw' else 4)
 assert validation['setup_zero_indices']==([0] if mode=='raw' else [0,1])
 frames=[r for r in rows if r.get('phase')==2];intervals=[(b['shown']-a['shown'])*1000 for a,b in zip(frames,frames[1:])]
 assert len(intervals)==119 and all(0<t<=18.333 for t in intervals)
 if mode=='link':
  assert summary['modes'][mode]['derived_metrics']=={'callback_to_render_deadline_ms':v.base.v.stats([(r['target']-r['receipt'])*1000 for r in frames]),'render_deadline_to_presentation_target_ms':v.base.v.stats([(r['presentation_target']-r['target'])*1000 for r in frames])}
 assert case['geometry_before']==case['geometry_after'] and summary['modes'][mode]['geometry_unchanged']
 assert summary['modes'][mode]['configuration_bytes_unchanged']
 cmds=[(case['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:
  for key,cmd in case[phase].items():cmds.append((cmd,root/folder/key))
 for cmd,folder in cmds:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['logs_complete'] and cmd['pins_stable']
  for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
  commands+=1
 for key in case['configuration_before']:assert case['configuration_before'][key]['logs']['stdout']['sha256']==case['configuration_after'][key]['logs']['stdout']['sha256']
assert commands==18
index=load(R/'evidence-index.json');assert sha(R/'evidence.tar.xz')==index['archive']['sha256']
with tarfile.open(R/'evidence.tar.xz') as tf:
 assert set(tf.getnames())==set(index['files'])
 for n,d in index['files'].items():
  b=tf.extractfile(n).read();assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
assert load(P/'review/disposition.json')['unresolved']==0
assert load(P/'checkpoint-review/disposition.json')['unresolved']==0
review=load(P/'checkpoint-review/prism.json');assert review['coverage']['complete'] and not review['findings']
for pin in summary['source_and_binary_pins']:
 assert not Path(pin['artifact_path']).is_absolute()
 assert sha(P.parent.parent/pin['artifact_path'])==pin['sha256']
 if pin['evidence_member'] is not None:assert index['files'][pin['evidence_member']]['sha256']==pin['sha256']
 else:assert pin['availability']!='archived'
for p in [R/'README.md',R.parent.parent.parent/'specs/macos-release-assessment.md',R.parent.parent.parent/'specs/macos-delivery.md',R.parent.parent.parent/'specs/macos-completion.md']:
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not link.startswith(('https:','#')):assert (p.parent/link.split('#')[0]).exists(),link
print(f'PASS: SDK {len(sdk)} files unchanged; runtime pins; 2 valid 128+120 cohorts; retained setup losses 1/2; foreground boundary snapshots and no-loss notification records; 238 ordered cadence intervals; exact target statistics; 18 owned groups retired; raw log hashes; archive and links; source-review disposition; no framework qualification or policy change')
