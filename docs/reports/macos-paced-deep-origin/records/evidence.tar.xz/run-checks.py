"""Two fixed Python-only checks using the unchanged owned headless executor."""
from pathlib import Path
import hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;X=W.parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,why):
 if not ok:raise ValueError(why)
def write(p,v):
 with p.open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def vector(root):
 result={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'immutable vector symlink')
  if p.is_file():result[p.relative_to(root).as_posix()]=sha(p)
 return result
def main():
 need(not(W/'checks-result.json').exists()and not(W/'checks-plan.json').exists(),'fresh checks only')
 binding=X/'macos-sdk-post-empty-publication/binding.json';b=read(binding);need(b['head']=='70bf39175903f0bc8408e358d58781efdfa5032c','exact current source');S=Path(b['sdk']);proposal=read(W/'proposal.json');need(all(sha(p)==h for p,h in proposal['inputs'].items()),'original proposal inputs')
 pins={**proposal['inputs'],**{str(W/p):v['sha256']for p,v in proposal['outputs'].items()},**b['association_inputs']}
 guard=X/'macos-sdk-stage0079-abe67c6-cache-v2/run.py';python=Path(sys.executable).resolve();need(sys.version_info>=(3,11),'modern diagnostic Python')
 for p in [binding,guard,X/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path(__file__),W/'proposal.json',python]:pins[str(p)]=sha(p)
 def boundary():
  need(all(sha(p)==h for p,h in pins.items()),'pinned input changed');observed={}
  for root in [C,T]:
   actual={n:sha(root/n)for n in b['source']};need(actual==b['source'],'complete bound source vector changed')
   prepared={m+'/'+n:h for m in ['upstream','typesetting']for n,h in vector(root/'drivers/cogent/build'/m).items()};need(prepared==b['prepared'],'prepared vector changed');observed[str(root)]={'bound_source_files':len(actual),'prepared_files':len(prepared),'source_sha256':hashlib.sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest(),'prepared_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True).encode()).hexdigest()}
  sdk=vector(S);need(sdk==b['sdk_files'],'SDK vector changed');observed['SDK']={'files':len(sdk),'sha256':hashlib.sha256(json.dumps(sdk,sort_keys=True).encode()).hexdigest()};return observed
 before=boundary();out=W/'checks';out.mkdir();plan={'binding_sha256':sha(binding),'inputs':pins,'before':before,'commands':{'candidate':{'argv':[str(python),'-B','-m','unittest','-v','check_presentation_test'],'cwd':str(W/'candidate/scripts')},'original-counterfactual':{'argv':[str(python),'-B',str(W/'counterfactual.py')],'cwd':str(W)}},'no_Git_commands':True};write(W/'checks-plan.json',plan);pins[str(W/'checks-plan.json')]=sha(W/'checks-plan.json')
 spec=importlib.util.spec_from_file_location('unchanged_headless_guard',guard);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
 profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in [C,T,S,W/'baseline',W/'candidate',W/'proposal.json',W/'counterfactual.py',W/'run-checks.py',W/'checks-plan.json'])
 stopped=[False];previous={sig:signal.signal(sig,lambda signum,frame:stopped.__setitem__(0,True))for sig in [signal.SIGINT,signal.SIGTERM]};result={'result':'FAILED_OR_CANCELED','commands':{},'inputs':pins,'before':before,'native_executed':False,'Go_or_Git_commands_executed':False,'error':None}
 try:
  for name,command in plan['commands'].items():
   boundary();need(not stopped[0],'canceled');r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,*command['argv']],Path(command['cwd']),out/name,lambda:stopped[0]or(W/'stop-checks').exists(),lambda:all(sha(p)==v for p,v in pins.items()),timeout=60,limit=4<<20);result['commands'][name]=r;write(W/(name+'-command.json'),r)
   need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned Python check failed')
  result['result']='PASS_25_CANDIDATE_CONTROLS_AND_EXPECTED_ORIGINAL_COUNTERFACTUAL'
 except BaseException as e:result['error']={'type':type(e).__name__,'message':str(e)}
 finally:
  try:result['after']=boundary();need(before==result['after']and not stopped[0],'boundary or cancellation')
  except BaseException as e:result.update(result='FAILED_OR_CANCELED',boundary_error={'type':type(e).__name__,'message':str(e)})
  write(W/'checks-result.json',result)
  for sig,handler in previous.items():signal.signal(sig,handler)
 print(json.dumps({'result':result['result'],'groups':{k:v['owned']for k,v in result['commands'].items()}}));need(result['result'].startswith('PASS_'),'check failed; no retry')
if __name__=='__main__':main()
