"""Targeted synthetic original-source counterfactual; run only after approval."""
from pathlib import Path
import importlib.util,io,sys,unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 tests=load('candidate_origin_tests',W/'candidate/scripts/check_presentation_test.py')
 old=load('unchanged_original_validator',W/'baseline/scripts/check-presentation.py')
 with patch.object(tests,'m',old):
  case=tests.PacedInitialOriginTests('test_deep_source_origins_are_accepted')
  output=io.StringIO();result=unittest.TextTestRunner(stream=output).run(unittest.TestSuite([case]))
  text=output.getvalue();print(text)
  if result.testsRun!=1 or result.failures or len(result.errors)!=4 or text.count('ValueError: paced initial/warmup baseline differs')!=4:raise ValueError('original source did not exhibit the four exact deep-origin refusals')
  for size in [10000,100000]:
   wrong=tests.shift_paced_origin(tests.deep_paced_fixture(size),0)
   if old.validate(wrong,tests.SOURCE,tests.BINARY)['result']!='VALID_PACED_NATIVE_FEEDBACK_JOURNAL':raise ValueError('original zero-origin counterexample changed')
 print('EXPECTED_ORIGINAL_DEEP_ORIGIN_DEFECT_CONFIRMED_SYNTHETIC_ONLY')
if __name__=='__main__':main()
