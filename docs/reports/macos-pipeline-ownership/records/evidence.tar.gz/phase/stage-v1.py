import difflib,hashlib,json,subprocess
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-pipeline-ownership');owned=r/'drivers/cogent/native/patches/pipelinelifecycle';owned.mkdir(exist_ok=False)
h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
manifest=json.loads((p/'candidate-final.json').read_text()); inputs={};outputs={};patch=''
for relative,expected in manifest['candidate'].items():
 candidate=p/'candidate'/relative;assert h(candidate)==expected
 prepared=r/'drivers/cogent/build/upstream'/relative
 original=p/'original'/relative
 if original.is_file():
  assert h(prepared)==h(original)==manifest['original'][relative]
  before=original.read_text();fromfile='a/'+relative;inputs[relative]=h(original)
 else:
  assert not prepared.exists();before='';fromfile='/dev/null';inputs[relative]=None
 outputs[relative]=expected
 patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),candidate.read_text().splitlines(keepends=True),fromfile=fromfile,tofile='b/'+relative))
file=owned/'0052-transactional-pipeline-reference-replacement.patch';file.write_text(patch)
for name,value in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (owned/name).write_text(json.dumps(value,indent=2)+'\n')
(owned/'README.md').write_text('''# Pipeline replacement ownership

Patch 0052 publishes only fresh live shader modules and bind groups. Factory
refusal preserves the current reference; returned partial handles retire. Shader
reload retires the prior module explicitly after replacement. Existing native
pipelines retain their dependencies and require rebuild to use the new shader.

Binding replacement queues the old group only after successful admission. Refusal
preserves current ownership, generation and retirement queue, allowing retry
without duplicate aliases. Matching live generations reuse the binding. Pass
completion/shutdown retires prior groups; pipeline retirement detaches both cache
maps. All operations use one serialized owner and fresh-owned native factories.

Fault kernels cover partial/nil/invalid/error admission and retry; opt-in tiny
headless checks observe module replacement and duplicate-layout native refusal
followed by exact compute output. They do not qualify physical GPU faults, native
heap reclamation, presentation, performance or full Mac acceptance. New helpers
and tests are MIT; modified upstream files retain their BSD notices. Every owned
stage input, output and patch is pinned; module-cache sources are unchanged.
''')
f=r/'drivers/cogent/native/dependencies.json';d=json.loads(f.read_text());assert len(d['dependencies'][0]['stages'])==51
base='native/patches/pipelinelifecycle/'
d['dependencies'][0]['stages'].append({'origin':'drivers/cogent/native/patches/pipelinelifecycle','inputs':base+'original-hashes.json','outputs':base+'output-hashes.json','patches':[{'file':base+file.name,'sha256':h(file)}]});f.write_text(json.dumps(d,indent=2)+'\n')
f=r/'drivers/cogent/prepare_test.py';s=f.read_text();assert 'list(range(1, 52))' in s;f.write_text(s.replace('list(range(1, 52))','list(range(1, 53))'))
f=r/'specs/gpu-frame-lifecycle.md';f.write_text(f.read_text()+'''
## Pipeline replacement ownership

Shader reload admits a fresh live module before replacing the current reference.
Factory refusal preserves the current module and retires any returned partial
reference. Success publishes the new module and explicitly retires the previous
one. Existing native pipelines retain their dependencies; callers rebuild them
to use new code. Shader retirement clears ownership before releasing the handle.

A bind-group replacement leaves current ownership, generation and retirement
queue unchanged on refusal. Only successful replacement queues the previous
group, once, for pass-completion/shutdown retirement. Matching live generations
reuse the current binding. Pipeline retirement detaches both cache maps. Native
factories return fresh owned references and callers serialize use/reconfiguration;
external native retirement and copied ownership remain outside this contract.

Counted admission/refusal/retry fixtures and tiny headless duplicate-layout
validation/shader-output checks qualify their observed reference scope. They do
not establish GPU/native heap reclamation, physical faults, presentation,
sustained performance or full Mac acceptance.
''')
f=r/'specs/macos-completion.md';f.write_text(f.read_text()+'''
Shader reload and bind-group replacement now have transactional owned-reference
publication in the [GPU ownership contract](gpu-frame-lifecycle.md). Refusal keeps
the current cache generation and retirement queue intact; successful reload
explicitly retires the prior module. Internal fault kernels and tiny headless
layout-refusal/retry checks remain separate from native/GPU memory, sustained
performance, physical backend faults and live Mac qualification.
''')
source_names=sorted([str(q.relative_to(r)) for q in owned.iterdir() if q.is_file()]+['drivers/cogent/native/dependencies.json','drivers/cogent/prepare_test.py','specs/gpu-frame-lifecycle.md','specs/macos-completion.md'])
assert len(source_names)==8
source={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip(),'sources':{n:h(r/n)for n in source_names},'decoded_outputs':outputs,'candidate_manifest_sha256':h(p/'candidate-final.json')}
(p/'source-final.json').write_text(json.dumps(source,indent=2)+'\n')
print('Registered patch52:',len(outputs),'outputs;',len(source_names),'root leaves')
