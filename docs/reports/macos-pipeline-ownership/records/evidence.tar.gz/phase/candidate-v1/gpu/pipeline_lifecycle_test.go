// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import (
	"errors"
	"testing"
)

type pipelineReference struct {
	live     bool
	releases int
}

func (r *pipelineReference) IsValid() bool { return r != nil && r.live }
func (r *pipelineReference) Release()      { r.live = false; r.releases++ }

func TestVellumPipelineReplacementRefusalAndRetry(t *testing.T) {
	failure := errors.New("injected replacement failure")
	for _, scenario := range []string{"error", "partial", "nil", "invalid"} {
		t.Run(scenario, func(t *testing.T) {
			old := &pipelineReference{live: true}
			for attempt := 0; attempt < 3; attempt++ {
				candidate := &pipelineReference{live: scenario != "invalid"}
				factory := func() (*pipelineReference, error) {
					switch scenario {
					case "error":
						return nil, failure
					case "partial":
						return candidate, failure
					case "nil":
						return nil, nil
					default:
						return candidate, nil
					}
				}
				module := old
				if err := replacePipelineReference(&module, factory); err == nil || module != old || !old.live || old.releases != 0 {
					t.Fatal("shader refusal changed old ownership", err, old)
				}
				want := 0
				if scenario == "partial" || scenario == "invalid" {
					want = 1
				}
				if candidate.releases != want {
					t.Fatal("partial shader release", candidate.releases, want)
				}
				candidate = &pipelineReference{live: scenario != "invalid"}
				current := map[int]*pipelineReference{2: old}
				counts := map[int]int{2: 7}
				var retired []*pipelineReference
				if result, err := refreshPipelineBinding(&current, &counts, &retired, 2, 8, factory); err == nil || result != nil || current[2] != old || counts[2] != 7 || len(retired) != 0 || !old.live || old.releases != 0 {
					t.Fatal("binding refusal changed ownership/generation", result, err, counts, retired)
				}
				if candidate.releases != want {
					t.Fatal("partial binding release", candidate.releases, want)
				}
				replacement := &pipelineReference{live: true}
				calls := 0
				create := func() (*pipelineReference, error) { calls++; return replacement, nil }
				result, err := refreshPipelineBinding(&current, &counts, &retired, 2, 8, create)
				if err != nil || result != replacement || counts[2] != 8 || len(retired) != 1 || retired[0] != old || !old.live {
					t.Fatal("successful retry did not retire old once", err, retired)
				}
				result, err = refreshPipelineBinding(&current, &counts, &retired, 2, 8, create)
				if err != nil || result != replacement || calls != 1 || len(retired) != 1 {
					t.Fatal("matching binding was recreated", calls, err)
				}
			}
		})
	}
}

func TestVellumShaderReplacementPublishesBeforeRetirement(t *testing.T) {
	old := &pipelineReference{live: true}
	current := old
	for i := 0; i < 1000; i++ {
		next := &pipelineReference{live: true}
		if err := replacePipelineReference(&current, func() (*pipelineReference, error) { return next, nil }); err != nil {
			t.Fatal(err)
		}
		if current != next || old.live || old.releases != 1 || next.releases != 0 {
			t.Fatal("replacement leaked or released wrong owner", i)
		}
		old = next
	}
}

func TestVellumPipelineBindingEmptyAndInvalidCache(t *testing.T) {
	var current map[int]*pipelineReference
	var counts map[int]int
	var retired []*pipelineReference
	failure := errors.New("refused")
	if result, err := refreshPipelineBinding(&current, &counts, &retired, 0, 0, func() (*pipelineReference, error) { return nil, failure }); result != nil || err == nil || current != nil || counts != nil || retired != nil {
		t.Fatal("empty refusal mutated cache")
	}
	invalid := &pipelineReference{}
	current = map[int]*pipelineReference{0: invalid}
	counts = map[int]int{0: 0}
	next := &pipelineReference{live: true}
	if result, err := refreshPipelineBinding(&current, &counts, &retired, 0, 0, func() (*pipelineReference, error) { return next, nil }); err != nil || result != next || len(retired) != 1 || retired[0] != invalid {
		t.Fatal("invalid cache reused", err)
	}
}
