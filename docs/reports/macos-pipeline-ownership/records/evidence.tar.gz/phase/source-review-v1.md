# Pipeline ownership candidate V1

NEEDS_FIX for two fixture defects: the wrong-usage Value buffer is repaired before reaching native binding creation, and the teardown drops unique retired binding references on an early failure. Production/helper ownership is sound under fresh factory and serialized-owner contracts.

Exact five candidate and two original source hashes are bound in the JSON certificate. No tests or native code were run by this reviewer. Broader layout propagation, rebuild policy and physical memory/performance are excluded.
