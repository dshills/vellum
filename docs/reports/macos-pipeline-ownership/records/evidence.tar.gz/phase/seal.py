"""Seal a scoped source/test/review checkpoint; never execute an application."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-pipeline-ownership');report=r/'docs/reports/macos-pipeline-ownership';records=report/'records'
h=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source=json.loads((p/'source-final.json').read_text());assert all(h(r/n)==v for n,v in source['sources'].items())
prepared={q.relative_to(r/'drivers/cogent/build').as_posix():h(q)for module in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/module).rglob('*'))if q.is_file()}
assert len(prepared)==6198 and all(prepared['upstream/'+n]==v for n,v in source['decoded_outputs'].items())
required=['prepare-owned','gpu-race-owned','vet-owned','prepare-tests-owned','native-compile-owned-v3','adapter-race-owned','pipeline-headless-owned']
receipts={}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv' not in d:continue
 name=f.stem
 for channel in ['stdout','stderr']:
  assert h(p/(name+'.'+channel))==d[channel+'_sha256'],name
 assert d['source_commit']==source['base_commit'] and d['error'] is None and (d['source_delta_stable'] or name=='native-compile-owned-v2') and d['overlay_inputs_before']==d['overlay_inputs_after'],name
 if name in required:
  assert d['exit_code']==0 and d['source_delta_after']==source['sources'] and d['prepared_after']==prepared,name
  if name!='prepare-owned':assert d['prepared_before']==prepared,name
 receipts[name]={'sha256':h(f),'exit_code':d['exit_code'],'final_owned':name in required}
assert set(required)<=set(receipts) and len(receipts)==15,len(receipts)
assert [n for n,v in receipts.items()if v['exit_code']!=0]==['native-compile-owned','pipeline-headless-candidate','pipeline-headless-original']
prism=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and process['source_index_stable'] and process['before']==source['sources']
assert prism['coverage']['complete'] and prism['coverage']['files']==8 and not prism['findings']
assert prism['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
review=json.loads((p/'source-review-final.json').read_text());assert review.get('result',review.get('status'))=='APPROVED_SOURCE' and review['files']==source['sources']
native=(p/'pipeline-headless-owned.stdout').read_text();observations=[json.loads(line.split('VELLUM_PIPELINE_NATIVE ',1)[1])for line in native.splitlines()if line.startswith('VELLUM_PIPELINE_NATIVE ')]
assert len(observations)==2 and observations[0]['old_module_refs_retired']==16 and observations[1]['refused_replacements']==3 and observations[1]['computed_words_checked']==4
baseline=(p/'pipeline-headless-original.stdout').read_text();assert baseline.count('reload retained old module')==16 and baseline.count('failed replacement changed current ownership')==1
q={'result':'PASS_PIPELINE_REFERENCE_OWNERSHIP','base_commit':source['base_commit'],'source':source['sources'],'decoded_outputs':source['decoded_outputs'],'prepared':prepared,'receipts':receipts,'native_observations':observations,'baseline_failed_assertions':17,'baseline_scope':'Unchanged parent prepared6195 plus one final native test overlay and byte-identical original2; no final helper/source patches applied.','prism':{'sha256':h(p/'prism-v1/prism.json'),'process_sha256':h(p/'prism-v1/process.json'),'coverage':prism['coverage']},'source_review_sha256':h(p/'source-review-final.json'),'limits':['No windows/surfaces/input/settings/presentation/performance','Native duplicate layout creation refusal inside VarGroup.bindGroup; not incompatible buffer creation refusal','Wrapper invalidation/refcount calls do not establish native heap reclamation or physical fault recovery','Native consumer compiled only; desktop checks deferred','Stage registration first guard compared40stages to51patches and stopped before manifest change; separate preparation used unchanged6195. Corrected patch-order guard and final52stage patch sequence pass.','Initial native fixture expected wrong-usage refusal; automatic buffer repair admitted valid binding. Initial candidate and raw failure preserved; corrected layout oracle passes.','First native compilation used nonexistent cmd/native-window-cycle; raw1 preserved. Corrected build passed with unstable inventory during Git staging; final repeated cmd/window-cycle-smoke build passes with stable complete inventory.']}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(parents=True,exist_ok=True)
t=prism['coverage']['tokens'][0]
(report/'README.md').write_text(f'''# Mac pipeline replacement ownership

Shader reload previously replaced its module pointer without releasing the old
owned reference. Bind-group replacement queued the current group for retirement
before creating its replacement; refusal left that group both cached and queued.
Repeated refusal could accumulate aliases and later invalidate a cached binding.

Patch 52 admits a fresh live candidate before publication. Shader refusal preserves
the current module; success explicitly retires the prior one. Existing native
pipelines retain their dependencies and require rebuild to use new shader code.
Binding refusal keeps the current reference, generation and retirement queue
unchanged. Successful replacement queues the old group once; matching live
bindings reuse it. Pipeline retirement detaches both cache maps. Factories return
fresh owned references and one owner serializes use and configuration.

## Verification and scope

Final GPU/gpudraw tests pass three race repetitions. The full offscreen adapter
race suite, vet, eleven preparation tests and native window-cycle consumer
compilation pass. The consumer was compiled only. Controlled kernels cover
partial/error/nil/invalid candidates, repeated refusal/retry, invalid-cache
replacement, matching-generation reuse and 1,000 shader reference replacements.

Two tiny actual headless cases retire sixteen prior shader modules and the final
module, preserve the current module after invalid WGSL, and refuse three duplicate
layout bindings before successful replacement/reuse and four exact shader result
words. Old and current bind groups retire at pass completion and pipeline shutdown.
The refusal is native layout creation within VarGroup.bindGroup, not an
incompatible-buffer TryCreateBindGroup failure. No windows, surfaces, input,
settings changes, presentation or performance measurement were used.

The unchanged parent prepared dependency with the final test-only overlay fails
both cases: sixteen retained-module assertions and one premature-retirement-queue
assertion. Explicit fixture cleanup retires unique detached references and avoids
releasing current aliases twice. This is a correctness comparison, not a native
heap or physical-device-fault qualification.

Fifteen command receipts preserve twelve passes and three raw exit-1 attempts.
The initial invalid-buffer fixture was automatically repaired and failed its
refusal oracle; its source and log are retained. The corrected duplicate-layout
fixture passes. A nonexistent native consumer path failed compilation; the actual
window-cycle-smoke path compiles. The original regression is the third raw failure.
The first corrected native build passed while Git staging crossed its two-part
source inventory capture, omitting four newly staged paths in that capture.
Its unstable inventory is preserved and excluded from final qualification; the
final repeat compiles with a stable complete source inventory.
An initial registration guard incorrectly compared forty stages with fifty-one
patches and stopped before manifest mutation; its producer is preserved. The
separate preparation before registration prepared the unchanged 6,195 files.
Final fresh preparation verifies 6,198 files and the complete 1–52 patch sequence.

## Reviews and evidence

Internal review identified the faulty initial native oracle and incomplete
fixture cleanup, then approved the corrected candidate and independently checked
owned patch replay, both static pin maps, prepared outputs and specs. Prism ran
once using Anthropic Claude Sonnet 5.5: complete eight-file coverage,
{prism['coverage']['chunks']} chunks, {t['input']} input/{t['output']} output tokens,
raw exit 0 and no findings. A separate internal evidence review binds this report,
raw receipts, source variants and sealed archive before commit.

The [checkpoint](records/checkpoint.json) binds reviews and the
[archive](records/evidence.tar.gz) with its [member index](records/evidence-index.json).
All 6,198 prepared endpoint identities are recorded; this is not a full compiler,
SDK or static-native-component closure. Native/GPU heap reclamation, actual live
window endurance, sustained performance and full Mac qualification remain open.
Desktop testing remains deferred while the user uses the computer.
''')
# Explicit source families and all bounded phase metadata/logs; omit binaries.
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in ['.json','.py','.md','.go','.stdout','.stderr','.txt','.log']:continue
 if f.name.startswith('evidence-review') or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in source['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size}for n,f in inputs.items()}
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
endpoints={'source_manifest_sha256':h(p/'source-final.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.gz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'source-review-final.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(endpoints,indent=2)+'\n')
(records/'source-review.json').write_bytes((p/'source-review-final.json').read_bytes())
print(json.dumps(endpoints,indent=2))
