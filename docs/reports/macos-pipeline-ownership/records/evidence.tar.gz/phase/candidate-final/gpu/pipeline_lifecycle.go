// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package gpu

import "fmt"

// Factories return fresh owned references. A refusal never publishes a partial
// reference. One serialized owner configures, uses and retires pipeline state.
func admitPipelineReference[R liveOwnedReference](create func() (R, error)) (R, error) {
	var zero R
	candidate, err := create()
	if err != nil || candidate == zero || !candidate.IsValid() {
		if candidate != zero {
			candidate.Release()
		}
		if err == nil {
			err = fmt.Errorf("gpu: pipeline factory returned no live reference")
		}
		return zero, err
	}
	return candidate, nil
}

// Shader replacement preserves the current module on refusal. Native pipelines
// retain their own shader dependencies; callers rebuild them to use new code.
func replacePipelineReference[R liveOwnedReference](current *R, create func() (R, error)) error {
	candidate, err := admitPipelineReference(create)
	if err != nil {
		return err
	}
	old := *current
	*current = candidate
	var zero R
	if old != zero {
		old.Release()
	}
	return nil
}

// Failed creation must not queue the current binding for retirement or change
// its generation. A successful replacement queues it exactly once until pass
// completion/shutdown; previously encoded commands retain their native refs.
func refreshPipelineBinding[R liveOwnedReference](current *map[int]R, counts *map[int]int,
	retired *[]R, group, generation int, create func() (R, error)) (R, error) {
	var zero R
	old, exists := (*current)[group]
	if exists && old != zero && old.IsValid() && (*counts)[group] == generation {
		return old, nil
	}
	candidate, err := admitPipelineReference(create)
	if err != nil {
		return zero, err
	}
	if *current == nil {
		*current = make(map[int]R)
	}
	if *counts == nil {
		*counts = make(map[int]int)
	}
	if old != zero {
		*retired = append(*retired, old)
	}
	(*current)[group], (*counts)[group] = candidate, generation
	return candidate, nil
}
