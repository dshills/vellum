// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

//go:build !js

package gpu

import (
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"testing"

	"github.com/oliverbestmann/webgpu/wgpu"
)

// Opt-in correctness fixture: no windows, surfaces, input, settings or timings.
func TestVellumPipelineNativeOwnership(t *testing.T) {
	if os.Getenv("VELLUM_PIPELINE_GPU_TEST") != "1" {
		t.Skip("explicit headless pipeline fixture required")
	}
	gp, borrowed, err := NoDisplayGPU()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { borrowed.Release(); gp.Release(); ReleaseInstance() }()
	record := func(fields map[string]any) {
		fields["windows_created"], fields["surfaces_created"] = 0, 0
		b, err := json.Marshal(fields)
		if err != nil {
			t.Fatal(err)
		}
		fmt.Printf("VELLUM_PIPELINE_NATIVE %s\n", b)
	}
	t.Run("shader_reload", func(t *testing.T) {
		sh := NewShader("reload", borrowed)
		var modules []*wgpu.ShaderModule
		// Baseline cleanup explicitly retires leaked wrappers, after observation.
		defer func() {
			sh.Release()
			for _, m := range modules {
				m.Release()
			}
		}()
		code := `@compute @workgroup_size(1) fn main() {}`
		if err := sh.OpenCode(code); err != nil {
			t.Fatal(err)
		}
		modules = append(modules, sh.module)
		for i := 0; i < 16; i++ {
			old := sh.module
			if err := sh.OpenCode(code); err != nil {
				t.Fatal(err)
			}
			modules = append(modules, sh.module)
			if sh.module == old || !sh.module.IsValid() {
				t.Fatal("reload did not publish a fresh live shader")
			}
			if old.IsValid() {
				t.Errorf("reload retained old module %d", i)
			}
		}
		current := sh.module
		if err := sh.OpenCode("this is deliberately invalid WGSL"); err == nil {
			t.Fatal("invalid WGSL accepted")
		}
		if sh.module != current || !current.IsValid() {
			t.Fatal("failed reload changed current shader")
		}
		sh.Release()
		sh.Release()
		if current.IsValid() || sh.module != nil {
			t.Fatal("release retained current shader")
		}
		if !t.Failed() {
			record(map[string]any{"case": "shader_reload", "old_module_refs_retired": 16, "current_module_ref_retired": 1, "invalid_reload_preserved_current": true})
		}
	})
	t.Run("binding_failure_retry_and_dispatch", func(t *testing.T) {
		sy := NewComputeSystem(gp, "binding-retry")
		if sy == nil {
			t.Fatal("compute system missing")
		}
		defer sy.Release()
		group := sy.Vars().AddGroup(Storage)
		variable := group.Add("Data", Uint32, 4, ComputeShader)
		other := group.Add("Other", Uint32, 4, ComputeShader)
		group.SetNValues(1)
		pipeline := sy.AddComputePipeline("add")
		shader := pipeline.AddShader("add")
		if err := shader.OpenCode(`@group(0) @binding(0) var<storage,read_write> data: array<u32,4>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id: vec3<u32>) { data[id.x] += 3u; }`); err != nil {
			t.Fatal(err)
		}
		pipeline.AddEntry(shader, ComputeShader, "main")
		sy.Config()
		value := variable.Values.Values[0]
		if err := SetValueFrom(value, []uint32{7, 11, 19, 31}); err != nil {
			t.Fatal(err)
		}
		old, _, err := pipeline.bindGroup(group)
		if err != nil || !old.IsValid() {
			t.Fatal("first binding", err)
		}
		count := pipeline.currentBindGroupsCount[group.Group]
		otherValue := other.Values.Values[0]
		if err := SetValueFrom(otherValue, []uint32{0, 0, 0, 0}); err != nil {
			t.Fatal(err)
		}
		originalBinding := other.Binding
		// The original code may wrongly queue duplicate aliases on failure.
		// Remove those aliases before system-owned current retirement.
		defer func() {
			other.Binding = originalBinding
			seen := make(map[*wgpu.BindGroup]bool)
			for _, binding := range pipeline.currentBindGroups {
				seen[binding] = true
			}
			for _, binding := range pipeline.oldBindGroups {
				if binding != nil && !seen[binding] {
					seen[binding] = true
					binding.Release()
				}
			}
			pipeline.oldBindGroups = nil
		}()
		other.Binding = variable.Binding // native duplicate-layout refusal
		group.ValuesUpdated()
		for i := 0; i < 3; i++ {
			binding, _, err := pipeline.bindGroup(group)
			if err == nil || binding != nil {
				t.Fatal("duplicate layout binding admitted", err)
			}
			if pipeline.currentBindGroups[group.Group] != old || pipeline.currentBindGroupsCount[group.Group] != count || len(pipeline.oldBindGroups) != 0 || !old.IsValid() {
				t.Fatalf("failed replacement changed current ownership: attempt=%d retired=%d", i, len(pipeline.oldBindGroups))
			}
		}
		other.Binding = originalBinding
		replacement, _, err := pipeline.bindGroup(group)
		if err != nil || !replacement.IsValid() || replacement == old || len(pipeline.oldBindGroups) != 1 || pipeline.oldBindGroups[0] != old || !old.IsValid() {
			t.Fatal("retry did not retain one old binding until pass retirement", err)
		}
		again, _, err := pipeline.bindGroup(group)
		if err != nil || again != replacement || len(pipeline.oldBindGroups) != 1 {
			t.Fatal("same generation recreated binding", err)
		}
		pass, err := sy.BeginComputePass()
		if err != nil {
			t.Fatal(err)
		}
		if err := pipeline.Dispatch(pass, 4, 1, 1); err != nil {
			t.Fatal(err)
		}
		pass.End()
		if err := value.GPUToRead(sy.CommandEncoder); err != nil {
			t.Fatal(err)
		}
		if err := sy.EndComputePass(); err != nil {
			t.Fatal(err)
		}
		if old.IsValid() || !replacement.IsValid() || len(pipeline.oldBindGroups) != 0 {
			t.Fatal("pass completion retired wrong binding")
		}
		result := make([]uint32, 4)
		if err := value.ReadSync(); err != nil {
			t.Fatal(err)
		}
		if err := ReadToBytes(value, result); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(result, []uint32{10, 14, 22, 34}) {
			t.Fatal("retry shader output", result)
		}
		pipeline.Release()
		pipeline.Release()
		if replacement.IsValid() || pipeline.currentBindGroups != nil || pipeline.currentBindGroupsCount != nil {
			t.Fatal("pipeline cache retained state")
		}
		record(map[string]any{"case": "binding_failure_retry_and_dispatch", "refused_replacements": 3, "computed_words_checked": 4, "old_binding_refs_retired": 1, "current_binding_refs_retired": 1})
	})
}
