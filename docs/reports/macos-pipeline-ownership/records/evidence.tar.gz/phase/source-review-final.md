# Owned pipeline reference stage review

APPROVED_SOURCE for eight exact root leaves and five decoded/prepared outputs. Patch0052 replays against the two pinned originals and three absent inputs, matches both static maps and the approved final candidate, and is registered after unchanged stages1..51. The preparation regression expects1..52.

The source preserves fresh-reference transactional admission, refusal retry, old-group pass retirement and serialized ownership. The actual native fault fixture is duplicate layout creation inside VarGroup.bindGroup. Corrected cleanup retires unique old refs while preserving current ownership. Scoped specs distinguish reference retirement from physical memory, performance and live Mac acceptance.

prepare-owned records source-stable exit0 and6195→6198 inputs; prepare-before-registration applies only to the original6195 source generation. The earlier failed stage-count guard is retained as failed history, not final preparation evidence. No tests, preparation, native, provider or Git operations were executed by this reviewer.
