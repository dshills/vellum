"""Fabricated records only: discrimination tests for the independent validator."""
import copy,json,unittest
import validate as v

def box(x=10,y=10,w=80,h=24):return dict(Min=dict(X=x,Y=y),Max=dict(X=x+w,Y=y+h))
def element(id,role='button',value='',focused=False,enabled=True,bounds=None,name=''):
 return dict(ID=id,DomainID=id,Parent='',Role=role,Name=name,Value=value,Bounds=bounds or box(),Enabled=enabled,Focused=focused,Selected=False)
def snapshot(frame,w,index):
 els={}
 def add(id,**kw):els[id]=element(id,**kw);return els[id]
 add(v.node(w['Page']),role='column');add(v.pages,role='tabs')
 for page in ['chrome','images','colors']:e=add(v.ident('option','media-pages',page),role='option');e['Selected']=page==w['Page']
 if w['Page']=='chrome':
  add(v.node('media-tools'),role='toolbar',bounds=box(0,0,260,50))
  for n in [0,2,7]:add(v.node('media-tool-'+str(n)),bounds=box(0,0,0,0)if n==7 and index==0 else box())
  add(v.node('media-name'),role='text-field');add(v.node('media-reset-path'));add(v.node('media-form'),role='form-group',name='<Project>');add(v.node('media-status'),role='status-bar',value=f"Tool {w['Last']} / actions {w['Tools']} / path {w['PathRequests']}")
  add(v.workspace,role='label'if w['Path']=='projects/workspace'else'button',enabled=not w['DisablePath'])
 elif w['Page']=='images':
  add(v.node('image-preview'),role='image');add(v.node('image-fit'),role='segmented-control',value=w['Fit'].capitalize());add(v.node('image-replace'))
 else:
  for field,i in zip([v.red,v.green,v.blue,v.alpha],[1,3,5,7]):add(field,role='slider',value=int(w['Hex'][i:i+2],16),enabled=not w['DisableColor'])
  add(v.hexfield,role='text-field',enabled=not w['DisableColor']);add(v.node('ink/color/preview'),role='image',name='Ink color preview '+w['Hex'])
  if w['Invalid']>0 and w['Edits']==5:add(v.node('ink/color/validation'),role='label')
 focus=v.ROWS[index][2]
 if focus:els[v.node(focus)]['Focused']=True
 return dict(Frame=frame,Size=dict(X=900,Y=700),LogicalDPI=160,Elements=list(els.values()),Popups=None,Grids=None,Trees=None,Canvases=None)
def fixture():
 d=dict(Event='vellum.media-native.result',Result='PASS_NATIVE_MEDIA',Error='',Failed=None,Unavailable=False,Session=dict(Started=True,Closed=True,Pending=False,LiveWindows=0,Issued=200),OriginalRefClosed=True,PostCloseInputError='closed',Steps=[],Inputs=[])
 frame=0;stale=None
 for i,(label,_,_)in enumerate(v.ROWS):
  w=v.VALUES[i]
  for p in [p for p in v.PACKETS if p['label'].split('/')[0]==label]:
   frame+=1;s=snapshot(frame,w,i);els={e['ID']:e for e in s['Elements']};target=p['target']
   if target not in els and not label=='hidden-color-refusal':s['Elements'].append(element(target));els[target]=s['Elements'][-1]
   inp=dict(Frame=frame,Target=target,Type=p['typ'],Code=p['code'],Rune=p['rune'],Modifiers=p['mods'],Button='Left'if p['typ']in['MouseDown','MouseUp']else'NoButton',Position=dict(X=0,Y=0),Delta=dict(X=0,Y=0))
   if target in els:
    e=els[target];e['Enabled']=not p['reject'];e['Focused']=True
    if p['typ']in['MouseDown','MouseUp']:e['Bounds']=box();inp['Position']=dict(X=50,Y=22)
   if p.get('stale'):inp=copy.deepcopy(stale)
   if p['label']=='breadcrumb-accept/MouseDown':stale=copy.deepcopy(inp)
   d['Inputs'].append(dict(Label=p['label'],Before=s,Input=inp,Rejected=p['reject']))
  frame+=1;d['Steps'].append(dict(Label=label,Model=w.copy(),Snapshot=snapshot(frame,w,i)))
 return d
class ValidatorControls(unittest.TestCase):
 def validate(self,d):return v.validate((json.dumps(d)+'\n').encode(),b'')
 def test_positive(self):self.assertEqual(self.validate(fixture())['inputs'],71)
 def test_negatives(self):
  def obs(d,label):return next(x for x in d['Steps']if x['Label']==label)
  def el(o,id):return next(x for x in o['Snapshot']['Elements']if x['ID']==id)
  def fresh_stale(d):
   item=next(x for x in d['Inputs']if x['Label'].startswith('breadcrumb-stale-frame'));item['Input']['Frame']=item['Before']['Frame']
  changes={
   'wrong callback':lambda d:obs(d,'toolbar-action')['Model'].update(Tools=2),
   'wrong color':lambda d:obs(d,'color-straight-alpha')['Model'].update(Hex='#F001ABFF'),
   'missing input':lambda d:d['Inputs'].pop(),
   'wrong rejection':lambda d:next(x for x in d['Inputs']if x['Rejected']).update(Rejected=False),
   'hidden disabled confound':lambda d:obs(d,'hidden-color-refusal')['Model'].update(DisableColor=True),
   'toolbar no overflow':lambda d:el(d['Steps'][0],v.node('media-tool-7')).update(Bounds=box()),
   'toolbar focus outside viewport':lambda d:el(obs(d,'toolbar-end'),v.node('media-tool-7')).update(Bounds=box(400)),
   'wrong role':lambda d:el(obs(d,'images-page'),v.node('image-preview')).update(Role='AXImage'),
   'missing focused state':lambda d:el(obs(d,'color-tab'),v.red).update(Focused=False),
   'pending session':lambda d:d['Session'].update(Pending=True),
   'unavailable result':lambda d:d.update(Unavailable=True),
   'fresh stale frame':fresh_stale,
   'extra console outcome':lambda d:d.update(Result='FAILED_NATIVE_MEDIA'),
  }
  for name,change in changes.items():
   with self.subTest(name=name):
    d=fixture();change(d)
    with self.assertRaises((ValueError,KeyError,TypeError)):self.validate(d)
if __name__=='__main__':unittest.main(verbosity=2)
