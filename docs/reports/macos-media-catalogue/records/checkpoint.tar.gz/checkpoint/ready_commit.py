from audit import *
import tarfile
R=T/'docs/reports/macos-media-catalogue/records';review=read(Q/'internal-commit-review.json');scope=read(Q/'final-scope.json');provider=read(Q/'review-scope.json');K=Q/'corrected-native';plan=read(K/'plan.json');proof=read(Q/'corrected-boundary.json');native=read(K/'result.json')
assert review['approved']and review['commit_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items())
assert set(review['inputs'])>={str(R/n)for n in ['checkpoint.tar.gz','manifest.json','archive.json']}|{str(Q/n)for n in ['ready_commit.py','post_promotion.py','audit.py','corrected-boundary.json']}
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD and not git(C,'status','--porcelain')and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
assert sha(Q/'final-staged.diff')==scope['staged_diff_sha256']==review['staged_diff_sha256']==hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()
assert len(scope['paths'])==15 and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths'])and all(sha(T/n)==v for n,v in scope['files'].items())
updates=read(Q/'post-provider-updates.json')['paths'];assert scope['post_provider_changed_paths']==updates and {k for k,v in provider['source_hashes'].items()if sha(k)!=v}=={str(T/n)for n in updates}
assert all(sha(Q/'provider-source'/n)==provider['source_hashes'][str(T/n)]for n in provider['paths'])
assert all(sha(T/n)==v for n,v in proof['all_Go_source'].items())and prepared(C)==prepared(T)==plan['prepared']and vector(Path(plan['sdk']))==plan['sdk_files']
assert native['result']=='PASS_NATIVE_MEDIA'and native['post_boundary_pass']and passing(native['run'])and(K/'stop-live').is_file()and(Q/'stop-live').is_file()and all(sha(k)==v for k,v in plan['pins'].items())and sha(plan['binary']['path'])==plan['binary']['sha256']
p=read(Q/'prism.json');cov=p['coverage'];assert cov['files']==len(provider['paths'])and cov['bytes']==provider['bytes']and cov['complete']and cov['llmCalls']==1 and not cov['excluded']and not cov['skipped']and not cov['truncatedBytes']and not p['suppressed']
assert read(Q/'prism-command.json')['staged_diff_sha256']==provider['staged_diff_sha256']==sha(Q/'prism-staged.diff')
d=read(Q/'internal-prism-disposition.json');assert d['approved']and not d['unresolved_findings']and all(sha(k)==v for k,v in d['inputs'].items())
assert {f['id']for f in p['findings']}==set(d['retained_finding_ids'])and {f['finding']['id']for f in p['discarded']}==set(d['discarded_finding_ids'])
manifest=read(R/'manifest.json');seen=set();expanded=0
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in manifest and m.name not in seen and not m.name.startswith('/')and '..'not in Path(m.name).parts
  seen.add(m.name);expanded+=m.size;assert len(seen)<=256 and expanded<=32<<20 and m.size<=10<<20
  data=tar.extractfile(m).read();assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
a=read(R/'archive.json');assert seen==set(manifest)and a['members']==len(seen)and a['expanded_bytes']==expanded and a['archive_sha256']==sha(R/'checkpoint.tar.gz')and a['manifest_sha256']==sha(R/'manifest.json')and a['archive_bytes']==(R/'checkpoint.tar.gz').stat().st_size<=8<<20
before=source(T);git(T,'diff','--cached','--check');print(git(T,'commit','-m','Qualify native media chrome and composite controls').decode());head=git(T,'rev-parse','HEAD').decode().strip();assert not git(T,'status','--porcelain')and source(T)==before
print(git(C,'merge','--ff-only',head).decode());assert git(C,'rev-parse','HEAD').decode().strip()==head and not git(C,'status','--porcelain')and source(C)==before
r={'commit':head,'canonical_clean':True,'candidate_clean':True,'native_result':'PASS_NATIVE_MEDIA','prepared_stage86_unchanged':True,'sdk_refreshed':False,'goal_complete':False};(Q/'commit-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
