from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
paths=['drivers/cogent/cmd/gallery/main.go', 'drivers/cogent/cmd/gallery/media_views.go', 'drivers/cogent/cmd/gallery/media_catalogue.go', 'drivers/cogent/cmd/gallery/media_catalogue_offscreen_test.go', 'drivers/cogent/cmd/gallery/media_catalogue_test.go', 'drivers/cogent/cmd/gallery/README.md', 'specs/control-acceptance.md', 'specs/macos-completion.md', 'specs/macos-delivery.md', 'docs/reports/macos-media-catalogue/README.md']
run_child(['git','diff','--check'],cwd=T,timeout=30,check=True,capture_output=True)
run_child(['git','add','--',*paths],cwd=T,timeout=30,check=True,capture_output=True)
assert set(run_child(['git','diff','--cached','--name-only'],cwd=T,timeout=30,check=True,capture_output=True).stdout.decode().splitlines())==set(paths)
diff=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,check=True,capture_output=True).stdout
(W/'staged.diff').write_bytes(diff)
d={'paths':paths,'source_hashes':{str(T/p):hashlib.sha256((T/p).read_bytes()).hexdigest()for p in paths},'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'bytes':len(diff),'raw_evidence_review_required':True,'archive_review_pending':True}
(W/'review-scope.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'files':len(paths),'bytes':len(diff),'sha256':d['staged_diff_sha256']}))
