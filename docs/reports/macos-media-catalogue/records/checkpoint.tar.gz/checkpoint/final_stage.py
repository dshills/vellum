from audit import *
provider=read(Q/'review-scope.json');updates=read(Q/'post-provider-updates.json')['paths'];assert {k for k,v in provider['source_hashes'].items()if sha(k)!=v}=={str(T/n)for n in updates}
assert all(sha(Q/'provider-source'/n)==provider['source_hashes'][str(T/n)]for n in provider['paths'])
paths=provider['paths']+['drivers/cogent/cmd/gallery/media_lifecycle_test.go']+['docs/reports/macos-media-catalogue/records/'+n for n in ['results.json','checkpoint.tar.gz','manifest.json','archive.json']]
git(T,'add','--',*paths);git(T,'diff','--cached','--check');assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(paths)and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
diff=git(T,'diff','--cached','--binary');(Q/'final-staged.diff').write_bytes(diff)
r={'paths':paths,'files':{n:sha(T/n)for n in paths},'base_commit':HEAD,'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'post_provider_changed_paths':updates,'post_provider_new_tests':['drivers/cogent/cmd/gallery/media_lifecycle_test.go'],'raw_evidence_added_for_internal_review':paths[11:]};(Q/'final-scope.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'files':len(paths),'bytes':len(diff),'sha256':r['staged_diff_sha256']}))
