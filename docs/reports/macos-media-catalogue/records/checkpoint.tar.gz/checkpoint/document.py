from pathlib import Path
import json
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-media-catalogue';R.mkdir(parents=True,exist_ok=True);(R/'records').mkdir(exist_ok=True)
r=json.loads((Q/'result.json').read_bytes());assert r['result']=='PASS_NATIVE_MEDIA'and r['post_boundary_pass']
text='''# Media, chrome and composite catalogue

The dedicated `gallery -media-native-check` consumer completes all **71 native
Go FIFO inputs and 42 independently expected observations** on the controlled
Darwin/ARM64 Go 1.25.6/GOMAXPROCS2 SDK786a configuration. The shared ordinary
constructors remain available in the normal gallery: images/colors pages and a
new Chrome page for overflowing toolbar, literal form caption and status.
The acceptance view composes the existing Breadcrumb beside those controls.

Actual native routing passes toolbar End/Home, disabled skipping, clipped-focus
reveal, one activation and form traversal; accepted/rejected/disabled Breadcrumb
navigation, current-location role change and old-frame refusal; image fit
selection and replacement callback; ColorPicker byte/hex, rejection,
normalization, invalid input, straight alpha, disabled and separately enabled-
but-hidden refusal. Exact callback totals are 1 toolbar action, 3 breadcrumb
requests, 3 fit proposals, 1 replacement, 6 color proposals (including the rejected one) and 1
invalid input. Values flow through public callbacks. Owner changes configure
rejection/disabled policy only. Every key requires actual focus; pointer targets
use fresh measured bounds and capabilities. The original window is closed and
rejects further input. Session closes with Pending=false, LiveWindows=0; owned
process group 17984 is absent after 6.759 seconds. No font diagnostics occur.

An independent Python oracle checks the complete authored model/packet record,
focus, roles, geometry, clipping, stale frames, interleaving and retirement. Its
fabricated positive and 13 negative controls pass; these are validator tests, not
native evidence. The native raw stdout is 757,739 bytes and stderr empty. Whole
source/prepared/SDK and binary boundaries match before/after the case while the
shared lease remains held. The terminal scope is permanently sealed; no retry.

The separate public Manual preflight passes at 160/162 DPI. It tests the same
accepted states and exact callbacks using the available public routing surface;
Manual uses keyboard navigation for page/segment options and its verified active
Select All binding. Native uses pointer option targets and verifies Meta+A.
Manual separately proves retired control-incarnation refusal. Known opaque strip
pixels change from (240,64,48,255) to (240,192,0,255)at stable measured image geometry,
while the old immutable source remains unchanged. Focus-ring changes cannot
satisfy that oracle. Native checks do not claim image pixels or presentation.

Initial internal review corrected four checker defects before native admission:
Cocoa-versus-public image role naming, ambiguous stale-target evidence, window-
only toolbar visibility, and whole-window image comparisons. Early offscreen
iterations also expose a compile assumption, distinct stale/disabled identities,
missing Manual option nodes, different active key bindings and retained hidden
geometry. Those failed receipts and source versions remain recorded. Full final
gallery race, default gallery vet, native build and owned validator controls pass.
No backend scheduling/acquisition policy or prepared stage86 bytes change.

This advances named M2 catalogue coverage. Structural, text/modal, remaining
workflow and full M2/M5 acceptance stay open. Automated native Go routing is
separate from OS/physical input, IME, human VoiceOver, native pixels, display
presentation, performance, memory/endurance and rights/distribution. M3–M7 remain
open. The typed unavailable error path is not exercised by this successful case;
a future unavailable result would terminate without automatic retry. The previous
failed structural and placement scopes remain sealed.

See [results](records/results.json), [bounded evidence archive](records/checkpoint.tar.gz)
and [manifest](records/manifest.json). The unchanged 7,880-file SDK uses its pinned
source-built native archive; this does not qualify the checkout's default cached
library. No SDK refresh, OS settings/input-source/clipboard changes or public
release occurs. Internal reviews and one scoped Prism Anthropic Claude Sonnet 5.5
review are required before the local checkpoint commit.
'''
(R/'README.md').write_text(text)
p=T/'drivers/cogent/cmd/gallery/README.md';s=p.read_text();assert '## Native media and chrome catalogue'not in s
s+='''
## Native media and chrome catalogue

```sh
go run ./cmd/gallery -media-native-check
```

This independent 900x700 requested view reuses the ordinary images/colors pages,
Chrome toolbar/form/status page and public Breadcrumb component. It completes 71
Go FIFO inputs and 42 observations with exact callbacks, actual keyboard focus,
measured pointer targets, overflow reveal and disabled/stale/hidden refusal.
The original window closes and the session/process retires. A 90-second scenario
deadline and 6-second worker join bound the mode; failure exits nonzero and a typed
drawable-unavailable result stops the case without retry. It is exclusive with
the other check/smoke flags and disables process-local geometry persistence.

The controlled Go 2/SDK786a native record passes. Software Manual image pixels are
separate evidence; native pixels, physical/OS input, IME/VoiceOver, presentation
and full Mac acceptance remain open. See the [result](../../../../docs/reports/macos-media-catalogue/README.md).
'''
p.write_text(s)
p=T/'specs/control-acceptance.md';s=p.read_text();updates={
'| `Image` |':'`; native `gallery -media-native-check` checks accepted fit/replacement callbacks, role and visible geometry (native pixels separate)',
'| `Toolbar` |':'`; native `gallery -media-native-check` checks actual overflow reveal, End/Home, disabled skipping and one activation',
'| `StatusBar` |':'`; native `gallery -media-native-check` checks accepted caption after toolbar/path actions',
'| `FormGroup` |':'`; native `gallery -media-native-check` checks literal caption and actual field traversal',
'| Breadcrumb composite |':'`; native `gallery -media-native-check` checks accepted/rejected/disabled path, current role and stale-frame refusal',
'| ColorPicker composite |':'`; native `gallery -media-native-check` checks byte/hex/reject/normalize/invalid/straight-alpha and disabled/hidden refusal',
}
lines=s.splitlines()
for i,line in enumerate(lines):
 for prefix,extra in updates.items():
  if line.startswith(prefix):
   # Append evidence in the scenario cell, preserving existing evidence marks.
   cells=line.rsplit(' | ',1);lines[i]=cells[0]+extra.replace('`;',';')+' | '+cells[1].replace('R |','R/N |').replace('R/A |','R/A/N |')
s='\n'.join(lines)+'\n';p.write_text(s)
note='''
The [media/chrome catalogue checkpoint](../docs/reports/macos-media-catalogue/README.md)
completes 71 native Go FIFO inputs/42 observations for shared Image, Toolbar,
StatusBar, FormGroup, Breadcrumb and ColorPicker views. Actual focus, measured
pointer targets, overflow, accepted/rejected/disabled/stale/hidden states and
exact callbacks pass; original window/session/process retire. Public Manual
160/162 DPI routing and independently sampled immutable-image replacement pixels,
full gallery race/vet/build and 13 negative validator controls pass separately.
Initial checker/preflight failures remain preserved. This is controlled
Go 2/SDK786a native routing; physical/OS input, IME/human accessibility, native
pixels/presentation and full M2/M5/M3–M7 stay open. No SDK refresh occurs.
'''
for n in ['control-acceptance.md','macos-completion.md','macos-delivery.md']:
 p=T/'specs'/n;s=p.read_text();assert 'media/chrome catalogue checkpoint'not in s;p.write_text(s+note)
checks={n:json.loads((Q/(n+'.json')).read_bytes())for n in [*[f'focused-v{i}'for i in range(1,8)],'gallery-final','vet-final','build-final','validation-final']}
results={'base_commit':'db98a6b31013d231c4ce3ba0fd0c320db5cf2961','native_result':r,'checks':checks,'preflight_failed_iterations_preserved':list(checks)[:6],'software_pixels_only':True,'physical_input_verified':False,'native_pixels_verified':False,'typed_unavailable_path_exercised':False,'sdk_refreshed':False,'closed_full_mac_gates':[]}
(R/'records/results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'documents_written':True,'native_result':r['result'],'raw_input_count':71,'observations':42}))
