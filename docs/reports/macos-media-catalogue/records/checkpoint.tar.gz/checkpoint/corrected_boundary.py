from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;K=Q/'corrected-native'
s=importlib.util.spec_from_file_location('corrected_media_run',K/'run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sha=h.sha;read=h.read;C=h.C;T=h.T
p=read(K/'plan.json');r=read(K/'result.json');a=read(K/'admission.json')
assert r['result']=='PASS_NATIVE_MEDIA'and r['post_boundary_pass']and h.passing(r['run'])and a['approved']and a['plan_sha256']==sha(K/'plan.json')and(K/'stop-live').is_file()and(Q/'stop-live').is_file()
assert all(sha(k)==v for k,v in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
for stream,info in r['run']['logs'].items():
 f=K/'case'/stream;assert f.stat().st_size==info['bytes']and sha(f)==info['sha256']
assert h.validator.validate((K/'case/stdout').read_bytes(),(K/'case/stderr').read_bytes())==r['summary']
assert not h.git(C,'status','--porcelain')and h.git(C,'rev-parse','HEAD').decode().strip()==h.HEAD and all(sha(C/n)==v for n,v in p['canonical_source'].items())
docs=read(Q/'post-provider-updates.json')['post_corrected_native_docs']
assert {n for n,v in p['candidate_source'].items()if sha(T/n)!=v}==set(docs)
assert h.prepared(C)==h.prepared(T)==p['prepared']==p['canonical_prepared']and h.vector(h.SDK)==p['sdk_files']
go={n:v for n,v in p['candidate_source'].items()if n.endswith('.go')};assert len(go)==720 and all(sha(T/n)==v for n,v in go.items())
provider=read(Q/'review-scope.json');updates=read(Q/'post-provider-updates.json')['paths'];assert {k for k,v in provider['source_hashes'].items()if sha(k)!=v}=={str(T/n)for n in updates}
assert all(sha(Q/'provider-source'/n)==provider['source_hashes'][str(T/n)]for n in provider['paths'])
d={'result':'CORRECTED_MEDIA_NATIVE_BOUNDARY_PASS','head':h.HEAD,'all_Go_source':go,'Go_files':len(go),'native_and_checked_source_unchanged':True,'post_corrected_native_modified_paths':docs,'post_provider_changed_paths':updates,'native_case':r['summary'],'native_seconds':r['run']['seconds'],'owned':r['run']['owned'],'full_source_boundary_at_native_exit':True,'prepared_files':len(p['prepared']),'prepared_sha256':h.digest(p['prepared']),'sdk_files':len(p['sdk_files']),'sdk_sha256':h.digest(p['sdk_files']),'sdk_refreshed':False,'closed_full_mac_gates':[]}
(Q/'corrected-boundary.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='all_Go_source'}))
