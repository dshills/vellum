from pathlib import Path
import shutil
q=Path(__file__).resolve().parent;d=Path('/private/tmp/vellum-macos-native-results-97aee13/drivers/cogent/cmd/gallery');v=q/'versions/v4';v.mkdir(parents=True)
for n in ['media_catalogue.go','media_catalogue_offscreen_test.go']:shutil.copy2(d/n,v/n)
p=d/'media_catalogue.go';s=p.read_text().replace('"cogentcore.org/core/events/key"','"cogentcore.org/core/events/key"\n "cogentcore.org/core/keymap"')
s=s.replace('if step.Kind == "text" {\n', '''if step.Kind == "text" {
 if keymap.Of(key.NewChord('a',key.CodeA,catalogueSelectAllModifiers()))!=keymap.SelectAll{err=errors.New("native Meta+A is not Select All");return}
''')
s=s.replace('if step.Want.Page == "chrome" {','''if step.Want.Page == "chrome" {
 toolbar,e:=visible("media-tools");if e!=nil{return e}
 if strings.HasPrefix(step.Focus,"media-tool-"){tool,e:=visible(step.Focus);if e!=nil{return e};if !tool.Bounds.In(toolbar.Bounds){return errors.New("focused tool outside toolbar viewport")}}
 if step.Label=="initial"{last,e:=catalogueElement(s,"media-tool-7");if e!=nil{return e};if !last.Bounds.Empty()&&last.Bounds.In(toolbar.Bounds){return errors.New("fixture does not overflow toolbar")}}
''');p.write_text(s)
p=d/'media_catalogue_offscreen_test.go';s=p.read_text().replace('\n\t"bytes"','\n "image"').replace('"cogentcore.org/core/events/key"','"cogentcore.org/core/events/key"\n "cogentcore.org/core/keymap"');s=s.replace('var initialImage []byte','var initialImage image.Rectangle\n var originalSample color.NRGBA\n originalSource:=g.picture\n selectAll:=catalogueSelectAllModifiers()\n if keymap.Of(key.NewChord(\'a\',key.CodeA,selectAll))!=keymap.SelectAll {selectAll=0;selectAll.SetFlag(true,key.Control)}\n if keymap.Of(key.NewChord(\'a\',key.CodeA,selectAll))!=keymap.SelectAll{t.Fatal("no tested Select All binding") }')
s=s.replace('in.Modifiers = catalogueSelectAllModifiers()','in.Modifiers = selectAll')
a=s.index('\n\t\tif step.Label == "image-contain"');b=s.index('\n\t}\n\tif g.mediaTools',a)
s=s[:a]+'''
  if strings.HasPrefix(step.Focus,"media-tool-")&&!find(step.Focus).Bounds.In(find("media-tools").Bounds){t.Fatal("focused tool outside toolbar viewport",step.Label)}
  if step.Label=="initial"{last:=find("media-tool-7");if !last.Bounds.Empty()&&last.Bounds.In(find("media-tools").Bounds){t.Fatal("fixture does not overflow")}}
  if step.Label=="image-contain" {
   im,e:=m.Capture(ctx,"gallery");if e!=nil{t.Fatal(e)}
   initialImage=find("image-preview").Bounds
   sample:=image.Pt(initialImage.Min.X+initialImage.Dx()/6,initialImage.Min.Y+initialImage.Dy()/2)
   originalSample=color.NRGBAModel.Convert(im.At(sample.X,sample.Y)).(color.NRGBA)
   if originalSample!=(color.NRGBA{R:240,G:64,B:48,A:255}){t.Fatal("independent original strip pixel",sample,initialImage,originalSample)}
  }
  if step.Label=="image-replace" {
   im,e:=m.Capture(ctx,"gallery");if e!=nil{t.Fatal(e)}
   box:=find("image-preview").Bounds;if box!=initialImage{t.Fatal("replacement changed image geometry")}
   sample:=image.Pt(box.Min.X+box.Dx()/6,box.Min.Y+box.Dy()/2)
   actual:=color.NRGBAModel.Convert(im.At(sample.X,sample.Y)).(color.NRGBA)
   if actual!=(color.NRGBA{R:240,G:192,A:255})||actual==originalSample||g.picture==originalSource||originalSource.NRGBAAt(0,0)!=(color.NRGBA{R:240,G:64,B:48,A:255}){t.Fatal("replacement pixels/immutable prior source",actual)}
  }
'''+s[b:];p.write_text(s)
print('Strengthened actual viewport/pixel oracles; select-all follows unchanged active Manual keymap')
