"""Independent media record oracle. Synthetic controls never qualify native UI."""
from pathlib import Path
import importlib.util,json,re
COMMON=Path(__file__).resolve().parents[1]/'macos-acquisition-diagnostics-4ce6ba4/validate.py'
spec=importlib.util.spec_from_file_location('catalogue_geometry_oracle',COMMON);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
need=v.need;node=v.node;ident=v.id;snapshot=v.snapshot
workspace=node('project-path/breadcrumb/item/d29ya3NwYWNl');red=node('ink/color/red');green=node('ink/color/green');blue=node('ink/color/blue');alpha=node('ink/color/alpha');hexfield=node('ink/color/hex');pages=node('media-pages')
# Independently authored state transitions; production callbacks are not imported.
INITIAL=dict(Page='chrome',Path='projects/workspace/document',Fit='contain',Hex='#2060E0FF',Text='Vellum',Tools=0,Last=0,PathRequests=0,FitRequests=0,Replacements=0,Edits=0,Invalid=0,RejectPath=False,DisablePath=False,RejectColor=False,NormalizeColor=False,DisableColor=False)
ROWS=[
 ('initial',{},'media-tool-0'),('toolbar-end',{},'media-tool-7'),('toolbar-action',dict(Tools=1,Last=7),'media-tool-7'),('toolbar-home',{},'media-tool-0'),('toolbar-skip-disabled',{},'media-tool-2'),('toolbar-last',{},'media-tool-7'),('form-traversal',{},'media-name'),
 ('breadcrumb-accept',dict(Path='projects/workspace',PathRequests=1),''),('breadcrumb-stale-frame',{},''),('breadcrumb-reset',dict(Path='projects/workspace/document'),'media-reset-path'),('breadcrumb-reject-policy',dict(RejectPath=True),''),('breadcrumb-rejected',dict(PathRequests=2),'project-path/breadcrumb/item/d29ya3NwYWNl'),('breadcrumb-disabled',dict(RejectPath=False,DisablePath=True),''),('breadcrumb-disabled-refusal',{},''),('breadcrumb-enabled',dict(DisablePath=False),''),('breadcrumb-restored',dict(Path='projects/workspace',PathRequests=3),''),
 ('images-page',dict(Page='images'),'media-pages'),('image-cover',dict(Fit='cover',FitRequests=1),'image-fit'),('image-stretch',dict(Fit='stretch',FitRequests=2),'image-fit'),('image-contain',dict(Fit='contain',FitRequests=3),'image-fit'),('image-replace',dict(Replacements=1),'image-replace'),
 ('colors-page',dict(Page='colors'),'media-pages'),('color-tab',{},'ink/color/red'),('color-red-step',dict(Hex='#2160E0FF',Edits=1),'ink/color/red'),('color-red-max',dict(Hex='#FF60E0FF',Edits=2),'ink/color/red'),('color-reject-policy',dict(RejectColor=True),'ink/color/red'),('color-rejected',dict(Edits=3),'ink/color/red'),('color-normalize-policy',dict(RejectColor=False,NormalizeColor=True),'ink/color/red'),('color-green-tab',{},'ink/color/green'),('color-blue-tab',{},'ink/color/blue'),('color-alpha-tab',{},'ink/color/alpha'),('color-alpha-normalized',dict(Edits=4),'ink/color/alpha'),('color-hex-tab',{},'ink/color/hex'),('color-hex-accepted',dict(Hex='#AABBCCFF',Edits=5),''),('color-hex-invalid',dict(Invalid=1),''),('color-straight-alpha-policy',dict(NormalizeColor=False),''),('color-straight-alpha',dict(Hex='#F001AB00',Edits=6),''),('color-disabled',dict(DisableColor=True),''),('color-disabled-refusal',{},''),('color-reenabled',dict(DisableColor=False),''),('chrome-return',dict(Page='chrome'),'media-pages'),('hidden-color-refusal',{},'media-pages'),
]
VALUES=[];w=INITIAL.copy()
for label,change,focus in ROWS:w={**w,**change};VALUES.append(w)
PACKETS=[]
def key(label,target,code,rune=0,mods=''):PACKETS.append(dict(label=label+'/KeyChord',target=target,typ='KeyChord',code=code,rune=rune,mods=mods,reject=False))
def click(label,target):
 for typ in ['MouseDown','MouseUp']:PACKETS.append(dict(label=label+'/'+typ,target=target,typ=typ,code='Unknown',rune=0,mods='',reject=False))
def refuse(label,target,stale=False):PACKETS.append(dict(label=label+'/MouseDown',target=target,typ='MouseDown',code='Unknown',rune=0,mods='',reject=True,stale=stale))
def text(label,value):
 click(label,hexfield)
 for i,r in enumerate('a'+value+'\n'):
  PACKETS.append(dict(label=label+'/text-'+str(i),target=hexfield,typ='KeyChord',code='A'if i==0 else'ReturnEnter'if r=='\n'else'Unknown',rune=0 if r=='\n'else ord(r),mods='Meta'if i==0 else'',reject=False))
key('toolbar-end',node('media-tool-0'),'End');key('toolbar-action',node('media-tool-7'),'ReturnEnter');key('toolbar-home',node('media-tool-7'),'Home');key('toolbar-skip-disabled',node('media-tool-0'),'RightArrow');key('toolbar-last',node('media-tool-2'),'End');key('form-traversal',node('media-tool-7'),'Tab');click('breadcrumb-accept',workspace);refuse('breadcrumb-stale-frame',workspace,True);click('breadcrumb-reset',node('media-reset-path'));click('breadcrumb-rejected',workspace);refuse('breadcrumb-disabled-refusal',workspace);click('breadcrumb-restored',workspace);click('images-page',ident('option','media-pages','images'));click('image-cover',ident('option','image-fit','cover'));key('image-stretch',node('image-fit'),'End');key('image-contain',node('image-fit'),'Home');click('image-replace',node('image-replace'));click('colors-page',ident('option','media-pages','colors'));key('color-tab',pages,'Tab');key('color-red-step',red,'RightArrow');key('color-red-max',red,'End');key('color-rejected',red,'Home');key('color-green-tab',red,'Tab');key('color-blue-tab',green,'Tab');key('color-alpha-tab',blue,'Tab');key('color-alpha-normalized',alpha,'Home');key('color-hex-tab',alpha,'Tab');text('color-hex-accepted','#abc');text('color-hex-invalid','invalid');text('color-straight-alpha','#F001AB00');refuse('color-disabled-refusal',red);click('chrome-return',ident('option','media-pages','chrome'));refuse('hidden-color-refusal',hexfield)
# Stale path packets use their original pre-activation key type in the consumer.
for p in PACKETS:
 if p['label']=='breadcrumb-stale-frame/MouseDown':p['label']='breadcrumb-stale-frame/KeyChord'
 if p['label']=='hidden-color-refusal/MouseDown':p['label']='hidden-color-refusal/KeyChord'
need(len(ROWS)==42 and len(PACKETS)==71,'frozen record counts')
def inside(a,b):return not v.empty(a)and all(b['Min'][k]<=a['Min'][k]<a['Max'][k]<=b['Max'][k]for k in ['X','Y'])
def publication(s,w,index):
 els=snapshot(s)
 def get(id,visible=True):
  e=els.get(id);need(e is not None and(not visible or not v.empty(e['Bounds'])),'current visible target '+id);return e
 for page in ['chrome','images','colors']:need((node(page)in els)==(page==w['Page']),'hidden page publication')
 get(pages)
 for option in ['chrome','images','colors']:
  e=get(ident('option','media-pages',option));need(e['Selected']==(option==w['Page'])and e['Enabled'],'selected page')
 focus=ROWS[index][2]
 if focus:need(get(node(focus))['Focused'],'actual observed focus '+focus)
 if w['Page']=='chrome':
  toolbar=get(node('media-tools'))
  if focus.startswith('media-tool-'):need(inside(get(node(focus))['Bounds'],toolbar['Bounds']),'focused tool within toolbar viewport')
  if index==0:need(not inside(get(node('media-tool-7'),False)['Bounds'],toolbar['Bounds']),'positive toolbar overflow')
  need(get(node('media-form'))['Name']=='<Project>','literal form caption')
  need(get(node('media-status'))['Value']==f"Tool {w['Last']} / actions {w['Tools']} / path {w['PathRequests']}",'status publication')
  e=get(workspace);need(e['Role']==('label'if w['Path']=='projects/workspace'else'button')and e['Enabled']==(not w['DisablePath']),'breadcrumb current/disabled publication')
 elif w['Page']=='images':
  need(get(node('image-preview'))['Role']=='image','image role')
  need(get(node('image-fit'))['Value']==w['Fit'].capitalize(),'controlled image fit')
 else:
  rgba=[int(w['Hex'][i:i+2],16)for i in [1,3,5,7]]
  for field,byte in zip([red,green,blue,alpha],rgba):
   e=get(field);need(type(e['Value'])in[int,float]and e['Value']==byte and e['Enabled']==(not w['DisableColor']),'color byte/disabled publication')
  need(get(node('ink/color/preview'))['Name']=='Ink color preview '+w['Hex'],'preview accepted color')
  need((node('ink/color/validation')in els)==(w['Invalid']>0 and w['Edits']==5),'validation publication')
 if index==41:need(hexfield not in els,'hidden enabled hex omitted')
 return els

def validate(stdout,stderr):
 need(len(stdout)<=4<<20 and len(stderr)<=4<<20,'bounded logs');records=[];warnings=0
 for raw,out in [(stdout,True),(stderr,False)]:
  for line in raw.decode('utf-8','strict').splitlines():
   if not line.strip():continue
   if out and line.startswith('{'):records.append(json.loads(line));continue
   need(bool(re.fullmatch(r'\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ERROR lines\.Lines font style MUST be Monospace\. Setting that but should fix upstream \| cogentcore\.org/core/text/lines\.\(\*Lines\)\.SetFontStyle .*/text/lines/api\.go:145',line)),'unexpected console line');warnings+=1;need(warnings<=64,'bounded font diagnostics')
 need(len(records)==1,'single native result');d=records[0]
 need(d['Event']=='vellum.media-native.result'and d['Result']=='PASS_NATIVE_MEDIA'and d['Error']==''and not d.get('ActiveStep')and d['Failed']is None and d['Unavailable']is False,'successful completed media result')
 need([x['Label']for x in d['Steps']]==[x[0]for x in ROWS]and[i['Label']for i in d['Inputs']]==[x['label']for x in PACKETS],'exact authored observations/inputs')
 extent=None;last=0
 for i,(step,w)in enumerate(zip(d['Steps'],VALUES)):
  need(step['Model']==w and all(type(step['Model'][k])is type(value)for k,value in w.items()),'literal expected model '+step['Label']);s=step['Snapshot'];publication(s,w,i);need(s['Frame']>last,'observation frame order');last=s['Frame']
  size=(s['Size'],s['LogicalDPI']);extent=extent or size;need(size==extent,'fixed scene configuration')
  frames=[x['Before']['Frame']for x in d['Inputs']if x['Label'].split('/')[0]==step['Label']];floor=d['Steps'][i-1]['Snapshot']['Frame']if i else 0;need(all(floor<f<s['Frame']for f in frames),'input/observation interleaving')
 last=0;originalPath=None
 for item,p in zip(d['Inputs'],PACKETS):
  s=item['Before'];els=snapshot(s);inp=item['Input'];need((s['Size'],s['LogicalDPI'])==extent and s['Frame']>last,'current input snapshot order');last=s['Frame']
  need(inp['Target']==p['target']and inp['Type']==p['typ']and inp['Code']==p['code']and inp['Rune']==p['rune']and inp['Modifiers']==p['mods']and inp['Delta']==dict(X=0,Y=0)and item['Rejected']is p['reject'],'exact packet '+p['label'])
  need(inp['Button']==('Left'if p['typ']=='MouseDown'or p['typ']=='MouseUp'else'NoButton')and v.point(inp['Position']),'typed point/button')
  if p.get('stale'):
   need(originalPath is not None and inp['Frame']==originalPath['Frame']<s['Frame']and inp['Position']==originalPath['Position'],'original stale frame preserved');continue
  need(inp['Frame']==s['Frame'],'current frame capability')
  if p['label'].startswith('hidden-color-refusal'):
   need(p['target']not in els,'hidden input target absent');continue
  e=els.get(p['target']);need(e is not None and e['Enabled']==(not p['reject']),'current target enabled state')
  if p['typ']=='KeyChord':need(e['Focused']and inp['Position']==dict(X=0,Y=0),'actual focused key target')
  else:need(not v.empty(e['Bounds'])and inp['Position']=={k:(e['Bounds']['Min'][k]+e['Bounds']['Max'][k])//2 for k in ['X','Y']},'actual measured pointer center')
  if p['label']=='breadcrumb-accept/MouseDown':originalPath=inp.copy()
 need(d['OriginalRefClosed']is True and d['PostCloseInputError']=='closed','original window closed refusal');s=d['Session'];need(s['Started']is True and s['Closed']is True and s['Pending']is False and s['LiveWindows']==0 and type(s['Issued'])is int and s['Issued']>=71,'terminal desktop session')
 return dict(result='PASS_NATIVE_MEDIA',observations=42,inputs=71,toolbar_actions=1,breadcrumb_requests=3,fit_requests=3,image_replacements=1,color_edits=6,invalid_colors=1,session=s,known_font_diagnostics=warnings,physical_input_verified=False,native_pixels_verified=False)
