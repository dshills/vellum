from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('media_run',Q/'run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sha=h.sha;read=h.read;C=h.C;T=h.T
p=read(Q/'plan.json');r=read(Q/'result.json');a=read(Q/'admission.json')
assert r['result']=='PASS_NATIVE_MEDIA'and r['post_boundary_pass']and h.passing(r['run'])and a['approved']and a['plan_sha256']==sha(Q/'plan.json')and(Q/'stop-live').is_file()
assert all(sha(k)==v for k,v in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
for stream,info in r['run']['logs'].items():
 f=Q/'case'/stream;assert f.stat().st_size==info['bytes']and sha(f)==info['sha256']
assert h.validator.validate((Q/'case/stdout').read_bytes(),(Q/'case/stderr').read_bytes())==r['summary']
assert not h.git(C,'status','--porcelain')and h.git(C,'rev-parse','HEAD').decode().strip()==h.HEAD and all(sha(C/n)==v for n,v in p['canonical_source'].items())
docs=['drivers/cogent/cmd/gallery/README.md',*[f'specs/{n}'for n in ['control-acceptance.md','macos-completion.md','macos-delivery.md']]]
assert {n for n,v in p['candidate_source'].items()if sha(T/n)!=v}==set(docs)
assert h.prepared(C)==h.prepared(T)==p['prepared']==p['canonical_prepared']and h.vector(h.SDK)==p['sdk_files']
source={n:v for n,v in p['candidate_source'].items()if n.endswith('.go')};assert all(sha(T/n)==v for n,v in source.items())
scope=read(Q/'review-scope.json');assert scope['staged_diff_sha256']==hashlib.sha256(h.git(T,'diff','--cached','--binary')).hexdigest()and all(sha(k)==v for k,v in scope['source_hashes'].items())
d={'result':'MEDIA_NATIVE_CHECKPOINT_BOUNDARY_PASS','head':h.HEAD,'all_Go_source':source,'Go_files':len(source),'native_and_checked_source_unchanged':True,'post_native_modified_plan_paths':docs,'native_case':r['summary'],'native_seconds':r['run']['seconds'],'owned':r['run']['owned'],'full_source_boundary_at_native_exit':True,'prepared_files':len(p['prepared']),'prepared_sha256':h.digest(p['prepared']),'sdk_files':len(p['sdk_files']),'sdk_sha256':h.digest(p['sdk_files']),'sdk_refreshed':False,'closed_full_mac_gates':[]}
(Q/'pre-review-boundary.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='all_Go_source'}))
