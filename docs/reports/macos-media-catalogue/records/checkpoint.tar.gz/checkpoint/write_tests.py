from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'drivers/cogent/cmd/gallery';Q=Path(__file__).resolve().parent
p=D/'media_views.go';s=p.read_text();a=s.index(' path, err := g.breadcrumb.View()');b=s.index('\n tools :=',a);s=s[:a]+s[b:];s=s.replace('  path,\n','');s=s.replace('  {ID:"media-reset-path",Kind:ui.Button,Text:"Reset location",Activate:func(){g.breadcrumb.Items=galleryBreadcrumbItems()}},\n','');s=s.replace(' focus:=g.focus',' path,err:=g.breadcrumb.View();if err!=nil{panic(err)}\n chrome:=g.chromeView()\n chrome.Children=append(chrome.Children[:2],append([]ui.Node{path,{ID:"media-reset-path",Kind:ui.Button,Text:"Reset location",Activate:func(){g.breadcrumb.Items=galleryBreadcrumbItems()}}},chrome.Children[2:]...)...)\n focus:=g.focus');s=s.replace('[]ui.Node{g.chromeView(),g.imagesView(),g.colorsView()}','[]ui.Node{chrome,g.imagesView(),g.colorsView()}');p.write_text(s)
(D/'media_catalogue.go').write_bytes((Q/'media_catalogue.go').read_bytes())
s=(D/'structure_catalogue_offscreen_test.go').read_text();a=s.index('\tcurrent := settle()');s=s[:a]
s=s.replace('"math"','"bytes"\n "image"').replace('"cogentcore.org/core/math32"\n','')
s=s.replace('TestStructureCataloguePublicManual','TestMediaCataloguePublicManual').replace('testStructureCataloguePublicManual','testMediaCataloguePublicManual').replace('g.structureCatalogueView','g.mediaCatalogueView').replace('Title: "Structure"','Title: "Media"')
s+='''
 current:=settle()
 find:=func(id string)cogent.ManualElement {t.Helper();for _,e:=range current.Elements {if e.ID==id{return e}};t.Fatal("actual target absent",id);return cogent.ManualElement{}}
 var stalePath,staleColor cogent.ManualInput
 var initialImage []byte
 send:=func(in cogent.ManualInput,refuse bool){t.Helper();e:=m.Input(ctx,in);if refuse {if !errors.Is(e,cogent.ErrManualStale){t.Fatal("target not refused",in,e)}}else if e!=nil{t.Fatal(e)};current=settle()}
 for _,step:=range g.mediaScript(){
  if step.Setup!=nil {if e:=a.Do(func(){step.Setup();_=a.Invalidate("gallery")});e!=nil{t.Fatal(e)};current=settle()}
  types:=[]events.Types{events.KeyChord};if step.Kind=="observe"{types=nil};if step.Kind=="click"||step.Kind=="text"{types=[]events.Types{events.MouseDown,events.MouseUp}};if step.Kind=="refuse"{types=[]events.Types{events.MouseDown}}
  for _,typ:=range types {
   in:=cogent.ManualInput{Window:"gallery",WindowIncarnation:current.Incarnation,Type:typ,Code:step.Code}
   reject:=step.Kind=="refuse"||step.Kind=="stale-path"||step.Kind=="stale-color"
   if step.Kind=="stale-path"{in=stalePath;in.Type=events.MouseDown}else if step.Kind=="stale-color"{in=staleColor;in.Type=events.MouseDown}else{
    id:=step.Target;if step.Option!=""{id=structureID("option",id,step.Option)}
    el:=find(id);in.Target=el.ID;in.TargetIncarnation=el.Incarnation
    if typ==events.KeyChord {if current.FocusedID!=step.Target{t.Fatalf("%s actual key focus %s want %s",step.Label,current.FocusedID,step.Target)}}else{in.Button=events.Left}
    if step.Target==ui.BreadcrumbItemID("project-path","workspace")&&typ==events.MouseDown&&!reject {stalePath=in}
    if step.Target==ui.ColorFieldID("ink",ui.ColorHex)&&typ==events.MouseDown {staleColor=in}
   }
   send(in,reject)
  }
  if step.Kind=="text" {
   for i,r:=range append(append([]rune{'a'},[]rune(step.Text)...),'\\n'){
    if current.FocusedID!=step.Target {t.Fatalf("%s text focus %s",step.Label,current.FocusedID)}
    in:=cogent.ManualInput{Window:"gallery",WindowIncarnation:current.Incarnation,Type:events.KeyChord,Rune:r}
    if i==0 {in.Code=key.CodeA;in.Modifiers=catalogueSelectAllModifiers()}else if r=='\\n'{in.Rune=0;in.Code=key.CodeReturnEnter}
    send(in,false)
   }
  }
  if g.mediaModel()!=step.Want{t.Fatalf("%s actual model %+v want %+v",step.Label,g.mediaModel(),step.Want)}
  if step.Focus!=""&&current.FocusedID!=step.Focus{t.Fatalf("%s focus %s want %s",step.Label,current.FocusedID,step.Focus)}
  if step.Focus!="" {e:=find(step.Focus);if e.Bounds.Empty()||!e.Bounds.In(image.Rectangle{Max:current.Size}){t.Fatal("focused control not visible",step.Label,e)}}
  if step.Label=="image-contain" {im,e:=m.Capture(ctx,"gallery");if e!=nil{t.Fatal(e)};initialImage=append([]byte(nil),im.Pix...)}
  if step.Label=="image-replace" {im,e:=m.Capture(ctx,"gallery");if e!=nil||bytes.Equal(initialImage,im.Pix){t.Fatal("replacement produced no completed software pixels",e)}}
 }
 if g.mediaTools!=1||g.breadcrumbRequests!=3||g.imageReplacements!=1||g.imageFitRequests!=3||g.colorEdits!=6||g.colorInvalid!=1||g.colorPicker.Color!=(color.NRGBA{R:240,G:1,B:171,A:0}){t.Fatal("independent final callback/value oracle",g.mediaModel())}
}
'''
(D/'media_catalogue_offscreen_test.go').write_text(s)
(D/'media_catalogue_test.go').write_text('''package main
import (
 "reflect"
 "testing"
 "github.com/dshills/vellum/ui"
)
func TestMediaCatalogueSharedViewsAndFrozenModel(t *testing.T){
 g:=newGallery();ordinary,media:=g.view(),g.mediaCatalogueView()
 for _,view:=range []ui.Node{ordinary,media}{if e:=ui.Validate(view);e!=nil{t.Fatal(e)}}
 for _,id:=range []string{"image-fit","image-preview","image-replace","ink","media-tools","media-form","media-status"}{
  a,b:=node(ordinary,id),node(media,id);if a.ID==""||a.Kind!=b.Kind||a.Text!=b.Text||a.Image!=b.Image||a.Disabled!=b.Disabled||!reflect.DeepEqual(a.Options,b.Options){t.Fatal("ordinary constructor differs",id)}
 }
 before:=g.mediaModel();steps:=g.mediaScript();if before!=g.mediaModel()||len(steps)!=41{t.Fatal("script mutates state or changed size",len(steps))}
 seen:=map[string]bool{};for _,s:=range steps{if s.Label==""||seen[s.Label]{t.Fatal("ambiguous label",s.Label)};seen[s.Label]=true}
 if !seen["hidden-color-refusal"]||!seen["image-replace"]||!seen["breadcrumb-stale"]{t.Fatal("lifecycle cases missing")}
}
''')
print('Media catalogue and public Manual routing preflight written')
