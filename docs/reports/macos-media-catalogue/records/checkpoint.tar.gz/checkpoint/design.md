# Remaining media/chrome catalogue

Baseline db98a6b. Close a named M2 evidence gap with an independently runnable
900x700 gallery mode using ordinary public controls. Extract image/color page
constructors unchanged for normal gallery reuse; add a reusable gallery chrome
page with overflowing toolbar, literal form caption, status and Breadcrumb.

Route native pointer/key inputs only through public DesktopSession. Explicit
expected models/callback counts, actual focus before every key, fresh completed
capabilities, retained/stale and disabled target refusal, and original-window
closure are required. The same view receives independent public Manual routing
preflight at two DPIs. Manual capture is software raster evidence; native
semantics/layout/routing never claim pixels/physical input/presentation/IME.

No retry of sealed structural or placement scopes. No automatic availability
retry: ErrDesktopFrameUnavailable terminates the new catalogue case, preserving
its typed error and partial record. Exactly one reviewed/admitted native attempt
may run after source/controller/pins review under the shared lease and owned
bounded child. No native execution is authorized by this document alone.

No SDK refresh, system setting/input source/clipboard changes, public release,
new backend scheduling policy or performance claim. M2 stays open until all
remaining catalogue and composed requirements are actually satisfied.
