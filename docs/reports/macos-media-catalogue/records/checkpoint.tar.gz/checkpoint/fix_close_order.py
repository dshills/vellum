from pathlib import Path
import shutil
Q=Path(__file__).resolve().parent;D=Path('/private/tmp/vellum-macos-native-results-97aee13/drivers/cogent/cmd/gallery');V=Q/'versions/first-shutdown-fix';V.mkdir(parents=True)
for n in ['media_catalogue.go','media_lifecycle_test.go']:shutil.copy2(D/n,V/n)
p=D/'media_catalogue.go';s=p.read_text();a=s.index('\tif err = catalogueOwner(ctx, a, ref, func() error { return a.CloseWindow(ref) });');b=s.index('\n\treport.PostCloseInputError',a)
s=s[:a]+'''\treport.OriginalRefClosed,err=mediaFinishWindow(ctx,a,s,ref,cogent.DesktopInput{Frame:last.Frame,Target:target.ID,Type:events.KeyChord,Code:key.CodeEnd})
 if err!=nil{return}
'''.rstrip()+s[b:]
s+='''
// Final teardown is already authorized after all observations. Keep its close
// acknowledgement and closed-reference check bounded but independent of the
// scenario cancellation triggered when closing the last window ends Run.
func mediaFinishWindow(ctx context.Context,a *app.Application,s *cogent.DesktopSession,ref app.WindowRef,in cogent.DesktopInput)(bool,error){
 if err:=ctx.Err();err!=nil{return false,err}
 finalCtx,cancel:=context.WithTimeout(context.WithoutCancel(ctx),time.Second)
 defer cancel()
 if err:=catalogueOwner(finalCtx,a,ref,func()error{return a.CloseWindow(ref)});err!=nil{return ref.Context().Err()!=nil,err}
 closed:=ref.Context().Err()!=nil
 err:=s.Input(finalCtx,ref,in)
 if !closed||!errors.Is(err,cogent.ErrDesktopClosed){return closed,fmt.Errorf("closed original admitted media input: %v",err)}
 return closed,nil
}
''';p.write_text(s)
p=D/'media_lifecycle_test.go';s=p.read_text().replace('"sync/atomic"','"sync/atomic"\n "sync"\n "github.com/dshills/vellum/drivers/cogent"\n "cogentcore.org/core/events"\n "cogentcore.org/core/events/key"')
s+='''
type mediaClosingDriver struct {admitted <-chan struct{};drained chan<- error}
func(d mediaClosingDriver)Run(ctx context.Context,a *app.Application)error{
 select{case <-d.admitted:case <-time.After(3*time.Second):return errors.New("close was not admitted")}
 go func(){d.drained<-a.Drain()}()
 <-ctx.Done()
 return ctx.Err()
}
func TestMediaCatalogueLastWindowAcknowledgesAfterRunCancellation(t *testing.T){
 a,err:=app.New(app.Config{});if err!=nil{t.Fatal(err)};defer a.Close()
 admitted:=make(chan struct{},1);ack:=make(chan struct{});var releaseOnce sync.Once
 release:=func(){releaseOnce.Do(func(){close(ack)})};defer release()
 a.SetWake(func(){if a.Context().Err()!=nil{<-ack;return};select{case admitted<-struct{}{}:default:}})
 if err=a.Open(app.Window{ID:"gallery",Title:"Last window retirement",Width:100,Height:100,View:func()ui.Node{return ui.Node{ID:"root",Kind:ui.Label}}});err!=nil{t.Fatal(err)}
 <-admitted
 ref,err:=a.WindowRef("gallery");if err!=nil{t.Fatal(err)}
 ctx,cancel:=context.WithCancel(context.Background());defer cancel()
 done:=make(chan mediaOutcome,1);workerDone:=make(chan struct{})
 go func(){closed,e:=mediaFinishWindow(ctx,a,cogent.NewDesktopSession(),ref,cogent.DesktopInput{Frame:1,Target:"retired",Type:events.KeyChord,Code:key.CodeEnd});if e==nil&&!closed{e=errors.New("close did not retire ref")};done<-mediaOutcome{err:e};close(workerDone)}()
 drained:=make(chan error,1)
 if e:=a.Run(context.Background(),mediaClosingDriver{admitted,drained});!errors.Is(e,context.Canceled){t.Fatal("last window did not end actual Run",e)}
 if ref.Context().Err()==nil{t.Fatal("last-window lifetime remained live")}
 joined:=make(chan mediaOutcome,1)
 go func(){r,ok:=mediaWorkerResult(cancel,done);if !ok{r.err=errors.Join(r.err,errors.New("terminal worker did not join"))};joined<-r}()
 <-ctx.Done() // Run-return cancellation precedes the owner's close reply.
 select{case <-workerDone:release();t.Fatal("terminal probe canceled before its close acknowledgement");case <-time.After(50*time.Millisecond):}
 release()
 select{case r:=<-joined:if r.err!=nil{t.Fatal("closed-reference probe lost terminal authority",r.err)};case <-time.After(2*time.Second):t.Fatal("bounded final probe did not join")}
 select{case e:=<-drained:if e!=nil&&!errors.Is(e,app.ErrClosed){t.Fatal("owner drain",e)};case <-time.After(time.Second):t.Fatal("owner did not finish after acknowledgement release")}
}
''';p.write_text(s)
print('Bounded final-close context and forced retirement-order regression written.')
