from pathlib import Path
import json
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-media-catalogue';K=Q/'corrected-native'
first=json.loads((Q/'result.json').read_bytes());current=json.loads((K/'result.json').read_bytes());assert current['result']=='PASS_NATIVE_MEDIA'and current['post_boundary_pass']and first['result']=='PASS_NATIVE_MEDIA'
r=current['run'];p=json.loads((Q/'prism.json').read_bytes());assert p['coverage']['llmCalls']==1
summary=current['summary'];assert summary['inputs']==71 and summary['observations']==42
report=f'''# Media, chrome and composite catalogue

The corrected `gallery -media-native-check` consumer completes **71 native Go
FIFO inputs and 42 independently expected observations**. It uses Darwin/ARM64,
Go 1.25.6, GOMAXPROCS2 and the retained SDK's source-built native archive786a.
The normal gallery reuses its image/color pages and adds a Chrome page for
an overflowing toolbar, literal form caption and status. The acceptance view
composes the existing public Breadcrumb beside those controls.

Native routing passes toolbar End/Home, disabled skipping, clipped-focus reveal,
one activation and form traversal; accepted/rejected/disabled Breadcrumb
navigation, current-location role change and stale-frame refusal; image fit
selection and replacement callback; ColorPicker byte/hex edits, rejection,
normalization, invalid input, straight alpha, disabled and separately enabled-
but-hidden refusal. Exact callback totals are 1 toolbar action, 3 Breadcrumb
requests, 3 fit proposals, 1 replacement, 6 color proposals (including the
rejected one) and 1 invalid input. Values flow through ordinary public callbacks;
owner changes configure policy only. Keys require actual focus and pointer
positions use fresh measured targets. Native image pixels are not claimed.

The original window closes and refuses further input. The final session is
Closed=true, Pending=false, LiveWindows=0, Issued={summary['session']['Issued']}.
The corrected case finishes in {r['seconds']:.3f} seconds; owned group
{r['owned']['group']} is absent. The earlier pre-fix case also passes its own
71/42 record in6.759 seconds with group17984 absent. Both distinct scopes are
permanently sealed. The corrected case qualifies the final lifecycle fixes;
the earlier record and binary remain unchanged. No retry occurs within a case.

An independent Python oracle checks every authored model and packet, focus,
roles, measured geometry, clipping, stale capabilities, interleaving and
retirement. A fabricated positive and 13 targeted negative controls validate
that oracle; they do not constitute native evidence. Whole source, prepared
output, SDK and binary match before/after each native case while the shared
lease remains held. Native logs and owned cleanup receipts are retained.

Separate public Manual routing passes at160/162 DPI. It uses keyboard navigation
for page/segment options and its verified active Select All binding; native uses
pointer option targets and verifies Meta+A. Manual separately proves retired
control-incarnation refusal. Known opaque strip pixels change from
(240,64,48,255) to (240,192,0,255) at stable measured geometry while the old
immutable source remains unchanged. A focus-ring change cannot pass that oracle.
Native semantics/layout/routing remain separate from software raster evidence.

One complete uncached Prism Anthropic Claude Sonnet5.5 call reviews the original
10-file/56,362-byte implementation and documentation scope. Raw CLI1 and both
retained medium findings remain intact. Independent review refutes the empty-
script concern: the frozen42-step contract and early returns guarantee a
completed observation before the final index. The worker-retirement finding
is real: application retirement can drop an admitted owner callback whose
private reply wait otherwise survives until the scenario timeout.

The final runner cancels the scenario immediately after Run returns, before
its existing6-second join. Final close acknowledgement and closed-reference
validation receive an independent1-second context after a live-scenario check,
so Run-return cancellation cannot invalidate those terminal operations. Actual
Application regressions force both orderings. Removing join cancellation fails
after6 seconds; removing the protected close context fails before acknowledgement.
Both corrected tests, both-DPI preflight, full gallery race, default gallery vet
and native build pass. Internal review approves these narrow post-provider
fixes and the additional lifecycle test; no second provider call is made.
The final corrected-source native case passes separately after that review.

Earlier internal review also corrected checker role naming, ambiguous stale
identity evidence, toolbar window-only bounds and whole-window image comparison.
All early preflight failures, source versions, counterfactuals and the original
unapproved finding disposition are preserved. Backend scheduling/acquisition,
stage86 prepared bytes and the retained7,880-file SDK remain unchanged.

This advances named M2 catalogue coverage. Structural, text/modal and remaining
workflows, full M2/M5 and M3–M7 stay open. Automated native Go routing does not
qualify OS/physical input, IME, human VoiceOver, native pixels, display
presentation, performance, memory/endurance or distribution rights. Neither
passing case exercises the typed drawable-unavailable path; it would terminate
without automatic retry. Prior failed structural and placement scopes stay sealed.
No SDK refresh, settings/input-source/clipboard changes or public release occurs.

See [results](records/results.json), [bounded evidence archive](records/checkpoint.tar.gz)
and [manifest](records/manifest.json). The SDK's separately pinned native-library
override does not qualify the checkout's default cached library. Follow the
[Mac delivery plan](../../../specs/macos-delivery.md).
'''
for a,b in {'in6.759':'in 6.759','group17984':'group 17984','at160/162':'at 160/162','Sonnet5.5':'Sonnet 5.5','CLI1':'CLI 1','frozen42-step':'frozen 42-step','existing6-second':'existing 6-second','independent1-second':'independent 1-second','after6 seconds':'after 6 seconds','retained7,880-file':'retained 7,880-file'}.items():report=report.replace(a,b)
(R/'README.md').write_text(report)
note='''
Prism then identifies a real undispatched-owner wait on application retirement.
The final media runner cancels after Run and gives final close acknowledgement/
closed-reference validation a separate 1-second context within its 6-second join.
Two actual Application regressions discriminate the missing-cancel and canceled-
close counterfactuals. Final gallery race/vet/build and the distinct corrected
71-input/42-observation native case pass; both native scopes remain sealed.
One original Anthropic Sonnet 5.5 call and independent fix reviews are retained.
'''
for n in ['control-acceptance.md','macos-completion.md','macos-delivery.md']:
 f=T/'specs'/n;s=f.read_text();assert 'Prism then identifies a real undispatched-owner wait'not in s;f.write_text(s+note)
f=T/'drivers/cogent/cmd/gallery/README.md';s=f.read_text();s+='''
After native Run returns, the media checker cancels pending scenario waits before
joining. Its final close acknowledgement and closed-reference probe use a separate
1-second bound, so closing the last window cannot cancel their validation. The
final corrected native record passes; the earlier passing scope stays preserved.
''';f.write_text(s)
checks=json.loads((R/'records/results.json').read_bytes())['checks']
for n in ['lifecycle-negative','lifecycle-focused','lifecycle-focused-v2','close-negative','gallery-fixed-final','vet-fixed-final','build-fixed-final']:checks[n]=json.loads((Q/(n+'.json')).read_bytes())
results={'base_commit':'db98a6b31013d231c4ce3ba0fd0c320db5cf2961','native_result':current,'prior_native_result':first,'checks':checks,'final_software_checks':['lifecycle-focused-v2','gallery-fixed-final','vet-fixed-final','build-fixed-final','validation-final'],'native_scopes_both_sealed':True,'provider':{'calls':1,'files':10,'bytes':56362,'cli_exit_code':1,'retained_findings':2,'confirmed_and_fixed':1,'refuted':1,'post_provider_fix_internally_reviewed':True},'software_pixels_only':True,'physical_input_verified':False,'native_pixels_verified':False,'typed_unavailable_path_exercised':False,'sdk_refreshed':False,'closed_full_mac_gates':[]}
(R/'records/results.json').write_text(json.dumps(results,indent=2)+'\n')
updates=['drivers/cogent/cmd/gallery/media_catalogue.go','docs/reports/macos-media-catalogue/README.md','drivers/cogent/cmd/gallery/README.md',*[f'specs/{n}'for n in ['control-acceptance.md','macos-completion.md','macos-delivery.md']]]
docs=[n for n in updates if not n.endswith('.go')]+['docs/reports/macos-media-catalogue/records/results.json']
(Q/'post-provider-updates.json').write_text(json.dumps({'paths':updates,'new_test':'drivers/cogent/cmd/gallery/media_lifecycle_test.go','reason':'Prism-confirmed worker cancellation fix and independent bounded final teardown, actualApplication regressions, corrected-native qualification and factual documentation','post_corrected_native_docs':docs},indent=2)+'\n')
print(json.dumps({'final_native':current['result'],'inputs':71,'observations':42,'post_provider_changed':len(updates),'new_test':1,'checks_retained':len(checks)}))
