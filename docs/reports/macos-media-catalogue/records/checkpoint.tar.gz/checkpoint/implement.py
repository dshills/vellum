from pathlib import Path
T=Path('/private/tmp/vellum-macos-native-results-97aee13'); D=T/'drivers/cogent/cmd/gallery'
p=D/'main.go';s=p.read_text();assert 'media-native-check'not in s
s=s.replace('type gallery struct {','type gallery struct {\n mediaPage string\n mediaTools, mediaLast, imageReplacements, imageFitRequests int')
a=s.index('\timages := ui.Node{'); b=s.index('\n\treturn ui.Node{ID: "gallery"',a)
old=s[a:b]; images,colors=old.split('\n\tcolorsPage := ',1)
images=images.replace('\timages := ', '\treturn ',1).replace('g.imageFit = ui.ImageFit(e.SelectedID)','g.imageFitRequests++; g.imageFit = ui.ImageFit(e.SelectedID)').replace('g.picture = source','g.picture = source; g.imageReplacements++')
colors='\treturn '+colors
(D/'media_views.go').write_text('''package main

import (
 "fmt"
 "image"
 "image/color"
 "github.com/dshills/vellum/ui"
)

func (g *gallery) imagesView() ui.Node {
'''+images+'''\n}
func (g *gallery) colorsView() ui.Node {
'''+colors+'''\n}
func (g *gallery) chromeView() ui.Node {
 path, err := g.breadcrumb.View(); if err != nil { panic(err) }
 tools := make([]ui.Node, 8)
 for i := range tools {
  i := i
  tools[i] = ui.Node{ID: fmt.Sprintf("media-tool-%d",i), Kind: ui.Button, Text: fmt.Sprintf("Tool %d",i), MinWidth:100, Disabled:i==1, Activate:func(){g.mediaTools++;g.mediaLast=i}}
 }
 return ui.Node{ID:"chrome",Kind:ui.Column,Grow:true,Children:[]ui.Node{
  {ID:"media-tools",Kind:ui.Toolbar,Accessibility:ui.Accessibility{Name:"Document tools"},Style:ui.Style{MaxSize:ui.Some(ui.Size{Width:260})},Children:tools},
  {ID:"media-form",Kind:ui.FormGroup,Text:"<Project>",Children:[]ui.Node{{ID:"media-name",Kind:ui.TextField,Text:g.text,Change:func(e ui.ChangeEvent){g.text=e.Text}}}},
  path,
  {ID:"media-reset-path",Kind:ui.Button,Text:"Reset location",Activate:func(){g.breadcrumb.Items=galleryBreadcrumbItems()}},
  {ID:"media-status",Kind:ui.StatusBar,Text:fmt.Sprintf("Tool %d / actions %d / path %d",g.mediaLast,g.mediaTools,g.breadcrumbRequests)},
 }}
}
func (g *gallery) mediaCatalogueView() ui.Node {
 focus:=g.focus
 if focus.Sequence==0 {focus=ui.FocusRequest{ID:"media-tool-0",Sequence:1}}
 return ui.Node{ID:"media-catalogue",Kind:ui.Column,Grow:true,Focus:focus,Style:ui.Style{Padding:ui.Some(ui.UniformInsets(16))},Children:[]ui.Node{
  {ID:"media-pages",Kind:ui.Tabs,Grow:true,SelectedID:g.mediaPage,Options:[]ui.Option{{ID:"chrome",Label:"Chrome"},{ID:"images",Label:"Images"},{ID:"colors",Label:"Colors"}},Change:func(e ui.ChangeEvent){g.mediaPage=e.SelectedID},Children:[]ui.Node{g.chromeView(),g.imagesView(),g.colorsView()}},
 }}
}
''')
s=s[:a]+'\timages := g.imagesView()\n\tcolorsPage := g.colorsView()\n'+s[b:]
# The ordinary gallery exposes exactly the same chrome page as the acceptance mode.
s=s.replace('{ID: "about", Label: "About"}', '{ID: "chrome", Label: "Chrome"}, {ID: "about", Label: "About"}')
s=s.replace('g.listBoxView(), {ID: "about"','g.listBoxView(), g.chromeView(), {ID: "about"')
s=s.replace('g.structurePage = "sections"','g.structurePage = "sections"\n g.mediaPage = "chrome"')
s=s.replace('\tflag.Parse()', '\tmedia := flag.Bool("media-native-check", false, "run bounded image/chrome/composite native FIFO acceptance")\n\tflag.Parse()\n if *media && (*structure || *navigation || *choices || *catalogue || *smoke || *disclosureSmoke || *menuSmoke || *colorSmoke || *progressSmoke || *exit>0) {must(errors.New("media-native-check requires its own bounded process"))}')
s=s.replace('if *disclosureSmoke || *menuSmoke || *colorSmoke || *progressSmoke || *catalogue || *choices || *navigation || *structure {','if *media || *disclosureSmoke || *menuSmoke || *colorSmoke || *progressSmoke || *catalogue || *choices || *navigation || *structure {')
s=s.replace('\tif *progressSmoke {\n\t\tview = g.progressView','\tif *media {view = g.mediaCatalogueView}\n\tif *progressSmoke {\n\t\tview = g.progressView')
s=s.replace('if *choices || *navigation || *structure {','if *media || *choices || *navigation || *structure {')
s=s.replace('\tif *structure {\n\t\tmust(runStructureCatalogue', '\tif *media {must(runMediaCatalogue(ctx,a,g,theme));return}\n\tif *structure {\n\t\tmust(runStructureCatalogue')
p.write_text(s)
print('Shared media/chrome views and exclusive mode wiring written')
