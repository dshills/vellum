from pathlib import Path
import shutil,sys
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
v=Q/'versions/pre-provider-docs';v.mkdir(parents=True)
for n in ['review-scope.json','staged.diff']:shutil.copy2(Q/n,v/n)
def head(n):return run_child(['git','show','HEAD:'+n],cwd=T,timeout=30,check=True,capture_output=True).stdout.decode()
for n in ['specs/control-acceptance.md','specs/macos-completion.md','specs/macos-delivery.md']:
 p=T/n;current=p.read_text();start=current.index('\nThe [media/chrome catalogue checkpoint]');note=current[start:].replace('Go 2/SDK786a','Go 1.25.6/GOMAXPROCS2/SDK786a');prior=head(n)
 if n=='specs/control-acceptance.md':
  prefixes=['| `Image` |','| `Toolbar` |','| `StatusBar` |','| `FormGroup` |','| Breadcrumb composite |','| ColorPicker composite |']
  replacements={prefix:next(line for line in current.splitlines()if line.startswith(prefix))for prefix in prefixes}
  prior='\n'.join(next((line2 for prefix,line2 in replacements.items()if line.startswith(prefix)),line)for line in prior.splitlines())+'\n'
 p.write_text(prior+note)
p=T/'drivers/cogent/cmd/gallery/README.md';current=p.read_text();section=current[current.index('\n## Native media and chrome catalogue'):].replace('Go 2/SDK786a','Go 1.25.6/GOMAXPROCS2/SDK786a');p.write_text(head('drivers/cogent/cmd/gallery/README.md')+section)
p=T/'docs/reports/macos-media-catalogue/README.md';s=p.read_text().replace('Go 2/SDK786a','Go 1.25.6/GOMAXPROCS2/SDK786a');p.write_text(s)
print('Clarified compiler versus GOMAXPROCS; preserved historical documentation bytes outside the new checkpoint.')
