# Media, chrome and composite catalogue

The dedicated `gallery -media-native-check` consumer completes all **71 native
Go FIFO inputs and 42 independently expected observations** on the controlled
Darwin/ARM64 Go 1.25.6/GOMAXPROCS2 SDK786a configuration. The shared ordinary
constructors remain available in the normal gallery: images/colors pages and a
new Chrome page for overflowing toolbar, literal form caption and status.
The acceptance view composes the existing Breadcrumb beside those controls.

Actual native routing passes toolbar End/Home, disabled skipping, clipped-focus
reveal, one activation and form traversal; accepted/rejected/disabled Breadcrumb
navigation, current-location role change and old-frame refusal; image fit
selection and replacement callback; ColorPicker byte/hex, rejection,
normalization, invalid input, straight alpha, disabled and separately enabled-
but-hidden refusal. Exact callback totals are 1 toolbar action, 3 breadcrumb
requests, 3 fit proposals, 1 replacement, 6 color proposals (including the rejected one) and 1
invalid input. Values flow through public callbacks. Owner changes configure
rejection/disabled policy only. Every key requires actual focus; pointer targets
use fresh measured bounds and capabilities. The original window is closed and
rejects further input. Session closes with Pending=false, LiveWindows=0; owned
process group 17984 is absent after 6.759 seconds. No font diagnostics occur.

An independent Python oracle checks the complete authored model/packet record,
focus, roles, geometry, clipping, stale frames, interleaving and retirement. Its
fabricated positive and 13 negative controls pass; these are validator tests, not
native evidence. The native raw stdout is 757,739 bytes and stderr empty. Whole
source/prepared/SDK and binary boundaries match before/after the case while the
shared lease remains held. The terminal scope is permanently sealed; no retry.

The separate public Manual preflight passes at 160/162 DPI. It tests the same
accepted states and exact callbacks using the available public routing surface;
Manual uses keyboard navigation for page/segment options and its verified active
Select All binding. Native uses pointer option targets and verifies Meta+A.
Manual separately proves retired control-incarnation refusal. Known opaque strip
pixels change from (240,64,48,255) to (240,192,0,255)at stable measured image geometry,
while the old immutable source remains unchanged. Focus-ring changes cannot
satisfy that oracle. Native checks do not claim image pixels or presentation.

Initial internal review corrected four checker defects before native admission:
Cocoa-versus-public image role naming, ambiguous stale-target evidence, window-
only toolbar visibility, and whole-window image comparisons. Early offscreen
iterations also expose a compile assumption, distinct stale/disabled identities,
missing Manual option nodes, different active key bindings and retained hidden
geometry. Those failed receipts and source versions remain recorded. Full final
gallery race, default gallery vet, native build and owned validator controls pass.
No backend scheduling/acquisition policy or prepared stage86 bytes change.

This advances named M2 catalogue coverage. Structural, text/modal, remaining
workflow and full M2/M5 acceptance stay open. Automated native Go routing is
separate from OS/physical input, IME, human VoiceOver, native pixels, display
presentation, performance, memory/endurance and rights/distribution. M3–M7 remain
open. The typed unavailable error path is not exercised by this successful case;
a future unavailable result would terminate without automatic retry. The previous
failed structural and placement scopes remain sealed.

See [results](records/results.json), [bounded evidence archive](records/checkpoint.tar.gz)
and [manifest](records/manifest.json). The unchanged 7,880-file SDK uses its pinned
source-built native archive; this does not qualify the checkout's default cached
library. No SDK refresh, OS settings/input-source/clipboard changes or public
release occurs. Internal reviews and one scoped Prism Anthropic Claude Sonnet 5.5
review are required before the local checkpoint commit.
