package main

import (
	"github.com/dshills/vellum/ui"
	"reflect"
	"testing"
)

func TestMediaCatalogueSharedViewsAndFrozenModel(t *testing.T) {
	g := newGallery()
	ordinary, media := g.view(), g.mediaCatalogueView()
	for _, view := range []ui.Node{ordinary, media} {
		if e := ui.Validate(view); e != nil {
			t.Fatal(e)
		}
	}
	for _, id := range []string{"image-fit", "image-preview", "image-replace", "ink", "media-tools", "media-form", "media-status"} {
		a, b := node(ordinary, id), node(media, id)
		if a.ID == "" || a.Kind != b.Kind || a.Text != b.Text || a.Image != b.Image || a.Disabled != b.Disabled || !reflect.DeepEqual(a.Options, b.Options) {
			t.Fatal("ordinary constructor differs", id)
		}
	}
	before := g.mediaModel()
	steps := g.mediaScript()
	if before != g.mediaModel() || len(steps) != 41 {
		t.Fatal("script mutates state or changed size", len(steps))
	}
	seen := map[string]bool{}
	for _, s := range steps {
		if s.Label == "" || seen[s.Label] {
			t.Fatal("ambiguous label", s.Label)
		}
		seen[s.Label] = true
	}
	if !seen["hidden-color-refusal"] || !seen["image-replace"] || !seen["breadcrumb-stale"] {
		t.Fatal("lifecycle cases missing")
	}
}
