package main

import (
	"context"
	"errors"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"sync/atomic"
	"testing"
	"time"
)

type mediaFailDriver struct {
	admitted <-chan struct{}
	failure  error
}

func (d mediaFailDriver) Run(ctx context.Context, a *app.Application) error {
	select {
	case <-d.admitted:
	case <-ctx.Done():
		return ctx.Err()
	case <-time.After(3 * time.Second):
		return errors.New("owner callback was not admitted")
	}
	if a.Pending().Ordinary != 1 {
		return errors.New("owner callback not queued")
	}
	return d.failure
}
func TestMediaCatalogueRetiredOwnerWorkerJoins(t *testing.T) {
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	admitted := make(chan struct{}, 1)
	a.SetWake(func() {
		select {
		case admitted <- struct{}{}:
		default:
		}
	})
	if err = a.Open(app.Window{ID: "gallery", Title: "Media retirement regression", Width: 100, Height: 100, View: func() ui.Node { return ui.Node{ID: "root", Kind: ui.Label, Text: "not launched"} }}); err != nil {
		t.Fatal(err)
	}
	<-admitted // Discard the registration wake, before the worker posts its callback.
	ref, err := a.WindowRef("gallery")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan mediaOutcome, 1)
	var called atomic.Bool
	go func() {
		e := catalogueOwner(ctx, a, ref, func() error { called.Store(true); return nil })
		done <- mediaOutcome{err: e}
	}()
	failure := errors.New("injected driver exit before owner dispatch")
	if err = a.Run(context.Background(), mediaFailDriver{admitted, failure}); !errors.Is(err, failure) {
		t.Fatal("actual Run failure lost", err)
	}
	if ref.Context().Err() == nil || a.Pending().Ordinary != 0 || called.Load() {
		t.Fatal("actual application did not retire and drop undispatched callback")
	}
	select {
	case <-done:
		t.Fatal("worker unexpectedly finished before scenario cancellation")
	default:
	}
	result, joined := mediaWorkerResult(cancel, done)
	if !joined {
		cancel()
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Error("regression cleanup worker did not join")
		}
		t.Fatal("retired owner wait outlived Run")
	}
	if !errors.Is(result.err, context.Canceled) || ctx.Err() != context.Canceled || called.Load() {
		t.Fatal("worker failed cancellation identity or dispatched retired callback", result.err)
	}
}
