# ListBox Prism adjudication

RESOLVED_NO_SOURCE_CHANGE — both medium findings are unsupported by the current implementation; no unresolved findings. All 28 sources match the provider input and recorded probe endpoints.

- `ecb36e63f0e50879`: host set is an intentional stable-ID route. Captured catalog/scope and generation guards precede current owner-side enabled-ID validation. The probe shows only `b` invokes the application; invalid scalars can consume bounded queue admission but produce no callback. The array is refused before queueing. Disabling the host setter would remove the designed route.
- `d963ae5691067d07`: `prepareChoice` initializes row epochs and `finishChoice` prunes them alongside removed buttons. The 512-catalog probe retains exactly two current entries and produces no removed-row callbacks.

Raw Prism remains exit 1 with two findings, complete 28-file coverage, one invocation and seven LLM calls. The discarded numeric-domain observation is also preserved; the current producer supplies validated string IDs. No source changes or reviewer execution occurred. These inert probes and this adjudication do not qualify native ListBox interaction, physical input, VoiceOver or broader Mac acceptance.
