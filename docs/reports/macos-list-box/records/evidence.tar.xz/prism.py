from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-listbox');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());sources=review['sources']
assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings'] and len(sources)==28
assert all(sha(R/n)==h for n,h in sources.items())
subprocess.run(['git','add','--',*sources],cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
out=P/'prism-v1';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Reusable bounded public ui.ListBox (0..256 stable unique IDs, empty or present selectedID, disabled/read-only), dedicated scrolling list over retained choice widgets; clamped arrows/HomeEnd/measured pages/Unicode initial-letter cycling; native absolute proposals preserve FIFO B then A even stale descriptor A, explicit same-selection activation allowed; programmatic setters no callback. Independently copied catalog ID/disabled epochs and exact row/scope tokens revoke remove/disable/hide/modal ABA without invalidating selection-only changes. Preserve inner native dialog closure lease in final workbench scope projection; do not weaken AX semantic generation revalidation. Real Mac AXList/AXRow roles, all/visible/selected rows/children clipped by pixel frames, setter accepts one enabled current child and goes through bounded Go owner delivery. List-only semantic focus explicitly reveals even already-focused wheel-hidden row. Catalog order change forces host layout despite aliased persistent options slice. Gallery Lists page plus independent SDK API contract; real offscreen keys held batches1/7/64 accepted/rejected, DPI96/120/160/240 navigation/reveal/scroll/pointer/raster, largefont/narrow/style reset, real Workbench/modal scopes, queue/window lifecycle, inert Cocoa setter generation/eligibility and sequential valid-refusal probes. Internal source review approved; full offscreen race/vet, native compile (application not launched), private SDK/source integrity; no physical/human/GPU/endurance/performance or full Mac completion claim. Review current28 source/spec/doc/test leaves; evidence archive records will be sealed after provider review.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'source-review.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
