//go:build offscreen && darwin && cgo
package cogent
import("encoding/json";"fmt";"testing";"cogentcore.org/core/core";"github.com/dshills/vellum/ui")
func TestListBoxPrismHostValueValidation(t *testing.T){
 a,b:=newAXTest(t,16);var calls []string;n:=listBoxDescriptor(func(e ui.ChangeEvent){calls=append(calls,e.SelectedID)});host:=core.NewFrame(core.NewBody("Host set"));r,err:=reconcile(host,nil,n,a,"ax");if err!=nil{t.Fatal(err)}
 nodes,handlers:=accessibilitySnapshot(r,b);b.mu.Lock();b.handlers=handlers;b.activationGuards=accessibilityActivationGuards(nodes);b.mu.Unlock();b.generation.Store(1)
 payload,_:=json.Marshal(nodes[0])
 for _,value:=range []string{`"b"`,`"Same"`,`"missing"`,`"c"`,`42`,`true`,`["b"]`,`""`}{
  before:=len(calls);admitted:=nativeAccessibilitySetValueFixture(b.token,1,string(payload),value);if err:=a.Drain();err!=nil{t.Fatal(err)}
  want:=0;if value==`"b"`{want=1;if !admitted{t.Fatal("documented host set ID refused")}}
  if len(calls)-before!=want{t.Fatal("unvalidated host value reached application",value,calls)}
  t.Logf("value=%s native-admitted=%v owner-callbacks=%d",value,admitted,len(calls)-before)
 }
 if len(calls)!=1||calls[0]!="b"{t.Fatal("host did not preserve stable ID",calls)}
}
func TestListBoxPrismCatalogStateRemainsBounded(t *testing.T){
 a,_:=newAXTest(t,16);host:=core.NewFrame(core.NewBody("Bounded list"));calls:=0;n:=listBoxDescriptor(func(ui.ChangeEvent){calls++});n.Options=n.Options[:2];r,err:=reconcile(host,nil,n,a,"ax");if err!=nil{t.Fatal(err)}
 for i:=range 512{old:=n.Options[1].ID;queueListBox(r,old,r.control.choice.buttons[old]);n.Options=[]ui.Option{{ID:"a",Label:"A"},{ID:fmt.Sprintf("item-%d",i),Label:"New item"}};r,err=reconcile(host,r,n,a,"ax");if err!=nil{t.Fatal(err)};a.Drain();c:=r.control.choice;if len(c.buttons)!=2||len(c.listRows)!=2||len(c.listCatalog.options)!=2||r.widget.AsTree().NumChildren()!=2{t.Fatal("retained catalog grew",i,len(c.buttons),len(c.listRows))}}
 if calls!=0{t.Fatal("removed rows inherited pending input",calls)}
 t.Log("512 distinct dynamic catalogs retained exactly two buttons, two row epochs and two eligibility entries, and no removed-row callbacks")
}
