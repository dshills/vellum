import ApplicationServices
import AppKit
import Foundation
struct Failure: Error, CustomStringConvertible { let description:String; init(_ s:String){description=s} }
func emit(_ o:[String:Any]){let d=try! JSONSerialization.data(withJSONObject:o,options:[.sortedKeys]);print(String(data:d,encoding:.utf8)!)}
func attr(_ n:AXUIElement,_ k:String)throws->CFTypeRef{var v:CFTypeRef?;let e=AXUIElementCopyAttributeValue(n,k as CFString,&v);guard e == .success,let v=v else{throw Failure("\(k):\(e.rawValue)")};return v}
func array(_ n:AXUIElement,_ k:String)->[AXUIElement]{(try? attr(n,k) as? [AXUIElement]) ?? []}
func string(_ n:AXUIElement,_ k:String)->String{(try? attr(n,k) as? String) ?? ""}
func encoded(_ s:String)->String{Data(s.utf8).base64EncodedString().replacingOccurrences(of:"+",with:"-").replacingOccurrences(of:"/",with:"_").replacingOccurrences(of:"=",with:"")}
func managed(_ s:String)->String{"node:"+encoded(s)}
func rowID(_ s:String)->String{"option:"+encoded("layers")+":"+encoded(s)}
func find(_ app:AXUIElement,_ id:String)throws->AXUIElement{let end=Date().addingTimeInterval(5);repeat{var q=[app];var at=0;while at<q.count && at<512 && Date()<end{let n=q[at];at+=1;_ = AXUIElementSetMessagingTimeout(n,0.3);if string(n,"AXIdentifier")==id{return n};q += array(n,"AXChildren");if at==1{q += array(n,"AXWindows")}};Thread.sleep(forTimeInterval:0.02)}while Date()<end;throw Failure("missing current element \(id)")}
func awaitValue(_ n:AXUIElement,_ value:String)throws{let end=Date().addingTimeInterval(3);repeat{if string(n,"AXValue")==value{return};Thread.sleep(forTimeInterval:0.02)}while Date()<end;throw Failure("expected value \(value), got \(string(n,"AXValue"))")}
func press(_ n:AXUIElement)throws{let e=AXUIElementPerformAction(n,kAXPressAction as CFString);guard e == .success else{throw Failure("press:\(e.rawValue)")};Thread.sleep(forTimeInterval:0.05)}
func click(_ n:AXUIElement,_ pid:pid_t)throws{let pv=try attr(n,"AXPosition"),sv=try attr(n,"AXSize");guard CFGetTypeID(pv)==AXValueGetTypeID(),CFGetTypeID(sv)==AXValueGetTypeID()else{throw Failure("row geometry type")};var p=CGPoint.zero;var s=CGSize.zero;guard AXValueGetValue(unsafeBitCast(pv,to:AXValue.self),.cgPoint,&p),AXValueGetValue(unsafeBitCast(sv,to:AXValue.self),.cgSize,&s),s.width>1,s.height>1 else{throw Failure("row clipped or empty")};p.x += s.width/2;p.y += s.height/2;
try check(NSWorkspace.shared.frontmostApplication?.processIdentifier==pid,"test app is not foreground for pointer");
emit(["probe":"mouse_geometry","x":p.x,"y":p.y,"width":s.width,"height":s.height,"frontmost_pid":NSWorkspace.shared.frontmostApplication?.processIdentifier ?? -1,"event_access":CGPreflightPostEventAccess()]);
CGEvent(mouseEventSource:nil,mouseType:.mouseMoved,mouseCursorPosition:p,mouseButton:.left)?.post(tap:.cghidEventTap);Thread.sleep(forTimeInterval:0.05);for t in [CGEventType.leftMouseDown,.leftMouseUp]{guard let e=CGEvent(mouseEventSource:nil,mouseType:t,mouseCursorPosition:p,mouseButton:.left)else{throw Failure("mouse allocation")};e.post(tap:.cghidEventTap);Thread.sleep(forTimeInterval:0.05)}}
func key(_ code:CGKeyCode,_ pid:pid_t){for down in [true,false]{let e=CGEvent(keyboardEventSource:nil,virtualKey:code,keyDown:down)!;e.flags=[];e.post(tap:.cghidEventTap);Thread.sleep(forTimeInterval:0.03)}}
func check(_ condition:Bool,_ why:String)throws{if !condition{throw Failure(why)}}
guard AXIsProcessTrusted()else{emit(["result":"UNAVAILABLE_EXISTING_AX_TRUST"]);exit(3)}
guard CommandLine.arguments.count==2,let pid=Int32(CommandLine.arguments[1])else{emit(["result":"INVALID_PID"]);exit(2)}
var evidence:[[String:Any]]=[]
do{
 let app=AXUIElementCreateApplication(pid);_ = AXUIElementSetMessagingTimeout(app,0.3)
 guard let running=NSRunningApplication(processIdentifier:pid)else{throw Failure("app process absent")};let activated=running.activate(options:[]);let activationDeadline=Date().addingTimeInterval(3);while NSWorkspace.shared.frontmostApplication?.processIdentifier != pid && Date()<activationDeadline{Thread.sleep(forTimeInterval:0.03)};emit(["probe":"activation","accepted":activated,"frontmost_pid":NSWorkspace.shared.frontmostApplication?.processIdentifier ?? -1]);defer{running.terminate()}
 let tab=try find(app,"option:"+encoded("pages")+":"+encoded("lists"));try press(tab)
 let list=try find(app,managed("layers"));try awaitValue(list,"Background")
 let rows=array(list,"AXRows");try check(string(list,"AXRole")=="AXList"&&rows.count==24,"real AXList/24 rows unavailable")
 try check(array(list,"AXSelectedRows").count==1,"initial native selected row missing")
 let initialVisible=array(list,"AXVisibleRows").count;try check(initialVisible>0&&initialVisible<24,"native visible rows are not bounded")
 evidence.append(["step":"initial","role":string(list,"AXRole"),"rows":rows.count,"visible_rows":initialVisible,"value":string(list,"AXValue")])
 let earlyRows=[try find(app,rowID("layer-01"))] as CFArray
 let earlySet=AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,earlyRows);try check(earlySet == .success,"initial external setter refused");try awaitValue(list,"Guides")
 evidence.append(["step":"initial-external-AX-setter","value":string(list,"AXValue")])
 let resetRows=[try find(app,rowID("layer-00"))] as CFArray;try check(AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,resetRows) == .success,"reset setter refused");try awaitValue(list,"Background")
 let guide=try find(app,rowID("layer-01"));try check(string(guide,"AXRole")=="AXRow","option is not native row")
 try click(guide,pid);try awaitValue(list,"Guides");evidence.append(["step":"os-pointer-measured-row","value":string(list,"AXValue")])
 key(119,pid);try awaitValue(list,"Annotations");evidence.append(["step":"os-key-end-scroll","value":string(list,"AXValue"),"visible_rows":array(list,"AXVisibleRows").count])
 key(125,pid);Thread.sleep(forTimeInterval:0.2);try check(string(list,"AXValue")=="Annotations","Down boundary changed selection")
 key(115,pid);try awaitValue(list,"Background")
 let setterRows=[try find(app,rowID("layer-01"))] as CFArray
 let setError=AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,setterRows);try check(setError == .success,"external selected-row setter refused \(setError.rawValue)");try awaitValue(list,"Guides")
 evidence.append(["step":"external-AX-selected-rows-owner-path","value":string(list,"AXValue")])
 key(115,pid);try awaitValue(list,"Background")
 let reject=try find(app,managed("list-reject"));try press(reject)
 let status=try find(app,managed("list-status"));let beforeReject=string(status,"AXDescription")+string(status,"AXTitle")
 try click(guide,pid);Thread.sleep(forTimeInterval:0.2);try check(string(list,"AXValue")=="Background","rejected native pointer changed accepted value")
 let afterReject=string(status,"AXDescription")+string(status,"AXTitle");try check(beforeReject != afterReject,"rejected native pointer did not reach owner request status")
 evidence.append(["step":"os-pointer-rejected","value":string(list,"AXValue"),"status":afterReject])
 let readonly=try find(app,managed("list-readonly"));try press(readonly)
 let beforeReadOnly=string(status,"AXDescription")+string(status,"AXTitle");key(119,pid);Thread.sleep(forTimeInterval:0.2)
 var settable=DarwinBoolean(false);let settableError=AXUIElementIsAttributeSettable(list,"AXSelectedRows" as CFString,&settable)
 try check(settableError == .success && !settable.boolValue,"read-only native list still writable")
 try check(string(list,"AXValue")=="Background" && beforeReadOnly==string(status,"AXDescription")+string(status,"AXTitle"),"read-only native key emitted model request")
 evidence.append(["step":"os-key-readonly-focus-only","value":string(list,"AXValue"),"selected_rows_settable":settable.boolValue])
 let clear=try find(app,managed("list-clear"));try press(clear);try awaitValue(list,"");try check(array(list,"AXSelectedRows").isEmpty,"programmatic empty selection retained native row")
 evidence.append(["step":"programmatic-clear","selected_rows":array(list,"AXSelectedRows").count])
 emit(["result":"PASS_SCOPED_NATIVE_LISTBOX_INPUT","pid":pid,"events":evidence,"scope":"Actual Mac app, external AX queries/actions and targeted CGEvent pointer/key delivery on current display; no physical hardware/human VoiceOver, cross-display, performance or memory qualification"])
}catch{emit(["result":"FAIL_SCOPED_NATIVE_LISTBOX_INPUT","pid":pid,"events":evidence,"error":"\(error)"]);exit(1)}
