from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
R=Path('/private/tmp/vellum-listbox');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-list-box/records'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
summary=json.loads((P/'summary.json').read_text());sources=summary['sources'];review=json.loads((P/'checkpoint-review.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());prism=json.loads((P/'prism-v1/prism.json').read_text());adjudication=json.loads((P/'prism-adjudication.json').read_text());coverage=prism['coverage']
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==sources and not review['unresolved_findings']and all(sha(R/n)==h for n,h in sources.items())
assert process['sources']==summary['provider_reviewed_sources']and process['source_index_stable']and process['exit_code']==1 and process['error']is None
assert coverage['complete']and coverage['files']==28 and not coverage['skipped']and not coverage['excluded']and coverage['truncatedBytes']==0 and coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert adjudication['sources']==process['sources']and not adjudication['unresolved_findings']and {f['id']for f in adjudication['findings']}=={f['id']for f in prism['findings']}
assert {g['id']for g in summary['native_qualification_gaps']if g['status']=='OPEN'}=={'LIST-NATIVE-01','LIST-NATIVE-02'}
D.mkdir(exist_ok=False)
excluded={'swift-cache','VellumListBox.app','__pycache__'}
omitted={}
for f in P.iterdir():
 if f.is_file()and(f.name.startswith('vellum-gallery')or f.name.startswith('vellum-sdk')and f.name.endswith('.tar.gz')or f.name.endswith('-inspector')or f.name=='listbox-live-inspector'):
  omitted[f.name]={'sha256':sha(f),'bytes':f.stat().st_size,'reason':'Private compiled app/inspector/SDK retained separately; invocation receipts and output scope are archived.'}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[]
for item in sorted(P.iterdir()):
 if item.name in excluded or item.name in omitted:continue
 if item.is_file():files.append(item)
 elif item.is_dir():files.extend(f for f in sorted(item.rglob('*'))if f.is_file()and'__pycache__'not in f.parts)
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
archive=D/'evidence.tar.xz'
with archive.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted,'excluded_directories':sorted(excluded)};(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**summary,'checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_process_sha256':sha(P/'prism-v1/process.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_llm_calls':coverage['llmCalls'],'prism_chunks':coverage['chunks'],'prism_raw_exit_code':1,'prism_findings':2,'prism_unresolved_findings':0,'prism_false_positives':2,'prism_coverage_complete':True,'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');subprocess.run(['git','add','--','docs/reports/macos-list-box/README.md','docs/reports/macos-list-box/records'],cwd=R,check=True);print(json.dumps({k:q[k]for k in ['result','archive_members','archive_bytes','archive_sha256','prism_findings']}))
