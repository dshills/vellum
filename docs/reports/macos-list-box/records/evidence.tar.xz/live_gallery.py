from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-listbox');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
from child_process import terminate_owned_group
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and all(sha(R/n)==h for n,h in review['sources'].items())
auth=P/'live-authorization.json';assert auth.is_file()and not(P/'stop-live').exists()
binary=P/'VellumListBox.app/Contents/MacOS/VellumListBox';assert sha(binary)==sha(P/'vellum-gallery-v3')
record={'authorization_sha256':sha(auth),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':[str(binary),'-exit-after=8m'],'binary_sha256':sha(binary),'sources':review['sources'],'native_application_executed':True,'producer_sha256':sha(__file__),'exit_code':None,'stop_reason':None};start=time.monotonic();process=None
try:
 with(P/'live-gallery.stdout').open('xb')as so,(P/'live-gallery.stderr').open('xb')as se:
  process=subprocess.Popen(record['argv'],cwd=R,env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
  record['pid']=process.pid;(P/'live-gallery-owned-process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'pid':process.pid,'native_application_launched':True}),flush=True)
  while process.poll()is None:
   if(P/'stop-live').exists()or time.monotonic()-start>500:
    record['stop_reason']='human-returned-or-stop-marker'if(P/'stop-live').exists()else'bounded-deadline';terminate_owned_group(process);break
   time.sleep(.2)
  record['exit_code']=process.wait(timeout=8)
finally:
 if process is not None and process.poll()is None:terminate_owned_group(process)
 record['elapsed_seconds']=time.monotonic()-start;record['sources_stable']=all(sha(R/n)==h for n,h in review['sources'].items());record['process_terminal']=process is not None and process.poll()is not None
 for channel in ['stdout','stderr']:record[channel+'_sha256']=sha(P/('live-gallery.'+channel))
 (P/'live-gallery.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','stop_reason','elapsed_seconds','process_terminal','sources_stable']}),flush=True)
