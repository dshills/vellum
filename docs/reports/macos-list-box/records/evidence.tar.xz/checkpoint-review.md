# ListBox scoped checkpoint review

APPROVED_SOURCE_AND_EVIDENCE — exact 28-file `checkpoint-inputs.json` vector; no unresolved review findings. The sole post-provider source difference is the reviewed report clarification.

Terminal code/SDK receipts, current hashes, 6,227-file recorded prepared maps, capture-only image bindings and raw native attempts reconcile. The actual external AX subset passes: AXList, 24 rows/seven initially visible, owner selection/rejection/read-only protection, clear and stable-ID offscreen selection. Raw Prism remains exit 1/two false-positive findings/seven calls.

**LIST-NATIVE-01/02 remain OPEN.** Read-only AX writability metadata still reports settable; native pointer/key and focus/reveal are unqualified. Failed probes and unknown causes remain preserved. Cleanup evidence supports reaped app/inspector children, without independent process-group absence or framework/native resource counters. The eight-minute gallery/CUA observation qualifies no ListBox interaction.

The later report clarification now states these limits. No tests/builds/apps/GUI/GPU/network/provider execution or repository edits were performed by this reviewer. Physical input, VoiceOver, performance, memory, endurance, distribution and full Mac/P6/P9/P11 acceptance remain open. Seal/final staged-artifact review is separate.
