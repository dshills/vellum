The ListBox design is feasible using retained choice widgets and existing managed focus/AX transport, with two requirements before implementation approval.

Do not reuse queueChoice delivery-time descriptor deduplication: held B→A proposals can drop the return to a stale accepted A descriptor and become batch-dependent. Preserve absolute FIFO intents/latest callbacks and keep focus, native preview and accepted owner selection separate. Host AX set actions also need an originating options/eligibility epoch or action-aware row guard; per-row guards alone do not bind action.Value. Preserve existing bridge-generation refusal semantics for AX.

Specify arrow-versus-selection and empty/read-only focus behavior. Use clamped list navigation, measured page/reveal behavior, bounded allocated scrolling, permanent row/whole-input revocation on observed disabled/hidden/modal/transfer ABA, and current callback delivery. Keep selection changes out of keyboard/pointer lease invalidation.

Add true list/list-option Cocoa roles and all/visible/selected row handling with clipped completed geometry; current option is a radio button and current visible-row projection is not a list viewport filter. Require held-queue batch1/7/64 ordering, lifecycle/saturation, four-DPI actual input/geometry/pixels, inert Cocoa and independent SDK/API tests. No new Core primitive appears necessary.

These are source-backed design constraints, not implementation or live acceptance. No test/build/native/provider or OS work was launched and no repository files changed; VoiceOver/performance/fullMac remain open.
