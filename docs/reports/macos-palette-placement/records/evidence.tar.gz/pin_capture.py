from pathlib import Path
import difflib,json,hashlib
R=Path('/private/tmp/vellum-palette-placement');P=Path(__file__).resolve().parent;U=R/'drivers/cogent/build/upstream';D=R/'drivers/cogent/native/patches/pointercapture';D.mkdir(exist_ok=True)
original=json.loads((P/'capture-original/hashes.json').read_text());names=[*original,'core/pointer_capture.go','core/pointer_capture_test.go']
old={n:(P/'capture-original'/n).read_text()if n in original else ''for n in names}
for n,h in original.items():assert hashlib.sha256((P/'capture-original'/n).read_bytes()).hexdigest()==h
patch=''.join(''.join(difflib.unified_diff(old[n].splitlines(True),(U/n).read_text().splitlines(True),fromfile='a/'+n if n in original else '/dev/null',tofile='b/'+n))for n in names)
file=D/'0065-scoped-window-pointer-capture.patch';file.write_text(patch)
(D/'original-hashes.json').write_text(json.dumps({n:original.get(n)for n in names},indent=2)+'\n')
(D/'output-hashes.json').write_text(json.dumps({n:hashlib.sha256((U/n).read_bytes()).hexdigest()for n in names},indent=2)+'\n')
manifest=R/'drivers/cogent/native/dependencies.json';doc=json.loads(manifest.read_text());stages=doc['dependencies'][0]['stages'];stages[:]=[s for s in stages if s.get('inputs')!='native/patches/pointercapture/original-hashes.json'];stages.append({'origin':'drivers/cogent/pointercapture','inputs':'native/patches/pointercapture/original-hashes.json','outputs':'native/patches/pointercapture/output-hashes.json','patches':[{'file':'native/patches/pointercapture/'+file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}]});manifest.write_text(json.dumps(doc,indent=2)+'\n')
print(len(names),len(patch))
