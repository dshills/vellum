from pathlib import Path
import hashlib,importlib.util,json,sys,tempfile,time
R=Path('/private/tmp/vellum-palette-placement');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child,check_child_output
from sdk_environment import child_environment
spec=importlib.util.spec_from_file_location('checker',R/'scripts/check-sdk.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected=json.loads((P/'sdk-archive-v2.stdout').read_text())['sha256'];archive=P/'vellum-sdk-v2.tar.gz'
source=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in source.items())
record={'archive_sha256':expected,'sources':source,'producer_sha256':sha(__file__),'native_binary_executed':False,'checks':[],'result':'STARTED'};start=time.monotonic()
env={**child_environment(),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2'}
try:
 verified=checker.verify_archive(archive,expected)
 with tempfile.TemporaryDirectory(prefix='vellum placement relocated ')as directory:
  sdk=checker.extract_verified(archive,Path(directory)/'extracted SDK',verified);consumer=sdk/'examples/placement'
  assert (sdk/'placement/placement.go').is_file()and (consumer/'routing_offscreen_test.go').is_file()
  modules=checker.decode_objects(check_child_output(['go','list','-m','-json','all'],cwd=consumer,env=env,text=True,timeout=120))
  record['origins']=checker.check_origin(modules,sdk,'github.com/dshills/vellum')
  with (P/'relocated-placement-v2.stdout').open('xb')as so,(P/'relocated-placement-v2.stderr').open('xb')as se:
   for args in [['go','test','-race','-tags','offscreen','./...','-count=1','-timeout=90s'],['go','vet','-tags','offscreen','./...'],['go','build','-o',str(P/'placement-relocated-v2.bin'),'.']]:
    result=run_child(args,cwd=consumer,env=env,stdout=so,stderr=se,timeout=180);record['checks'].append({'argv':args,'exit_code':result.returncode});assert result.returncode==0
 record['source_stable']=all(sha(R/n)==h for n,h in source.items());assert record['source_stable'];record['result']='PASS_RELOCATED_PLACEMENT_CONSUMER'
except BaseException as error:
 record['result']='FAILED';record['error']={'type':type(error).__name__,'message':str(error)};raise
finally:
 record['elapsed_seconds']=time.monotonic()-start
 for name in ['stdout','stderr']:
  path=P/('relocated-placement-v2.'+name);record[name+'_sha256']=sha(path)if path.exists()else None
 (P/'relocated-placement-v2.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['result','elapsed_seconds','archive_sha256','source_stable','origins']}))
