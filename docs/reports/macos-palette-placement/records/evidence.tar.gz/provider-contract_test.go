package app

import (
 "errors"
 "image/color"
 "runtime"
 "strings"
 "testing"

 "github.com/dshills/vellum/canvas"
 "github.com/dshills/vellum/ui"
)
func TestPrismDoIsSynchronousAndQueueIndependent(t *testing.T){
 a,err:=New(Config{QueueCapacity:1});if err!=nil{t.Fatal(err)};defer a.Close()
 for _,id:=range []string{"one","sibling"}{if err:=a.Open(Window{ID:id,Title:id,Width:400,Height:300,View:func()ui.Node{return ui.Node{ID:"root",Kind:ui.Label,Text:"Test"}}});err!=nil{t.Fatal(err)}}
 if err:=a.Post(func(){});err!=nil{t.Fatal(err)}
 if err:=a.Post(func(){});!errors.Is(err,ErrQueueFull){t.Fatal("ordinary queue not saturated",err)}
 caller:=make([]byte,128);caller=caller[:runtime.Stack(caller,false)]
 var callback []byte
 calls:=0
 err=a.Do(func(){calls++;callback=make([]byte,128);callback=callback[:runtime.Stack(callback,false)]})
 if err!=nil || calls!=1 || strings.Fields(string(caller))[1]!=strings.Fields(string(callback))[1]{t.Fatal("Do is queued, asynchronous or changed goroutine",err,calls)}
 if err:=a.CloseWindow("one");err!=nil{t.Fatal(err)}
 if err:=a.Do(func(){calls++});err!=nil || calls!=2{t.Fatal("window closure changed Do error contract",err)}
 a.Close()
 if err:=a.Do(func(){calls++});!errors.Is(err,ErrClosed) || calls!=2{t.Fatal("closed-owner Do admitted callback",err)}
}
func TestPrismCanvasPreviewColorIsConcrete(t *testing.T){
 var col color.Color=canvas.Rect{}.Color
 if col==nil{t.Fatal("concrete RGBA unexpectedly nil")}
 _=color.NRGBAModel.Convert(col).(color.NRGBA)
}
