from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path('/private/tmp/vellum-palette-placement');P=Path(__file__).resolve().parent;D=R/'docs/reports/macos-palette-placement/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];summary=json.loads((P/'summary.json').read_text());review=json.loads((P/'checkpoint-review.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==sources and not review['unresolved_findings']
assert summary['sources']==sources and summary['result']=='PASS_SCOPED_PALETTE_PLACEMENT_CODE_CHECKS'and summary['prepared_files']==6223
assert not any(summary[k]for k in ['native_binary_executed','full_mac_qualified','full_P9_qualified','full_P11_qualified','physical_pointer_qualified','cross_window_supported'])
assert all(sha(R/n)==h for n,h in sources.items())
prism=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());coverage=prism['coverage'];adjudication=json.loads((P/'prism-adjudication.json').read_text())
assert process['exit_code']in [0,1]and process['error']is None and process['source_index_stable']and process['sources']==adjudication['pre_provider_sources']
assert adjudication['sources']==sources and not adjudication['unresolved_findings']
assert {f['id']for f in prism['findings']}=={f['id']for f in adjudication['findings']}
assert coverage['complete']and coverage['files']==len(process['sources'])and not coverage['excluded']and not coverage['skipped']and coverage['truncatedBytes']==0
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
D.mkdir(exist_ok=False)
omitted={}
for name in ['vellum-placement','vellum-placement-v2','placement-relocated-v2.bin','vellum-sdk.tar.gz','vellum-sdk-v2.tar.gz']:
 f=P/name
 if f.is_file():omitted[name]={'sha256':sha(f),'bytes':f.stat().st_size,'reason':('Private SDK archive checked and relocated; full SDK omitted from source evidence archive.' if name.endswith('.tar.gz') else 'Compiled native executable; never launched; omitted from source evidence archive.')}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[f for f in sorted(P.rglob('*'))if f.is_file()and f.relative_to(P).as_posix()not in omitted and '__pycache__'not in f.parts]
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files}
archive=D/'evidence.tar.gz'
with archive.open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for f in files:
  data=f.read_bytes();info=tarfile.TarInfo(f.relative_to(P).as_posix());info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'omitted_binaries':omitted}
(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**summary,'result':'PASS_SCOPED_PALETTE_PLACEMENT_CHECKPOINT','checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'prism_sha256':sha(P/'prism-v1/prism.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_invocations':1,'prism_llm_calls':coverage['llmCalls'],'prism_chunks':coverage['chunks'],'prism_raw_exit_code':process['exit_code'],'prism_findings':len(prism['findings']),'prism_unresolved_findings':0,'prism_false_positives':sum(f['disposition']=='REJECTED_FALSE_POSITIVE'for f in adjudication['findings']),'prism_discarded_observations':len(prism.get('discarded',[])),'prism_adjudication_sha256':sha(P/'prism-adjudication.json'),'prism_coverage_complete':True,'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
subprocess.run(['git','add','docs/reports/macos-palette-placement/records'],cwd=R,check=True)
print(json.dumps({'result':q['result'],'members':len(members),'archive_bytes':index['archive_bytes'],'archive_sha256':index['archive_sha256'],'prism_findings':q['prism_findings'],'prism_llm_calls':coverage['llmCalls']}))
