# Palette placement Prism adjudication

RESOLVED_NO_SOURCE_CHANGE. Current and pre-provider 38-source maps are identical; no unresolved findings. Raw exit 1, one high and three medium retained findings, two discarded observations, and ten calls remain preserved.

- 56ce65265d5581d4: non-closed Do errors are unreachable at this nonnil callback; queue/window refusal belongs to other APIs.
- 79751d033bfb1686: preview colour is concrete RGBA; supported active-stage dispatch/teardown is serialized and revokes capture before field cleanup.
- a588c137672a06e3: Do executes directly on the test caller, so t.Fatal is on the test goroutine.
- 8a4d5a409e9e2c5b: Manual has no hidden event loop; fixture writes and refresh/Drain are sequential.

The isolated provider-contract test confirms Do/error/goroutine and concrete-colour contracts. Actual discarded focus-loss and synchronous-loss paths were also read: the window context already exists at entry, capture revokes before loss, and managed loss only clears preview and publishes reserved owner cancellation. No claim is made that arbitrary third-party loss callbacks can reenter teardown.

Raw/provider/source bytes are unchanged. This is bounded source adjudication, not native or performance qualification.
