from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-palette-placement');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((P/'checkpoint-source.json').read_text());sources=manifest['sources']
assert all(sha(R/n)==h for n,h in sources.items())
checks={}
scopes={
 'portable-v5':['app/','automation/','canvas/','command/','document/','editor/','execution/','history/','placement/','replay/','tasks/','ui/','virtual/','workbench/'],
 'vet-root-final':['placement/','ui/'],
 'capture-v3':['drivers/cogent/native/patches/pointercapture/'],
 'routed-v5':['drivers/cogent/native/patches/pointercapture/'],
 'routing-origin-v1':['drivers/cogent/placement.go','drivers/cogent/accessibility.go','drivers/cogent/controls.go'],
 'consumer-v4':['examples/placement/','drivers/cogent/placement.go','drivers/cogent/accessibility.go','drivers/cogent/controls.go'],
 'adapter-race-v2':['drivers/','placement/','ui/'],
 'vet-adapter-v2':['drivers/','placement/','ui/'],
 'vet-consumer-v2':['examples/placement/','drivers/','placement/','ui/'],
 'native-build-v2':['examples/placement/','drivers/','placement/','ui/'],
 'prepare-tests-final':['drivers/cogent/prepare_test.py','drivers/cogent/native/'],
 'prepare-reproduction':['drivers/cogent/native/'],
 'sdk-tests-final':['scripts/release-sdk.py','scripts/release-sdk_test.py','ui/','placement/'],
 'sdk-archive-v2':[''],
 'sdk-relocation-v2':[''],
}
for name,prefixes in scopes.items():
 d=json.loads((P/(name+'.json')).read_text())
 assert d['exit_code']==0 and d['error']is None and d['source_delta_stable']and d['prepared_before']==d['prepared_after']
 assert len(d['prepared_after'])==6223
 required={n:h for n,h in sources.items()if any(n.startswith(prefix)for prefix in prefixes)}
 assert all(d['source_delta_after'].get(n)==h for n,h in required.items()),(name,[n for n,h in required.items()if d['source_delta_after'].get(n)!=h])
 for channel in ['stdout','stderr']:assert sha(P/(name+'.'+channel))==d[channel+'_sha256']
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'current_sources_matched':sorted(required),'source_stable':True,'prepared_files':6223}
relocated=json.loads((P/'relocated-placement-v2.json').read_text());assert relocated['result']=='PASS_RELOCATED_PLACEMENT_CONSUMER'and relocated['source_stable']and relocated['sources']==sources
archive=json.loads((P/'sdk-archive-v2.stdout').read_text());assert archive['sha256']==sha(P/'vellum-sdk-v2.tar.gz')==relocated['archive_sha256']
review=json.loads((P/'checkpoint-review-source-v2.json').read_text());assert review['result']=='APPROVED_SOURCE'and review['sources']==sources and not review['unresolved_findings']
summary={
 'result':'PASS_SCOPED_PALETTE_PLACEMENT_CODE_CHECKS','base_commit':manifest['base_commit'],'sources':sources,'checks':checks,
 'prepared_files':6223,'pinned_preparation_reproduced_exactly':True,
 'relocated_placement_receipt_sha256':sha(P/'relocated-placement-v2.json'),'sdk_sha256':archive['sha256'],
 'native_binary_sha256':sha(P/'vellum-placement-v2'),'native_binary_executed':False,'physical_pointer_qualified':False,'cross_window_supported':False,'full_mac_qualified':False,'full_P9_qualified':False,'full_P11_qualified':False,
 'internal_source_review_sha256':sha(P/'checkpoint-review-source-v2.json'),
 'failed_attempts_excluded_from_acceptance':{'portable-v1':'initial rejection fixture remained in accepted world region; corrected fixture','routed-v2':'completion admission exhaustion initially surfaced as sticky failure; corrected graceful refusal','consumer-v1':'selection test clicked object boundary; uses interior point','routed-v4':'wheel intentionally zoomed child canvas; fixture now sets real ancestor scrollbar before pointer route','consumer-v3':'manual API accepts primitive MouseMove, not derived MouseDrag; corrected fixture','relocated-placement-v1':'extraction destination already existed; corrected producer uses new subdirectory'},
 'limits':['Same native window only; no OS drag session, cross-window/app transfer or drag autoscroll','Code/offscreen evidence only; no native GUI/GPU/physical pointer, cross-display or external AX qualification','Payload/history bounds count objects/changes, not application payload bytes','App owns scene/domain geometry, target policy and atomic command/history mutation'],
}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'result':summary['result'],'sources':len(sources),'checks':len(checks),'sdk_sha256':archive['sha256']}))
