"""Final affected-package checks for the permanent epoch-exhaustion latch."""
from pathlib import Path
import datetime,importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-pending-native-final');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
spec=importlib.util.spec_from_file_location('pending_checks',W/'check-pending.py');checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(checks)
name=sys.argv[1];commands={'package':['go','test','-race','-p=1','-count=1','-tags=offscreen','.'],'vet':['go','vet','-p=1','-tags=offscreen','./...']};assert name in commands
P.mkdir(mode=0o700,exist_ok=True);out=P/name;out.mkdir();before=checks.source();(out/'source.json').write_text(json.dumps(before,indent=2)+'\n');env={**checks.child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};start=time.monotonic();argv=commands[name]
with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:r=checks.run_child(argv,cwd=str(T/'drivers/cogent'),env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20)
d=dict(argv=argv,exit_code=r.returncode,source_stable=checks.source()==before,source_sha256=checks.sha(out/'source.json'),producer_sha256=checks.sha(__file__),elapsed_seconds=time.monotonic()-start,native_ui_runtime_executed=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),logs={n:dict(bytes=(out/n).stat().st_size,sha256=checks.sha(out/n))for n in ['stdout','stderr']});(out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert d['exit_code']==0 and d['source_stable']
