"""Stage only the reviewed candidate after all frozen-source native cases retire."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-pending-native-work')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
review=json.loads((W/'source-review-v1.json').read_bytes());sources=review['sources'];assert review['source_ready']and not review['unresolved_findings']and all(sha(T/p)==h for p,h in sources.items())
native=json.loads((W/'pending-native-analysis.json').read_bytes());assert len(native['cases'])==22 and native['ordinary_samples']==2400
spec=importlib.util.spec_from_file_location('pending_build',W/'build-pending-native.py');build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
assert build.identity()==json.loads((P/'native-build/source.json').read_bytes())
assert git('rev-parse','HEAD').decode().strip()==review['base_commit']and not git('diff','--cached','--name-only')
changed=set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(sources)
subprocess.run(['git','diff','--check'],cwd=T,check=True);subprocess.run(['git','add','--',*sources],cwd=T,check=True);assert not git('diff','--name-only')
diff=git('diff','--cached','--binary');assert 0<len(diff)<48000
(W/'pending-staged.diff').write_bytes(diff)
binding=dict(base_commit=review['base_commit'],sources=sources,source_review_sha256=sha(W/'source-review-v1.json'),native_result_sha256=sha(W/'pending-native-analysis.json'),staged_diff_sha256=hashlib.sha256(diff).hexdigest(),staged_diff_bytes=len(diff),producer_sha256=sha(__file__),source_files=len(git('ls-files','-z').split(b'\0'))-1,prepared_files=6243)
(W/'pending-binding.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({k:v for k,v in binding.items()if k!='sources'}))
