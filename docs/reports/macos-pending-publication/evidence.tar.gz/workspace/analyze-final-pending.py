"""Reconcile every raw native case and matched pair, preserving scope limits."""
from pathlib import Path
import hashlib,importlib.util,json,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-pending-native-final')
spec=importlib.util.spec_from_file_location('pending_native',W/'run-final-pending.py');run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
sha=run.sha
def main():
 cases={};streams={}
 for name in run.ORDER:
  out=P/'native-runs'/name;r=run.read(out/'receipt.json')
  run.need(r['result']=='PASS_SCOPED_NATIVE_CASE'and r['error']is None and not r['cleanup_errors'],'terminal '+name)
  run.need(all(r[k]is True for k in ['native_runtime_executed','source_stable','pins_stable','logs_complete','lease_held_through_cleanup'])and r['stop_marker_at_exit']is False,'controls '+name)
  run.need(r['retirement']['terminal']and r['retirement']['group_absent']and r['retirement']['exit_code']==0 and r['exit_code']==0,'retirement '+name)
  for n,item in r['logs'].items():run.need((out/n).stat().st_size==item['bytes']and sha(out/n)==item['sha256'],'raw output '+name)
  records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];validation=run.validate(name,records)
  run.need(validation==r['validation'],'recorded validation '+name)
  cases[name]=dict(receipt_sha256=sha(out/'receipt.json'),validation=validation,elapsed_seconds=r['elapsed_seconds'],binary_sha256=r['binary_sha256'],binary_source_sha256=r['binary_source_sha256']);streams[name]=records
 comparisons={}
 for mode in ['cpu','gpu']:
  pairs=[];all_metrics={arm:[]for arm in ['base','candidate']}
  for pair in range(1,2):
   runs={arm:run.benchmark.validate_records(streams[f'{mode}-p{pair}-{arm}'],1000000,False,120,False,gpu_scene_rendering=mode=='gpu')for arm in ['base','candidate']}
   run.benchmark.compare_geometry(runs['base'],runs['candidate'])
   for a,b in zip(runs['base'],runs['candidate']):
    run.need(a['geometry']==b['geometry'],'complete paired geometry '+mode)
   metrics={arm:run.benchmark.distribution([x['metrics']['ui_work_ns']for x in samples])for arm,samples in runs.items()}
   pairs.append(dict(pair=pair,geometry_pairs=120,ui_work_ns=metrics,p95_ratio=metrics['candidate']['p95']/metrics['base']['p95']))
   for arm in all_metrics:all_metrics[arm].append(runs[arm])
  comparisons[mode]=dict(pairs=pairs,metrics={arm:run.benchmark.summarize(runs)for arm,runs in all_metrics.items()},
   median_process_p95_ns={arm:statistics.median([p['ui_work_ns'][arm]['p95']for p in pairs])for arm in ['base','candidate']},
   individual_runs_failing_p95_4ms={arm:sum(p['ui_work_ns'][arm]['p95']>4000000 for p in pairs)for arm in ['base','candidate']},
   individual_runs_failing_p99_6ms={arm:sum(p['ui_work_ns'][arm]['p99']>6000000 for p in pairs)for arm in ['base','candidate']})
 result=dict(schema='vellum-pending-publication-native-comparison-v1',cases=cases,comparisons=comparisons,total_native_processes=6,ordinary_processes=4,ordinary_samples=480,geometry_pairs=240,
  analyzer_sha256=sha(__file__),native_execution_review_sha256=sha(W/'cache-parity-execution-review.json'),native_build_receipt_sha256=sha(P/'native-build/receipt.json'),
  scope_limits=['Exact-byte uncommitted candidate versus clean c504 baseline; binary source manifests and runtime metadata retained.', 'Only fixed million-row ordinary workload in CPU and GPU-requested modes. No variable/10k/general workload or full Mac acceptance.', 'No physical pointer, keyboard, preview, display, IME, VoiceOver or GPU-execution qualification.', 'No native-function CPU attribution, native/GPU memory budget or continuous global host-isolation proof.'])
 (W/'final-native-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(processes=6,ordinary_samples=480,geometry_pairs=240,modes={mode:{k:r[k]for k in ['median_process_p95_ns','individual_runs_failing_p95_4ms','individual_runs_failing_p99_6ms']}for mode,r in comparisons.items()})))
if __name__=='__main__':main()
