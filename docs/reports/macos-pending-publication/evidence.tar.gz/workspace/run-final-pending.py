"""Serial, owned native acceptance and matched ordinary grid comparisons."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,selectors,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-pending-native-final');T=Path('/private/tmp/vellum-macos-native-results-97aee13');BASE=Path('/private/tmp/vellum-native-grid-stacks-c5045bc')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
build=module('pending_native_build',W/'build-final-pending.py');owned=module('owned_stack',W/'run.py')
benchmark=module('pending_grid_benchmark',T/'scripts/benchmark-grid.py')
sha=build.sha
STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
ORDER=['ax','grid-ax']+[f'{mode}-p{pair}-{arm}'for pair in range(1,2)for mode in ['cpu','gpu']for arm in(['base','candidate']if pair%2 else['candidate','base'])]
def need(ok,message):
 if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_bytes())
def validate(name,records):
 need(all(type(x)is dict for x in records),'stdout objects')
 if name=='ax':
  need(len(records)==1 and records[0].get('result')=='PASS'and records[0].get('native')=='macOS NSAccessibility'and records[0].get('voiceover_tested')is False and records[0].get('preferences_changed')is False and records[0].get('geometry_persistence_disabled_in_fixture')is True,'native AX outcome');return dict(native_ax=records[0],physical_input_verified=False)
 if name=='grid-ax':
  need(len(records)==2 and [x.get('event')for x in records]==['grid.accessibility.pass','grid.accessibility.closed'],'grid stages');a,b=records
  need(a.get('rows')==1000000 and a.get('visible_minimum')==400 and a.get('overlap_objects_reused',0)>=400 and a.get('replacement_objects_retired',0)>=400 and a.get('native_press_admitted')is True and b.get('attachment_query_refused')is True and b.get('geometry_persistence_disabled_in_fixture')is True,'grid identities/actions/closure');return dict(events=records,physical_input_verified=False)
 mode,_,arm=name.split('-');samples=benchmark.validate_records(records,1000000,False,120,False,gpu_scene_rendering=mode=='gpu');settings=records[0]['build_settings']
 need(settings.get('vcs.revision')=='c5045bc76a6d06c4f127957453fa3321719d46a8'and settings.get('vcs.modified')==('false'if arm=='base'else'true')and settings.get('CGO_ENABLED')=='1'and settings.get('-race','false')!='true','runtime exact source build metadata')
 need(records[1]['warmup']==128 and records[0].get('geometry_persistence_disabled_in_fixture')is True,'warm/persistence')
 need(all(x.get(k,False)is False for x in records for k in ['cpu_profile','alloc_profile','input_details','source_details']),'ordinary no profile flags')
 return dict(samples=120,warmup=128,ui_work_ns=benchmark.distribution([s['metrics']['ui_work_ns']for s in samples]),arm=arm,exact_byte_uncommitted_candidate=arm=='candidate',gpu_execution_verified=False,physical_input_verified=False)
def main():
 need(len(sys.argv)==2 and sys.argv[1]in ORDER,'fixed native case');name=sys.argv[1]
 review=read(W/'cache-parity-execution-review.json');need(review['execution_ready']and not review['unresolved_findings'],'execution review');pins=review['inputs']
 def stable():return all(sha(p)==h for p,h in pins.items())
 def stopping():return STOP.exists()or(P/'stop-live').exists()
 receipt=read(P/'native-build/receipt.json');source=read(P/'native-build/source.json');need(receipt['source_stable']and receipt['uncommitted_candidate'],'compiled exact candidate');need(build.identity()==source,'current source')
 if name=='ax':entry=receipt['binaries']['ax'];args=[]
 elif name=='grid-ax':entry=receipt['binaries']['loadedgrid'];args=['-accessibility-smoke','-rows=1000000']
 else:
  mode,_,arm=name.split('-');entry=read(BASE/'build.json')if arm=='base'else receipt['binaries']['loadedgrid'];args=['-perf','-rows=1000000','-perf-samples=120','-perf-warmup=128']+(['-gpu-scene']if mode=='gpu'else[])
 binary=entry['binary'];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'binary')
 need(stable()and not stopping(),'admission')
 with owned.LiveLease()as lease:
  need(lease.held()and stable()and not stopping(),'lease admission')
  index=ORDER.index(name)
  if index:
   prior=read(P/'native-runs'/ORDER[index-1]/'receipt.json');need(prior['result']=='PASS_SCOPED_NATIVE_CASE','predecessor');owned.absent(prior['retirement']['pid'])
  out=P/'native-runs'/name;out.mkdir(parents=True,mode=0o700);argv=[binary['path'],*args];child=None;start=time.monotonic();errors=[];counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()];eof=[False,False]
  binary_source=BASE/'source.json'if name.endswith('-base')else P/'native-build/source.json'
  d=dict(case=name,argv=argv,cwd=entry['cwd'],binary_sha256=binary['sha256'],binary_source_sha256=sha(binary_source),current_candidate_source_sha256=sha(P/'native-build/source.json'),producer_sha256=sha(__file__),review_sha256=sha(W/'cache-parity-execution-review.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False,physical_input_generated=False,settings_changes=False,error=None)
  try:
   with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr,selectors.DefaultSelector()as selector:
    need(stable()and not stopping(),'final launch admission')
    child=subprocess.Popen(argv,cwd=d['cwd'],env={**owned.child_environment(True),'GOMAXPROCS':'2'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);d.update(pid=child.pid,native_runtime_executed=True)
    (out/'owned.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(event='native.started',case=name,pid=child.pid)),flush=True)
    for i,pipe in enumerate([child.stdout,child.stderr]):selector.register(pipe,selectors.EVENT_READ,i)
    terminal=None
    while selector.get_map()or child.poll()is None:
     need(not stopping(),'human-return marker');need(time.monotonic()-start<180,'native watchdog')
     if child.poll()is not None:
      if terminal is None:terminal=time.monotonic()
      need(not selector.get_map()or time.monotonic()-terminal<5,'surviving pipe writer')
     for key,_ in selector.select(.1):
      data=os.read(key.fd,64<<10);i=key.data
      if not data:eof[i]=True;selector.unregister(key.fileobj);continue
      accepted=min(len(data),(8<<20)-counts[i]);stream=[stdout,stderr][i]
      need(stream.write(data[:accepted])==accepted,'short output');stream.flush();counts[i]+=accepted;digests[i].update(data[:accepted]);need(accepted==len(data),'log bound')
    d['exit_code']=child.wait(timeout=5)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   d['retirement']=owned.retire(child,'native',errors);d['cleanup_errors']=errors
   try:d['source_stable']=build.identity()==source;d['pins_stable']=stable()
   except BaseException as e:errors.append(dict(stage='identity',type=type(e).__name__,message=str(e)))
   d['logs_complete']=False
   try:
    d['logs']={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']};d['logs_complete']=all(eof)and all(d['logs'][n]['bytes']==counts[i]and d['logs'][n]['sha256']==digests[i].hexdigest()for i,n in enumerate(['stdout','stderr']))
   except BaseException as e:errors.append(dict(stage='output-observation',type=type(e).__name__,message=str(e)))
   try:
    need(d['error']is None and not errors and d.get('exit_code')==0 and d['retirement'].get('terminal')and d['retirement'].get('group_absent')and d.get('source_stable')and d.get('pins_stable')and d['logs_complete']and not stopping()and lease.held(),'native controls')
    records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];d['validation']=validate(name,records)
   except BaseException as e:
    if d['error']is None:d['error']=dict(type=type(e).__name__,message=str(e))
   d.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),lease_held_through_cleanup=lease.held(),stop_marker_at_exit=stopping());d['result']='PASS_SCOPED_NATIVE_CASE'if d['error']is None and not errors else'FAILED_OR_CANCELED_NATIVE_CASE'
   (out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k]for k in ['case','result','error','cleanup_errors','elapsed_seconds']}),flush=True)
  need(d['result']=='PASS_SCOPED_NATIVE_CASE','native case failed')
if __name__=='__main__':main()
