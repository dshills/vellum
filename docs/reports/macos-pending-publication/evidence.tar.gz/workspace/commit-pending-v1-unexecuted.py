"""Commit the final bound eight files and fast-forward the clean canonical checkout."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=60)
def clean(root):return not git(root,'status','--porcelain=v1','--untracked-files=all')
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
b=json.loads((W/'final-binding.json').read_bytes());r=json.loads((W/'final-review.json').read_bytes())
assert r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
assert git(T,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/macos-native-results'
assert git(C,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/foundation-completion'
assert git(T,'rev-parse','HEAD').decode().strip()==b['base_commit']==git(C,'rev-parse','HEAD').decode().strip()
assert clean(C)and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources'])
assert all(sha(T/p)==h for p,h in b['sources'].items())
diff=git(T,'diff','--cached','--binary');assert len(diff)==b['staged_diff_bytes']and hashlib.sha256(diff).hexdigest()==b['staged_diff_sha256']==sha(W/'final-staged.diff')
spec=importlib.util.spec_from_file_location('finalbuild',W/'build-final-pending.py');build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
source=json.loads(Path('/private/tmp/vellum-pending-native-final/native-build/source.json').read_bytes())
assert build.prepared()==source['prepared']
for p,h in source['source']['files'].items():assert sha(T/p)==h
message=W/'source-commit-message.txt';message.write_text('Preserve native accessibility state on pending publications\n\nProve pending-only changes against a detached wire baseline, preflight every native scope, and keep full JSON fallback. Preserve object identity while pruning ancillary geometry caches identically to full publication; disable reuse permanently after epoch exhaustion.\n\nAdd differential native state/lifecycle and bounded-baseline regressions. Verified affected-package offscreen race, module vet, native AX/grid and matched grid sanity runs. One Prism Anthropic Sonnet 5.5 review plus independent internal correction/result review; performance qualification remains open.\n')
subprocess.run(['git','commit','--file',str(message)],cwd=T,check=True,timeout=120)
commit=git(T,'rev-parse','HEAD').decode().strip();assert git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit']and clean(T)
assert set(git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources'])
assert clean(C)and git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']
subprocess.run(['git','merge','--ff-only',commit],cwd=C,check=True,timeout=120)
assert clean(C)and git(C,'rev-parse','HEAD').decode().strip()==commit
files=git(T,'ls-files','-z').decode().rstrip('\0').split('\0');assert len(files)==b['source_files']
assert all(sha(T/p)==sha(C/p)for p in files)
for p,h in source['prepared'].items():assert sha(C/'drivers/cogent/build'/p)==h
result=dict(source_commit=commit,parent=b['base_commit'],canonical_promoted=True,both_clean=True,source_files=len(files),prepared_files=len(source['prepared']),binding_sha256=sha(W/'final-binding.json'),review_sha256=sha(W/'final-review.json'),producer_sha256=sha(__file__),runtime_binaries_relabelled=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(W/'commit-pending-receipt.json',result);print(json.dumps(result))
