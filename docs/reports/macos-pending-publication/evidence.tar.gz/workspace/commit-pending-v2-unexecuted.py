"""Commit the final bound eight files and fast-forward the clean canonical checkout."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=60)
def clean(root):return not git(root,'status','--porcelain=v1','--untracked-files=all')
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment

def observation(root):
 return dict(head=git(root,'rev-parse','HEAD').decode().strip(),status=git(root,'status','--porcelain=v1','--untracked-files=all').decode(),branch=git(root,'rev-parse','--abbrev-ref','HEAD').decode().strip())

def git_admission(root):
 r=subprocess.run(['git','config','--type=bool','--get','commit.gpgsign'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 assert r.returncode in [0,1]and not r.stderr
 signing=r.stdout.decode().strip();assert signing in ['', 'false'],'unexpected signing requires separate review'
 directory=Path(git(root,'rev-parse','--path-format=absolute','--git-path','hooks').decode().strip())
 hooks={p.name:dict(sha256=sha(p),executable=os.access(p,os.X_OK))for p in sorted(directory.iterdir())if p.is_file()}if directory.exists()else{}
 assert not[n for n,d in hooks.items()if not n.endswith('.sample')and d['executable']],'active Git hook requires review'
 return dict(signing=signing,hooks_directory=str(directory),hooks=hooks)

def mutation(root,name,argv,result):
 out=W/'commit-logs'/name;out.mkdir(parents=True);record=dict(argv=argv,cwd=str(root),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=None);result['mutations'].append(record);start=time.monotonic()
 try:
  with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:
   r=run_child(argv,cwd=str(root),env=child_environment(False),stdout=stdout,stderr=stderr,timeout=120,log_limit_bytes=1<<20)
  record['exit_code']=r.returncode;assert r.returncode==0,'Git mutation failed'
 except BaseException as e:
  record['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  record['elapsed_seconds']=time.monotonic()-start;record['logs']={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']if(out/n).exists()}
  record['canonical_observed']=observation(C);record['candidate_observed']=observation(T)

def main():
 result=dict(result='INCOMPLETE',producer_sha256=sha(__file__),mutations=[],error=None)
 try:
  result['before']=dict(candidate=observation(T),canonical=observation(C))
  admission=dict(candidate=git_admission(T),canonical=git_admission(C));result['git_admission']=admission
  b=json.loads((W/'final-binding.json').read_bytes());r=json.loads((W/'final-review.json').read_bytes())
  assert r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
  assert git(T,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/macos-native-results'
  assert git(C,'rev-parse','--abbrev-ref','HEAD').decode().strip()=='codex/foundation-completion'
  assert git(T,'rev-parse','HEAD').decode().strip()==b['base_commit']==git(C,'rev-parse','HEAD').decode().strip()
  assert clean(C)and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
  assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources'])
  assert all(sha(T/p)==h for p,h in b['sources'].items())
  diff=git(T,'diff','--cached','--binary');assert len(diff)==b['staged_diff_bytes']and hashlib.sha256(diff).hexdigest()==b['staged_diff_sha256']==sha(W/'final-staged.diff')
  spec=importlib.util.spec_from_file_location('finalbuild',W/'build-final-pending.py');build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
  source=json.loads(Path('/private/tmp/vellum-pending-native-final/native-build/source.json').read_bytes())
  assert build.prepared()==source['prepared']
  for p,h in source['source']['files'].items():assert sha(T/p)==h
  message=W/'source-commit-message.txt';message.write_text('Preserve native accessibility state on pending publications\n\nProve pending-only changes against a detached wire baseline, preflight every native scope, and keep full JSON fallback. Preserve object identity while pruning ancillary geometry caches identically to full publication; disable reuse permanently after epoch exhaustion.\n\nAdd differential native state/lifecycle and bounded-baseline regressions. Verified affected-package offscreen race, module vet, native AX/grid and matched grid sanity runs. One Prism Anthropic Sonnet 5.5 review plus independent internal correction/result review; performance qualification remains open.\n')
  assert git_admission(T)==admission['candidate']and git_admission(C)==admission['canonical']
  mutation(T,'commit',['git','commit','--file',str(message)],result)
  commit=git(T,'rev-parse','HEAD').decode().strip();assert git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit']and clean(T)
  assert set(git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources'])
  assert clean(C)and git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']
  assert git_admission(C)==admission['canonical']
  mutation(C,'fast-forward',['git','merge','--ff-only',commit],result)
  assert clean(C)and git(C,'rev-parse','HEAD').decode().strip()==commit
  files=git(T,'ls-files','-z').decode().rstrip('\0').split('\0');assert len(files)==b['source_files']
  assert all(sha(T/p)==sha(C/p)for p in files)
  for p,h in source['prepared'].items():assert sha(C/'drivers/cogent/build'/p)==h
  result.update(result='REVIEWED_SOURCE_COMMITTED_AND_INTEGRATED',source_commit=commit,parent=b['base_commit'],canonical_promoted=True,both_clean=True,source_files=len(files),prepared_files=len(source['prepared']),binding_sha256=sha(W/'final-binding.json'),review_sha256=sha(W/'final-review.json'),producer_sha256=sha(__file__),runtime_binaries_relabelled=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except BaseException as e:
  result['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  for label,root in [('canonical',C),('candidate',T)]:
   try:result[label+'_terminal_observation']=observation(root)
   except BaseException as e:result[label+'_observation_error']=dict(type=type(e).__name__,message=str(e))
  write(W/'commit-pending-receipt.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
