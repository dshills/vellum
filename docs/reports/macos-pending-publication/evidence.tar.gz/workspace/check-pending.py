"""Bounded local checks of the pending publication candidate, without native UI."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-pending-native-work')
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
def source():
 names=git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')[:-1]
 return dict(commit=git('rev-parse','HEAD').decode().strip(),status=git('status','--porcelain').decode(),files={n:sha(T/n)for n in sorted(set(names))if(T/n).is_file()})
def main():
 name=sys.argv[1]; selected=name.removesuffix('-v2'); commands={
 'focused':['go','test','-race','-p=1','-count=1','-tags=offscreen','-run','TestAccessibilityPending|TestNativeAccessibilityPending','./...'],
 'full':['go','test','-race','-p=1','-count=1','-tags=offscreen','./...'],
 'vet':['go','vet','-p=1','-tags=offscreen','./...'],
 'build':['go','build','-p=1','-trimpath','-o',str(P/'loadedgrid'),'.']}
 assert selected in commands
 out=P/name;out.mkdir();before=source();(out/'source.json').write_text(json.dumps(before,indent=2)+'\n')
 argv=commands[selected];cwd=T/('examples/loadedgrid'if selected=='build'else'drivers/cogent')
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
 d=dict(argv=argv,cwd=str(cwd),source_sha256=sha(out/'source.json'),producer_sha256=sha(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False);start=time.monotonic()
 with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:r=run_child(argv,cwd=str(cwd),env=env,stdout=stdout,stderr=stderr,timeout=600,log_limit_bytes=8<<20)
 d.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_stable=source()==before,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['stdout','stderr']})
 (out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert d['exit_code']==0 and d['source_stable']
if __name__=='__main__':main()
