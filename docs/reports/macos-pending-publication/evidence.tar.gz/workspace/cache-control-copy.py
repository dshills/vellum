"""Compile the native mutant in an owned module copy; original sources stay frozen."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-pending-native-final/cache-control-copy');P.mkdir(mode=0o700)
spec=importlib.util.spec_from_file_location('pending_checks',W/'check-pending.py');checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(checks)
before=checks.source();module=P/'module';module.mkdir();prefix='drivers/cogent/';copied={}
for name in before['files']:
 if not name.startswith(prefix)or name.startswith(prefix+'build/'):continue
 rel=name.removeprefix(prefix);target=module/rel;target.parent.mkdir(parents=True,exist_ok=True);data=(T/name).read_bytes();target.write_bytes(data);copied[rel]=hashlib.sha256(data).hexdigest()
(P/'copied-source.json').write_text(json.dumps(copied,indent=2)+'\n')
mutant=module/'accessibility_darwin.m';text=mutant.read_text();needle=' vellumAXPruneGeometry(state,state.elements);\n';assert text.count(needle)==1;mutant.write_text(text.replace(needle,''))
mod=module/'go.mod';text=mod.read_text()
for old,new in [('=> ../..','=> '+str(T)),('=> ./build/upstream','=> '+str(T/'drivers/cogent/build/upstream')),('=> ./build/typesetting','=> '+str(T/'drivers/cogent/build/typesetting'))]:assert text.count(old)==1;text=text.replace(old,new)
mod.write_text(text);changed={n:checks.sha(module/n)for n,h in copied.items()if checks.sha(module/n)!=h};assert set(changed)=={'go.mod','accessibility_darwin.m'}
argv=['go','test','-race','-p=1','-count=1','-tags=offscreen','-run','^TestNativeAccessibilityPendingPrunesAncillaryCachesLikeFull$','.'];env={**checks.child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};start=time.monotonic()
with(P/'stdout').open('xb')as out,(P/'stderr').open('xb')as err:r=checks.run_child(argv,cwd=str(module),env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=8<<20)
success=r.returncode==1 and b'ancillary state differs at step'in(P/'stdout').read_bytes()and before==checks.source()
d=dict(expected_failure_observed=success,exit_code=r.returncode,argv=argv,cwd=str(module),source_stable=before==checks.source(),original_sha256=checks.sha(T/'drivers/cogent/accessibility_darwin.m'),mutant_sha256=checks.sha(mutant),copied_files=len(copied),copied_source_sha256=checks.sha(P/'copied-source.json'),module_changes=changed,producer_sha256=checks.sha(__file__),elapsed_seconds=time.monotonic()-start,native_ui_runtime_executed=False,logs={n:checks.sha(P/n)for n in ['stdout','stderr']});(P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert success
