"""Compile native fixtures from the exact candidate; this never launches UI."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-pending-native-hardened');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
spec=importlib.util.spec_from_file_location('pending_checks',W/'check-pending.py');checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(checks)
sha=checks.sha
def prepared():
 out={}
 for directory in ['upstream','typesetting']:
  for p in(T/'drivers/cogent/build'/directory).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():out[p.relative_to(T/'drivers/cogent/build').as_posix()]=sha(p)
 return out
def identity():return dict(source=checks.source(),prepared=prepared())
def main():
 before=identity();base=json.loads(Path('/private/tmp/vellum-native-grid-stacks-c5045bc/source.json').read_bytes());assert before['prepared']==base['prepared']
 out=P/'native-build';out.mkdir();(out/'source.json').write_text(json.dumps(before,indent=2)+'\n')
 env={**checks.child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
 results={}
 for name,cwd in [('loadedgrid',T/'examples/loadedgrid'),('ax',T/'drivers/cogent/cmd/accessibility-smoke')]:
  exe=out/name;argv=['go','build','-p=1','-trimpath','-o',str(exe),'.'];start=time.monotonic()
  with(out/(name+'.stdout')).open('xb')as stdout,(out/(name+'.stderr')).open('xb')as stderr:r=checks.run_child(argv,cwd=str(cwd),env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20)
  assert r.returncode==0
  m=checks.run_child(['go','version','-m',str(exe)],env=env,capture_output=True,timeout=20);assert m.returncode==0 and not m.stderr
  (out/(name+'.metadata')).write_bytes(m.stdout);text=m.stdout.decode();assert 'vcs.revision='+base['commit']in text and 'vcs.modified=true'in text and 'CGO_ENABLED=1'in text
  results[name]=dict(argv=argv,cwd=str(cwd),exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,binary=dict(path=str(exe),bytes=exe.stat().st_size,sha256=sha(exe)),metadata_sha256=sha(out/(name+'.metadata')),logs={k:dict(bytes=(out/(name+'.'+k)).stat().st_size,sha256=sha(out/(name+'.'+k)))for k in ['stdout','stderr']})
 d=dict(source_sha256=sha(out/'source.json'),producer_sha256=sha(__file__),source_stable=identity()==before,native_runtime_executed=False,base_commit=base['commit'],uncommitted_candidate=True,binaries=results,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(source_stable=d['source_stable'],source_sha256=d['source_sha256'],binaries={k:v['binary']['sha256']for k,v in results.items()})));assert d['source_stable']
if __name__=='__main__':main()
