"""Native compiler overlay proves ancillary-cache parity is discriminating."""
from pathlib import Path
import importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-pending-native-final/cache-control')
spec=importlib.util.spec_from_file_location('pending_checks',W/'check-pending.py');checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(checks)
P.mkdir(mode=0o700);original=T/'drivers/cogent/accessibility_darwin.m';text=original.read_text();needle=' vellumAXPruneGeometry(state,state.elements);\n';assert text.count(needle)==1
mutant=P/'accessibility_darwin.m';mutant.write_text(text.replace(needle,''));overlay=P/'overlay.json';overlay.write_text(json.dumps({'Replace':{str(original):str(mutant)}})+'\n');before=checks.source()
argv=['go','test','-race','-p=1','-count=1','-tags=offscreen','-overlay='+str(overlay),'-run','^TestNativeAccessibilityPendingPrunesAncillaryCachesLikeFull$','.'];env={**checks.child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};start=time.monotonic()
with(P/'stdout').open('xb')as out,(P/'stderr').open('xb')as err:r=checks.run_child(argv,cwd=str(T/'drivers/cogent'),env=env,stdout=out,stderr=err,timeout=240,log_limit_bytes=8<<20)
success=r.returncode==1 and b'ancillary state differs at step'in(P/'stdout').read_bytes()and before==checks.source()
d=dict(expected_failure_observed=success,exit_code=r.returncode,argv=argv,source_stable=before==checks.source(),original_sha256=checks.sha(original),mutant_sha256=checks.sha(mutant),overlay_sha256=checks.sha(overlay),producer_sha256=checks.sha(__file__),elapsed_seconds=time.monotonic()-start,native_ui_runtime_executed=False,logs={n:checks.sha(P/n)for n in ['stdout','stderr']});(P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert success
