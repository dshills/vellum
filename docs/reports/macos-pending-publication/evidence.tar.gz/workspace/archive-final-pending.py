"""Seal all tested endpoints, controls, raw native evidence and one provider review."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent
P=Path('/private/tmp/vellum-pending-native-work')
H=Path('/private/tmp/vellum-pending-native-hardened')
F=Path('/private/tmp/vellum-pending-native-final')
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
items={}
def add(prefix,root,names):
 for name in names:items[prefix+name]=root/name
def checks(prefix,root,cases):
 for case in cases:add(prefix+case+'/',root/case,['source.json','stdout','stderr','receipt.json'])
def builds(prefix,root):
 add(prefix,root/'native-build',['source.json','receipt.json','loadedgrid.metadata','ax.metadata','loadedgrid.stdout','loadedgrid.stderr','ax.stdout','ax.stderr'])
def native(prefix,root,count):
 cases=sorted(p for p in(root/'native-runs').iterdir()if p.is_dir());assert len(cases)==count
 for case in cases:add(prefix+case.name+'/',case,['owned.json','receipt.json','stdout','stderr'])
add('workspace/',W,['check-pending.py','build-pending-native.py','run-pending-native.py','analyze-pending.py','proof-control.py','stage-pending.py','prism-pending.py','source-review-v1.json','pending-execution-review.json','pending-result-review.json','pending-native-analysis.json','pending-binding.json','pending-staged.diff','prism-disposition-v1.json','prism-disposition.json','final-review.json','check-hardening.py','build-hardened-native.py','run-hardened-native.py','analyze-hardened.py','hardened-source-review.json','hardened-execution-review.json','check-final-pending.py','build-final-pending.py','run-final-pending.py','analyze-final-pending.py','cache-control.py','cache-control-copy.py','cache-parity-source-review.json','cache-parity-execution-review.json','cache-parity-result-review.json','final-native-analysis.json','stage-final-pending.py','final-binding.json','final-staged.diff','commit-pending.py','commit-pending-v1-unexecuted.py','commit-pending-v2-unexecuted.py','commit-pending-receipt.json','archive-final-pending.py'])
for case in ['commit','fast-forward']:
 add('workspace/commit-logs/'+case+'/',W/'commit-logs'/case,['stdout','stderr'])
add('workspace/shared-native-producer/',W,['build.py','run.py'])
add('clean-baseline-build/',Path('/private/tmp/vellum-native-grid-stacks-c5045bc'),['build.json','source.json','go-version.txt','build.stdout','build.stderr'])
add('repository/scripts/',T/'scripts',['child_process.py','sdk_environment.py','benchmark-grid.py'])
add('repository/examples/loadedgrid/',T/'examples/loadedgrid',['perf_runtime.go'])
add('shared/',Path('/private/tmp/vellum-empty-text-native-isolated-v2'),['live_lease.py'])
add('workspace/prism-pending/',W/'prism-pending',['payload.diff','rules.json','prism.json','receipt.json','stdout','stderr'])
checks('pre-hardening-checks/',P,['focused','full','full-v2','vet'])
add('pre-hardening-checks/proof-control/',P/'proof-control',['pending.go','overlay.json','stdout','stderr','receipt.json'])
builds('pre-hardening-checks/native-build/',P);native('pre-hardening-native/',P,22)
checks('latch-only-checks/',H,['package','vet']);builds('latch-only-checks/native-build/',H)
assert not(H/'native-runs').exists(),'denied endpoint must stay unlaunched'
checks('final-checks/',F,['package','vet']);builds('final-checks/native-build/',F);native('final-native/',F,6)
add('final-checks/failed-overlay-control/',F/'cache-control',['accessibility_darwin.m','overlay.json','receipt.json','stdout','stderr'])
add('final-checks/copied-module-control/',F/'cache-control-copy',['copied-source.json','receipt.json','stdout','stderr'])
add('final-checks/copied-module-control/module/',F/'cache-control-copy/module',['accessibility_darwin.m','go.mod'])
for binding_name,prefix,root in [('pending-binding.json','pre-hardening-source/',W/'pre-hardening-source'),('final-binding.json','source/',T)]:
 b=json.loads((W/binding_name).read_bytes())
 for name,expected in b['sources'].items():
  p=root/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected;items[prefix+name]=p
entries=[];raw=io.BytesIO()
with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as compressed:
 with tarfile.open(fileobj=compressed,mode='w')as archive:
  for name,path in sorted(items.items()):
   assert path.is_file()and not path.is_symlink(),str(path)
   data=path.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o600;entry.mtime=0;archive.addfile(entry,io.BytesIO(data));entries.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
data=raw.getvalue();(W/'pending-evidence.tar.gz').write_bytes(data)
manifest=dict(schema='vellum-pending-publication-evidence-v2',archive_sha256=hashlib.sha256(data).hexdigest(),archive_bytes=len(data),expanded_bytes=sum(e['bytes']for e in entries),entries=entries)
(W/'pending-evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items()if k!='entries'}|dict(entries=len(entries))))
