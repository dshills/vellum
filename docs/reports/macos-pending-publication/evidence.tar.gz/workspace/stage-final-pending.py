"""Bind only the final eight source/spec files after final native retirement."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');H=Path('/private/tmp/vellum-pending-native-final')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
old=json.loads((W/'pending-binding.json').read_bytes());review=json.loads((W/'cache-parity-source-review.json').read_bytes());assert review['source_ready']and not review['unresolved_findings']
spec=importlib.util.spec_from_file_location('hardened_build',W/'build-final-pending.py');build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
assert build.identity()==json.loads((H/'native-build/source.json').read_bytes())
analysis=json.loads((W/'final-native-analysis.json').read_bytes());assert len(analysis['cases'])==6 and analysis['ordinary_samples']==480
assert git('rev-parse','HEAD').decode().strip()==old['base_commit']
changed=set(git('diff','--name-only').decode().splitlines())|set(git('diff','--cached','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(old['sources'])
sources={p:sha(T/p)for p in old['sources']};subprocess.run(['git','diff','--check'],cwd=T,check=True);subprocess.run(['git','add','--',*sources],cwd=T,check=True);assert not git('diff','--name-only')
diff=git('diff','--cached','--binary');(W/'final-staged.diff').write_bytes(diff)
b=dict(base_commit=old['base_commit'],sources=sources,staged_diff_sha256=hashlib.sha256(diff).hexdigest(),staged_diff_bytes=len(diff),provider_binding_sha256=sha(W/'pending-binding.json'),provider_raw_sha256=sha(W/'prism-pending/prism.json'),source_review_sha256=sha(W/'cache-parity-source-review.json'),final_native_analysis_sha256=sha(W/'final-native-analysis.json'),producer_sha256=sha(__file__),source_files=len(git('ls-files','-z').split(b'\0'))-1,prepared_files=6243)
(W/'final-binding.json').write_text(json.dumps(b,indent=2)+'\n');print(json.dumps({k:v for k,v in b.items()if k!='sources'}))
