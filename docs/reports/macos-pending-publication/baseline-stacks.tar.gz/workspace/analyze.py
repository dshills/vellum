"""Count disjoint inclusive main-thread stack observations, not CPU attribution."""
from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent
P=Path('/private/tmp/vellum-native-grid-stacks-c5045bc')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
groups={
 'update':lambda s:'__vellumAXUpdate_block_invoke_2 ' in s,
 'commit':lambda s:s.startswith('vellumAXCommitSnapshot '),
 'validate':lambda s:s.startswith('vellumAXValidatedNodes '),
 'json_reader':lambda s:s.startswith('-[_NSJSONReader parseData:options:error:] '),
 'mach_port_wait':lambda s:s.startswith('__CFRunLoopServiceMachPort '),
}
results=[]
for case in ['cpu','gpu']:
 p=P/case/'native-stacks.txt';lines=p.read_text().splitlines();begin=lines.index('Call graph:')+1
 first=next(i for i in range(begin,len(lines))if re.match(r'^    \d+ Thread_',lines[i]))
 end=next(i for i in range(first+1,len(lines))if re.match(r'^    \d+ Thread_',lines[i]))
 need=re.match(r'^    (\d+) Thread_.*Main Thread',lines[first]);assert need
 total=int(need[1]);counts={k:0 for k in groups};stack=[];matches={k:[]for k in groups}
 for i in range(first+1,end):
  m=re.match(r'^([ +!:\|]*)(\d+) (.*)$',lines[i])
  if not m:continue
  col=len(m[1]);n=int(m[2]);symbol=m[3]
  while stack and stack[-1][0]>=col:stack.pop()
  for key,predicate in groups.items():
   if predicate(symbol)and not any(predicate(ancestor[1])for ancestor in stack):
    counts[key]+=n;matches[key].append(dict(line=i+1,count=n,symbol=symbol))
  stack.append((col,symbol))
 assert all(0<=n<=total for n in counts.values())
 assert counts['validate']<=counts['commit']<=counts['update'] and counts['json_reader']<=counts['update']
 results.append(dict(case=case,profile_sha256=sha(p),main_thread_observations=total,inclusive_disjoint_counts=counts,match_lines=matches,
  interpretation='Counts for each category include descendants once; categories overlap. Native wall-stack observations are not CPU percentages, elapsed function timings or ordinary performance acceptance.'))
out=dict(schema='vellum-native-grid-stack-analysis-v1',analyzer_sha256=sha(__file__),cases=results)
(W/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:r[k]for k in ['case','main_thread_observations','inclusive_disjoint_counts']}for r in results]))
