"""Preserve unchanged-source wall-stack evidence without executables."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-native-grid-stacks-c5045bc');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
items={}
for name in ['build.py','run.py','validate.py','analyze.py','archive-stacks.py','readiness.json','cpu-validation.json','gpu-validation.json','analysis.json','design-review.json','result-review.json']:items['workspace/'+name]=W/name
for name in ['build.json','source.json','go-version.txt','build.stdout','build.stderr']:items['native/'+name]=P/name
for case in ['cpu','gpu']:
 for name in ['receipt.json','owned-native.json','owned-sampler.json','native.stdout','native.stderr','sample.stdout','sample.stderr','native-stacks.txt']:items['native/'+case+'/'+name]=P/case/name
for name in ['scripts/benchmark-grid.py','scripts/child_process.py','scripts/sdk_environment.py','examples/loadedgrid/perf_runtime.go']:items['repository/'+name]=T/name
items['shared/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
entries=[];raw=io.BytesIO()
with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as compressed:
 with tarfile.open(fileobj=compressed,mode='w')as archive:
  for name,path in sorted(items.items()):
   assert path.is_file()and not path.is_symlink();data=path.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o600;entry.mtime=0;archive.addfile(entry,io.BytesIO(data));entries.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
data=raw.getvalue();archive_path=W/'baseline-stack-evidence.tar.gz';archive_path.write_bytes(data)
manifest=dict(schema='vellum-native-stack-evidence-v1',archive_sha256=hashlib.sha256(data).hexdigest(),archive_bytes=len(data),expanded_bytes=sum(e['bytes']for e in entries),entries=entries)
(W/'baseline-stack-evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items()if k!='entries'}|dict(entries=len(entries))))
