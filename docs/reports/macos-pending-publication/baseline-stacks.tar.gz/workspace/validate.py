"""Read-only checks of owned stack diagnostics; never qualifies ordinary timing."""
from pathlib import Path
import hashlib, importlib.util, json, re, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = Path('/private/tmp/vellum-native-grid-stacks-c5045bc')
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
spec = importlib.util.spec_from_file_location('benchmark_grid', T/'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)
def need(ok, message):
    if not ok: raise ValueError(message)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def validate(case):
    out = P/case
    receipt = json.loads((out/'receipt.json').read_bytes())
    need(receipt['result'] == 'COMPLETED_STACK_DIAGNOSTIC', 'terminal result')
    need(receipt['error'] is None and not receipt['cleanup_errors'], 'run errors')
    need(all(receipt[k] is True for k in ['source_stable', 'pins_stable', 'native_logs_complete', 'lease_held_through_cleanup']), 'run controls')
    need(receipt['stop_marker_at_exit'] is False, 'stop marker')
    for role in ['native', 'sampler']:
        child = receipt[role]
        need(child['created'] and child['terminal'] and child['group_absent'] and child['exit_code'] == 0, 'child retirement')
        need(child['group'] == child['pid'] == child['group_observation']['group'] and child['group_observation']['members'] == [], 'group observation')
    need(receipt['sampler_argv'] == ['/usr/bin/sample', str(receipt['native']['pid']), '8', '1', '-mayDie', '-file', str(out/'native-stacks.txt')], 'exact sampler target')
    for name, item in {**receipt['logs'], 'native-stacks.txt': receipt['profile']}.items():
        need((out/name).stat().st_size == item['bytes'] and sha(out/name) == item['sha256'], 'output digest: '+name)
    profile = (out/'native-stacks.txt').read_text()
    match = re.search(r'^Process:\s+loadedgrid \[(\d+)\]$', profile, re.M)
    need(match and int(match[1]) == receipt['native']['pid'], 'profile process identity')
    records = [json.loads(line) for line in (out/'native.stdout').read_bytes().splitlines()]
    samples = benchmark.validate_records(records, 1_000_000, False, 1024, False, gpu_scene_rendering=case=='gpu')
    need(records[0].get('geometry_persistence_disabled_in_fixture') is True, 'fixture persistence disabled')
    need(records[1]['warmup'] == 128, 'warmup identity')
    need(samples[0] == receipt['trigger'], 'sampler launch trigger')
    result = dict(case=case, valid=True, scope='external native wall-stack diagnostic; ordinary performance qualification excluded',
                  receipt_sha256=sha(out/'receipt.json'), profile_sha256=sha(out/'native-stacks.txt'), validator_sha256=sha(__file__),
                  benchmark_validator_sha256=sha(T/'scripts/benchmark-grid.py'), native_pid=receipt['native']['pid'], sampler_pid=receipt['sampler']['pid'],
                  records=len(records), samples=len(samples), warmup=128, geometry_and_raw_phases_validated=True,
                  native_and_sampler_retired=True, physical_input_verified=False, gpu_execution_verified=False,
                  diagnostic_timing_ms=benchmark.summarize([samples]))
    return result, samples
if __name__ == '__main__':
    need(len(sys.argv)==2 and sys.argv[1] in ['cpu', 'gpu', 'both'], 'fixed case')
    chosen = ['cpu', 'gpu'] if sys.argv[1]=='both' else [sys.argv[1]]
    outputs = [validate(case) for case in chosen]
    if len(outputs)==2: benchmark.compare_geometry(outputs[0][1], outputs[1][1])
    for result, _ in outputs:
        path = W/(result['case']+'-validation.json')
        path.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps({k:result[k] for k in ['case', 'valid', 'records', 'samples', 'profile_sha256']}))
