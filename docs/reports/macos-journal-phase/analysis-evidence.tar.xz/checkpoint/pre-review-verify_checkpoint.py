from pathlib import Path
import ast,sys,json,hashlib,subprocess
x=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');code=r/'tools/macos-calibration/displayclock';final=x/'analysis-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(code/n):sha(code/n) for n in ['phase_analysis.py','phase_test.py']}
for p in source:ast.parse(Path(p).read_text())
args=[sys.executable,'-B',str(code/'phase_analysis.py'),'--reports','docs/reports','--output',str(x/'reproduction')]
run=subprocess.run(args,cwd=r,capture_output=True,timeout=15)
(x/'reproduction.stdout').write_bytes(run.stdout);(x/'reproduction.stderr').write_bytes(run.stderr);assert run.returncode==0 and not run.stderr
for name in ['summary.json','rows.json']:assert (final/name).read_bytes()==(x/'reproduction'/name).read_bytes()
refusal=subprocess.run(args,cwd=r,capture_output=True,timeout=15)
(x/'overwrite-refusal.stdout').write_bytes(refusal.stdout);(x/'overwrite-refusal.stderr').write_bytes(refusal.stderr);assert refusal.returncode!=0 and b'FileExistsError' in refusal.stderr
for name in ['summary.json','rows.json']:assert (final/name).read_bytes()==(x/'reproduction'/name).read_bytes()
assert all(sha(Path(p))==h for p,h in source.items())
rows=json.loads((final/'rows.json').read_text());assert len(rows)==4 and all(len(rs)==248 for rs in rows.values())
assert sum(sum(r['phase']=='measured' for r in rs) for rs in rows.values())==480
s=json.loads((final/'summary.json').read_text());assert [p['order'] for p in s['pairs']]==[['off','on'],['on','off']]
checks={'result':'PASS','focused_unit_methods':7,'syntax':True,'four_raw_journals_reclassified':True,'original_classifier_files_per_pair':8,'pinned_archives':4,'joined_inputs':992,'measured_inputs':480,'warmup_inputs':512,'byte_identical_reproduction':{n:sha(final/n) for n in ['summary.json','rows.json']},'existing_output_refused_without_mutation':True,'source_sha256':source,'native_executions':0,'no_SDK_app_framework_rebuild':True,'release_gate_changed':False,'scope':'Offscreen only; prior native/SDK qualification evidence reused as retained, no new physical/cadence/resize/ordinary qualification.'}
(x/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
