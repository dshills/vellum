from pathlib import Path
import hashlib,io,json,tarfile
x=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-journal-phase';files={}
def add(name,path):
    assert name not in files and path.is_file()
    files[name]=path
for name in ['summary.json','rows.json']:add('analysis/'+name,x/'verification-v2/analysis'/name)
for p in (x/'verification-v2').iterdir():
    if p.is_file():add('verification/'+p.name,p)
for name in ['internal-review.json','archive-inventory.json','review-completion.json',
             'pre-review-checks.json','pre-review-verify_checkpoint.py',
             'pre-review-phase_analysis.py.txt','verify_checkpoint.py','review_checkpoint.py',
             'review_followup.py','retain.py','write_report.py']:
    add('checkpoint/'+name,x/name)
for folder in ['result-review','followup-review']:
    for p in (x/'prepared'/folder).rglob('*'):
        if p.is_file() and 'tmp' not in p.relative_to(x/'prepared').parts:
            add('reviews/'+p.relative_to(x/'prepared').as_posix(),p)
for name in ['phase_analysis.py','phase_test.py','PHASE.md']:
    add('source/'+name,r/'tools/macos-calibration/displayclock'/name)
for name in ['README.md','checks.json','review-completion.json','archive-inventory.json']:
    add('report/'+name,d/name)
add('report/macos-release-assessment.md',r/'specs/macos-release-assessment.md')
archive=x/'analysis-evidence.tar.xz';index={}
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for name,p in sorted(files.items()):
        data=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644
        member.mtime=member.uid=member.gid=0;member.uname=member.gname='';tar.addfile(member,io.BytesIO(data))
        index[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as tar:
    assert tar.getnames()==sorted(index)
    for member in tar:
        data=tar.extractfile(member).read();assert len(data)==index[member.name]['bytes'] and hashlib.sha256(data).hexdigest()==index[member.name]['sha256']
result={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':index,
        'scope':'Offscreen derived data, exact source/verification/review records only. Original four immutable input archives remain in their prior committed reports. No executable, native library, SDK, cache or credential included.'}
(x/'analysis-evidence-index.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'members':len(index),'bytes':archive.stat().st_size,'sha256':result['archive_sha256']}))
