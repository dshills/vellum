from pathlib import Path
import json,shutil
x=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-journal-phase';d.mkdir(exist_ok=True);(d/'execution-sources').mkdir(exist_ok=True)
s=json.loads((x/'analysis-final/summary.json').read_text());pairs=s['pairs'];cases=[(p['pair'],c) for p in pairs for c in p['cases']];table=[]
for name,c in cases:
 t=c['p95_rank_ticket'];split=t['present_gpu_split_ms'];label='Earlier' if name.endswith('scheduling') else 'Reversed'
 table.append(f"| {label} / {c['mode']} | {t['accepted_revision']} | {t['receipt_to_shown_ms']:.3f} | {split['receipt_to_present_gpu_end']:.3f} | {split['present_gpu_end_to_shown']:.3f} | {c['p95_ticket_post_present_gpu_fraction_pct']:.1f}% |")
on=[c for _,c in cases if c['mode']=='on'];pending=[]
for event in ['receipt','raster_end','upload_end','first_submit','present_request','present_gpu_end']:
 pending.append('| '+event+' | '+' | '.join(str(c['display_clock_phase'][event]['preceding_reported_callback_not_yet_delivered'])+'/120' for c in on)+' |')
text=f'''# Offscreen timing-journal phase analysis

The remaining interval is still mostly after the recorded final present GPU end.
On the actual p95 input of each retained run, that interval is **81–92%** of
receipt-to-shown latency. Neither observer presence nor a reported display
timestamp establishes the cause. This analysis adopts no production change.

## Same-input attribution

Each row below identifies that run's actual p95-ranked measured input. The last
two duration columns partition that individual input exactly. They are not
independently selected phase percentiles. Times are milliseconds.

| Run / observer | Accepted revision | Receipt to shown | Before final present GPU end | Final present GPU end to shown | Post-GPU fraction |
| --- | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(table)}

Every input also has a disjoint five-part partition: receipt to acquire,
acquire to first render submission, submission to first render GPU start,
render GPU span and render GPU end to shown. All 992 partitions close within
the inherited one-microsecond tolerance. Render GPU spans on these four ranked
inputs are 0.253–0.321 ms. The pre-final-GPU intervals include CPU work, waiting,
submission and GPU work; they are not a pure CPU metric. Go request lateness and
clock-read brackets are retained separately, without inventing a native-clock
scheduled target or adding them to the receipt partition.

The new receipt-to-shown quantiles exactly reproduce the complete original
validators. Earlier off/on p95 stays 51.101/33.947 ms; reversed on/off stays
37.882/37.923 ms. All four exceed the unchanged 33.3 ms gate. Phase percentile
summaries are descriptive marginal distributions and must not be added together
or used to decompose differences between runs' p95 values. Separate processes
and pairs are never pooled or joined by absolute timestamp.

## A reported clock is not a delivered callback

For each event in each on run, the analyzer independently brackets the event in
reported timestamps and callback observations. Equality belongs to the last
preceding event; duplicate observation times use the last equal observation.
No fitted lattice or assumed refresh cadence is used. All 248 inputs per case,
including warmup, remain in the derived rows; summaries use the fixed 120 measured
inputs. Off runs have no display-clock joins or inferred clocks from another run.

The following counts show when the callback associated with the **preceding
reported timestamp** had not yet been observed at the named event:

| Event | Earlier on | Reversed on |
| --- | ---: | ---: |
{chr(10).join(pending)}

These are recorded callback observations, sampled in the native callback. They
must not be treated as application scheduling opportunities already delivered
at the reported timestamp. The preceding reported callback may still be pending
while an older callback has already arrived. Late callback records are retained.

The nearest reported timestamp to actual shown feedback also has its own
callback observation. That observation occurs after shown by p95 **10.912 ms**
in the earlier on run and **16.340 ms** in the reversed on run. This is a recorded
clock relation, not measured physical display latency or callback processing cost.
In the earlier on run, reported timestamps in (final-present GPU end, shown]
have histogram {{0:13, 1:107}}, while actual callback observations in that same
interval have histogram {{1:62, 2:58}}. Reversed on gives reported
{{0:9, 1:110, 2:1}} versus delivered {{1:12, 2:108}}. These count different event
series; neither is a missed-vsync count, guaranteed latch count or optical proof.

## Conclusion and next bounded control

The earlier one-refresh observer advantage did not reproduce when order was
reversed. Callback delivery phase also differs across the two on runs. The data
therefore does not justify adopting a permanent display link, making a pacing
change or calling the observer neutral. The post-GPU interval remains the main
lead, but it includes unisolated presentation/scheduling work; no compositor-only,
driver-only or WebGPU-specific cause follows.

A future presentation control should match request phase and record pending
presentation/drawable state before any scheduling-policy change. It must keep
reported timestamps separate from observed callback delivery, retain complete
accounting and compare actual same-input GPU readiness with shown feedback.
This checkpoint does not prepare or authorize another native run, or change a
release criterion. M3–M7 remain open. Cadence, resize, physical input, displayed
pixels, observer overhead and ordinary-build equivalence are not qualified here.

## Verification and reproduction

Seven focused unit methods cover late versus delivered callbacks, exact timestamp
and delivery equality, duplicate observations, missing coverage, nonfinite/order
rejection, same-input closure and overlapping present request, actual rank-ticket
identity, absence of off-mode clock inference, classifier-source drift and archive
integrity failures. All four raw journals are independently reclassified with
the original eight validator/script sources pinned to the original runs. Stored
validations match exactly, with 992 joined inputs: 512 warmup and 480 measured.

All four original archives verify by fixed SHA256. Selected members verify their
indexed bytes/hash; no archive is extracted and no executable is loaded. An
independent fresh analysis produces byte-identical summary and complete row files;
existing output is refused without mutation. No native execution, rebuild, screen
use, system-setting change or SDK/app modification occurs. Prior native and SDK
checks remain the retained evidence; they were not rerun for this pure analysis.

From the repository root, with a fresh output directory:

```sh
python3 -B -m unittest discover -s tools/macos-calibration/displayclock -p phase_test.py -v
python3 -B tools/macos-calibration/displayclock/phase_analysis.py \\
  --reports docs/reports --output /tmp/vellum-journal-phase
```

The [summary](summary.json), [checks](checks.json),
[analysis contract](../../../tools/macos-calibration/displayclock/PHASE.md),
indexed analysis evidence and the original [off/on](../macos-display-scheduling/README.md)
and [on/off](../macos-display-reversed/README.md) checkpoints retain the basis.
Internal review passes; Prism with Anthropic Claude Sonnet 5.5 reviews this
checkpoint before commit. Features, original backend, rendering/pacing defaults,
SDK/app and the 33.3 ms release gate stay unchanged.
'''
(d/'README.md').write_text(text)
for name,src in [('summary.json',x/'analysis-final/summary.json'),('checks.json',x/'checks.json')]:shutil.copyfile(src,d/name)
shutil.copyfile(x/'verify_checkpoint.py',d/'execution-sources/verify_checkpoint.py.txt')
p=r/'specs/macos-release-assessment.md';p.write_text(p.read_text()+'''
The [offscreen journal phase analysis](../docs/reports/macos-journal-phase/README.md)
reclassifies all four immutable journals through the original pinned validators:
992 joins, 512 warmup and 480 measured, without native execution or rebuilding.
Seven focused methods and byte-identical independent reproduction pass. Actual
p95 inputs retain 81–92% of latency after final-present GPU end. Reported timestamp
and callback observation are independent event series: the preceding reported
callback is still pending at 118/120 reversed-on receipts. Earlier on versus
reversed on nearest-shown-timestamp callback observation lag has p95 10.912 versus
16.340 ms. These are descriptive clock relations, not optical/latch/causal proof.
No observer scheduling fix, ordinary qualification, feature/default/SDK/app/gate
change follows; M3–M7 open. Future controls should match request phase and record
pending presentation/drawable state before changing scheduling policy. No new
native scope is prepared or authorized by this offscreen checkpoint.
''')
(r/'tools/macos-calibration/displayclock/PHASE.md').write_text('''# Offscreen phase-analysis contract

Consume only the two sealed off/on and on/off report archives and their indexed
preparation match. Their four SHA256 values are fixed in `phase_analysis.py`.
Read selected regular members in memory, verifying the archive hash, index member
coverage, uniqueness and selected bytes/hash. Never extract or execute contents.
Reclassify every raw document through the complete unchanged display-clock parent
chain; require exact equality with both stored validations and case receipts.
Pin the eight validator/script files to original bound-plan source hashes.

Keep four runs separate, with 248 joins each: 128 warmup then 120 measured. Retain
all rows. For each input, partition receipt/acquire/first-render-submit/first-GPU/
last-render-GPU/shown; also retain the independent two-part final-present-GPU
split. Each closes to that same input's receipt latency within 1us. Present
request can overlap GPU execution and is not added to disjoint phase intervals.
Marginal quantiles must not be added. Select each actual p95 ticket by existing
nearest-rank receipt latency and accepted-revision tie break, checking its identity.
Keep Go lateness/brackets separate; no guessed Go/native target conversion.

For on cases only, bracket every native event independently in reported timestamp
and observed callback arrays. Preceding includes equality; following is strictly
later. Equal observation times resolve to the last equal callback. Require both
sides in both arrays, with no dropped input on coverage failure. Nearest reported
tick ties choose preceding. Preserve signed event-to-nearest timestamp and that
tick's actual observation delay. Count reported and observed events separately
in (final-present GPU end, shown]. Off cases get no inferred clock joins. No
cross-process timestamp matching, fitted clock lattice, pooling, overhead
calibration, optical/latch/missed-vsync proof or causal observer claim.

Pure Python/offscreen only; no screen, native launch, rebuild, setting, framework,
backend/default/SDK/app/feature or release-gate change. Output must be fresh and
must reproduce byte-identically. Focused tests, internal review and Prism using
Anthropic Claude Sonnet 5.5 precede commit. No live authority follows from analysis.
''')
(x/'internal-review.json').write_text(json.dumps({'result':'PASS','checks':['Four immutable archive pins; selected member identities; no executable loading or extraction','Eight classifier/script source pins match each original run; full raw reclassification equals both stored receipts','992same-input closures and actual rank identities; no marginal quantile sums','Reported and observed arrays independent; right-inclusive/equality/duplicates/future-nearest signed joins','No on-clock inference for off cases; no cross-process join or pooling','7focusedmethods plus complete integration/reproduction/refusedoverwrite; zero native runs','Conclusions limited to post-GPU remainder and callback-phase observations; original design/gate/features unchanged'],'unresolved_findings':[]},indent=2)+'\n')
