from pathlib import Path
import json,sys,hashlib,importlib.util
sys.dont_write_bytecode=True
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');code=r/'tools/macos-calibration/presentationphase';sys.path.insert(0,str(r/'scripts'));sys.path.insert(0,str(x.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('phase_build_owned',x.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();identity=json.loads((q/'reused-build-identity.json').read_text());pins=dict(identity['pins']);pins.update({str(p):sha(p) for root in [code,q/'consumer'] for p in root.rglob('*') if p.is_file()});pins.update({str(q/n):sha(q/n) for n in ['overlay.json','framework.mod','framework.sum','presentation_darwin.m','presentation_darwin.go','desktop_measurement.go','native.m','match.json']});case=sys.argv[1];base=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)'];cwd=q
if case=='failure-build':
 pins[str(q/'failure_prefix_test.m')]=sha(q/'failure_prefix_test.m');argv=base+['/usr/bin/clang','-fno-objc-arc','-mmacosx-version-min=14.0','-Wall','-Wextra','-Werror','-framework','Foundation','-framework','QuartzCore',str(q/'failure_prefix_test.m'),'-o',str(q/'failure-prefix-test')]
elif case=='failure':argv=base+[str(q/'failure-prefix-test')];pins[str(q/'failure-prefix-test')]=sha(q/'failure-prefix-test')
elif case=='fixture-build':argv=base+['/usr/bin/clang','-fno-objc-arc','-mmacosx-version-min=14.0','-Wall','-Wextra','-Werror','-framework','Foundation','-framework','QuartzCore',str(code/'control_test.m'),'-o',str(q/'control-test')]
elif case=='fixture':argv=base+[str(q/'control-test')];pins[str(q/'control-test')]=sha(q/'control-test')
elif case=='native-object':argv=base+['/usr/bin/clang','-c','-fno-objc-arc','-mmacosx-version-min=14.0','-Wall','-Wextra','-Werror','-I'+str(q/'consumer'),str(q/'consumer/display_clock_impl.m'),'-o',str(q/'display.o')]
elif case=='native-build':
 pins[str(q/'display.o')]=sha(q/'display.o');argv=base+['/usr/bin/clang','-O2','-fobjc-arc','-mmacosx-version-min=14.0','-Wall','-Wextra','-Werror','-I'+str(q/'consumer'),'-I'+str(r/'tools/macos-calibration'),'-framework','Cocoa','-framework','Metal','-framework','QuartzCore',str(q/'native.m'),str(r/'tools/macos-calibration/observe.m'),str(q/'consumer/control.m'),str(q/'display.o'),'-o',str(q/'native')]
elif case in ['framework-build','pixels']:
 cwd=q/'consumer';argv=base+['/bin/sh',str(x.parent/'macos-app-examples/go-check')]
 if case=='framework-build':argv+=['build','-modfile='+str(q/'framework.mod'),'-overlay='+str(q/'overlay.json'),'-ldflags=-buildid='+identity['native_archive_sha256'],'-o',str(q/'framework'),'.']
 else:
  overlay=json.loads((q/'overlay.json').read_text());overlay['Replace']={k:v for k,v in overlay['Replace'].items() if not k.endswith(('presentation_darwin.m','presentation_darwin.go'))};key=next(k for k in overlay['Replace'] if k.endswith('/desktop_measurement.go'));overlay['Replace'][key]=str(x.parent/'macos-display-scheduling/prepared/desktop_measurement.go');(q/'pixels-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n');argv+=['test','-tags=offscreen','-modfile='+str(q/'framework.mod'),'-overlay='+str(q/'pixels-overlay.json'),'-run','^TestRoutedStateAndExactPatchPixels$','-count=1','-v','.']
else:raise ValueError(case)
run=g.execute(argv,cwd,q/case,lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=180,limit=4<<20);(q/(case+'-receipt.json')).write_text(json.dumps({'pins':pins,'run':run},indent=2)+'\n');print(json.dumps({'case':case,**{k:run[k] for k in ['exit_code','error','seconds']}}));assert run['exit_code']==0 and run['error'] is None and run['owned']['group_absent'] and run['owned']['terminal']
