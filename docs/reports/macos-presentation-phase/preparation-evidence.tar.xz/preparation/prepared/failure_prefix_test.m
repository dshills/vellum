#import "/Users/dshills/Development/projects/Vellum/tools/macos-calibration/presentationphase/control.m"
#include <assert.h>
int main(void){@autoreleasepool{
 assert(pc_configure());uint64_t ids[PC_LIVE+1];
 for(int i=0;i<=PC_LIVE;i++){ids[i]=pc_acquire_begin(1,i,1,CACurrentMediaTime());pc_acquired(ids[i],i,CACurrentMediaTime());}
 assert(pc.invalid&&pc.overflow);int prefix=pc.count;
 for(int i=0;i<=PC_LIVE;i++)pc_presented(ids[i],CACurrentMediaTime());
 assert(pc.count==prefix);uint64_t pendingIds[PC_LIVE]={0};int acquiring=0;assert(pc_census(pendingIds,&acquiring)==0&&acquiring==0);
 char *raw=pc_snapshot();assert(raw);puts(raw);free(raw);
}return 0;}
