from pathlib import Path
import shutil,json
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-presentation-phase';d.mkdir();s=d/'execution-sources';s.mkdir()
for name,path in [('consumer-main.go.txt',q/'consumer/main_darwin.go'),('native.m.txt',q/'native.m'),('core-presentation.m.txt',q/'presentation_darwin.m'),('core-presentation.go.txt',q/'presentation_darwin.go'),('measured-input.go.txt',q/'desktop_measurement.go'),('display-observer.m.txt',q/'consumer/display_clock_impl.m'),('verify_preparation.py.txt',x/'verify_preparation.py')]:shutil.copyfile(path,s/name)
shutil.copyfile(q/'preparation-checks.json',d/'preparation-checks.json')
(d/'README.md').write_text('''# Phase-matched presentation control — preparation

This prepares one native-reference then framework pair with pending drawable
feedback state. **No native capture has started.** The existing design, features,
SDK/app, renderer defaults and33.3ms release gate remain unchanged; M3–M7 open.

The [protocol](../../../tools/macos-calibration/presentationphase/PLAN.md) fixes
four reported-period phases (1/8,3/8,5/8,7/8), an eight-callback anchor stride,
128warmups and120measured requests. Each phase has30measured inputs. Actual
native receipt error must be0..2ms; each phase's p50/p95 error must match within
1ms between implementations. A mismatch refuses the comparison without dropping
or replacing observations. Request spacing is diagnostic input scheduling;
renderer pacing remains unchanged. The approximate Go/native target bridge is
recorded separately and cannot substitute for actual native receipt matching.

Shared scalar hooks record every acquisition start, success/unavailability,
receipt and presented callback, with pending IDs and acquiring counts before
and after. Every transition is replayed. Exact receipt/acquisition/drawable/shown
joins preserve startup and all248cohort states. Native GPU/submit observations
are added without changing its command order; the framework keeps its full
source/raster/upload/backend observer chain. A pending record means acquired and
awaiting callback, not a claim about Metal pool availability, reference lifetime,
compositor queue depth or physical scanout. The receipt-hook census has its own
observation bracket; earlier event-time state is reconstructed separately.

The native reference still uses an internal AppKit event and cached-texture blit;
framework still routes the public command and normal view/paint/upload. That
algorithm/API difference and extra diagnostic overhead prevent interpreting
subtraction as pure framework overhead. Both view observers use the same source;
reported timestamp and actual delivered callback clocks remain separate.

[Focused checks](preparation-checks.json) pass: six classifier methods plus two
controller methods, including phase/lifecycle/parent-refusal and fail-first controls;
headless native bounds/lifecycle/JSON tests and four concurrent producers;
warning-free native reference/observer builds and private Go consumer build;
full routed pixels; exact recipe reproduction; source/log/process ownership
pins and all8,321SDK files. The Go build retains existing AppKit deprecation and
duplicate-objc link warnings. No Rust/native archive or SDK rebuild occurs.

Preparation inspection corrected the receipt hook to the actual measured-input
recorder path. An initial offscreen link failure is retained; native-only hook
overlays are excluded from the unchanged pixel fixture. Unused intermediate
preparations remain local and did not run a native application. The actual
consumer/core/measurement/observer snapshots are included for source review.

One approved quiet scope may run after tests, internal review, Prism using
Anthropic Claude Sonnet5.5 and commit: at most100seconds overall and40seconds
per process, native then framework, fixed80ms held tail, existing exclusive lease,
configuration/geometry and source/SDK guards. Stop first invalid, seal and retain;
no unchanged retry. Performance above33.3ms remains an observation. Results,
including rejection, require separate review and commit. No permanent link,
production scheduling change or release qualification follows.
''')
p=r/'specs/macos-release-assessment.md';p.write_text(p.read_text()+'''
The [phase-matched pending-state preparation](../docs/reports/macos-presentation-phase/README.md)
adds private native/framework consumers with four predeclared request phases,
30measured inputs per phase and complete scalar acquisition/receipt/callback
censuses. Actual native receipt matching is required before comparing latency;
recorded pending feedback does not establish Metal pool availability or ownership.
Eight focused methods, headless native concurrency/lifecycle/bounds/JSON, both
builds, full routed pixels, recipe/source/log/SDK checks pass. No native capture
yet. One approved100second overall/40second per-process scope may follow review
and commit. Existing design/features/defaults/SDK/app and33.3ms gate unchanged;
M3–M7 open. Actual results or rejection receive separate review and commit.
''')
(q/'internal-review.json').write_text(json.dumps({'result':'PASS','scope':'Preparation only; no native execution','checks':['Actual measured recorder receipt path hooked after exact clock read before FIFO; no general-window-path assumption','Shared scalar-only bounded mutex recorder; no native/Go refs; lifecycle/drain and actual callback observations','Native/Core acquisition clock shared exactly with old receipt journal; all startup retained','Four native-clock phase targets, exact sequence/stride/populations; actualreceipt matching independent of approximate Go bridge','Existing complete parent validators preserved; replay each event and exact drawable attribution','One native/framework order, failfirst/partialretention/seal; inherited Host admission/deadline/lease/owned retire reused unchanged','All focused controls/builds/pixels/recipe/source/logs/SDK8321 pass; no shipping feature/policy/library/gate change'],'unresolved_findings':[]},indent=2)+'\n')
