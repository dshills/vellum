from pathlib import Path
import hashlib,tarfile,io,json,sys
x=Path(__file__).resolve().parent;q=x/'prepared';mode=sys.argv[1]
if mode=='preparation':
 paths=[p for p in q.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts and '__pycache__' not in p.relative_to(q).parts and p.name not in ['framework','native','control-test','failure-prefix-test'] and not p.name.endswith(('.o','.tar.xz','evidence-index.json'))]
 paths += [p for p in (x/'initial-reviewed-sources').rglob('*') if p.is_file()]
 old=x/'prepared-unused-v3';paths += [p for p in old.rglob('*') if p.is_file() and ('pixels-rejected' in p.parts or p.name=='pixels-rejected-receipt.json') and 'tmp' not in p.parts]
 paths += [p for p in x.glob('*.py')]
else:
 names=['result.json','bound-plan.json','started.json','preparation-commit.json','result-summary.json','result-internal-review.json','result-review-completion.json','pair-validation.json','linked-source-audit.json','linked-acquire-method.txt','result-verification.stdout']
 paths=[q/n for n in names if (q/n).is_file()]+[p for name in ['native-case','framework-case','result-review','result-reviewed-docs'] for p in (q/name).rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts]
 paths += [p for p in x.glob('*result*.py')]+[x/'retain.py',x/'audit_linked.py']
archive=q/(mode+'-evidence.tar.xz');files={}
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in sorted(set(paths)):
  data=p.read_bytes();name=mode+'/'+p.relative_to(x).as_posix();member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=member.uid=member.gid=0;member.uname=member.gname='';tar.addfile(member,io.BytesIO(data));files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(archive,'r:xz') as tar:
 assert sorted(tar.getnames())==sorted(files) and len(tar.getnames())==len(files)
 for m in tar:
  b=tar.extractfile(m).read();assert len(b)==files[m.name]['bytes'] and hashlib.sha256(b).hexdigest()==files[m.name]['sha256']
index={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'scope':'Private diagnostic local checkpoint. Source, logs, reviews and actual input pins retained; no executable/object/native archive/SDK/cache/credential. Unused preparations remain local; initial reviewed sources and link failure included.'};(q/(mode+'-evidence-index.json')).write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'sha256':index['archive_sha256']}))
