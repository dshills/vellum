from pathlib import Path
import json,shutil
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-presentation-phase';s=json.loads((q/'result-summary.json').read_text());assert s['outcome']=='REJECT';native=s['cases'][0];assert native['validated'] and not s['cases'][1]['validated']
text=f'''# Phase-matched presentation control — first attempt rejected

The native reference completed and passed the strict phase/pending-state
classifier. The framework diagnostic then exited with **initial natural
presentation deadline**, before any routed input. **No matched pair exists.**
The complete attempt is retained and sealed; no unchanged retry occurred.

Native retains128warmup and120measured joins, with30measured inputs in each
predeclared phase. Its receipt-to-shown p95 is **{native['receipt_to_shown_ms']['p95']:.3f}ms**;
{native['over33_3ms']}/120responses exceed33.3ms. Per-phase p95 values for1/8,3/8,5/8,7/8 are
30.933,26.734,22.571,35.105ms. Receipt-error maxima remain below0.862ms.
These are instrumented sparse-fixture observations, not release qualification,
a universal native floor or permission to change the gate.

All{native['attempts']}native acquisition attempts (including three startup attempts),
{native['events']}scalar events and{native['callbacks']}display callbacks remain accounted for.
Every measured receipt hook and reconstructed receipt/present-request/final-GPU
point has zero **other** recorded pending drawables. All callbacks drain to
pending0/acquiring0. This describes acquisition-awaiting-callback state, not
Metal pool availability, reference lifetime, drawable credits or compositor queue
depth. It cannot establish the cause of presentation latency.

The framework emits four startup backend present records with zero shown feedback,
no presentation-metrics samples or input receipts, and an empty pending trace.
Its observer never starts because startup readiness fails first. This is a
failed diagnostic startup, not a framework latency observation. There are no
framework phase buckets and no subtraction from the valid native run.

An [offscreen linked-code audit](linked-source-audit.json) finds that the actual
framework `VellumPresentationLayer nextDrawable` method lacks the pending hooks
present in the supplied Objective-C overlay. The original presentation-acquire
call is linked, so the missing pending hooks do not independently explain the
whole startup failure. Source/build recipes and offscreen pixels alone were
insufficient to prove native-overlay integration. The next diagnostic repair is
to materialize native Core changes in a fresh private copy and require actual
linked-hook evidence before any new capture. The SDK/original Core remain sealed.

The attempt takes{s['elapsed_seconds']:.3f}seconds within100seconds; native takes
{native['native_seconds']:.3f}seconds and framework6.001seconds. All18owned native/probe
groups retire and are observed absent. Configuration/geometry, raw log hashes,
compiled/runtime pins and all8,321SDK files verify. Framework stderr/error are
retained, without dropping the failure. The approved quiet scope is consumed;
desktop free, no native process remains. A corrected attempt needs its own
preparation, review, commit and fresh bounded desktop authority.

Preparation checkpoint`{s['prepared_commit'][:7]}` includes eight focused methods,
headless concurrency/overflow/JSON/drain tests, both source builds, routed full
pixels, recipe and SDK checks. Prism using Anthropic Claude Sonnet5.5 covered
21initial and7follow-up files; its overflow concern was fixed and rejected-prefix
state continuation was proven to remain visibly refused. The actual result and
linked-code audit receive a separate review before commit.

Original Cogent/WebGPU/Metal design, features, SDK/app, allocation/cache/presentation
and pacing defaults, and33.3ms release gate are unchanged. M3–M7 remain open;
no permanent display link or production repair is adopted. See the
[protocol](../../../tools/macos-calibration/presentationphase/PLAN.md),
[preparation checks](preparation-checks.json), [result summary](result-summary.json),
review receipts and indexed evidence.
'''
(d/'README.md').write_text(text)
for name in ['result-summary.json','linked-source-audit.json']:shutil.copyfile(q/name,d/name)
for name in ['verify_results.py','audit_linked.py']:shutil.copyfile(x/name,d/'execution-sources'/(name+'.txt'))
p=r/'specs/macos-release-assessment.md';p.write_text(p.read_text()+f'''
The [first phase-matched control](../docs/reports/macos-presentation-phase/README.md)
is rejected in{s['elapsed_seconds']:.3f}seconds. Native completes248joins with30measured
per phase, p9534.960ms and zero other recorded pending drawables at measured
receipt/present/GPU points. Framework fails startup before any input or metrics
sample; no matched comparison exists. Linked-code audit finds pending hooks absent
from its acquisition method despite the Objective-C overlay. The original acquire
observer call is linked, so the whole startup failure remains unisolated. All18
groups/logs/config/geometry/source/SDK8321checks pass; rejection retained/sealed.
Next diagnostic preparation must materialize native changes in a private Core
copy and verify linked hooks. No unchanged retry or features/defaults/SDK/app/
gate change; M3–M7 open. Original quiet scope consumed, desktop free.
''')
(q/'result-internal-review.json').write_text(json.dumps({'result':'PASS','checks':['Native raw journal independently reclassified; exact stored match,248joins/30perphase','Framework exit1 with startup deadline/0inputs/0metrics/0pendinghook records retained; no matched-pair or causal claim','Actual linked method lacks expectedpendinghooks but retainsoriginalobservercall; do not overattribute missingstartup to overlay alone','All18groups/config/geometry/pins/logs/SDK8321 intact; scope consumed/sealed','No gate/default/feature/SDK/app changes or ordinaryqualification; no unchanged retry'],'unresolved_findings':[]},indent=2)+'\n')
