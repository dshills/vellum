from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-sdk-lifecycle-stage0079';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((W/'post-proof.json').read_text());assert proof['result']=='PASS_UNCHANGED_SDK_SOURCE_AND_RETIRED_GROUPS'
assert json.loads((W/'internal-result-review.json').read_text())['approved'];assert json.loads((W/'internal-prose-review.json').read_text())['approved'];prism=json.loads((W/'prism.json').read_text());assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1;assert {x['id']for x in prism['findings']}=={'94a2758f3ad5fa4b','c01d3ae7cd32b26a'};assert json.loads((W/'internal-prism-disposition.json').read_text())['addressed']
p=json.loads((W/'plan.json').read_text());shared=W/'shared';shared.mkdir();sharedmap={}
for i,(source,digest)in enumerate(sorted(p['pins'].items())):
 src=Path(source);assert sha(src)==digest;name=f'{i:02d}-'+src.name;dst=shared/name;shutil.copyfile(src,dst);sharedmap[source]={'stored':name,'sha256':digest}
sdk=Path(p['sdk']);shutil.copyfile(sdk/'SDK_MANIFEST.json',shared/'sdk-manifest.json');assert sha(shared/'sdk-manifest.json')==p['sdk_files']['SDK_MANIFEST.json'];(shared/'sources.json').write_text(json.dumps(sharedmap,indent=2)+'\n')
checks={'scope':'Unchanged minimumGoSDK two-cycle/40sshort/480sfourstateidle functionalchecks, original sandbox failure retained','source_sdk':p['source_sdk'],'documentation_head':p['current_documentation_head'],'native_runs_created':4,'successful_scoped_runs':3,'harness_failures_retained':1,'physical_input_generated':False,'closed_mac_gates':[],'prism_calls':1,'prism_raw_exit_code':1,'prism_retained_medium':2,'prism_addressed':['94a2758f3ad5fa4b','c01d3ae7cd32b26a'],'prism_findings_remain_open_in_product_evidence':True,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for prefix,root in[(n,W.parent/n)for n in['macos-sdk-m4-preflight-f875857','macos-sdk-m4-preflight-f875857-v2','macos-sdk-idle-preflight-f875857','macos-sdk-idle-eligible-f875857']]:
 for leaf in sorted(root.rglob('*')):
  assert not leaf.is_symlink(),leaf
  if not leaf.is_file()or '__pycache__'in leaf.parts or leaf.name.startswith('stop-')or leaf.name=='report-draft.md':continue
  size=leaf.stat().st_size;assert size<8<<20,(leaf,size);name=prefix+'/'+leaf.relative_to(root).as_posix();files[name]={'bytes':size,'sha256':sha(leaf)};sources[name]=leaf
assert len(files)<200 and sum(x['bytes']for x in files.values())<40<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<10<<20;record={'archive':archive.name,'archive_sha256':sha(archive),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
