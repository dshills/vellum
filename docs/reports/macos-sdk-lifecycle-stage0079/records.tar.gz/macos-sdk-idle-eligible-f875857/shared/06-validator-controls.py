from pathlib import Path
import copy,hashlib,importlib.util,json
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('idle_controls',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=json.loads((W/'plan.json').read_text());r=json.loads((W/'result.json').read_text());events=[json.loads(x)for x in(W/'native/stdout').read_text().splitlines()if x.strip()];pid=r['run']['pid'];validate=m.validator(Path(p['sdk']));assert validate(events,p['idle_config'],pid)==r['validation'];cases={}
for name in['wrong-owned-pid','counter-decrease','bad-read-bracket','missing-transition','wrong-occlusion','duplicate-action','missing-terminal']:
 e=copy.deepcopy(events);owned=pid
 if name=='wrong-owned-pid':owned+=1
 if name=='counter-decrease':
  a=next(x for x in e if x['event']=='vellum.soak.sample')['framework_native_activity'];a['end']['empty_event_post_attempts']=0;a['start']['empty_event_post_attempts']=1
 if name=='bad-read-bracket':
  a=next(x for x in e if x['event']=='vellum.soak.sample');a['framework_native_activity']['start_read']['end_utc']=a['end_utc']
 if name=='missing-transition':e.remove(next(x for x in e if x['event']=='vellum.soak.transition'))
 if name=='wrong-occlusion':next(x for x in e if x['event']=='vellum.soak.transition'and x['phase']=='occluded')['target']['OcclusionVisible']=True
 if name=='duplicate-action':e.insert(0,copy.deepcopy(e[0]))
 if name=='missing-terminal':e.pop()
 try:validate(e,p['idle_config'],owned)
 except Exception as error:cases[name]={'rejected':True,'type':type(error).__name__,'message':str(error)}
 else:raise AssertionError('accepted malformed '+name)
d={'result':'PASS_PURE_VALIDATOR_CONTROLS','native_executed':False,'cases':cases,'baseline_validation_equal':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(W/'validator-controls.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'rejected':len(cases),'native_executed':False}))
