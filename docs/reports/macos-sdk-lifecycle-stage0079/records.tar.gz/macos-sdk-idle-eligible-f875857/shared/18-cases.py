"""Fixed current-source lifecycle cases. Later cases require validated predecessors."""
CASES={}
for name,n,e,same in [('same-two',2,1,True),('same-five',5,1,True),('same-thousand',1000,25,True),('unique-thousand',1000,25,False)]:
 timeout=300 if n<1000 else 14400
 args=['-composed']+(['-same-name']if same else[])+[f'-cycles={n}',f'-sample-every={e}',f'-timeout={timeout}s']
 CASES[name]={'cycles':n,'every':e,'same_name':same,'heap_profile':None,'timeout_seconds':timeout,'watchdog_seconds':timeout+60,'args':args}
ORDER=list(CASES)
