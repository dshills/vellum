from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('proof_base',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);h=m.h
p=json.loads((W/'plan.json').read_text());r=json.loads((W/'result.json').read_text());assert r['result']=='PASS_SCOPED_SDK_ELIGIBLE_IDLE_TRACE'and r['error']is None;m.b.clean()
roots={}
for root in[h.C,h.T]:
 files={n+'/'+q.relative_to(root/'drivers/cogent/build'/n).as_posix():h.sha(q)for n in['upstream','typesetting']for q in(root/'drivers/cogent/build'/n).rglob('*')if q.is_file()};digest=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert len(files)==6260 and digest=='1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba';roots[str(root)]={'clean_head':h.git(root,'rev-parse','HEAD').decode().strip(),'prepared_files':len(files),'prepared_sha256':digest}
assert all(h.sha(k)==z for k,z in p['pins'].items());assert m.b.vector(Path(p['sdk']))==p['sdk_files'];assert h.sha(p['binary']['path'])==p['binary']['sha256'];archive=W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/deliverables/vellum-v0.1.0-alpha.2-macos-arm64-go1.25.6-sdk.tar.gz';assert archive.stat().st_size==29816117 and h.sha(archive)=='0bce4f09f8a51a7b196b2bba57c92d1c3fc4eaa999093fdef5c50edbea7bb7f9'
groups={}
for name in['macos-sdk-m4-preflight-f875857','macos-sdk-m4-preflight-f875857-v2','macos-sdk-idle-preflight-f875857','macos-sdk-idle-eligible-f875857']:
 root=W.parent/name;item=json.loads((root/'result.json').read_text());assert(root/'stop-preflight').exists();groups[name]=h.g.absent(item['run']['group'])
d={'result':'PASS_UNCHANGED_SDK_SOURCE_AND_RETIRED_GROUPS','roots':roots,'sdk_files_including_manifest':len(p['sdk_files']),'binary_sha256':p['binary']['sha256'],'sdk_archive_sha256':h.sha(archive),'pins':len(p['pins']),'group_observations':groups,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'post-proof.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'groups':len(groups),'pins':d['pins'],'prepared_per_root':6260}))
