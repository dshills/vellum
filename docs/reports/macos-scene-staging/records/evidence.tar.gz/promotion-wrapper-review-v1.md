The initial promotion wrapper needs one correction. Its first-parent check does not require a sole parent.

Producer SHA256: `9d349c6435261dfe6dab9b8df3a818673fc427f370ce7ac488ad0dea30e0ece3`. Replace that check with an exact two-token parent list `[commit, base]`. All other reviewed safety guards are sound. No producer or Git commands were executed.
