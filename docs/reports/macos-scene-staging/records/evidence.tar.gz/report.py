import hashlib,io,json,re,tarfile
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-scene-staging'); report=root/'docs/reports/macos-scene-staging';records=report/'records'; records.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qualification=json.loads((phase/'qualification.json').read_text());review=json.loads((phase/'source-review-v1.json').read_text());prism=json.loads((phase/'prism-v1/prism.json').read_text());process=json.loads((phase/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and process['source_index_stable']
assert review['result']=='APPROVED_SOURCE' and not review['findings']
assert all(sha(Path(name))==h for name,h in review['reviewed_file_sha256'].items())
coverage=prism['coverage']
assert coverage['complete'] and coverage['files']==9 and not coverage['excluded'] and not coverage['skipped'] and coverage['truncatedBytes']==0
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert not prism['findings'] and not prism['discarded'] and not prism['suppressed']
assert qualification['source']==process['after']
wrapper=json.loads((phase/'promotion-wrapper-review-v2.json').read_text())
assert wrapper['status']=='APPROVED' and not wrapper['findings'] and sha(phase/'promote.py')==wrapper['producer_sha256']
summary={}
for label in ['baseline','candidate']:
 text=(phase/(label+'-bench')/'stdout.log').read_text()
 result={}
 for name,ns,bytes_,allocs in re.findall(r'^(Benchmark\S+)\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',text,re.M):
  key=re.sub(r'-\d+$','',name);result.setdefault(key,[]).append({'bytes_per_op':int(bytes_),'allocs_per_op':int(allocs)})
 assert len(result)==4 and all(len(v)==5 for v in result.values())
 summary[label]={k:{'bytes_per_op':[min(r['bytes_per_op']for r in v),max(r['bytes_per_op']for r in v)],'allocs_per_op':[min(r['allocs_per_op']for r in v),max(r['allocs_per_op']for r in v)]}for k,v in result.items()}
(phase/'allocation-summary.json').write_text(json.dumps({'scope':'Local offscreen synthetic fixture Go allocated bytes/objects only. Wall timing is deliberately excluded; shared computer use and these fixtures cannot qualify frame latency, native/GPU behavior or total retained memory.','results':summary},indent=2)+'\n')
members={}
for p in sorted(phase.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  name=p.relative_to(phase).as_posix(); members[name]={'sha256':sha(p),'bytes':p.stat().st_size}
(records/'archive-index.json').write_text(json.dumps(members,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as archive:
 for name in members:
  data=(phase/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
checkpoint={'base_commit':qualification['base_commit'],'scope':'Offscreen-only scene staging and encoder scratch checkpoint. Live native/GPU/full-frame performance tests deferred until the user says computer is free. Whole Mac acceptance remains open.','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':0,'qualification_sha256':sha(phase/'qualification.json'),'source_review_sha256':sha(phase/'source-review-v1.json'),'prism_process_sha256':sha(phase/'prism-v1/process.json'),'archive':{'sha256':sha(records/'evidence.tar.gz'),'members':len(members),'index_sha256':sha(records/'archive-index.json')},'prepared_files':qualification['prepared_files'],'allocation':summary}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
rows=[]
for k,old in summary['baseline'].items():
 new=summary['candidate'][k]
 fmt=lambda v:str(v[0])if v[0]==v[1]else str(v[0])+'–'+str(v[1])
 rows.append('| '+k.replace('BenchmarkVellumScenePlan','')+' | '+fmt(old['bytes_per_op'])+' | '+fmt(new['bytes_per_op'])+' | '+fmt(old['allocs_per_op'])+' → '+fmt(new['allocs_per_op'])+' |')
report.joinpath('README.md').write_text('''# Scene staging: offscreen checkpoint

Stage 0044 reduces scene-construction copying with private 64-operation blocks
and flattens once at seal. It also reuses tile-count scratch after writing the
output row table. Packet ownership, painter order, logical limits and wire bytes
stay fixed. This is an offscreen checkpoint; Mac acceptance remains open.

The operation limit is checked before allocating another block. Per builder,
at most 1024 blocks exist and the last has at most 63 unused slots. Successful
and refused seals retire all construction references. Refused span streams skip
compaction, with byte admission after spare-header refund. Retained operations
have exact capacity. Block metadata, spare slots, flattening overlap and encoder
scratch are excluded from the logical packet payload limit.

Checks passed: full sceneplan/rasterx/gpuscene offscreen race; root and driver
offscreen race; root, driver and prepared-renderer vet; preparation tests; and
fresh pin-verified preparation. Eleven encoding digests captured from unchanged
fdb67bc match, including block boundaries through 65,536 operations and mixed
image/mask/span payloads. A separate tile-outer oracle checks row counts and
painter-ordered references. Existing randomized image/draw source-mutation and
exact scanner arithmetic tests remain. New checks cover exact byte/operation
boundaries, reset detection and both retirement paths.

Local offscreen allocation fixtures ran five times per revision:

| Fixture | Baseline B/op | Candidate B/op | Allocations/op |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Operation fixtures include synthetic uniform source creation and sealing.
The 8192-operation fixture allocates fewer bytes but more objects because blocks
replace geometric slice growth. TileScratch uses a 2048×2048 target and one
small operation; SpanBandsTallTarget uses the existing scanner-band fixture.
These numbers describe Go allocated bytes/objects in these fixtures, not whole
frames, peak/retained/native/GPU memory or UI responsiveness. Wall timing is
excluded because the computer is shared and live comparison is deferred.

Internal source review approved the implementation. One Prism review used
Anthropic Claude Sonnet 5.5 for nine source/pin/test/contract files, with complete
coverage and no reported findings. Runtime evidence was excluded from provider
inputs. Pin reproduction changes exactly three prepared files; the complete
prepared set contains 6172 files.

Two development errors were corrected: a test initially compared a struct
containing a slice, and the staging producer initially confused grouped stage
count with patch number. The failed compilation and the preparation sequence
are retained in evidence; the final tests and flattened pin-order guard pass.
Before promotion, internal review strengthened the proposed Git parent guard
to require exactly one parent. The original unexecuted proposal and both
wrapper reviews are preserved.

Live windows/input, actual native GPU parity and full-frame allocation/latency
checks are deferred until the user explicitly says the computer is free. No OS
preferences were changed and no public release or publication ran. Prior warm
performance failures and other Mac completion gates remain unresolved.

[Checkpoint](records/checkpoint.json), [archive index](records/archive-index.json)
and [raw evidence](records/evidence.tar.gz) bind the source, tests and local
allocation observations. This report does not qualify broad native acceptance.
''')
print(json.dumps({'archive_members':len(members),'archive_sha256':checkpoint['archive']['sha256'],'report_sha256':sha(report/'README.md')}))
