import difflib,hashlib,json
from pathlib import Path
root=Path('/private/tmp/vellum-large-data'); phase=Path('/private/tmp/vellum-scene-staging'); before=json.loads((phase/'original-hashes.json').read_text())['upstream']
dest=root/'drivers/cogent/native/patches/operationblocks'; dest.mkdir(exist_ok=True); after={}; chunks=[]
for name,h in sorted(before.items()):
 current=root/'drivers/cogent/build/upstream'/name; old=phase/'original/upstream'/name
 assert (hashlib.sha256(old.read_bytes()).hexdigest()if old.exists()else None)==h
 after[name]=hashlib.sha256(current.read_bytes()).hexdigest(); assert h!=after[name]
 chunks.append(''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True)if old.exists()else[],current.read_text().splitlines(keepends=True),fromfile='a/'+name if old.exists()else'/dev/null',tofile='b/'+name,n=3)))
patch=dest/'0044-bounded-operation-staging.patch'; patch.write_text(''.join(chunks))
(dest/'original-hashes.json').write_text(json.dumps(before,indent=2)+'\n');(dest/'output-hashes.json').write_text(json.dumps(after,indent=2)+'\n')
mp=root/'drivers/cogent/native/dependencies.json'; manifest=json.loads(mp.read_text()); core=manifest['dependencies'][0]
stage={'origin':'drivers/cogent/native/patches/operationblocks','inputs':'native/patches/operationblocks/original-hashes.json','outputs':'native/patches/operationblocks/output-hashes.json','patches':[{'file':'native/patches/operationblocks/'+patch.name,'sha256':hashlib.sha256(patch.read_bytes()).hexdigest()}]}
numbers=[int(Path(p['file']).name[:4])for s in core['stages']for p in s['patches']]
assert numbers==list(range(1,44)); core['stages'].append(stage);mp.write_text(json.dumps(manifest,indent=2)+'\n')
(phase/'stage.json').write_text(json.dumps({'base_commit':'fdb67bc645ab25d64409faf06b0dc0191bef23e7','before':before,'after':after,'stage':stage},indent=2)+'\n')
print('pinned stage 44',len(after),'files')
