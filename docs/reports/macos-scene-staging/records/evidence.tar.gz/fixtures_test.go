// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package sceneplan

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"testing"
)

func stagingFixture(n int, mixed bool) *Packet {
	b := New(image.Rect(0, 0, 35, 33))
	source := image.NewRGBA(image.Rect(2, 3, 7, 8))
	mask := image.NewAlpha(source.Rect)
	for i := range source.Pix { source.Pix[i] = byte(i*37+11) }
	for i := range mask.Pix { mask.Pix[i] = byte(i*19+7) }
	for i := 0; i < n; i++ {
		c := color.RGBA{byte(i*3), byte(i*5), byte(i*7), 255}
		x, y := i%31, (i*11)%29
		r := image.Rect(x, y, x+5, y+5)
		if i == 0 { b.Draw(b.packet.bounds, image.NewUniform(c), image.Point{}, nil, image.Point{}, draw.Src); continue }
		if !mixed { b.Draw(r, image.NewUniform(c), image.Point{}, nil, image.Point{}, draw.Op(i%2)); continue }
		switch i%4 {
		case 0:
			b.Draw(r, image.NewUniform(c), image.Point{}, nil, image.Point{}, draw.Over)
		case 1:
			b.Draw(r, image.NewUniform(c), image.Point{}, mask, mask.Rect.Min, draw.Over)
		case 2:
			b.Draw(r, source, source.Rect.Min, mask, mask.Rect.Min, draw.Src)
		default:
			b.BeginSpans(c, draw.Over)
			b.Span(y+4, x+1, x+5, 32767)
			b.Span(y, x, x+3, 65535)
			b.Span(y+4, x, x+2, 12345)
		}
		// Existing operations must keep their previous source/mask snapshots.
		mask.Pix[0]++; source.Pix[0]++
	}
	p := b.Seal(true)
	clear(source.Pix); clear(mask.Pix)
	return p
}

func stagingDigest(p *Packet) string {
	e, ok := p.Encode(); if !ok { panic("fixture encode refused") }
	h := sha256.New()
	for _, value := range []int{e.Tiles.X, e.Tiles.Y} { var b [8]byte; binary.LittleEndian.PutUint64(b[:], uint64(value)); h.Write(b[:]) }
	for _, part := range [][]byte{e.Ops, e.Rows, e.Refs, e.Data} {
		var b [8]byte; binary.LittleEndian.PutUint64(b[:], uint64(len(part))); h.Write(b[:]); h.Write(part)
	}
	return fmt.Sprintf("%x", h.Sum(nil))
}

// Digests captured from unchanged fdb67bc before the staging/encoding edits.
var originalStagingDigests = map[string]string{
	"uniform-0": "380c03491f7fff5743aa87fde71576ab4248a9f2ae17a479cc7d56bb1a10fd44",
	"uniform-1": "8a498f84f3743f34ec0a25567ef375ecb0413fa0a8a74b1347ea3b2a07ac1f36",
	"uniform-63": "3c4fd0e1c66adfac6d11a20ee39daf5e8eae4091ea7856b7ef3bec2b20a4fe1c",
	"uniform-64": "6c19fc3f5b04443d7fd667f8849760778e3819f69bf7657f0c1320699dc09fa3",
	"uniform-65": "31b4c9ecc987308173937bb8d23d0cb220dd0127f363c9abf5f9a3bab35e6148",
	"uniform-127": "2d38e44c19eabbb0c632fa6e58983ca34cbd1f5dd5475838efec663226752c1a",
	"uniform-128": "a88a7178cb1a1725b39a3d988c3c3dec3ddecd695364ce351c655d2db8f2e99a",
	"uniform-129": "b2593ecaea3626963773bd1dbb94be53d71a786368ddedc886bbbaf2e59dba28",
	"uniform-1024": "f079303693ece55bd28fba295a8a8c9fcbbf268b3be5886d72b16d0917f049dd",
	"uniform-65536": "a976ae02c220bc061621808b2dfe9350ec1f5184e2e99ea491beafee6780367d",
	"mixed-129": "92d138e7354d980b93a910e9b207d4d616873cb65811e15676b21c794033d363",
}

func TestVellumScenePlanStagingOriginalEncoding(t *testing.T) {
	for _, n := range []int{0,1,63,64,65,127,128,129,1024,MaxOps} {
		p := stagingFixture(n, false)
		if p == nil || p.Operations() != n { t.Fatalf("fixture %d refused", n) }
		if stagingDigest(p) != originalStagingDigests[fmt.Sprint("uniform-",n)] { t.Fatal("original encoded bytes changed",n) }
	}
	p := stagingFixture(129, true)
	if p == nil { t.Fatal("mixed fixture refused") }
	if stagingDigest(p) != originalStagingDigests["mixed-129"] { t.Fatal("original mixed encoded bytes changed") }
}

func TestVellumScenePlanStagingIndependentTileOracle(t *testing.T) {
	p := stagingFixture(129, true)
	e, ok := p.Encode(); if !ok { t.Fatal("encode refused") }
	// Tile-outer traversal is independent of the encoder's operation-outer bin fill.
	ref := 0
	for y := 0; y < e.Tiles.Y; y++ { for x := 0; x < e.Tiles.X; x++ {
		tile := image.Rect(x*TileSize, y*TileSize, (x+1)*TileSize, (y+1)*TileSize)
		var want []uint32
		for i, op := range p.ops { if op.rect.Overlaps(tile) { want = append(want, uint32(i)) } }
		at := (y*e.Tiles.X+x)*8
		if binary.LittleEndian.Uint32(e.Rows[at:]) != uint32(ref) || binary.LittleEndian.Uint32(e.Rows[at+4:]) != uint32(len(want)) { t.Fatal("tile row differs", x,y) }
		for _, index := range want { if binary.LittleEndian.Uint32(e.Refs[ref*4:]) != index { t.Fatal("painter order differs", x,y,ref) }; ref++ }
	} }
	if len(e.Refs) != ref*4 { t.Fatal("unused reference bytes") }
	first := stagingDigest(p)
	for _, part := range [][]byte{e.Ops,e.Rows,e.Refs,e.Data} { clear(part) }
	if stagingDigest(p) != first { t.Fatal("encoded outputs alias packet") }
	got, want := image.NewRGBA(p.Bounds()), image.NewRGBA(p.Bounds())
	if !p.Replay(want) || !p.Replay(got) || !bytes.Equal(got.Pix,want.Pix) { t.Fatal("replay changed after output mutation") }
}

var stagingPacketSink *Packet
var stagingEncodedSink *Encoded
func BenchmarkVellumScenePlanOperationStaging(b *testing.B) {
	for _, n := range []int{512,8192} { b.Run(fmt.Sprint(n),func(b *testing.B) {
		b.ReportAllocs()
		for i:=0;i<b.N;i++ { stagingPacketSink=stagingFixture(n,false); if stagingPacketSink==nil { b.Fatal("refused") } }
	}) }
}
func BenchmarkVellumScenePlanTileScratch(b *testing.B) {
	p:=New(image.Rect(0,0,2048,2048)); p.Draw(image.Rect(100,100,116,116),image.White,image.Point{},nil,image.Point{},draw.Src); packet:=p.Seal(false)
	b.ReportAllocs(); b.ResetTimer()
	for i:=0;i<b.N;i++ { var ok bool; stagingEncodedSink,ok=packet.Encode(); if !ok { b.Fatal("refused") } }
}
