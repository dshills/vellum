"""Reconcile the sealed interrupted campaign without requalifying failed runs."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-tile-binning-native'
spec=importlib.util.spec_from_file_location('tile_native_inherited_run',OLD/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
review=r.load_review();r.need(r.approved_stable(review),'original reviewed inputs restored');r.need((r.P/'stop-live').exists(),'original campaign sealed');r.need(r.build.identity()==r.read(r.P/'build/source.json'),'unchanged candidate source')
cases={};pins={}
for name in r.ORDER[:12]:
 d,h=r.saved_case(name,review);r.owned.absent(d['pid']);cases[name]=dict(receipt_sha256=h,validation=d['validation'],original_result=d['result'])
 for leaf in['receipt.json','owned.json','stdout','stderr']:pins[str(r.P/'runs'/name/leaf)]=r.sha(r.P/'runs'/name/leaf)
excluded={}
for name in r.ORDER[12:14]:
 out=r.P/'runs'/name;d=r.read(out/'receipt.json');r.owned.absent(d['pid']);r.need(d['source_stable']and d['binary_stable']and d['logs_complete']and d['exit_code']==0 and d['retirement']['terminal']and d['retirement']['group_absent']and not d['cleanup_errors'],'excluded terminal/source/binary facts')
 if name.startswith('baseline'):
  r.need(d['result']=='FAILED_OR_CANCELED_NATIVE_RUN'and d['pins_stable']is False and d['error']==dict(type='ValueError',message='runtime controls'),'original failed result preserved')
 else:r.need(d['result']=='VALID_SCOPED_NATIVE_RUN'and d['pins_stable']is True,'unpaired candidate original result')
 excluded[name]=dict(result=d['result'],receipt_sha256=r.sha(out/'receipt.json'),comparison_qualified=False,reason='Freshly repeat both members of interrupted CPU fixed r2 pair; preserve both original records.')
 for leaf in['receipt.json','owned.json','stdout','stderr']:pins[str(out/leaf)]=r.sha(out/leaf)
edited=W/'history/report-edited.py';original=OLD/'report.py';before=original.read_bytes();changed=edited.read_bytes();r.need(changed==before.replace(b'without overlays, race or profiler/detail flags. Only the encoder production',b'with GOMAXPROCS=2 and without overlays, race or profiler/detail flags. Only the encoder production'),'sole report edit identified')
d=dict(result='SEALED_PARTIAL_CAMPAIGN_RECONCILED',inherited_cases=cases,accepted_gpu_processes=2,accepted_ordinary_processes=10,excluded_cases=excluded,original_processes=14,new_ordinary_processes_planned=30,qualified_ordinary_processes_planned=40,physical_processes_total_if_completed=44,original_readiness_sha256=r.sha(OLD/'native-readiness.json'),restored_report_sha256=r.sha(original),edited_report_sha256=r.sha(edited),producer_sha256=r.sha(__file__),original_runner_sha256=r.sha(OLD/'run.py'),pins=pins,failed_result_requalified=False,source_changed=False,native_runtime_executed_by_this_producer=False)
with(W/'inherited.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:d[k]for k in['result','accepted_gpu_processes','accepted_ordinary_processes','original_processes','new_ordinary_processes_planned','failed_result_requalified']}))
