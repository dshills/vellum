"""Consumer-only synthetic refusal controls; never launch native code."""
from pathlib import Path
import copy,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('tile_native_controls_run',W/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
fixture=Path('/private/tmp/vellum-current-viewport-native-23ea03f/runs/gpu-fixed-r1-1000000/stdout')
records=[json.loads(line)for line in fixture.read_bytes().splitlines()]
name='baseline-gpu-fixed-r3-1000000'
# Explicitly synthetic parser input: retain old ordinary records but bind their
# declared source metadata to the baseline expected by this parser. This is not
# runtime evidence for that baseline binary.
records[0]['build_settings']['vcs.revision']=r.definition(name)['source_commit']
records[0]['build_settings']['vcs.modified']='false'
def encoded(rs):return b'\n'.join(json.dumps(x).encode()for x in rs)+b'\n'
checks=[]
def check(label,fn,refused):
 error=None
 try:fn()
 except(ValueError,AssertionError,KeyError,TypeError)as e:error=type(e).__name__+': '+str(e)
 ok=(error is not None)==refused;checks.append(dict(control=label,pass_control=ok,expected_refusal=refused,error=error));r.need(ok,label)
check('synthetic ordinary accepted',lambda:r.validate(name,encoded(records)),False)
for label,mutate in[
 ('missing native guard',lambda rs:rs[0].pop('window_geometry_guard')),
 ('dirty source',lambda rs:rs[0]['build_settings'].__setitem__('vcs.modified','true')),
 ('wrong revision',lambda rs:rs[0]['build_settings'].__setitem__('vcs.revision','0'*40)),
 ('profiling flag',lambda rs:rs[0].__setitem__('source_details',True)),
 ('missing sample',lambda rs:rs.pop(2)),
 ('duplicate sample',lambda rs:rs.insert(2,copy.deepcopy(rs[2]))),
]:
 mutated=copy.deepcopy(records);mutate(mutated);check(label,lambda mutated=mutated:r.validate(name,encoded(mutated)),True)
for case,roots in r.ROOTS.items():
 lines=[]
 for root in sorted(roots):lines.extend(['=== RUN   '+root,'--- PASS: '+root+' (0.01s)'])
 text='\n'.join(lines)+'\nPASS\n';check(case+' synthetic roots accepted',lambda case=case,text=text:r.validate(case,text.encode()),False)
 for label,changed in [('skip',text.replace('--- PASS:','--- SKIP:',1)),('missing root','\n'.join(text.splitlines()[2:])+'\n'),('no final PASS',text[:-5])]:check(case+' '+label,lambda case=case,changed=changed:r.validate(case,changed.encode()),True)
d=dict(result='CONSUMER_CONTROLS_PASS',count=len(checks),checks=checks,producer_sha256=r.sha(__file__),runner_sha256=r.sha(W/'run.py'),original_fixture_sha256=r.sha(fixture),synthetic_inputs_only=True,native_runtime_executed=False)
with(W/'controls.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(result=d['result'],count=len(checks),native_runtime_executed=False)))
