"""Serial explicit GPU readback checks and balanced matched ordinary grid runs."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,selectors,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
build=module('tile_native_build',W/'build.py');P,T,BASE=build.P,build.T,build.BASE
sys.path.insert(0,str(W.parent/'macos-grid-native-stacks'))
owned=module('tile_native_ownership',W.parent/'macos-grid-native-stacks/run.py')
benchmark=module('tile_native_grid_consumer',T/'scripts/benchmark-grid.py')
sha,read,need=build.sha,build.read,build.need
STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
ALL_ORDER=['gpu-scene','gpu-drawer']+[f'{cohort}-{mode}-{height}-r{repeat}-1000000'for repeat in range(1,6)for mode in(['gpu','cpu']if repeat%2 else['cpu','gpu'])for height in(['fixed','variable']if repeat%2 else['variable','fixed'])for cohort in(['baseline','candidate']if repeat%2 else['candidate','baseline'])]
ORDER=ALL_ORDER[12:]
ROOTS={
 'gpu-scene':{'TestVellumGPUSceneNativeIntegerCompositor','TestVellumGPUSceneNativeSharedDrawerOrderAndFallback','TestVellumGPUSceneNativeActualTextAndPaths','TestVellumGPUSceneNativeCoveredUniforms','TestVellumGPUSceneNativeInputAttemptBytesFailureAndRecovery'},
 'gpu-drawer':{'TestVellumSceneSourceNativeThreeBatchSharedToOwned'},
}
def stopping():return STOP.exists()or(P/'stop-live').exists()
def load_review():
 raw=(W/'native-readiness.json').read_bytes();r=json.loads(raw);need(r['execution_ready']and not r['unresolved_findings'],'native readiness');r['_sha256']=hashlib.sha256(raw).hexdigest();return r
def approved_stable(r):return sha(W/'native-readiness.json')==r['_sha256']and all(sha(p)==h for p,h in r['inputs'].items())
def definition(name):
 need(name in ORDER,'fixed case');b=read(P/'build/receipt.json');need(b['result']=='CLEAN_NATIVE_BINARIES_BUILT'and b['source_stable']and b['error']is None,'candidate build')
 if name in ROOTS:
  binary=b['jobs'][name]['binary'];commit=b['source_commit'];regex='^TestVellumGPUSceneNative'if name=='gpu-scene'else'^TestVellumSceneSourceNativeThreeBatchSharedToOwned$';argv=[binary['path'],'-test.v','-test.run='+regex,'-test.count=1','-test.timeout=120s']
 else:
  cohort,mode,height,repeat,rows=name.split('-');binary=b['baseline_binary']if cohort=='baseline'else b['jobs']['grid']['binary'];commit=read(BASE/'build/source.json')['commit']if cohort=='baseline'else b['source_commit']
  argv=[binary['path'],'-perf','-rows='+rows,'-perf-samples=120','-perf-warmup=128']+(['-variable-rows']if height=='variable'else[])+(['-gpu-scene']if mode=='gpu'else[])
 return dict(case=name,argv=argv,cwd=str(P/'runs'/name/'runtime'),source_commit=commit,candidate_source_sha256=sha(P/'build/source.json'),build_sha256=sha(P/'build/receipt.json'),binary=binary,producer_sha256=sha(__file__),physical_input_generated=False,settings_changed=False)
def validate(name,stdout):
 if name in ROOTS:
  text=stdout.decode();runs={line.split()[2]for line in text.splitlines()if line.startswith('=== RUN   ')and'/'not in line.split()[2]};passes={line.split()[2]for line in text.splitlines()if line.startswith('--- PASS: ')and'/'not in line.split()[2]}
  need(runs==passes==ROOTS[name]and text.rstrip().endswith('PASS')and'--- SKIP:'not in text and'--- FAIL:'not in text,'explicit native root execution/readback');return dict(roots=sorted(runs),root_count=len(runs),explicit_gpu_execution_and_readback=True,native_window_opened=False,physical_input_verified=False)
 cohort,mode,height,repeat,rows=name.split('-');records=[json.loads(line)for line in stdout.splitlines()];samples=benchmark.validate_records(records,int(rows),height=='variable',120,False,gpu_scene_rendering=mode=='gpu')
 setup,ready,end=records[0],records[1],records[-1];need(all(type(r.get('window_geometry_guard'))is int and r['window_geometry_guard']==1 for r in[setup,ready,end]),'current native geometry');need(setup['geometry_persistence_disabled_in_fixture']is True and ready['warmup']==128,'persistence/warmup')
 settings=setup['build_settings'];expected=definition(name)['source_commit'];need(settings.get('vcs.revision')==expected and settings.get('vcs.modified')=='false'and settings.get('CGO_ENABLED')=='1'and settings.get('-race','false')!='true','clean optimized cohort metadata');need(all(r.get(k,False)is False for r in records for k in['cpu_profile','source_details','alloc_profile','input_details']),'ordinary flags')
 dist=benchmark.distribution([s['metrics']['ui_work_ns']for s in samples]);return dict(samples=120,warmup=128,native_window=ready['native_window'],initial_grid_bounds=ready['initial_geometry'],warm_viewport=ready['warm_end_viewport'],ui_work_ns=dist,warm_target_met=dist['p95']<=4000000 and dist['p99']<=6000000,gpu_execution_verified=False,physical_input_verified=False)
def saved_case(name,review):
 out=P/'runs'/name;raw=(out/'receipt.json').read_bytes();d=json.loads(raw);expected=definition(name)
 need(all(type(d.get(k))is type(v)and d[k]==v for k,v in expected.items())and d['review_sha256']==review['_sha256'],'saved exact provenance '+name);need(d['result']=='VALID_SCOPED_NATIVE_RUN'and d['error']is None and not d['cleanup_errors'],'saved terminal '+name);need(all(d[k]is True for k in['source_stable','pins_stable','binary_stable','logs_complete','lease_held_through_cleanup'])and d['stop_marker_at_exit']is False,'saved guards '+name)
 ret=d['retirement'];pid=d['pid'];need(type(pid)is int and pid>0 and ret['created']is True and ret['pid']==ret['group']==pid and ret['terminal']is True and ret['group_absent']is True and ret['exit_code']==d['exit_code']==0,'saved retirement '+name);need(ret['group_observation']['group']==pid and ret['group_observation']['members']==[]and len(ret['group_observation']['observation_sha256'])==64,'saved absence '+name)
 launch=read(out/'owned.json');need(launch['pid']==pid and launch['native_runtime_executed']is True and all(k in d and d[k]==v for k,v in launch.items()),'saved ownership '+name);need(set(d['logs'])=={'stdout','stderr'},'saved logs '+name)
 for n,log in d['logs'].items():need(type(log['bytes'])is int and 0<=log['bytes']<=8<<20 and log['eof']is True and(out/n).stat().st_size==log['bytes']and sha(out/n)==log['sha256'],'saved log '+name)
 need(validate(name,(out/'stdout').read_bytes())==d['validation'],'saved validation '+name);return d,hashlib.sha256(raw).hexdigest()
def run(name,review):
 need(approved_stable(review)and not stopping(),'initial review/stop');source=read(P/'build/source.json');need(build.identity()==source,'exact clean candidate');d=definition(name);binary=d['binary'];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'binary identity')
 with owned.LiveLease()as lease:
  need(lease.held()and approved_stable(review)and not stopping(),'lease/review/stop');index=ORDER.index(name)
  if index:
   prior,_=saved_case(ORDER[index-1],review);owned.absent(prior['pid'])
  out=P/'runs'/name;out.mkdir(parents=True,mode=0o700);(out/'runtime').mkdir(mode=0o700)
  d.update(review_sha256=review['_sha256'],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=None,native_runtime_executed=False);child=None;errors=[];counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()];eof=[False,False];start=time.monotonic()
  try:
   with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr,selectors.DefaultSelector()as selector:
    need(lease.held()and approved_stable(review)and not stopping(),'final admission');env={**owned.child_environment(True),'GOMAXPROCS':'2'}
    if name in ROOTS:env['VELLUM_GPU_SCENE_TEST']='1'
    child=subprocess.Popen(d['argv'],cwd=d['cwd'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);d.update(pid=child.pid,native_runtime_executed=True);(out/'owned.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(event='native.started',case=name,pid=child.pid)),flush=True)
    for i,pipe in enumerate([child.stdout,child.stderr]):selector.register(pipe,selectors.EVENT_READ,i)
    terminal=None
    while selector.get_map()or child.poll()is None:
     need(not stopping(),'human return');need(time.monotonic()-start<180,'case watchdog')
     if child.poll()is not None:
      if terminal is None:terminal=time.monotonic()
      need(not selector.get_map()or time.monotonic()-terminal<5,'surviving pipe writers')
     for key,_ in selector.select(.1):
      data=os.read(key.fd,64<<10);i=key.data
      if not data:eof[i]=True;selector.unregister(key.fileobj);continue
      accepted=min(len(data),(8<<20)-counts[i]);stream=[stdout,stderr][i];need(stream.write(data[:accepted])==accepted,'short stream write');stream.flush();counts[i]+=accepted;digests[i].update(data[:accepted]);need(accepted==len(data),'log bound')
    d['exit_code']=child.wait(timeout=5)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   d['retirement']=owned.retire(child,'native',errors);d['cleanup_errors']=errors
   try:d['source_stable']=build.identity()==source;d['pins_stable']=approved_stable(review);d['binary_stable']=sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes']
   except BaseException as e:errors.append(dict(stage='source/binary/pins',type=type(e).__name__,message=str(e)))
   try:d['logs']={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n),eof=eof[i])for i,n in enumerate(['stdout','stderr'])};d['logs_complete']=all(eof)and all(d['logs'][n]['bytes']==counts[i]and d['logs'][n]['sha256']==digests[i].hexdigest()for i,n in enumerate(['stdout','stderr']))
   except BaseException as e:errors.append(dict(stage='log observation',type=type(e).__name__,message=str(e)))
   try:
    need(d['error']is None and not errors and d.get('exit_code')==0 and all(d.get(k)is True for k in['source_stable','pins_stable','binary_stable','logs_complete'])and d['retirement']['terminal']and d['retirement']['group_absent']and lease.held()and not stopping(),'runtime controls');d['validation']=validate(name,(out/'stdout').read_bytes())
    if name not in ROOTS:
     cohort,mode,height,repeat,rows=name.split('-');other=f'{"candidate"if cohort=="baseline"else"baseline"}-{mode}-{height}-{repeat}-{rows}'
     if(P/'runs'/other/'receipt.json').exists():
      prior,prior_sha=saved_case(other,review);need(d['validation']['native_window']==prior['validation']['native_window'],'matched native endpoints');a=[json.loads(line)for line in(P/'runs'/other/'stdout').read_bytes().splitlines()][2:-1];b=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()][2:-1];benchmark.compare_geometry(a,b);need(all(x['geometry']==y['geometry']for x,y in zip(a,b)),'complete matched grid geometry');d['paired_geometry']=dict(case=other,receipt_sha256=prior_sha,samples=120,full_grid_and_native_endpoints_equal=True)
   except BaseException as e:
    if d['error']is None:d['error']=dict(type=type(e).__name__,message=str(e))
   d.update(seconds=time.monotonic()-start,lease_held_through_cleanup=lease.held(),stop_marker_at_exit=stopping(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());d['result']='VALID_SCOPED_NATIVE_RUN'if d['error']is None and not errors else'FAILED_OR_CANCELED_NATIVE_RUN'
   with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
   print(json.dumps(dict(case=name,result=d['result'],error=d['error'],seconds=d['seconds'],validation=d.get('validation'))),flush=True)
  need(d['result']=='VALID_SCOPED_NATIVE_RUN','native case failed')
def main():
 need(sys.argv[1:]in[['--all']]+[[n]for n in ORDER],'fixed selection');review=load_review()
 for name in(ORDER if sys.argv[1]=='--all'else[sys.argv[1]]):run(name,review)
if __name__=='__main__':main()
