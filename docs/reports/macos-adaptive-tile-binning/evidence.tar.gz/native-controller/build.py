"""Reference the reviewed clean original build; no rebuild or native action."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
ORIGINAL=W.parent/'macos-tile-binning-native'
spec=importlib.util.spec_from_file_location('tile_native_original_build',ORIGINAL/'build.py');original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
P=Path('/private/tmp/vellum-tile-binning-native-75-continuation')
T,BASE,S,sha,read,need,identity,committed,environment=original.T,original.BASE,original.S,original.sha,original.read,original.need,original.identity,original.committed,original.environment
