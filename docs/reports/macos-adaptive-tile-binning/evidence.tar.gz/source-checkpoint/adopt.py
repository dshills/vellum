"""Adopt the tested isolated encoder as owned stage0075; no Git/UI actions."""
from pathlib import Path
import difflib,hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd');N=T/'drivers/cogent/native/patches/tilebinning'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,timeout=10).decode().strip()=='77da1dd8784b5ef699f8f7a0f07f7aa1bf0e62d4'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=T,timeout=10)
assert read(W/'prototype-review.json')['adoption_ready']and read(W/'grid-parity.json')['frames']==24 and read(W/'grid-parity.json')['all_dense_selected']
assert read(P/'unit-v2/receipt.json')['exit_code']==0 and read(P/'unit-v2/receipt.json')['source_stable']and read(P/'unit-v2/receipt.json')['overlays_stable']and read(P/'fault/receipt.json')['expected_failure']
assert sha(P/'packet.go')=='9433c82a204fd19d3dbb7ff29d8abe959f5ae580e2c9e0a7b93586bcf1e9fd86'
original=P/'original-packet.go';relative='paint/renderers/sceneplan/packet.go';assert sha(original)==sha(T/'drivers/cogent/build/upstream'/relative)
notice='// Copyright (c) 2026, Davin Hills.\n// SPDX-License-Identifier: MIT\n\n'
test=notice+(P/'tile_binning_v2_test.go').read_text();(P/'adopted_tile_binning_vellum_test.go').write_text(test)
newrelative='paint/renderers/sceneplan/tile_binning_vellum_test.go'
patch=''.join(difflib.unified_diff(original.read_text().splitlines(True),(P/'packet.go').read_text().splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
patch+=''.join(difflib.unified_diff([],test.splitlines(True),fromfile='/dev/null',tofile='b/'+newrelative))
N.mkdir();name='0075-adaptive-tile-bin-counts.patch';(N/name).write_text(patch)
(N/'original-hashes.json').write_text(json.dumps({relative:sha(original),newrelative:None},indent=2)+'\n');(N/'output-hashes.json').write_text(json.dumps({relative:sha(P/'packet.go'),newrelative:sha(P/'adopted_tile_binning_vellum_test.go')},indent=2)+'\n')
(N/'README.md').write_text('''# Adaptive scene tile-bin counts

Owned stage0075 replaces the encoder's first per-reference counting traversal.
Admission computes the exact original rectangular tile-reference count, including
operations later omitted by EncodeGPU. Original operation, mask/data, encoded-byte
and reference limits are unchanged. Builder-produced rectangles are clipped to
bounded packet extents; per-tile counts are bounded by MaxOps, totals by
MaxTileReferences. All arithmetic fits supported Go integer targets.

When retained references exceed twice the tile count, four rectangle-difference
corners and an in-place two-dimensional prefix pass recover exact counts. Sparse
batches retain direct counting. The same temporary count array subsequently
becomes fill positions. There is no new cache, backing allocation, retained
reference or packet/Encoded ABI. Final painter order, compact operation IDs,
per-tile reference order, detached bytes, CPU replay and reset proof are unchanged.

The frozen pre-change encoder is the byte/admission oracle. Tests cover mixed
masks/pixels/spans, random nonaligned rectangles, both encoding modes, exact
reference limits, threshold edges and 65,536 operations in one tile. Existing
encoded-byte/operation bounds and frozen digests remain required. A wrong corner
sign is rejected by the oracle. The managed-driver offscreen fixture compares
24 actual fixed/variable grid frames at supported manual DPI96/160/192 through
serialized integer execution, packet replay and complete captured pixels.
Manual DPI162 is unsupported; its failed fixture attempt remains separate from
native DPI162 evidence. Microbenchmarks are synthetic, and native/ordinary
latency, GPU completion, memory and full Mac qualification are separate gates.

Modified/new owned Go source is MIT. Preparation pins patch input/output hashes
and patch SHA256 before replacing either prepared module.
''')
p=T/'drivers/cogent/native/dependencies.json';m=read(p);up=next(x for x in m['dependencies']if x['name']=='upstream');up['stages'].append(dict(origin='drivers/cogent/native/patches/tilebinning',inputs='native/patches/tilebinning/original-hashes.json',outputs='native/patches/tilebinning/output-hashes.json',patches=[dict(file='native/patches/tilebinning/'+name,sha256=sha(N/name))]));p.write_text(json.dumps(m,indent=2)+'\n')
p=T/'drivers/cogent/prepare_test.py';s=p.read_text();assert 'list(range(1, 75))'in s;p.write_text(s.replace('list(range(1, 75))','list(range(1, 76))'))
grid=(P/'grid_tile_binning_offscreen_test.go').read_text();grid=grid.replace('//go:build offscreen\npackage cogent\n','//go:build offscreen\n\n'+notice+'package cogent\n');(T/'drivers/cogent/grid_tile_binning_offscreen_test.go').write_text(grid)
p=T/'drivers/cogent/native/README.md';p.write_text(p.read_text()+'''\nStage 75 (`patches/tilebinning`) uses adaptive exact scene tile-bin counting:\nanalytic original admission, dense rectangle differences/prefixes and sparse\ndirect counts. Serialized bytes, painter order, compact IDs and all original\nlimits stay fixed. See [owned contract](patches/tilebinning/README.md).\n''')
p=T/'specs/grid-performance.md';p.write_text(p.read_text()+'''\n## Scene encoding tile-bin counts\n\nOwned stage0075 changes CPU-side scene encoding work inside the GPU-requested\nsource path. Original tile-reference/encoded-byte admission still charges every\noperation, including covered clears later omitted from compact output. Dense\nbatches (retained references > twice the tile count) use rectangle differences\nand an in-place prefix pass; sparse batches keep direct counting. The existing\ncount array becomes fill positions afterward. No new cache or retained backing\nis introduced. Encoded ABI bytes, painter order, detached ownership and packet\nreplay/reset semantics must match the frozen pre-change encoder exactly.\n\nExact admission/branch boundaries, mixed operations, frozen bytes, a wrong-corner\ncontrol and full actual-driver software pixel comparisons precede acceptance.\nSupported software DPI96/160/192 does not qualify native DPI162. Synthetic\nencoder microbenchmarks are separate from ordinary native frame targets; all\nhistorical failures and full P4/P6/P11/Mac qualification remain open.\n''')
print(json.dumps(dict(stage=75,patch_sha256=sha(N/name),patch_bytes=len(patch),source_ready_for_checks=True,native_runtime_executed=False)))
