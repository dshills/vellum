"""Commit exact reviewed stage0075 source and integrate/reprepare canonical."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');CHECKS=Path('/private/tmp/vellum-tile-binning-checks-77da1dd')
spec=importlib.util.spec_from_file_location('tile_binning_commit_guard',W.parent/'macos-grid-native-stacks/commit-pending.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W
original_env=m.child_environment;m.child_environment=lambda runtime=False:{**original_env(runtime),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
sha=m.sha;read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def prepared(root):return {p.relative_to(root/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in(root/'drivers/cogent/build'/module).rglob('*')if p.is_file()}
def main():
 output=W/'commit-receipt.json';need(not output.exists(),'exclusive receipt');d=dict(result='INCOMPLETE',producer_sha256=sha(__file__),mutations=[],error=None)
 try:
  b=read(W/'binding.json');r=read(W/'final-review.json');need(r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'final review pins')
  d['before']=dict(candidate=m.observation(T),canonical=m.observation(C));admit=dict(candidate=m.git_admission(T),canonical=m.git_admission(C));d['git_admission']=admit
  need(d['before']['candidate']['head']==d['before']['canonical']['head']==b['base_commit'],'base heads');need(d['before']['candidate']['branch']=='codex/macos-native-results'and d['before']['canonical']['branch']=='codex/foundation-completion','branches');need(m.clean(C)and not m.git(T,'diff','--name-only')and not m.git(T,'ls-files','--others','--exclude-standard'),'external changes')
  need(set(m.git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources']),'staged names');need(all(sha(T/p)==h and hashlib.sha256(m.git(T,'show',':'+p)).hexdigest()==h for p,h in b['sources'].items()),'staged/current bytes');need(hashlib.sha256(m.git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256'],'staged diff')
  source=read(CHECKS/'driver-v2/source.json');need(len(source['files'])==4650 and all(sha(T/p)==h for p,h in source['files'].items()),'full tested source');need(len(source['prepared'])==6246 and prepared(T)==source['prepared'],'full tested preparation')
  for name in ['prepare-v2','prepare-unit-v2','unit-boundaries','driver-v2','vet-v2']:
   check=read(CHECKS/name/'receipt.json');need(check['exit_code']==0 and check['source_stable']and check['prepared_stable']and check['stage75_outputs_match'],'passing check '+name)
  need(Path('/private/tmp/vellum-current-source-costs-native-77da1dd/stop-live').exists()and Path('/private/tmp/vellum-current-viewport-native-23ea03f/stop-live').exists(),'prior native campaigns sealed')
  message=W/'commit-message.txt'
  with message.open('x')as out:out.write('perf(render): count dense scene tile bins with rectangle prefixes\n\nReplace per-reference bin counting with adaptive rectangle differences and in-place prefixes for dense batches, retaining direct sparse counts. Charge exact original references and bytes before compaction; preserve all serialized bytes, painter order, detached ownership and original limits.\n\nAdd owned stage0075, frozen encoder and near-limit oracles, wrong-corner control, and24 actual retained-grid software encoding/pixel pairs. Final preparation, affected-package race, full adapter offscreen race and vet pass with stable source/prepared inputs. Reviewed internally and once with Prism Anthropic Claude Sonnet5.5. Native frame improvement and full Mac qualification remain open.\n')
  need(m.git_admission(T)==admit['candidate']and m.git_admission(C)==admit['canonical'],'Git admission unchanged');m.mutation(T,'source-commit',['git','commit','--file',str(message)],d)
  commit=m.git(T,'rev-parse','HEAD').decode().strip();need(m.clean(T)and m.git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit'],'candidate committed');need(set(m.git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources']),'committed names')
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==admit['canonical'],'canonical admission');m.mutation(C,'source-fast-forward',['git','merge','--ff-only',commit],d)
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==commit,'canonical head');m.mutation(C/'drivers/cogent','prepare-canonical',['python3','prepare.py'],d)
  files=m.git(T,'ls-files','-z').decode().split('\0')[:-1];need(len(files)==4650 and all(sha(T/p)==sha(C/p)for p in files),'tracked parity');need(prepared(T)==prepared(C)==source['prepared'],'prepared parity');need(m.clean(T)and m.clean(C),'clean endpoints')
  d.update(result='REVIEWED_TILE_BINNING_SOURCE_COMMITTED_AND_INTEGRATED',commit=commit,parent=b['base_commit'],source_files=len(files),prepared_files=len(source['prepared']),both_clean=True,canonical_promoted=True,binding_sha256=sha(W/'binding.json'),review_sha256=sha(W/'final-review.json'),provider_calls=1,native_candidate_executed=False,native_frame_gain_qualified=False,full_macos_qualified=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  failed=False
  for label,root in [('candidate',T),('canonical',C)]:
   try:d[label+'_terminal']=m.observation(root)
   except BaseException as e:failed=True;d[label+'_observation_error']=dict(type=type(e).__name__,message=str(e))
  if failed:d.update(result='FAILED_TERMINAL_OBSERVATION',both_clean=False)
  with output.open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps(d),flush=True)
  if failed and d['error']is None:raise RuntimeError('terminal observation failed')
if __name__=='__main__':main()
