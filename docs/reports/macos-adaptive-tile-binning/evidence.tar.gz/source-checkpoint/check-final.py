from pathlib import Path
import hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-tile-binning-checks-77da1dd');P.mkdir(exist_ok=True);sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,timeout=10).decode().strip()=='77da1dd8784b5ef699f8f7a0f07f7aa1bf0e62d4'
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=T,timeout=10).decode().split('\0')[:-1];files={n:sha(T/n)for n in sorted(set(paths))if(T/n).is_file()};assert len(files)==4650
 return files
def prepared():return {p.relative_to(T/'drivers/cogent/build').as_posix():sha(p)for name in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/name).rglob('*')if p.is_file()}
commands={'prepare':(['python3','prepare.py'],T/'drivers/cogent',180),'prepare-unit':(['python3','-m','unittest','prepare_test.py'],T/'drivers/cogent',180),'focused':(['go','test','-race','-p=1','-tags=offscreen','-count=1','./paint/renderers/sceneplan','./paint/renderers/rasterx','./paint/renderers/gpuscene','./gpu/gpudraw','./system/composer'],T/'drivers/cogent/build/upstream',420),'driver':(['go','test','-race','-p=1','-tags=offscreen','-count=1','.'],T/'drivers/cogent',540),'vet':(['go','vet','-p=1','./...'],T/'drivers/cogent',360)}
commands.update({'prepare-v2':commands['prepare'],'prepare-unit-v2':commands['prepare-unit'],'unit-boundaries':(['go','test','-race','-p=1','-tags=offscreen','-count=1','./paint/renderers/sceneplan','./paint/renderers/gpuscene','./gpu/gpudraw','./system/composer'],T/'drivers/cogent/build/upstream',420),'driver-v2':commands['driver'],'vet-v2':commands['vet']})
name=sys.argv[1];argv,cwd,deadline=commands[name];O=P/name;O.mkdir();before=source();prep=prepared();(O/'source.json').write_text(json.dumps(dict(commit='77da1dd8784b5ef699f8f7a0f07f7aa1bf0e62d4',files=before,prepared=prep),indent=2)+'\n')
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};start=time.monotonic()
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(cwd),env=env,stdout=out,stderr=err,timeout=deadline,log_limit_bytes=8<<20)
after=prepared();expected=json.loads((T/'drivers/cogent/native/patches/tilebinning/output-hashes.json').read_bytes());d=dict(name=name,argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-start,source_stable=before==source(),prepared_stable=name in ['prepare','prepare-v2']or prep==after,prepared_files=len(after),stage75_outputs_match=all(sha(T/'drivers/cogent/build/upstream'/n)==h for n,h in expected.items()),source_sha256=sha(O/'source.json'),producer_sha256=sha(__file__),logs={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']},native_runtime_executed=False)
with(O/'receipt.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d),flush=True);assert r.returncode==0 and d['source_stable']and d['prepared_stable']and d['prepared_files']==6246 and d['stage75_outputs_match']
