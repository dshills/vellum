from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
assert not(W/'binding.json').exists()and not(W/'staged.diff').exists()and not git('diff','--cached','--name-only')
expected=sorted(['drivers/cogent/grid_tile_binning_offscreen_test.go','drivers/cogent/native/README.md','drivers/cogent/native/dependencies.json','drivers/cogent/prepare_test.py','specs/grid-performance.md']+['drivers/cogent/native/patches/tilebinning/'+n for n in ['0075-adaptive-tile-bin-counts.patch','README.md','original-hashes.json','output-hashes.json']]);names=sorted(set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()));assert expected==names,names;assert git('rev-parse','HEAD').decode().strip()=='77da1dd8784b5ef699f8f7a0f07f7aa1bf0e62d4'
sources={n:sha(T/n)for n in names};git('add','--',*names);assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard');assert all(sha(T/n)==h and hashlib.sha256(git('show',':'+n)).hexdigest()==h for n,h in sources.items())
with(W/'staged.diff').open('xb')as f:f.write(git('diff','--cached','--binary'))
b=dict(base_commit=git('rev-parse','HEAD').decode().strip(),sources=sources,files=len(names),staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=(W/'staged.diff').stat().st_size,producer_sha256=sha(__file__))
with(W/'binding.json').open('x')as f:f.write(json.dumps(b,indent=2)+'\n')
print(json.dumps({k:b[k]for k in ['base_commit','files','staged_diff_bytes','staged_diff_sha256']}))
