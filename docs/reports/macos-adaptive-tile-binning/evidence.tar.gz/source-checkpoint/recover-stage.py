"""Bind the completed staged source after the stage producer's hash-type failure; no Git mutation."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
expected=sorted(['drivers/cogent/grid_tile_binning_offscreen_test.go','drivers/cogent/native/README.md','drivers/cogent/native/dependencies.json','drivers/cogent/prepare_test.py','specs/grid-performance.md']+['drivers/cogent/native/patches/tilebinning/'+n for n in ['0075-adaptive-tile-bin-counts.patch','README.md','original-hashes.json','output-hashes.json']]);names=git('diff','--cached','--name-only').decode().splitlines()
assert names==expected and not(W/'binding.json').exists()and not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard');assert git('rev-parse','HEAD').decode().strip()=='77da1dd8784b5ef699f8f7a0f07f7aa1bf0e62d4';assert git('diff','--cached','--binary')==(W/'staged.diff').read_bytes()
sources={n:sha(T/n)for n in names};assert all(hashlib.sha256(git('show',':'+n)).hexdigest()==h for n,h in sources.items())
b=dict(base_commit=git('rev-parse','HEAD').decode().strip(),sources=sources,files=len(names),staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=(W/'staged.diff').stat().st_size,producer_sha256=sha(__file__),staging_producer_sha256=sha(W/'stage.py'),prior_failure='stage.py completed git add and staged.diff write, then AttributeError hashing __file__ str with a Path-only lambda; no binding or commit was created.',recovery_git_mutations=False)
with(W/'binding.json').open('x')as f:f.write(json.dumps(b,indent=2)+'\n')
print(json.dumps({k:b[k]for k in ['base_commit','files','staged_diff_bytes','staged_diff_sha256','recovery_git_mutations']}))
