from pathlib import Path
import hashlib,json
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd');P.mkdir()
original=(T/'drivers/cogent/build/upstream/paint/renderers/sceneplan/packet.go').read_text();candidate=original
start=candidate.index('\t\tfor y := o.rect.Min.Y / TileSize;');end=candidate.index('\n\t\tif len(p.ops)*opWords*4',start)
candidate=candidate[:start]+'''\t\tx0, x1 := o.rect.Min.X/TileSize, (o.rect.Max.X-1)/TileSize
		y0, y1 := o.rect.Min.Y/TileSize, (o.rect.Max.Y-1)/TileSize
		if x0 <= x1 && y0 <= y1 {
			n := (x1-x0+1)*(y1-y0+1)
			if n > MaxTileReferences-refs { return nil, false }
			refs += n
			if keep { retainedRefs += n }
		}''' +candidate[end:]
start=candidate.index('\n\te := &Encoded')
candidate=candidate[:start]+'''
	// Dense rectangles use four difference corners and one prefix pass. Sparse
	// batches keep direct counting, avoiding a full-grid prefix for small damage.
	if retainedRefs > 2*len(counts) {
		for i, o := range p.ops {
			if compact && p.coveredClear(i) { continue }
			x0, x1 := o.rect.Min.X/TileSize, (o.rect.Max.X-1)/TileSize
			y0, y1 := o.rect.Min.Y/TileSize, (o.rect.Max.Y-1)/TileSize
			if x0 > x1 || y0 > y1 { continue }
			counts[y0*tiles.X+x0]++
			if x1+1 < tiles.X { counts[y0*tiles.X+x1+1]-- }
			if y1+1 < tiles.Y {
				counts[(y1+1)*tiles.X+x0]--
				if x1+1 < tiles.X { counts[(y1+1)*tiles.X+x1+1]++ }
			}
		}
		for y:=0; y<tiles.Y; y++ {
			running:=0
			for x:=0; x<tiles.X; x++ {
				at:=y*tiles.X+x
				running+=counts[at]; counts[at]=running
				if y>0 { counts[at]+=counts[at-tiles.X] }
			}
		}
	} else {
		for i,o:=range p.ops {
			if compact && p.coveredClear(i) { continue }
			for y:=o.rect.Min.Y/TileSize; y<=(o.rect.Max.Y-1)/TileSize; y++ {
				for x:=o.rect.Min.X/TileSize; x<=(o.rect.Max.X-1)/TileSize; x++ { counts[y*tiles.X+x]++ }
			}
		}
	}
''' +candidate[start:]
(P/'packet.go').write_text(candidate)
legacy=original[original.index('func (p *Packet) encode(compact bool)'):].replace('func (p *Packet) encode(compact bool)','func (p *Packet) originalBinningEncode(compact bool)',1)
test='''package sceneplan
import("encoding/binary";"image";"image/color";"image/draw";"math/rand";"reflect";"testing")
// Frozen pre-change encoder is the byte/admission oracle, independent of the
// revised rectangle arithmetic and difference/prefix implementation.
'''+legacy+'''
func binningFixture(width,height,n int, sparse bool)*Packet {
 b:=New(image.Rect(0,0,width,height));r:=rand.New(rand.NewSource(75))
 if !sparse { b.Draw(image.Rect(0,0,width,height),image.NewUniform(color.RGBA{31,47,63,255}),image.Point{},nil,image.Point{},draw.Src) }
 for i:=0;i<n;i++ {
  x,y:=r.Intn(width),r.Intn(height);w,h:=1+r.Intn(max(1,width-x)),1+r.Intn(max(1,height-y))
  if sparse { w,h=1,1 }
  rect:=image.Rect(x,y,min(width,x+w),min(height,y+h))
  b.Draw(rect,image.NewUniform(color.RGBA{11,17,23,25}),image.Point{},nil,image.Point{},draw.Src)
  b.Draw(rect,image.NewUniform(color.RGBA{61,83,101,255}),image.Point{},nil,image.Point{},draw.Over)
 }
 return b.Seal(true)
}
func TestVellumTileBinningOriginalOracle(t *testing.T) {
 for i:=0;i<96;i++ {
  p:=binningFixture(17+i%31,19+i%29,1+i*3,i%3==0)
  if p==nil { t.Fatal("fixture refused",i) }
  for _,compact:=range []bool{false,true} { got,ok:=p.encode(compact);want,accepted:=p.originalBinningEncode(compact);if ok!=accepted||!reflect.DeepEqual(got,want){ t.Fatal("original encoder bytes/admission differ",i,compact) } }
 }
 for _,p:=range []*Packet{stagingFixture(129,true),binningFixture(1519,1266,250,false),binningFixture(8192,2048,8,true),binningFixture(512,512,1025,false)} {
  if p==nil{ t.Fatal("fixture absent") };for _,compact:=range []bool{false,true} { got,ok:=p.encode(compact);want,accepted:=p.originalBinningEncode(compact);if ok!=accepted||!reflect.DeepEqual(got,want){ t.Fatal("large/mixed encoder bytes/admission differ",compact) } }
 }
}
func BenchmarkVellumTileBinning(b *testing.B) {
 cases:=[]struct{name string;p *Packet}{{"dense",binningFixture(512,512,400,false)},{"grid-sized",binningFixture(1519,1266,250,false)},{"sparse",binningFixture(8192,2048,8,true)}}
 for _,tc:=range cases { if tc.p==nil { b.Fatal("fixture absent",tc.name) };b.Run(tc.name,func(b *testing.B){
  for _,compact:=range []bool{false,true} { name:="all";if compact{name="compact"};b.Run(name,func(b *testing.B){
   b.Run("original",func(b *testing.B){ b.ReportAllocs();for i:=0;i<b.N;i++{if _,ok:=tc.p.originalBinningEncode(compact);!ok{b.Fatal("refused")}} })
   b.Run("candidate",func(b *testing.B){ b.ReportAllocs();for i:=0;i<b.N;i++{if _,ok:=tc.p.encode(compact);!ok{b.Fatal("refused")}} })
  }) }
 }) }
}
'''
(P/'tile_binning_vellum_test.go').write_text(test)
package=T/'drivers/cogent/build/upstream/paint/renderers/sceneplan';overlay={'Replace':{str(package/'packet.go'):str(P/'packet.go'),str(package/'tile_binning_vellum_test.go'):str(P/'tile_binning_vellum_test.go')}};(P/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
(W/'prototype.json').write_text(json.dumps(dict(base_commit='77da1dd8784b5ef699f8f7a0f07f7aa1bf0e62d4',source_mutated=False,original_sha256=hashlib.sha256(original.encode()).hexdigest(),files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in P.iterdir()}),indent=2)+'\n')
print(P)
