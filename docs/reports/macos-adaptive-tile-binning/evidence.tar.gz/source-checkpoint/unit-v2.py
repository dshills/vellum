from pathlib import Path
import importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd');O=P/'unit-v2';O.mkdir()
spec=importlib.util.spec_from_file_location('binning_unit_binding',W.parent/'macos-current-source-costs/build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from child_process import run_child
from sdk_environment import child_environment
source=m.identity();(O/'source.json').write_text(json.dumps(source,indent=2)+'\n');paths=[P/'packet.go',P/'tile_binning_v2_test.go',P/'unit-v2-overlay.json'];before={str(p):m.sha(p)for p in paths}
argv=['go','test','-race','-p=1','-count=1','-overlay='+str(P/'unit-v2-overlay.json'),'./paint/renderers/sceneplan'];env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};start=time.monotonic()
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(T/'drivers/cogent/build/upstream'),env=env,stdout=out,stderr=err,timeout=180,log_limit_bytes=1<<20)
d=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,source_sha256=m.sha(O/'source.json'),source_stable=m.identity()==source,overlays=before,overlays_stable=before=={str(p):m.sha(p)for p in paths},logs={n:dict(bytes=(O/n).stat().st_size,sha256=m.sha(O/n))for n in ['stdout','stderr']},producer_sha256=m.sha(__file__),native_runtime_executed=False)
with(O/'receipt.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d));assert r.returncode==0 and d['source_stable']and d['overlays_stable']
