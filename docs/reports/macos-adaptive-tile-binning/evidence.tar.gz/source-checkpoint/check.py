from pathlib import Path
import hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment
O=P/sys.argv[1];O.mkdir();argv={'format':['gofmt','-w',str(P/'packet.go'),str(P/'tile_binning_vellum_test.go')],'race':['go','test','-race','-p=1','-count=1','-overlay='+str(P/'overlay.json'),'./paint/renderers/sceneplan'],'bench':['go','test','-p=1','-run=^$','-bench=BenchmarkVellumTileBinning','-benchmem','-benchtime=200ms','-count=5','-overlay='+str(P/'overlay.json'),'./paint/renderers/sceneplan']}[sys.argv[1]]
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};before=subprocess.check_output(['git','status','--porcelain'],cwd=T,timeout=10);assert not before
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(T/'drivers/cogent/build/upstream'),env=env,stdout=out,stderr=err,timeout=360,log_limit_bytes=4<<20)
d=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,source_stable=subprocess.check_output(['git','status','--porcelain'],cwd=T,timeout=10)==before,source_mutated=False,overlays={str(p):sha(p)for p in [P/'packet.go',P/'tile_binning_vellum_test.go',P/'overlay.json']},logs={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']},producer_sha256=sha(Path(__file__)),native_runtime_executed=False)
with(O/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d));assert r.returncode==0 and d['source_stable']
