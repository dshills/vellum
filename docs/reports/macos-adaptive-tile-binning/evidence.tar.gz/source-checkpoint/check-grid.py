from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd')
spec=importlib.util.spec_from_file_location('tile_source_binding',W.parent/'macos-current-source-costs/build.py');binding=importlib.util.module_from_spec(spec);spec.loader.exec_module(binding)
from child_process import run_child
from sdk_environment import child_environment
sha=binding.sha;case=sys.argv[1];assert case in ['grid-original-v3','grid-candidate-v3'];O=P/case;O.mkdir();source=binding.identity();(O/'source.json').write_text(json.dumps(source,indent=2)+'\n');overlay=P/(case.removesuffix('-v3')+'.json');paths=[P/'packet.go',P/'grid_tile_binning_offscreen_test.go',overlay];before={str(p):sha(p)for p in paths}
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'};argv=['go','test','-race','-p=1','-tags=offscreen','-v','-count=1','-run=^TestVellumTileBinningActualGrid$','-overlay='+str(overlay),'.'];start=time.monotonic()
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(T/'drivers/cogent'),env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=4<<20)
d=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,source_sha256=sha(O/'source.json'),source_stable=source==binding.identity(),overlays=before,overlays_stable=before=={str(p):sha(p)for p in paths},logs={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']},producer_sha256=sha(Path(__file__)),native_runtime_executed=False)
with(O/'receipt.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d));assert r.returncode==0 and d['source_stable']and d['overlays_stable']
