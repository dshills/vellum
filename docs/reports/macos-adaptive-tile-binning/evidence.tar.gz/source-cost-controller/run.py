"""Two fixed serial source-cost diagnostics; not ordinary performance qualification."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,selectors,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
P=Path('/private/tmp/vellum-current-source-costs-native-77da1dd');T=Path('/private/tmp/vellum-macos-native-results-97aee13');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
build=module('current_cost_build',W/'build.py');sys.path.insert(0,str(W.parent/'macos-grid-native-stacks'));owned=module('current_owned_native',W.parent/'macos-grid-native-stacks/run.py');benchmark=module('current_cost_consumer',T/'scripts/benchmark-grid.py');sha=build.sha
ORDER=['cpu-fixed-r1-1000000','gpu-fixed-r1-1000000']
def read(p):return json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def validate(name,records):
 mode,height,_,row=name.split('-');rows=int(row)
 samples=benchmark.validate_records(records,rows,height=='variable',120,False,allow_source_details=True,gpu_scene_rendering=mode=='gpu')
 setup,ready,end=records[0],records[1],records[-1];need(all(type(r.get('window_geometry_guard'))is int and r['window_geometry_guard']==1 for r in [setup,ready,end]),'current native geometry required')
 need(setup['geometry_persistence_disabled_in_fixture']is True and ready['warmup']==128,'persistence/warmup')
 settings=setup['build_settings'];need(settings.get('vcs.revision')==build.COMMIT and settings.get('vcs.modified')=='false'and settings.get('CGO_ENABLED')=='1'and settings.get('-race','false')!='true','exact optimized source metadata')
 need(all(r.get('source_details')is True and all(r.get(k,False)is False for k in ['cpu_profile','alloc_profile','input_details'])for r in records),'source-details-only flags')
 distribution=benchmark.distribution([s['metrics']['ui_work_ns']for s in samples])
 return dict(samples=120,warmup=128,native_window=ready['native_window'],initial_grid_bounds=ready['initial_geometry'],warm_viewport=ready['warm_end_viewport'],ui_work_ns=distribution,diagnostic=True,warm_target_qualified=False,gpu_execution_verified=False,physical_input_verified=False)
def load_review():
 raw=(W/'native-readiness.json').read_bytes();review=json.loads(raw)
 need(review['execution_ready']and not review['unresolved_findings'],'execution review')
 review['_receipt_sha256']=hashlib.sha256(raw).hexdigest();return review
def approved_stable(review):
 return sha(W/'native-readiness.json')==review['_receipt_sha256']and all(sha(p)==h for p,h in review['inputs'].items())
def case_argv(name,binary):
 mode,height,_,rows=name.split('-')
 return [binary,'-perf','-rows='+rows,'-perf-samples=120','-perf-warmup=128','-perf-source-details']+(['-variable-rows']if height=='variable'else[])+(['-gpu-scene']if mode=='gpu'else[])
def saved_case(name,review):
 need(name in ORDER,'saved fixed case');out=P/'runs'/name
 receipt_raw=(out/'receipt.json').read_bytes();d=json.loads(receipt_raw);b=read(P/'build/receipt.json')
 expected=dict(case=name,argv=case_argv(name,b['binary']['path']),cwd=str(out/'runtime'),source_commit=build.COMMIT,source_sha256=sha(P/'build/source.json'),binary_sha256=b['binary']['sha256'],review_sha256=review['_receipt_sha256'],producer_sha256=review['inputs'][str(W/'run.py')],physical_input_generated=False,settings_changed=False)
 need(all(type(d.get(k))is type(v)and d[k]==v for k,v in expected.items()),'saved approved provenance '+name)
 need(d['result']=='VALID_CURRENT_SOURCE_DIAGNOSTIC'and d['error']is None and not d['cleanup_errors'],'saved terminal '+name)
 need(all(d[k]is True for k in ['source_stable','pins_stable','native_runtime_executed','logs_complete','lease_held_through_cleanup'])and d['stop_marker_at_exit']is False,'saved controls '+name)
 pid=d['pid'];ret=d['retirement'];need(type(pid)is int and pid>0 and ret['created']is True and ret['pid']==ret['group']==pid and ret['terminal']is True and ret['group_absent']is True and ret['exit_code']==d['exit_code']==0,'saved owned retirement '+name)
 observation=ret['group_observation'];need(observation['group']==pid and observation['members']==[] and len(observation['observation_sha256'])==64,'saved group observation '+name)
 owned_record=read(out/'owned.json');need(owned_record['pid']==pid and owned_record['native_runtime_executed']is True and all(k in d and d[k]==v for k,v in owned_record.items()),'saved launch ownership '+name)
 need(set(d['logs'])=={'stdout','stderr'},'saved exact logs '+name)
 for n,log in d['logs'].items():
  need(type(log['bytes'])is int and 0<=log['bytes']<=8<<20 and log['eof']is True and (out/n).stat().st_size==log['bytes']and sha(out/n)==log['sha256'],'saved raw '+name)
 records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];need(validate(name,records)==d['validation'],'saved validation '+name)
 return d,records,hashlib.sha256(receipt_raw).hexdigest()
def run(name,review):
 need(name in ORDER,'fixed case');stable=lambda:approved_stable(review);stopping=lambda:STOP.exists()or(P/'stop-live').exists()
 b=read(P/'build/receipt.json');source=read(P/'build/source.json');need(b['exit_code']==0 and b['source_stable']and b['overlays']is False and build.identity()==source,'source/build')
 binary=b['binary'];need(sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'binary binding')
 with owned.LiveLease()as lease:
  need(lease.held()and stable()and not stopping(),'lease/pins/stop admission')
  index=ORDER.index(name)
  if index:
   prior,_,_=saved_case(ORDER[index-1],review);owned.absent(prior['retirement']['pid'])
  out=P/'runs'/name;out.mkdir(parents=True,mode=0o700);(out/'runtime').mkdir(mode=0o700)
  mode,height,_,rows=name.split('-');argv=case_argv(name,binary['path'])
  # The CLI flag is pinned/reviewed against current main.go before execution.
  child=None;errors=[];counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()];eof=[False,False];start=time.monotonic()
  d=dict(case=name,argv=argv,cwd=str(out/'runtime'),source_commit=build.COMMIT,source_sha256=sha(P/'build/source.json'),binary_sha256=binary['sha256'],review_sha256=sha(W/'native-readiness.json'),producer_sha256=sha(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=None,native_runtime_executed=False,physical_input_generated=False,settings_changed=False)
  try:
   with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr,selectors.DefaultSelector()as selector:
    need(stable()and not stopping(),'final child admission');child=subprocess.Popen(argv,cwd=out/'runtime',env={**owned.child_environment(True),'GOMAXPROCS':'2'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);d.update(pid=child.pid,native_runtime_executed=True);(out/'owned.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(event='native.started',case=name,pid=child.pid)),flush=True)
    for i,pipe in enumerate([child.stdout,child.stderr]):selector.register(pipe,selectors.EVENT_READ,i)
    terminal=None
    while selector.get_map()or child.poll()is None:
     need(not stopping(),'human-return stop');need(time.monotonic()-start<180,'native watchdog')
     if child.poll()is not None:
      if terminal is None:terminal=time.monotonic()
      need(not selector.get_map()or time.monotonic()-terminal<5,'surviving pipe writers')
     for key,_ in selector.select(.1):
      data=os.read(key.fd,64<<10);i=key.data
      if not data:eof[i]=True;selector.unregister(key.fileobj);continue
      accepted=min(len(data),(8<<20)-counts[i]);stream=[stdout,stderr][i];need(stream.write(data[:accepted])==accepted,'short stream write');stream.flush();counts[i]+=accepted;digests[i].update(data[:accepted]);need(accepted==len(data),'log bound')
    d['exit_code']=child.wait(timeout=5)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   d['retirement']=owned.retire(child,'native',errors);d['cleanup_errors']=errors
   try:d['source_stable']=build.identity()==source;d['pins_stable']=stable()
   except BaseException as e:errors.append(dict(stage='source-observation',type=type(e).__name__,message=str(e)))
   try:
    d['logs']={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n),eof=eof[i])for i,n in enumerate(['stdout','stderr'])};d['logs_complete']=all(eof)and all(d['logs'][n]['bytes']==counts[i]and d['logs'][n]['sha256']==digests[i].hexdigest()for i,n in enumerate(['stdout','stderr']))
   except BaseException as e:errors.append(dict(stage='log-observation',type=type(e).__name__,message=str(e)))
   try:
    need(d['error']is None and not errors and d.get('exit_code')==0 and d.get('source_stable')and d.get('pins_stable')and d.get('logs_complete')and d['retirement']['terminal']and d['retirement']['group_absent']and lease.held()and not stopping(),'runtime controls')
    records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];d['validation']=validate(name,records)
    if index:
     paired,old,paired_sha=saved_case(ORDER[index-1],review)
     need(d['validation']['native_window']==paired['validation']['native_window'],'diagnostic native endpoints')
     benchmark.compare_geometry(old[2:-1],records[2:-1]);need(all(a['geometry']==b['geometry']for a,b in zip(old[2:-1],records[2:-1])),'diagnostic complete grid geometry')
     d['paired_geometry']=dict(case=ORDER[index-1],receipt_sha256=paired_sha,samples=120,full_grid_and_native_endpoints_equal=True)
   except BaseException as e:
    if d['error']is None:d['error']=dict(type=type(e).__name__,message=str(e))
   d.update(seconds=time.monotonic()-start,lease_held_through_cleanup=lease.held(),stop_marker_at_exit=stopping(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());d['result']='VALID_CURRENT_SOURCE_DIAGNOSTIC'if d['error']is None and not errors else'FAILED_OR_CANCELED_SOURCE_DIAGNOSTIC';(out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k]for k in ['case','result','error','seconds']}|{'metrics':d.get('validation',{}).get('ui_work_ns')}),flush=True)
  need(d['result']=='VALID_CURRENT_SOURCE_DIAGNOSTIC','native case failed')
def main():
 review=load_review()
 need(sys.argv[1:]in [['--all']]+[[name]for name in ORDER],'fixed selection')
 for name in(ORDER if sys.argv[1]=='--all'else[sys.argv[1]]):run(name,review)
if __name__=='__main__':main()
