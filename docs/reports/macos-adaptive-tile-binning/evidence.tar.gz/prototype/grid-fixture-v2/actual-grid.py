from pathlib import Path
import json,re
T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd')
s=(T/'drivers/cogent/build/upstream/paint/renderers/sceneplan/covered_encoding_test.go').read_text();a=s.index('func replayEncodedGPU');b=s.index('\nfunc Test',a);interpreter=s[a:b].replace('e *Encoded','e *sceneplan.Encoded')
for old,new in [('opWords','16'),('TileSize','sceneplan.TileSize'),('Spans','sceneplan.Spans'),('Pixels','sceneplan.Pixels')]:interpreter=re.sub(r'\b'+old+r'\b',new,interpreter)
code='''//go:build offscreen
package cogent
import("bytes";"crypto/sha256";"encoding/binary";"encoding/json";"fmt";"image";"image/draw";"strconv";"testing";"cogentcore.org/core/math32";"cogentcore.org/core/paint/renderers/rasterx";"cogentcore.org/core/paint/renderers/sceneplan";"github.com/dshills/vellum/app";"github.com/dshills/vellum/ui";"github.com/dshills/vellum/virtual")
'''+interpreter+'''
type tileBinningSource struct{nativeGridSource}
func(s *tileBinningSource)Cell(row,column string)(string,error){ r,err:=strconv.Atoi(row[4:]);if err!=nil{return "",err};c,err:=strconv.Atoi(column[1:]);return strconv.Itoa((r*20+c)*37%10000),err }
type tileBinningVariableSource struct{*tileBinningSource}
func(s *tileBinningVariableSource)RowOffset(i int)(int,error){ if i<0||i>s.rows{return 0,virtual.ErrGridRange};n:=i/4*48;for j:=0;j<i%4;j++{n+=[]int{9,11,13,15}[j]};return n,nil }
func(s *tileBinningVariableSource)RowAt(pixel int)(int,error){max,_:=s.RowOffset(s.rows);if pixel<0||pixel>=max{return 0,virtual.ErrGridRange};row,rem:=pixel/48*4,pixel%48;for _,h:=range []int{9,11,13,15}{if rem<h{return row,nil};row++;rem-=h};return 0,virtual.ErrGridRange }
func TestVellumTileBinningActualGrid(t *testing.T){
 for _,dpi:=range []float32{96,162,192}{for _,variable:=range []bool{false,true}{t.Run(fmt.Sprintf("%g/%v",dpi,variable),func(t *testing.T){
  source:=&tileBinningSource{nativeGridSource:nativeGridSource{rows:1000000,revision:1}};var input virtual.GridSource=source;if variable{input=&tileBinningVariableSource{source}}
  columns:=make([]virtual.GridColumn,20);for i:=range columns{columns[i]=virtual.GridColumn{ID:fmt.Sprint("c",i),Title:fmt.Sprint("C",i),Width:96}}
  model,err:=virtual.NewGrid(input,columns,virtual.GridConfig{RowHeight:12,HeaderHeight:24,FrozenColumns:2,OverscanRows:1,OverscanColumns:1},virtual.GridViewport{Width:768,Height:624});if err!=nil{t.Fatal(err)}
  config:=manualConfig(t,7);config.LogicalDPI=dpi;config.Theme.Default.Typography=ui.Some(ui.Typography{Family:"Noto Sans",Size:15})
  a,err:=app.New(app.Config{QueueCapacity:32});if err!=nil{t.Fatal(err)}
  view:=func()ui.Node{return ui.Node{ID:"root",Kind:ui.Column,Style:ui.Style{Padding:ui.Some(ui.Insets{}),Gap:ui.Some(float32(0))},Children:[]ui.Node{{ID:"g",Kind:ui.DataGrid,Grid:model,Style:ui.Style{Grow:ui.Some(float32(0)),MinSize:ui.Some(ui.Size{Width:1299,Height:1060}),MaxSize:ui.Some(ui.Size{Width:1299,Height:1060})}}}}}
  if err=a.Open(app.Window{ID:"one",Title:"Grid encoder",Width:1500*dpi/160,Height:1250*dpi/160,View:view});err!=nil{t.Fatal(err)}
  m,err:=NewManual(testContext,a,config);if err!=nil{t.Fatal(err)};t.Cleanup(func(){if e:=m.Close(testContext);e!=nil{t.Error(e)}})
  for frame,step:=range []image.Point{{},{0,12},{96,12},{-96,-12}}{
   if frame>0{if err=a.Do(func(){if e:=model.Scroll(step.X,step.Y);e!=nil{t.Error(e)};_ = a.Invalidate("one")});err!=nil{t.Fatal(err)}};gridFrame(t,m)
   captured,err:=m.Capture(testContext,"one");if err!=nil{t.Fatal(err)}
   if err=a.Do(func(){scene:=m.implementation.find("one").state.body.Scene;scene.RenderWidget();commands:=scene.Painter.RenderDone();rs:=rasterx.New(math32.FromPoint(scene.SceneGeom.Size)).(*rasterx.Renderer);defer rs.Release();packet:=rs.ScenePacket(commands);if packet==nil{t.Fatal("actual packet refused")}
    encoded,ok:=packet.EncodeGPU();if !ok{t.Fatal("actual encoded refused")};original,ok:=packet.Encode();if !ok{t.Fatal("original layout refused")}
    expected:=image.NewRGBA(packet.Bounds());if !packet.Replay(expected){t.Fatal("packet replay refused")};got:=image.NewRGBA(packet.Bounds());replayEncodedGPU(t,encoded,got)
    if !bytes.Equal(expected.Pix,got.Pix)||!bytes.Equal(expected.Pix,captured.Pix){t.Fatal("serialized/packet/actual grid pixels differ")}
    h:=sha256.New();for _,data:=range [][]byte{encoded.Ops,encoded.Rows,encoded.Refs,encoded.Data}{h.Write(data)};record:=map[string]any{"dpi":dpi,"variable":variable,"frame":frame,"bounds":packet.Bounds(),"operations":packet.Operations(),"packet_bytes":packet.Bytes(),"tiles":encoded.Tiles,"original_refs":len(original.Refs)/4,"retained_refs":len(encoded.Refs)/4,"dense_selected":len(encoded.Refs)/4>2*encoded.Tiles.X*encoded.Tiles.Y,"encoded_sha256":fmt.Sprintf("%x",h.Sum(nil)),"pixels_sha256":fmt.Sprintf("%x",sha256.Sum256(got.Pix))};line,_:=json.Marshal(record);t.Log("BINNING",string(line))
   });err!=nil{t.Fatal(err)}
  }
 })}}
}
'''
(P/'grid_tile_binning_offscreen_test.go').write_text(code)
virtual=str(T/'drivers/cogent/grid_tile_binning_offscreen_test.go')
for name,candidate in [('grid-original',False),('grid-candidate',True)]:
 changes={virtual:str(P/'grid_tile_binning_offscreen_test.go')}
 if candidate:changes[str(T/'drivers/cogent/build/upstream/paint/renderers/sceneplan/packet.go')]=str(P/'packet.go')
 (P/(name+'.json')).write_text(json.dumps({'Replace':changes},indent=2)+'\n')
print('Prepared 24 actual retained-grid software frames with serialized-byte interpreter and full pixel oracle.')
