"""Build clean committed stage75 grid and explicit GPU test binaries; no execution."""
from pathlib import Path
import hashlib,json,plistlib,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
P=Path('/private/tmp/vellum-tile-binning-native-75')
BASE=Path('/private/tmp/vellum-current-source-costs-native-77da1dd')
S=W.parent/'macos-tile-binning'
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
def committed():
 d=read(S/'commit-receipt.json')
 need(d['result']=='REVIEWED_TILE_BINNING_SOURCE_COMMITTED_AND_INTEGRATED'and d['both_clean']and d['canonical_promoted'],'reviewed source commit')
 return d['commit']
def identity():
 commit=committed();need(git('rev-parse','HEAD').decode().strip()==commit and not git('status','--porcelain','-z'),'clean exact candidate')
 names=git('ls-files','-z').decode().split('\0')[:-1];files={n:sha(T/n)for n in names};prepared={}
 for module in ['upstream','typesetting']:
  for p in(T/'drivers/cogent/build'/module).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(T/'drivers/cogent/build').as_posix()]=sha(p)
 need(len(files)==4650 and len(prepared)==6246,'source/prepared count')
 return dict(commit=commit,files=files,prepared=prepared)
def environment():return {**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
def main():
 P.mkdir(mode=0o700);out=P/'build';out.mkdir();source=identity();(out/'source.json').write_text(json.dumps(source,indent=2)+'\n')
 baseline=read(BASE/'build/source.json');binding=read(S/'binding.json')
 need(baseline['commit']==binding['base_commit'],'baseline commit')
 source_delta={n for n in set(source['files'])|set(baseline['files'])if source['files'].get(n)!=baseline['files'].get(n)}
 prepared_delta={n for n in set(source['prepared'])|set(baseline['prepared'])if source['prepared'].get(n)!=baseline['prepared'].get(n)}
 need(source_delta==set(binding['sources']),'exact nine source delta')
 need(prepared_delta=={'upstream/paint/renderers/sceneplan/packet.go','upstream/paint/renderers/sceneplan/tile_binning_vellum_test.go'},'exact two prepared delta')
 exe=out/'loadedgrid.app/Contents/MacOS/loadedgrid';exe.parent.mkdir(parents=True)
 plist=exe.parent.parent/'Info.plist'
 with plist.open('xb')as f:plistlib.dump(dict(CFBundleIdentifier='com.vellum.tilebinning',CFBundleName='Vellum tile binning',CFBundleExecutable='loadedgrid',CFBundlePackageType='APPL',CFBundleVersion='1',NSHighResolutionCapable=True),f)
 jobs=[('grid',T/'examples/loadedgrid',['go','build','-p=1','-trimpath','-o',str(exe),'.'],exe)]
 upstream=T/'drivers/cogent/build/upstream'
 for name,package in [('gpu-scene','./paint/renderers/gpuscene'),('gpu-drawer','./gpu/gpudraw')]:
  binary=out/(name+'.test');jobs.append((name,upstream,['go','test','-c','-p=1','-trimpath','-o',str(binary),package],binary))
 results={};start=time.monotonic();d=dict(result='INCOMPLETE',error=None,source_sha256=sha(out/'source.json'),producer_sha256=sha(__file__),source_delta=sorted(source_delta),prepared_delta=sorted(prepared_delta),native_runtime_executed=False,overlays=False,race=False)
 try:
  for name,cwd,argv,binary in jobs:
   job=out/name;job.mkdir();before=time.monotonic()
   with(job/'stdout').open('xb')as stdout,(job/'stderr').open('xb')as stderr:r=run_child(argv,cwd=str(cwd),env=environment(),stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20)
   record=dict(argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-before,source_stable=identity()==source,logs={n:dict(bytes=(job/n).stat().st_size,sha256=sha(job/n))for n in ['stdout','stderr']})
   if binary.exists():record['binary']=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary))
   results[name]=record
   need(r.returncode==0 and record['source_stable'],'build '+name)
   version=run_child(['go','version','-m',str(binary)],env=environment(),capture_output=True,timeout=20);need(version.returncode==0 and not version.stderr,'build metadata '+name);(job/'go-version.txt').write_bytes(version.stdout);record['metadata_sha256']=sha(job/'go-version.txt')
   if name=='grid':
    text=version.stdout.decode();need('vcs.revision='+source['commit']in text and 'vcs.modified=false'in text and 'CGO_ENABLED=1'in text and '-race=true'not in text,'optimized clean grid metadata')
   (job/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
   print(json.dumps(dict(build=name,exit_code=r.returncode,seconds=record['seconds'])),flush=True)
  d.update(result='CLEAN_NATIVE_BINARIES_BUILT',source_stable=identity()==source,source_commit=source['commit'],baseline_source_sha256=sha(BASE/'build/source.json'),baseline_binary=read(BASE/'build/receipt.json')['binary'],plist_sha256=sha(plist))
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  d.update(jobs=results,seconds=time.monotonic()-start)
  with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps(dict(result=d['result'],error=d['error'],seconds=d['seconds'])),flush=True)
if __name__=='__main__':main()
