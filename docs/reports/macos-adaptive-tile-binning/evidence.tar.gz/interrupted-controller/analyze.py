"""Revalidate every raw result and matched geometry before reporting timing effects."""
from pathlib import Path
import importlib.util,json,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('tile_native_analysis_run',W/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
review=r.load_review();r.need(r.approved_stable(review),'analysis pins');r.need(r.build.identity()==r.read(r.P/'build/source.json'),'analysis source')
cases={};raw={};grouped={};gpu={}
for name in r.ORDER:
 receipt,receipt_sha=r.saved_case(name,review);v=receipt['validation'];cases[name]=dict(receipt_sha256=receipt_sha,seconds=receipt['seconds'],validation=v)
 if name in r.ROOTS:gpu[name]=v;continue
 records=[json.loads(line)for line in(r.P/'runs'/name/'stdout').read_bytes().splitlines()];raw[name]=records
 cohort,mode,height,repeat,rows=name.split('-');grouped.setdefault(f'{cohort}-{mode}-{height}',[]).append(records[2:-1])
pairs={}
for repeat in range(1,6):
 for mode in['cpu','gpu']:
  for height in['fixed','variable']:
   a,b=[f'{cohort}-{mode}-{height}-r{repeat}-1000000'for cohort in['baseline','candidate']]
   r.need(cases[a]['validation']['native_window']==cases[b]['validation']['native_window'],'matched native endpoints '+a);r.benchmark.compare_geometry(raw[a][2:-1],raw[b][2:-1]);r.need(all(x['geometry']==y['geometry']for x,y in zip(raw[a][2:-1],raw[b][2:-1])),'complete geometry '+a)
   before,after=[cases[n]['validation']['ui_work_ns']for n in[a,b]];pairs[f'{mode}-{height}-r{repeat}']=dict(samples=120,full_grid_and_native_endpoints_equal=True,candidate_to_baseline={metric:after[metric]/before[metric]for metric in['p50','p95','p99']})
groups={name:r.benchmark.summarize(runs)for name,runs in grouped.items()};comparisons={}
for mode in['cpu','gpu']:
 for height in['fixed','variable']:
  ratios=[pairs[f'{mode}-{height}-r{repeat}']['candidate_to_baseline']for repeat in range(1,6)]
  comparisons[f'{mode}-{height}']={metric:dict(median=statistics.median(p[metric]for p in ratios),minimum=min(p[metric]for p in ratios),maximum=max(p[metric]for p in ratios),per_pair=[p[metric]for p in ratios])for metric in['p50','p95','p99']}
result=dict(status='MATCHED_NATIVE_TILE_BINNING_RESULTS_VALIDATED',cases=cases,groups=groups,pairs=pairs,comparisons=comparisons,total_processes=len(r.ORDER),ordinary_processes=len(raw),ordinary_samples=120*len(raw),geometry_pairs=120*len(pairs),gpu_readback_roots=sum(v['root_count']for v in gpu.values()),individual_p95_failures={cohort:sum(c['validation']['ui_work_ns']['p95']>4000000 for name,c in cases.items()if name.startswith(cohort+'-'))for cohort in['baseline','candidate']},individual_p99_failures={cohort:sum(c['validation']['ui_work_ns']['p99']>6000000 for name,c in cases.items()if name.startswith(cohort+'-'))for cohort in['baseline','candidate']},source_sha256=r.sha(r.P/'build/source.json'),readiness_sha256=review['_sha256'],analyzer_sha256=r.sha(__file__),native_gpu_readback_scoped=True,ordinary_grid_gpu_execution_verified=False,physical_input_verified=False,native_gpu_memory_qualified=False,old_results_requalified=False,full_macos_qualified=False)
r.need(r.approved_stable(review),'analysis pins changed')
with(W/'analysis.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in['status','total_processes','ordinary_samples','geometry_pairs','gpu_readback_roots','comparisons','individual_p95_failures','individual_p99_failures']}))
