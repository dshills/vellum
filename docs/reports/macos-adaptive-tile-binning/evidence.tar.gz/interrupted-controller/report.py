"""Package sealed, independently reviewed source/correctness/timing evidence."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;S=W.parent/'macos-tile-binning';COST=W.parent/'macos-current-source-costs';T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-tile-binning-native-75');CHECKS=Path('/private/tmp/vellum-tile-binning-checks-77da1dd');PROTOTYPE=Path('/private/tmp/vellum-tile-binning-candidate-77da1dd');CP=Path('/private/tmp/vellum-current-source-costs-native-77da1dd');D=T/'docs/reports/macos-adaptive-tile-binning'
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
review=read(W/'result-review.json');need(review['result_accepted']and not review['unresolved_findings']and all(sha(p)==h for p,h in review['inputs'].items()),'result review')
need((P/'stop-live').exists()and(CP/'stop-live').exists(),'campaigns sealed')
a=read(W/'analysis.json');need(a['ordinary_processes']==40 and a['ordinary_samples']==4800 and a['geometry_pairs']==2400 and a['gpu_readback_roots']==6,'native result scope')
commit=read(S/'commit-receipt.json');need(commit['result']=='REVIEWED_TILE_BINNING_SOURCE_COMMITTED_AND_INTEGRATED','source checkpoint');binding=read(S/'binding.json');need(all(sha(T/n)==h for n,h in binding['sources'].items()),'source bytes')
cost_review=read(COST/'result-review.json');need(cost_review['result_accepted']and not cost_review['unresolved_findings']and all(sha(p)==h for p,h in cost_review['inputs'].items()),'source-cost review')
members={};excluded={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'artifact symlink')
  if not p.is_file()or'__pycache__'in p.parts:continue
  name=label+p.relative_to(root).as_posix()
  if p.name=='loadedgrid'and p.parent.name=='MacOS'or p.name in['gpu-scene.test','gpu-drawer.test']:
   excluded[name]=dict(bytes=p.stat().st_size,sha256=sha(p),reason='compiled binary excluded; source/build/runtime identity retained');continue
  members[name]=p
for label,root in[('source-checkpoint/',S),('prototype/',PROTOTYPE),('source-checks/',CHECKS),('native-controller/',W),('native/',P),('source-cost-controller/',COST),('source-cost-native/',CP)]:add(label,root)
for n in binding['sources']:members['source/'+n]=T/n
for n in['app/app.go','scripts/child_process.py','scripts/sdk_environment.py','scripts/benchmark-grid.py']:members['shared/'+n]=T/n
for n,p in{'owned-run.py':W.parent/'macos-grid-native-stacks/run.py','owned-build.py':W.parent/'macos-grid-native-stacks/build.py','commit-guard.py':W.parent/'macos-grid-native-stacks/commit-pending.py','live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),'prism-retirement.py':Path('/private/tmp/vellum-native-attestation-probe-20261016/run-verifier.py')}.items():members['shared/'+n]=p
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<650 and expanded<96<<20,'archive bounds');D.mkdir()
manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},excluded_executables=excluded,count=len(members),expanded_bytes=expanded)
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in members.items():
    data=p.read_bytes();need(len(data)==manifest['files'][name]['bytes']and hashlib.sha256(data).hexdigest()==manifest['files'][name]['sha256'],'archive input drift');entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive member count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive verification')
result=dict(status='REVIEWED_ADAPTIVE_TILE_BINNING_CHECKPOINT',source_commit=commit['commit'],baseline_commit=binding['base_commit'],sources=binding['sources'],production_packet_sha256='9433c82a204fd19d3dbb7ff29d8abe959f5ae580e2c9e0a7b93586bcf1e9fd86',source_checks={n:read(CHECKS/n/'receipt.json')for n in['prepare-v2','prepare-unit-v2','unit-boundaries','driver-v2','vet-v2']},grid_parity=read(S/'grid-parity.json'),synthetic_benchmark=read(S/'bench-analysis.json'),source_cost_diagnostics=read(COST/'analysis.json'),native=a,review=dict(source_sha256=sha(S/'source-review.json'),source_final_sha256=sha(S/'final-review.json'),prism_report_sha256=sha(S/'prism/prism.json'),provider_disposition=read(S/'provider-disposition.json'),native_readiness_sha256=sha(W/'native-readiness.json'),native_results_sha256=sha(W/'result-review.json'),provider_calls=1,provider='anthropic',model='claude-sonnet-5-5'),evidence=dict(file='evidence.tar.gz',sha256=sha(D/'evidence.tar.gz'),compressed_bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded,manifest_sha256=sha(D/'evidence.manifest.json')),full_macos_qualified=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for name,group in a['groups'].items():
 cohort,mode,height=name.split('-');v=group['ui_work_ns']['pooled'];rows.append(f"| {cohort} | {'CPU'if mode=='cpu'else'GPU requested'} | {height} | {v['p95']/1e6:.3f} | {v['p99']/1e6:.3f} |")
ratios=[]
for name,metrics in a['comparisons'].items():
 mode,height=name.split('-');v=metrics['p95'];ratios.append(f"| {'CPU'if mode=='cpu'else'GPU requested'} | {height} | {v['median']:.3f} | {v['minimum']:.3f}–{v['maximum']:.3f} |")
p95=a['individual_p95_failures'];p99=a['individual_p99_failures']
(D/'README.md').write_text(f'''# Adaptive scene tile bins — macOS checkpoint

Vellum now counts dense scene tile bins with rectangle differences and an
in-place prefix pass. Sparse batches keep direct counting. Exact original
operation, byte and tile-reference limits remain enforced before compaction;
serialized bytes, painter order and detached ownership are unchanged. The owned
dependency stage is 0075, committed as `{commit['commit']}`.

## Correctness and review

Preparation, its unit suite, affected scene/compositor race tests, the complete
offscreen adapter race suite and vet passed against exact source/prepared bytes.
A frozen original encoder checks admission and every serialized byte, including
dense/sparse branch edges, high counts, mixed masks/pixels/spans and public
Builder fixtures immediately below, at and above reference/encoded-byte limits.
Encoded-byte cases differ by four bytes, the smallest reachable alignment.
A deliberately wrong difference-corner sign fails the byte oracle.

Twenty-four actual retained-grid software frames cover fixed/variable heights,
scrolling and supported manual DPI 96/160/192. Original/candidate encoded and
pixel vectors match; integer encoded replay, packet replay and complete captured
pixels agree. This is procedural-source correctness coverage. Unsupported manual
DPI 162, an initial compile failure and earlier strict wrappers that failed on
17 generated reference PNGs remain preserved. Generated missing goldens are not
regression evidence; final fresh checks passed with exact prepared-file sets.

One Prism review used Anthropic Claude Sonnet 5.5. Its medium concern about
`t.Fatal` in `Application.Do` was independently refuted: `Do` directly invokes
the closure synchronously on the calling test goroutine. The original finding,
exit 1, complete nine-file payload and precise disposition remain in evidence.
Internal source, commit, native-readiness and result reviews are preserved.

Six explicit native GPU roots passed with actual execution/readback: integer
compositing, shared drawer ordering/fallback, text/paths, covered uniforms,
checked input refusal/recovery and three-batch shared-to-owned texture reuse.
Their GPU evidence applies to those fixtures. Ordinary grid measurements below
do not prove GPU completion for individual grid tickets.

## Matched ordinary native measurements

Clean optimized CGO binaries compare baseline `77da1dd` and candidate `29ec8c9`
without overlays, race or profiler/detail flags. Only the encoder production
file changes in prepared dependencies; the other prepared delta adds tests.
Five repeat sets alternate CPU/GPU, fixed/variable and adjacent build order.
Forty processes warm 128 routed events and measure 120 each: 4,800 frames, with
2,400 complete per-sample grid/native endpoint geometry comparisons.

Both cohorts use the corrected current viewport, the same million stored rows
and unchanged minimum 400 clipped cells / 50 rows / eight columns. This is a
matched implementation comparison; old viewport failures retain their status.
Times below are milliseconds, pooled across 600 samples per group.

| Build | Mode | Heights | P95 ms | P99 ms |
|---|---|---|---:|---:|
'''+ '\n'.join(rows)+f'''

Per-pair candidate/baseline p95 ratios show repeat variation. Lower is faster;
these are total UI-work ratios and do not isolate encoder cost.

| Mode | Heights | Median ratio | Pair range |
|---|---|---:|---:|
'''+ '\n'.join(ratios)+f'''

The unchanged 4 ms p95 limit fails in {p95['baseline']}/20 baseline and
{p95['candidate']}/20 candidate processes; 6 ms p99 fails in
{p99['baseline']}/20 and {p99['candidate']}/20. Complete table/tree performance
qualification remains open. Synthetic dense encoder microbenchmarks had
24–34% lower medians; sparse medians were 4–6% higher with substantial ordering
variation. Those separate results do not establish general frame gains.

The preceding two source-cost diagnostic processes are also preserved. Their
nested raster/copy/capture/encode/lease/resource/input intervals describe attempted
host work; they must not be added or treated as GPU execution/transfer time.

## Scope and evidence

Every owned process was reaped and observed absent. Reviewed source, preparation,
binary and launch bindings, bounded streams/EOF, watchdogs, exclusive lease and
human-return stops governed collection. Both campaigns are sealed. No OS input
source, VoiceOver, clipboard, power or permission settings were changed.
Grid scrolling entered the native event deque programmatically; physical
pointer/key interaction and presentation latency remain unverified.

Native/GPU memory, the complete table/tree workload, 1,000 controls plus canvas,
endurance, cross-display, broader accessibility and full macOS qualification
remain open. No public release is qualified by this checkpoint.

See [structured results](result.json), [manifest](evidence.manifest.json),
[raw evidence](evidence.tar.gz) and [performance contract](../../../specs/grid-performance.md).
''')
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Adaptive scene tile bins](macos-adaptive-tile-binning/README.md): owned stage0075, byte/pixel limits and native GPU checks; matched ordinary grid results retain the open performance gate.\n')
p=T/'docs/implementation.md';p.write_text(p.read_text()+'''\n## Adaptive scene tile bin counting\n\nOwned stage0075 replaces dense per-reference count loops with four rectangle\ndifference corners and an in-place prefix, while sparse batches count directly.\nOriginal admission limits, serialized bytes, painter order and ownership remain\nunchanged. [The checkpoint](reports/macos-adaptive-tile-binning/README.md)\nincludes frozen byte/admission oracles,24 retained-grid software frame pairs,\nsix explicit native GPU readback roots and40 matched ordinary grid processes.\nThe complete table/tree, native/GPU memory and full Mac gates remain open.\n''')
p=T/'specs/macos-completion.md';p.write_text(p.read_text()+f'''\n## Adaptive scene tile bins — source and native checkpoint\n\n[Stage0075 evidence](../docs/reports/macos-adaptive-tile-binning/README.md)\nbinds clean source29ec8c9, unchanged admission/serialized bytes and24 actual\nretained-grid software frame pairs. Six explicit native GPU readback roots pass.\nForty matched ordinary baseline77da1dd/candidate29ec8c9 processes cover CPU/GPU\nrequested modes and fixed/variable million-row grids at identical geometry.\nCandidate p95 fails4ms in {p95['candidate']}/20 processes and p99 fails6ms in\n{p99['candidate']}/20. P6/P11 and complete Mac qualification remain open.\nOrdinary tickets do not prove GPU execution or native/GPU memory, and programmed\nevent routing does not qualify physical interaction.\n''')
print(json.dumps(dict(report=str(D),members=len(members),expanded_bytes=expanded,archive_sha256=sha(D/'evidence.tar.gz'),archive_bytes=(D/'evidence.tar.gz').stat().st_size)))
