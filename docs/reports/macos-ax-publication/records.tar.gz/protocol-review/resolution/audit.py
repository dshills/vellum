"""Read-only supplemental provider/disposition/doc linkage audit; stdlib only."""
import ast
import hashlib
import json
import re
from pathlib import Path

ROOT = Path('/private/tmp/vellum-large-data')
Q = Path('/private/tmp/vellum-ax-publication-cost')
OUT = Path(__file__).parent
FILES = {}


def read(path):
    path = Path(path)
    value = path.read_bytes()
    FILES[str(path)] = hashlib.sha256(value).hexdigest()
    return value


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def record(path):
    return json.loads(read(path))


def main():
    receipt_path = Q / 'internal-receipt-review.json'
    receipt_sha = sha(receipt_path)
    assert receipt_sha == '54f4a14622bec6be5a592c7f8def99e4f61209a47047c2dea6c6231915d03ffb'
    receipt = record(receipt_path)
    assert receipt['decision'] == 'APPROVED_RECEIPTS' and receipt['findings'] == []
    resolution = Q / 'resolution'
    correction = record(resolution / 'correction.json')
    report_path = ROOT / correction['path']
    before, after = read(resolution / 'report-before.md'), read(resolution / 'report-after.md')
    assert correction['result'] == 'DOC_ONLY_ADDENDUM' and correction['selected_source_unchanged'] is True
    assert sha(resolution / 'report-before.md') == correction['before_sha256'] == receipt['reviewed_file_sha256'][str(report_path)]
    assert sha(resolution / 'report-after.md') == correction['after_sha256'] == sha(report_path)
    assert read(report_path) == after
    producer = read(resolution / 'producer.py.txt').decode()
    assert sha(resolution / 'producer.py.txt') == correction['producer_sha256']
    values = {}
    for node in ast.walk(ast.parse(producer)):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ('needle', 'paragraph'):
                    values[target.id] = ast.literal_eval(node.value)
    assert before.decode().count(values['needle']) == 1
    assert before.decode().replace(values['needle'], values['needle'] + values['paragraph'], 1).encode() == after
    assert 'provider result is not represented as a\nzero-finding pass' in values['paragraph']
    # Every original byte reviewed remains identical except this exact retained report addendum.
    for path, expected in receipt['reviewed_file_sha256'].items():
        if path == str(report_path):
            continue
        assert sha(path) == expected, path

    raw = record(Q / 'prism/prism.json')
    process = record(Q / 'prism/process.json')
    inputs = record(Q / 'prism/inputs.json')
    assert process['exit_code'] == 1 and process['error'] is None
    assert process['before'] == process['after'] == inputs['files'] and len(inputs['files']) == 11
    assert process['source_index_unchanged'] is True
    assert process['prism_sha256'] == sha(Q / 'prism/prism.json')
    for filename, key in (('producer.py.txt', 'producer_sha256'), ('stdout.log', 'stdout_sha256'), ('stderr.log', 'stderr_sha256')):
        assert sha(Q / 'prism' / filename) == process[key]
    assert inputs['staged_diff_sha256'] == sha(Q / 'prism/staged.diff.txt')
    assert inputs['staged_diff_bytes'] == len(read(Q / 'prism/staged.diff.txt'))
    assert len(raw['findings']) == 1 and raw['discarded'] == raw['suppressed'] == []
    finding = raw['findings'][0]
    assert finding['id'] == 'eb6ac100ffff8f63' and finding['severity'] == 'medium' and finding['confidence'] == .3
    assert 'If a.Do runs the callback on a different goroutine' in finding['message']
    coverage = raw['coverage']
    assert coverage['complete'] is True and coverage['files'] == 11
    assert coverage['llmCalls'] == coverage['chunks'] == 3 and coverage['excluded'] == coverage['skipped'] == []
    assert coverage['truncatedBytes'] == 0
    assert coverage['reviewer'] == [{'provider': 'anthropic', 'model': 'claude-sonnet-5-5'}]
    for path, expected in inputs['files'].items():
        assert (sha(resolution / 'report-before.md') if path == correction['path'] else sha(ROOT / path)) == expected

    local = record(Q / 'internal-prism-finding-review.json')
    assert local['status'] == 'REFUTED' and local['finding_id'] == finding['id'] and local['source_changes_required'] is False
    assert local['raw_review']['finding'] == finding and local['raw_review']['coverage'] == coverage
    assert local['raw_review']['sha256'] == sha(Q / 'prism/prism.json')
    assert local['provider_process']['sha256'] == sha(Q / 'prism/process.json') and local['provider_process']['exit_code'] == 1
    assert sha(Q / 'internal-prism-finding-review.json') == correction['finding_review_sha256']
    assert sha(Q / 'prism/process.json') == correction['prism_process_sha256']
    for path, expected in local['source_sha256'].items():
        assert sha(ROOT / path) == expected
    app_source = read(ROOT / 'app/app.go').decode()
    do_body = app_source.split('func (a *Application) Do(fn func()) error {', 1)[1].split('// Post admits', 1)[0]
    assert '\n\tfn()\n' in do_body and '\n\tgo ' not in do_body
    test_source = read(ROOT / 'drivers/cogent/accessibility_geometry_offscreen_test.go').decode()
    calls = [i for i, line in enumerate(test_source.splitlines(), 1)
             if 'assertNativeGeometryProjection(t,' in line and not line.startswith('func ')]
    assert calls == local['all_helper_call_lines'] == [75, 124, 135]
    test_body = test_source.split('func TestNativeAccessibilityGeometryOmitsScopedGridOnly', 1)[1]
    assert 't.Run(fmt.Sprint(dpi), func(t *testing.T)' in test_body
    assert '\n\t\t\tgo ' not in test_body and '.Post(' not in test_body and 'PostWindow(' not in test_body
    assert 'if err := a.Do(func() {' in test_body
    assert 'check("ready")' in test_body and 'check("editing")' in test_body and 'check("scrolled")' in test_body
    state = record(Q / 'checks/qualification.json')['after']
    assert correction['selected_source_map_sha256'] == hashlib.sha256(json.dumps(state['source'], sort_keys=True).encode()).hexdigest()
    for path, expected in state['source'].items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected
    assert record(Q / 'native/qualification.json')['after'] == record(Q / 'performance/qualification.json')['after'] == state
    orchestration = {}
    for name in ('archive', 'audit', 'promote'):
        path = Path('/private/tmp/vellum-ax-publication-' + name + '.py')
        orchestration[str(path)] = sha(path)
    for path, expected in list(FILES.items()):
        assert sha(path) == expected

    certificate = {
        'schema': 1, 'decision': 'APPROVED_RESOLUTION', 'status': 'APPROVED', 'findings': [],
        'original_receipt_review_sha256': receipt_sha,
        'reviewed_file_sha256': FILES,
        'provider': {'raw_exit_code': 1, 'raw_findings': 1, 'raw_discarded': 0, 'finding_id': finding['id'],
                     'severity': 'medium', 'confidence': .3, 'coverage': coverage,
                     'raw_prism_sha256': FILES[str(Q / 'prism/prism.json')],
                     'process_sha256': FILES[str(Q / 'prism/process.json')],
                     'raw_result_preserved': True},
        'local_disposition': {'result': 'REFUTED', 'source_changes_required': False,
                              'reason': 'Application.Do calls fn() synchronously under owner serialization; all three helper calls stay on their owning t.Run goroutine. The conditional remote-goroutine premise is false for these exact sources/call sites.',
                              'source_sha256': local['source_sha256'], 'call_lines': calls,
                              'review_sha256': FILES[str(Q / 'internal-prism-finding-review.json')]},
        'document_delta': {'path': correction['path'], 'before_sha256': correction['before_sha256'],
                           'after_sha256': correction['after_sha256'], 'one_inserted_addendum_only': True,
                           'no_original_table_measurement_or_numeric_prose_edits': True,
                           'correctly_preserves_provider_one_finding_exit1': True},
        'inheritance': {'original_certificate_unchanged': True, 'all_original_artifact_hashes_unchanged': True,
                        'source_spec_test_map_653_unchanged': True,
                        'native_and_performance_endpoint_maps_unchanged': True,
                        'original_40_process_4800_sample_approval_retained': True},
        'supplemental_orchestration_source_review': {
            'files': orchestration,
            'assessment': 'Archive retains raw provider/finding, local disposition, report pre/post copies, independent recipes and the bound prior helper. Audit treats raw exit1 separately from REFUTED and checks current supplement bytes plus original receipt-report substitution. Promotion requires explicit exit1/one finding/local REFUTED/unresolved0 and target/baseline guards; it does not infer a raw provider pass.',
            'execution_approved_or_observed': False,
        },
        'scope': 'Independent source/callsite adjudication and exact provider/disposition/report-addendum linkage. Original raw/statistical receipt approval is inherited byte-exact, without new workload execution.',
        'limits': ['No tests, builds, preparation, Git, provider, GUI/native or OS changes executed; only this external recipe and certificate written.',
                   'This refutation applies to direct current Do/subtest call sites; fatal assertions in future queued/native/spawned callbacks would need separate review.',
                   'Provider raw exit1 and medium finding remain intact; local refutation is not a zero-finding raw provider pass.',
                   'Final archive and whole compiler/SDK closure remain outside this selected receipt/resolution review.',
                   'Measured results remain mixed and all40 warm targets fail; no general speedup or full P6/Mac acceptance claim.'],
        'recipe_sha256': sha(Path(__file__)),
    }
    target = Q / 'internal-resolution-review.json'
    target.write_text(json.dumps(certificate, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'decision': certificate['decision'], 'certificate': str(target),
                      'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'reviewed_files': len(FILES)}, sort_keys=True))


if __name__ == '__main__':
    main()
