"""Read-only independent AX receipt audit, importing only prior reviewer code.
No repository imports, producers, tests, builds, Git, provider or native runs.
"""
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HELPER = Path('/private/tmp/vellum-raster-coverage-protocol-review/final-receipts/audit.py')
s = importlib.util.spec_from_file_location('reviewer_receipt_functions', HELPER)
h = importlib.util.module_from_spec(s)
s.loader.exec_module(h)
ROOT = Path('/private/tmp/vellum-large-data')
BASE = Path('/Users/dshills/Development/projects/Vellum')
Q = Path('/private/tmp/vellum-ax-publication-cost')
OUT = Path(__file__).parent
h.ROOT = ROOT
h.Q = Q
data, text, record, sha, map_sha = h.data, h.text, h.record, h.sha, h.map_sha


def main():
    checks = record(Q / 'checks/qualification.json')
    native = record(Q / 'native/qualification.json')
    base = record(Q / 'baseline-build-v2/qualification.json')
    perf = record(Q / 'performance/qualification.json')
    proofs = {'checks': checks, 'native': native, 'baseline-build-v2': base, 'performance': perf}
    state = checks['before']
    assert len(state['source']) == 653 and len(state['prepared']) == 6140
    assert base['head'] == perf['baseline_head'] == 'b995782de24d472b2a45727e75b60301c20bf8d8'
    assert len(base['before']['source']) == 651 and len(base['before']['prepared']) == 6140
    assert base['before'] == base['after'] and base['after']['prepared'] == state['prepared']
    for name, proof in proofs.items():
        assert proof['result'] == ('PASS_MATCHED_COMPARISON' if name == 'performance' else 'PASS')
        assert proof['producer_sha256'] == sha(Q / name / 'producer.py.txt')
        if name != 'baseline-build-v2':
            assert proof['before'] == proof['after'] == state
    approved = record(Q / 'internal-review-inputs.json')
    source_review = record(Q / 'internal-source-review.json')
    assert source_review['status'] == 'APPROVED' and source_review['findings'] == []
    assert source_review['receipt_sha256'] == sha(Q / 'internal-review-inputs.json')
    assert len(approved) == 9 and approved == source_review['reviewed_files']
    changed = sorted(p for p in base['after']['source'].keys() | state['source'].keys()
                     if base['after']['source'].get(p) != state['source'].get(p))
    assert changed == sorted(approved) == perf['baseline_changed_paths']
    assert all(state['source'][p] == value for p, value in approved.items())
    for path, value in source_review['supporting_context_files'].items():
        assert sha(ROOT / path) == value
    for path, expected in state['source'].items():
        assert sha(ROOT / path) == expected, path
    for path, expected in base['after']['source'].items():
        assert sha(BASE / path) == expected, path
    actual = {str(p.relative_to(ROOT)): sha(p) for dep in ('upstream', 'typesetting')
              for p in sorted((ROOT / 'drivers/cogent/build' / dep).rglob('*')) if p.is_file()}
    assert actual == state['prepared']
    # Whole maps stay in existing source-bound proofs; keep this certificate compact.
    current_source_paths = {str(ROOT / p) for p in state['source']}
    baseline_source_paths = {str(BASE / p) for p in base['after']['source']}
    for path in list(h.FILES):
        if path in current_source_paths or path in baseline_source_paths or path.startswith(str(ROOT / 'drivers/cogent/build') + '/'):
            del h.FILES[path]
    for path in approved:
        sha(ROOT / path)

    assert len(checks['checks']) == 11 and len(native['checks']) == 3
    for phase, rows in (('checks', checks['checks']), ('native', native['checks']), ('baseline-build-v2', [base['check']])):
        for child in rows:
            assert child['exit_code'] == 0 and child['error'] is None
            assert child['log_sha256'] == sha(Q / phase / (child['name'] + '.log'))
    assert data(Q / 'checks/producer.py.txt') == data('/private/tmp/vellum-ax-publication-qualify.py')
    assert data(Q / 'native/producer.py.txt') == data('/private/tmp/vellum-ax-publication-qualify-v2.py')
    assert data(Q / 'performance/producer.py.txt') == data('/private/tmp/vellum-ax-publication-performance.py')
    baseline_producer = text(Q / 'baseline-build-v2/producer.py.txt')
    assert "git','status','--porcelain" in baseline_producer and "assert head=='b995782de24d472b2a45727e75b60301c20bf8d8'" in baseline_producer
    assert base['check']['cwd'] == str(BASE / 'examples/loadedgrid')
    failures = text(Q / 'baseline-build/build.log')
    assert 'Library/Caches/go-build' in failures and 'operation not permitted' in failures
    assert not (Q / 'baseline-build/qualification.json').exists()
    record(Q / 'baseline-build/inputs-before.json')
    publication_log = text(Q / 'checks/publication-race3.log')
    declared = []
    for p in (ROOT / 'drivers/cogent').glob('*test.go'):
        for name in re.findall(r'^func (Test(?:NativeAccessibilityGeometry|NativeAccessibilityPayload|NativeGridAccessibilityEnvelope|AccessibilityGridPublication)\w*)\(', p.read_text(), re.M):
            declared.append(name)
    assert declared and all(len(re.findall(r'^--- PASS: ' + re.escape(name) + r' ', publication_log, re.M)) == 3 for name in declared)
    assert native['binaries'] == checks['binaries']
    for filename, expected in checks['binaries'].items():
        assert sha(Path('/private/tmp') / filename) == expected
    assert perf['binaries']['baseline'] == base['binary_sha256'] == sha('/private/tmp/vellum-ax-publication-baseline')
    assert perf['binaries']['candidate'] == checks['binaries']['vellum-ax-publication-candidate'] == native['binaries']['vellum-ax-publication-candidate']
    for name, rows in (('fixed10k-ax', 10000), ('variable-million-ax', 1000000)):
        events = [json.loads(line) for line in text(Q / 'native' / (name + '.log')).splitlines() if line.startswith('{')]
        assert [e['event'] for e in events] == ['grid.accessibility.pass', 'grid.accessibility.closed']
        assert events[0]['rows'] == rows and events[0]['visible_minimum'] == 400
        assert events[0]['native_press_admitted'] is True and events[0]['overlap_objects_reused'] > 0 and events[0]['replacement_objects_retired'] > 0
        assert events[1]['attachment_query_refused'] is True
    generic = json.loads(text(Q / 'native/generic-ax.log'))
    assert generic['result'] == 'PASS' and generic['native'] == 'macOS NSAccessibility'
    assert generic['preferences_changed'] is False and generic['voiceover_tested'] is False

    assert perf['samples'] == 4800 and perf['runs_per_case_build'] == 5
    assert perf['samples_per_run'] == 120 and perf['warmup'] == 128
    assert perf['warm_targets_ns'] == {'p95': 4000000, 'p99': 6000000}
    assert perf['benchmark_sha256'] == sha(ROOT / 'scripts/benchmark-grid.py')
    assert perf['helper_sha256'] == sha('/private/tmp/vellum-grid-publication-qualify.py')
    cases = ['fixed-10000', 'fixed-1000000', 'variable-10000', 'variable-1000000']
    expected_order = [(build, case, rep) for case in cases for rep in range(1, 6)
                      for build in (('baseline', 'candidate') if rep % 2 else ('candidate', 'baseline'))]
    assert [(r['build'], r['case'], r['repetition']) for r in perf['runs']] == expected_order
    summary = record(Q / 'performance/summary.json')
    assert sha(Q / 'performance/summary.json') == perf['summary_sha256']
    runs = {build: {case: [] for case in cases} for build in ('baseline', 'candidate')}
    settings, font = {}, None
    targets_failed = 0
    for item in perf['runs']:
        build, case, rep = item['build'], item['case'], item['repetition']
        folder = Q / 'performance' / build / case / ('run-' + str(rep))
        result = record(folder / 'result.json')
        assert item['result_sha256'] == sha(folder / 'result.json')
        assert result['result'] == 'PASS' and result['error'] is None and result['exit_code'] == 0
        assert result['log_sha256'] == sha(folder / 'native.log')
        assert h.raw_records(folder / 'native.log') == result['records']
        rows, variable = int(case.split('-')[1]), case.startswith('variable')
        assert result['argv'] == ['/private/tmp/vellum-ax-publication-' + build, '-perf', '-rows=' + str(rows), '-perf-samples=120', '-perf-warmup=128'] + (['-variable-rows'] if variable else [])
        samples = h.validate_run(result, rows, variable)
        setup = result['records'][0]
        if build not in settings:
            settings[build] = setup['build_settings']
        assert setup['build_settings'] == settings[build]
        assert setup['build_settings']['vcs.revision'] == base['head']
        assert setup['build_settings']['vcs.modified'] == ('false' if build == 'baseline' else 'true')
        if font is None:
            font = setup['embedded_regular_font_sha256']
        assert font == setup['embedded_regular_font_sha256']
        runs[build][case].append(samples)
        stats = h.distribution([s['metrics']['ui_work_ns'] for s in samples])
        assert stats['p95'] > 4000000 and stats['p99'] > 6000000
        targets_failed += 1
    assert {k: v for k, v in settings['baseline'].items() if k != 'vcs.modified'} == {k: v for k, v in settings['candidate'].items() if k != 'vcs.modified'}
    recalculated = {build: {case: {'timings_ns': h.summarize(samples)} for case, samples in cases_.items()}
                    for build, cases_ in runs.items()}
    assert recalculated == summary and targets_failed == 40
    assert perf['warm_target_met'] == {'baseline': False, 'candidate': False}
    geometry_pairs = 0
    for case in cases:
        for a, b in zip(runs['baseline'][case], runs['candidate'][case]):
            for first, second in zip(a, b):
                assert first['geometry'] == second['geometry']
                geometry_pairs += 1
    for build in runs:
        for height in ('fixed', 'variable'):
            for a, b in zip(runs[build][height + '-10000'], runs[build][height + '-1000000']):
                for first, second in zip(a, b):
                    assert first['geometry'] == second['geometry']
                    geometry_pairs += 1
    assert geometry_pairs == 4800

    values = record(Q / 'report-values.json')
    report_path = ROOT / 'docs/reports/macos-ax-publication/README.md'
    report, implementation = text(report_path), text(ROOT / 'docs/implementation.md')
    assert sha(report_path) == values['report_sha256']
    assert sha(ROOT / 'docs/implementation.md') == values['implementation_sha256']
    assert sha('/private/tmp/vellum-ax-publication-report.py') == sha(Q / 'report-producer.py.txt') == values['producer_sha256']
    reductions = [100 * (1 - recalculated['candidate'][case]['timings_ns']['ui_work_ns']['pooled']['p95'] /
                             recalculated['baseline'][case]['timings_ns']['ui_work_ns']['pooled']['p95']) for case in cases]
    assert reductions == values['p95_reductions_percent'] and values['failed_both_processes'] == 40
    table = re.findall(r'^\| (fixed-\d+|variable-\d+) \| (baseline|candidate) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|$', report, re.M)
    assert len(table) == 8
    for case, build, *shown in table:
        pooled = recalculated[build][case]['timings_ns']['ui_work_ns']['pooled']
        assert shown == [format(pooled[k] / 1e6, '.3f') for k in ('p50', 'p95', 'p99', 'max')]
    mixed = 'Pooled p95 changes are mixed across these four matched cases'
    assert mixed in report and mixed in implementation and 'without a general speedup claim' in report
    assert all(v > 0 for v in reductions[:3]) and reductions[-1] < 0
    assert 'Every one of the 40 ordinary processes still fails both' in report
    assert 'All 40 ordinary processes still fail both' in implementation
    assert 'do not reliably attribute asynchronous Cocoa/GPU execution' in report
    assert 'not a whole compiler or SDK closure' in report

    profile_root = Path('/private/tmp/vellum-text-parse-profile')
    profile = record(profile_root / 'qualification.json')
    assert profile['result'] == 'PASS' and profile['before'] == profile['after']
    assert 'Diagnostic CPU profiling only' in profile['scope'] and 'excluded' in profile['scope']
    assert profile['check']['exit_code'] == 0 and profile['check']['error'] is None
    assert sha(profile_root / 'diagnostic.log') == profile['check']['log_sha256']
    profiled = h.raw_records(profile_root / 'diagnostic.log')
    assert len(profiled) == 515 and len([r for r in profiled if r['event'] == 'grid.perf.sample']) == 512
    assert profiled[0]['cpu_profile'] is profiled[1]['cpu_profile'] is profiled[-1]['cpu_profile'] is True
    assert profiled[0]['release'] is True and profiled[-1]['pending'] == profiled[-1]['dropped'] == 0
    assert str(profile_root / 'cpu.pprof') in profile['check']['argv'][-1]
    sha(profile_root / 'cpu.pprof')
    assert profile['binary_sha256'] != perf['binaries']['candidate']
    assert not any(profile['binary_sha256'] == v for v in perf['binaries'].values())

    for path, value in list(h.FILES.items()):
        assert sha(path) == value, path
    recipe_sha = sha(Path(__file__))
    helper_sha = sha(HELPER)
    # Binary bytes are linked by exact hashes; avoid a redundant raw binary archive claim.
    binaries = dict(perf['binaries'])
    for filename in checks['binaries']:
        del h.FILES[str(Path('/private/tmp') / filename)]
    del h.FILES['/private/tmp/vellum-ax-publication-baseline']
    certificate = {
        'schema': 1, 'decision': 'APPROVED_RECEIPTS', 'status': 'APPROVED', 'findings': [],
        'reviewed_file_sha256': h.FILES,
        'qualification_sha256': {name: h.FILES[str(Q / name / 'qualification.json')] for name in proofs},
        'source_linkage': {'baseline_head': base['head'], 'baseline_selected_source_count': 651,
                           'candidate_selected_source_count': 653, 'prepared_file_count': 6140,
                           'all_candidate_endpoint_maps_equal': True, 'baseline_endpoint_maps_equal': True,
                           'complete_prepared_bytes_equal': True,
                           'current_candidate_source_and_complete_prepared_set_rehashed': True,
                           'current_baseline_selected_sources_rehashed': True,
                           'baseline_clean_git': 'Producer-asserted before/after; reviewer executed no Git.',
                           'candidate_source_map_sha256': map_sha(state['source']),
                           'baseline_source_map_sha256': map_sha(base['after']['source']),
                           'prepared_map_sha256': map_sha(state['prepared']),
                           'approved_changed_paths': changed, 'approved_bytes_match': True},
        'binary_sha256': binaries,
        'verification': {'checks': 11, 'publication_top_level_groups': len(declared), 'group_repetitions': 3,
                         'native_children': 3, 'stored_400cell_native_pass_and_closed': 2,
                         'generic_native_accessibility_pass': True,
                         'producer_entry_copies_and_hashes_match': True,
                         'current_check_producer_unchanged': True},
        'performance': {'processes': 40, 'samples': 4800, 'samples_per_run': 120, 'warmup_callbacks': 128,
                        'all_ordinary_diagnostic_modes_off': True, 'closed_warmups_all': True,
                        'full_geometry_equal_pairs': geometry_pairs,
                        'all_11_metric_pooled_per_run_variation_distributions_recomputed': True,
                        'pooled_ui_work_ns': {build: {case: values_['timings_ns']['ui_work_ns']['pooled'] for case, values_ in cases_.items()} for build, cases_ in recalculated.items()},
                        'pooled_p95_reductions_percent': dict(zip(cases, reductions)),
                        'mixed_p95_direction': True, 'target_met': perf['warm_target_met'],
                        'warm_targets_ns': perf['warm_targets_ns'], 'processes_failing_both_targets': 40},
        'historical_failure': {'default_cache_attempt': 'Separate raw operation-not-permitted build log; no PASS qualification exists. Accepted baseline-v2 is independently bound.'},
        'diagnostic_profile': {'samples': 512, 'binary_separate_from_both_comparison_artifacts': True,
                               'qualified_measurement': False,
                               'scope': 'Separate diagnostic CPU profile motivates source inspection; Go/CGO semantic frames do not establish complete C/Objective-C or asynchronous Cocoa/GPU attribution.'},
        'scope': 'Independent read-only raw log/result, build/source/binary identity, statistics, geometry, target and report audit. No repository source/spec/report changes or runtime execution.',
        'limits': ['Provider and final archive gates are separate and not certified here.',
                   'Source maps and complete prepared bytes are not full compiler/module-cache/SDK/ambient runtime closure.',
                   'Clean baseline Git state is retained producer evidence; actual baseline selected source bytes were independently rehashed without Git.',
                   'Wall durations of measured same-ticket UI work are not OS thread CPU or physical GPU/display presentation; process observations are end-only and not native/GPU memory attribution.',
                   'All 40 processes fail both warm targets. Mixed host/workload p95 differences do not establish a general speedup, individual optimization attribution, endurance, full P6 or complete Mac/professional-human acceptance.',
                   'No tests, builds, prepare, Git, provider, native/GUI programs or OS changes executed by this reviewer.'],
        'recipe_sha256': recipe_sha, 'independent_reviewer_helpers_sha256': helper_sha,
    }
    (OUT / 'recomputed-statistics.json').write_text(json.dumps(recalculated, indent=2, sort_keys=True) + '\n')
    target = Q / 'internal-receipt-review.json'
    target.write_text(json.dumps(certificate, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'decision': certificate['decision'], 'certificate': str(target),
                      'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'files': len(h.FILES),
                      'p95_reductions_percent': reductions, 'samples': 4800}, sort_keys=True))


if __name__ == '__main__':
    main()
