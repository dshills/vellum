package cogent

import (
	"html"

	"cogentcore.org/core/colors"
	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/states"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/tree"
	"github.com/dshills/vellum/ui"
)

// Managed children occupy host, never the private heading/message structure.
type chromeState struct {
	host    *core.Frame
	caption *core.Text
}

func mountChrome(parent tree.Node, r *record) core.Widget {
	outer := core.NewFrame(parent)
	c := &chromeState{host: outer}
	r.control.chrome = c
	outer.Styler(func(s *styles.Style) {
		s.Direction = styles.Row
		s.Grow.Set(1, 0)
		s.Padding.Set(units.Dp(4), units.Dp(8))
		s.Gap.Set(units.Dp(8))
		s.Align.Items = styles.Center
		s.Background = colors.Scheme.SurfaceContainer
		if r.node.Kind == ui.Toolbar {
			if r.node.Orientation == ui.Vertical {
				s.Direction = styles.Column
				s.Grow.Set(0, 1)
			}
			// Scroll keeps the same native controls and their private editing state.
			s.Overflow.Set(styles.OverflowAuto, styles.OverflowVisible)
			if r.node.Orientation == ui.Vertical {
				s.Overflow.Set(styles.OverflowVisible, styles.OverflowAuto)
			}
		}
		if r.node.Kind == ui.FormGroup {
			s.Direction = styles.Column
			s.Align.Items = styles.Start
			s.Padding.Set(units.Dp(8))
			s.Border.Width.Set(units.Dp(1))
			s.Border.Color.Set(colors.Scheme.OutlineVariant)
			s.Border.Radius.Set(units.Dp(6))
		}
	})
	if r.node.Kind != ui.Toolbar {
		c.caption = core.NewText(outer)
		c.caption.SetName("vellum-caption")
		c.caption.Styler(func(s *styles.Style) {
			if r.node.Text == "" {
				s.Display = styles.DisplayNone
			}
		})
		c.host = core.NewFrame(outer)
		c.host.SetName("vellum-content")
		c.host.Styler(func(s *styles.Style) {
			s.Direction = styles.Row
			s.Grow.Set(1, 0)
			s.Gap.Set(units.Dp(8))
			if r.node.Kind == ui.FormGroup {
				s.Direction = styles.Column
			}
			value, _ := ui.ResolveStyle(r.node, r.theme)
			if value.Gap.Set {
				s.Gap.Set(units.Dp(value.Gap.Value))
			}
			if value.Align.Set {
				s.Align.Items = nativeAlignment(value.Align.Value)
				s.Align.Content = nativeAlignment(value.Align.Value)
			}
			if value.Justify.Set {
				s.Justify.Content = nativeAlignment(value.Justify.Value)
			}
		})
	} else {
		// Child controls consume editing/navigation chords first. Managed toolbar
		// navigation runs before Frame defaults, which can focus disabled children.
		outer.OnFinal(events.KeyChord, func(e events.Event) { toolbarKey(r, e) })
	}
	return outer
}
func syncChrome(r *record, previous ui.Node) {
	c := r.control.chrome
	if c.caption != nil {
		if previous.Text != r.node.Text || c.caption.Text != html.EscapeString(r.node.Text) {
			c.caption.SetText(html.EscapeString(r.node.Text)).Update()
		}
		c.caption.SetState(r.control.disabled, states.Disabled)
	}
}
func toolbarKey(r *record, e events.Event) {
	if e.IsHandled() || e.Modifiers() != 0 || r.control.retired || r.control.disabled {
		return
	}
	order := ui.FocusOrder(ui.FocusScope(r.node))
	if len(order) == 0 {
		return
	}

	targets := map[string]accessibilityFocusTarget{}
	accessibilityNativeFocusTargets(r, "", targets)
	target := ""
	step := 0
	switch e.KeyCode() {
	case key.CodeHome:
		target = order[0]
	case key.CodeEnd:
		target = order[len(order)-1]
	case key.CodeLeftArrow:
		if r.node.Orientation == ui.Vertical {
			return
		}
		step = -1
	case key.CodeRightArrow:
		if r.node.Orientation == ui.Vertical {
			return
		}
		step = 1
	case key.CodeUpArrow:
		if r.node.Orientation != ui.Vertical {
			return
		}
		step = -1
	case key.CodeDownArrow:
		if r.node.Orientation != ui.Vertical {
			return
		}
		step = 1
	default:
		return
	}
	if step != 0 {
		index := -1
		for i, id := range order {
			if targets[accessibilityManagedID(id)].focused {
				index = i
				break
			}
		}
		if index < 0 && step < 0 {
			index = 0
		}
		target = order[(index+step+len(order))%len(order)]
	}

	if next, ok := targets[accessibilityManagedID(target)]; ok && !tree.IsNil(next.widget) {
		// Key delivery already has an active native/manual event owner. Set actual
		// focus here; pre-show semantic intent uses StartFocus elsewhere.
		next.widget.AsWidget().SetFocus()
		e.SetHandled()
	}
}
