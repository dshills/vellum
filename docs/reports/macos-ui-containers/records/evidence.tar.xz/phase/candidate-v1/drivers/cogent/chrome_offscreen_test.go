//go:build offscreen

package cogent

import (
	"bytes"
	"fmt"
	"testing"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/math32"
	"github.com/dshills/vellum/ui"
)

func TestChromeManualToolbarOverflowAndStatusUpdates(t *testing.T) {
	status := "Ready"
	actions := 0
	view := func() ui.Node {
		tools := []ui.Node{}
		for i := range 8 {
			i := i
			tools = append(tools, ui.Node{ID: fmt.Sprintf("tool-%d", i), Kind: ui.Button, Text: fmt.Sprintf("Tool %d", i), MinWidth: 100, Disabled: i == 1, Activate: func() { status = fmt.Sprintf("Tool %d activated", i); actions++ }})
		}
		return ui.Node{ID: "root", Kind: ui.Column, Grow: true, Focus: ui.FocusRequest{ID: "tool-0", Sequence: 1}, Children: []ui.Node{
			{ID: "tools", Kind: ui.Toolbar, Accessibility: ui.Accessibility{Name: "Document tools"}, Style: ui.Style{MaxSize: ui.Some(ui.Size{Width: 260})}, Children: tools},
			{ID: "form", Kind: ui.FormGroup, Text: "<Project>", Children: []ui.Node{{ID: "field", Kind: ui.TextField, Text: "Name"}}},
			{ID: "status", Kind: ui.StatusBar, Text: status, Accessibility: ui.Accessibility{Name: "Application status"}, Children: []ui.Node{{ID: "reset", Kind: ui.Button, Text: "Reset", Activate: func() { status = "Ready" }}}},
		}}
	}
	m, _ := simpleManual(t, manualConfig(t, 7), view)
	unitSettle(t, m)
	w := m.implementation.find("one")
	toolbar := findRecord(w.state.root, "tools").control.chrome.host
	if toolbar.Scrolls[math32.X] == nil {
		t.Fatal("narrow toolbar has no overflow scrolling")
	}
	before, err := m.Capture(testContext, "one")
	if err != nil {
		t.Fatal(err)
	}
	send := func(code key.Codes) {
		t.Helper()
		if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Code: code}); err != nil {
			t.Fatal(err)
		}
		unitSettle(t, m)
	}
	focus := func() string {
		t.Helper()
		s, err := m.Snapshot(testContext)
		if err != nil {
			t.Fatal(err)
		}
		return s.Windows[0].FocusedID
	}
	send(key.CodeEnd)
	if focus() != "tool-7" || toolbar.Scrolls[math32.X].Value <= 0 {
		t.Fatal("End failed to reveal overflowing last tool", focus(), toolbar.Scrolls[math32.X].Value)
	}
	box := findRecord(w.state.root, "tool-7").widget.AsWidget().Geom.TotalBBox
	if box.Empty() || !box.In(toolbar.Geom.TotalBBox) {
		t.Fatal("focused tool clipped outside toolbar", box, toolbar.Geom.TotalBBox)
	}
	send(key.CodeReturnEnter)
	if status != "Tool 7 activated" || actions != 1 {
		t.Fatal("overflowing focused tool activation failed", status, actions)
	}
	statusRecord := findRecord(w.state.root, "status")
	if statusRecord.control.chrome.caption.Text != status {
		t.Fatal("status caption stale")
	}
	nodes, _ := accessibilitySnapshot(w.state.root, nil)
	found := false
	for _, n := range nodes {
		if n.DomainID == "status" {
			found = true
			if n.Value != status || n.Focusable || len(n.Actions) != 0 {
				t.Fatal("status value/action metadata", n)
			}
		}
	}
	if !found {
		t.Fatal("status semantics missing")
	}
	after, err := m.Capture(testContext, "one")
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Equal(before.Pix, after.Pix) {
		t.Fatal("toolbar/status produced no completed raster change")
	}
	send(key.CodeHome)
	if focus() != "tool-0" || toolbar.Scrolls[math32.X].Value != 0 {
		t.Fatal("Home failed to reveal first tool", focus(), toolbar.Scrolls[math32.X].Value)
	}
	send(key.CodeRightArrow)
	if focus() != "tool-2" {
		t.Fatal("toolbar arrows did not skip disabled tool", focus())
	}
	send(key.CodeEnd)
	send(key.CodeTab)
	if focus() != "field" {
		t.Fatal("toolbar/form added private managed focus stops", focus())
	}
	form := findRecord(w.state.root, "form")
	if form.control.chrome.caption.Text != "&lt;Project&gt;" {
		t.Fatal("form title entered markup")
	}
}

func TestChromeManualVerticalToolbarScrollAndDisabledNavigation(t *testing.T) {
	view := func() ui.Node {
		tools := []ui.Node{}
		for i := range 7 {
			tools = append(tools, ui.Node{ID: fmt.Sprintf("tool-%d", i), Kind: ui.Button, Text: fmt.Sprintf("Tool %d", i), Disabled: i == 1})
		}
		return ui.Node{ID: "root", Kind: ui.Row, Grow: true, Focus: ui.FocusRequest{ID: "tool-0", Sequence: 1}, Children: []ui.Node{{ID: "tools", Kind: ui.Toolbar, Orientation: ui.Vertical, Style: ui.Style{MaxSize: ui.Some(ui.Size{Height: 120})}, Children: tools}}}
	}
	m, _ := simpleManual(t, manualConfig(t, 7), view)
	unitSettle(t, m)
	w := m.implementation.find("one")
	toolbar := findRecord(w.state.root, "tools").control.chrome.host
	if toolbar.Scrolls[math32.Y] == nil {
		t.Fatal("vertical toolbar has no main-axis scrollbar")
	}
	send := func(code key.Codes) {
		t.Helper()
		if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Code: code}); err != nil {
			t.Fatal(err)
		}
		unitSettle(t, m)
	}
	focus := func() string {
		t.Helper()
		s, err := m.Snapshot(testContext)
		if err != nil {
			t.Fatal(err)
		}
		return s.Windows[0].FocusedID
	}
	send(key.CodeEnd)
	box := findRecord(w.state.root, "tool-6").widget.AsWidget().Geom.TotalBBox
	if focus() != "tool-6" || toolbar.Scrolls[math32.Y].Value <= 0 || box.Empty() || !box.In(toolbar.Geom.TotalBBox) {
		t.Fatal("vertical End failed to reveal tool", focus(), box, toolbar.Geom.TotalBBox)
	}
	send(key.CodeHome)
	send(key.CodeDownArrow)
	if focus() != "tool-2" {
		t.Fatal("vertical toolbar did not skip disabled tool", focus())
	}
	send(key.CodeUpArrow)
	if focus() != "tool-0" {
		t.Fatal("vertical previous enabled tool wrong", focus())
	}
	send(key.CodeUpArrow)
	if focus() != "tool-6" {
		t.Fatal("vertical toolbar did not wrap enabled tools", focus())
	}
}

func TestChromeManualToolbarLeavesTextEditingHomeEndToField(t *testing.T) {
	m, _ := simpleManual(t, manualConfig(t, 7), func() ui.Node {
		return ui.Node{ID: "root", Kind: ui.Column, Focus: ui.FocusRequest{ID: "field", Sequence: 1}, Children: []ui.Node{{ID: "tools", Kind: ui.Toolbar, Children: []ui.Node{{ID: "first", Kind: ui.Button, Text: "First"}, {ID: "field", Kind: ui.TextField, Text: "alpha"}, {ID: "last", Kind: ui.Button, Text: "Last"}}}}}
	})
	unitSettle(t, m)
	w := m.implementation.find("one")
	field := findRecord(w.state.root, "field").widget.(*core.TextField)
	for _, test := range []struct {
		code key.Codes
		want int
	}{{key.CodeHome, 0}, {key.CodeEnd, 5}} {
		if err := m.Input(testContext, ManualInput{Window: "one", WindowIncarnation: w.incarnation, Type: events.KeyChord, Code: test.code}); err != nil {
			t.Fatal(err)
		}
		unitSettle(t, m)
		snapshot, err := m.Snapshot(testContext)
		if err != nil {
			t.Fatal(err)
		}
		if snapshot.Windows[0].FocusedID != "field" || field.EditingState().Focus != test.want {
			t.Fatal("toolbar stole text editing chord", snapshot.Windows[0].FocusedID, field.EditingState())
		}
	}
}
