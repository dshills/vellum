The immutable 16-file source-v1 container snapshot needs correction. Three concrete source findings are retained here, independently of the existing passing author fixtures.

A Toolbar's enabled managed arrow traversal runs only at the outer Frame. An intervening Row's generic Core Frame.OnFinal can consume the arrow first and focus a disabled direct child. The current fixtures use direct toolbar children and do not cover this nested path. A scoped layout interception must preserve focused child text/choice handlers before replacing generic descendant navigation.

Empty private captions latch Core's Invisible state via DisplayNone. Core Style does not clear that state when normal display returns; Update and widget walks preserve/skip it. The source therefore cannot satisfy the specified empty-to-nonempty restoration. The current retention test proves hiding only. This needs explicit two-way visibility plus actual restored geometry/raster coverage.

Private caption TextBodyLarge defaults also overwrite inherited font weight with Normal. Explicit or themed container Typography.Weight is therefore lost although the contract describes typography inheritance. A final caption style or a narrower contract, with weight restoration coverage, resolves this issue.

The rest of the reviewed structure is coherent: managed children occupy the retained private content host, reconciliation parks/moves them before deleting removed hosts, captions are escaped and omitted from duplicate semantic nodes, status exposes its literal accepted value, and normal managed child Tab order stays intact. Existing chrome-v7 and portable-v1 are source-bound author passes on their own source intervals; they do not refute the additional cases above.

This is a read-only source review. The reviewer ran no tests/builds/preparation, native UI/input, provider or Git action. Physical Mac input, human VoiceOver, memory/endurance/performance and full completion remain separate gates.
