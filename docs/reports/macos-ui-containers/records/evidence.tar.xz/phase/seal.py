"""Seal retained UI-container changes and bounded Mac offscreen evidence."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-ui-containers');report=r/'docs/reports/macos-ui-containers';records=report/'records'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((p/'source-final-v4.json').read_text());assert len(source['sources'])==16 and all(h(r/n)==v for n,v in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
assert len(prepared)==6198 and prepared==json.loads(Path('/private/tmp/vellum-macos-choice-controls/qualification.json').read_text())['prepared']
required=['portable-race-final-v3','adapter-race-final-v3','chrome-race-final-v3','vet-final-v3','gallery-build-final-v3'];receipts={};baseline=json.loads((p/'source-final-v3.json').read_text())['sources']
assert {n for n,v in source['sources'].items()if baseline[n]!=v}=={'drivers/cogent/chrome_test.go'}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv' not in d:continue
 name=f.stem
 assert d['source_commit']==source['base_commit'] and d['error'] is None and d['source_delta_stable'] and d['prepared_before']==prepared==d['prepared_after'] and d['overlay_inputs_before']==d['overlay_inputs_after'],name
 for channel in ['stdout','stderr']:assert h(p/(name+'.'+channel))==d[channel+'_sha256'],name
 if name in required:assert d['exit_code']==0 and d['source_delta_before']==baseline==d['source_delta_after'],name
 receipts[name]={'sha256':h(f),'exit_code':d['exit_code'],'final_source_qualified':name in required}
assert all(name in receipts for name in required)
final_test=json.loads((p/'chrome-race-final-v4.json').read_text());assert final_test['exit_code']==0 and final_test['source_delta_before']==source['sources']==final_test['source_delta_after']
receipts['chrome-race-final-v4']['final_source_qualified']=True
for name,needle in [('chrome-v2','focused tool clipped outside toolbar'),('chrome-v3','toolbar arrows did not skip disabled tool'),('review-original-v1','nested layout bypassed enabled toolbar order'),('review-original-v1','caption stayed hidden after nonempty text'),('review-original-v1','caption lost inherited font weight'),('font-scale-original-v2','caption double-scaled inherited font 31.25 25'),('all-disabled-original-v2','all-disabled toolbar fell through to disabled sibling')]:assert needle in(p/(name+'.stdout')).read_text(),name
negative=json.loads((p/'source-review-original.json').read_text())['sources'];assert negative==json.loads((p/'review-original-v1.json').read_text())['source_delta_before'] and all(h(p/'candidate-review-original'/n)==v for n,v in negative.items())
for name in ['font-scale-original-v2','all-disabled-original-v2']:
 d=json.loads((p/(name+'.json')).read_text())
 assert d['exit_code']==1 and d['overlay_inputs_before']
 for n,v in d['overlay_inputs_before'].items():assert h(Path(n))==v
review=json.loads((p/'review-final-v4.json').read_text());assert review.get('status',review.get('result'))=='APPROVED_SOURCE' and {Path(n).relative_to(r).as_posix():v for n,v in review['reviewed_file_sha256'].items()}==source['sources'] and not review['findings']
prism=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text());assert process['exit_code']==1 and process['source_index_stable'] and process['before']==baseline
assert prism['coverage']['complete'] and prism['coverage']['files']==16 and len(prism['findings'])==1 and prism['findings'][0]['id']=='262c0caf0a5e5181' and prism['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
pool={}
for f in sorted(p.rglob('*')):
 if f.is_file() and f.suffix in ['.go','.txt','.md','.m']:pool.setdefault(h(f),[]).append(f.relative_to(p).as_posix())
variants={}
for name in receipts:
 d=json.loads((p/(name+'.json')).read_text());variants[name]={n:{'sha256':v,'available_phase_payloads':pool.get(v,[])}for n,v in d['source_delta_before'].items()}
(p/'historical-source-payloads.json').write_text(json.dumps(variants,indent=2)+'\n')
q={'result':'PASS_UI_CONTAINERS','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'receipts':receipts,'source_review_sha256':h(p/'review-final-v4.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'prism_coverage':prism['coverage'],'prism_raw_exit_code':1,'prism_findings':1,'prism_findings_resolved':True,'baseline_qualification_source':baseline,'provider_disposition':'Internal review of the final single test-only assertion delta resolves missing-caption silent-skip finding; provider was not rerun','limits':['Sixteen changed source leaves and unchanged6198 prepared identities are endpoint hashes, not a full compiler/SDK/native-binary closure','Five final-v3 checks support unchanged production; one test-only assertion correction then compiles and passes three final-v4 targeted race runs against exact16 final sources; provider16 initial source and internal1-file correction scopes remain distinct','Actual Manual software input/raster, direct retained Core fixtures and inert Cocoa roles are separate from physical OS input, native attachment, human VoiceOver and presentation','Go-only font scaling fixture changes one in-process scalar after body initialization and restores it; no persistent preference or settings API is called','Initial font-scale-original-v1 PASS had weak pre-bootstrap setup and is not qualification of scaling behavior; corrected same final fixture fails old whole-Font overlay and passes Weight-only fix','Toolbar overflow scrolls the same retained controls on its main axis; modal and extension input scope remains separate','Gallery compiled only; no desktop windows/input/settings or general clipboard writes','Physical Mac input/VoiceOver, native/GPU memory, sustained performance/endurance, package rights/signing/release and full Mac qualification remain open']}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');records.mkdir(parents=True,exist_ok=True);t=prism['coverage']['tokens'][0];failures=[n for n,v in receipts.items()if v['exit_code']!=0]
(report/'README.md').write_text(f'''# Toolbars, status bars and form groups

Vellum now provides `ui.Toolbar`, `ui.StatusBar` and `ui.FormGroup` as retained
containers. Toolbars use horizontal/default or vertical main-axis scrolling,
keeping native controls, private editing state and stable child identity during
overflow. The cross axis keeps natural control size subject to explicit limits.
Tab uses child managed stops; unused main-axis arrows wrap through enabled stops,
and Home/End reveal the first/last. Focused text/choice handlers retain precedence.
Nested layouts route navigation through the current nearest toolbar; reparenting
clears the old scope. Modal content and extension-owned trees keep their own input
scope. Recognized traversal with a disabled toolbar/ancestor or no enabled stop
is consumed without generic disabled-child fallback. Ordinary trees without an
active/old toolbar scope avoid native traversal and binder map allocations.

FormGroup has an escaped visible Text heading and retained column content.
StatusBar places an escaped status Text beside a row of children and exposes the
literal message as semantic Value. Stable Accessibility.Name can name that region.
Private captions do not duplicate accessible nodes or add focus stops. Empty Text
hides a caption; nonempty Text restores it. Managed Gap/Align/Justify style content
as well as the outer structure; font attributes inherit, with weight restored
after native Text defaults. The caption keeps normalized inherited size so global
font scaling applies once. The Mac bridge maps Toolbar to AXToolbar and status/form
to AXGroup, publishing ordinary managed children/actions. No live-region announcement
or automatic field-label association is implied.

See [the catalog](../../controls.md) and [contract](../../../specs/controls.md).
The independent gallery demonstrates all three using accepted application state.

## Verification and corrections

Final portable and complete offscreen adapter race suites pass. Focused chrome
and gallery tests pass three race repetitions; adapter vet and native gallery
compilation also pass. These five final-v3 receipts bind the sixteen-leaf baseline and unchanged 6,198
prepared identities. A final single test-only caption assertion change then passes
three focused race repetitions against all sixteen final-v4 source identities.
The fifteen other leaves and all production code remain unchanged; earlier full
qualification supports that same production. The final targeted run compiles the
entire affected test package, including the strengthened caption fixture. The gallery was
compiled only. Native objects verify AXToolbar and two group roles without a window.

Actual Manual fixtures verify both toolbar orientations, constrained overflow,
keyboard reveal and activation of the last tool, Home, disabled-aware wrapping
arrows, ordinary Tab order, child text Home/End precedence and completed status
pixels. They also verify nested-row traversal, nearest-inner toolbar scope and
current scope removal when a layout moves out. The moved-out Home check directly
sends a Core event to the retained frame, separately from the full Manual router.
Retained tests cover private-host reorder/reparent, uncommitted field drafts,
latest callbacks, disabled delivery, title escaping and style removal/restoration.

Internal review identified nested layouts using generic disabled navigation,
captions remaining Invisible after Text returns, and native Text resetting font
weight. All three fail in the exact preserved pre-review sixteen-leaf candidate:
nested Right focuses disabled B, returning captions have empty geometry, and
caption weight is normal versus accepted semibold. They pass after dynamic layout
fallback binding, explicit two-way visibility restoration and weight inheritance.
Real Manual empty→nonempty→empty→nonempty tests check geometry and completed pixels.

Review of the first font fix exposed a whole-Font copy rescaling inherited Size.
The corrected125% in-process fixture checks the active scalar and25dp parent size,
fails the preserved old Chrome overlay at31.25dp caption size and passes the
Weight-only fix. The initial pre-bootstrap fixture PASS is explicitly weak evidence:
body settings initialization could reset its scalar. Tests call no persistent
settings API and restore the in-process scalar. Another genuine overlay regression
shows all-disabled children, toolbar and ancestor modes focus a disabled sibling
without the final recognized-traversal guard; the unchanged final fixture passes.

{len(receipts)} raw receipts and {len(receipts)*2} logs retain {len(failures)} exit-1
attempts. Switch insertion and test-only-helper compilation mistakes,
both-axis toolbar collapse, native disabled arrows, normal-handler non-bubbling
attempts, the initial review regressions, corrected scaling red and disabled-scope
reds remain historical attempts. The five final-v3 baseline checks plus final-v4 targeted race run support
this unchanged-production checkpoint with its one strengthened test leaf. Historical source maps and available payloads explicitly list any gaps;
exact pre-review sources and old overlay inputs are retained. The initial review
NEEDS_FIX snapshot remains immutable. Binaries, caches and complete compiler/SDK
closure are excluded.

## Review and remaining gates

Final internal source review approves the exact sixteen leaves after corrections.
Prism runs once at this checkpoint using Anthropic Claude Sonnet5.5: complete
sixteen-file baseline coverage, {prism['coverage']['chunks']} chunks, {t['input']} input/
{t['output']} output tokens, raw exit1 with one medium test-coverage finding.
The retention fixture previously guarded captions by nil presence, permitting
silent skips in that single fixture. Other rendering/font tests dereference the
caption and were already independent coverage. The final test now explicitly
requires a caption for status/form and absence for toolbar, and runs checks by
kind. Internal review verifies that sole test-only correction, and three targeted
race repetitions pass. The finding is resolved; its original raw provider report
is preserved. Prism was not repeated for this trivial assertion correction.
Provider baseline coverage and internal final-delta coverage remain distinct. Separate internal evidence
review binds the report, raw receipts, source families, review/provider records and
sealed archive before commit. The [checkpoint](records/checkpoint.json) binds that
review and the [archive](records/evidence.tar.xz) with its [member index](records/evidence-index.json).

No OS desktop UI/input/settings or general clipboard writes occurred. Software and
inert-object evidence does not qualify physical Mac input, human VoiceOver,
native/GPU memory, sustained performance/endurance or full framework completion.
Those original gates remain open while the public UI vocabulary expands.
''')
(records/'source-review.json').write_bytes((p/'review-final-v4.json').read_bytes())
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in ['.go','.m','.json','.md','.py','.stdout','.stderr','.txt','.log']:continue
 if f.name.startswith('evidence-review') or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in source['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size}for n,f in inputs.items()};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','w:xz')as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
e={'source_manifest_sha256':h(p/'source-final-v4.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.xz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'review-final-v4.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e,indent=2))
