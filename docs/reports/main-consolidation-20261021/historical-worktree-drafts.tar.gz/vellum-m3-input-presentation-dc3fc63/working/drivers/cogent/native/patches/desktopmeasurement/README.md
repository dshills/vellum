# Bounded originating input measurements

Stage0098 adds an opt-in bounded FrameTrace event-group transaction. It preserves
actual event identities and waits for dispatch, owner drain and reconciliation;
only a separate checked commit arms a composition. In-flight/intermediate
compositions keep their original unarmed identity. Cancellation preserves input
and owner terminals, while window retirement releases the final reservation.
Ordinary single-event tracing is unchanged. Controlled Core tests do not provide
real native presentation, physical input or Mac release evidence.
