//go:build darwin && cgo && !offscreen && vellum_native_checks

package main

import (
	"context"
	"errors"
	cogent "github.com/dshills/vellum/drivers/cogent"
	"testing"
	"time"
)

func TestSoakRejectsImpossibleWindowsAndUnboundedDeadlines(t *testing.T) {
	c := config{cycles: 1, every: 1, composed: true, timeout: time.Minute + 40*time.Second, soak: soakConfig{Duration: 40 * time.Second, Quiet: time.Second, Settle: time.Second, Interval: 2 * time.Second}}
	if e := c.validate(); e != nil {
		t.Fatal(e)
	}
	for _, mutate := range []func(*config){func(c *config) { c.composed = false }, func(c *config) { c.cycles = 1000 }, func(c *config) { c.every = 2 }, func(c *config) { c.soak.Duration = 13 * time.Hour }, func(c *config) { c.soak.Quiet = 0 }, func(c *config) { c.soak.Interval = time.Second }, func(c *config) { c.timeout = c.soak.Duration }, func(c *config) { c.timeout = 24 * time.Hour }, func(c *config) { c.heapProfile = "relative.heap" }, func(c *config) { c.soak.Quiet = time.Duration(1<<63 - 1) }} {
		bad := c
		mutate(&bad)
		if bad.validate() == nil {
			t.Fatal("invalid soak admitted", bad)
		}
	}
}
func TestSoakStateRequiresObservedVisibilityAndOcclusion(t *testing.T) {
	s := cogent.NativeServiceWindowCheck{Visible: true, OcclusionVisible: true, Frame: [4]float64{0, 0, 100, 100}}
	if !soakState(s, "visible") || soakState(s, "occluded") || soakState(s, "minimized") {
		t.Fatal("visible state confused")
	}
	s.OcclusionVisible = false
	if !soakState(s, "occluded") || soakState(s, "visible") {
		t.Fatal("occlusion confused")
	}
	s.Visible = false
	s.Miniaturized = true
	if !soakState(s, "minimized") {
		t.Fatal("minimized refused")
	}
	s.Key = true
	if soakState(s, "minimized") {
		t.Fatal("focused primary qualified")
	}
}
func TestSoakWaitCancellationIsImmediate(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if e := soakSleep(ctx, time.Hour); !errors.Is(e, context.Canceled) {
		t.Fatal(e)
	}
}

func TestSoakWorkerResultSurfacesFailure(t *testing.T) {
	marker := errors.New("worker failed")
	if !errors.Is(soakResult(133693440, marker), marker) {
		t.Fatal("worker error lost")
	}
	if soakResult(0, nil) == nil {
		t.Fatal("wrong checksum accepted")
	}
	if e := soakResult(133693440, nil); e != nil {
		t.Fatal(e)
	}
}
