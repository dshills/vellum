from pathlib import Path
W=Path(__file__).resolve().parent;R=W/'source/paint/renderers/rasterx'
p=R/'outline_cache.go';s=p.read_text();a='func (cache *staticOutlineCache) bounded(face *font.Face, gid font.GID, budget *font.GlyphOutlineBudget) (font.GlyphOutline, bool) {\n';assert s.count(a)==1
s=s.replace(a,a+' outline, _, ok := cache.boundedCost(face,gid,budget)\n return outline,ok\n}\n\nfunc (cache *staticOutlineCache) boundedCost(face *font.Face, gid font.GID, budget *font.GlyphOutlineBudget) (font.GlyphOutline, font.GlyphOutlineCost, bool) {\n',1)
a=s.index('func (cache *staticOutlineCache) boundedCost');z=s.index('// retain is called',a);part=s[a:z];part=part.replace('return face.GlyphDataOutlineBounded(gid, budget)','return face.GlyphDataOutlineBoundedCost(gid, budget)').replace('return font.GlyphOutline{}, false','return font.GlyphOutline{}, font.GlyphOutlineCost{}, false').replace('return entry.outline, true','return entry.outline, entry.cost, true').replace('return outline, true','return outline, cost, true');s=s[:a]+part+s[z:];p.write_text(s)
p=R/'renderer.go';s=p.read_text();s=s.replace('glyphCoverageEnabled bool','glyphCoverageEnabled bool\n rowFragments *rowFragmentCache\n fragmentCosts *[]font.GlyphOutlineCost');s=s.replace('"cogentcore.org/core/styles/units"','"cogentcore.org/core/styles/units"\n "github.com/go-text/typesetting/font"');s=s.replace('rs.glyphMasks = nil','rs.glyphMasks = nil\n rs.rowFragments = nil');a='''		case *render.TextBatch:
			for j := 0; j < x.Len(); j++ {''';b='''		case *render.TextBatch:
            if clip == (image.Rectangle{}) && rs.renderRowBatch(x) {continue}
			for j := 0; j < x.Len(); j++ {''';assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
p=R/'scene_packet.go';s=p.read_text();s=s.replace('glyphMasks: rs.maskResources()}','glyphMasks: rs.maskResources(), rowFragments:rs.rowFragmentStore()}')
a='''		case *render.TextBatch:
			for j := 0; j < x.Len(); j++ {
				text := x.At(j)
				capture.RenderText(&text)''';b='''		case *render.TextBatch:
            capture.renderCapturedRows(x)
            if b.Failed() {return nil}
            continue
			for j := 0; j < x.Len(); j++ {
				text := x.At(j)
				capture.RenderText(&text)''';assert s.count(a)==1;s=s.replace(a,b);# remove now unreachable original loop
start=s.index('            continue\n\t\t\tfor j := 0; j < x.Len(); j++ {');end=s.index('\n\t\tcase *render.Text:',start);s=s[:start]+s[end:];p.write_text(s)
p=R/'text.go';s=p.read_text();a='data, ok := rs.staticOutlines().bounded(run.Face, g.GlyphID, rs.sceneWork.outlines)';b='''data, cost, ok := rs.staticOutlines().boundedCost(run.Face, g.GlyphID, rs.sceneWork.outlines)
            if ok && rs.fragmentCosts != nil { *rs.fragmentCosts = append(*rs.fragmentCosts,cost) }''';assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
print('Patched4privateoriginalleaves')
