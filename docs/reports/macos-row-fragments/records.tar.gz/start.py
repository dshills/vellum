from pathlib import Path
import json,datetime
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');U=T/'drivers/cogent/build/upstream';sources={}
for name in ['paint/renderers/rasterx/renderer.go','paint/renderers/rasterx/scene_packet.go','paint/renderers/rasterx/text.go','paint/renderers/rasterx/outline_cache.go']:
 p=W/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((U/name).read_bytes());sources[str(U/name)]=str(p)
for name in ['paint/renderers/sceneplan/fragment_vellum.go','paint/renderers/rasterx/row_fragments_vellum.go','paint/renderers/sceneplan/fragment_vellum_test.go','paint/renderers/rasterx/row_fragments_vellum_test.go']:
 p=W/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);sources[str(U/name)]=str(p)
(W/'overlay.json').write_text(json.dumps({'Replace':sources},indent=2)+'\n')
p=W/'feasibility-plan.json';s=json.loads(p.read_text());s.update(timebox_started=True,implementation_started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reassessment_utc='2026-10-17T23:55:12Z',status='PRIVATE_OVERLAY_IMPLEMENTATION');p.write_text(json.dumps(s,indent=2)+'\n')
print('Created4originalsources and8path privateoverlay; no prepared source edited')
