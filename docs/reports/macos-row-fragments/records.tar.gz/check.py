from pathlib import Path
import sys,json,time,os,hashlib,threading,_thread,importlib.util
from contextlib import nullcontext
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
mode=sys.argv[1];phase=mode.split('-v')[0];go='/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go'
overlay=W/('diagnostic-overlay.json' if phase=='build-diagnostic' else 'overlay.json')
common=['-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly','-overlay='+str(overlay)]
packages=['cogentcore.org/core/paint/renderers/sceneplan','cogentcore.org/core/paint/renderers/rasterx','cogentcore.org/core/paint/renderers/gpuscene']
if phase=='full':args=[go,'test',*common,'-race','-tags=offscreen',*packages,'-count=1','-v','-timeout=4m']
elif phase=='grid':args=[go,'test',*common,'-race','-tags=offscreen','github.com/dshills/vellum/drivers/cogent','-run=TestManagedGridPanePaint|TestVellumGlyphPlacementActualGridWarm','-count=1','-v','-timeout=4m']
elif phase=='vet':args=[go,'vet',*common,'-tags=offscreen',*packages]
elif phase in ('build','build-diagnostic'):args=[go,'build',*common,'-trimpath','-buildvcs=false','-o','/private/tmp/vellum-ready-native-5482f9b/bin/'+('row-fragments-diagnostic' if phase=='build-diagnostic' else 'row-fragments'),'.']
elif phase=='native-gpu':args=[go,'test',*common,'-race','-tags=offscreen',packages[-1],'-count=1','-v','-timeout=4m']
else:args=[go,'test',*common,'-race','-tags=offscreen',*packages[:2],'-run=TestVellumFragment|TestVellumRowFragments','-count=1','-v','-timeout=3m']
env=dict(os.environ,GOMAXPROCS='2',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOPROXY='off');env.pop('GOFLAGS',None)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [overlay,*map(Path,json.loads(overlay.read_text())['Replace'].values())]}
d={'argv':args,'source_pins':pins,'source_base':'b0534e9f767237e3d7577ea9fde7128bd887889e','native_executed':phase=='native-gpu'};finished=threading.Event();stop=W/('stop-'+mode);context=nullcontext()
if phase=='native-gpu':
 plan=(W/'native-gpu-plan.json').read_bytes();admit=json.loads((W/'native-gpu-admission.json').read_text())
 assert not stop.exists() and admit['execution_ready'] and admit['plan_sha256']==hashlib.sha256(plan).hexdigest()
 assert json.loads(plan)['source_pins']==pins
 env['VELLUM_GPU_SCENE_TEST']='1'
 spec=importlib.util.spec_from_file_location('row_fragment_gpu_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py');lease=importlib.util.module_from_spec(spec);spec.loader.exec_module(lease);context=lease.LiveLease()
 def watch():
  while not finished.wait(.2):
   if stop.exists():_thread.interrupt_main();return
 threading.Thread(target=watch,daemon=True).start()
start=time.monotonic()
try:
 with context:
  assert all(sha(p)==v for p,v in pins.items())
  with (W/(mode+'.stdout')).open('xb')as out,(W/(mode+'.stderr')).open('xb')as err:
   result=run_child(args,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=300,log_limit_bytes=2<<20)
  d['exit_code']=result.returncode
  assert all(sha(p)==v for p,v in pins.items()),'source changed during check'
except BaseException as e:d.update(exit_code=1,error={'type':type(e).__name__,'message':str(e)})
finally:
 finished.set()
 if phase=='native-gpu':stop.touch()
 d['seconds']=time.monotonic()-start;(W/(mode+'-command.json')).write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:d.get(k) for k in ['exit_code','error','seconds','native_executed']}));sys.exit(d['exit_code'])
