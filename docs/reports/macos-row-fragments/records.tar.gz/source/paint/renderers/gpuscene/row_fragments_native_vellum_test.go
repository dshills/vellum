//go:build !js

package gpuscene

import (
	"bytes"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/system/composer"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"io/fs"
	"reflect"
	"testing"
)

func rowNativeHits(r *rasterx.Renderer) uint64 {
	v := reflect.ValueOf(r).Elem().FieldByName("rowFragments")
	if !v.IsValid() || v.IsNil() {
		return 0
	}
	return v.Elem().FieldByName("hits").Uint()
}
func TestVellumRowFragmentsNativeRetainedPixelAndInputLedger(t *testing.T) {
	_, dev := nativeDevice(t)
	size := image.Pt(240, 80)
	res := &resources{}
	defer res.release()
	reserve := func(n uint64) error {
		if n > 128<<20 {
			return fmt.Errorf("native row budget")
		}
		return nil
	}
	if e := res.initialize(dev, size, reserve); e != nil {
		t.Fatal(e)
	}
	shaper := shapedgt.NewShaperWithFonts([]fs.FS{fonts.Default})
	uc := units.Context{}
	uc.Defaults()
	parent := &render.Context{}
	parent.Init(styles.NewPaint(), &render.Bounds{Rect: math32.B2FromRect(image.Rectangle{Max: size})}, nil)
	for _, fontSize := range []float32{10, 24} {
		ts := text.NewStyle()
		ts.FontSize = units.Dot(fontSize)
		ts.WhiteSpace = text.WrapNever
		ts.ToDots(&uc)
		src := rich.NewText(rich.NewStyle(), []rune("12.5"))
		runs := shaper.Shape(src, ts)
		if len(runs) == 0 {
			t.Fatal("no shaped glyphs")
		}
		lines := &shaped.Lines{Source: src, Color: color.NRGBA{40, 100, 180, 137}, Lines: []shaped.Line{{Runs: runs, Offset: math32.Vec2(0, 30)}}}
		batch := render.NewTextBatch(parent)
		var original render.Render
		for i := range 3 {
			position := math32.Vec2(5.25+80*float32(i), 2.5)
			clip := image.Rect(i*80, 1, (i+1)*80, 74)
			batch.Add(lines, position, clip)
			one := batch.At(i)
			original = append(original, &one)
		}
		rs := rasterx.New(math32.FromPoint(size)).(*rasterx.Renderer)
		reference := rasterx.New(math32.FromPoint(size)).(*rasterx.Renderer)
		clearCmd := pimage.NewDraw(image.Rectangle{Max: size}, image.NewUniform(color.RGBA{19, 37, 61, 255}), nil, image.Point{}, draw.Src)
		complete := append(render.Render{clearCmd}, batch)
		ordinary := append(render.Render{clearCmd}, original...)
		if rs.ScenePacket(complete) == nil {
			t.Fatal("cold capture refused")
		}
		before := rowNativeHits(rs)
		warm := rs.ScenePacket(complete)
		if warm == nil || rowNativeHits(rs) <= before {
			t.Fatal("warm native fixture did not use actual row fragment", fontSize)
		}
		expected := image.NewRGBA(image.Rectangle{Max: size})
		reference.Render(ordinary)
		if !warm.Replay(expected) || !bytes.Equal(expected.Pix, reference.Image().(*image.RGBA).Pix) {
			t.Fatal("warm packet differs from uncached original")
		}
		submit := func(packetCommands render.Render) {
			t.Helper()
			p := rs.ScenePacket(packetCommands)
			if p == nil {
				t.Fatal("capture refused")
			}
			encoded, ok := p.EncodeGPU()
			if !ok {
				t.Fatal("encode refused")
			}
			host := &composer.SceneHostTiming{Available: true}
			if e := res.renderWithTiming(encoded, reserve, host); e != nil {
				t.Fatal(e)
			}
			if host.InputWriteAttempts != 5 || host.InputWriteErrors != 0 || host.QueueSubmitAttempts != 1 || host.LogicalInputBytes != uint64(16+len(encoded.Ops)+len(encoded.Rows)+len(encoded.Refs)+len(encoded.Data)) {
				t.Fatal("original input ledger changed", host)
			}
			if !bytes.Equal(readTexture(t, dev, res.texture).Pix, expected.Pix) {
				t.Fatal("native retained pixels differ", fontSize)
			}
		}
		submit(complete)
		partial := rs.ScenePacket(render.Render{batch})
		if partial == nil || partial.Independent() {
			t.Fatal("partial fixture lost retained dependency")
		}
		fresh := image.NewRGBA(expected.Rect)
		partial.Replay(fresh)
		partial.Replay(expected)
		if bytes.Equal(fresh.Pix, expected.Pix) {
			t.Fatal("fixture cannot distinguish retained from fresh target")
		}
		submit(render.Render{batch})
		rs.Release()
		reference.Release()
	}
}
