// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package sceneplan

import (
	"image"
	"unsafe"
)

// Fragment owns a detached operation interval at exact original coordinates.
// It exposes no pixels, mask bytes, operation slices, or builder references.
// Reuse with a different placement or clip is deliberately unsupported.
type Fragment struct {
	packet           Packet
	masks            map[*image.Alpha]*MaskResource
	charge, retained int
}

// BeginFragment closes the preceding stream, as the next glyph draw does, and
// returns an interval marker confined to this builder's construction lifetime.
func (b *Builder) BeginFragment() int { b.flush(); return b.count }

// EndFragment snapshots completed operations. Mutable-source masks and pixels
// decline retention; the current ordinary construction remains unchanged.
func (b *Builder) EndFragment(start int) *Fragment {
	b.flush()
	if b.failed || start < 0 || start > b.count || b.count-start > 1024 {
		return nil
	}
	f := &Fragment{packet: Packet{bounds: b.packet.bounds}, masks: make(map[*image.Alpha]*MaskResource)}
	available := make(map[*image.Alpha]*MaskResource, len(b.maskResources))
	for m := range b.maskResources {
		available[m.mask] = m
	}
	for block, base := b.head, 0; block != nil; block, base = block.next, base+operationBlockSize {
		for j := 0; j < operationBlockSize && base+j < b.count; j++ {
			if base+j < start {
				continue
			}
			o := block.ops[j]
			if o.kind == Pixels || o.kind == Mask && available[o.mask] == nil {
				return nil
			}
			f.packet.ops = append(f.packet.ops, o)
			f.charge += int(unsafe.Sizeof(operation{}))
			if o.kind == Mask {
				f.masks[o.mask] = available[o.mask]
			}
			if o.kind == Spans {
				f.charge += len(o.rows) * int(unsafe.Sizeof([]span{}))
				for _, r := range o.rows {
					f.charge += len(r) * int(unsafe.Sizeof(span{}))
				}
			}
		}
	}
	for _, m := range f.masks {
		f.charge += m.Bytes()
	}
	// Count map/node and interval headers conservatively as retained cache bytes.
	f.retained = f.charge + (cap(f.packet.ops)-len(f.packet.ops))*int(unsafe.Sizeof(operation{})) + int(unsafe.Sizeof(Fragment{})) + len(f.masks)*96
	if f.retained > 256<<10 {
		return nil
	}
	return f
}
func (f *Fragment) Bytes() int {
	if f == nil {
		return 0
	}
	return f.retained
}
func (f *Fragment) Operations() int {
	if f == nil {
		return 0
	}
	return len(f.packet.ops)
}
func (f *Fragment) Replay(dst *image.RGBA) bool { return f != nil && f.packet.Replay(dst) }

// AppendFragment replays original admission and ordered owned operations. Near
// byte/operation limits it declines without refusing the builder, so the caller
// runs ordinary capture. The extra row-header headroom bounds the original
// scanner stream's geometric temporary growth, including a full-height stream.
func (b *Builder) AppendFragment(f *Fragment) bool {
	if !b.CanAppendFragment(f) {
		return false
	}
	for _, o := range f.packet.ops {
		if o.kind == Mask {
			resource := f.masks[o.mask]
			if !b.maskResources[resource] {
				if !b.reserve(resource.Bytes()) {
					return false
				}
				if b.maskResources == nil {
					b.maskResources = make(map[*MaskResource]bool)
				}
				b.maskResources[resource] = true
			}
		}
		if o.kind == Spans {
			n := len(o.rows) * int(unsafe.Sizeof([]span{}))
			for _, r := range o.rows {
				n += len(r) * int(unsafe.Sizeof(span{}))
			}
			if !b.reserve(n) {
				return false
			}
		}
		b.add(o)
	}
	return !b.failed
}

func (b *Builder) CanAppendFragment(f *Fragment) bool {
	return b.stream == nil && f != nil && !b.failed && f.packet.bounds == b.packet.bounds && len(f.packet.ops) <= MaxOps-b.count && f.charge+MaxDimension*int(unsafe.Sizeof([]span{})) <= MaxBytes-b.packet.bytes
}
