package sceneplan

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"testing"
)

func TestVellumFragmentAdmissionPixelsAndLifetime(t *testing.T) {
	bounds := image.Rect(0, 0, 47, 35)
	mask := image.NewAlpha(image.Rect(0, 0, 8, 9))
	for i := range mask.Pix {
		mask.Pix[i] = uint8(i * 17)
	}
	resource := NewMaskResource(mask)
	paint := func(b *Builder) {
		b.DrawMaskResource(image.Rect(4, 5, 12, 14), image.NewUniform(color.NRGBA{30, 80, 190, 133}), resource, image.Point{}, draw.Over)
		b.BeginSpans(color.RGBA{60, 90, 130, 177}, draw.Over)
		b.Span(9, 2, 16, 33111)
		b.Span(10, 7, 28, 61000)
	}
	source := New(bounds)
	start := source.BeginFragment()
	paint(source)
	f := source.EndFragment(start)
	original := source.Seal(false)
	if f == nil || f.Bytes() == 0 {
		t.Fatal("no retained fragment")
	}
	actual := New(bounds)
	reference := New(bounds)
	for range 3 {
		if !actual.AppendFragment(f) {
			t.Fatal("append refused")
		}
		paint(reference)
	}
	got, want := actual.Seal(false), reference.Seal(false)
	a, b := image.NewRGBA(bounds), image.NewRGBA(bounds)
	got.Replay(a)
	want.Replay(b)
	if !bytes.Equal(a.Pix, b.Pix) || got.Bytes() != want.Bytes() {
		t.Fatal("pixels or original resource dedup/charges differ", got.Bytes(), want.Bytes())
	}
	ge, gok := got.EncodeGPU()
	we, wok := want.EncodeGPU()
	if !gok || !wok || !bytes.Equal(ge.Ops, we.Ops) || !bytes.Equal(ge.Data, we.Data) || !bytes.Equal(ge.Refs, we.Refs) || !bytes.Equal(ge.Rows, we.Rows) {
		t.Fatal("ordered encoded stream differs")
	}
	clear(mask.Pix)
	c := image.NewRGBA(bounds)
	f.Replay(c)
	clear(a.Pix)
	original.Replay(a)
	if !bytes.Equal(a.Pix, c.Pix) {
		t.Fatal("builder retirement or borrowed mask mutation changed fragment")
	}
	wrong := New(image.Rect(0, 0, 48, 35))
	before := wrong.packet.bytes
	if wrong.AppendFragment(f) || wrong.failed || wrong.count != 0 || wrong.packet.bytes != before {
		t.Fatal("wrong-target refusal not transactional")
	}
	limit := New(bounds)
	limit.packet.bytes = MaxBytes - 1
	if limit.CanAppendFragment(f) || limit.AppendFragment(f) || limit.failed || limit.count != 0 || limit.packet.bytes != MaxBytes-1 {
		t.Fatal("near-limit refusal changed original route")
	}
}
func TestVellumFragmentMutableAndPixelRefusal(t *testing.T) {
	for _, pixels := range []bool{false, true} {
		b := New(image.Rect(0, 0, 20, 20))
		mark := b.BeginFragment()
		src := image.Image(image.White)
		var mask image.Image = image.NewAlpha(image.Rect(0, 0, 4, 4))
		if pixels {
			src = image.NewRGBA(image.Rect(0, 0, 4, 4))
			mask = nil
		}
		b.Draw(image.Rect(1, 1, 5, 5), src, image.Point{}, mask, image.Point{}, draw.Over)
		if b.EndFragment(mark) != nil || b.Failed() || b.Seal(false) == nil {
			t.Fatal("unsupported retention changed ordinary admission")
		}
	}
}
