// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package rasterx

import (
	"container/list"
	"image"
	"image/color"
	"image/draw"
	"slices"
	"strings"
	"unsafe"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/styles/sides"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"github.com/go-text/typesetting/di"
	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/shaping"
	"golang.org/x/image/math/fixed"
)

const rowFragmentBytes = 8 << 20
const rowFragmentEntries = 1024
const rowFragmentFonts = 8

type rowRunProof struct {
	face                    *font.Font
	ppem                    [2]uint16
	font                    text.Font
	maxBounds               math32.Box2
	advance, size           fixed.Int26_6
	direction               di.Direction
	runes                   shaping.Range
	lineBounds, glyphBounds shaping.Bounds
	visual                  int32
	fill                    [4]uint32
	glyphs                  []shaping.Glyph
}
type rowLineProof struct {
	offset math32.Vector2
	bounds math32.Box2
	runs   []rowRunProof
}
type rowTextProof struct {
	position, offset                  math32.Vector2
	bounds                            math32.Box2
	clip                              image.Rectangle
	color, selection, highlight       [4]uint32
	fontSize, lineHeight, contextSize float32
	direction                         rich.Directions
	truncated                         bool
	lines                             []rowLineProof
}
type rowKey struct {
	first, last                   image.Rectangle
	position, end                 math32.Vector2
	count                         int
	winding, glyphCache, coverage bool
	op                            draw.Op
	content                       uint64
}
type rowFragmentEntry struct {
	key         rowKey
	proof       []rowTextProof
	fragment    *sceneplan.Fragment
	costs       []font.GlyphOutlineCost
	fonts       []*font.Font
	work, bytes int
	winding     bool
}
type rowFragmentCache struct {
	entries      map[rowKey]*list.Element
	fonts        map[*font.Font]int
	lru          list.List
	bytes        int
	hits, misses uint64
}

func (rs *Renderer) rowFragmentStore() *rowFragmentCache {
	if rs.rowFragments == nil {
		rs.rowFragments = &rowFragmentCache{entries: make(map[rowKey]*list.Element), fonts: make(map[*font.Font]int)}
	}
	return rs.rowFragments
}
func valueColor(c color.Color) ([4]uint32, bool) {
	if c == nil {
		return [4]uint32{}, true
	}
	u := image.Uniform{C: c}
	return sceneplan.Color(&u)
}
func rowImageColor(c image.Image) ([4]uint32, bool) {
	if c == nil {
		return [4]uint32{}, true
	}
	return sceneplan.Color(c)
}

// compareRow reads only known value fields. Borrowed pointers never certify a
// hit. On a miss, clone only these bounded values, not layouts, faces or widgets.
func compareRow(batch *render.TextBatch, start, end int, proof []rowTextProof, copyValues bool) ([]rowTextProof, []*font.Font, bool) {
	if end-start < 1 || end-start > 64 || !copyValues && len(proof) != end-start {
		return nil, nil, false
	}
	var own []rowTextProof
	var fonts []*font.Font
	if copyValues {
		own = make([]rowTextProof, end-start)
	}
	for at := start; at < end; at++ {
		t := batch.At(at)
		lns := t.Text
		c := &t.Context
		if lns == nil || lns.Color == nil || t.Geometry != nil || c.Cumulative != math32.Identity2() || c.Mask != nil || len(c.ClipPath) != 0 || len(c.Bounds.Path) != 0 || !sides.AreZero(c.Bounds.Radius.Sides) || c.Bounds.Rect != math32.B2FromRect(c.Bounds.Rect.ToRect()) || len(lns.Lines) > 4 {
			return nil, nil, false
		}
		clr, ok := valueColor(lns.Color)
		if !ok {
			return nil, nil, false
		}
		sel, ok := rowImageColor(lns.SelectionColor)
		if !ok {
			return nil, nil, false
		}
		hi, ok := rowImageColor(lns.HighlightColor)
		if !ok {
			return nil, nil, false
		}
		p := rowTextProof{position: t.Position, offset: lns.Offset, bounds: lns.Bounds, clip: c.Bounds.Rect.ToRect(), color: clr, selection: sel, highlight: hi, fontSize: lns.FontSize, lineHeight: lns.LineHeight, contextSize: c.Style.Text.FontSize.Dots, direction: lns.Direction, truncated: lns.Truncated}
		var prior *rowTextProof
		if copyValues {
			p.lines = make([]rowLineProof, len(lns.Lines))
		} else {
			prior = &proof[at-start]
			if p.position != prior.position || p.offset != prior.offset || p.bounds != prior.bounds || p.clip != prior.clip || p.color != prior.color || p.selection != prior.selection || p.highlight != prior.highlight || p.fontSize != prior.fontSize || p.lineHeight != prior.lineHeight || p.contextSize != prior.contextSize || p.direction != prior.direction || p.truncated != prior.truncated || len(lns.Lines) != len(prior.lines) {
				return nil, nil, false
			}
		}
		totalGlyphs := 0
		for li := range lns.Lines {
			ln := &lns.Lines[li]
			if len(ln.Selections) != 0 || len(ln.Highlights) != 0 || len(ln.Runs) > 8 {
				return nil, nil, false
			}
			line := rowLineProof{offset: ln.Offset, bounds: ln.Bounds}
			if copyValues {
				line.runs = make([]rowRunProof, len(ln.Runs))
			} else if line.offset != prior.lines[li].offset || line.bounds != prior.lines[li].bounds || len(ln.Runs) != len(prior.lines[li].runs) {
				return nil, nil, false
			}
			for ri, raw := range ln.Runs {
				run, ok := raw.(*shapedgt.Run)
				if !ok || run == nil || run.Face == nil || !run.Face.SupportsBoundedOutlines() || len(run.Face.Coords()) != 0 || run.Direction.IsVertical() || run.Math.Path != nil || run.Decoration != 0 || run.Background != nil || run.StrokeColor != nil {
					return nil, nil, false
				}
				if len(run.Font.Family) > 1024 {
					return nil, nil, false
				}
				totalGlyphs += len(run.Glyphs)
				if totalGlyphs > 128 {
					return nil, nil, false
				}
				fill := clr
				if run.FillColor != nil {
					fill, ok = rowImageColor(run.FillColor)
					if !ok {
						return nil, nil, false
					}
				}
				x, y := run.Face.Ppem()
				rp := rowRunProof{face: run.Face.Font, ppem: [2]uint16{x, y}, font: run.Font, maxBounds: run.MaxBounds, advance: run.Output.Advance, size: run.Size, direction: run.Direction, runes: run.Output.Runes, lineBounds: run.Output.LineBounds, glyphBounds: run.Output.GlyphBounds, visual: run.VisualIndex, fill: fill}
				// Advance() converts fixed to float; preserve the exact source field.
				rp.advance = run.Output.Advance
				if copyValues {
					rp.glyphs = slices.Clone(run.Glyphs)
					rp.font.Family = strings.Clone(rp.font.Family)
					line.runs[ri] = rp
					if !slices.Contains(fonts, rp.face) {
						fonts = append(fonts, rp.face)
					}
				} else {
					old := &prior.lines[li].runs[ri]
					if rp.face != old.face || rp.ppem != old.ppem || rp.font != old.font || rp.maxBounds != old.maxBounds || rp.advance != old.advance || rp.size != old.size || rp.direction != old.direction || rp.runes != old.runes || rp.lineBounds != old.lineBounds || rp.glyphBounds != old.glyphBounds || rp.visual != old.visual || rp.fill != old.fill || !slices.Equal(run.Glyphs, old.glyphs) {
						return nil, nil, false
					}
				}
			}
			if copyValues {
				p.lines[li] = line
			}
		}
		if copyValues {
			own[at-start] = p
		}
	}
	return own, fonts, true
}
func rowBounds(batch *render.TextBatch, start int) (int, image.Rectangle) {
	first := batch.At(start).Context.Bounds.Rect.ToRect()
	end := start + 1
	for end < batch.Len() {
		r := batch.At(end).Context.Bounds.Rect.ToRect()
		if r.Min.Y != first.Min.Y || r.Max.Y != first.Max.Y {
			break
		}
		end++
	}
	return end, first
}

// This discriminator avoids evicting alternating text values at one location.
// It is not an identity proof: every candidate still compares all paint inputs.
func rowContentHash(batch *render.TextBatch, start, end int) uint64 {
	if end-start < 1 || end-start > 64 {
		return 0
	}
	h := uint64(14695981039346656037)
	for i := start; i < end; i++ {
		t := batch.At(i)
		if t.Text == nil || len(t.Text.Lines) > 4 {
			return 0
		}
		count := 0
		h = (h ^ uint64(len(t.Text.Lines))) * 1099511628211
		for _, ln := range t.Text.Lines {
			if len(ln.Runs) > 8 {
				return 0
			}
			h = (h ^ uint64(len(ln.Runs))) * 1099511628211
			for _, raw := range ln.Runs {
				r, ok := raw.(*shapedgt.Run)
				if !ok || r == nil {
					return 0
				}
				count += len(r.Glyphs)
				if count > 128 {
					return 0
				}
				h = (h ^ uint64(uint32(r.Size))) * 1099511628211
				for _, g := range r.Glyphs {
					h = (h ^ uint64(g.GlyphID)) * 1099511628211
					h = (h ^ uint64(uint32(g.Advance))) * 1099511628211
				}
			}
		}
	}
	return h
}
func (rs *Renderer) rowLookup(batch *render.TextBatch, start, end int) (rowKey, *rowFragmentEntry) {
	a, z := batch.At(start), batch.At(end-1)
	op := rs.ImgSpanner
	actualOp := draw.Over
	if op != nil {
		actualOp = op.Op
	}
	if spanner, ok := rs.Scanner.Spanner.(*sceneSpanner); ok {
		actualOp = draw.Op(spanner.op)
	}
	key := rowKey{first: a.Context.Bounds.Rect.ToRect(), last: z.Context.Bounds.Rect.ToRect(), position: a.Position, end: z.Position, count: end - start, winding: rs.Scanner.UseNonZeroWinding, glyphCache: UseGlyphCache, coverage: rs.glyphCoverageEnabled, op: actualOp, content: rowContentHash(batch, start, end)}
	store := rs.rowFragmentStore()
	if el := store.entries[key]; el != nil {
		entry := el.Value.(*rowFragmentEntry)
		if _, _, ok := compareRow(batch, start, end, entry.proof, false); ok {
			store.lru.MoveToFront(el)
			return key, entry
		}
		store.remove(el)
	}
	return key, nil
}
func (c *rowFragmentCache) remove(el *list.Element) {
	e := el.Value.(*rowFragmentEntry)
	delete(c.entries, e.key)
	c.bytes -= e.bytes
	for _, f := range e.fonts {
		c.fonts[f]--
		if c.fonts[f] == 0 {
			delete(c.fonts, f)
		}
	}
	c.lru.Remove(el)
}
func (rs *Renderer) retainRow(batch *render.TextBatch, start, end int, key rowKey, fragment *sceneplan.Fragment, work int, costs []font.GlyphOutlineCost, winding bool) {
	if fragment == nil {
		return
	}
	proof, fonts, ok := compareRow(batch, start, end, nil, true)
	if !ok || len(fonts) > rowFragmentFonts {
		return
	}
	bytes := fragment.Bytes() + cap(costs)*int(unsafe.Sizeof(font.GlyphOutlineCost{})) + cap(proof)*int(unsafe.Sizeof(rowTextProof{})) + 512
	for _, t := range proof {
		bytes += cap(t.lines) * int(unsafe.Sizeof(rowLineProof{}))
		for _, l := range t.lines {
			bytes += cap(l.runs) * int(unsafe.Sizeof(rowRunProof{}))
			for _, r := range l.runs {
				bytes += cap(r.glyphs)*int(unsafe.Sizeof(shaping.Glyph{})) + len(r.font.Family)
			}
		}
	}
	if bytes > rowFragmentBytes {
		return
	}
	c := rs.rowFragmentStore()
	for {
		missing := 0
		for _, f := range fonts {
			if c.fonts[f] == 0 {
				missing++
			}
		}
		if c.bytes+bytes <= rowFragmentBytes && len(c.entries) < rowFragmentEntries && len(c.fonts)+missing <= rowFragmentFonts {
			break
		}
		if c.lru.Len() == 0 {
			return
		}
		c.remove(c.lru.Back())
	}
	entry := &rowFragmentEntry{key: key, proof: proof, fragment: fragment, costs: slices.Clone(costs), fonts: fonts, work: work, bytes: bytes, winding: winding}
	if old := c.entries[key]; old != nil {
		c.remove(old)
	}
	c.entries[key] = c.lru.PushFront(entry)
	c.bytes += bytes
	for _, f := range fonts {
		c.fonts[f]++
	}
}
func (rs *Renderer) rowStateReady() bool {
	if rs.Scanner == nil || rs.Raster == nil || len(rs.Path) != 0 {
		return false
	}
	bounds, ok := rs.glyphCoverageReady(image.Black)
	return ok && bounds == (image.Rectangle{Max: rs.size.ToPointCeil()}) && (rs.image == nil || bounds == rs.image.Bounds())
}
func (rs *Renderer) rowFinished(winding bool, clip image.Rectangle) {
	rs.Path.Clear()
	rs.Raster.Clear()
	rs.Scanner.SetWinding(winding)
	rs.Scanner.SetClip(clip)
}
func (rs *Renderer) renderCapturedRows(batch *render.TextBatch) {
	for start := 0; start < batch.Len(); {
		end, _ := rowBounds(batch, start)
		key, entry := rs.rowLookup(batch, start, end)
		if entry != nil && rs.rowStateReady() && rs.sceneRecord.CanAppendFragment(entry.fragment) {
			if !rs.sceneWork.take(entry.work) {
				rs.sceneRecord.Refuse()
				return
			}
			for _, cost := range entry.costs {
				if !cost.Charge(rs.sceneWork.outlines) {
					rs.sceneRecord.Refuse()
					return
				}
			}
			if !rs.sceneRecord.AppendFragment(entry.fragment) {
				rs.sceneRecord.Refuse()
				return
			}
			rs.rowFragments.hits++
			rs.rowFinished(entry.winding, batch.At(end-1).Context.Bounds.Rect.ToRect())
			start = end
			continue
		}
		rs.rowFragments.misses++
		if !rs.rowStateReady() {
			for at := start; at < end; at++ {
				text := batch.At(at)
				rs.RenderText(&text)
			}
			start = end
			continue
		}
		mark := rs.sceneRecord.BeginFragment()
		before := rs.sceneWork.remaining
		var costs []font.GlyphOutlineCost
		rs.fragmentCosts = &costs
		for at := start; at < end; at++ {
			t := batch.At(at)
			rs.RenderText(&t)
			if rs.sceneRecord.Failed() {
				break
			}
		}
		rs.fragmentCosts = nil
		fragment := rs.sceneRecord.EndFragment(mark)
		if !rs.sceneRecord.Failed() {
			rs.retainRow(batch, start, end, key, fragment, before-rs.sceneWork.remaining, costs, rs.Scanner.UseNonZeroWinding)
		}
		start = end
	}
}
func (rs *Renderer) renderRowBatch(batch *render.TextBatch) bool {
	if rs.scrollRecord != nil || rs.sceneRecord != nil || rs.Scanner == nil || rs.Raster == nil || len(rs.Path) != 0 {
		return false
	}
	if !rs.rowStateReady() {
		return false
	}
	for start := 0; start < batch.Len(); {
		end, _ := rowBounds(batch, start)
		key, entry := rs.rowLookup(batch, start, end)
		if entry != nil && rs.rowStateReady() && entry.fragment.Replay(rs.image) {
			rs.rowFragments.hits++
			rs.rowFinished(entry.winding, batch.At(end-1).Context.Bounds.Rect.ToRect())
			start = end
			continue
		}
		rs.rowFragments.misses++
		if _, _, ok := compareRow(batch, start, end, nil, true); ok && rs.rowStateReady() {
			commands := make(render.Render, 0, end-start)
			for at := start; at < end; at++ {
				t := batch.At(at)
				commands = append(commands, &t)
			}
			out := rs.compileScene(commands, true)
			if out.packet != nil && out.fragment != nil && out.packet.Replay(rs.image) {
				rs.retainRow(batch, start, end, key, out.fragment, out.work, out.costs, out.packet.Winding())
				rs.rowFinished(out.packet.Winding(), batch.At(end-1).Context.Bounds.Rect.ToRect())
				start = end
				continue
			}
		}
		for at := start; at < end; at++ {
			t := batch.At(at)
			if !t.Context.Bounds.Rect.IsEmpty() {
				rs.RenderText(&t)
			}
		}
		start = end
	}
	return true
}
