// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package rasterx

import (
	"bytes"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/styles"
	"image"
	"testing"
)

func TestTextBatchCPUReplayCaptureAndRefusal(t *testing.T) {
	text := vellumSceneText(t)
	text.Text.SelectReset()
	text.Text.HighlightReset()
	parent := text.Context
	batch := render.NewTextBatch(&parent)
	var ordinary render.Render
	for _, p := range []math32.Vector2{math32.Vec2(7.25, 2.5), math32.Vec2(18.5, 27.25)} {
		bounds := image.Rect(3, 1, 211, 79)
		batch.Add(text.Text, p, bounds)
		ctx := render.NewContext(nil, render.NewBoundsRect(bounds, parent.Bounds.Radius), &parent)
		ordinary = append(ordinary, render.NewText(text.Text, styles.NewPaint(), ctx, p))
	}
	reference := New(math32.Vec2(240, 80)).(*Renderer)
	reference.Render(ordinary)
	actual := New(math32.Vec2(240, 80)).(*Renderer)
	actual.Render(render.Render{batch})
	if !bytes.Equal(reference.image.Pix, actual.image.Pix) {
		t.Fatal("CPU batch changed ordered overlapping text")
	}
	packet := actual.ScenePacket(render.Render{batch})
	dst := image.NewRGBA(actual.image.Rect)
	if packet == nil || !packet.Replay(dst) || !bytes.Equal(reference.image.Pix, dst.Pix) {
		t.Fatal("batch packet mismatch")
	}
	if actual.glyphMasks == nil || actual.glyphMasks.count == 0 {
		t.Fatal("actual bitmap route did not retain sealed masks")
	}
	hits := actual.glyphMasks.hits
	rowHits := actual.rowFragmentStore().hits
	if actual.ScenePacket(render.Render{batch}) == nil || actual.glyphMasks.hits <= hits && actual.rowFragmentStore().hits <= rowHits {
		t.Fatal("warm capture did not reuse immutable resources")
	}
	// An unknown render command refuses the whole capture. Ordinary CPU replay
	// skips that unsupported command and must paint the batch exactly once.
	commands := render.Render{batch, &unknownBatchCommand{}}
	before := append([]byte(nil), actual.image.Pix...)
	clip := actual.Scanner.Clip
	winding := actual.Scanner.UseNonZeroWinding
	if actual.ScenePacket(commands) != nil || !bytes.Equal(before, actual.image.Pix) || actual.Scanner.Clip != clip || actual.Scanner.UseNonZeroWinding != winding {
		t.Fatal("refusal changed CPU state")
	}
	clear(actual.image.Pix)
	actual.Render(commands)
	if !bytes.Equal(reference.image.Pix, actual.image.Pix) {
		t.Fatal("ordinary fallback lost or duplicated batch")
	}
	// A retained packet survives cache destruction and subsequent owner reuse.
	actual.Release()
	clear(dst.Pix)
	packet.Replay(dst)
	if !bytes.Equal(reference.image.Pix, dst.Pix) {
		t.Fatal("release changed retained packet")
	}
	for _, invalid := range []*render.TextBatch{nil, render.NewTextBatch(&parent)} {
		if actual.ScenePacket(render.Render{invalid}) != nil {
			t.Fatal("invalid batch admitted")
		}
	}
	invalid := render.NewTextBatch(&parent)
	invalid.Add(nil, math32.Vector2{}, image.Rect(0, 0, 2, 2))
	if actual.ScenePacket(render.Render{invalid}) != nil {
		t.Fatal("nil layout admitted")
	}
	huge := render.NewTextBatch(&parent)
	for range sceneplan.MaxOps/3 + 1 {
		huge.Add(text.Text, math32.Vector2{}, image.Rect(0, 0, 2, 2))
	}
	if actual.ScenePacket(render.Render{huge}) != nil {
		t.Fatal("logical text command limit bypassed")
	}
}

type unknownBatchCommand struct{}

func (*unknownBatchCommand) IsRenderItem()  {}
func (*unknownBatchCommand) String() string { return "batch refusal fixture" }
