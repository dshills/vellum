package rasterx

import (
	"bytes"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/ppath"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx/scan"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"github.com/go-text/typesetting/font"
	"golang.org/x/image/math/fixed"
	"image"
	"image/color"
	"image/draw"
	"slices"
	"testing"
)

func TestVellumRowFragmentsMutableProofPixelsAndCleanup(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	parent := txt.Context
	batch := render.NewTextBatch(&parent)
	batch.Add(txt.Text, math32.Vec2(7.25, 2.5), image.Rect(2, 1, 218, 64))
	actual := New(math32.Vec2(240, 80)).(*Renderer)
	oracle := New(math32.Vec2(240, 80)).(*Renderer)
	check := func(label string) {
		t.Helper()
		clear(actual.image.Pix)
		clear(oracle.image.Pix)
		clearCmd := pimage.NewDraw(actual.image.Rect, image.NewUniform(color.NRGBA{19, 41, 73, 137}), nil, image.Point{}, draw.Src)
		one := batch.At(0)
		ordinary := render.Render{clearCmd, &one}
		commands := render.Render{clearCmd, batch}
		oracle.Render(ordinary)
		actual.Render(commands)
		if !bytes.Equal(actual.image.Pix, oracle.image.Pix) {
			t.Fatal(label, "CPU original pixels differ")
		}
		p, q := actual.ScenePacket(commands), oracle.ScenePacket(ordinary)
		if p == nil || q == nil {
			t.Fatal(label, "capture refused")
		}
		a, b := image.NewRGBA(actual.image.Rect), image.NewRGBA(actual.image.Rect)
		p.Replay(a)
		q.Replay(b)
		if !bytes.Equal(a.Pix, b.Pix) || !bytes.Equal(a.Pix, oracle.image.Pix) {
			t.Fatal(label, "captured/cached original replay differs")
		}
	}
	check("cold")
	hits := actual.rowFragments.hits
	check("warm")
	if actual.rowFragments.hits <= hits {
		t.Fatal("no positive retained-fragment hit")
	}
	run := txt.Text.Lines[0].Runs[0].(*shapedgt.Run)
	old := run.Glyphs[0].XOffset
	run.Glyphs[0].XOffset += 13
	check("same-pointer glyph mutation")
	run.Glyphs[0].XOffset = old
	txt.Text.Color = color.NRGBA{180, 15, 30, 89}
	check("same-pointer color mutation")
	for _, size := range []math32.Vector2{math32.Vec2(241, 81), math32.Vec2(240, 80)} {
		actual.SetSize(0, size)
		if actual.rowFragments != nil {
			t.Fatal("resize retained row fragments")
		}
	}
	actual.Release()
	if actual.rowFragments != nil {
		t.Fatal("release retained fragment/font/proof refs")
	}
}

func TestVellumRowFragmentsOriginalWorkAndOutlineAdmission(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	batch := render.NewTextBatch(&txt.Context)
	batch.Add(txt.Text, math32.Vec2(7.25, 2.5), image.Rect(0, 0, 220, 75))
	owner := New(math32.Vec2(240, 80)).(*Renderer)
	if owner.ScenePacket(render.Render{batch}) == nil {
		t.Fatal("warmup refused")
	}
	var entry *rowFragmentEntry
	for _, e := range owner.rowFragments.entries {
		entry = e.Value.(*rowFragmentEntry)
	}
	if entry == nil || entry.work == 0 || len(entry.costs) == 0 {
		t.Fatal("fixture has no actual charged work")
	}
	run := func(cached bool, work, outline int) (*sceneplan.Packet, int) {
		r := New(math32.Vec2(240, 80)).(*Renderer)
		r.sceneRecord = sceneplan.New(r.image.Bounds())
		r.sceneWork = &sceneWorkBudget{remaining: work, outlines: font.NewGlyphOutlineBudget(outline, outline)}
		r.Scanner.Spanner = &sceneSpanner{builder: r.sceneRecord, op: int(draw.Over)}
		if cached {
			r.rowFragments = owner.rowFragments
			r.renderCapturedRows(batch)
		} else {
			one := batch.At(0)
			r.RenderText(&one)
		}
		return r.sceneRecord.Seal(r.Scanner.UseNonZeroWinding), r.sceneWork.remaining
	}
	for _, limit := range []int{0, entry.work - 1, entry.work, entry.work + 100} {
		a, ar := run(false, limit, 1<<20)
		b, br := run(true, limit, 1<<20)
		if (a == nil) != (b == nil) {
			t.Fatal("cache bypassed original work refusal", limit)
		}
		if a != nil && (ar != br || a.Bytes() != b.Bytes()) {
			t.Fatal("successful original work/byte charges differ", ar, br)
		}
	}
	for _, limit := range []int{0, 1, 8, 1 << 20} {
		a, _ := run(false, sceneMaxWork, limit)
		b, _ := run(true, sceneMaxWork, limit)
		if (a == nil) != (b == nil) {
			t.Fatal("cache bypassed original outline admission", limit)
		}
	}
}

func TestVellumRowFragmentsCachedToOrdinaryAndPositionProof(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	for _, phase := range []float32{0, .25, .5, .6875, .75} {
		owner := New(math32.Vec2(240, 80)).(*Renderer)
		reference := New(math32.Vec2(240, 80)).(*Renderer)
		for step := 0; step < 8; step++ {
			batch := render.NewTextBatch(&txt.Context)
			clip := image.Rect(step%3, 1, 218-step%2, 76)
			position := math32.Vec2(7+phase+float32(step%2), 2.5)
			batch.Add(txt.Text, position, clip)
			one := batch.At(0)
			tail := *txt
			tail.Position = math32.Vec2(31.75, 16.25)
			tail.Context.Cumulative = math32.Translate2D(3.5, 1.25).Scale(.9, .9)
			clear(owner.image.Pix)
			clear(reference.image.Pix)
			reference.Render(render.Render{&one, &tail})
			owner.Render(render.Render{batch, &tail})
			if !bytes.Equal(owner.image.Pix, reference.image.Pix) {
				t.Fatal("cached→ordinary scanner transition mismatch", phase, step)
			}
			got, want := owner.ScenePacket(render.Render{batch, &tail}), reference.ScenePacket(render.Render{&one, &tail})
			if got == nil || want == nil {
				t.Fatal("transition capture refused")
			}
			a, b := image.NewRGBA(owner.image.Rect), image.NewRGBA(owner.image.Rect)
			got.Replay(a)
			want.Replay(b)
			if !bytes.Equal(a.Pix, b.Pix) {
				t.Fatal("GPU fragment transition changed pixels")
			}
		}
		if owner.rowFragments.hits == 0 {
			t.Fatal("transition fixture never hit")
		}
	}
}

func TestVellumRowFragmentsBlendAndNilColorMutation(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	batch := render.NewTextBatch(&txt.Context)
	batch.Add(txt.Text, math32.Vec2(7.25, 2.5), image.Rect(0, 0, 220, 75))
	owner := New(math32.Vec2(240, 80)).(*Renderer)
	reference := New(math32.Vec2(240, 80)).(*Renderer)
	oldCache := UseGlyphCache
	UseGlyphCache = false
	defer func() { UseGlyphCache = oldCache }()
	for _, op := range []draw.Op{draw.Over, draw.Over, draw.Src, draw.Src, draw.Over} {
		owner.ImgSpanner.Op = op
		reference.ImgSpanner.Op = op
		draw.Draw(owner.image, owner.image.Rect, image.NewUniform(color.NRGBA{30, 60, 90, 171}), image.Point{}, draw.Src)
		copy(reference.image.Pix, owner.image.Pix)
		one := batch.At(0)
		owner.Render(render.Render{batch})
		reference.Render(render.Render{&one})
		if !bytes.Equal(owner.image.Pix, reference.image.Pix) {
			t.Fatal("blend-state mutation reused wrong fragment", op)
		}
		a, b := owner.ScenePacket(render.Render{batch}), reference.ScenePacket(render.Render{&one})
		if a == nil || b == nil {
			t.Fatal("blend capture refused")
		}
		ea, _ := a.Encode()
		eb, _ := b.Encode()
		if !bytes.Equal(ea.Ops, eb.Ops) || !bytes.Equal(ea.Data, eb.Data) {
			t.Fatal("capture blend mismatch", op)
		}
	}
	txt.Text.Color = color.RGBA{}
	owner.Render(render.Render{batch})
	owner.Render(render.Render{batch})
	hits := owner.rowFragments.hits
	txt.Text.Color = nil
	clear(owner.image.Pix)
	clear(reference.image.Pix)
	one := batch.At(0)
	owner.Render(render.Render{batch})
	reference.Render(render.Render{&one})
	if !bytes.Equal(owner.image.Pix, reference.image.Pix) || owner.rowFragments.hits != hits {
		t.Fatal("nil base color bypassed original CPU route")
	}
	if owner.ScenePacket(render.Render{batch}) != nil {
		t.Fatal("nil base color bypassed preflight")
	}
}

type rowHookSpanner struct {
	under         scan.Spanner
	colors, spans int
}

func (s *rowHookSpanner) SetColor(c image.Image) { s.colors++; s.under.SetColor(c) }
func (s *rowHookSpanner) GetSpanFunc() scan.SpanFunc {
	fn := s.under.GetSpanFunc()
	return func(y, x0, x1 int, a uint32) { s.spans++; fn(y, x0, x1, a) }
}
func TestVellumRowFragmentsCustomAndPendingScannerFallback(t *testing.T) {
	old := UseGlyphCache
	UseGlyphCache = false
	defer func() { UseGlyphCache = old }()
	for _, mode := range []string{"custom", "pending", "path"} {
		t.Run(mode, func(t *testing.T) {
			txt := vellumSceneText(t)
			txt.Text.SelectReset()
			txt.Text.HighlightReset()
			batch := render.NewTextBatch(&txt.Context)
			batch.Add(txt.Text, math32.Vec2(7.25, 2.5), image.Rect(0, 0, 220, 75))
			owner := New(math32.Vec2(240, 80)).(*Renderer)
			reference := New(math32.Vec2(240, 80)).(*Renderer)
			owner.Render(render.Render{batch})
			owner.Render(render.Render{batch})
			hits := owner.rowFragments.hits
			clear(owner.image.Pix)
			var hook *rowHookSpanner
			switch mode {
			case "custom":
				hook = &rowHookSpanner{under: owner.ImgSpanner}
				owner.Scanner.Spanner = hook
				reference.Scanner.Spanner = &rowHookSpanner{under: reference.ImgSpanner}
			case "pending":
				owner.Scanner.Set(fixed.P(13, 7))
				reference.Scanner.Set(fixed.P(13, 7))
			case "path":
				owner.Path.Start(fixed.P(1, 1))
				reference.Path.Start(fixed.P(1, 1))
			}
			one := batch.At(0)
			owner.Render(render.Render{batch})
			reference.Render(render.Render{&one})
			if !bytes.Equal(owner.image.Pix, reference.image.Pix) || owner.rowFragments.hits != hits {
				t.Fatal("non-owned or pending scanner bypassed original route", mode)
			}
			if hook != nil && (hook.spans == 0 || hook.colors == 0) {
				t.Fatal("original custom span hook was bypassed")
			}
		})
	}
}

func TestVellumRowFragmentsBoundedWorkingSetEviction(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	owner := New(math32.Vec2(240, 80)).(*Renderer)
	for i := 0; i < rowFragmentEntries+16; i++ {
		batch := render.NewTextBatch(&txt.Context)
		batch.Add(txt.Text, math32.Vec2(7+float32(i)/2048, 2.5), image.Rect(0, 0, 220, 75))
		p := owner.ScenePacket(render.Render{batch})
		if p == nil {
			t.Fatal("valid cold row refused", i)
		}
		c := owner.rowFragments
		if c.bytes > rowFragmentBytes || len(c.entries) > rowFragmentEntries || len(c.fonts) > rowFragmentFonts {
			t.Fatal("retention bound exceeded", c.bytes, len(c.entries), len(c.fonts))
		}
	}
	c := owner.rowFragments
	if len(c.entries) == 0 || c.misses <= rowFragmentEntries {
		t.Fatal("eviction fixture did not exercise bounded cache")
	}
	owner.Release()
	if owner.rowFragments != nil {
		t.Fatal("release retains cache")
	}
}

func TestVellumRowFragmentsContentAlternationAndHashCollision(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	batch := render.NewTextBatch(&txt.Context)
	batch.Add(txt.Text, math32.Vec2(7.25, 2.5), image.Rect(0, 0, 220, 75))
	owner := New(math32.Vec2(240, 80)).(*Renderer)
	run := txt.Text.Lines[0].Runs[0].(*shapedgt.Run)
	original := run.Glyphs[0].Advance
	if owner.ScenePacket(render.Render{batch}) == nil {
		t.Fatal("A capture refused")
	}
	run.Glyphs[0].Advance += 11
	if owner.ScenePacket(render.Render{batch}) == nil {
		t.Fatal("B capture refused")
	}
	run.Glyphs[0].Advance = original
	hits := owner.rowFragments.hits
	if owner.ScenePacket(render.Render{batch}) == nil || owner.rowFragments.hits <= hits {
		t.Fatal("A→B→A failed to retain independently validated A")
	}
	// Base color is intentionally absent from the cheap discriminator. Full proof
	// must reject this collision, then produce the uncached original pixels.
	hash := rowContentHash(batch, 0, 1)
	hits = owner.rowFragments.hits
	txt.Text.Color = color.NRGBA{203, 31, 17, 111}
	p := owner.ScenePacket(render.Render{batch})
	if p == nil || hash != rowContentHash(batch, 0, 1) || owner.rowFragments.hits != hits {
		t.Fatal("hash collision bypassed full proof")
	}
	one := batch.At(0)
	oracle := New(math32.Vec2(240, 80)).(*Renderer)
	q := oracle.ScenePacket(render.Render{&one})
	a, b := image.NewRGBA(owner.image.Rect), image.NewRGBA(owner.image.Rect)
	p.Replay(a)
	q.Replay(b)
	if !bytes.Equal(a.Pix, b.Pix) {
		t.Fatal("collision reused stale color")
	}
}

func TestVellumRowFragmentsMathThenCachedBitmapState(t *testing.T) {
	txt := vellumSceneText(t)
	txt.Text.SelectReset()
	txt.Text.HighlightReset()
	mathLines := *txt.Text
	mathLines.Lines = slices.Clone(txt.Text.Lines)
	mathLines.Lines[0].Runs = slices.Clone(txt.Text.Lines[0].Runs)
	mathRun := *mathLines.Lines[0].Runs[0].(*shapedgt.Run)
	path := ppath.New()
	path.MoveTo(2, 2)
	path.LineTo(20, 3)
	path.LineTo(9, 18)
	path.Close()
	mathRun.Math.Path = *path
	mathLines.Lines[0].Runs[0] = &mathRun
	owner := New(math32.Vec2(240, 80)).(*Renderer)
	reference := New(math32.Vec2(240, 80)).(*Renderer)
	primer := render.NewTextBatch(&txt.Context)
	primer.Add(txt.Text, math32.Vec2(7.25, 42.5), image.Rect(0, 40, 220, 80))
	owner.Render(render.Render{primer})
	owner.ScenePacket(render.Render{primer})
	clear(owner.image.Pix)
	batch := render.NewTextBatch(&txt.Context)
	batch.Add(&mathLines, math32.Vec2(7.25, 2.5), image.Rect(0, 0, 220, 39))
	batch.Add(txt.Text, math32.Vec2(7.25, 42.5), image.Rect(0, 40, 220, 80))
	a, b := batch.At(0), batch.At(1)
	owner.Render(render.Render{batch})
	reference.Render(render.Render{&a, &b})
	if !bytes.Equal(owner.image.Pix, reference.image.Pix) || !slices.Equal(owner.Path, reference.Path) || len(reference.Path) == 0 {
		t.Fatal("math→cached bitmap changed original pending path state")
	}
	follow := render.NewPath(*path, styles.NewPaint(), &txt.Context)
	owner.Render(render.Render{follow})
	reference.Render(render.Render{follow})
	if !bytes.Equal(owner.image.Pix, reference.image.Pix) {
		t.Fatal("following ordinary path changed")
	}
	commands := render.Render{batch, follow}
	original := render.Render{&a, &b, follow}
	p, q := owner.ScenePacket(commands), reference.ScenePacket(original)
	if p == nil || q == nil {
		t.Fatal("mixed math scene refused")
	}
	x, y := image.NewRGBA(owner.image.Rect), image.NewRGBA(owner.image.Rect)
	p.Replay(x)
	q.Replay(y)
	if !bytes.Equal(x.Pix, y.Pix) {
		t.Fatal("capture math→bitmap→ordinary path pixels differ")
	}
}
