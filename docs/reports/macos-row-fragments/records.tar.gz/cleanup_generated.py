from pathlib import Path
import json,hashlib,shutil
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum/drivers/cogent/build');T=Path('/private/tmp/vellum-macos-native-results-97aee13/drivers/cogent/build')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def leaves(root):return {n+'/'+p.relative_to(root/n).as_posix():p for n in ['upstream','typesetting'] for p in (root/n).rglob('*') if p.is_file()}
a,b=leaves(C),leaves(T);assert len(a)==6260 and all(n in b and sha(p)==sha(b[n]) for n,p in a.items())
extra={n:p for n,p in b.items() if n not in a};old=json.loads((W.parent/'macos-tile-culling-31afa90/generated-output-cleanup.json').read_text())['preserved_then_removed'];assert set(extra)==set(old) and len(extra)==17
record={}
for n,p in extra.items():
 assert n.startswith('upstream/paint/renderers/rasterx/testdata/') and p.suffix=='.png' and not p.is_symlink()
 target=W/'generated-raster-test-output'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);assert sha(p)==sha(target);record[n]={'sha256':sha(p),'bytes':p.stat().st_size,'same_as_prior_test_output':sha(p)==old[n]};p.unlink()
c=leaves(T);assert set(c)==set(a);d={n:sha(p) for n,p in c.items()};digest=hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert digest=='1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'
(W/'generated-output-cleanup.json').write_text(json.dumps({'result':'ORIGINAL_PREPARED_SOURCES_UNCHANGED','files':len(c),'sha256':digest,'preserved_outputs':record},indent=2)+'\n');print(json.dumps({'prepared_files':len(c),'sha256':digest,'outputs_preserved':len(record)}))
