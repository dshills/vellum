
func TestVellumRowFragmentsBlendAndNilColorMutation(t *testing.T){
 txt:=vellumSceneText(t);txt.Text.SelectReset();txt.Text.HighlightReset();batch:=render.NewTextBatch(&txt.Context);batch.Add(txt.Text,math32.Vec2(7.25,2.5),image.Rect(0,0,220,75));owner:=New(math32.Vec2(240,80)).(*Renderer);reference:=New(math32.Vec2(240,80)).(*Renderer)
 oldCache:=UseGlyphCache;UseGlyphCache=false;defer func(){UseGlyphCache=oldCache}()
 for _,op:=range []draw.Op{draw.Over,draw.Over,draw.Src,draw.Src,draw.Over}{
  owner.ImgSpanner.Op=op;reference.ImgSpanner.Op=op
  draw.Draw(owner.image,owner.image.Rect,image.NewUniform(color.NRGBA{30,60,90,171}),image.Point{},draw.Src);copy(reference.image.Pix,owner.image.Pix)
  one:=batch.At(0);owner.Render(render.Render{batch});reference.Render(render.Render{&one});if !bytes.Equal(owner.image.Pix,reference.image.Pix){t.Fatal("blend-state mutation reused wrong fragment",op)}
  a,b:=owner.ScenePacket(render.Render{batch}),reference.ScenePacket(render.Render{&one});if a==nil||b==nil{t.Fatal("blend capture refused")};ea,_:=a.Encode();eb,_:=b.Encode();if !bytes.Equal(ea.Ops,eb.Ops)||!bytes.Equal(ea.Data,eb.Data){t.Fatal("capture blend mismatch",op)}
 }
 txt.Text.Color=color.RGBA{};owner.Render(render.Render{batch});owner.Render(render.Render{batch});hits:=owner.rowFragments.hits
 txt.Text.Color=nil
 clear(owner.image.Pix);clear(reference.image.Pix);one:=batch.At(0);owner.Render(render.Render{batch});reference.Render(render.Render{&one});if !bytes.Equal(owner.image.Pix,reference.image.Pix)||owner.rowFragments.hits!=hits{t.Fatal("nil base color bypassed original CPU route")};if owner.ScenePacket(render.Render{batch})!=nil{t.Fatal("nil base color bypassed preflight")}
}
