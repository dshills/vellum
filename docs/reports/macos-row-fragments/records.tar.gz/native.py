"""Fixed native feasibility and ordinary adoption cases using the existing runner."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,math,os,signal,subprocess,sys,threading,_thread
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-ready-native-5482f9b');HEAD='b0534e9f767237e3d7577ea9fde7128bd887889e'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('row_grid_runner',T/'scripts/benchmark-grid.py');lease=load('row_live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def clean():need(all(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain') for root in [C,T]),'clean source identity')
def prepared():
 d={n+'/'+p.relative_to(T/'drivers/cogent/build'/n).as_posix():sha(p) for n in ['upstream','typesetting'] for p in (T/'drivers/cogent/build'/n).rglob('*') if p.is_file()}
 return {'files':len(d),'sha256':hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
def prepare():
 need(not (W/'native-plan.json').exists(),'fresh plan');clean()
 for mode in ['full-v5','grid-v4','vet','build','build-diagnostic']:need(json.loads((W/(mode+'-command.json')).read_text())['exit_code']==0,'passing '+mode)
 old=json.loads((W.parent/'macos-ax-semantic-02f8dbe/binary-receipt.json').read_text());need(all(sha(C/'drivers/cogent'/n)==v for n,v in old['compiled_leaves'].items()),'baseline compiled leaves');need(not git(C,'diff','bd672a6',HEAD,'--','drivers/cogent','go.mod','examples/loadedgrid'),'baseline runtime unchanged')
 pins={}
 for p in [Path(__file__),W/'check.py',W/'overlay.json',W/'diagnostic-overlay.json',T/'scripts/benchmark-grid.py',Path(lease.__file__)]:pins[str(p)]=sha(p)
 for name in ['overlay.json','diagnostic-overlay.json']:
  for v in json.loads((W/name).read_text())['Replace'].values():pins[v]=sha(v)
 binaries={label:{'path':str(path),'sha256':sha(path)} for label,path in [('baseline',Path(old['path'])),('candidate',P/'bin/row-fragments'),('diagnostic',P/'bin/row-fragments-diagnostic')]};need(binaries['baseline']['sha256']==old['sha256'],'baseline binary')
 plan={'source_base':HEAD,'prepared':prepared(),'inputs':pins,'binaries':binaries,'rows':10000,'variable':False,'samples':120,'warmup':128,'diagnostics':'SeparateCPU/GPUsource-details runs, counter/per-Ymaps only, observer overhead means no timing acceptance. Body defined conservatively beyond gridMinY+(24header+12row)*actualScale. Requirepositivebodyhits inboth beforecomparison.','ordinary':'FiveCPU andfiveGPU baseline/candidate pairs, alternatingorder, normalenv;20ordinaryruns, neverdiagnosticbinary.','novel':'One additional ordinarybaseline/candidate pair perCPU/GPU mode with -perf-novel; separate cold/novelmiss observation, notfive-run acceptance.','bar':{'median_run_p95_reduction_ns':400000,'minimum_improved_pairs':4,'pairs_per_mode':5,'both_modes':True,'no_correctness_retention_tail_regression':True},'limits':{'owned_fragment_proof_bytes':8<<20,'entries':1024,'strong_immutable_fonts':8},'reassessment_utc':'2026-10-17T23:55:12Z','native_input_scope':'existing programmatic grid benchmark event deque; no placementoperator, physicalpointer, preferences orinputsourcechanges'}
 need(plan['prepared']=={'files':6260,'sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'},'exact prepared tree');(W/'native-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Prepared native plan '+sha(W/'native-plan.json'))
def run(phase):
 stop=W/('stop-'+phase);out=W/(phase+'-result.json');need(not stop.exists() and not out.exists(),'fresh case')
 raw=(W/'native-plan.json').read_bytes();plan=json.loads(raw);admit=json.loads((W/'native-admission.json').read_text());need(admit['execution_ready'] and admit['plan_sha256']==hashlib.sha256(raw).hexdigest(),'reviewed exact plan');need(json.loads((W/'native-gpu-command.json').read_text())['exit_code']==0,'actual native GPU prerequisite')
 if phase=='comparison':need(json.loads((W/'diagnostic-assessment.json').read_text())['comparison_admitted'],'positive body-reuse prerequisite')
 def boundary():
  need(not stop.exists(),'stop requested');clean();need(all(sha(p)==v for p,v in plan['inputs'].items()),'source/controller pins changed');need(all(sha(v['path'])==v['sha256'] for v in plan['binaries'].values()),'binary changed')
 d={'result':'INCOMPLETE','source_base':HEAD,'plan_sha256':hashlib.sha256(raw).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':{},'error':None,'physical_pointer_tested':False};finished=threading.Event()
 def watch():
  while not finished.wait(.2):
   if stop.exists():_thread.interrupt_main();return
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('native case terminated')))
 try:
  boundary();need(prepared()==plan['prepared'],'prepared before');need(all(os.environ.get(k) is None for k in ['GOMAXPROCS','GOMEMLIMIT','GOFLAGS','VELLUM_ROW_FRAGMENT_DIAGNOSTIC']),'normal env before')
  with lease.LiveLease():
   d['displays']=b.metadata_command(['system_profiler','SPDisplaysDataType','-json'],15);threading.Thread(target=watch,daemon=True).start()
   for mode in ['gpu','cpu']:
    gpu=mode=='gpu'
    if phase=='diagnostic':
     boundary();directory=W/'diagnostic'/mode;os.environ['VELLUM_ROW_FRAGMENT_DIAGNOSTIC']='1'
     try:data,outcome=b.run_case(Path(plan['binaries']['diagnostic']['path']),directory,10000,False,120,128,False,180,source_details=True,gpu_scene_rendering=gpu)
     finally:os.environ.pop('VELLUM_ROW_FRAGMENT_DIAGNOSTIC',None)
     ready=False;pending=[];records=[]
     for line in (directory/'native.log').read_bytes().splitlines():
      try:x=json.loads(line)
      except (ValueError,UnicodeDecodeError):continue
      if x.get('event')=='row.fragment.diagnostic' and ready:pending.append(x)
      elif x.get('event')=='grid.perf.ready':ready=True;pending=[]
      elif x.get('event')=='grid.perf.sample':
       need(len(pending)==1 and pending[0]['pipeline']==mode,'one matching observer per source');r=pending[0];a,z=r['before'],r['after'];need(all(z[k]>=a[k] for k in ['Hits','Misses']),'monotonic counters');need(z['Bytes']<=8<<20 and z['Entries']<=1024 and z['Fonts']<=8,'bounded cache')
       geometry=x['geometry'];cut=math.ceil(geometry['bounds']['Min']['Y']+36*geometry['scale']);upper=geometry['bounds']['Max']['Y'];hit=sum(n-a.get('HitRows',{}).get(y,0) for y,n in z.get('HitRows',{}).items() if cut<=int(y)<upper);miss=sum(n-a.get('MissRows',{}).get(y,0) for y,n in z.get('MissRows',{}).items() if cut<=int(y)<upper);need(hit>=0 and miss>=0,'nonnegative body deltas')
       if gpu:
        hosts=[v['SceneHost'] for v in x['native_sample']['SourceDetails']['Records'] if v.get('SceneHost',{}).get('CaptureAttempted')];need(len(hosts)==1 and hosts[0]['DrawAccepted'] and not hosts[0]['Fallback'] and not hosts[0]['Reused'],'actualGPU source')
       records.append({'index':x['index'],'tag':x['tag'],'generation':x['generation'],'geometry':geometry,'body_cut_y':cut,'body_hit_rows':hit,'body_miss_rows':miss,'observation':r});pending=[]
     need(len(records)==120,'120correlated observations');(directory/'row-reuse.json').write_text(json.dumps(records,indent=2)+'\n');d['cases'][mode]={'exit_code':outcome['exit_code'],'samples':len(records),'body_hits':sum(x['body_hit_rows'] for x in records),'body_misses':sum(x['body_miss_rows'] for x in records),'frames_with_body_hits':sum(x['body_hit_rows']>0 for x in records),'max_owned_cache_bytes':max(x['observation']['after']['Bytes'] for x in records),'max_entries':max(x['observation']['after']['Entries'] for x in records),'scope':'Diagnosticonly; no ordinarytimingacceptance'};print(json.dumps({'mode':mode,**d['cases'][mode]}),flush=True)
    else:
     runs={'baseline':[],'candidate':[]};case={k:{'runs':[]} for k in runs}
     for pair in range(5):
      for label in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
       boundary();directory=W/'ordinary'/mode/f'{pair+1}-{label}';data,outcome=b.run_case(Path(plan['binaries'][label]['path']),directory,10000,False,120,128,False,180,gpu_scene_rendering=gpu);need(b'row.fragment.diagnostic' not in (directory/'native.log').read_bytes(),'diagnostic leaked into ordinaryrun');runs[label].append(data);stats=b.distribution([x['metrics']['ui_work_ns'] for x in data]);alloc=b.distribution([x['go_process_alloc_bytes'] for x in data]);case[label]['runs'].append({'directory':str(directory),'exit_code':outcome['exit_code'],'log_sha256':outcome['log_sha256'],'ui_work_ns':stats,'alloc_bytes':alloc});print(json.dumps({'mode':mode,'pair':pair+1,'build':label,'p95_ms':stats['p95']/1e6}),flush=True)
      b.compare_geometry(runs['baseline'][-1],runs['candidate'][-1])
     d['cases'][mode]=case
     novel={}
     for label in ['baseline','candidate']:
      boundary();directory=W/'novel'/mode/label;data,outcome=b.run_case(Path(plan['binaries'][label]['path']),directory,10000,False,120,128,True,180,gpu_scene_rendering=gpu);novel[label]={'exit_code':outcome['exit_code'],'directory':str(directory),'ui_work_ns':b.distribution([x['metrics']['ui_work_ns'] for x in data]),'alloc_bytes':b.distribution([x['go_process_alloc_bytes'] for x in data])}
     d.setdefault('novel',{})[mode]=novel
   boundary();d['prepared_after']=prepared();need(d['prepared_after']==plan['prepared'],'prepared after');d['result']='MEASURED'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:os.environ.pop('VELLUM_ROW_FRAGMENT_DIAGNOSTIC',None);finished.set();stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'error':d['error']}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:] in [['prepare'],['diagnostic'],['comparison']],'fixed phase');prepare() if sys.argv[1]=='prepare' else run(sys.argv[1])
