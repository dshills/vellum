from pathlib import Path
import json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');U=T/'drivers/cogent/build/upstream';R=W/'source/paint/renderers/rasterx'
s=(R/'row_fragments_vellum.go').read_text();s=s.replace('hits, misses uint64','hits, misses uint64\n hitRows,missRows map[int]uint64')
# Gofmt alignment varies: insert after the type header instead.
if 'hitRows,missRows' not in s:s=s.replace('type rowFragmentCache struct {','type rowFragmentCache struct {\n hitRows,missRows map[int]uint64')
s=s.replace('rs.rowFragments.hits++','rs.rowFragments.hits++;if rs.rowFragments.hitRows==nil {rs.rowFragments.hitRows=make(map[int]uint64)};rs.rowFragments.hitRows[key.first.Min.Y]++')
s=s.replace('rs.rowFragments.misses++','rs.rowFragments.misses++;if rs.rowFragments.missRows==nil {rs.rowFragments.missRows=make(map[int]uint64)};rs.rowFragments.missRows[key.first.Min.Y]++')
s+='''
// This scalar/coordinate observer exists only in the separate diagnostic overlay.
type RowFragmentDiagnostic struct {Hits,Misses uint64;Bytes,Entries,Fonts int;HitRows,MissRows map[int]uint64}
func(rs *Renderer)VellumRowFragmentSnapshot()RowFragmentDiagnostic {
 c:=rs.rowFragments;if c==nil{return RowFragmentDiagnostic{}}
 out:=RowFragmentDiagnostic{Hits:c.hits,Misses:c.misses,Bytes:c.bytes,Entries:len(c.entries),Fonts:len(c.fonts),HitRows:make(map[int]uint64),MissRows:make(map[int]uint64)}
 for y,n:=range c.hitRows {out.HitRows[y]=n};for y,n:=range c.missRows {out.MissRows[y]=n};return out
}
''';(W/'diagnostic-row.go').write_text(s)
s=(R/'renderer.go').read_text().replace('import (','import (\n "os"\n "fmt"\n "encoding/json"',1);a='''	rs.scrollStats = ScrollStats{}
	rs.renderItems''';b=''' beforeRows:=rs.VellumRowFragmentSnapshot()
\trs.scrollStats = ScrollStats{}
\trs.renderItems''';assert s.count(a)==1;s=s.replace(a,b);a='\trs.scrollStats.DescriptorBytes = rs.scrollPlanBytes\n';b=a+''' if os.Getenv("VELLUM_ROW_FRAGMENT_DIAGNOSTIC")=="1" {
  data,_:=json.Marshal(map[string]any{"event":"row.fragment.diagnostic","pipeline":"cpu","before":beforeRows,"after":rs.VellumRowFragmentSnapshot()})
  fmt.Fprintln(os.Stdout,string(data))
 }
''';assert s.count(a)==1;s=s.replace(a,b);(W/'diagnostic-rasterx-renderer.go').write_text(s)
s=(U/'paint/renderers/gpuscene/renderer.go').read_text().replace('import (','import (\n "os"\n "encoding/json"',1);a='\t\tpacket = r.cpu.ScenePacket(commands)';b='''        beforeRows:=r.cpu.VellumRowFragmentSnapshot()
'''+a+'''
        if host!=nil && packet!=nil {
         data,_:=json.Marshal(map[string]any{"event":"row.fragment.diagnostic","pipeline":"gpu","before":beforeRows,"after":r.cpu.VellumRowFragmentSnapshot()})
         fmt.Fprintln(os.Stdout,string(data))
        }''';assert s.count(a)==1;s=s.replace(a,b);(W/'diagnostic-gpuscene-renderer.go').write_text(s)
o=json.loads((W/'overlay.json').read_text());o['Replace'].update({str(U/'paint/renderers/rasterx/row_fragments_vellum.go'):str(W/'diagnostic-row.go'),str(U/'paint/renderers/rasterx/renderer.go'):str(W/'diagnostic-rasterx-renderer.go'),str(U/'paint/renderers/gpuscene/renderer.go'):str(W/'diagnostic-gpuscene-renderer.go')});(W/'diagnostic-overlay.json').write_text(json.dumps(o,indent=2)+'\n')
print('Created separate diagnostic-only geometry/counter observer; ordinary overlay unchanged')
