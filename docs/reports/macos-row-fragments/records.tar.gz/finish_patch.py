from pathlib import Path
W=Path(__file__).resolve().parent;R=W/'source/paint/renderers/rasterx'
p=R/'row_fragments_vellum.go';s=p.read_text().replace('advance:run.Advance()','advance:run.Output.Advance');s=s.replace('"slices"','"slices"\n "strings"');s=s.replace('rp.glyphs=slices.Clone(run.Glyphs);','rp.glyphs=slices.Clone(run.Glyphs);rp.font.Family=strings.Clone(rp.font.Family);');p.write_text(s)
p=R/'scene_packet.go';s=p.read_text();start=s.index('func (rs *Renderer) ScenePacket(');end=s.index('\nfunc sceneContextFinite',start);part=s[start:end];part=part.replace('func (rs *Renderer) ScenePacket(commands render.Render) *sceneplan.Packet {','''type rowSceneResult struct {packet *sceneplan.Packet;fragment *sceneplan.Fragment;work int;costs []font.GlyphOutlineCost}
func (rs *Renderer) ScenePacket(commands render.Render) *sceneplan.Packet {return rs.compileScene(commands,false).packet}
func (rs *Renderer) compileScene(commands render.Render,freeze bool) rowSceneResult {''');part=part.replace('return nil','return rowSceneResult{}');part=part.replace('\tfor _, item := range commands {\n\t\tswitch x := item.(type) {\n\t\tcase *pimage.Params:\n\t\t\tb.Draw', '\tbefore:=work.remaining;var costs []font.GlyphOutlineCost\n if freeze {capture.fragmentCosts=&costs}\n\tfor _, item := range commands {\n\t\tswitch x := item.(type) {\n\t\tcase *pimage.Params:\n\t\t\tb.Draw');part=part.replace('return b.Seal(capture.Scanner.UseNonZeroWinding)','''var f *sceneplan.Fragment
 if freeze {f=b.EndFragment(0)}
 return rowSceneResult{packet:b.Seal(capture.Scanner.UseNonZeroWinding),fragment:f,work:before-work.remaining,costs:costs}''');s=s[:start]+part+s[end:];p.write_text(s)
p=W/'source/paint/renderers/sceneplan/fragment_vellum.go';s=p.read_text();s=s.replace('f.retained=f.charge+int(unsafe.Sizeof(Fragment{}))+len(f.masks)*96','f.retained=f.charge+(cap(f.packet.ops)-len(f.packet.ops))*int(unsafe.Sizeof(operation{}))+int(unsafe.Sizeof(Fragment{}))+len(f.masks)*96');a=''' b.flush()
 if f==nil || b.failed || f.packet.bounds!=b.packet.bounds || len(f.packet.ops)>MaxOps-b.count || f.charge+MaxDimension*int(unsafe.Sizeof([]span{}))>MaxBytes-b.packet.bytes {return false}
 for _,o:=range f.packet.ops {''';b=''' b.flush()
 if !b.CanAppendFragment(f) {return false}
 for _,o:=range f.packet.ops {''';assert s.count(a)==1;s=s.replace(a,b);s+='''
func(b *Builder) CanAppendFragment(f *Fragment)bool {
 b.flush()
 return f!=nil && !b.failed && f.packet.bounds==b.packet.bounds && len(f.packet.ops)<=MaxOps-b.count && f.charge+MaxDimension*int(unsafe.Sizeof([]span{}))<=MaxBytes-b.packet.bytes
}
''';p.write_text(s)
print('Completed compileScene helper and transactional append preflight')
