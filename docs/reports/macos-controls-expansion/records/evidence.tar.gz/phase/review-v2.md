# Controls expansion final source review v2

Verdict: APPROVED_SOURCE; no unresolved findings on the final14 source leaves. The current files and candidate-final copies match source-final.json.

Switch and ToggleButton inherit bounded owner delivery, latest callbacks, disabled/retired refusal and boolean accessibility actions. The correction captures native Checked mismatch before resetting accepted state and requests Update/Style when needed, restoring checked-dependent backgrounds without emitting Change. The unchanged final regression genuinely compiled and failed at the stale-background assertion on the preserved pre-fix source. Review-v1 and the two earlier fixture failures remain historical.

Progress is finite0..1 and passive; separators are decorative and omitted from AX. Orientation, focus exclusion, native final-style overrides/restoration and Cocoa role/boolean conversion are coherent. The public catalog and specs state the limits accurately.

The rejected-style fixture uses the actual Core Switch listener/Styler and owner queue with an explicit post-event restyle. The separate Manual fixture routes Enter and measured pointer input and checks completed progress pixels. These scopes are distinct. This reviewer ran no tests/UI/native/provider actions; final root qualifications remain separate, and physical Mac input/VoiceOver, native memory, sustained performance and complete Mac acceptance stay open. Exact source, reference and negative-receipt hashes are recorded in review-v2.json.
