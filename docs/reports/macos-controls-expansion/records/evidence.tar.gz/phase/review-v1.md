# Controls expansion source review v1

Verdict: NEEDS_FIX on the inspected final13 source map, preserved in candidate-final/.

The new ToggleButton reuses controlled boolean synchronization, but a rejected actual native toggle can retain checked background/color after its Checked flag is restored. Core restyles on the click; SetChecked changes flags only; syncControl does not request Update when the descriptor remains unchanged. The direct retained test checks flags and identity, and the actual-router test in this snapshot accepts changes, so neither establishes rejected-value style restoration. Detect native/accepted Checked mismatch before SetChecked and exercise that restoration.

Validation, passive progress/separator semantics, finite fractions, orientation, disabled/retired delivery, Cocoa role/boolean conversion and the native-final-style override contract otherwise appear coherent. The thirteen inspected snapshots and nine originals match their exact source manifest. This is a source review, with no independent tests/native/UI/provider execution; physical Mac and memory/performance acceptance remain open. Parent's subsequent regression/catalog edits are not certified here. Exact hashes and source references are in review-v1.json.
