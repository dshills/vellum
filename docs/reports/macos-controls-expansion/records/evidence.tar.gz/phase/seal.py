"""Seal scoped UI vocabulary implementation and offscreen evidence."""
from pathlib import Path
import hashlib,json,tarfile
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-controls-expansion');report=r/'docs/reports/macos-controls-expansion';records=report/'records'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((p/'source-final.json').read_text());assert len(source['sources'])==14 and all(h(r/n)==v for n,v in source['sources'].items())
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():h(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
assert len(prepared)==6198 and prepared==json.loads(Path('/private/tmp/vellum-macos-pipeline-ownership/qualification.json').read_text())['prepared']
required=['controls-race-v2','adapter-race-v2','portable-race-v3','vet-v2','gallery-build-v2','controls-preview-reviewed'];receipts={}
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if 'argv' not in d:continue
 name=f.stem
 assert d['source_commit']==source['base_commit'] and d['error'] is None and d['source_delta_stable'] and d['prepared_before']==prepared==d['prepared_after'],name
 for channel in ['stdout','stderr']:assert h(p/(name+'.'+channel))==d[channel+'_sha256'],name
 if name in required:assert d['exit_code']==0 and d['source_delta_before']==source['sources']==d['source_delta_after'],name
 receipts[name]={'sha256':h(f),'exit_code':d['exit_code'],'final_source_qualified':name in required}
assert len(receipts)==19,len(receipts)
assert sorted(n for n,v in receipts.items()if v['exit_code']!=0)==['portable-race-v1','rejected-toggle-original','rejected-toggle-original-v2','rejected-toggle-original-v3']
assert 'rejected toggle retained selected background' in (p/'rejected-toggle-original-v3.stdout').read_text()
review=json.loads((p/'review-v2.json').read_text());assert review['status']=='APPROVED_SOURCE' and {Path(n).relative_to(r).as_posix():v for n,v in review['reviewed_source_sha256'].items()}==source['sources'] and not review['findings']
prism=json.loads((p/'prism-v1/prism.json').read_text());process=json.loads((p/'prism-v1/process.json').read_text());assert process['exit_code']==0 and process['source_index_stable'] and process['before']==source['sources']
assert prism['coverage']['complete'] and prism['coverage']['files']==14 and not prism['findings'] and prism['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
q={'result':'PASS_UI_ELEMENTS_EXPANSION','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'receipts':receipts,'source_review_sha256':h(p/'review-v2.json'),'preview_sha256':h(p/'controls-reviewed.png'),'prism_sha256':h(p/'prism-v1/prism.json'),'prism_coverage':prism['coverage'],'limits':['Four public controls and their tested boundaries; no indeterminate progress/radio or grouped single-choice contract','Direct Core rejection fixture routes Click and explicitly completes post-event Style before owner drain; separate Manual fixture routes accepted Enter/pointer and completed software frame','Cocoa role and NSNumber fixtures use retained objects without an OS window or native attachment','Gallery compiled only; no desktop UI/input/settings or general clipboard writes','Offscreen/native-object results do not establish physical Mac input/VoiceOver, native heap or performance/endurance qualification','All6198 prepared hashes are endpoint identities, not a full SDK/compiler/native binary component closure']}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');records.mkdir(parents=True,exist_ok=True);t=prism['coverage']['tokens'][0]
(report/'README.md').write_text(f'''# Mac UI element expansion

The public framework now includes controlled `ui.Switch` and `ui.ToggleButton`,
read-only `ui.ProgressBar`, and decorative `ui.Separator`. Switches and toggles
use accepted Checked values and typed owner Change requests. Progress uses a
finite 0..1 Number fraction. Progress/separators accept horizontal/default or
vertical Orientation, reject input callbacks, and stay outside keyboard focus.
Separators are omitted from the accessible hierarchy; progress publishes read-only
fraction/bounds and the Cocoa progress role. Both boolean additions publish
checkable roles and boolean press/set actions.

Retained synchronization preserves identity, latest callbacks, disabled ancestry
and queued retirement refusal. Explicit size/grow styles run after native final
defaults and restore those defaults when removed. A native boolean mismatch
requests restyling before resetting Checked, so an application rejection cannot
leave a toggle's selected background visible. The independent gallery demonstrates
all four additions; [the public catalog](../../controls.md) lists available kinds.
The [controls spec](../../../specs/controls.md) describes their contracts and
prioritized future vocabulary. Grouped radio/segmented choices and indeterminate
progress are separate work.

## Verification

Final portable and complete offscreen adapter race suites, adapter vet and desktop
gallery compilation pass. Focused control/gallery tests pass three race repetitions.
They exercise payloads, retained callbacks/identity, rejected state restoration,
disabled/retired queued changes, finite progress bounds, passive action refusal,
orientation, explicit style override/removal and accessible values/actions.
Native Cocoa object fixtures verify three role mappings and NSNumber boolean
set conversion without a window, native attachment or system input.

The Manual software fixture routes Enter to a focused switch and a measured
pointer click to a toggle. It observes accepted state, completed raster changes,
progress geometry/value and changed progress pixels. A final-source
[software frame](records/controls.png) is stored. This fixture uses explicit fonts,
colors, workers and clock; it does not measure physical presentation or latency.
The decorative separator's native type/orientation is checked separately.

Internal review identified stale checked-background styling after an application
rejects a toggle request. The corrected direct Core fixture routes a real Switch
Click and explicitly completes the queued pre-owner post-event Styler pass;
it reproduces that visible style assertion on the preceding candidate. This is
separate from the Manual accepted input fixture and from physical OS input.
The same final test passes after the native-mismatch redraw fix.

Nineteen command receipts preserve fifteen passes and four raw exit-1 attempts:
the initial portable suite's temporary Unix sockets were sandbox-denied and pass
with authorized local socket access; the first rejection fixture violated Manual's
required explicit colors; its replacement dereferenced the intentionally nil
unchecked background and panicked in Go; the corrected pre-fix fixture then failed
the genuine stale-background assertion. All sources/logs are retained with their
scope, and none of these raw failures is a passing acceptance result. Final six
required checks bind the exact fourteen source leaves and unchanged 6,198 prepared
dependency identities. The earlier thirteen-source review snapshot is preserved
by hash with an explicit original-path mapping after final snapshots were refreshed.

## Review and evidence

Internal source review approved the final fourteen files after the styling fix.
Prism ran once using Anthropic Claude Sonnet 5.5 with complete fourteen-file
coverage: {prism['coverage']['chunks']} chunks, {t['input']} input/{t['output']}
output tokens, raw exit 0 and no findings. A separate internal evidence review
binds this report, source variants, raw receipts, producers and archive before
commit. The [checkpoint](records/checkpoint.json) binds the reviews and
[archive](records/evidence.tar.gz) with its [member index](records/evidence-index.json).
Native binaries/caches and complete compiler/SDK closure are excluded.

No desktop windows were opened, OS input sent, settings changed or general
clipboard written. Human VoiceOver and physical input acceptance, native/GPU heap,
sustained performance/endurance and full Mac qualification remain open. Mac UI
vocabulary expansion continues alongside those foundation checks.
''')
(records/'controls.png').write_bytes((p/'controls-reviewed.png').read_bytes());(records/'source-review.json').write_bytes((p/'review-v2.json').read_bytes())
inputs={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in ['.go','.json','.md','.py','.stdout','.stderr','.txt','.log','.png']:continue
 if f.name.startswith('evidence-review') or f.name in ['endpoints.json','checkpoint.json']:continue
 inputs['phase/'+f.relative_to(p).as_posix()]=f
for n in source['sources']:inputs['source/'+n]=r/n
inputs['report/README.md']=report/'README.md'
index={n:{'sha256':h(f),'bytes':f.stat().st_size}for n,f in inputs.items()};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as archive:
 for n,f in inputs.items():archive.add(f,arcname=n,recursive=False)
e={'source_manifest_sha256':h(p/'source-final.json'),'qualification_sha256':h(p/'qualification.json'),'report_sha256':h(report/'README.md'),'archive_sha256':h(records/'evidence.tar.gz'),'index_sha256':h(records/'evidence-index.json'),'source_review_sha256':h(p/'review-v2.json'),'prism_sha256':h(p/'prism-v1/prism.json'),'preview_sha256':h(records/'controls.png'),'archive_members':len(index),'receipts':len(receipts),'prepared_files':len(prepared)}
(p/'endpoints.json').write_text(json.dumps(e,indent=2)+'\n');print(json.dumps(e,indent=2))
