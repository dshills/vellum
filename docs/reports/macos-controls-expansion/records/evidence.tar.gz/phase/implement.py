from pathlib import Path
import json,hashlib
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-controls-expansion')
names=['ui/node.go','ui/controls.go','drivers/cogent/controls.go','drivers/cogent/accessibility.go','drivers/cogent/accessibility_darwin.m','drivers/cogent/cmd/gallery/main.go','drivers/cogent/cmd/gallery/main_test.go','specs/controls.md','specs/macos-completion.md']
for n in names:
 f=p/'original'/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((r/n).read_bytes())
 f=p/'candidate'/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((r/n).read_bytes())
def edit(n,fn):
 f=p/'candidate'/n;f.write_text(fn(f.read_text()))
edit('ui/controls.go',lambda s:s.replace('Checkbox      Kind = "checkbox"','''Checkbox      Kind = "checkbox"
	Switch        Kind = "switch"
	ToggleButton  Kind = "toggle-button"
	ProgressBar   Kind = "progress-bar"
	Separator     Kind = "separator"''').replace('type Numeric struct{ Min, Max, Step float32 }','''type Numeric struct{ Min, Max, Step float32 }

// Orientation sets a progress bar or separator's direction. The zero value
// selects horizontal; these display controls never join keyboard focus order.
type Orientation string
const (
	Horizontal Orientation = "horizontal"
	Vertical Orientation = "vertical"
)''').replace('Checkbox, Number for Slider/NumberField','Checkbox/Switch/ToggleButton, Number for Slider/NumberField').replace('case Button, Checkbox, Selector','case Button, Checkbox, Switch, ToggleButton, Selector').replace('func ValidateControl(n Node) error {','''func ValidateControl(n Node) error {
	if n.Orientation != "" && n.Kind != ProgressBar && n.Kind != Separator {
		return fmt.Errorf("ui: Orientation belongs only on progress bars and separators")
	}
	if n.Orientation != "" && n.Orientation != Horizontal && n.Orientation != Vertical {
		return fmt.Errorf("ui: invalid display orientation %q", n.Orientation)
	}
	if n.Kind == ProgressBar {
		if !finite(n.Number) || n.Number < 0 || n.Number > 1 {
			return fmt.Errorf("ui: progress requires a finite fraction within 0..1")
		}
	}
	if (n.Kind == ProgressBar || n.Kind == Separator) && (n.Change != nil || n.Activate != nil) {
		return fmt.Errorf("ui: display-only controls cannot have input callbacks")
	}'''))
edit('ui/node.go',lambda s:s.replace('Numeric             Numeric','''Numeric             Numeric
	// Orientation applies to ProgressBar and Separator; empty means horizontal.
	Orientation         Orientation''').replace('Extension, Checkbox, Selector','Extension, Checkbox, Switch, ToggleButton, ProgressBar, Separator, Selector'))
edit('drivers/cogent/controls.go',lambda s:s.replace('''case ui.Selector:
		widget = core.NewChooser(parent)''','''case ui.Switch:
		widget = core.NewSwitch(parent).SetType(core.SwitchSwitch)
	case ui.ToggleButton:
		widget = core.NewSwitch(parent).SetType(core.SwitchSegmentedButton)
	case ui.ProgressBar:
		widget = core.NewMeter(parent)
	case ui.Separator:
		widget = core.NewSeparator(parent)
	case ui.Selector:
		widget = core.NewChooser(parent)''',1).replace('r.node.Kind == ui.Checkbox || r.node.Kind == ui.Selector','r.node.Kind == ui.Checkbox || r.node.Kind == ui.Switch || r.node.Kind == ui.ToggleButton || r.node.Kind == ui.Selector',1).replace('''	r.widget = widget
	if r.node.Kind''','''	r.widget = widget
	if r.node.Kind == ui.ProgressBar || r.node.Kind == ui.Separator {
		widget.AsWidget().Styler(func(s *styles.Style) {
			s.Direction = styles.Row
			if r.node.Orientation == ui.Vertical { s.Direction = styles.Column }
		})
	}
	if r.node.Kind''',1).replace('''	case *core.Spinner:
		w.Precision''','''	case *core.Meter:
		w.Min, w.Max, w.Value = 0, 1, r.node.Number
	case *core.Spinner:
		w.Precision''',1).replace('if restoring || previous.SoftWrap','if restoring || previous.Orientation != r.node.Orientation || previous.SoftWrap',1))
edit('drivers/cogent/accessibility.go',lambda s:s.replace('''		name := n.Accessibility.Name''','''		if n.Kind == ui.Separator { return } // decorative, no accessible target
		name := n.Accessibility.Name''',1).replace('case ui.Checkbox:', 'case ui.Checkbox, ui.Switch, ui.ToggleButton:').replace('''		case ui.Slider, ui.NumberField:
			x.Value''','''		case ui.ProgressBar:
			x.Value = n.Number
			minimum, maximum := float32(0), float32(1)
			x.Min, x.Max = &minimum, &maximum
		case ui.Slider, ui.NumberField:
			x.Value''',1).replace('if n.Kind == ui.Checkbox && n.Change != nil {','if (n.Kind == ui.Checkbox || n.Kind == ui.Switch || n.Kind == ui.ToggleButton) && n.Change != nil {'))
edit('drivers/cogent/accessibility_darwin.m',lambda s:s.replace('static NSString *vellumAXRole(NSString *role){','''static BOOL vellumAXCheckable(NSString *role){return [role isEqual:@"checkbox"]||[role isEqual:@"switch"]||[role isEqual:@"toggle-button"];}
static NSString *vellumAXRole(NSString *role){''').replace('if([role isEqual:@"checkbox"])return NSAccessibilityCheckBoxRole;','''if(vellumAXCheckable(role))return NSAccessibilityCheckBoxRole;
 if([role isEqual:@"progress-bar"])return NSAccessibilityProgressIndicatorRole;''').replace('if([self.node[@"role"] isEqual:@"checkbox"]&&[value isKindOfClass:NSNumber.class])','if(vellumAXCheckable(self.node[@"role"])&&[value isKindOfClass:NSNumber.class])'))
edit('drivers/cogent/cmd/gallery/main.go',lambda s:s.replace('enabled              bool','enabled              bool\n\tsnapping, pinned bool').replace('''		{ID: "show-dialog", Kind: ui.Button''','''		{ID: "more-controls", Kind: ui.Row, Children: []ui.Node{
			{ID: "snapping", Kind: ui.Switch, Text: "Snapping", Checked: g.snapping, Change: func(e ui.ChangeEvent) { g.snapping = e.Checked }},
			{ID: "pinned", Kind: ui.ToggleButton, Text: "Pin panel", Checked: g.pinned, Change: func(e ui.ChangeEvent) { g.pinned = e.Checked }},
		}},
		{ID: "controls-separator", Kind: ui.Separator},
		{ID: "progress", Kind: ui.ProgressBar, Number: g.number / 100, Accessibility: ui.Accessibility{Name: "Operation progress"}},
		{ID: "show-dialog", Kind: ui.Button''',1))
edit('drivers/cogent/cmd/gallery/main_test.go',lambda s:s+'''
func TestGalleryExpandedControls(t *testing.T) {
	g := newGallery()
	node(g.view(), "snapping").Change(ui.ChangeEvent{Checked:true})
	node(g.view(), "pinned").Change(ui.ChangeEvent{Checked:true})
	node(g.view(), "slider").Change(ui.ChangeEvent{Number:75})
	if !node(g.view(), "snapping").Checked || !node(g.view(), "pinned").Checked || node(g.view(), "progress").Number != 0.75 { t.Fatal("expanded gallery controls do not reflect accepted state") }
	if err := ui.Validate(g.view()); err != nil { t.Fatal(err) }
}
''')
edit('specs/controls.md',lambda s:s.replace('The public `ui.Node` vocabulary now includes checkbox, selector, slider, numeric','The public `ui.Node` vocabulary now includes checkbox, switch, toggle button,\nprogress bar, separator, selector, slider, numeric')+'''
## Expanded desktop elements

`Switch` and `ToggleButton` are controlled boolean leaves. `Checked` is the
accepted value and `Change` receives the requested Checked value with stable ID
and kind. Switch displays an on/off switch; ToggleButton displays a checkable
button. They share bounded owner delivery, latest callbacks, ancestor-disabled
refusal, accepted-value restoration, retained identity and focus traversal with
Checkbox. Programmatic synchronization emits no Change.

`ProgressBar` displays a finite accepted `Number` fraction in 0..1 without a
keyboard step or input callbacks. `Separator` is a decorative line. Both accept
`Orientation` Horizontal/Vertical; empty defaults to horizontal. Other kinds
refuse Orientation. They are leaves and do not join managed focus order.
Progress exposes its fraction and 0/1 bounds with the Mac progress-indicator role;
Separator is omitted from the accessible hierarchy. Switch and ToggleButton
publish checkable Mac roles and boolean press/set actions. Human VoiceOver and
physical keyboard/pointer acceptance remain separate from offscreen/native-object
fixtures. No indeterminate animation, radio grouping or segmented single-choice
contract is implied by these elements.

The gallery demonstrates all four additions using ordinary descriptors and
accepted application state. Next vocabulary expansion should prioritize radio
and segmented choices, reusable toolbars/status bars, form groups and adjustable
splitters, each with keyboard, disabled, lifetime and accessibility contracts.
''')
edit('specs/macos-completion.md',lambda s:s+'''
## UI element expansion

The public control vocabulary adds controlled switches and toggle buttons plus
passive progress bars and oriented decorative separators. The native adapter,
semantic actions and gallery follow the [controls contract](controls.md).
Offscreen lifecycle/input and Mac native-object checks do not substitute for
human VoiceOver, physical keyboard/pointer interaction or the remaining native
memory and sustained-performance gates. Further UI vocabulary is part of the
framework completion work, alongside the existing ownership/qualification effort.
''')
print('Prepared candidates for four public UI element additions')
