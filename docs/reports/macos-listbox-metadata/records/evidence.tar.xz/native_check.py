"""Bounded external AX check; no OS pointer/key delivery or preference changes."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time
P=Path(__file__).resolve().parent
R=Path('/private/tmp/vellum-native-audit')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child, terminate_owned_group
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
name,mode=sys.argv[1:]
assert mode in ['baseline','final']
inputs=P/('native-'+mode+'-inputs.json')
binding=json.loads(inputs.read_text());root=Path(binding['root']);binary=Path(binding['binary'])
authorization=P/'live-authorization.json';auth=json.loads(authorization.read_text())
def stop():return (P/'stop-live').exists() or Path(auth['stop_marker']).exists()
def stable():return all(sha(root/n)==h for n,h in binding['sources'].items())
assert stable() and not stop() and sha(binary)==binding['binary_sha256']
source=P/'ListBoxLive.swift';inspector=P/(name+'-inspector')
record={'mode':mode,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':sha(__file__),'inputs_sha256':sha(inputs),'authorization_sha256':sha(authorization),'binding':binding,'swift_source_sha256':sha(source),'compiler_exit_code':None,'native_exit_code':None,'inspector_exit_code':None,'native_process_terminal':False,'inspector_process_terminal':False,'stop_reason':None}
app=probe=None;start=time.monotonic()
try:
 with (P/(name+'-compile.stdout')).open('xb')as so,(P/(name+'-compile.stderr')).open('xb')as se:
  record['compiler_argv']=['/usr/bin/swiftc','-module-cache-path',str(P/'swift-cache'),str(source),'-o',str(inspector)]
  record['compiler_exit_code']=run_child(record['compiler_argv'],env=child_environment(),stdout=so,stderr=se,timeout=60).returncode
 assert record['compiler_exit_code']==0 and not stop()
 record['inspector_sha256']=sha(inspector)
 with(P/(name+'-app.stdout')).open('xb')as ao,(P/(name+'-app.stderr')).open('xb')as ae,(P/(name+'-inspector.stdout')).open('xb')as io,(P/(name+'-inspector.stderr')).open('xb')as ie:
  assert stable()and sha(inputs)==record['inputs_sha256']and sha(binary)==binding['binary_sha256']and sha(source)==record['swift_source_sha256']and sha(inspector)==record['inspector_sha256']and not stop()
  record['native_argv']=[str(binary),'-exit-after=3m']
  app=subprocess.Popen(record['native_argv'],cwd=root,env=child_environment(runtime=True),stdout=ao,stderr=ae,start_new_session=True)
  record['native_pid']=app.pid;record['inspector_argv']=[str(inspector),str(app.pid)]
  probe=subprocess.Popen(record['inspector_argv'],cwd=root,env=child_environment(runtime=True),stdout=io,stderr=ie,start_new_session=True)
  record['inspector_pid']=probe.pid
  (P/(name+'-owned-processes.json')).write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({'app_pid':app.pid,'inspector_pid':probe.pid}),flush=True)
  deadline=time.monotonic()+45
  while probe.poll()is None:
   if stop()or time.monotonic()>deadline:
    record['stop_reason']='stop-marker'if stop()else'deadline';terminate_owned_group(probe);break
   time.sleep(.1)
  record['inspector_exit_code']=probe.wait(timeout=5)
  try:app.wait(timeout=5)
  except subprocess.TimeoutExpired:record['app_close_fallback']='owned-process-group';terminate_owned_group(app)
  record['native_exit_code']=app.wait(timeout=5)
finally:
 for process in [probe,app]:
  if process is not None and process.poll()is None:terminate_owned_group(process)
 record['native_process_terminal']=app is not None and app.poll()is not None
 record['inspector_process_terminal']=probe is not None and probe.poll()is not None
 record['sources_stable']=stable();record['binary_stable']=sha(binary)==binding['binary_sha256'];record['swift_stable']=sha(source)==record['swift_source_sha256'];record['elapsed_seconds']=time.monotonic()-start
 record['logs']={f.name:sha(f)for suffix in ['stdout','stderr']for f in P.glob(name+'-*.'+suffix)}
 record['stop_marker_observed_at_exit']=stop()
 record['result']='PASS_SCOPED_NATIVE_METADATA'if record['native_exit_code']==0 and record['inspector_exit_code']==0 and record['sources_stable']and record['binary_stable']and record['swift_stable']and record['stop_reason']is None and not record['stop_marker_observed_at_exit']else'FAILED_NATIVE_METADATA_ATTEMPT'
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k]for k in ['result','native_exit_code','inspector_exit_code','elapsed_seconds','stop_reason']}),flush=True)
sys.exit(0 if record['result']=='PASS_SCOPED_NATIVE_METADATA'else 1)
