from pathlib import Path
import hashlib,json,subprocess,sys,time,shutil
R=Path('/private/tmp/vellum-native-audit');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent;O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-listbox-metadata')
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
env={**child_environment(),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2'}
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=env,capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in(root/'drivers/cogent/build'/m).rglob('*')if f.is_file()}
D=R/'docs/reports/macos-listbox-metadata/records';q=json.loads((D/'qualification.json').read_text());review=json.loads((P/'final-review.json').read_text())
assert q['result']=='PASS_SCOPED_LISTBOX_METADATA_CHECKPOINT'and review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not review['unresolved_findings']and q['prism_invocations']==0
assert q['native_application_executed']and q['native_external_ax_metadata_qualified']and all(not q[k]for k in ['native_pointer_keyboard_qualified','native_focus_reveal_qualified','human_voiceover_qualified','native_latency_qualified','retained_memory_qualified','full_mac_qualified'])
base=q['base_commit'];commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]and git(C,'rev-parse','HEAD')==base and not git(C,'status','--porcelain')and not git(R,'status','--porcelain')
changed=set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines());assert changed==set(q['sources'])|{'docs/reports/macos-listbox-metadata/records/'+n for n in ['qualification.json','archive-index.json','evidence.tar.xz']}
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert review['sources']=={n:expected[n]for n in changed}and all(expected[n]==h for n,h in q['sources'].items())
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/name.decode();assert kind=='blob'and path.is_file()and not path.is_symlink();data=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
assert prepared(C)==q['prepared_before']==q['prepared_after']==prepared(R)and len(q['prepared_after'])==6227
historical=Path('/private/tmp/vellum-macos-quiet-current/stop-live');historical_hash=sha(historical);assert historical_hash=='db5c4df12d8f08cedc63b39d7998a963aa1ca313aaa3b5a434ad64836064164f'
O.mkdir(parents=True,exist_ok=True);output=O/'canonical-promotion.json';output.open('x').close();start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'changed_files':sorted(changed),'scope':'Scoped native ListBox metadata fix; native pointer/input/focus and full Mac qualification remain open.'}
try:
 with(O/'prepare.stdout').open('xb')as so,(O/'prepare.stderr').open('xb')as se:
  git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
  result=run_child(['python3','prepare.py'],cwd=C/'drivers/cogent',env=env,stdout=so,stderr=se,timeout=120)
 assert result.returncode==0
 actual=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'prepare_exit_code':result.returncode,'prepare_stdout_sha256':sha(O/'prepare.stdout'),'prepare_stderr_sha256':sha(O/'prepare.stderr'),'tracked_files':len(expected),'tracked_exact':set(actual)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_files':6227,'prepared_exact':prepared(C)==q['prepared_after'],'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'heads_exact':git(C,'rev-parse','HEAD')==commit and git(R,'rev-parse','HEAD')==commit,'historical_stop_marker_preserved':sha(historical)==historical_hash,'archive_sha256':sha(C/'docs/reports/macos-listbox-metadata/records/evidence.tar.xz'),'final_review_sha256':sha(P/'final-review.json')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean','heads_exact','historical_stop_marker_preserved'])and record['archive_sha256']==q['archive_sha256']
 for name in ['qualification.json','archive-index.json','evidence.tar.xz']:shutil.copy2(D/name,O/name)
 for name in ['final-review.json','final-review.md','summary.json','gallery-final','final-native.json','final-native-inspector.stdout']:shutil.copy2(P/name,O/name)
 assert sha(O/'gallery-final')==q['native_binary_sha256'];record['durable_private_artifacts_exact']=True;record['result']='PASS_CANONICAL_PROMOTION'
except BaseException as error:record['result']='FAILED_CANONICAL_PROMOTION';record['error']={'type':type(error).__name__,'message':str(error)};raise
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');output.write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
