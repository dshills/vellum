from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-listbox');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child,terminate_owned_group
from sdk_environment import child_environment
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
review=json.loads((P/'source-review.json').read_text());assert all(sha(R/n)==h for n,h in review['sources'].items())and not(P/'stop-live').exists()
name=sys.argv[1];source=P/'ListBoxLive.swift';tool=P/(name+'-inspector');binary=P/'VellumListBox.app/Contents/MacOS/VellumListBox';start=time.monotonic()
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorization_sha256':sha(P/'live-authorization.json'),'framework_sources':review['sources'],'swift_source_sha256':sha(source),'producer_sha256':sha(__file__),'native_binary_sha256':sha(binary),'diagnostic_overlay_inputs':{n:sha(P/n) for n in ['selector-overlay.json','accessibility-diagnostic.m']},'diagnostic_binary':True,'native_application_executed':False,'native_exit_code':None,'inspector_exit_code':None,'native_process_terminal':False,'inspector_process_terminal':False,'stop_reason':None}
app=inspector=None
try:
 with(P/(name+'-compile.stdout')).open('xb')as so,(P/(name+'-compile.stderr')).open('xb')as se:
  argv=['/usr/bin/swiftc','-module-cache-path',str(P/'swift-cache'),str(source),'-o',str(tool)];record['compiler_argv']=argv;record['compiler_exit_code']=run_child(argv,env=child_environment(),stdout=so,stderr=se,timeout=60).returncode
 assert record['compiler_exit_code']==0
 record['inspector_sha256']=sha(tool)
 with(P/(name+'-app.stdout')).open('xb')as ao,(P/(name+'-app.stderr')).open('xb')as ae,(P/(name+'-inspector.stdout')).open('xb')as io,(P/(name+'-inspector.stderr')).open('xb')as ie:
  record['native_argv']=[str(binary),'-exit-after=3m'];app=subprocess.Popen(record['native_argv'],cwd=R,env=child_environment(runtime=True),stdout=ao,stderr=ae,start_new_session=True);record['native_application_executed']=True;record['native_pid']=app.pid
  record['inspector_argv']=[str(tool),str(app.pid)];inspector=subprocess.Popen(record['inspector_argv'],cwd=R,env=child_environment(runtime=True),stdout=io,stderr=ie,start_new_session=True);record['inspector_pid']=inspector.pid
  (P/(name+'-owned-processes.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'app_pid':app.pid,'inspector_pid':inspector.pid}),flush=True)
  deadline=time.monotonic()+45
  while inspector.poll()is None:
   if(P/'stop-live').exists()or time.monotonic()>deadline:
    record['stop_reason']='human-returned-or-marker'if(P/'stop-live').exists()else'inspector-deadline';terminate_owned_group(inspector);break
   time.sleep(.1)
  record['inspector_exit_code']=inspector.wait(timeout=5)
  try:app.wait(timeout=5)
  except subprocess.TimeoutExpired:record['app_close_fallback']='owned-process-group';terminate_owned_group(app)
  record['native_exit_code']=app.wait(timeout=5)
finally:
 for process in [inspector,app]:
  if process is not None and process.poll()is None:terminate_owned_group(process)
 record['elapsed_seconds']=time.monotonic()-start;record['native_process_terminal']=app is not None and app.poll()is not None;record['inspector_process_terminal']=inspector is not None and inspector.poll()is not None;record['framework_sources_stable']=all(sha(R/n)==h for n,h in review['sources'].items());record['swift_source_stable']=sha(source)==record['swift_source_sha256']
 for f in sorted(P.glob(name+'-*.stdout'))+sorted(P.glob(name+'-*.stderr')):record[f.name+'_sha256']=sha(f)
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['inspector_exit_code','native_exit_code','elapsed_seconds','native_process_terminal','stop_reason']}),flush=True)
sys.exit(0 if record['inspector_exit_code']==0 and record['native_exit_code']==0 and record['framework_sources_stable'] else 1)
