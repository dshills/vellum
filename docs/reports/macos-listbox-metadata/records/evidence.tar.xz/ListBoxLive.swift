import ApplicationServices
import AppKit
import Foundation
struct Failure: Error, CustomStringConvertible { let description:String; init(_ s:String){description=s} }
func emit(_ o:[String:Any]){let d=try! JSONSerialization.data(withJSONObject:o,options:[.sortedKeys]);print(String(data:d,encoding:.utf8)!)}
func attr(_ n:AXUIElement,_ k:String)throws->CFTypeRef{var v:CFTypeRef?;let e=AXUIElementCopyAttributeValue(n,k as CFString,&v);guard e == .success,let v=v else{throw Failure("\(k):\(e.rawValue)")};return v}
func array(_ n:AXUIElement,_ k:String)->[AXUIElement]{(try? attr(n,k) as? [AXUIElement]) ?? []}
func string(_ n:AXUIElement,_ k:String)->String{(try? attr(n,k) as? String) ?? ""}
func encoded(_ s:String)->String{Data(s.utf8).base64EncodedString().replacingOccurrences(of:"+",with:"-").replacingOccurrences(of:"/",with:"_").replacingOccurrences(of:"=",with:"")}
func managed(_ s:String)->String{"node:"+encoded(s)}
func rowID(_ s:String)->String{"option:"+encoded("layers")+":"+encoded(s)}
func find(_ app:AXUIElement,_ id:String)throws->AXUIElement{let end=Date().addingTimeInterval(5);repeat{var q=[app];var at=0;while at<q.count && at<512 && Date()<end{let n=q[at];at+=1;_ = AXUIElementSetMessagingTimeout(n,0.3);if string(n,"AXIdentifier")==id{return n};q += array(n,"AXChildren");if at==1{q += array(n,"AXWindows")}};Thread.sleep(forTimeInterval:0.02)}while Date()<end;throw Failure("missing current element \(id)")}
func awaitValue(_ n:AXUIElement,_ value:String)throws{let end=Date().addingTimeInterval(3);repeat{if string(n,"AXValue")==value{return};Thread.sleep(forTimeInterval:0.02)}while Date()<end;throw Failure("expected value \(value), got \(string(n,"AXValue"))")}
func press(_ n:AXUIElement)throws{let e=AXUIElementPerformAction(n,kAXPressAction as CFString);guard e == .success else{throw Failure("press:\(e.rawValue)")};Thread.sleep(forTimeInterval:0.05)}
func focusPID()->pid_t {var value:CFTypeRef?;guard AXUIElementCopyAttributeValue(AXUIElementCreateSystemWide(),kAXFocusedApplicationAttribute as CFString,&value) == .success,let value=value else{return -1};var pid:pid_t=0;_ = AXUIElementGetPid(unsafeBitCast(value,to:AXUIElement.self),&pid);return pid}
func check(_ condition:Bool,_ why:String)throws{if !condition{throw Failure(why)}}
func checkSettable(_ n:AXUIElement,_ attribute:String,_ expected:Bool)throws {var value=DarwinBoolean(false);let error=AXUIElementIsAttributeSettable(n,attribute as CFString,&value);emit(["probe":"mutability","attribute":attribute,"query_error":error.rawValue,"settable":value.boolValue,"expected":expected]);try check(error == .success && value.boolValue == expected,"unexpected mutability for \(attribute)")}
func awaitBool(_ n:AXUIElement,_ attribute:String,_ expected:Bool)throws {let deadline=Date().addingTimeInterval(3);repeat {if let value=try? attr(n,attribute) as? NSNumber,value.boolValue == expected{return};Thread.sleep(forTimeInterval:0.02)}while Date()<deadline;throw Failure("expected \(attribute)=\(expected)")}
guard AXIsProcessTrusted()else{emit(["result":"UNAVAILABLE_EXISTING_AX_TRUST"]);exit(3)}
guard CommandLine.arguments.count==2,let pid=Int32(CommandLine.arguments[1])else{emit(["result":"INVALID_PID"]);exit(2)}
var evidence:[[String:Any]]=[]
do{
 let app=AXUIElementCreateApplication(pid);_ = AXUIElementSetMessagingTimeout(app,0.3)
 let registrationDeadline=Date().addingTimeInterval(5);var registered:NSRunningApplication?
 repeat {registered=NSRunningApplication(processIdentifier:pid);if registered != nil{break};RunLoop.current.run(until:Date().addingTimeInterval(0.02))}while Date()<registrationDeadline
 guard let running=registered else{throw Failure("app process absent after bounded registration wait")};emit(["probe":"session","frontmost_pid":focusPID()]);defer{running.terminate()}
 let tab=try find(app,"option:"+encoded("pages")+":"+encoded("lists"));try press(tab)
 let list=try find(app,managed("layers"));try awaitValue(list,"Background")
 let rows=array(list,"AXRows");try check(string(list,"AXRole")=="AXList"&&rows.count==24,"real AXList/24 rows unavailable")
 try check(array(list,"AXSelectedRows").count==1,"initial native selected row missing")
 let initialVisible=array(list,"AXVisibleRows").count;try check(initialVisible>0&&initialVisible<24,"native visible rows are not bounded")
 evidence.append(["step":"initial","role":string(list,"AXRole"),"rows":rows.count,"visible_rows":initialVisible,"value":string(list,"AXValue")])
 var initiallySettable=DarwinBoolean(false);let initialQuery=AXUIElementIsAttributeSettable(list,"AXSelectedRows" as CFString,&initiallySettable);try check(initialQuery == .success && initiallySettable.boolValue,"writable native list is not reported settable")
 try checkSettable(list,"AXValue",true)
 let earlyRows=[try find(app,rowID("layer-01"))] as CFArray
 let earlySet=AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,earlyRows);try check(earlySet == .success,"initial external setter refused");try awaitValue(list,"Guides")
 evidence.append(["step":"initial-external-AX-setter","value":string(list,"AXValue")])
 try check(AXUIElementSetAttributeValue(list,"AXValue" as CFString,"layer-00" as CFString) == .success,"host stable-ID setter refused");try awaitValue(list,"Background")
 let reject=try find(app,managed("list-reject"));try press(reject);try awaitBool(reject,"AXValue",true)
 let status=try find(app,managed("list-status"));let beforeReject=string(status,"AXDescription")+string(status,"AXTitle")
 try check(AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,earlyRows) == .success,"rejected request did not enter validated owner path");Thread.sleep(forTimeInterval:0.2)
 try check(string(list,"AXValue")=="Background","rejected external request changed accepted selection")
 let afterReject=string(status,"AXDescription")+string(status,"AXTitle");try check(beforeReject != afterReject,"rejected external request missing from owner status")
 evidence.append(["step":"external-AX-rejected-owner-request","value":string(list,"AXValue"),"status":afterReject])
 let readonly=try find(app,managed("list-readonly"));try press(readonly)
 try awaitBool(readonly,"AXValue",true)
 let beforeReadonly=string(status,"AXDescription")+string(status,"AXTitle")
 var settable=DarwinBoolean(false);let readonlyStatus=AXUIElementIsAttributeSettable(list,"AXSelectedRows" as CFString,&settable)
 emit(["probe":"readonly-metadata","query_error":readonlyStatus.rawValue,"selected_rows_settable":settable.boolValue,"checkbox_value":String(describing:try? attr(readonly,"AXValue"))])
 try check(readonlyStatus == .success && !settable.boolValue,"readonly native list remains reported writable")
 try checkSettable(list,"AXValue",false)
 let hostRefused=AXUIElementSetAttributeValue(list,"AXValue" as CFString,"layer-01" as CFString)
 let refused=AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,earlyRows);Thread.sleep(forTimeInterval:0.2)
 try check(string(list,"AXValue")=="Background" && beforeReadonly==string(status,"AXDescription")+string(status,"AXTitle"),"read-only external setter changed model or emitted owner proposal")
 evidence.append(["step":"external-AX-readonly-refusal","setter_error":refused.rawValue,"host_setter_error":hostRefused.rawValue,"attribute_settable":settable.boolValue,"value":string(list,"AXValue")])
 let clear=try find(app,managed("list-clear"));try press(clear);try awaitValue(list,"");try check(array(list,"AXSelectedRows").isEmpty,"programmatic clear retained selected row")
 evidence.append(["step":"programmatic-clear","selected_rows":0])
 try press(readonly);try awaitBool(readonly,"AXValue",false);try press(reject);try awaitBool(reject,"AXValue",false)
 try checkSettable(list,"AXSelectedRows",true);try checkSettable(list,"AXValue",true)
 try check(CFEqual(list,try find(app,managed("layers"))),"readonly transition replaced native list identity")
 let disabled=try find(app,managed("list-disabled"));try press(disabled);try awaitBool(list,"AXEnabled",false)
 try checkSettable(list,"AXSelectedRows",false);try checkSettable(list,"AXValue",false)
 let beforeDisabled=string(status,"AXDescription")+string(status,"AXTitle")
 let disabledSet=AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,earlyRows);Thread.sleep(forTimeInterval:0.2)
 try check(string(list,"AXValue").isEmpty && beforeDisabled==string(status,"AXDescription")+string(status,"AXTitle"),"disabled list mutation or callback")
 evidence.append(["step":"disabled-selectedRows-refusal","setter_error":disabledSet.rawValue])
 try press(disabled);try awaitBool(list,"AXEnabled",true);try checkSettable(list,"AXSelectedRows",true)
 var unknown=DarwinBoolean(true);let unknownError=AXUIElementIsAttributeSettable(list,"AXVellumUnknownAttribute" as CFString,&unknown)
 try check(unknownError != .success || !unknown.boolValue,"unknown attribute reported settable")
 try check(string(list,"AXRole")=="AXList","unknown attribute query killed native list")
 evidence.append(["step":"unknown-attribute-survived","query_error":unknownError.rawValue,"settable":unknown.boolValue])
 let last=try find(app,rowID("layer-23"));let finalRows=[last] as CFArray
 try check(AXUIElementSetAttributeValue(list,"AXSelectedRows" as CFString,finalRows) == .success,"last selection setter refused");try awaitValue(list,"Annotations")
 evidence.append(["step":"external-AX-select-offscreen-stable-ID","value":string(list,"AXValue"),"selected_rows":array(list,"AXSelectedRows").count])
 emit(["result":"PASS_SCOPED_NATIVE_LISTBOX_WRITABILITY","pid":pid,"events":evidence,"scope":"Actual Mac app, external AX list/row/visible/selected getters and owner-validated selection/rejection/read-only/clear. Foreground activation and native focus/reveal unqualified; Read-only selectedRows metadata checked separately from owner refusal. No pointer/key, physical hardware/human VoiceOver, cross-display, performance or memory qualification"])
}catch{emit(["result":"FAIL_SCOPED_NATIVE_LISTBOX_INPUT","pid":pid,"events":evidence,"error":"\(error)"]);exit(1)}
