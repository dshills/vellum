from pathlib import Path
import hashlib,io,json,lzma,tarfile
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-native-audit');D=R/'docs/reports/macos-listbox-metadata/records'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((P/'summary.json').read_text());review=json.loads((P/'checkpoint-review.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE'and review['sources']==s['sources']and not review['unresolved_findings']and all(sha(R/n)==h for n,h in s['sources'].items())
assert s['result']=='PASS_SCOPED_LISTBOX_METADATA_CHECKPOINT'and s['prism_invocations']==0
D.mkdir(exist_ok=False)
excluded={'swift-cache','VellumListBox.app','VellumListBoxMetadata.app','__pycache__'}
omitted={}
for f in P.iterdir():
 if f.is_file()and f.read_bytes()[:4]in[b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe']:
  omitted[f.name]={'sha256':sha(f),'bytes':f.stat().st_size,'reason':'Private compiled binary retained separately; source/receipt/logs archived.'}
(P/'omitted-binaries.json').write_text(json.dumps(omitted,indent=2)+'\n')
files=[]
for f in sorted(P.iterdir()):
 if f.name in excluded or f.name in omitted:continue
 if f.is_file():files.append(f)
 elif f.is_dir():files.extend(x for x in sorted(f.rglob('*'))if x.is_file()and'__pycache__'not in x.parts)
members={f.relative_to(P).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size}for f in files};a=D/'evidence.tar.xz'
with a.open('xb')as raw,lzma.LZMAFile(raw,'w',preset=6)as z,tarfile.open(fileobj=z,mode='w')as t:
 for f in files:
  data=f.read_bytes();i=tarfile.TarInfo(f.relative_to(P).as_posix());i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
index={'archive_sha256':sha(a),'archive_bytes':a.stat().st_size,'members':members,'omitted_binaries':omitted,'excluded_directories':sorted(excluded)}
(D/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
q={**s,'checkpoint_review_sha256':sha(P/'checkpoint-review.json'),'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'archive_members':len(members)}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k]for k in ['result','archive_members','archive_bytes','archive_sha256']}))
