from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-native-audit');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
read=lambda n:json.loads((P/n).read_text())
base='ea0032a9b43acd27e9732810272b324213087ad3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==base
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
names={n for n in names if not n.startswith('docs/reports/macos-listbox-metadata/records/')}
sources={n:sha(R/n)for n in sorted(names)};assert len(sources)==6
def prepared(root):return {f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in(root/'drivers/cogent/build'/m).rglob('*')if f.is_file()}
tree=prepared(R);assert len(tree)==6227 and tree==prepared(C)
checks=[]
checked=read('adapter-race-final.json')['source_delta_before']
assert set(checked)==set(sources)
docdelta={n:{'before':checked[n],'after':sources[n]}for n in sources if sources[n]!=checked[n]}
assert set(docdelta)=={'docs/reports/macos-listbox-metadata/README.md'}
for name in ['adapter-race-final','adapter-vet-final','native-build-final','native-package-final']:
 d=read(name+'.json')
 assert d['source_commit']==base and d['exit_code']==0 and d['error']is None and d['source_delta_stable']and d['source_delta_before']==checked==d['source_delta_after']
 assert d['prepared_before']==tree==d['prepared_after']
 assert all(sha(P/(name+'.'+channel))==d[channel+'_sha256']for channel in ['stdout','stderr'])
 checks.append({'name':name,'receipt_sha256':sha(P/(name+'.json')),'argv':d['argv'],'exit_code':0,'elapsed_seconds':d['elapsed_seconds']})
original=read('baseline-native.json');final=read('final-native.json')
for name,d in [('baseline-native',original),('final-native',final)]:
 assert d['native_exit_code']==0 and d['compiler_exit_code']==0 and d['native_process_terminal']and d['inspector_process_terminal']and d['sources_stable']and d['binary_stable']and d['swift_stable']and d['stop_reason']is None
 assert all(sha(P/n)==h for n,h in d['logs'].items())
assert original['inspector_exit_code']==1 and final['inspector_exit_code']==0 and original['swift_source_sha256']==final['swift_source_sha256']==sha(P/'ListBoxLive.swift')
assert original['producer_sha256']==final['producer_sha256']==sha(P/'native_check-v1.py.txt')
last=lambda name:json.loads((P/(name+'-inspector.stdout')).read_text().strip().splitlines()[-1])
o=last('baseline-native');f=last('final-native')
assert o['error']=='readonly native list remains reported writable'and f['result']=='PASS_SCOPED_NATIVE_LISTBOX_WRITABILITY'
assert final['binding']['sources']['drivers/cogent/accessibility_darwin.m']==sources['drivers/cogent/accessibility_darwin.m']
assert final['binding']['sources']['drivers/cogent/list_box_writability_darwin_test.go']==sources['drivers/cogent/list_box_writability_darwin_test.go']
binary=sha(P/'gallery-final');assert binary==final['binding']['binary_sha256']==sha(Path(final['binding']['binary']))
history=Path('/private/tmp/vellum-macos-quiet-current/stop-live');assert sha(history)=='db5c4df12d8f08cedc63b39d7998a963aa1ca313aaa3b5a434ad64836064164f'
summary={'result':'PASS_SCOPED_LISTBOX_METADATA_CHECKPOINT','base_commit':base,'sources':sources,'checks':checks,'prepared_before':tree,'prepared_after':tree,'native_baseline':{'result':'EXPECTED_NATIVE_ORACLE_FAILURE','receipt_sha256':sha(P/'baseline-native.json'),'error':o['error'],'binary_sha256':original['binding']['binary_sha256']},'native_final':{'result':final['result'],'receipt_sha256':sha(P/'final-native.json'),'observed':f},'native_binary_sha256':binary,'native_application_executed':True,'native_external_ax_metadata_qualified':True,'native_pointer_keyboard_qualified':False,'native_focus_reveal_qualified':False,'human_voiceover_qualified':False,'native_latency_qualified':False,'retained_memory_qualified':False,'full_mac_qualified':False,'prism_invocations':0,'review_policy':'Small internal-review follow-up after the complete Anthropic Claude Sonnet5.5 ListBox checkpoint; no new provider qualification claimed.','native_qualification_findings':[{'id':'LIST-NATIVE-01','status':'CLOSED_SCOPED_NATIVE_METADATA','scope':'SelectedRows/value metadata plus real external owner selection/rejection/readOnly/disable/restoration; one local Mac.'},{'id':'LIST-NATIVE-02','status':'OPEN','scope':'Foreground PID unavailable; no native pointer/key/focus qualification or cause assertion.'}],'failed_or_superseded_attempts':[{'name':'selector-native-v1','scope':'Overlay instrumentation not established; repeated native subset does not trace selector dispatch.'},{'name':'selector-native-v2','scope':'Inspector raced app registration; app fallback terminated/reaped. Subsequent fixture added bounded registration wait.'},{'name':'metadata-original','scope':'Invalid direct legacy-message test oracle; original superclass lacks optional method. SIGABRT retained, not proof of original metadata behavior.'},{'name':'metadata-routing-v1','scope':'Broad draft, superseded by list-only subclass.'},{'name':'metadata-routing-v2','scope':'Targeted draft check; final full-suite receipt is authoritative.'},{'name':'legacy-native-v1','scope':'Feasibility experiment with diagnostics; not final production qualification.'}],'cleanup_scope':'App and inspector children terminal/reaped; no independent process-group absence observation or native/GPU allocation-zero evidence.','limits':['One local Mac and SDK; optional legacy compatibility hook remains deprecated.','Setter transport success is distinct from owner admission/acceptance.','Private unsigned native bundle; no public release/signing/distribution qualification.','Existing full Mac performance/endurance/memory/physical/human/distribution gates remain open.'],'historical_stop_marker_preserved':True}
summary['checked_sources']=checked;summary['post_check_documentation_delta']=docdelta
summary['producer_hardening']='native_check-v1.py.txt produced both completed runs. Future native_check.py adds immediate prelaunch source/manifest/binary/Swift/inspector rechecks and stop-marker-fails-PASS. These hardening edits are source-reviewed, not claimed runtime-tested.'
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k]for k in ['result','native_binary_sha256','prism_invocations']}))
