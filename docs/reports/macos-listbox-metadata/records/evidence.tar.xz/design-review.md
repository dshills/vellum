# ListBox writability design review

A ListBox-only native subclass is a reasonable compatibility seam. Keep the base class untouched and preserve modern/owner guards. The deprecated selector requires a guarded lexical-superclass lookup; a header declaration is not an implementation guarantee.

Two required implementation checks remain: ordinary native IDs currently reuse across role changes, so class transitions need explicit replacement; and replacement clears frame caches while Go can suppress an identical geometry payload. Preserve ordinary frame cache or invalidate the bridge cache, with a both-directions same-ID/same-bounds regression.

Verify AXSelectedRows true/false/true, owner refusal and the intentional AXValue host route on the final source-bound binary. Other roles, foreground/input/focus, human VoiceOver and cross-version behavior remain unqualified. Diagnostic source copies now match their recorded hashes. No implementation or runtime approval is issued here.
