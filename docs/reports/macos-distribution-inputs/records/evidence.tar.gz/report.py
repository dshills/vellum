import hashlib,io,json,tarfile
from pathlib import Path
root=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-distribution-inventory');report=root/'docs/reports/macos-distribution-inputs';records=report/'records';records.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=json.loads((phase/'qualification.json').read_text());prism=json.loads((phase/'prism-v1/prism.json').read_text());process=json.loads((phase/'prism-v1/process.json').read_text());review=json.loads((phase/'source-review-v3.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings'] and all(sha(Path(n))==h for n,h in review['reviewed_file_sha256'].items())
assert review['finding_resolution']['id']=='4120b84c2f4db58d' and review['finding_resolution']['disposition']=='ACCEPTED_FIXED'
assert prism['coverage']['complete'] and prism['coverage']['files']==7 and prism['coverage']['chunks']==3 and not prism['coverage']['excluded'] and not prism['coverage']['skipped'] and prism['coverage']['truncatedBytes']==0
assert prism['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert process['exit_code']==1 and process['source_index_stable'] and len(prism['findings'])==1 and prism['findings'][0]['id']=='4120b84c2f4db58d'
assert {n for n,h in q['source'].items()if process['after'][n]!=h}=={'scripts/distribution-inventory.py','scripts/distribution-inventory_test.py','specs/release.md'}
assert q['repeat_byte_identical'] and q['sdk_file_identities_match_current'] and q['result']=='PASS_STATIC_INPUT_INVENTORY'
members={p.relative_to(phase).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(phase.rglob('*'))if p.is_file()and'__pycache__'not in p.parts}
(records/'archive-index.json').write_text(json.dumps(members,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.gz','w:gz')as t:
 for name in members:
  data=(phase/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
checkpoint={'base_commit':q['base_commit'],'scope':'Mac SDK source/build-input identity inventory, no rights approval or linked-binary/native/runtime/performance acceptance.','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':1,'prism_findings_resolved':True,'source_review_sha256':sha(phase/'source-review-v3.json'),'qualification_sha256':sha(phase/'qualification.json'),'inventory_sha256':q['inventory_sha256'],'archive':{'sha256':sha(records/'evidence.tar.gz'),'members':len(members),'index_sha256':sha(records/'archive-index.json')},'prepared_files':len(q['prepared']),'distribution_audit':'pending','live_tests_run':False}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
report.joinpath('README.md').write_text('''# Mac distribution input checkpoint

The new collector records actual SDK source files and selected workbench build
inputs without launching an application. It provides reproducible evidence for
the still-pending distribution audit; it approves no redistribution rights.

The final capture used macOS arm64, cgo enabled and Go 1.27.2. Two corrected-source
runs produce byte-identical JSON SHA256 `'''+q['inventory_sha256']+'''`.
Capture source is base 777afeb with private precommit changes and explicit
untracked inclusion. It records 6793 SDK files, 232 nonstandard selected packages,
4438 resolved embedded assets (including 12 fonts) and 89 module notice records.
The complete 6172 prepared files remain unchanged from the prior checkpoint.

The one native linker-search file candidate is Darwin arm64
`libwgpu_native.a`, 34356312 bytes, SHA256
`7d8b688a6b55f0728c847e1c3b028d07ccb1009d8cea4833a6186a5775384248`.
This is a conventional file in a declared module-owned search directory, not
proof of final linker selection or the archive's embedded Rust/C component
closure. The captured build has no unresolved native options in the collector's
recorded syntax. Framework references retain unverified resolution.

Five downloaded library modules lack their own conventional root/license-directory
declaration: WebGPU libs-android, libs-darwin, libs-ios, libs-linux and libs-windows.
All appear in the Go notice graph; only the Darwin archive is a native file
candidate for this target. Nearby notices are candidates, with all asset/native
rights remaining review-required. This inventory does not interpret those terms
or resolve native provenance. Namespace/MIT choices and release gates are unchanged.

Nine inventory fixtures pass, covering relocation/path aliases, exact identities,
pending status, missing/external/direct/unsupported link inputs, source-byte/set
and build-metadata drift, pre-hash entry admission, streaming notice refusal and
exclusive output. Existing SDK 28, SDK checker 20 and app packaging 16 tests pass.
Real collection, exact repeat and current source-file identity checks pass.
These are tooling checks, not application/native GPU or performance acceptance.

Internal review found and corrected two admission issues: selected source counts
were checked after hashing, and inherited notice collection loaded unused full
contents. Admission now precedes surplus hashing, and metadata-only notices
stream 64 KiB chunks with a 1 GiB file bound and retain no content copies. The SDK
producer's default notice-copy semantics stay fixed. Initial tests also exposed
path-alias/test-stream issues; the initial real run exposed Homebrew's Go LICENSE
placement in GOROOT's parent. Corrected identities and declaration candidates
pass; failed receipts remain archived.

One Prism review used Anthropic Claude Sonnet 5.5 with complete seven-file,
three-chunk coverage and reported one medium finding 4120b84c2f4db58d. Its raw exit 1
is preserved. The correction adds direct native file candidates and explicit
unresolved records for unknown/-Wl/-F, external searches and missing candidates;
framework names no longer imply system ownership. Independent V3 source review
approved that exact correction and finding closure. No unchanged provider rerun
was performed. V1 NEEDS_FIX and V2/V3 approvals remain distinct records.

Live windows/input/performance tests stay deferred until the user says the
computer is free. No app executed, OS preference changed or public artifact
published. Complete Mac acceptance, target performance, signing/notarization,
final native dependency closure and distribution approval remain open.

[Checkpoint](records/checkpoint.json), [raw evidence](records/evidence.tar.gz)
and [archive index](records/archive-index.json) bind the static observations.
''')
print(json.dumps({'members':len(members),'archive_sha256':checkpoint['archive']['sha256'],'report_sha256':sha(report/'README.md')}))
