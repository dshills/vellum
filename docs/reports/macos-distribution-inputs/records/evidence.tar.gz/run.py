import hashlib,json,sys,time
from pathlib import Path
root=Path('/private/tmp/vellum-large-data'); phase=Path('/private/tmp/vellum-distribution-inventory')
sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
label=sys.argv[1]; cwd=root/sys.argv[2]; argv=sys.argv[3:]; out=phase/label; out.mkdir(exist_ok=False)
record={'argv':argv,'cwd':str(cwd),'exit_code':None,'error':None,'live_tests':False}; start=time.monotonic()
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:
  r=run_child(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=240)
 record['exit_code']=r.returncode
except BaseException as error: record['error']={'type':type(error).__name__,'message':str(error)}
finally:
 record['elapsed_seconds']=time.monotonic()-start
 for n in ['stdout','stderr']: record[n+'_sha256']=hashlib.sha256((out/(n+'.log')).read_bytes()).hexdigest()
 (out/'process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));sys.exit(0 if record['exit_code']==0 and record['error']is None else 1)
