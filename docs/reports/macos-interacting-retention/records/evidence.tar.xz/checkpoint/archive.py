"""Fail-fast assembly of reviewed fixture and FAILED endurance evidence."""
from pathlib import Path
import hashlib, json, tarfile

R = Path('/private/tmp/vellum-large-data')
P = Path('/private/tmp/vellum-macos-interacting-retention')
D = R/'docs/reports/macos-interacting-retention/records'
def sha(f): return hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources = json.loads((P/'checkpoint-source.json').read_text())['sources']
assert len(sources) == 12 and all(sha(R/n) == h for n,h in sources.items())
internal = json.loads((P/'internal-final-review.json').read_text())
assert internal['result'] == 'APPROVED_SCOPED_SOURCE_AND_FAILED_EVIDENCE' and internal['unresolved_findings'] == 0
assert all(sha(P/n) == h for n,h in internal['evidence_bindings'].items())
assert internal['sources'] == sources
prism = json.loads((P/'prism-v1/prism.json').read_text())
process = json.loads((P/'prism-v1/process.json').read_text())
assert process['exit_code'] == 0 and process['error'] is None and process['source_index_stable']
assert prism['coverage']['complete'] and prism['coverage']['files'] == 12 and not prism['findings']
assert prism['coverage']['reviewer'] == [{'provider':'anthropic','model':'claude-sonnet-5-5'}]
failed = json.loads((P/'failed-campaign-summary-v3.json').read_text())
assert failed['result'] == 'PRESERVED_FAILED_CAMPAIGN' and failed['completed_cycles'] == 343
assert failed['full_campaign_qualified'] is False and failed['steps_with_retries'] == 4 and len(failed['trailing_retries']) == 1 and failed['total_retry_steps'] == 5
assert failed['run_receipt_sha256'] == sha(P/'interacting-1000.json')
assert failed['producer_sha256'] == sha(P/'preserve_terminal_v3.py')
assert failed['heap_profile_sha256'] == sha(P/'final.heap')
preflight = json.loads((P/'preflight-summary-v2.json').read_text())
assert preflight['result'] == 'PASS_FIVE_INTERACTING_PREFLIGHT_CYCLES' and preflight['actions'] == 120
base = json.loads((P/'baseline-v2.json').read_text())
assert len(base['prepared']) == 6204
current_prepared = {f.relative_to(R/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting'] for f in sorted((R/'drivers/cogent/build'/m).rglob('*')) if f.is_file()}
assert current_prepared == base['prepared']
code_suffixes = {'.go','.mod','.sum','.m','.h','.c','.patch','.sh','.py'}
for name in ['interacting-native-contracts-final','interacting-accessibility-retirement-final','interacting-native-vet-final','interacting-model-layout-final']:
    receipt = json.loads((P/(name+'.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['error'] is None and receipt['live_tests'] is False
    assert receipt['source_delta_stable'] and receipt['prepared_before'] == receipt['prepared_after'] == base['prepared']
    for n,h in receipt['source_delta_after'].items():
        if Path(n).suffix in code_suffixes: assert sha(R/n) == h
    for ch in ['stdout','stderr']: assert receipt[ch+'_sha256'] == sha(P/(name+'.'+ch))
allowed = {'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.heap'}
inputs = {'checkpoint/'+f.relative_to(P).as_posix():f for f in sorted(P.rglob('*')) if f.is_file() and not f.is_symlink() and '__pycache__' not in f.parts and f.suffix in allowed}
inputs.update({'reviewed_source/'+n:R/n for n in sources})
D.mkdir(parents=True,exist_ok=True)
index = {n:{'sha256':sha(f),'bytes':f.stat().st_size} for n,f in inputs.items()}
archive = D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3) as tar:
    for n,f in inputs.items(): tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    assert set(tar.getnames()) == set(index)
    for item in tar:
        assert item.isfile() and hashlib.sha256(tar.extractfile(item).read()).hexdigest() == index[item.name]['sha256']
q = {'result':'REVIEWED_COLOR_INCLUSIVE_LIFECYCLE_FIXTURE_WITH_FAILED_CAMPAIGN','base_commit':base['commit'],'sources':sources,
     'internal_review':'APPROVED_SCOPED_SOURCE_AND_FAILED_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5',
     'prism_files':12,'prism_calls':prism['coverage']['llmCalls'],'prism_unresolved_findings':0,
     'preflight_completed_windows':5,'preflight_completed_actions':120,'requested_campaign_windows':1000,
     'campaign_result':'FAILED_NATIVE_WINDOW_CYCLES','campaign_completed_windows':343,'completed_cycle_actions':8232,
     'failed_window':'native-cycle-0343','failed_attempted_window_ordinal':344,'failed_step':19,'completed_cycle_retry_steps':4,'trailing_retry_steps':1,'total_retry_steps':5,
     'native_clean_teardown':True,'retirement_trigger_known':False,'live_testing_paused':True,
     'prepared_files':6204,'prepared_changed':False,'full_campaign_qualified':False,'full_p6_qualified':False,
     'full_p11_qualified':False,'human_voiceover_qualified':False,'physical_input_qualified':False,
     'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'archive_sha256':sha(archive),
     'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'scope':'Original fixture/layout failures and strict admission assumption retained. Five-window preflight passes; 1000-window native campaign FAILS at attempted window344. Binary excluded, hash retained. Profile and early snapshot retained. No broad acceptance.'},indent=2)+'\n')
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({k:v for k,v in q.items() if k!='sources'},indent=2))
