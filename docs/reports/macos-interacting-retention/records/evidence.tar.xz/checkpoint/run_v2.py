"""Bounded, owned-process checks on the newly authorized quiet Mac host."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time

ROOT = Path('/private/tmp/vellum-large-data')
PHASE = Path('/private/tmp/vellum-macos-interacting-retention')
sys.path.insert(0, str(ROOT / 'scripts'))
from child_process import run_child
from sdk_environment import child_environment

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().rstrip('\n')

def identity():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0') + subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    suffixes = {'.go', '.mod', '.sum', '.m', '.h', '.c', '.patch', '.sh', '.py'}
    selected = {n: sha(ROOT / n) for n in names if n and not n.startswith('docs/reports/')
                and (Path(n).suffix in suffixes or n == 'drivers/cogent/native/dependencies.json')}
    prepared = {f.relative_to(ROOT / 'drivers/cogent/build').as_posix(): sha(f)
                for module in ['upstream', 'typesetting']
                for f in sorted((ROOT / 'drivers/cogent/build' / module).rglob('*')) if f.is_file()}
    return {'commit': git('rev-parse', 'HEAD'), 'source_status': '\n'.join(line for line in git('status', '--porcelain').splitlines() if not line[3:].startswith(('docs/','specs/')) and Path(line[3:]).suffix in {'.go','.mod','.sum','.m','.h','.c','.patch','.sh','.py'}),
            'selected_source': selected, 'prepared': prepared}

def baseline():
    actual = identity()
    assert len(actual['prepared']) == 6204
    dest = PHASE / 'baseline-v2.json'
    if dest.exists():
        assert actual == json.loads(dest.read_text()), 'source/prepared endpoint changed'
    else:
        dest.write_text(json.dumps(actual, indent=2) + '\n')
    return actual

def main():
    name, mode, relative, seconds = sys.argv[1:5]
    argv = sys.argv[5:]
    assert mode in ['build', 'live', 'performance'] and argv
    timeout = float(seconds)
    long_campaign = mode == 'live' and argv == [str(PHASE / 'window-cycle-v2'), '-composed', '-cycles=1000', '-sample-every=25', '-timeout=3h', '-heap-profile=' + str(PHASE / 'final.heap')]
    assert 0 < timeout <= (11100 if long_campaign else 3000)
    authorization = PHASE / 'testing-authorization.json'
    assert json.loads(authorization.read_text())['live_window_input_performance_tests_allowed']
    before = baseline()
    env = {**child_environment(runtime=mode != 'build'),
           'GOCACHE': '/tmp/vellum-p0-cache/build',
           'GOMODCACHE': '/tmp/vellum-p0-cache/mod', 'GOPATH': '/tmp/vellum-p0-cache/gopath'}
    receipt = {'argv': argv, 'cwd': str(ROOT / relative), 'mode': mode,
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'source_commit': before['commit'], 'baseline_sha256': sha(PHASE / 'baseline-v2.json'),
               'producer_sha256': sha(__file__), 'authorization_sha256': sha(authorization),
               'executable_sha256': sha(argv[0]) if Path(argv[0]).is_file() else None,
               'exit_code': None, 'error': None, 'timeout_seconds': timeout}
    started = time.monotonic()
    try:
        with (PHASE / (name + '.stdout')).open('xb') as output, (PHASE / (name + '.stderr')).open('xb') as errors:
            receipt['exit_code'] = run_child(argv, cwd=ROOT / relative, env=env,
                                             stdout=output, stderr=errors, timeout=timeout).returncode
    except BaseException as error:
        receipt['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        receipt['elapsed_seconds'] = time.monotonic() - started
        receipt['source_prepared_stable'] = identity() == before
        for channel in ['stdout', 'stderr']:
            path = PHASE / (name + '.' + channel)
            receipt[channel + '_sha256'] = sha(path) if path.is_file() else None
        (PHASE / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt), flush=True)
    if receipt['exit_code'] != 0 or receipt['error'] or not receipt['source_prepared_stable']:
        sys.exit(1)

if __name__ == '__main__':
    main()
