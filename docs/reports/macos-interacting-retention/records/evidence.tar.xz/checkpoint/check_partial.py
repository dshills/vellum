from pathlib import Path
import ast,datetime,json,hashlib
from run_v2 import ROOT as R,PHASE as P,identity,sha
base=json.loads((P/'baseline-v2.json').read_text());now=identity()
assert all(now[k]==base[k]for k in ['commit','selected_source','prepared']), 'frozen source/dependencies changed'
# Reuse the internally reviewed validator's explicit step inventory without
# executing terminal validation against an unfinished campaign.
plans=[n for n in ast.parse((P/'validate.py').read_text()).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='plan'for t in n.targets)]
assert len(plans)==1
plan=ast.literal_eval(plans[0].value);assert len(plan)==24
raw=(P/'interacting-1000.stdout').read_bytes();lines=raw.splitlines(keepends=True)
truncated_tail=bool(lines and not lines[-1].endswith(b'\n'))
if truncated_tail:lines=lines[:-1]
events=[json.loads(line)for line in lines if line.strip()]
cycles=[x for x in events if x.get('event')=='vellum.composed-cycle'];steps=[x for x in events if x.get('event')=='vellum.native-action'];samples=[x['sample']for x in events if x.get('event')=='vellum.window-cycle.sample']
assert not any(x.get('event')=='vellum.window-cycle.result'for x in events), 'terminal run: use full validator'
assert [x['cycle']for x in cycles]==list(range(1,len(cycles)+1))and len(cycles)<=1000
for i,c in enumerate(cycles):
 assert c['dense_defined']==c['dense_fully_visible']==1000 and c['tree_accessibility_rows']>0 and c['native_color_edits']==2 and c['native_tree_disclosures']==2
 assert all(c[k]for k in ['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])and not c['full_p11_qualified']
 assert len(c['native_actions'])==24 and [(a['Target'],a['Kind'],a['Value'])for a in c['native_actions']]==plan
 assert steps[i*24:(i+1)*24]==[{'event':'vellum.native-action','window':f'native-cycle-{i:04d}','action':a}for a in c['native_actions']]
 assert all(a['Attempts']==a['Admissions']==1 and a['OwnerAndNativeCompleted']for a in c['native_actions'])
assert 0<=len(steps)-len(cycles)*24<=24
expected_samples=list(range(0,len(cycles)+1,25));actual_samples=[s['Completed']for s in samples]
assert actual_samples==expected_samples or actual_samples==expected_samples[:-1], 'sample sequence diverged'
assert all(s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 for s in samples)
assert (P/'interacting-1000.stderr').stat().st_size==0
record={'result':'VALIDATED_COMPLETED_PREFIX_ONLY','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed_cycles':len(cycles),'validated_completed_actions':len(cycles)*24,'trailing_inflight_actions':len(steps)-len(cycles)*24,'truncated_inflight_line_excluded':truncated_tail,'forced_gc_sample_cycles':actual_samples,'source_prepared_stable_now':True,'baseline_sha256':sha(P/'baseline-v2.json'),'validator_sha256':sha(P/'validate.py'),'producer_sha256':sha(__file__),'observed_stdout_prefix_bytes':len(raw),'observed_stdout_prefix_sha256':hashlib.sha256(raw).hexdigest(),'terminal_receipt_present':(P/'interacting-1000.json').exists(),'full_campaign_qualified':False,'scope':'Live prefix inspection only; source/dependencies, completed native action order/counts/flags/density/tree/color and available samples. No final cleanup/profile/retention/1000/fullP11 acceptance.'}
with(P/f'partial-{len(cycles):04d}.json').open('x')as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
