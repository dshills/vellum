from pathlib import Path
import datetime,hashlib,json,subprocess,sys
P=Path('/private/tmp/vellum-macos-interacting-retention');R=Path('/private/tmp/vellum-large-data');sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
name=sys.argv[1];assert name in ['vmmap-early','vmmap-late'];expected=str(P/'window-cycle-v2');raw=subprocess.check_output(['ps','-axo','pid=,args='],text=True)
rows=[]
for line in raw.splitlines():
 parts=line.strip().split(None,1)
 if len(parts)==2 and parts[1].startswith(expected+' -composed -cycles=1000 '):rows.append((int(parts[0]),parts[1]))
assert len(rows)==1, 'expected exactly one owned campaign process'
pid,command=rows[0];assert command==' '.join([str(P/'window-cycle-v2'),'-composed','-cycles=1000','-sample-every=25','-timeout=3h','-heap-profile='+str(P/'final.heap')]);before=subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True).strip();assert before==command
cycles=[]
for line in (P/'interacting-1000.stdout').read_text().splitlines():
 try:x=json.loads(line)
 except json.JSONDecodeError:continue
 if x.get('event')=='vellum.composed-cycle':cycles.append(x['cycle'])
r=run_child(['vmmap','-summary',str(pid)],capture_output=True,timeout=30)
assert subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True).strip()==command
with (P/(name+'.stdout')).open('xb') as f:f.write(r.stdout)
with (P/(name+'.stderr')).open('xb') as f:f.write(r.stderr)
record={'argv':['vmmap','-summary',str(pid)],'owned_command':command,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed_cycles_at_capture':max(cycles,default=0),'exit_code':r.returncode,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
for channel in ['stdout','stderr']:record[channel+'_sha256']=hashlib.sha256((P/(name+'.'+channel)).read_bytes()).hexdigest()
with (P/(name+'.json')).open('x') as f:f.write(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(r.returncode)
