from pathlib import Path
import datetime,hashlib,json,os,sys
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-interacting-retention');sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
commands={'cpu':['/usr/sbin/sysctl','-n','machdep.cpu.brand_string'],'ram_bytes':['/usr/sbin/sysctl','-n','hw.memsize'],'logical_cpus':['/usr/sbin/sysctl','-n','hw.logicalcpu'],'os':['/usr/bin/sw_vers'],'architecture':['/usr/bin/uname','-m'],'go':['go','version']}
rows={}
for key,argv in commands.items():
 result=run_child(argv,cwd=R,env=child_environment(),capture_output=True,timeout=15)
 rows[key]={'argv':argv,'exit_code':result.returncode,'stdout':result.stdout.decode().strip(),'stderr':result.stderr.decode().strip()}
record={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'commands':rows,'runtime_environment':{key:os.environ.get(key)for key in ['GOMAXPROCS','GOMEMLIMIT','GPU_DEVICE','GPU_COMPUTE_DEVICE','VK_ICD_FILENAMES','VK_DRIVER_FILES']},'scope':'Read-only host/selected runtime inventory; display refresh/physical scale, private/GPU attribution and target qualification are not collected or inferred.'}
with (P/'host-inventory.json').open('x')as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
