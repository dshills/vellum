"""Validate and preserve a FAILED campaign; never qualify partial completion."""
import ast, datetime, hashlib, json, math
from run_v2 import PHASE as P, identity, sha

base = json.loads((P/'baseline-v2.json').read_text())
now = identity()
assert now['commit'] == base['commit'] and now['prepared'] == base['prepared']
# Terminal wrapper already bound original source. Only the reviewed post-run
# hook tests may differ now; no production source is changed.
assert set(now['selected_source']) == set(base['selected_source'])
assert all(now['selected_source'][n] == h for n,h in base['selected_source'].items() if n != 'drivers/cogent/cmd/window-cycle-smoke/interactions_test.go')
receipt = json.loads((P/'interacting-1000.json').read_text())
assert receipt['exit_code'] == 1 and receipt['error'] is None and receipt['source_prepared_stable']
assert receipt['producer_sha256'] == sha(P/'run_v2.py')
assert receipt['baseline_sha256'] == sha(P/'baseline-v2.json')
assert receipt['authorization_sha256'] == sha(P/'testing-authorization.json')
for ch in ['stdout', 'stderr']:
    assert receipt[ch+'_sha256'] == sha(P/('interacting-1000.'+ch))
raw = (P/'interacting-1000.stdout').read_bytes()
assert raw.endswith(b'\n')
events = [json.loads(line) for line in raw.splitlines()]
cycles = [e for e in events if e.get('event') == 'vellum.composed-cycle']
steps = [e for e in events if e.get('event') == 'vellum.native-action']
results = [e for e in events if e.get('event') == 'vellum.window-cycle.result']
assert len(results) == 1 and len(cycles) == 343
assert [c['cycle'] for c in cycles] == list(range(1, 344))
plans = [n for n in ast.parse((P/'validate.py').read_text()).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'plan' for t in n.targets)]
assert len(plans) == 1
plan = ast.literal_eval(plans[0].value)
assert len(plan) == 24
retries = []
for i, c in enumerate(cycles):
    actions = c['native_actions']
    assert len(actions) == 24 and [(a['Target'], a['Kind'], a['Value']) for a in actions] == plan
    assert steps[i*24:(i+1)*24] == [{'event':'vellum.native-action','window':f'native-cycle-{i:04d}','action':a} for a in actions]
    assert all(c[k] for k in ['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])
    assert c['native_color_edits'] == c['native_tree_disclosures'] == 2
    assert c['dense_defined'] == c['dense_fully_visible'] == 1000 and c['tree_accessibility_rows'] > 0
    assert c['requested_logical_size'] == [1920,1080] and c['full_p11_qualified'] is False
    for j, a in enumerate(actions):
        assert type(a['Attempts']) is int and type(a['Admissions']) is int
        assert 1 <= a['Admissions'] <= a['Attempts'] and a['OwnerAndNativeCompleted'] is True and a['NativeRole']
        assert type(a['ElapsedSeconds']) in (int,float) and math.isfinite(a['ElapsedSeconds']) and 0 < a['ElapsedSeconds'] <= 5
        if a['Attempts'] != 1 or a['Admissions'] != 1:
            retries.append({'cycle':i+1,'window':f'native-cycle-{i:04d}','step':j+1,'action':a})
    assert actions[15]['NativeRole'] == 'AXSlider' and actions[16]['NativeRole'] == 'AXTextField'
tail = steps[343*24:]
assert len(tail) == 19 and all(e['window'] == 'native-cycle-0343' for e in tail)
assert [(e['action']['Target'],e['action']['Kind'],e['action']['Value']) for e in tail] == plan[:19]
for i,e in enumerate(tail):
    a=e['action']
    assert type(a['Attempts']) is int and type(a['Admissions']) is int and 1<=a['Admissions']<=a['Attempts']
    assert type(a['ElapsedSeconds']) in (int,float) and math.isfinite(a['ElapsedSeconds']) and 0<a['ElapsedSeconds']<=5
    assert a['NativeRole']
    assert a['OwnerAndNativeCompleted'] is (i < 18)
assert tail[15]['action']['NativeRole']=='AXSlider' and tail[16]['action']['NativeRole']=='AXTextField'
assert tail[-1]['action']['Attempts']==tail[-1]['action']['Admissions']==1 and tail[-1]['action']['NativeRole']=='AXRow'
result = results[0]
assert result['result'] == 'FAILED_NATIVE_WINDOW_CYCLES' and result['requested_cycles'] == 1000 and result['completed_cycles'] == 343
assert result['cooperative_timeout_seconds'] == 10800 and receipt['timeout_seconds'] == 11100
assert receipt['argv'] == [str(P/'window-cycle-v2'),'-composed','-cycles=1000','-sample-every=25','-timeout=3h','-heap-profile='+str(P/'final.heap')]
assert receipt['cwd'] == '/private/tmp/vellum-large-data/drivers/cogent'
assert receipt['executable_sha256'] == sha(P/'window-cycle-v2')
assert result['go_heap_guard_bytes'] == 512<<20 and result['rss_guard_bytes'] == 1<<30
samples = result['samples']
assert [s['Completed'] for s in samples] == list(range(0,326,25))
assert [e['sample'] for e in events if e.get('event') == 'vellum.window-cycle.sample'] == samples
assert all(s['HeapAlloc'] <= 512<<20 and s['RSSBytes'] <= 1<<30 for s in samples)
assert result['samples_after_forced_gc'] and result['geometry_persistence_disabled_in_fixture']
for k in ['full_p11_qualified','gpu_memory_qualified','native_heap_qualified','preferences_changed','clipboard_access']:
    assert result[k] is False
cleanup = result['native_cleanup']
assert cleanup['MainThread'] and cleanup['CleanupObserved'] and cleanup['CallbacksStopped'] and not cleanup['WindowTitles']
assert cleanup['NativeOutstanding'] == cleanup['AccessibilityWindows'] == cleanup['PendingCallbacks'] == 0
assert 0 < (P/'final.heap').stat().st_size <= 8<<20
stderr = (P/'interacting-1000.stderr').read_text()
assert stderr == 'cycle 343: native tree:b3V0bGluZQ:row:bjA press: cogent: native accessibility attachment closed (attempts=1 admissions=1)\ncompleted 343 of 1000 cycles\n'
record = {
    'result':'PRESERVED_FAILED_CAMPAIGN', 'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'producer_sha256':sha(__file__), 'baseline_sha256':sha(P/'baseline-v2.json'), 'run_receipt_sha256':sha(P/'interacting-1000.json'),
    'completed_cycles':343, 'completed_cycle_actions':343*24, 'trailing_completed_actions':18, 'failed_action':tail[-1],
    'elapsed_seconds':receipt['elapsed_seconds'], 'retries':retries, 'steps_with_retries':len(retries),
    'trailing_retries':[{'cycle':344,'window':'native-cycle-0343','step':i+1,'action':e['action']} for i,e in enumerate(tail[:-1]) if e['action']['Attempts']!=1 or e['action']['Admissions']!=1],
    'total_retry_steps':len(retries)+sum(e['action']['Attempts']!=1 or e['action']['Admissions']!=1 for e in tail[:-1]),
    'queue_admissions_are_not_accepted_callbacks':True, 'retry_cause_observed':False,
    'source_prepared_stable':True, 'samples':samples, 'native_cleanup':cleanup,
    'heap_profile_bytes':(P/'final.heap').stat().st_size, 'heap_profile_sha256':sha(P/'final.heap'),
    'failed_before_user_return':True, 'interrupted_by_user_return':False,
    'full_campaign_qualified':False, 'full_p6_qualified':False, 'full_p11_qualified':False,
    'scope':'Failed campaign with validated completed prefix and cleanup; no 1000-cycle retention, native/GPU memory budget, human/physical-input or full framework qualification.'
}
with (P/'failed-campaign-summary-v3.json').open('x') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['samples','native_cleanup']},indent=2))
