from pathlib import Path
import json,subprocess,sys,time
P=Path('/private/tmp/vellum-macos-interacting-retention');R=Path('/private/tmp/vellum-large-data');sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
for threshold,name in [(150,'vmmap-early'),(650,'vmmap-late')]:
 deadline=time.monotonic()+10800
 while time.monotonic()<deadline:
  cycles=[]
  for line in (P/'interacting-1000.stdout').read_text().splitlines():
   try:x=json.loads(line)
   except json.JSONDecodeError:continue
   if x.get('event')=='vellum.composed-cycle':cycles.append(x['cycle'])
  if max(cycles,default=0)>=threshold:
   result=run_child(['python3',str(P/'snapshot.py'),name],capture_output=True,timeout=40)
   (P/(name+'-monitor.stdout')).write_bytes(result.stdout);(P/(name+'-monitor.stderr')).write_bytes(result.stderr)
   print(result.stdout.decode(),flush=True)
   if result.returncode:sys.exit(result.returncode)
   break
  if (P/'interacting-1000.json').exists():sys.exit('native process ended before snapshot milestone')
  time.sleep(10)
 else:sys.exit('bounded monitor deadline')
