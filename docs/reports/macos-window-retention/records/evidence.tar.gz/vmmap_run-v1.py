import datetime,hashlib,json,os,selectors,subprocess,sys,time
from pathlib import Path
p=Path('/private/tmp/vellum-macos-window-retention');sys.path.insert(0,'/private/tmp/vellum-large-data/scripts')
from child_process import run_child
end=datetime.datetime.fromisoformat(json.loads((p/'testing-authorization.json').read_text())['authorized_until_utc'])
remaining=(end-datetime.datetime.now(datetime.timezone.utc)).total_seconds();assert remaining>240
argv=[str(p/'window-cycle-cache-candidate'),'-cycles=1000','-sample-every=25','-timeout=4m'];started=time.monotonic();record={'argv':argv,'executable_sha256':hashlib.sha256(Path(argv[0]).read_bytes()).hexdigest(),'vmmap':[],'native_exit_code':None,'error':None}
with (p/'vmmap-native.stdout').open('xb') as output,(p/'vmmap-native.stderr').open('xb') as errors:
 native=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=errors,bufsize=0)
 record['owned_pid']=native.pid;record['owned_process_group']=os.getpgid(native.pid)
 select=selectors.DefaultSelector();select.register(native.stdout,selectors.EVENT_READ);pending=bytearray();seen=set()
 try:
  while native.poll() is None or pending:
   if time.monotonic()-started>min(260,remaining-5):raise TimeoutError('bounded native vmmap diagnostic expired')
   if not select.select(.1):
    if native.poll() is not None:break
    continue
   data=os.read(native.stdout.fileno(),65536)
   if not data:break
   output.write(data);output.flush();pending.extend(data)
   while b'\n' in pending:
    line,_,rest=pending.partition(b'\n');pending=bytearray(rest);value=json.loads(line)
    cycle=value.get('sample',{}).get('Completed')
    if cycle not in [250,750] or cycle in seen:continue
    seen.add(cycle);query=['/usr/bin/vmmap','-summary',str(native.pid)];begin=time.monotonic()
    result=run_child(query,timeout=5,capture_output=True)
    for channel,bytes_ in [('stdout',result.stdout),('stderr',result.stderr)]:(p/f'vmmap-{cycle}.{channel}').write_bytes(bytes_)
    record['vmmap'].append({'cycle_observed':cycle,'argv':query,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-begin,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
  native.wait(timeout=5);record['native_exit_code']=native.returncode
 except BaseException as error:
  record['error']={'type':type(error).__name__,'message':str(error)}
 finally:
  select.close();native.stdout.close()
  if native.poll() is None:native.kill();native.wait(timeout=5)
  record['observed_terminal_exit']=native.returncode;record['elapsed_seconds']=time.monotonic()-started
  (p/'vmmap-native-process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
if record['native_exit_code']!=0 or record['error'] is not None:sys.exit(1)
