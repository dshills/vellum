"""Compile/vet the private native visibility consumer; never launch it."""
from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('trusted_sdk_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
name,kind=sys.argv[1:];assert kind in ['build','vet']and not(W/name).exists()
names=run_child(['git','ls-files','-z'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode().split('\0')[:-1]
paths=[T/n for n in names]+[p for folder in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/folder).rglob('*')if p.is_file()]+[p for p in(W/'program').iterdir()if p.is_file()]+[p for p in(SDK/'drivers/cogent/build/libs-darwin').rglob('*')if p.is_file()]+[Path(__file__),Path(h.__file__),h.GUARD,h.GO,h.PROV,T/'scripts/child_process.py']
pins={str(p):h.sha(p)for p in paths}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','PYTHONDONTWRITEBYTECODE':'1'}
args=['build','-p=1','-tags=vellum_native_checks','-o',str(W/'native-visibility'),'.']if kind=='build'else['vet','-p=1','-tags=vellum_native_checks','.']
profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in [T,SDK,W/'program'])
def interrupted(signum,frame):raise InterruptedError('visibility build signal '+str(signum))
old=signal.signal(signal.SIGTERM,interrupted)
try:r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args],W/'program',W/name,lambda:False,lambda:all(h.sha(p)==v for p,v in pins.items()),timeout=300,limit=4<<20)
finally:signal.signal(signal.SIGTERM,old)
r['source_pins']=pins;r['native_executed']=False
if kind=='build'and r['exit_code']==0:r['binary']={'path':str(W/'native-visibility'),'sha256':h.sha(W/'native-visibility')}
(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}))
sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
