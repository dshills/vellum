# Native visibility lifecycle qualification

This is a separately reviewed corrected consumer. The original private
macos-native-visibility-2aca9b6 scope is failed and permanently sealed at
SessionIssued0/Measured0, with owned process97947 absent and full post-boundary
identity intact. Exact original-helper Foundation fixtures (nil and a fake
Foundation object, no NSApplication/NSWindow) prove Visible encodes as integers0/1.
The Go bool decoder dropped those packets, fitting its implied callbackFault and
two timeout errors; the original malformed native packet bytes were not retained.
The corrected helper uses explicit @YES/@NO, verified by the corresponding actual
fixed-helper fixture. It also retains bounded malformed-wire evidence so a future
decode failure fails promptly. No main-queue scheduling or product defect is
inferred. The original source/controller/plan/admission/results remain immutable.

One fresh native consumer of clean 2aca9b6, compiling actual checkout Go and
Objective-C sources with the existing source-built SDK786a library and stage86
dependencies. No Go overlay for compiler-read Objective-C files. No new product
API or SDK refresh. The prior visibility checkpoint's software evidence remains
unchanged. This is a bounded acceptance investigation for ordinary window redraw,
not another catalogue replay or a diagnosis of earlier occlusion failures.

The private consumer creates one process-owned native window with a unique title,
a normal Selector and a diagnostic Extension. The extension wraps the actual
composer drawer before painting, delegating ordinary, measured and redraw calls.
Counters report returned calls on those paths, not successful GPU/presentation/pixels.
EndMeasured delegates exactly once and preserves its actual checked result. Its
ordinary counter must advance after the real visible notification and before
the consumer makes a new explicit Frame request. Native ordinary redraw can also
be caused by the backend's expose handling: the existing software negative dirt
test supplies the causal discrimination for the Vellum observer path.
The actual native notification callback and ordinary End entry share a bounded
scalar ordinal under one mutex. After its delegate returns, End publishes that
entry ordinal with its completed counter. No lock spans native/GPU work. The
consumer requires both a later ordinary entry ordinal and a greater completed
count than captured at the notification, excluding a trailing hidden paint even
when scheduling delays its counter publication. This conservative check can refuse a recovery that
finishes before the private observer itself receives the notification; a failure
is not automatically evidence of a production redraw defect.

A separate private main-thread Cocoa observer weakly targets only the uniquely
named owned NSWindow. It subscribes before sampling, emits bounded scalar records
and waits for actual NSWindowDidChangeOcclusionStateNotification delivery. Commands
orderOut/orderFront that same window. A post-notification main dispatch barrier
precedes public DesktopSession.Visibility inspection, allowing production
synchronous notification observers to finish. No polling, focus, elapsed delay or
shown-state inference admits a Frame. Deadlines bound waiting; they never prove
readiness. A visible bit still does not promise successful drawable acquisition.

Fixed record: wait for actual visible state; inspect original-window visibility;
one initial explicit Frame/Snapshot; clean hide notification and hidden inspection;
one hidden Frame must return typed terminal unavailable without publishing a
Snapshot capability; show notification; an ordinary End before any new measured
request; visible inspection; one new explicit Frame/Snapshot. Open the actual
Selector through two public Go FIFO pointer records and repeat this hide/show
record with its popup open. Final Snapshot must retain that popup. There are
exactly seven explicit Frame requests (including a fresh capability before
Selector MouseUp), two expected unavailable results, five successful snapshots,
two ordinary redraw observations and five copied visibility
observations. This fixed scope never retries a Frame or resets a sealed case.

Explicitly retire the private Cocoa observer before original-window closure.
Also install a main-cleanup hook for every cancellation/early exit. Cancel the
worker when Run returns and bound its join by six seconds. Require original ref
closed, subsequent Visibility ErrDesktopClosed, tracked session Closed/Pendingfalse/
LiveWindows0 and cleanup callbacks/AX registry empty. This is tracked teardown,
not NSWindow deallocation or native/GPU memory qualification.

Before launch: internal source/controller review, actual-source build and vet,
independent validator negative controls, whole clean C/T+prepared+SDK identity,
exact binary/compiler/helper pins, then a separate exact-plan admission with a
30-minute launch deadline. Use the existing shared live lease and owned-child
controller, 50-second watchdog, 4MiB streams, IP/write restrictions and permanent
seal. Preserve every failure. No replay of any earlier native scope, OS input,
system settings, clipboard, input sources, VoiceOver, physical input, display
transition, timing/resource budget, public release or full Mac qualification.

This private consumer is not launched until exact admission. If visibility does
not arrive or the next explicit frame yields, fail and clean up; preserve that
actual boundary instead of adding an automatic acquisition loop.
