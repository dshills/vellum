"""One exact reviewed/admitted native window lifecycle; never reset/replay."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');HEAD='2aca9b6b30651bec195c4591c7acea4672b12714'
SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
s=importlib.util.spec_from_file_location('trusted_visibility_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g;sha=h.sha;need=h.need
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sys.path.insert(0,str(W));import validate as validator
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,capture_output=True,check=True,timeout=30).stdout
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'no vector symlinks')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean2aca9b6 checkout')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5498,'exact tracked source count')
 return {n:sha(root/n)for n in sorted(names)}
def baseline():
 a=source(C);need(source(T)==a,'whole C/T source identity')
 prepared=lambda root:{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
 p=prepared(C);need(prepared(T)==p and len(p)==6276 and digest(p)=='1cf2dfa8fd75d4c78cfe7e347ac81bf6e66d7c4072e9134e682897de4835d1ed','unchanged stage86 prepared inputs')
 sdk=vector(SDK);need(len(sdk)==7880 and digest(sdk)=='4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26','whole unchanged SDK')
 return {'source':a,'prepared':p,'sdk':sdk}
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def runtime_options():
 effective={**g.child_environment(True),'GOMAXPROCS':'2'}
 return{k:effective.get(k)for k in ['GOMAXPROCS','GOMEMLIMIT','GORACE']}
def prepare():
 need(not(W/'plan.json').exists()and not(W/'case').exists()and not(W/'stop-live').exists(),'fresh native lifecycle scope')
 b=baseline();review=read(W/'internal-source-review.json');need(review['approved']and review['source_controller_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items()),'exact source/controller review')
 pins={}
 for name in ['build-v1','vet-v1']:
  p=W/(name+'.json');r=read(p);need(passing(r),'owned prerequisite '+name);need(all(sha(k)==v for k,v in r['source_pins'].items()),'current build/vet inputs');pins.update(r['source_pins']);pins[str(p)]=sha(p)
  for stream,info in r['logs'].items():
   p=W/name/stream;need(p.stat().st_size==info['bytes']and sha(p)==info['sha256'],'raw prerequisite stream');pins[str(p)]=sha(p)
 controls=read(W/'controls-final.json');need(controls['synthetic_only']and not controls['native_executed']and len(controls['refusals'])==26 and all(sha(k)==v for k,v in controls['inputs'].items()),'current validator26refusals')
 old=W.parent/'macos-native-visibility-2aca9b6'
 need((old/'stop-live').is_file()and read(old/'result.json')['result']=='FAILED_OR_CANCELED'and read(old/'result.json')['post_boundary_pass'],'original native scope remains failed/sealed')
 for stem,types,result in [('wire-proof',[int,int],'PROVEN_ORIGINAL_VISIBLE_IS_JSON_INTEGER'),('wire-fixed-proof',[bool,bool],'PROVEN_FIXED_VISIBLE_IS_JSON_BOOLEAN')]:
  wire=read(W/(stem+'.json'));need(wire['result']==result and not wire['native_application_executed']and not wire['NSApplication_or_NSWindow_constructed']and [type(v['Visible'])for v in wire['values']]==types,'actual original/fixed wire proof')
 for name in ['compile-wire-original','run-wire-original','compile-wire-fixed','run-wire-fixed']:
  p=W/(name+'.json');r=read(p);need(passing(r)and all(sha(k)==v for k,v in r['source_pins'].items()),'actual unchanged Foundation wire check '+name);pins.update(r['source_pins']);pins[str(p)]=sha(p)
  for stream,info in r['logs'].items():
   p=W/name/stream;need(p.stat().st_size==info['bytes']and sha(p)==info['sha256'],'wire raw stream');pins[str(p)]=sha(p)
 need(sha(h.GO)==h.GOSHA and sha(SDK/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')==h.LIBSHA,'exact compiler/source-built native archive')
 files=[Path(__file__),W/'validate.py',W/'controls.py',W/'controls-final.json',W/'design.md',W/'internal-source-review.json',W/'build.py',Path(h.__file__),h.GUARD,h.GO,h.PROV,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 files += [W/n for n in ['wire.py','wire-fixed.py','wire-original.m','wire-fixed.m','wire-proof.json','wire-fixed-proof.json']]+[old/n for n in ['result.json','stop-live','plan.json','admission.json','internal-source-review.json','internal-native-result-review.json','program/main.go','program/native.m','case/stdout','case/stderr','case/owned.json']]
 pins.update({str(p):sha(p)for p in files});binary=read(W/'build-v1.json')['binary'];need(sha(binary['path'])==binary['sha256'],'exact private binary')
 now=datetime.datetime.now(datetime.timezone.utc)
 plan={'head':HEAD,'boundary':b,'pins':pins,'binary':binary,'runtime_options':runtime_options(),'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':50,'stream_limit_bytes':4<<20,'scope':'One separately reviewed corrected private600x400Dp one-native-window clean/popup hide-show lifecycle. Original native scope failed/sealed0issued, private wire defect proven with actual Foundation fixtures; explicitJSONbooleans plusboundedrawdecodefault added. Clean2aca9b6 actualTGo/native sources and stage86+SDK786a native library unchanged. Seven explicit Frames/two expected hidden typed terminal yields/five successful snapshots/five copiedvisibility/two publicGoFIFO pointerrecords; actual Cocoa notifications and completedordinaryEnd startingstrictlyaftervisiblecallback; actualpopup preserved andtrackedclosure. No reset/replay of originalsealedcase or Frame retry/OSinput/preferences/physical/pixels/presentation/performance/resources/SDKrefresh/distribution/fullMac claim.'}
 (W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(W/'plan.json'),'native_executed':False}))
def run():
 raw=(W/'plan.json').read_bytes();adraw=(W/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(adraw);stop=W/'stop-live'
 need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact native admission')
 need(not stop.exists()and not(W/'case').exists()and not(W/'result.json').exists(),'fresh one-shot lifecycle')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==adraw and all(sha(k)==v for k,v in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  need(not stop.exists()and stable(),'stable inputs/no stop');need(baseline()==p['boundary'],'whole source/prepared/SDK boundary');need(runtime_options()==p['runtime_options'],'runtime options')
 d={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_full_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('native visibility controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline')
   profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(q))+'))'for q in [C,T,SDK,W/'program'])
   r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path']],W/'program',W/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);d['run']=r;d['native_executed']=r['created']
   boundary();need(lease.held(),'lease through cleanup');d['post_boundary_pass']=True;need(passing(r),'owned native result')
   d['summary']=validator.validate((W/'case/stdout').read_bytes(),(W/'case/stderr').read_bytes());d['result']='PASS_NATIVE_VISIBILITY'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error','summary']}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in[['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
