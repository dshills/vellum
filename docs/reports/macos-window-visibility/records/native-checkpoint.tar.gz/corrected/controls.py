"""Synthetic validator controls only; no native or Go execution."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W));import validate as v
def fixture():
 rows=[]
 def add(event,value):rows.append({'Event':event,'Value':value})
 def native(kind,op,ord,visible,notifications,ordinary,measured,active=True):add('native',dict(Kind=kind,Operation=op,MainThread=True,WindowNumber=17 if active else 0,Visible=visible,Ordered=visible,Notifications=notifications,Active=active,Ordinal=ord,Ordinary=ordinary,Measured=measured))
 rect={'Min':{'X':10,'Y':10},'Max':{'X':200,'Y':45}}
 def snap(frame,popup=False):return dict(Frame=frame,Size={'X':600,'Y':400},LogicalDPI=162,Elements=[dict(ID='managed:selector',DomainID='selector',Value='Alpha',Enabled=True,Bounds=rect),dict(ID='managed:label',DomainID='label',Name='Native window visibility recovery'),dict(ID='managed:root',DomainID='root')],Popups=[dict(Interactive=True,Bounds=rect,Items=[dict(Name=n,Enabled=True)for n in ['Alpha','Beta']])]if popup else None)
 def vis(seq,want):add('visibility',dict(Known=True,Visible=want,Sequence=seq))
 native('ack',0,1,True,0,1,0);vis(2,True);add('baseline',snap(2))
 for i,phase in enumerate(['clean','popup']):
  if i:add('selector-down',snap(11));add('popup-baseline',snap(14,True))
  off=i*7;count=1+i;measured=[2,6][i]
  native('ack',1,2+off,False,i*2,count,measured-1);native('notification',0,3+off,False,i*2+1,count,measured-1);native('ack',3,4+off,False,i*2+1,count,measured-1)
  vis(3+i*2,False);add('hidden',dict(Phase=phase,Failure='surface unavailable attempts=1 first=occluded(196609) last=occluded(196609)',NoCapability=True,OrdinaryBefore=count,MeasuredBefore=measured,Session=dict(Pending=False,LiveWindows=1)))
  native('ack',2,5+off,True,i*2+1,count,measured);native('notification',0,6+off,True,i*2+2,count,measured);native('ack',3,8+off,True,i*2+2,count+1,measured)
  add('ordinary',dict(Phase=phase,Before=count,After=count+1,Measured=measured,NotificationOrdinal=6+off,AtNotification=count,LastOrdinaryStartOrdinal=7+off));vis(4+i*2,True);add('restored',dict(Phase=phase,Snapshot=snap([8,20][i],bool(i))))
 native('ack',4,16,False,4,3,7,False);add('closed',True)
 add('result',dict(Result='PASS_NATIVE_VISIBILITY',Error='<nil>',PrivateCleanup=True,Session=dict(Started=True,Closed=True,Pending=False,LiveWindows=0,Issued=21),Cleanup=dict(MainThread=True,CleanupObserved=True,CallbacksStopped=True,AccessibilityWindows=0,PendingCallbacks=0,NativeOutstanding=0,MenuCallbacks=0,TrayCallbacks=0),Measured=7,Ordinary=3,Redraw=0,PhysicalInputVerified=False,NativePixelsVerified=False))
 return rows
def encode(rs):return b''.join(json.dumps(r).encode()+b'\n'for r in rs)
def item(rs,event,i=0):return[r['Value']for r in rs if r['Event']==event][i]
def main():
 base=fixture();out={'synthetic_only':True,'native_executed':False,'positive':v.validate(encode(base),b''),'refusals':{}}
 cases={
 'missing-result':lambda r:r.pop(),
 'duplicate-result':lambda r:r.append(copy.deepcopy(r[-1])),
 'selector-value':lambda r:item(r,'baseline')['Elements'][0].update(Value='Beta'),
 'missing-notification':lambda r:r.remove(next(x for x in r if x['Event']=='native'and x['Value']['Kind']=='notification')),
 'wrong-window':lambda r:item(r,'native',2).update(WindowNumber=18),
 'not-main':lambda r:item(r,'native',2).update(MainThread=False),
 'sequence-reused':lambda r:item(r,'visibility',2).update(Sequence=3),
 'wrong-visible':lambda r:item(r,'visibility',2).update(Visible=False),
 'capability-fabricated':lambda r:item(r,'restored')['Snapshot'].update(Frame=7),
 'popup-lost':lambda r:item(r,'restored',1)['Snapshot'].update(Popups=None),
 'popup-items-wrong':lambda r:item(r,'popup-baseline')['Popups'][0]['Items'][1].update(Name='Gamma'),
 'two-acquisition-attempts':lambda r:item(r,'hidden').update(Failure='attempts=2 first=occluded(196609)'),
 'failed-frame-published':lambda r:item(r,'hidden').update(NoCapability=False),
 'pending-hidden':lambda r:item(r,'hidden')['Session'].update(Pending=True),
 'measured-retry':lambda r:item(r,'ordinary').update(Measured=3),
 'ordinary-before-notification':lambda r:item(r,'ordinary').update(LastOrdinaryStartOrdinal=5),
 'ordinary-only-trailing-hidden':lambda r:item(r,'ordinary').update(After=1),
 'wrong-notification-witness':lambda r:item(r,'ordinary').update(NotificationOrdinal=3),
 'unretired-observer':lambda r:item(r,'native',-1).update(Active=True),
 'reference-open':lambda r:next(x for x in r if x['Event']=='closed').update(Value=False),
 'pending-final':lambda r:item(r,'result')['Session'].update(Pending=True),
 'wrong-request-count':lambda r:item(r,'result')['Session'].update(Issued=22),
 'retained-native-callback':lambda r:item(r,'result')['Cleanup'].update(PendingCallbacks=1),
 'missing-private-cleanup':lambda r:item(r,'result').update(PrivateCleanup=False),
 'frame-retry-count':lambda r:item(r,'result').update(Measured=8),
 'native-pixels-overclaim':lambda r:item(r,'result').update(NativePixelsVerified=True),
 }
 for name,mutate in cases.items():
  rows=copy.deepcopy(base);mutate(rows)
  try:v.validate(encode(rows),b'')
  except(ValueError,KeyError,TypeError,IndexError)as e:out['refusals'][name]=str(e)
  else:raise AssertionError('validator admitted '+name)
 out['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),W/'validate.py']}
 assert sys.argv[1:]in [[],['current'],['final']]
 path=W/('controls-'+sys.argv[1]+'.json'if sys.argv[1:]else'controls.json');assert not path.exists();path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'positive':True,'refusals':len(out['refusals']),'native_executed':False}))
if __name__=='__main__':main()
