"""Independent bounded native-record validation; no app or OS operations."""
import json,math
def need(ok,message):
 if not ok:raise ValueError(message)
def integer(v):return type(v)is int and 0<=v<1<<63
def rectangle(r):
 need(type(r)is dict and set(r)=={'Min','Max'},'rectangle shape')
 for p in r.values():need(set(p)=={'X','Y'}and all(type(x)is int and abs(x)<1<<20 for x in p.values()),'bounded point')
 need(r['Max']['X']>r['Min']['X']and r['Max']['Y']>r['Min']['Y'],'nonempty rectangle')
def snapshot(s,popup):
 need(type(s)is dict and integer(s.get('Frame'))and s['Frame']>0,'completed frame capability')
 need(set(s.get('Size',{}))=={'X','Y'}and all(type(n)is int and 0<n<=8192 for n in s['Size'].values()),'bounded native scene size')
 need(type(s.get('LogicalDPI'))in [int,float]and math.isfinite(s['LogicalDPI'])and 0<s['LogicalDPI']<=1000,'native DPI')
 need(type(s.get('Elements'))is list and 3<=len(s['Elements'])<=32,'bounded semantics')
 need(all(type(e)is dict and type(e.get('ID'))is str and e['ID']for e in s['Elements']),'element identities')
 selectors=[e for e in s['Elements']if e.get('DomainID')=='selector'];need(len(selectors)==1,'one Selector')
 el=selectors[0];need(el.get('Enabled')is True and el.get('Value')=='Alpha','unchanged Selector value');rectangle(el['Bounds'])
 labels=[e for e in s['Elements']if e.get('DomainID')=='label'];need(len(labels)==1 and labels[0].get('Name')=='Native window visibility recovery','independent label')
 ps=s.get('Popups')or[];need(type(ps)is list and len(ps)==int(popup),'actual popup count')
 if popup:
  p=ps[0];rectangle(p['Bounds']);need(p.get('Interactive')is True,'interactive popup')
  need([e.get('Name')for e in p['Items']]==['Alpha','Beta']and all(e.get('Enabled')is True for e in p['Items']),'actual popup items')
 return s['Frame']
def validate(stdout,stderr):
 need(len(stdout)<=4<<20 and len(stderr)<=4<<20,'bounded streams')
 rs=[json.loads(line)for line in stdout.splitlines()if line.strip()]
 need(20<=len(rs)<=128 and all(type(r)is dict and set(r)=={'Event','Value'}for r in rs),'bounded exact record envelopes')
 nonnative=[r['Event']for r in rs if r['Event']!='native']
 need(nonnative==['visibility','baseline','visibility','hidden','ordinary','visibility','restored','selector-down','popup-baseline','visibility','hidden','ordinary','visibility','restored','closed','result'],'fixed consumer record order')
 grouped={}
 for r in rs:grouped.setdefault(r['Event'],[]).append(r['Value'])
 native=grouped['native'];number=None;last=0;ordinal=0;acks=[];notifications=[]
 for n in native:
  need(set(n)=={'Kind','Operation','MainThread','WindowNumber','Visible','Ordered','Notifications','Active','Ordinal','Ordinary','Measured'},'native scalar schema')
  need(integer(n['Ordinal'])and n['Ordinal']>ordinal and integer(n['Ordinary'])and integer(n['Measured']),'monotonic native witness');ordinal=n['Ordinal']
  need(n['MainThread']is True and n['Kind']in ['ack','notification']and integer(n['Notifications']),'native owner')
  need(type(n['Visible'])is bool and type(n['Ordered'])is bool and type(n['Active'])is bool,'native booleans')
  if n['WindowNumber']:
   need(type(n['WindowNumber'])is int and n['WindowNumber']>0,'window number');number=number or n['WindowNumber'];need(n['WindowNumber']==number,'same original sampled window')
  if n['Kind']=='notification':
   need(n['Notifications']==last+1 and n['Active']is True,'complete notification sequence');last=n['Notifications'];notifications.append(n)
  else:acks.append(n)
 if not acks[0]['Visible']:
  need(acks[1]['Operation']==3 and acks[1]['Visible']is True and any(n['Visible']is True and n['Ordinal']<acks[1]['Ordinal']for n in notifications),'initial actual visible notification barrier')
  acks=acks[:1]+acks[2:]
 need([n['Operation']for n in acks]==[0,1,3,2,3,1,3,2,3,4],'exact native command ACK record')
 need(all(n['Active']is True and n['WindowNumber']==number for n in acks[:-1]),'live owned diagnostic before retirement')
 need(4<=len(notifications)<=32,'actual visibility notifications')
 # Each authored order command is followed by a new expected-state actual
 # notification before the main-queue barrier ACK. Duplicate OS notifications
 # remain logged and cannot replace a missing transition.
 previous_count=acks[0]['Notifications']
 for start,barrier,want in [(1,2,False),(3,4,True),(5,6,False),(7,8,True)]:
  b=acks[barrier];need(b['Visible']is want and b['Notifications']>previous_count,'barrier after actual transition')
  need(any(n['Visible']is want and previous_count<n['Notifications']<=b['Notifications']for n in notifications),'new target-state notification')
  previous_count=b['Notifications']
 need(acks[-1]['Active']is False and acks[-1]['WindowNumber']==0,'private subscription retired')
 vs=grouped['visibility'];need(len(vs)==5,'five copied observations');prev=0
 for v,want in zip(vs,[True,False,True,False,True]):
  need(set(v)=={'Known','Visible','Sequence'}and v['Known']is True and v['Visible']is want and integer(v['Sequence'])and v['Sequence']>prev,'copied sequence/state');prev=v['Sequence']
 frames=[snapshot(grouped['baseline'][0],False),snapshot(grouped['restored'][0]['Snapshot'],False),snapshot(grouped['selector-down'][0],False),snapshot(grouped['popup-baseline'][0],True),snapshot(grouped['restored'][1]['Snapshot'],True)]
 need(frames==[2,8,11,14,20],'seven explicit Frame requests with independent FIFO tags')
 for i,phase in enumerate(['clean','popup']):
  hidden=grouped['hidden'][i];ordinary=grouped['ordinary'][i];restored=grouped['restored'][i]
  need(hidden['Phase']==ordinary['Phase']==restored['Phase']==phase,'phase identities')
  need(hidden['NoCapability']is True and 'attempts=1' in hidden['Failure']and 'occluded(196609)'in hidden['Failure'],'one actual terminal acquisition attempt')
  need(hidden['MeasuredBefore']==ordinary['Measured']==[2,6][i],'no automatic measured retry')
  need(integer(ordinary['Before'])and integer(ordinary['After'])and ordinary['Before']==hidden['OrdinaryBefore']and ordinary['After']>ordinary['Before'],'ordinary composition path observed before new frame')
  shown=[n for n in notifications if n['Ordinal']==ordinary['NotificationOrdinal']]
  need(len(shown)==1 and shown[0]['Visible']is True and shown[0]['Ordinary']==ordinary['AtNotification']and shown[0]['Measured']==ordinary['Measured'],'actual visible notification witness')
  need(ordinary['LastOrdinaryStartOrdinal']>ordinary['NotificationOrdinal']and ordinary['After']>ordinary['AtNotification'],'completed ordinary End began strictly after visible notification')
  need(hidden['Session']['Pending']is False and hidden['Session']['LiveWindows']==1,'terminal hidden request released')
 need(grouped['closed']==[True],'original reference closed')
 r=grouped['result'][0];need(r['Result']=='PASS_NATIVE_VISIBILITY'and r['Error']=='<nil>'and r['PrivateCleanup']is True,'successful owned consumer result')
 need(r['Session']=={'Started':True,'Closed':True,'Pending':False,'LiveWindows':0,'Issued':21},'exact session accounting')
 need(r['Measured']==7 and r['Ordinary']>=2 and r['PhysicalInputVerified']is False and r['NativePixelsVerified']is False,'measured count and evidence limits')
 c=r['Cleanup'];need(c['MainThread']is True and c['CleanupObserved']is True and c['CallbacksStopped']is True and all(c[k]==0 for k in ['AccessibilityWindows','PendingCallbacks','NativeOutstanding','MenuCallbacks','TrayCallbacks']),'tracked cleanup')
 return {'result':'PASS_NATIVE_VISIBILITY_RECORD','explicit_frames':7,'typed_terminal_hidden_frames':2,'successful_snapshots':5,'ordinary_redraw_observations':2,'public_pointer_records':2,'visibility_observations':5,'native_notifications':len(notifications),'native_window_number':number,'physical_input_verified':False,'native_pixels_verified':False,'native_deallocation_verified':False,'closed_full_mac_gates':[]}
