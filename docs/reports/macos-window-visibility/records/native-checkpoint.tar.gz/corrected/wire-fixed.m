#import "/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-native-visibility-corrected-2aca9b6/program/native.m"
#include <stdio.h>
void visibilityRecord(char *json) { puts(json); }
// Foundation object with the required selectors; no NSApplication/NSWindow.
@interface WireFake : NSObject
@end
@implementation WireFake
-(NSInteger)windowNumber { return 17; }
-(BOOL)isVisible { return YES; }
-(NSWindowOcclusionState)occlusionState { return NSWindowOcclusionStateVisible; }
@end
int main(void) {
 @autoreleasepool {
  record(@"fixture",0,nil,0,NO);
  record(@"fixture",0,(NSWindow *)[WireFake new],0,YES);
 }
 return 0;
}
