package main

/*
#cgo CFLAGS: -fobjc-arc
#cgo LDFLAGS: -framework Cocoa
void visibilityCommand(int operation);
int visibilityShutdown(void);
*/
import "C"

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"sync"
	"sync/atomic"
	"time"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/system/composer"
	"cogentcore.org/core/system/driver/desktop"
	"cogentcore.org/core/tree"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/drivers/cogent"
	"github.com/dshills/vellum/ui"
)

type nativeRecord struct {
	Kind                        string
	Operation                   int
	MainThread                  bool
	WindowNumber                int
	Visible, Ordered            bool
	Notifications               uint64
	Active                      bool
	Ordinal, Ordinary, Measured uint64
	WireError                   string `json:",omitempty"`
	Raw                         string `json:",omitempty"`
}

var records = make(chan nativeRecord, 64)
var callbackFault atomic.Bool
var privateCleanup atomic.Bool
var witnesses struct {
	sync.Mutex
	ordinal uint64
}
var observedDrawer atomic.Pointer[countingDrawer]

//export visibilityRecord
func visibilityRecord(raw *C.char) {
	var r nativeRecord
	text := ""
	if raw != nil {
		text = C.GoString(raw)
	}
	decodeErr := json.Unmarshal([]byte(text), &r)
	if raw == nil || len(text) > 4096 || decodeErr != nil {
		callbackFault.Store(true)
		if len(text) > 4096 {
			text = text[:4096]
		}
		r = nativeRecord{Kind: "wire-error", Raw: text, WireError: fmt.Sprint(decodeErr)}
		select {
		case records <- r:
		default:
		}
		return
	}
	witnesses.Lock()
	witnesses.ordinal++
	r.Ordinal = witnesses.ordinal
	if d := observedDrawer.Load(); d != nil {
		r.Ordinary = d.ordinary.Load()
		r.Measured = d.measured.Load()
	}
	witnesses.Unlock()
	select {
	case records <- r:
	default:
		callbackFault.Store(true)
	}
}

var outputMu sync.Mutex

func emit(kind string, v any) {
	outputMu.Lock()
	defer outputMu.Unlock()
	if err := json.NewEncoder(os.Stdout).Encode(struct {
		Event string
		Value any
	}{kind, v}); err != nil {
		callbackFault.Store(true)
	}
}
func require(ok bool, message string) error {
	if !ok {
		return errors.New(message)
	}
	return nil
}

type countingDrawer struct {
	composer.Drawer
	ordinary, measured, redraw atomic.Uint64
	lastOrdinaryStart          atomic.Uint64
	signal                     chan struct{}
}

func (d *countingDrawer) notify() {
	select {
	case d.signal <- struct{}{}:
	default:
	}
}
func (d *countingDrawer) End() {
	witnesses.Lock()
	witnesses.ordinal++
	started := witnesses.ordinal
	witnesses.Unlock()
	d.Drawer.End()
	witnesses.Lock()
	d.lastOrdinaryStart.Store(started)
	d.ordinary.Add(1)
	witnesses.Unlock()
	d.notify()
}
func (d *countingDrawer) EndMeasured() composer.ComposeTiming {
	m, ok := d.Drawer.(interface{ EndMeasured() composer.ComposeTiming })
	if !ok {
		return composer.ComposeTiming{Failure: "diagnostic drawer missing measured delegate"}
	}
	r := m.EndMeasured()
	witnesses.Lock()
	d.measured.Add(1)
	witnesses.Unlock()
	d.notify()
	return r
}
func (d *countingDrawer) CanRedraw() bool {
	r, ok := d.Drawer.(interface{ CanRedraw() bool })
	return !ok || r.CanRedraw()
}
func (d *countingDrawer) Redraw() { d.Drawer.Redraw(); d.redraw.Add(1); d.notify() }

type probe struct {
	ready  chan struct{}
	once   sync.Once
	drawer *countingDrawer
	err    error
}

func (p *probe) Mount(parent tree.Node) core.Widget {
	f := core.NewFrame(parent)
	f.Scene.Body.OnShow(func(events.Event) {
		p.once.Do(func() {
			rw := f.Scene.RenderWindow()
			if rw == nil || rw.SystemWindow == nil {
				p.err = errors.New("no native window on show")
			} else if cd, ok := rw.SystemWindow.Composer().(*composer.ComposerDrawer); !ok {
				p.err = errors.New("no composer drawer")
			} else {
				p.drawer = &countingDrawer{Drawer: cd.Drawer, signal: make(chan struct{}, 1)}
				cd.Drawer = p.drawer
				observedDrawer.Store(p.drawer)
			}
			close(p.ready)
		})
	})
	return f
}
func (p *probe) Sync(core.Widget) error { return nil }
func owner(ctx context.Context, a *app.Application, fn func() error) error {
	done := make(chan error, 1)
	if err := a.PostWait(ctx, func() { done <- fn() }); err != nil {
		return err
	}
	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return ctx.Err()
	}
}

type nativeReader struct {
	number       int
	notification nativeRecord
	seen         uint64
}

func (r *nativeReader) take(ctx context.Context) (nativeRecord, error) {
	select {
	case n := <-records:
		emit("native", n)
		if callbackFault.Load() || !n.MainThread || n.Kind == "error" {
			return n, errors.New("native diagnostic refusal/callback fault")
		}
		if n.WindowNumber != 0 {
			if r.number == 0 {
				r.number = n.WindowNumber
			}
			if n.WindowNumber != r.number {
				return n, errors.New("native window identity changed")
			}
		}
		if n.Kind == "notification" {
			if n.Notifications != r.seen+1 {
				return n, errors.New("notification counter discontinuity")
			}
			r.seen = n.Notifications
			r.notification = n
		}
		return n, nil
	case <-ctx.Done():
		return nativeRecord{}, ctx.Err()
	}
}
func (r *nativeReader) command(ctx context.Context, op int) (nativeRecord, error) {
	C.visibilityCommand(C.int(op))
	for {
		n, e := r.take(ctx)
		if e != nil {
			return n, e
		}
		if n.Kind == "ack" {
			if n.Operation != op {
				return n, errors.New("wrong native ACK")
			}
			return n, nil
		}
	}
}
func (r *nativeReader) transition(ctx context.Context, op int, visible bool) (nativeRecord, error) {
	before := r.seen
	ack, e := r.command(ctx, op)
	if e != nil {
		return ack, e
	}
	for r.notification.Notifications <= before || r.notification.Visible != visible {
		if _, e = r.take(ctx); e != nil {
			return ack, e
		}
	}
	if r.notification.WindowNumber != r.number {
		return ack, errors.New("transition window mismatch")
	}
	notification := r.notification
	// Drain the main dispatch after the observed notification so all synchronous
	// production observers have returned before the Go FIFO inspection.
	if _, e = r.command(ctx, 3); e != nil {
		return ack, e
	}
	return notification, nil
}
func copied(ctx context.Context, s *cogent.DesktopSession, ref app.WindowRef, want bool, previous uint64) (cogent.DesktopWindowVisibility, error) {
	v, e := s.Visibility(ctx, ref)
	if e == nil {
		e = require(v.Known && v.Visible == want && v.Sequence > previous, "copied original-window visibility mismatch")
	}
	emit("visibility", v)
	return v, e
}
func waitOrdinary(ctx context.Context, d *countingDrawer, notification nativeRecord) error {
	for d.ordinary.Load() <= notification.Ordinary || d.lastOrdinaryStart.Load() <= notification.Ordinal {
		select {
		case <-d.signal:
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return nil
}
func runScenario(ctx context.Context, a *app.Application, s *cogent.DesktopSession, ref app.WindowRef, p *probe) (err error) {
	select {
	case <-p.ready:
	case <-ctx.Done():
		return ctx.Err()
	}
	if p.err != nil {
		return p.err
	}
	if p.drawer == nil {
		return errors.New("drawer not installed")
	}
	reader := &nativeReader{}
	attached := false
	defer func() {
		// Stop the private subscription while main remains alive even on failure.
		if attached {
			cleanup, cancel := context.WithTimeout(context.WithoutCancel(ctx), time.Second)
			defer cancel()
			_, e := reader.command(cleanup, 4)
			err = errors.Join(err, e)
		}
	}()
	attached = true
	first, e := reader.command(ctx, 0)
	if e != nil {
		return e
	}
	if !first.Visible {
		for !reader.notification.Visible {
			if _, e = reader.take(ctx); e != nil {
				return e
			}
		}
		if _, e = reader.command(ctx, 3); e != nil {
			return e
		}
	}
	v, e := copied(ctx, s, ref, true, 0)
	if e != nil {
		return e
	}
	if e = s.Frame(ctx, ref); e != nil {
		return fmt.Errorf("initial frame: %w", e)
	}
	snap, e := s.Snapshot(ctx, ref)
	if e != nil {
		return e
	}
	emit("baseline", snap)
	for _, phase := range []string{"clean", "popup"} {
		if phase == "popup" {
			var target cogent.DesktopElement
			for _, el := range snap.Elements {
				if el.DomainID == "selector" {
					target = el
					break
				}
			}
			if target.ID == "" || target.Bounds.Empty() {
				return errors.New("selector not found")
			}
			pt := target.Bounds.Min.Add(target.Bounds.Size().Div(2))
			for _, typ := range []events.Types{events.MouseDown, events.MouseUp} {
				if e = s.Input(ctx, ref, cogent.DesktopInput{Frame: snap.Frame, Target: target.ID, Type: typ, Button: events.Left, Position: pt}); e != nil {
					return e
				}
				// Each accepted input revokes the prior frame capability. Resolve
				// MouseUp from a newly completed frame and current target geometry.
				if typ == events.MouseDown {
					if e = s.Frame(ctx, ref); e != nil {
						return e
					}
					snap, e = s.Snapshot(ctx, ref)
					if e != nil {
						return e
					}
					target = cogent.DesktopElement{}
					for _, el := range snap.Elements {
						if el.DomainID == "selector" {
							target = el
							break
						}
					}
					if target.ID == "" || target.Bounds.Empty() {
						return errors.New("selector lost before MouseUp")
					}
					pt = target.Bounds.Min.Add(target.Bounds.Size().Div(2))
					emit("selector-down", snap)
				}
			}
			if e = s.Frame(ctx, ref); e != nil {
				return e
			}
			snap, e = s.Snapshot(ctx, ref)
			if e != nil {
				return e
			}
			if len(snap.Popups) != 1 {
				return errors.New("selector popup not open")
			}
			emit("popup-baseline", snap)
		}
		if _, e = reader.transition(ctx, 1, false); e != nil {
			return e
		}
		v, e = copied(ctx, s, ref, false, v.Sequence)
		if e != nil {
			return e
		}
		failed := s.Frame(ctx, ref)
		var composition *cogent.DesktopCompositionError
		if !errors.Is(failed, cogent.ErrDesktopFrameUnavailable) || !errors.As(failed, &composition) || !composition.Unavailable {
			return fmt.Errorf("hidden frame must yield typed terminal unavailable: %v", failed)
		}
		_, pending := s.Snapshot(ctx, ref)
		if !errors.Is(pending, cogent.ErrDesktopPending) {
			return fmt.Errorf("failed frame published capability: %v", pending)
		}
		before := p.drawer.ordinary.Load()
		measured := p.drawer.measured.Load()
		emit("hidden", map[string]any{"Phase": phase, "Failure": failed.Error(), "NoCapability": true, "OrdinaryBefore": before, "MeasuredBefore": measured, "Session": s.State()})
		shown, e := reader.transition(ctx, 2, true)
		if e != nil {
			return e
		}
		if e = waitOrdinary(ctx, p.drawer, shown); e != nil {
			return fmt.Errorf("ordinary %s redraw: %w", phase, e)
		}
		if p.drawer.measured.Load() != measured {
			return errors.New("unexpected measured composition before new request")
		}
		emit("ordinary", map[string]any{"Phase": phase, "Before": before, "After": p.drawer.ordinary.Load(), "Measured": measured, "NotificationOrdinal": shown.Ordinal, "AtNotification": shown.Ordinary, "LastOrdinaryStartOrdinal": p.drawer.lastOrdinaryStart.Load()})
		v, e = copied(ctx, s, ref, true, v.Sequence)
		if e != nil {
			return e
		}
		if e = s.Frame(ctx, ref); e != nil {
			return fmt.Errorf("new explicit frame after %s transition: %w", phase, e)
		}
		snap, e = s.Snapshot(ctx, ref)
		if e != nil {
			return e
		}
		if phase == "popup" && len(snap.Popups) != 1 {
			return errors.New("visibility dismissed selector popup")
		}
		emit("restored", map[string]any{"Phase": phase, "Snapshot": snap})
	}
	terminal, e := reader.command(ctx, 4)
	if e != nil {
		return e
	}
	attached = false
	if terminal.Active || terminal.WindowNumber != 0 {
		return errors.New("private observer not retired")
	}
	final, cancel := context.WithTimeout(context.WithoutCancel(ctx), time.Second)
	defer cancel()
	if e = owner(final, a, func() error { return a.CloseWindow(ref) }); e != nil {
		return e
	}
	_, e = s.Visibility(final, ref)
	if !errors.Is(e, cogent.ErrDesktopClosed) || ref.Context().Err() == nil {
		return errors.New("original-window inspection survived closure")
	}
	emit("closed", true)
	return nil
}
func main() {
	core.DebugSettings.DisableWindowGeometrySaver = true
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	a, e := app.New(app.Config{})
	if e != nil {
		panic(e)
	}
	defer a.Close()
	p := &probe{ready: make(chan struct{})}
	ref, e := a.OpenWindow(app.Window{ID: "visibility", Title: "Vellum visibility lifecycle 2aca9b6", Width: 600, Height: 400, View: func() ui.Node {
		return ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "label", Kind: ui.Label, Text: "Native window visibility recovery"}, {ID: "selector", Kind: ui.Selector, SelectedID: "a", Options: []ui.Option{{ID: "a", Label: "Alpha"}, {ID: "b", Label: "Beta"}}}, {ID: "probe", Kind: ui.Extension, Custom: p}}}
	}})
	if e != nil {
		panic(e)
	}
	privateRemove, e := desktop.TheApp.AddMainCleanup(func() { privateCleanup.Store(C.visibilityShutdown() == 1) })
	if e != nil {
		panic(e)
	}
	defer privateRemove()
	remove, e := cogent.ObserveNativeServiceCleanup()
	if e != nil {
		panic(e)
	}
	defer remove()
	s := cogent.NewDesktopSession()
	done := make(chan error, 1)
	go func() { done <- runScenario(ctx, a, s, ref, p); cancel() }()
	runErr := a.Run(ctx, cogent.Driver{DesktopSession: s})
	cancel()
	select {
	case e = <-done:
	case <-time.After(6 * time.Second):
		fmt.Fprintln(os.Stderr, "native visibility worker did not join")
		os.Exit(3)
	}
	if runErr != nil && !errors.Is(runErr, context.Canceled) {
		e = errors.Join(e, runErr)
	}
	state := s.State()
	cleanup, ok := cogent.NativeServiceCleanupObservation()
	if !state.Closed || state.Pending || state.LiveWindows != 0 || !ok || cleanup.AccessibilityWindows != 0 || cleanup.PendingCallbacks != 0 || !privateCleanup.Load() || callbackFault.Load() {
		e = errors.Join(e, errors.New("tracked lifecycle cleanup failed"))
	}
	result := "PASS_NATIVE_VISIBILITY"
	if e != nil {
		result = "FAILED_NATIVE_VISIBILITY"
	}
	var measured, ordinary, redraw uint64
	if p.drawer != nil {
		measured = p.drawer.measured.Load()
		ordinary = p.drawer.ordinary.Load()
		redraw = p.drawer.redraw.Load()
	}
	emit("result", map[string]any{"Result": result, "Error": fmt.Sprint(e), "Session": state, "Cleanup": cleanup, "PrivateCleanup": privateCleanup.Load(), "Measured": measured, "Ordinary": ordinary, "Redraw": redraw, "PhysicalInputVerified": false, "NativePixelsVerified": false})
	if e != nil {
		os.Exit(1)
	}
}
