"""Exact original private record helper, Foundation-only scalar wire proof."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
V=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('trusted_wire_guard',V.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
src=V/'wire-original.m';original=V.parent/'macos-native-visibility-2aca9b6/program/native.m';compiler=Path('/usr/bin/clang');output=V/'wire-original'
paths=[Path(__file__),src,original,compiler,Path(h.__file__),h.GUARD]
pins={str(p):h.sha(p)for p in paths};stable=lambda:all(h.sha(k)==v for k,v in pins.items())
def run(name,args):
 r=h.g.execute(['/usr/bin/sandbox-exec','-p',h.PROFILE,*args],V,V/name,lambda:False,stable,timeout=30,limit=1<<20)
 r['source_pins']=dict(pins);r['native_application_executed']=False
 (V/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
 assert r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors'],r
 return r
run('compile-wire-original',[str(compiler),'-fobjc-arc','-framework','Cocoa',str(src),'-o',str(output)])
pins[str(output)]=h.sha(output);run('run-wire-original',[str(output)])
values=[json.loads(s)for s in(V/'run-wire-original/stdout').read_bytes().splitlines()]
assert len(values)==2 and [type(r['Visible'])for r in values]==[int,int]and [r['Visible']for r in values]==[0,1]
assert all(type(r['Ordered'])is bool and type(r['MainThread'])is bool for r in values)
result={'result':'PROVEN_ORIGINAL_VISIBLE_IS_JSON_INTEGER','values':values,'native_application_executed':False,'NSApplication_or_NSWindow_constructed':False,'original_source_unchanged':stable()}
(V/'wire-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
