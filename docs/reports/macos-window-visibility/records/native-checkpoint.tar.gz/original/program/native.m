#import <Cocoa/Cocoa.h>
#include <stdlib.h>
extern void visibilityRecord(char *json);

// Private one-window diagnostic. No OS input, global preferences or foreign
// windows. All AppKit access and retirement stay on the native main thread.
@interface VisibilityCheck : NSObject
@property(weak) NSWindow *window;
@property NSInteger number;
@property NSUInteger notifications;
@end
static VisibilityCheck *check;
int visibilityShutdown(void) {
    if(!NSThread.isMainThread)return 0;
    if(check)[NSNotificationCenter.defaultCenter removeObserver:check];
    check.window=nil;check=nil;
    return 1;
}
static void record(NSString *kind,int operation,NSWindow *window,NSUInteger notifications,BOOL active) {
    NSDictionary *value=@{@"Kind":kind,@"Operation":@(operation),@"MainThread":@(NSThread.isMainThread),@"WindowNumber":@(window?window.windowNumber:0),@"Visible":@(window && (window.occlusionState&NSWindowOcclusionStateVisible)),@"Ordered":@(window.isVisible),@"Notifications":@(notifications),@"Active":@(active)};
    NSData *data=[NSJSONSerialization dataWithJSONObject:value options:0 error:nil];
    NSString *json=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    visibilityRecord((char *)json.UTF8String);
}
@implementation VisibilityCheck
-(void)changed:(NSNotification *)note {
    if(!NSThread.isMainThread || note.object!=self.window)return;
    self.notifications++;
    record(@"notification",0,self.window,self.notifications,YES);
}
@end
void visibilityCommand(int operation) {
    dispatch_async(dispatch_get_main_queue(),^{@autoreleasepool {
        if(operation==0) {
            if(check) {record(@"error",operation,nil,0,YES);return;}
            NSWindow *selected=nil;
            for(NSWindow *window in NSApp.windows) {
                if([window.title isEqualToString:@"Vellum visibility lifecycle 2aca9b6"]) {
                    if(selected){record(@"error",operation,nil,0,NO);return;}
                    selected=window;
                }
            }
            if(!selected){record(@"error",operation,nil,0,NO);return;}
            check=[VisibilityCheck new];check.window=selected;check.number=selected.windowNumber;
            [NSNotificationCenter.defaultCenter addObserver:check selector:@selector(changed:) name:NSWindowDidChangeOcclusionStateNotification object:selected];
        }
        if(operation==4) {
            NSUInteger count=check.notifications;
            visibilityShutdown();
            record(@"ack",operation,nil,count,NO);return;
        }
        NSWindow *window=check.window;
        if(!check || !window || window.windowNumber!=check.number || operation<0 || operation>3) {record(@"error",operation,nil,0,check!=nil);return;}
        if(operation==1)[window orderOut:nil];
        if(operation==2)[window orderFront:nil];
        record(@"ack",operation,window,check.notifications,YES);
    }});
}
