from audit import *
import tarfile,datetime
cert=read(Q/'internal-commit-review.json');scope=read(Q/'final-scope.json');proof=read(Q/'boundary.json')
assert cert['approved']and cert['commit_ready']and not cert['unresolved_findings']
assert cert['staged_diff_sha256']==scope['staged_diff_sha256']
record=T/'docs/reports/macos-window-visibility/records'
required_bindings=[Q/n for n in ['commit_checkpoint.py','audit.py','boundary.py','boundary.json','final-scope.json','internal-source-review.json','internal-checkpoint-review.json','internal-prism-disposition.json','review-scope.json','prism-staged.diff','prism.json','prism-command.json','prism.stdout','prism.stderr','prism-rules.json']]+[record/n for n in ['checkpoint.tar.gz','manifest.json','archive.json']]
assert all(str(p)in cert['inputs']for p in required_bindings)

assert all(sha(p)==h for p,h in cert['inputs'].items())
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD
assert not git(C,'status','--porcelain')and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
assert hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==scope['staged_diff_sha256']
assert sorted(git(T,'diff','--cached','--name-only').decode().splitlines())==scope['paths']
assert all(sha(T/n)==h for n,h in scope['files'].items())
s=source(T);assert all(s[n]==h for n,h in proof['compiled_source'].items())
old=read(Q.parent/'macos-text-modal-9854e5d/plan.json');p=prepared(T);assert p==prepared(C)==old['prepared']
sv=vector(Path(old['sdk']));assert sv==old['sdk_files']
for name in ['focused-v8','driver-final-v2','gallery-final-v2','vet-final-v2','build-final-v2']:
 r=read(Q/(name+'.json'));assert passing(r)
 for n,h in proof['compiled_source'].items():assert r['source_pins'][str(T/n)]==h,(name,n)
 # Preserve all compiler/controller/prepared/native-module bindings; source doc
 # additions after checks cannot change compilation and are reviewed separately.
 for f,h in r['source_pins'].items():
  if not str(f).startswith(str(T)+'/'):assert sha(f)==h,f
negative=read(Q/'negative-dirt-v2.json');assert negative['negative_control_passed']and negative['negative_assertions']==2
provider=read(Q/'prism.json');assert provider['coverage']['complete']and provider['coverage']['llmCalls']==1
disposition=read(Q/'internal-prism-disposition.json');assert disposition['approved']and not disposition['unresolved_findings']and all(sha(p)==h for p,h in disposition['inputs'].items())
assert disposition['retained_ids']==sorted(f['id']for f in provider['findings'])and disposition['discarded_ids']==sorted(f['finding']['id']for f in provider['discarded'])and not provider['suppressed']
assert not provider['coverage']['excluded']and not provider['coverage']['skipped']and not provider['coverage']['truncatedBytes']

record=T/'docs/reports/macos-window-visibility/records';manifest=read(record/'manifest.json');archive=record/'checkpoint.tar.gz';assert archive.stat().st_size<=8<<20
assert len(manifest)<=256 and sum(v['bytes']for v in manifest.values())<=32<<20
with tarfile.open(archive,'r:gz')as tar:
 entries=tar.getmembers();assert len(entries)==len(manifest)
 names=set()
 for item in entries:
  assert item.isreg()and item.name not in names and item.name in manifest and not item.name.startswith('/')and '..'not in Path(item.name).parts
  names.add(item.name);m=manifest[item.name];assert item.size==m['bytes']and item.size<=10<<20
  b=tar.extractfile(item).read();b.decode('utf8');assert hashlib.sha256(b).hexdigest()==m['sha256']
git(T,'diff','--cached','--check')
print(git(T,'commit','-m','Restore owner redraw after Mac visibility changes').decode())
commit=git(T,'rev-parse','HEAD').decode().strip();assert not git(T,'status','--porcelain')and source(T)==s
print(git(C,'merge','--ff-only',commit).decode())
assert not git(C,'status','--porcelain')and source(C)==s and git(C,'rev-parse','HEAD').decode().strip()==commit
z={'commit':commit,'canonical_clean':True,'candidate_clean':True,'source_files':len(s),'source_sha256':digest(s),'Go_files':len(proof['all_Go']),'prepared_files':len(p),'prepared_sha256':digest(p),'sdk_files':len(sv),'sdk_sha256':digest(sv),'native_executed':False,'goal_complete':False,'closed_full_mac_gates':[],'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(Q/'commit-result.json').write_text(json.dumps(z,indent=2)+'\n')
state=Q.parent/'vellum-resume-state.json';d=read(state);(Q/'previous-resume-state.json').write_bytes(state.read_bytes())
nextwork='Design and separately admit a fresh bounded actual native visibility lifecycle scenario: authoritative NSWindow notifications, ordinary hidden-to-visible redraw, terminal Frame behavior and owned closure. No old catalogue scope replay or inferred/timed readiness. Then complete remaining M2 catalogue, materially different M3/full matrix, M4 resource/endurance, human M5, stable SDK/rights M6 and M7 audit.'
d.update(canonical_head=commit,canonical_current_source=commit,candidate_head=commit,current_canonical_commit=commit,latest_checkpoint_commit=commit,status='WINDOW_VISIBILITY_OWNER_REDRAW_COMMITTED_NATIVE_PENDING',source_files=len(s),tracked_paths=len(s),staged_source_files=[],active_tool_sessions=[],active_case=None,active_process_group=None,active_artifacts=str(Q),current_checkpoint_native_executed=False,checkpoint=commit+': Mac occlusion observer/one owner redraw wake and public Visibility inspection; actual-source software race/vet/build/internal/onePrism reviewed; no native execution/full gate closure',next=nextwork,next_work=nextwork,next_action=nextwork,updated_utc=z['updated_utc'],last_goal_turn_classification='progress: implemented bounded native visibility lifecycle/owner redraw and independent session inspection; verified software/native notification ownership, reviewed and committed; actual native qualification pending',prism_invocations=1,prism_files=provider['coverage']['files'],prism_complete=True,prism_cli_exit_code=read(Q/'prism-command.json')['exit_code'],prism_retained_findings=len(provider['findings']),prism_discarded_findings=len(provider['discarded']))
d['window_visibility_checkpoint']={**z,'artifacts':str(Q),'report':str(T/'docs/reports/macos-window-visibility/README.md'),'native_execution_authorized':False};state.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(z))
