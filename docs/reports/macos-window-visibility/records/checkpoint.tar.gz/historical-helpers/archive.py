from audit import *
import io,tarfile
report=T/'docs/reports/macos-window-visibility';records=report/'records';records.mkdir(exist_ok=False)
required={'focused-v8','driver-final-v2','gallery-final-v2','vet-final-v2','build-final-v2','negative-dirt-v2'}
current=read(Q/'software-summary.json');prism=read(Q/'prism.json')
assert prism['coverage']['complete']and not prism['coverage']['excluded']and not prism['coverage']['skipped']and not prism['coverage']['truncatedBytes']and prism['coverage']['llmCalls']==1
scope=read(Q/'review-scope.json');members={};origins={}
disposition=read(Q/'internal-prism-disposition.json')
assert disposition['approved']and not disposition['unresolved_findings']and all(sha(p)==h for p,h in disposition['inputs'].items())
assert disposition['retained_ids']==sorted(f['id']for f in prism['findings'])and disposition['discarded_ids']==sorted(f['finding']['id']for f in prism['discarded'])and not prism['suppressed']

def add(name,data,origin):
 assert name not in members and len(data)<=10<<20
 data.decode('utf8');members[name]=data;origins[name]=origin
for p in sorted(Q.iterdir()):
 if not p.is_file()or p.name in ['native-gallery','internal-commit-review.json','archive-result.json','commit-result.json','final-scope.json','final-staged.diff']:continue
 if p.name.endswith('.json'):
  try:d=read(p)
  except ValueError:continue
  if isinstance(d,dict)and 'source_pins'in d and p.stem not in required:
   compact={k:v for k,v in d.items()if k!='source_pins'}
   compact.update(original_receipt_sha256=sha(p),original_receipt_path=str(p),source_pin_count=len(d['source_pins']),source_pin_digest=digest(d['source_pins']),archive_form='condensed historical receipt; complete original retained in local checkpoint workspace')
   add('historical/'+p.name,json.dumps(compact,indent=2).encode()+b'\n',{'path':str(p),'sha256':sha(p),'derived':True});continue
 add('controller/'+p.name,p.read_bytes(),{'path':str(p),'sha256':sha(p)})
for directory in sorted(Q.iterdir()):
 if not directory.is_dir()or directory.name in ['provider-source']:continue
 assert directory.name in ['focused-v'+str(i)for i in range(1,9)]+['driver-final','gallery-final','vet-final','build-final','negative-dirt','driver-final-v2','gallery-final-v2','vet-final-v2','build-final-v2','negative-dirt-v2'],directory
 for name in ['stdout','stderr','owned.json']:
  p=directory/name;assert p.is_file();add('checks/'+directory.name+'/'+name,p.read_bytes(),{'path':str(p),'sha256':sha(p)})
for name in scope['paths']:
 original=Q/'provider-source'/name
 assert original.is_file()and sha(original)==scope['files'][name]
 add('provider-source/'+name,original.read_bytes(),{'path':str(original),'sha256':sha(original)})
 p=T/name;add('source/'+name,p.read_bytes(),{'path':str(p),'sha256':sha(p)})
add('member-origins.json',json.dumps(origins,indent=2).encode()+b'\n',{'generated':True})
assert len(members)<=256 and sum(map(len,members.values()))<=32<<20
manifest={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in members.items()}
archive=records/'checkpoint.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9,format=tarfile.USTAR_FORMAT)as tar:
 for n,b in sorted(members.items()):
  item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(b))
assert archive.stat().st_size<=8<<20
with tarfile.open(archive,'r:gz')as tar:
 entries=tar.getmembers();assert len(entries)==len(members)
 for entry in entries:
  assert entry.isreg()and entry.name in members and entry.size==len(members[entry.name]);assert tar.extractfile(entry).read()==members[entry.name]
(records/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
z={'members':len(members),'expanded_bytes':sum(map(len,members.values())),'compressed_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'manifest_sha256':sha(records/'manifest.json'),'native_executed':False,'historical_full_receipts_external':True,'complete_current_receipts':sorted(required),'final_commit_certificate_external_to_snapshot':True}
(records/'archive.json').write_text(json.dumps(z,indent=2)+'\n');(Q/'archive-result.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps(z))
