# Drawable lifecycle follow-up at a328208

The reviewed text-gallery/font checkpoint is committed; full native text/modal acceptance is still failed and sealed at 35 inputs/19 independently validated observations. Its actual one-attempt Occluded result is not a diagnosis of earlier failures.

Inspect the exact retained native build/source provenance before making backend claims. The GLFW Cocoa source shows a missing application notification path: it updates its private occluded flag, while its refresh callback may never run on Aqua. Investigate a Vellum-owned Cocoa occlusion observer integrated into the existing exclusive attachment and lifetime. Keep bounded state per window, subscribe before the initial main-thread sample, revoke the callback before native teardown, and request one coalesced owner paint on a hidden-to-visible transition. No polling or retained failed frame capability.

Before implementation, settle how an optional public session observation/wait would expose a real visibility event without implying drawable readiness. Existing Frame remains first-attempt/terminal. A visibility event may justify a new application-requested frame; acquisition can still yield. Waiting must handle cancellation, last-window retirement, duplicate events, event-before-wait, rapid hide/show and stale generations with no lost wake or native references after close.

Required checks: deterministic bounded state/ownership tests, real Foundation notification fixture without constructing NSWindow where possible, actual adapter attachment close ordering, race/build checks, internal review, then a new exact bounded native lifecycle scenario only after admission. Never reset/replay a sealed catalogue case or use focus/shown/timers as drawable proof. A full catalogue run comes only after this architecture has evidence. No input sources, VoiceOver, clipboard or OS settings change.

This is an investigation and design direction, not an implemented or qualified capability. No additional runtime/native test/provider call occurred in this follow-up.
