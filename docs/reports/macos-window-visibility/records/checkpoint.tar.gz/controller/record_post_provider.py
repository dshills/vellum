from audit import *
scope=read(Q/'review-scope.json')
assert all(sha(Q/'provider-source'/n)==h for n,h in scope['files'].items())
changed=sorted(n for n,h in scope['files'].items()if sha(T/n)!=h)
expected=sorted(['docs/desktop-integration.md','drivers/cogent/accessibility.go','drivers/cogent/accessibility_darwin.go','drivers/cogent/window_visibility_test.go','specs/desktop-integration.md','docs/reports/macos-window-visibility/README.md'])
assert changed==expected,changed
z={'post_provider_paths':changed,'original_files':scope['files'],'current_files':{n:sha(T/n)for n in scope['paths']},'retained_ids':['b18183efbfc73f34'],'discarded_ids':['2e3f2b9547ff421b'],'provider_calls':1,'runtime_changes':['drivers/cogent/accessibility.go','drivers/cogent/accessibility_darwin.go'],'tests_changed':['drivers/cogent/window_visibility_test.go'],'native_executed':False,'disposition':'Documented/tested fail-closed sequence policy; constructor visibility publication invariant strengthened. No pre-fix native race reproduced.'}
(Q/'post-provider.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps({'post_provider_paths':changed,'provider_calls':1}))
