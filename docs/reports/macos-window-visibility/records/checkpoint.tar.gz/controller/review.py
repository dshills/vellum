from audit import *
import time
review=read(Q/'internal-checkpoint-review.json');scope=read(Q/'review-scope.json')
assert review['approved']and not review['unresolved_findings']and all(sha(p)==h for p,h in review['inputs'].items())
assert review['staged_diff_sha256']==scope['staged_diff_sha256']
assert scope['staged_diff_sha256']==hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()
assert not(Q/'prism.json').exists()
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','160000','--max-diff-bytes','160000','--rules',str(Q/'prism-rules.json'),'--format','json','--out',str(Q/'prism.json')]
start=time.monotonic();r=run_child(argv,cwd=T,timeout=180,capture_output=True,check=False)
(Q/'prism.stdout').write_bytes(r.stdout);(Q/'prism.stderr').write_bytes(r.stderr)
z={'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'staged_diff_sha256':scope['staged_diff_sha256'],'staged_diff_bytes':scope['bytes']};(Q/'prism-command.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps(z))
