from audit import *
old=read(Q.parent/'macos-text-modal-9854e5d/plan.json')
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD
assert not git(C,'status','--porcelain')
candidate=source(T);canonical=source(C)
p=prepared(T);assert p==prepared(C)==old['prepared']
sdk=Path(old['sdk']);v=vector(sdk);assert v==old['sdk_files']
compiled={n:h for n,h in candidate.items()if (n.endswith('.go')and not n.startswith('prototypes/'))or n in ['go.mod','go.sum']or n.endswith(('.wgsl','/go.mod','/go.sum'))or (n.startswith('drivers/cogent/')and len(Path(n).parts)==3 and Path(n).suffix in ['.m','.h','.c'])}
z={'base':HEAD,'canonical_clean':True,'candidate_source':candidate,'canonical_source':canonical,'changed_paths':sorted(n for n in candidate if candidate.get(n)!=canonical.get(n)),'compiled_source':compiled,'all_Go':{n:h for n,h in candidate.items()if n.endswith('.go')},'prepared_files':len(p),'prepared_sha256':digest(p),'sdk_files':len(v),'sdk_sha256':digest(v),'sdk_unchanged':True,'prepared_unchanged':True,'native_executed':False,'closed_full_mac_gates':[]}
(Q/'boundary.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps({k:z[k]for k in ['base','prepared_files','sdk_files','native_executed']}))
