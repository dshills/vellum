from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Q.parent/'macos-acquisition-diagnostics-4ce6ba4';HEAD='a328208e020203ea96bc21ef4ada80b25ae78020'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=300,capture_output=True,check=True).stdout
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def vector(root):
 out={}
 for p in root.rglob('*'):
  assert not p.is_symlink(),p
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 names=git(root,'ls-files','-z').decode().split('\0')[:-1]+git(root,'ls-files','--others','--exclude-standard','-z').decode().split('\0')[:-1]
 assert len(names)==len(set(names))and len(names)<20000
 return{n:sha(root/n)for n in sorted(names)}
def prepared(root):return{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
def overlay_matches(s,p,sdk):
 mapping=read(Q/'overlay.json')['Replace']
 for original,replacement in mapping.items():
  rel=Path(original).relative_to(sdk)
  if replacement=='':assert not(T/rel).exists()
  else:assert Path(replacement).read_bytes()==(T/rel).read_bytes(),rel
 for n,v in s.items():
  if n.endswith('.go')and not n.startswith('prototypes/'):
   q=sdk/n;assert sha(mapping.get(str(q),str(q)))==v,n
 for q in(T/'drivers/cogent').iterdir():
  if q.suffix in ['.m','.c','.h','.sum']:
   original=sdk/q.relative_to(T);assert sha(mapping.get(str(original),str(original)))==sha(q),q
 for n,v in p.items():
  q=sdk/'drivers/cogent/build'/n;assert sha(mapping.get(str(q),str(q)))==v,n
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
