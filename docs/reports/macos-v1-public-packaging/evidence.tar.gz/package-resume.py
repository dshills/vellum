from pathlib import Path
import os,sys,json,hashlib,importlib.util,tarfile,shutil,time,subprocess,copy
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent
D=X.parents[1]/'deliveries/macos-v1-public-candidates-20261027';D.mkdir(exist_ok=True)
W=Path('/private/tmp/vellum-v1-public-checks-20261027');W.mkdir(exist_ok=True)
OLD=X.parents[1]/'deliveries/macos-v1-distribution-audit-20261027'
sys.path.insert(0,str(R/'scripts'));from sdk_environment import child_environment
from child_process import run_child
import app_notices
s=importlib.util.spec_from_file_location('sdk_checker',R/'scripts/check-sdk.py');checker=importlib.util.module_from_spec(s);s.loader.exec_module(checker)
s=importlib.util.spec_from_file_location('sdk_release',R/'scripts/release-sdk.py');release=importlib.util.module_from_spec(s);s.loader.exec_module(release)
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
metadata=json.loads((R/'release/version.json').read_text());audit=json.loads((R/metadata['distribution_audit_record']).read_text());packet=json.loads((R/audit['decision_inputs']['packet']['path']).read_text());assert sha(R/audit['decision_inputs']['packet']['path'])==audit['decision_inputs']['packet']['sha256'];assert not audit['publication_authorized']
release.release_gates(R,metadata,True)
checks=[json.loads(line) for line in (X/'package.log').read_text().splitlines() if line.startswith('{')]
def run(name,args,cwd=R):
 start=time.monotonic()
 with (X/(name+'.stdout')).open('wb') as out,(X/(name+'.stderr')).open('wb') as err:p=run_child([str(a) for a in args],cwd=cwd,env=env,stdout=out,stderr=err,timeout=600,log_limit_bytes=16<<20)
 checks.append({'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)});print(json.dumps(checks[-1]),flush=True)
 if p.returncode:raise RuntimeError(name+': '+(X/(name+'.stderr')).read_text(errors='replace')[-2000:])
 return (X/(name+'.stdout')).read_text()
for line in (OLD/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(OLD/n)==h
assert sha(OLD/'PRE_SIGN_INPUTS.tar.gz')==audit['decision_inputs']['retained_pre_sign_inputs']['sha256']
inputs=W/'inputs'
if not inputs.exists():
 inputs=W/'inputs';inputs.mkdir();total=count=0
 with tarfile.open(OLD/'PRE_SIGN_INPUTS.tar.gz','r|gz') as tar:
  for m in tar:
   count+=1;total+=m.size;assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts and count<2048 and m.size<128<<20 and total<1<<30
   target=inputs/m.name;target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as f:shutil.copyfileobj(tar.extractfile(m),f)
   target.chmod(0o755 if m.name.endswith('/binary') else 0o644)
oldcheck=checker.verify_archive(OLD/packet['sdk_archive'],packet['sdk_sha256']);old=W/'audit-sdk/vellum-v1.0.0';lib=old/'drivers/cogent/build/libs-darwin';assert sha(lib/'arm64/libwgpu_native.a')==audit['native_archive_sha256']
archive=D/'vellum-v1.0.0-darwin-arm64-sdk.tar.gz'
text=(X/'sdk-public.stdout').read_text();result=json.loads(text[text.rfind('\n{')+1:]);assert sha(archive)==result['sha256']
verified=checker.verify_archive(archive,result['sha256']);sdk=checker.extract_verified(archive,W/'public-sdk',verified);m=verified['manifest'];assert not m['private_build'] and m['source']=={'commit':head,'clean':True} and m['release']['third_party_distribution_audit']=='approved'
a,b=oldcheck['manifest']['files'],m['files'];changed=[n for n in sorted(a.keys()&b.keys()) if a[n]!=b[n]];added=sorted(b.keys()-a.keys());removed=sorted(a.keys()-b.keys())
def doc(n):return n.endswith('.md') and not n.startswith(('drivers/cogent/build/','release/native-components/'))
allowed={'release/version.json','release/macos-v1-distribution-audit.json','THIRD_PARTY_INVENTORY.json'}
assert all(n in allowed or doc(n) for n in changed+added),(changed,added)
assert all(n=='PRIVATE_BUILD.txt' for n in removed),removed
oldinventory=json.loads((old/'THIRD_PARTY_INVENTORY.json').read_text());newinventory=json.loads((sdk/'THIRD_PARTY_INVENTORY.json').read_text());o=copy.deepcopy(oldinventory);n=copy.deepcopy(newinventory);o['native_gpu_candidate']['distribution_audit']=n['native_gpu_candidate']['distribution_audit'];assert o==n
comparisons={'product_source':packet['source_commit'],'public_packaging_source':head,'added':added,'removed':removed,'changed':changed,'product_and_native_asset_files_unchanged':True,'third_party_inventory_only_changed_field':'native_gpu_candidate.distribution_audit','native_archive_sha256':audit['native_archive_sha256']}
(X/'public-product-equivalence.json').write_text(json.dumps(comparisons,indent=2)+'\n')
run('sdk-independent-consumer',[sys.executable,'-B',R/'scripts/check-sdk.py','--archive',archive,'--sha256',result['sha256']])
apps=[];launch=W/'launch';launch.mkdir()
for app in packet['apps']:
 slug=app['id'];source=inputs/'apps'/slug;binary=source/'binary';assert sha(binary)==app['source_binary_sha256'];inv=source/'INVENTORY.json';assert sha(inv)==app['notice_inventory_sha256'];v=json.loads(inv.read_text());notice=source/'notices';notice.mkdir();shutil.copyfile(inv,notice/'INVENTORY.json')
 for name in v['files']:
  app_notices.notice_name(name);dest=notice/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(inputs/'shared-notices'/name,dest)
 app_notices.load(notice,app['source_binary_sha256']);bundle=W/(app['name']+'.app')
 args=[sys.executable,'-B',R/'scripts/package-app.py','--public','--binary',binary,'--output',bundle,'--name',app['name'],'--identifier',app['identifier'],'--version','1.0.0','--build-version','10','--notice-bundle',notice,'--sign-identity','-']
 if 'icon_input' in app:
  icon=inputs/app['icon_input']['file'];assert sha(icon)==app['icon_input']['sha256'];args+=['--icon',icon]
 produced=json.loads(run(slug+'-public',args));assert produced['private_build'] is False and produced['native_distribution_audit']=='approved'
 zipfile=D/app['archive'];run(slug+'-zip',['ditto','-c','-k','--norsrc','--noextattr','--keepParent',bundle,zipfile]);stage=W/(slug+'-exact');stage.mkdir();run(slug+'-extract',['ditto','-x','-k',zipfile,stage]);exact=stage/bundle.name;run(slug+'-signature',['codesign','--verify','--deep','--strict',exact])
 manifest=json.loads((exact/'Contents/Resources/APP_MANIFEST.json').read_text());assert not manifest['private_build'] and manifest['native_distribution_audit']=='approved' and not manifest['notarized'] and manifest['source_binary_sha256']==app['source_binary_sha256'];assert manifest['release_authorization']['source']=={'commit':head,'clean':True}
 assert sha(binary)==app['source_binary_sha256'];target=launch/bundle.name;run(slug+'-launch-copy',['ditto','--norsrc','--noextattr',exact,target]);run(slug+'-launch-signature',['codesign','--verify','--deep','--strict',target]);assert sha(target/'Contents/MacOS'/app['name'])==sha(exact/'Contents/MacOS'/app['name'])
 apps.append({'id':slug,'name':app['name'],'identifier':app['identifier'],'archive':zipfile.name,'archive_sha256':sha(zipfile),'source_binary_sha256':app['source_binary_sha256'],'packaged_binary_sha256':sha(exact/'Contents/MacOS'/app['name']),'notice_inventory_sha256':app['notice_inventory_sha256'],'notice_files':app['notice_files'],'manifest_sha256':sha(exact/'Contents/Resources/APP_MANIFEST.json'),'private_build':False,'native_distribution_audit':'approved','notarized':False,'launch_path':str(target),'runtime_result':'not-yet-run'})
 (X/'apps-progress.json').write_text(json.dumps(apps,indent=2)+'\n')
assert git('rev-parse','HEAD')==head and not git('status','--porcelain');assert json.loads((R/'release/version.json').read_text())==metadata
out={'schema':1,'product_source':packet['source_commit'],'packaging_source':head,'audit_record_sha256':sha(R/'release/macos-v1-distribution-audit.json'),'sdk':{'archive':archive.name,'sha256':result['sha256'],'private_build':False,'source':m['source'],'verified_files':len(m['files'])},'apps':apps,'checks':checks,'publication_authorized':False,'uploaded':False,'notarized':False,'native_archive_sha256':audit['native_archive_sha256']}
(X/'package-result.json').write_text(json.dumps(out,indent=2)+'\n');(D/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');(D/'SHA256SUMS').write_text(result['sha256']+'  '+archive.name+'\n'+''.join(a['archive_sha256']+'  '+a['archive']+'\n' for a in apps));(X/'locations.json').write_text(json.dumps({'work':str(W),'delivery':str(D),'sdk':str(sdk),'launch':str(launch)},indent=2)+'\n');print(json.dumps({'complete':True,'delivery':str(D),'source':head,'apps':len(apps)}),flush=True)
