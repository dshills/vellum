from pathlib import Path
import json,hashlib,tarfile,io,gzip,shutil
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent
D=X.parents[1]/'deliveries/macos-v1-public-candidates-20261027';O=R/'docs/reports/macos-v1-public-packaging';O.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((X/'package-result.json').read_text());v=json.loads((X/'postlaunch-verification.json').read_text())
for name in ['package-result.json','postlaunch-verification.json','public-product-equivalence.json']:
 shutil.copyfile(X/name,O/name)
for name in ['SHA256SUMS','RECOMMENDED_SHA256SUMS']:
 shutil.copyfile(D/name,O/name)
files=sorted(f for f in X.iterdir() if f.is_file() and f.suffix in {'.py','.swift','.json','.log','.stdout','.stderr'})+sorted((X/'native').iterdir())
assert all(f.is_file() and f.suffix in {'.py','.swift','.json','.log','.stdout','.stderr','.jpg','.txt'} for f in files)
index=[{'path':str(f.relative_to(X)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
with (O/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for f in files:
    b=f.read_bytes();m=tarfile.TarInfo(str(f.relative_to(X)));m.size=len(b);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(b))
(O/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(O/'evidence.tar.gz'),'members':index},indent=2)+'\n')
rows='\n'.join('| '+a['name']+' | '+str(a['notice_files'])+' | '+('Held: dark contrast' if a['id']=='shell' else 'Pass')+' | `'+a['archive_sha256']+'` |' for a in p['apps'])
(O/'README.md').write_text('''# Final local macOS v1 public packaging and launch checks

The owner's 27 October 2026 exact-payload audit approval is recorded in
[the release-specific decision](../../../release/macos-v1-distribution-audit.json).
Final public-mode production succeeded for the SDK and all six audited apps.
**The SDK and five apps are recommended for a separate publication decision.
Mac Shell is held for a dark-appearance contrast defect. Nothing was uploaded.**
Features, APIs, backend, rendering/pacing defaults and the release gate are unchanged.
No signing identity, notarization, global setting or user notebook change was made.

## Artifact identities and disposition

Frozen product source/tag: `4b42fb89948b8abf0f2f65970fb5980987c1af0c` / `v1.0.0`.
Packaging/approval source: `1fc594b6952d3b072a4c72b619a6f259da389474`, clean.
That later commit changes approval/docs only. The source tag is unchanged.
Final SDK SHA256: `'''+p['sdk']['sha256']+'''`.

| App | Original notice files | Render/close outcome | Final ZIP SHA256 |
| --- | ---: | --- | --- |
'''+rows+'''

[All produced archive hashes](SHA256SUMS) include the held fixture for traceability.
[Recommended archive hashes](RECOMMENDED_SHA256SUMS) exclude Mac Shell.
[Production record](package-result.json) retains pre-launch status; the separate
[post-launch record](postlaunch-verification.json) records final observed outcomes.
The delivery manifest outside Git also has those outcomes. Signed executable
hashes differ from the audit's pre-sign hashes; both are retained and checked.

SDK/app archives and a short delivery README are retained outside Git at the
research workspace's `deliveries/macos-v1-public-candidates-20261027/`.
ZIP/tar archives are the durable handoff; launch copies under `/private/tmp/`
are disposable and must not be substituted for the recorded archive bytes.

## Focused automated evidence

The unchanged public SDK/app guards accepted the approved audit, clean committed
source, verified dependency/native payload and exact executable-bound notices.
The final production record contains 38 successful command steps: SDK export,
independent SDK consumer, and six app production/ZIP/extraction/signature/copy
sequences. All seven archive hashes were rechecked after native checks.

The public SDK verifies all 8,856 listed files. Its independent relocated
consumer passes race/vet/build and public API scenarios with replacements inside
the extracted SDK. Native runtime is deliberately not executed by that SDK check.
[Product equivalence](public-product-equivalence.json) compares the public SDK to
the approved private audit candidate: only approval/release/source documentation,
public markers and the inventory's native-audit field differ. Code, dependencies,
prepared native files and assets match. The native archive remains `786aaad8…`.

All six ZIP extractions and launch copies pass strict deep ad-hoc signature
validation. After closing, all six signatures, signed executable hashes,
manifest hashes and original notice inventories pass again; all six exact launch
process paths are absent. Exact notice hashes still match the approved packet,
including the added Go-font family notice in the three showcases. Public manifests
carry `private_build=false` and `native_distribution_audit=approved`.

Notice-discovery labels `pending`/`review-required` and sealed producer
`target_runtime=unverified` remain unchanged. They are collection-time declarations,
not rewritten to assert human review or runtime results. The separate owner audit
and this observed runtime record supply those distinct decisions/evidence.
Existing [exact-product-source CI](../macos-v1-distribution/reused-ci.json) is reused;
no new broad campaign or claim of CI on the later local packaging commit is made.

## Native observations

These are bounded local launch/render/native-close observations on this Apple
Silicon macOS host, using the exact ZIP-extracted signed bytes. They do not assert
full physical-input, performance, accessibility or download/Gatekeeper acceptance.

- Notes: native toolbar, sample list and proportional prose rendered; native close
  retired the process. A fixed, digest-checked, app-restricted launcher used a new
  disposable data directory. The personal notebook was not opened or changed.
- Mac Widgets: catalogue/theme controls and native toolbar rendered readably in
  the observed dark appearance; native close retired the process. No appearance
  switch or fresh full catalogue interaction pass is claimed.
- Forma: poster GPU surface, three layers and inspector rendered; native close
  retired the process.
- Luma: landscape, six-image filmstrip and histogram rendered; native close
  retired the process.
- Pulse: metrics/chart, selected service row and inspector rendered readably in
  dark appearance; native close retired the process.
- Mac Shell: both independent native windows and toolbar labels appeared, and
  closing both retired the process. Body labels were nearly black against the
  dark native background. **Visual acceptance failed; hold this app ZIP.**
  [Reproduction and smallest next action](SHELL_CONTRAST_ISSUE.md).

Raw AX trees and unedited screenshots are inside [evidence.tar.gz](evidence.tar.gz),
with [member hashes](evidence-index.json). They contain only generated fixtures,
local paths and checkpoint metadata. Native close success is observed process
retirement; no uncollected process exit code is reported as zero.

One computer-use inspection call for Widgets stalled for about 73 minutes before
returning. That is a tool inspection delay, not a measured app launch time or
framework responsiveness result. After it returned, the remaining checks completed.

## Controller corrections and remaining limits

Two local reporting-controller attempts stopped while parsing producer stdout:
dependency-patch progress before SDK JSON, and icon conversion output before app
JSON. Both actual producers had exited successfully. Already-produced archives
were verified/reused; parsing was corrected only in the disposable controller.
Original attempts/logs are preserved. A final reporting assertion initially compared
an annotated tag object to a commit; dereferencing `v1.0.0^{commit}` fixed the check.
No producer, signature, audit or dependency verifier was weakened.

The apps are ad-hoc signed and unnotarized, ARM64 only. No downloaded-quarantine
launch or other host/display qualification is claimed. Human IME and VoiceOver
remain explicitly unqualified. The owner's decision approves the identified
payload, not a new upstream license grant; the prior pinned objc2 caveat remains
in the audit packet. [The final publication packet](PUBLICATION_PACKET.md)
identifies exactly what can be proposed next. No tags, assets or release text were
published, and no Developer ID credential or Apple submission was used.
''')
(O/'SHELL_CONTRAST_ISSUE.md').write_text('''# Held fixture: Mac Shell dark-system contrast

The exact final `Vellum Mac Shell.zip` hash is in [SHA256SUMS](SHA256SUMS).
Both windows launch and close, but their body text is nearly black over a dark
native background. Both screenshots (`native/shell-a.jpg`, `native/shell-b.jpg`)
and AX trees are preserved in the evidence archive. Raising the B window did not
correct contrast. This fixture is excluded from RECOMMENDED_SHA256SUMS.

## Reproduction

On the observed dark-appearance desktop, extract the recorded ZIP, verify its
signature and open Vellum Mac Shell.app. Inspect both windows' title/status/
checkbox labels. Do not change a global appearance setting to reproduce it.
The existing example sets `cogent.Driver{Theme: ui.MacTheme(false)}` while both
`app.Window` values omit explicit native chrome appearance:
[fixture source](../../../examples/macapps/cmd/macshell/main.go).
That mismatch is the source-based explanation; a corrective build has not been tested.

## Smallest next action

Make an app-only fixture correction: explicitly select Light native appearance to
match its existing fixed light managed theme, or synchronize both through the
existing system-appearance path. Run a focused fixture check and Prism review,
commit, then rebuild/repackage only Mac Shell. Record its new pre-sign binary and
notice bindings as an audit delta before recommending the replacement ZIP. Reuse
all unchanged SDK/other-app verification. Do not relabel this current ZIP as fixed.

No runtime code change was made in the final-packaging task: the owner's exact
approved payload was preserved, and the fixture is held instead of silently
replacing its audited binary. This is a visible defect in that optional fixture,
not a new framework feature or a changed performance gate.
''')
(O/'PUBLICATION_PACKET.md').write_text('''# Final macOS v1 asset publication packet — unpublished

Local public-mode production is complete. Owner payload audit is approved;
**final asset publication is not yet authorized**. No upload, tag change, merge,
Developer ID signing or notarization is performed by this checkpoint.

## Proposed exact upload set

Use the six entries in [RECOMMENDED_SHA256SUMS](RECOMMENDED_SHA256SUMS): the SDK,
Vellum Notes, Vellum Mac Widgets, Forma, Luma and Pulse. The six filenames/digests
are the concrete proposed asset set. The complete seven-output inventory remains
in [SHA256SUMS](SHA256SUMS); **do not upload Vellum Mac Shell.zip** while its
[contrast issue](SHELL_CONTRAST_ISSUE.md) is held.

The durable files live in the research workspace's
`deliveries/macos-v1-public-candidates-20261027/`, not in Git or a temporary tree.
The SDK is frozen product source4b42fb8 plus packaging/approval metadata1fc594b;
apps reuse the audit's exact pre-sign binaries/notices/icons, then receive public
metadata and ad-hoc signatures. Do not claim that the unchanged v1.0.0 tag contains
the later approval/report commits or move that tag to manufacture that claim.

## Draft asset announcement

> Prepared macOS ARM64 developer downloads for the existing v1.0.0 source release:
> a relocatable SDK, Notes, the Mac Widgets catalogue, and Forma/Luma/Pulse showcase
> apps. Product code remains frozen at4b42fb8; public packaging/approval metadata
> comes from1fc594b. Verify the provided recommended SHA256 list before extraction.
> Apps are ad-hoc signed and unnotarized; a downloaded-quarantine launch has not
> been qualified. Notes is a local plain-text notebook; the showcases use offline
> fixture data. Human IME/VoiceOver and other hardware/macOS/display configurations
> remain unqualified. The optional Mac Shell fixture is withheld for dark contrast.

## Final owner decision and execution

Obtain approval identifying these exact six hashes, the disclosed ad-hoc/
unnotarized route, the README/release text and the destination (for example,
attaching to the existing v1.0.0 source release with a disclosed packaging revision).
Audit approval alone is not that upload decision. Only after that approval,
recheck the archive hashes, attach the selected files and recommended checksum
list, verify remote byte hashes and update current docs to the actual download
URLs. Do not upload private audit inputs, evidence archives or the held fixture.

The existing root source release/tag remains immutable. Native-module tags are
outside this packet. A separately authorized notarization route would produce
new asset hashes and require a new final packet; it is not a hidden prerequisite
for the currently disclosed developer-download option.
''')
(O/'REPRODUCE.md').write_text('''# Reproduce the packaging handoff

Use the unchanged public producers at packaging checkpoint1fc594b with the
[approved packet's retained exact pre-sign inputs](../macos-v1-distribution/REPRODUCE.md).
The public commands and frozen/native input hashes in that recipe remain valid;
the current exact-payload audit is now approved in release/version.json.

The evidence archive retains the actual production controllers, stdout/stderr,
SDK independent-consumer receipt, fixed-profile Notes launcher and final
postlaunch.py. These are historical local controllers with explicit host paths,
not an unattended publisher. Their command timeouts and their earlier parsing
failures are visible. No controller contains an upload command or credential.

1. Verify retained input archive SHA44ea387d… and reconstruct each app's exact
   inventory subset, not the union of all shared notices.
2. Use clean committed packaging source, fresh verified preparation, the approved
   native archive786aaad8…, and the pinned Go1.25.6 toolchain. Run public SDK/app
   producers without private flags. Preserve default backend/rendering policy.
3. Verify all SDK manifest files and independent consumer with the supplied SDK
   digest; verify every ZIP extraction and strict signature. Compare the SDK file
   delta to the approved private candidate before calling it the same product.
4. Launch only separate verified extraction copies. Use a new disposable Notes
   profile and preserve personal notebooks/settings. Observe native content and
   close, then verify process retirement, signatures and signed hashes again.
5. Record actual new archive hashes; do not expect ad-hoc signatures/manifests or
   public metadata to reproduce older private-candidate hashes. Hold failures.
   Reuse this checkpoint's unchanged results instead of repeating these steps
   without a concrete change or failure.

All produced and recommended checksums differ intentionally: the Mac Shell
fixture is retained for traceability but excluded from the proposed upload set.
The sealed producer runtime labels are not edited after native observations.
''')
# Delivery instructions are outside sealed archives and can describe final outcomes.
(D/'README.md').write_text('''# Vellum macOS v1 — local public candidates

Prepared from frozen product4b42fb8 and approval/packaging1fc594b. No files have
been uploaded. Use RECOMMENDED_SHA256SUMS for the SDK plus Notes, Mac Widgets,
Forma, Luma and Pulse. SHA256SUMS also records the held Mac Shell fixture.

Verify checksums before extracting. Extract app ZIPs with Finder/Archive Utility,
then open the app. Apps are ARM64, ad-hoc signed and unnotarized; downloaded
quarantine/Gatekeeper behavior was not qualified. No security bypass is part of
these instructions. Do not substitute temporary launch copies for these archives.

SDK: extract vellum-v1.0.0-darwin-arm64-sdk.tar.gz; use Go1.25.6 and Xcode command
line tools. See SDK_DOCUMENTATION.md in the extracted folder. The pinned native
capsule is already included; do not overwrite it with prepare.sh. Independent
SDK consumer race/vet/build passed. All8,856 listed files were verified.

Notes is a local plain-text notebook. Its public launch check used disposable
fixture data; normal launch uses your existing application notebook location.
Mac Widgets demonstrates controls/themes. Forma is a small poster/layers demo;
Luma displays procedural photographs/histograms; Pulse is a fictional service
metrics dashboard. Showcase data resets on launch. All five rendered and closed
successfully; full interactions were not repeated during this packaging pass.

Do not distribute Vellum Mac Shell.zip: both windows start/close but show poor
text contrast in the observed dark appearance. That fixture needs an app-only
appearance correction and new binary/notice binding before replacement.

Human IME/VoiceOver, other hardware/macOS/displays and downloaded-app behavior
remain unqualified. Features/backend/performance policy are unchanged. The final
source report is docs/reports/macos-v1-public-packaging/README.md in Vellum.
Final publication remains a separate owner decision for these exact files.
''')
# Current guides point at completed evidence, without rewriting historical packet identities.
f=R/'README.md';s=f.read_text();s=s.replace('final local public packaging and launch checks are the next checkpoint. No native binaries or prepared SDK assets accompany the source\nrelease. Private apps are ad-hoc signed and unnotarized.', '[final local packaging checks](docs/reports/macos-v1-public-packaging/README.md)\nproduced an SDK and five recommended app candidates. The optional Mac Shell fixture\nis held for dark-appearance contrast. No v1 native download has been uploaded.\nThe candidates are ad-hoc signed and unnotarized.')
s=s.replace('that exact payload and notice bundle. The v1.0.0 source tag is public; current native SDK/app bundles remain private.\nNew public native assets require the applicable audit, notice checks and publication\napproval.', 'that exact payload and notice bundle. The owner has also approved the exact\n[current v1 payload](release/macos-v1-distribution-audit.json). The v1.0.0 source\ntag is public; final public-mode SDK/app candidates remain local and unpublished.\nTheir [publication packet](docs/reports/macos-v1-public-packaging/PUBLICATION_PACKET.md)\nrecords matched notices, final checksums, a held fixture and the separate upload decision.')
f.write_text(s)
f=R/'docs/README.md';s=f.read_text().replace('- [Current macOS distribution packet](reports/macos-v1-distribution/README.md): pending delta audit, private candidate hashes and publication steps.','- [Current macOS public packaging](reports/macos-v1-public-packaging/README.md): approved audit, final local candidates, launch results and separate publication decision.\n- [Historical delta-audit packet](reports/macos-v1-distribution/README.md): exact private inputs bound by the current approval.') ;f.write_text(s)
f=R/'docs/macos-v1.md';s=f.read_text().replace('adds a public root tag and checkout source; current native SDK/app packages remain\nprivate with their original identities. No native binaries accompany that tag.', 'adds a public root tag and checkout source. Historical private packages retain\ntheir original identities. [Final public-mode candidates](reports/macos-v1-public-packaging/README.md)\nare now prepared locally; no v1 native downloads have been uploaded.')
s=s.replace('downloadable assets remain unpublished until a separate final-asset decision.', 'downloadable assets remain unpublished until a separate final-asset decision.\nThe [final packaging report](reports/macos-v1-public-packaging/README.md) records\na verified SDK plus five rendered/closed apps; the optional Mac Shell fixture\nis held for poor contrast in the observed dark appearance. Apps remain ad-hoc\nsigned and unnotarized; downloaded-quarantine behavior is unqualified.')
f.write_text(s)
f=R/'specs/release.md';s=f.read_text()+'''

### Final local public-candidate outcome

[Final public packaging](../docs/reports/macos-v1-public-packaging/README.md)
passes guarded SDK/app production, SDK independent consumption and exact-byte
extraction/signature/notice checks. Five app render/close observations pass; the
optional Mac Shell fixture is held for dark-system contrast. Preserve its audited
binary and failed visual evidence; do not include it in the recommended checksum
set or silently replace it with an unaudited fix. Sealed collection/runtime labels
retain their producer meanings; separate reports record owner approval and actual
observations. No full interaction/performance/human-accessibility campaign is
implied. Public upload still requires approval of the exact recommended assets,
destination and disclosed ad-hoc/unnotarized route. No source tag is moved.
''';f.write_text(s)
print(json.dumps({'report':str(O),'evidence_members':len(files),'evidence_bytes':(O/'evidence.tar.gz').stat().st_size}))
