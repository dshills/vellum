from pathlib import Path
import sys,json,hashlib,subprocess,datetime
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent
D=X.parents[1]/'deliveries/macos-v1-public-candidates-20261027';W=Path('/private/tmp/vellum-v1-public-checks-20261027')
sys.path.insert(0,str(R/'scripts'));import app_notices
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((X/'package-result.json').read_text());audit=json.loads((R/'release/macos-v1-distribution-audit.json').read_text())
assert sha(R/'release/macos-v1-distribution-audit.json')==p['audit_record_sha256']
assert subprocess.check_output(['git','rev-parse','v1.0.0^{commit}'],cwd=R,text=True).strip()==p['product_source']
assert not json.loads((R/'release/version.json').read_text())['macos_v1']['public_publication_authorized']
archives=[]
for line in (D/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(D/n)==h;archives.append({'file':n,'sha256':h,'verified':True})
ps=subprocess.check_output(['ps','-axo','pid=,comm=,args='],text=True)
matching=[line.strip() for line in ps.splitlines() if any(str(W/'launch'/(a['name']+'.app')/'Contents/MacOS'/a['name']) in line for a in p['apps'])]
assert not matching,'candidate process still alive: '+str(matching)
results=[]
for a in p['apps']:
 bundle=Path(a['launch_path']);manifest=bundle/'Contents/Resources/APP_MANIFEST.json';m=json.loads(manifest.read_text())
 assert sha(manifest)==a['manifest_sha256'];assert sha(bundle/'Contents/MacOS'/a['name'])==a['packaged_binary_sha256']
 assert m['private_build'] is False and m['notarized'] is False and m['native_distribution_audit']=='approved'
 assert m['source_binary_sha256']==a['source_binary_sha256'];assert m['release_authorization']['source']==p['sdk']['source']
 c=subprocess.run(['codesign','--verify','--deep','--strict',str(bundle)],capture_output=True,text=True,timeout=30)
 (X/(a['id']+'-postlaunch-signature.stdout')).write_text(c.stdout);(X/(a['id']+'-postlaunch-signature.stderr')).write_text(c.stderr);assert c.returncode==0
 record,_=app_notices.load(bundle/'Contents/Resources/THIRD_PARTY_NOTICES',a['source_binary_sha256'])
 assert record==m['component_notices'];assert record['inventory_sha256']==a['notice_inventory_sha256'];assert record['files']==a['notice_files']
 aa=next(aa for aa in audit['apps'] if aa['id']==a['id']);assert aa['source_binary_sha256']==a['source_binary_sha256'] and aa['notice_inventory_sha256']==record['inventory_sha256']
 shots=['shell-a','shell-b'] if a['id']=='shell' else [a['id']]
 evidence=[]
 for shot in shots:
  for ext in ['jpg','txt']:
   f=X/'native'/(shot+'.'+ext);assert f.is_file() and f.stat().st_size>100
   evidence.append({'file':'native/'+f.name,'sha256':sha(f),'bytes':f.stat().st_size})
 results.append({'id':a['id'],'name':a['name'],'launch':'observed','native_close':'observed','process_absent_after_closure':True,'strict_signature_after_closure':True,'signed_binary_unchanged':True,'manifest_unchanged':True,'binary_bound_original_notices_verified':True,'visual_result':'held-dark-contrast' if a['id']=='shell' else 'pass','recommended_for_publication':a['id']!='shell','evidence':evidence})
res={'schema':1,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'bounded local launch/render/native-close; not full pointer, performance, download/quarantine or human accessibility acceptance','product_source':p['product_source'],'packaging_source':p['packaging_source'],'all_candidate_processes_absent':True,'archives':archives,'apps':results,'notes_profile':'disposable fixture only; personal notebook not opened','runtime_manifests':'Producer target_runtime=unverified is preserved in sealed packages; this separate report records observed checks. Component notice discovery labels remain pending/review-required; exact-payload owner approval is recorded separately.','publication_authorized':False,'uploaded':False}
(X/'postlaunch-verification.json').write_text(json.dumps(res,indent=2)+'\n')
final=json.loads(json.dumps(p))
for a in final['apps']:
 r=next(r for r in results if r['id']==a['id']);a['runtime_result']=r['visual_result'];a['native_close']='observed';a['process_absent_after_closure']=True;a['recommended_for_publication']=r['recommended_for_publication']
(D/'manifest.json').write_text(json.dumps(final,indent=2)+'\n')
(D/'RECOMMENDED_SHA256SUMS').write_text(''.join(v['sha256']+'  '+v['file']+'\n' for v in archives if v['file']!='Vellum Mac Shell.zip'))
print(json.dumps({'archives_verified':len(archives),'strict_signed_app_rechecks':len(results),'visual_pass':5,'visual_hold':['shell'],'all_candidate_processes_absent':True}))
