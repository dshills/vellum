from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('app_owned_base',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
PYTHON=Path('/opt/homebrew/bin/python3').resolve()
origins=json.loads((W/'bundle-origins.json').read_text());BINARY=Path(origins['binary'])
files=[T/'release/version.json']+[T/'scripts'/n for n in ['app_notices.py','package-app.py','native_gpu.py','native_archive.py','artifact_io.py','child_process.py','sdk_environment.py']]+[Path(__file__),Path(h.__file__),Path(h.GUARD),PYTHON,BINARY,W/'bundle-origins.json',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]+[p for p in (W/'notice-bundle').rglob('*')if p.is_file()]
pins={str(p):h.sha(p)for p in files};assert h.sha(BINARY)==origins['record']['artifact_sha256']
env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'LANG':os.environ.get('LANG','en_US.UTF-8'),'PYTHONDONTWRITEBYTECODE':'1'}
args=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(PYTHON),'-B',str(T/'scripts/package-app.py'),'--binary',str(BINARY),'--output',str(W/'VellumNotices.app'),'--name','VellumNotices','--identifier','com.vellum.local.notices','--version','0.1.0','--build-version','1','--platform','darwin','--notice-bundle',str(W/'notice-bundle')]
def interrupt(signum,frame):raise InterruptedError('headless package signal '+str(signum))
previous=signal.signal(signal.SIGTERM,interrupt)
try:
 r=h.g.execute(args,T,W/'real-package-v1',lambda:(W/'stop-headless').exists(),lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=180,limit=2<<20);r['source_pins']=pins;r['native_ui_executed']=False;r['signing_requested']=False;(W/'real-package-v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']else 1)
finally:signal.signal(signal.SIGTERM,previous)
