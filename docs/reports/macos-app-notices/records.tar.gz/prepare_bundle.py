from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'))
from native_gpu import read_regular,strict_json
from app_notices import load,notice_name
OLD=W.parent/'macos-stdlib-inputs-d3d4eb8/owned-build-v2'
SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
GO=Path('/Users/dshills/Development/Go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64')
sha=lambda data:hashlib.sha256(data).hexdigest()
receipt_bytes=read_regular(OLD/'build-receipt.json',1<<20);receipt=strict_json(receipt_bytes)
inventory_bytes=read_regular(OLD/'inventory.json',8<<20);inventory=strict_json(inventory_bytes)
assert receipt['artifacts']['inventory.json']['sha256']==sha(inventory_bytes)
binary=OLD/'vellum-workbench';binary_bytes=read_regular(binary,128<<20);artifact=receipt['artifacts']['vellum-workbench']
assert len(binary_bytes)==artifact['bytes'] and sha(binary_bytes)==artifact['sha256']
assert inventory['build_configuration']['GOVERSION']=='go1.25.6'
sdk_raw=read_regular(SDK/'THIRD_PARTY_INVENTORY.json',8<<20);sdk=strict_json(sdk_raw);by_module={item['module']:item for item in sdk['modules']}
root=W/'notice-bundle';root.mkdir()
files={};components=[];origins=[]
def source_bytes(base,name,bound):
 path=base
 for part in Path(name).parts:
  assert part not in ['..','/'];path/=part;assert not path.is_symlink()
 return path,read_regular(path,bound)
def add(name,source,body,expected):
 notice_name(name);assert sha(body)==expected and name not in files
 path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
 files[name]={'bytes':len(body),'sha256':expected};origins.append({'name':name,'source':str(source),'bytes':len(body),'sha256':expected})
for i,module in enumerate(inventory['go_notices']['modules']):
 candidate=by_module[module['module']]
 assert (candidate.get('version'),candidate.get('sum'))==(module.get('version'),module.get('sum'))
 entries={entry['file']:entry for entry in candidate['license_files']};names=[]
 for j,entry in enumerate(module['license_files']):
  counterpart=entries[entry['file']];assert counterpart['sha256']==entry['sha256']
  source,body=source_bytes(SDK,'THIRD_PARTY_NOTICES/'+counterpart['notice'],4<<20);assert len(body)==entry['bytes']
  name=f'NOTICES/go-module-{i:03d}/{j:03d}-'+Path(entry['file']).name;add(name,source,body,entry['sha256']);names.append(name)
 if names:components.append({'id':'Go module:'+module['module']+'@'+str(module.get('version','local')),'notice_files':names})
standard=[]
for i,entry in enumerate(inventory['go_standard_library']['declaration_candidates']):
 source,body=source_bytes(GO,entry['file'],4<<20);assert len(body)==entry['bytes'];name=f'NOTICES/go-standard/{i:03d}-'+Path(entry['file']).name;add(name,source,body,entry['sha256']);standard.append(name)
components.append({'id':'Go 1.25.6:selected-package declaration candidates','notice_files':standard})
entry=next(entry for entry in inventory['framework_declarations']if entry['module']=='github.com/dshills/vellum');source,body=source_bytes(T,'LICENSE',4<<20);assert len(body)==entry['bytes'];name='NOTICES/vellum/LICENSE';add(name,source,body,entry['sha256']);components.append({'id':'Vellum:MIT declaration','notice_files':[name]})
value={'schema':1,'target':'darwin','artifact_sha256':artifact['sha256'],'distribution_audit':'pending','applicability':'review-required','scope':'Private packaging exercise: original full Go graph declarations matching retained SDK bytes, selected Go 1.25.6 ancestor declaration candidates and Vellum declaration. Conservative graph scope, not linked membership or applicable-license selection. The actual native archive is different from the SDK source-built archive, so that archive-specific bundle is deliberately excluded; native/font/generated/non-font/embedded attribution and rights completeness remain open.','files':files,'components':components}
(root/'INVENTORY.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
record,_=load(root,artifact['sha256'])
(W/'bundle-origins.json').write_text(json.dumps({'record':record,'origins':origins,'binary':str(binary),'build_receipt_sha256':sha(receipt_bytes),'build_inventory_sha256':sha(inventory_bytes),'sdk_go_inventory_sha256':sha(sdk_raw),'native_candidates':inventory['native_link_candidates'],'excluded_sdk_native_artifact':sdk['native_gpu_candidate']['artifact_sha256'],'rights_approved':False},indent=2)+'\n')
(W/'input-build-receipt.json').write_bytes(receipt_bytes)
print(json.dumps(record))
