from pathlib import Path
import datetime,hashlib,json,shutil,sys,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-app-notices'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((W/'internal-results-review.json').read_text())['approved']
closure=json.loads((W/'internal-prism-closure.json').read_text());assert closure['approved']
for name in ['prism.json','prism-disposition.json']:assert closure['inputs'][str(W/name)]==sha(W/name)
prism=json.loads((W/'prism.json').read_text());assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1
buckets={'retained_ids':[x['id']for x in prism['findings']],'discarded_ids':[x['finding']['id']for x in prism.get('discarded',[])],'suppressed_ids':[x['id']for x in prism.get('suppressed',[])]}
disposition=json.loads((W/'prism-disposition.json').read_text())
for key,ids in buckets.items():assert sorted(disposition[key])==sorted(ids)
r=json.loads((W/'real-package-v1.json').read_text());assert r['exit_code']==0 and r['pins_stable']and r['logs_complete']and r['error']is None and r['owned']['group_absent']and r['owned']['errors']==[]
for name in ['app_notices.py','app_notices_test.py','package-app.py','package-app_test.py']:assert (W/name).read_bytes()==(T/'scripts'/name).read_bytes()
shared=W/'shared';shared.mkdir();mapping={};binary=Path(json.loads((W/'bundle-origins.json').read_text())['binary'])
for i,(source,digest)in enumerate(sorted(r['source_pins'].items())):
 src=Path(source);assert sha(src)==digest
 if src.is_relative_to(W):mapping[source]={'stored':src.relative_to(W).as_posix(),'sha256':digest}
 elif src!=binary and src.suffix in ['.py','.json']:
  name=f'{i:03d}-'+src.name;shutil.copyfile(src,shared/name);mapping[source]={'stored':'shared/'+name,'bytes':src.stat().st_size,'sha256':digest}
 else:mapping[source]={'stored':None,'kind':'binary-or-tool-executable-identity-only','bytes':src.stat().st_size,'sha256':digest}
(shared/'sources.json').write_text(json.dumps(mapping,indent=2)+'\n')
diff=run_child(['git','diff','--cached','--binary'],cwd=T,capture_output=True,check=True,timeout=30).stdout;(W/'final-source-docs.diff').write_bytes(diff)
checks={'base':'56e1dc79b9497c6e4c85bdb2d6e5cdcbca40f937','production_change':'Binary-bound original notice payloads and executable/manifest validation in Mac app packaging','runtime_changed':False,'tests':36,'real_package':'real-package-v1','real_app_files':113,'real_app_bytes':60486868,'notice_files':109,'notice_components':86,'notice_bytes_including_inventory':346810,'prism_calls':1,'prism_cli_exit':json.loads((W/'prism-command.json').read_text())['exit_code'],'prism_buckets':buckets,'rights_approved':False,'native_ui_executed':False,'signing_requested':False,'closed_mac_gates':[],'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for leaf in sorted(W.rglob('*')):
 assert not leaf.is_symlink(),leaf
 if not leaf.is_file()or any(part in ['__pycache__','docs','VellumNotices.app']for part in leaf.relative_to(W).parts)or leaf.name.startswith('stop-')or leaf.name=='report-draft.md':continue
 assert leaf.stat().st_size<8<<20,(leaf,leaf.stat().st_size);name=leaf.relative_to(W).as_posix();files[name]={'bytes':leaf.stat().st_size,'sha256':sha(leaf)};sources[name]=leaf
assert len(files)<300 and sum(x['bytes']for x in files.values())<24<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<5<<20;record={'archive':archive.name,'archive_sha256':sha(archive),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
