"""Prepare a bounded retained-evidence checkpoint; never launch native applications."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile

X=Path(__file__).resolve().parent; A=X.parent; Q=A/'macos-m2-catalogue-1338b11'
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
C=Path('/Users/dshills/Development/projects/Vellum')
OUT=T/'docs/reports/macos-current-catalogue'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
encode=lambda v:(json.dumps(v,indent=2)+'\n').encode()

assert not OUT.exists()
review=read(Q/'internal-native-result-review.json')
assert review['approved'] and review['native_case_passed'] and not review['unresolved_findings']
assert all(sha(p)==v for p,v in review['inputs'].items())
audit=read(Q/'contract-audit.json')
assert audit['audit_status']=='COMPLETE_WITH_OPEN_M2_GAPS' and not audit['full_M2_closed']
assert audit['source_assertion_test_count']==205
assert all(sha(p)==v for p,v in audit['inputs'].items())
assert read(Q/'result.json')['result']=='PASS_CURRENT_FIVE_NATIVE_CATALOGUES'
base=read(Q/'gallery-v1.json')['source_pins']; keys=list(base); indices={k:i for i,k in enumerate(keys)}
files={'shared-input-base.json':encode(base)}; origins={}
prior=A/'macos-m2-audit-9013a73/package.py'
# Use exactly the existing lossless JSON input-map reconstructor, not the old packager.
import ast
tree=ast.parse(prior.read_text())
reconstructor=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='reconstructor' for t in n.targets))
ns={'__name__':'archive_reconstructor'};exec(reconstructor,ns);restore=ns['restore']
files['reconstruct.py']=reconstructor.encode()
def compact(value):
 if isinstance(value,dict):
  out={}
  for k,v in value.items():
   if k in ['inputs','pins','source_pins'] and isinstance(v,dict) and len(v)>100 and all(isinstance(a,str) and isinstance(b,str) and len(b)==64 for a,b in v.items()):
    name='input-maps/'+hashlib.sha256(encode(v)).hexdigest()+'.json'
    data=encode({'order':[indices.get(a,a) for a in v],'changes':{a:b for a,b in v.items() if base.get(a)!=b}})
    assert name not in files or files[name]==data
    files[name]=data;out[k]={'$input_map':name}
   else:out[k]=compact(v)
  return out
 if isinstance(value,list):return[compact(v) for v in value]
 return value
def add(p,key):
 p=Path(p);assert p.is_file() and not p.is_symlink() and key not in files
 raw=p.read_bytes();assert len(raw)<=8<<20;raw.decode('utf-8');data=raw;mode='verbatim'
 if p.suffix=='.json':
  value=json.loads(raw)
  if encode(value)==raw:
   data=encode(compact(value));assert encode(restore(json.loads(data),lambda n:files[n]))==raw
   mode='lossless-input-map-references'
 files[key]=data;origins[key]={'path':str(p),'original_bytes':len(raw),'original_sha256':sha(p),'stored_sha256':hashlib.sha256(data).hexdigest(),'mode':mode}
for name in ['design.md','check.py','checked.mod','checked.sum','consumer-proof.json','overlay.json','prepare_consumer.py','reuse_runtime.py','runtime-reuse.json','run.py','validate.py','validation_controls.py','validation-controls.json','internal-source-review.json','plan.json','admission.json','result.json','stop-live','internal-native-result-review.json','oracles.json','control_oracle.py','choice_oracle.py','navigation_oracle.py','media_oracle.py','structure_oracle.py','contract-audit.json','contract-audit.md']:
 add(Q/name,'catalogue/'+name)
for p in sorted((Q/'consumer').glob('*.go')):add(p,'catalogue/'+p.relative_to(Q).as_posix())
for case in ['control','choice','navigation','media','structure']:
 for name in ['result.json','stop-live','run/stdout','run/stderr','run/owned.json']:add(Q/case/name,'catalogue/'+case+'/'+name)
for check in ['gallery-v1','vet-v1','build-v1']:
 add(Q/(check+'.json'),'catalogue/'+check+'.json')
 for name in ['stdout','stderr','owned.json']:add(Q/check/name,'catalogue/'+check+'/'+name)
sources={v['source'] for v in audit['source_assertion_index'].values()}
for name in sorted(sources):
 p=Path(name)
 root=C if p.is_relative_to(C) else T
 assert p.is_relative_to(root)
 add(p,'assertion-source/'+p.relative_to(root).as_posix())
# Raw prior software logs already live in the preceding repository checkpoint.
# Keep their exact hash references and do not recursively duplicate those archives.
prior_refs={p:v for p,v in audit['inputs'].items() if not Path(p).is_relative_to(Q) and p not in sources}
files['prior-evidence-references.json']=encode({'inputs':prior_refs,'repository_report':'docs/reports/macos-current-workflows','source_snapshot':read(Q/'plan.json')['head'],'scope':'Hash references, not newly executed evidence; exact historical raw logs and reviews remain in their existing report archives.'})
add(T/'LICENSE','licenses/vellum-MIT.txt')
add(T/'drivers/cogent/build/upstream/LICENSE','licenses/core-BSD.txt')
add(Path(__file__),'checkpoint/prepare.py')
files['member-origins.json']=encode(origins)
assert len(files)<=256 and sum(map(len,files.values()))<=48<<20
manifest={k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(files.items())}
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
packed=gzip.compress(buf.getvalue(),mtime=0);assert len(packed)<=8<<20
OUT.mkdir();records=OUT/'records';records.mkdir()
(records/'checkpoint.tar.gz').write_bytes(packed);(records/'manifest.json').write_bytes(encode(manifest))
meta={'archive':'checkpoint.tar.gz','sha256':sha(records/'checkpoint.tar.gz'),'manifest_sha256':sha(records/'manifest.json'),'members':len(files),'expanded_bytes':sum(map(len,files.values())),'compressed_bytes':len(packed),'original_members_losslessly_verified':len(origins),'input_maps':len([k for k in files if k.startswith('input-maps/')]),'limits':{'members':256,'member_bytes':8<<20,'expanded_bytes':48<<20,'compressed_bytes':8<<20},'native_inputs':255,'native_states':169,'M2_closed':False,'open_methods':['tab-close Cocoa selectors','Breadcrumb Cocoa selectors','ColorPicker Cocoa selectors'],'runtime_changed':False,'SDK_changed':False,'closed_full_mac_gates':[]}
(records/'archive.json').write_bytes(encode(meta));(X/'archive-result.json').write_bytes(encode(meta))
(OUT/'README.md').write_bytes((X/'report-draft.md').read_bytes())
p=T/'specs/macos-delivery.md';s=p.read_text();anchor='## Finish line\n'
paragraph='''The [current catalogue and contract audit](../docs/reports/macos-current-catalogue/README.md)
qualifies all five current native records: 255 routed inputs and 169 observations.
The assertion audit covers 36 catalogue rows, 29 requirement groups and 205 exact
executed test functions. M2 remains open for three explicit dedicated Cocoa
methods: the eight-stage tab-close, twelve-stage Breadcrumb and eight-step
ColorPicker selector records. Their fixtures pass current builds/software checks
and internal source review, but have not run natively on this candidate. The
owner is online, so foreground testing is deferred. Reconcile the current source
baseline before preparing their exact launch plan. No old scope is replayed.
After M2, resume the materially different measured M3 rendering/publication work;
M4–M7, physical/human qualification and final SDK acceptance remain open.

'''
assert s.count(anchor)==1;s=s.replace(anchor,paragraph+anchor)
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| M2 | Partial; headless and native workspace records pass, native catalogue open |'):
  lines[i]='| M2 | Partial; current workspace, text and five catalogue records pass; three Cocoa methods open | [Current workflow](../docs/reports/macos-current-workflows/README.md) qualifies native workspace 432/54 and text 68/33. [Current catalogue/audit](../docs/reports/macos-current-catalogue/README.md) qualifies five records 255/169 and maps actual assertions for 205 executed tests. Dedicated tab-close, Breadcrumb and ColorPicker Cocoa-selector methods remain unqualified; renew and review those before M2 closure. Physical/human workflows remain M5. |'
p.write_text('\n'.join(lines)+'\n')
p=T/'specs/control-acceptance.md';s=p.read_text();anchor='## Remaining Mac acceptance\n';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''
The [current catalogue and assertion audit](../docs/reports/macos-current-catalogue/README.md)
renews all five native Go FIFO records on `1338b11`/stage87: 255 inputs and
169 observations, independently reviewed. The audit covers 36 rows, 29 requirement
groups and 205 exact executed test functions, with source assertion predicates
and raw PASS locations retained. Three explicit M2 methods remain open: attached
Cocoa-selector tab closing (eight stages), Breadcrumb (twelve stages) and
ColorPicker (eight steps, seven edits and one invalid proposal). The current
Go FIFO records do not replace those dedicated methods. Their existing fixtures
are built and source-reviewed, with no new native launch while the owner is
online. M2 remains partial; physical/human and M3–M7 requirements remain open.

The older entries below retain their original source/configuration and failure
identities. They are historical checkpoints, not outstanding copies of already
qualified current records.
''')
p.write_text(s)
print(json.dumps(meta))
