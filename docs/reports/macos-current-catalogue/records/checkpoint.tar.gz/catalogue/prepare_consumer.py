"""Preserve authored actions/oracles; add bounded copied visibility and private geometry isolation."""
from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;A=Q.parent;H=A/'macos-text-gutter-native-v1';J=A/'macos-m2-dock-document-9013a73';T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(Q/'overlay.json').exists();(Q/'consumer').mkdir()
originals=json.loads((H/'consumer-originals.json').read_bytes());proof={'private_only':True,'actions_and_domain_expectations_unchanged':True,'originals':{},'output_files':{},'metadata_changes':{}}
for name in ['control_catalogue.go','structure_catalogue.go','text_catalogue.go']:
 p=T/'drivers/cogent/cmd/gallery'/name;assert sha(p)==originals[name];shutil.copy2(H/'consumer'/name,Q/'consumer'/name);proof['originals'][name]=sha(p)
for name,typ in [('control_catalogue.go','catalogueReport'),('choice_catalogue.go','choiceReport'),('navigation_catalogue.go','navigationReport'),('media_catalogue.go','mediaReport')]:
 p=T/'drivers/cogent/cmd/gallery'/name;proof['originals'][name]=sha(p)
 data=(Q/'consumer'/name).read_text()if name=='control_catalogue.go'else p.read_text()
 before=data;start='type '+typ+' struct {\n';assert data.count(start)==1 and data.count('result.report.Session = s.State()')==1
 data=data.replace(start,start+'\tAvailability []catalogueAvailabilityObservation\n').replace('result.report.Session = s.State()','result.report.Availability = catalogueAvailabilitySnapshot()\n\tresult.report.Session = s.State()')
 (Q/'consumer'/name).write_text(data);proof['metadata_changes'][name]={'field':typ+'.Availability','copied_after_worker_join':True,'before_metadata_sha256':hashlib.sha256(before.encode()).hexdigest()}
shutil.copy2(J/'consumer/docking_geometry.go',Q/'consumer/geometry_isolated_vellum.go')
for name in ['checked.mod','checked.sum']:shutil.copy2(H/name,Q/name)
mapping={str(T/'drivers/cogent/cmd/gallery'/p.name):str(p)for p in sorted((Q/'consumer').glob('*.go'))}
assert len(mapping)==7 and not(T/'drivers/cogent/cmd/gallery/geometry_isolated_vellum.go').exists()
(Q/'overlay.json').write_text(json.dumps({'Replace':mapping},indent=2)+'\n')
for p in sorted((Q/'consumer').glob('*.go')):proof['output_files'][p.name]=sha(p)
proof['inputs']={str(p):sha(p)for p in [Path(__file__),H/'consumer-originals.json',*[H/'consumer'/n for n in ['control_catalogue.go','structure_catalogue.go','text_catalogue.go']],J/'consumer/docking_geometry.go',Q/'checked.mod',Q/'checked.sum']}
(Q/'consumer-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
paths={'control':A/'macos-control-popup-a1f92bb/validate_refocus.py','choice':A/'macos-choice-catalogue-500cf80/validate.py','navigation':A/'macos-navigation-catalogue-d9eb5ab/validate.py','media':A/'macos-media-catalogue-db98a6b/validate.py','structure':H/'structure_oracle.py'}
oracles={}
for kind,p in paths.items():
 name=kind+'_oracle.py';shutil.copy2(p,Q/name);oracles[name]={'original':str(p),'sha256':sha(p)}
(Q/'oracles.json').write_text(json.dumps(oracles,indent=2)+'\n');print(json.dumps({'private_Go_files':7,'copied_authored_oracles':5,'native_executed':False}))
