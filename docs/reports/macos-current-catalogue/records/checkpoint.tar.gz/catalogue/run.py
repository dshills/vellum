"""Five existing authored catalogue records on the current shared runtime, bounded and sealed."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD=json.loads((Q.parent/'macos-m2-audit-9013a73/commit-result.json').read_bytes())['commit'];SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
s=importlib.util.spec_from_file_location('trusted_catalogue_guard',Q.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g;sha=h.sha;need=h.need
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sys.path.insert(0,str(Q));import validate as validator
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'no vector symlink')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean committed stage87 candidate')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5521,'current tracked source count')
 return{n:sha(root/n)for n in sorted(names)}
def geometry_state():
 root=Path('/Users/dshills/Library/Cogent Core')
 need(all(not p.is_symlink()for p in [root,*root.parents]),'real Core data path, no symlink redirection')
 entries={}
 for name in ['window-geometry-0.3.6.json','window-geometry-0.3.6.lst','window-geometry-0.3.6.lck']:
  p=root/name
  need(not p.is_symlink(),'no geometry-file symlink redirection')
  if p.exists():
   need(p.is_file()and p.stat().st_size<=16<<20,'bounded regular existing geometry data');entries[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return {'directory_exists':root.exists(),'files':entries}
def baseline():
 a=source(C);need(source(T)==a,'whole C/T source identity')
 prepared=lambda root:{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
 p=prepared(C);need(prepared(T)==p and len(p)==6277 and digest(p)=='eea8467deea571109daf815ab16508385baeb5e117dc51910e436146a26a41bf','reviewed stage87')
 sdk=vector(SDK);need(len(sdk)==7880 and digest(sdk)=='4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26','whole SDK unchanged')
 mapping=read(Q/'overlay.json')['Replace']
 expected={str(T/'drivers/cogent/cmd/gallery'/p.name):str(p)for p in sorted((Q/'consumer').glob('*.go'))}
 proof=read(Q/'consumer-proof.json');need(len(mapping)==len(expected)==7 and mapping==expected and not(T/'drivers/cogent/cmd/gallery/geometry_isolated_vellum.go').exists(),'seven private Go consumer copies/addition only')
 need(all(sha(T/'drivers/cogent/cmd/gallery'/n)==v for n,v in proof['originals'].items())and all(sha(Q/'consumer'/n)==v for n,v in proof['output_files'].items())and all(sha(p)==v for p,v in proof['inputs'].items()),'unchanged original actions and exact private metadata/geometry guard bytes')
 return{'source':a,'prepared':p,'sdk':sdk,'unchanged_core_geometry':geometry_state()}
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def runtime_options():
 env={**g.child_environment(True),'GOMAXPROCS':'2'}
 return{k:env.get(k)for k in ['GOMAXPROCS','GOMEMLIMIT','GORACE']}
CASES=[{'id':k,'flag':'-'+k+'-native-check','inputs':i,'observations':o}for k,i,o in [('control',57,21),('choice',30,23),('navigation',47,41),('media',71,42),('structure',50,42)]]
def prepare():
 need(not(Q/'plan.json').exists()and not(Q/'stop-live').exists()and all(not(Q/c['id']).exists()for c in CASES),'fresh five-case catalogue scope')
 b=baseline();review=read(Q/'internal-source-review.json');need(review['approved']and review['source_controller_ready']and not review['unresolved_findings']and all(sha(p)==v for p,v in review['inputs'].items()),'exact source/controller review')
 reuse=read(Q/'runtime-reuse.json');need(reuse['qualified_reuse']and all(sha(p)==v for p,v in reuse['inputs'].items()),'exact runtime prerequisite reuse');pins=dict(reuse['inputs']);pins[str(Q/'runtime-reuse.json')]=sha(Q/'runtime-reuse.json')
 for name in ['gallery-v1','vet-v1','build-v1']:
  path=Q/(name+'.json');r=read(path);need(passing(r)and all(sha(p)==v for p,v in r['source_pins'].items()),'current private configuration prerequisite '+name);pins.update(r['source_pins']);pins[str(path)]=sha(path)
  for stream,info in r['logs'].items():
   p=Q/name/stream;need(p.stat().st_size==info['bytes']and sha(p)==info['sha256'],'complete prerequisite raw streams');pins[str(p)]=sha(p)
 controls=read(Q/'validation-controls.json');need(controls['synthetic_only']and not controls['native_executed']and len(controls['cases'])==110 and sum(c['expected_accept']for c in controls['cases'])==10 and all(c['expected_accept']==c['observed_accept']for c in controls['cases'])and all(sha(p)==v for p,v in controls['inputs'].items()),'110current synthetic controls only');pins.update(controls['inputs'])
 names=['run.py','check.py','design.md','consumer-proof.json','prepare_consumer.py','overlay.json','oracles.json','validate.py','validation_controls.py','validation-controls.json','reuse_runtime.py','internal-source-review.json']
 files=[Q/n for n in names]+[Q/(k+'_oracle.py')for k in ['control','choice','navigation','media','structure']]+[Path(h.__file__),h.GUARD,h.GO,h.PROV,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(p):sha(p)for p in files});binary=read(Q/'build-v1.json')['binary'];need(sha(binary['path'])==binary['sha256']and sha(h.GO)==h.GOSHA and sha(SDK/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')==h.LIBSHA,'exact native binary/compiler/archive')
 oldpaths=['macos-structure-catalogue-e9896d6','macos-acquisition-diagnostics-4ce6ba4','macos-text-modal-9854e5d','macos-native-visibility-2aca9b6','macos-native-visibility-corrected-2aca9b6','macos-catalogue-visibility-90fc432','macos-catalogue-focus-d1232b5','macos-text-publication-native-v1','macos-text-gutter-native-v1','macos-native-workspace-594bd37/native-v2','macos-native-workspace-594bd37/native-v4','macos-native-workspace-594bd37/native-v5','macos-native-workspace-9013a73','macos-m2-dock-document-9013a73','macos-control-multiclick-4d0b5f7','macos-choice-catalogue-500cf80','macos-navigation-embedded-d9eb5ab','macos-media-catalogue-db98a6b']
 seals={str(Q.parent/n/'stop-live'):sha(Q.parent/n/'stop-live')for n in oldpaths};need(len(seals)==18,'all eighteen named prior scopes retain their seals');pins.update(seals)
 now=datetime.datetime.now(datetime.timezone.utc);plan={'head':HEAD,'boundary':b,'pins':pins,'binary':binary,'runtime_options':runtime_options(),'old_seals':seals,'cases':CASES,'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':120,'stream_limit_bytes':4<<20,'scope':'Five existing control/choice/navigation/media/structure public gallery GoFIFO records, unchanged authored255inputs169states/oracles, current1338b11/stage87 Go1.25.6/Go2/SDK786a actual native units. Seven private Go files add bounded copied visibility metadata and proven normalsettings-load-before-disable geometry init only. Strict output/correlation wrapper110synthetic controls. Sharedlease/serialownedprocesses/fresh120s4MiB cases/firstfailure sealscampaign and skipsremaining/wholeC/T5521prepared6277SDK7880 and Coregeometrymetadata before-after/readonly sources+Coredata+SDK/IPdenied/tempownership. No H/I/J or oldsealed case replay, product/native/SDK/prepared/golden/OSprefs/source changes. No physical/human/IME/VoiceOver/realpanels/nativepixels/presentation/performance/resource/deallocation/fullMac or fullM2 closure from this record alone.'}
 (Q/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(Q/'plan.json'),'native_executed':False}))
def run():
 raw=(Q/'plan.json').read_bytes();araw=(Q/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(araw);stop=Q/'stop-live'
 need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact reviewed plan');need(not stop.exists()and not(Q/'result.json').exists()and all(not(Q/c['id']).exists()for c in p['cases']),'fresh five-case scope')
 def stable():return(Q/'plan.json').read_bytes()==raw and(Q/'admission.json').read_bytes()==araw and all(sha(k)==v for k,v in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():need(not stop.exists()and stable(),'stable/no stop');need(baseline()==p['boundary']and runtime_options()==p['runtime_options'],'whole current source/prepared/SDK/Coregeometry/runtime boundary')
 d={'result':'INCOMPLETE','native_executed':False,'cases':{},'error':None,'closed_full_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('five-case controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary()
   for case in p['cases']:
    kind=case['id'];root=Q/kind;need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline percase');boundary();root.mkdir();temporary=root/'tmp';temporary.mkdir();entry={'result':'INCOMPLETE','error':None};d['cases'][kind]=entry
    try:
     profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(q))+'))'for q in [C,T,SDK,Q/'consumer',Path('/Users/dshills/Library/Cogent Core')])
     need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline immediately before launch')
     r=g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','TMPDIR='+str(temporary),p['binary']['path'],case['flag']],T/'drivers/cogent',root/'run',lambda:stop.exists()or(root/'stop-live').exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);entry['run']=r;d['native_executed']|=r['created'];boundary();need(lease.held(),'lease through retirement');entry['post_boundary_pass']=True;need(passing(r),'owned native '+kind)
     need(temporary.is_dir()and not temporary.is_symlink()and not list(temporary.iterdir()),'owned temporary outputs removed');summary=validator.validate(kind,(root/'run/stdout').read_bytes(),(root/'run/stderr').read_bytes());need(summary['inputs']==case['inputs']and summary['observations']==case['observations'],'complete unchanged authored record');entry['summary']=summary;entry['result']='PASS_NATIVE_'+kind.upper()
    except BaseException as e:entry.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
    finally:(root/'stop-live').touch();(root/'result.json').write_text(json.dumps(entry,indent=2)+'\n')
   d['result']='PASS_CURRENT_FIVE_NATIVE_CATALOGUES'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(Q/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error']}));print(json.dumps({k:v.get('summary')for k,v in d['cases'].items()}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
