# M2 control-contract assertion audit

The five current catalogue records pass 255 inputs and 169 observations. **M2 remains open for three dedicated Cocoa-selector methods.** These methods have explicit contracts that the gallery's Go FIFO records do not replace.

| Requirement | Status | Remaining evidence |
| --- | --- | --- |
| Tab close | OPEN | Run the complete eight-stage attached Cocoa-selector sequence: selected/nonselected rejection, retained edited draft, accepted removals, absent/disabled refusal, final empty state and recreated identities. Historical `4c0df93`/6,214 prepared files does not establish current equivalence. |
| Breadcrumb | OPEN | Renew the twelve-stage attached Cocoa roles, hit tests, callbacks, refusal, identity and cleanup record. Historical `87e7de1`/6,216 files differs from current shared runtime. The native path-order-only fault remains nondiscriminating; the inert queued-path test separately detects that guard. |
| ColorPicker | OPEN | Renew the bounded selector campaign explicitly included in `color-picker.md`. Its historical eight-step, seven-valid/one-invalid record is distinct from current gallery six-edit/one-invalid Go FIFO evidence. |

Root is preparing distinct current selector qualifications. This audit authorizes no launch and resets no historical seal.

## Assertions checked

The JSON companion contains 36 catalogue rows, 29 requirement groups and 205 exact test functions. Every referenced function has an executed top-level PASS line, a current source hash and line number, and retained assertion predicates. The preceding 36-row/57-reference map established names and execution; this audit adds the actual conditions those tests check.

| Contract group | Scoped result | Actual assertions |
| --- | --- | --- |
| Controlled values and ownership | PASS | Typed payloads, accepted model restoration, latest callbacks, bounded queue refusal, originating-window restoration, disabled ancestors and retired callbacks. |
| Numeric and ordinary text | PASS | Finite bounds and clamping, retained draft/preedit, rejected commit restoration, native byte limits and FIFO-acknowledged focus handoff. |
| Text settlement | PASS | Earlier admitted keys/composition precede the callback; stale queued values retire; one shared pending slot, cancellation, retirement and unchanged repeated barriers remain bounded. |
| Editor model and adapter | PASS | Exact Unicode/CRLF bytes, directional selection, composition/history boundaries, stale clocks and mounts, copied-model refusal, atomic budget errors, persistence and native settlement. |
| Focus, tabs and modal lifetime | PASS | Stable ID/sequence focus, absolute queued tab intent, read-only and lifetime revocation, retained page identity, modal parking and exactly one dismissal. |
| Layout and themes | PASS | Precedence and explicit resets, detached themes, invalid-update atomicity, retained widget identity, restored defaults, Slider sizing and monospace body versus themed gutter. |
| Boolean, choice and passive controls | PASS | Controlled owner proposals, disabled skipping, exclusive stable-ID choices, rejected styling, passive semantics and no extra focus stops. |
| Toolbar, StatusBar and FormGroup | PASS | Measured overflow revelation, key priority and disabled skipping, passive accepted status, literal captions, retained drafts and style restoration. |
| SplitPane | PASS | Both orientations, bounded fractions, actual keys/drag and pane geometry, retained drafts, latest bounds and stale request refusal. |
| Icons and managed Image | PASS | All bundled symbols, retained artwork, passive roles, fit/clip/alpha pixels, immutable source retirement, bounded decoding and style resets. |
| Progress shapes | PASS | Fractions 0/.25/.75/1 at four software DPI settings, changed completed pixels, retained identity and no ongoing timer or future paint. |
| ListBox and MenuButton | PASS | Real scene routing, scrolling and paging, stable row/action identity, FIFO/latest delivery, popup retirement, checks/separators and inert Cocoa selectors. |
| Breadcrumb and ColorPicker software | PASS | Path identity/queued guards, namespaces, literal roles, four-DPI routing, current-color channel merging, bounded hex parsing and independent checker pixels. Attached selector requirements remain OPEN above. |
| Tab-close software | PASS | Controlled rejection/acceptance, pointer header focus, draft reparenting, queue refusal, private target geometry and stale/artwork/dialog capability retirement. Attached full sequence remains OPEN above. |
| Grid and tree workflow | PASS | Bounded measured rows/cells, stored-data routing, selection, scrolling, stale pooled targets, inline edit/history, asynchronous disclosure and surviving window state. |
| Canvas2D and placement workflow | PASS | Completed paint-order semantics, exact object selection, transformed placement, one commit, cancellation, scroll clipping and preview retirement. |
| Full professional record | PASS | Six frozen software records at 10k/1M rows and owner batches 1/7/64 compare all 1,296 operations and 162 captures with unchanged expected data and image hashes. |

A PASS applies to the functional assertions stated here. It does not imply every native, physical, performance or resource method in a linked specification has passed.

## Evidence and scope

Original G driver/gallery/workspace receipts pass in 295.116/35.254/195.083 seconds. Effective compiled and prepared bytes were rechecked using the seven byte-identical promotions. M portable root race passes in 25.228 seconds. The `9013a73` to `1338b11` difference contains six documentation/archive paths only. All named software assertions have exact raw PASS locations in the companion JSON.

H qualifies the full text/editor/modal 68/33 record. I qualifies both complete native workspace records, 432 operations and 54 captures. Q qualifies the five current catalogues; its separate independent review reconstructs all 169 expected models and checks actual packets, focus, geometry, semantics and frame correlation. H's 51, I's 54 and K's 44 review bindings remain current.

K accepts retained native docking/document source assertions plus independent saved-layout/output checks. J's original controller remains failed. The source-derived footer correction is 1,000 component nodes plus project and group, totaling 1,002; no native rerun occurred. The chooser is injected, so real file panels remain unverified.

## Gates preserved

Managed Image scene painting does not qualify MeshCanvas's 4096-square GPU image, filter pixels or changed-tile uploads. Canvas2D rectangles and placement do not qualify P4 drawing, 3D, compute, HDR or asynchronous readback. Those original P4/M3/M4/M6 requirements remain unchanged.

Physical and human input, live IME, VoiceOver, external AX, real panels, platform services and hardware display transitions remain M5 work. Original frame/input/resize budgets, allocations, native/GPU retention, lifecycle/overnight/idle/presentation requirements, final SDK/rights/distribution and final M7 audit stay open. The inactive TUINS window remains unclassified; process and session retirement do not prove native deallocation.

This audit reran no test, build, native application or provider. Only the audit Markdown and JSON were written. The JSON binds 241 source/evidence files.
