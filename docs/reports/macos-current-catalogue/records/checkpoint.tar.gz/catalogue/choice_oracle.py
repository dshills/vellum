"""Independent literal choice expectations; software fixtures are not native evidence."""
import base64,json,math,re
def need(ok,why):
 if not ok:raise ValueError(why)
def encoded(s):return base64.urlsafe_b64encode(s.encode()).decode().rstrip('=')
def managed(s):return 'node:'+encoded(s)
def option(g,o):return 'option:'+encoded(g)+':'+encoded(o)
LABELS=['initial','editing-disabled','disabled-no-proposals','editing-reenabled','switch-pointer','switch-keyboard','toggle-pointer','toggle-keyboard','radio-pointer','radio-wrap-skips-disabled','radio-rejected','segments-pointer-shared-selection','segments-wrap-skips-disabled','segments-end','segments-no-duplicate','disabled-option-refused','slider-keyboard-focus','slider-accepted','slider-rejected','slider-min-progress-zero','slider-max-progress-full','slider-boundary-once','ordinary-action-once']
KEYS=['Enabled','Snapping','Pinned','Selected','Number','EnableRequests','SnappingRequests','PinnedRequests','SelectionRequests','NumberRequests','OutsideClicks']
# Authored independently of the Go checker: enabled, switch, pin, selection, level, six counters.
VALUES=[
 (True,False,False,'basic',25,0,0,0,0,0,0),
 (False,False,False,'basic',25,1,0,0,0,0,0),
 (False,False,False,'basic',25,1,0,0,0,0,0),
 (True,False,False,'basic',25,2,0,0,0,0,0),
 (True,True,False,'basic',25,2,1,0,0,0,0),
 (True,False,False,'basic',25,2,2,0,0,0,0),
 (True,False,True,'basic',25,2,2,1,0,0,0),
 (True,False,False,'basic',25,2,2,2,0,0,0),
 (True,False,False,'advanced',25,2,2,2,1,0,0),
 (True,False,False,'basic',25,2,2,2,2,0,0),
 (True,False,False,'basic',25,2,2,2,3,0,0),
 (True,False,False,'advanced',25,2,2,2,4,0,0),
 (True,False,False,'basic',25,2,2,2,5,0,0),
 (True,False,False,'advanced',25,2,2,2,6,0,0),
 (True,False,False,'advanced',25,2,2,2,6,0,0),
 (True,False,False,'advanced',25,2,2,2,6,0,0),
 (True,False,False,'advanced',25,2,2,2,6,0,0),
 (True,False,False,'advanced',26,2,2,2,6,1,0),
 (True,False,False,'advanced',26,2,2,2,6,2,0),
 (True,False,False,'advanced',0,2,2,2,6,3,0),
 (True,False,False,'advanced',100,2,2,2,6,4,0),
 (True,False,False,'advanced',100,2,2,2,6,5,0),
 (True,False,False,'advanced',100,2,2,2,6,5,1)]
ROLES={'enable':'checkbox','snapping':'switch','pinned':'toggle-button','radio-preset':'radio-group','segmented-preset':'radio-group','slider':'slider','progress':'progress-bar','progress-ring':'progress-bar','progress-gauge':'progress-bar','choice-status':'status-bar','outside':'button','choice-icon':'image','choice-title':'label'}
PACKETS=[]
def key(label,id,code,reject=False):PACKETS.append((label,managed(id)if id else '', 'KeyChord',code,reject))
def click(label,id,opt=''):
 for typ in ['MouseDown','MouseUp']:PACKETS.append((label+'/'+typ,option(id,opt)if opt else managed(id),typ,'Unknown',False))
key('disable-editing','enable','Spacebar');key('disabled-slider','slider','RightArrow',True)
PACKETS.append(('disabled-radio',option('radio-preset','advanced'),'MouseDown','RightArrow',True))
key('disabled-ordinary-up','','UpArrow');click('reenable-editing','enable');click('switch-on','snapping');key('switch-off','snapping','Spacebar');click('pin-on','pinned');key('pin-off','pinned','Spacebar');click('radio-advanced','radio-preset','advanced');key('radio-wrap','radio-preset','RightArrow');key('radio-reject','radio-preset','RightArrow');click('segments-advanced','segmented-preset','advanced');key('segments-wrap','segmented-preset','RightArrow');key('segments-end','segmented-preset','End');key('segments-noop','segmented-preset','Spacebar')
PACKETS.append(('disabled-option',option('segmented-preset','unavailable'),'MouseDown','RightArrow',True))
key('tab-to-slider','segmented-preset','Tab');key('slider-increment','slider','RightArrow');key('slider-reject','slider','RightArrow');key('slider-min','slider','Home');key('slider-max','slider','End');key('slider-boundary','slider','RightArrow');key('tab-to-action','slider','Tab');key('acknowledge','outside','Spacebar')
need(len(PACKETS)==30 and len(VALUES)==len(LABELS)==23,'authored sizes')
def numeric(v):return type(v)in[int,float]and math.isfinite(v)
def point(p):return set(p)=={'X','Y'}and all(type(v)is int for v in p.values())
def inside(r,size):
 return point(r['Min'])and point(r['Max'])and 0<=r['Min']['X']<r['Max']['X']<=size['X']and 0<=r['Min']['Y']<r['Max']['Y']<=size['Y']
def contains(r,p):return point(p)and r['Min']['X']<=p['X']<r['Max']['X']and r['Min']['Y']<=p['Y']<r['Max']['Y']
def snapshot(s):
 need(type(s['Frame'])is int and s['Frame']>0 and point(s['Size'])and min(s['Size'].values())>0 and numeric(s['LogicalDPI'])and s['LogicalDPI']>0,'completed geometry')
 need(not s.get('Popups'),'unexpected popup')
 els={}
 for el in s['Elements']:
  need(type(el['ID'])is str and el['ID']not in els,'unique identity')
  need(all(type(el[k])is bool for k in ['Enabled','Focused','Selected']),'boolean semantics')
  els[el['ID']]=el
 for id,role in ROLES.items():
  el=els.get(managed(id));need(el and el['DomainID']==id and el['Role']==role and inside(el['Bounds'],s['Size']),'ordinary control '+id)
 for group in ['radio-preset','segmented-preset']:
  for opt in ['basic','advanced','unavailable']:
   el=els.get(option(group,opt));need(el and el['Parent']==managed(group)and el['DomainID']==opt and el['Role']=='option'and inside(el['Bounds'],s['Size']),'group-qualified choice')
 return els
def publication(s,w):
 els=snapshot(s);enabled,switch,pin,selected,number=w[:5]
 for id in ROLES:
  need(els[managed(id)]['Enabled']==(enabled if id in ['radio-preset','segmented-preset','slider']else True),'effective enabled '+id)
 for id,value in [('enable',enabled),('snapping',switch),('pinned',pin)]:
  v=els[managed(id)]['Value'];need(type(v)is bool and v==value,'controlled boolean '+id)
 for group in ['radio-preset','segmented-preset']:
  need(els[managed(group)]['Value']=={'basic':'Basic','advanced':'Advanced'}[selected],'controlled selection')
  for opt in ['basic','advanced','unavailable']:
   el=els[option(group,opt)];need(el['Selected']==(opt==selected)and type(el['Value'])is bool and el['Value']==(opt==selected)and el['Enabled']==(enabled and opt!='unavailable'),'option controlled publication')
 for id in ['slider','progress','progress-ring','progress-gauge']:
  value=els[managed(id)]['Value'];want=number if id=='slider'else number/100
  need(numeric(value)and abs(value-want)<=1e-7,'numeric/progress '+id)
 need(els[managed('choice-status')]['Value']==f'Preset {selected} / level {number:g}','controlled status')
 return els
def validate(raw,stderr=b''):
 need(len(raw)<=4<<20 and len(stderr)<=4<<20,'bounded streams');reports=[];warnings=0
 for line,out in[(x,True)for x in raw.decode().splitlines()]+[(x,False)for x in stderr.decode().splitlines()]:
  if out and line.startswith('{'):reports.append(line);continue
  need(bool(re.fullmatch(r'\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ERROR lines\.Lines font style MUST be Monospace\. Setting that but should fix upstream \| cogentcore\.org/core/text/lines\.\(\*Lines\)\.SetFontStyle .*/text/lines/api\.go:145',line)),'unexpected console output');warnings+=1;need(warnings<=64,'diagnostic bound')
 need(len(reports)==1,'one JSON result');d=json.loads(reports[0]);need(d['Event']=='vellum.choices-native.result'and d['Result']=='PASS_NATIVE_CHOICES'and d['Error']=='','successful result')
 need([x['Label']for x in d['Steps']]==LABELS and[x['Label']for x in d['Inputs']]==[x[0]for x in PACKETS],'complete authored sequence')
 last=0
 for step,w in zip(d['Steps'],VALUES):
  m=step['Model'];need(set(m)==set(KEYS)and all(type(m[k])is bool for k in KEYS[:3])and type(m['Selected'])is str and numeric(m['Number'])and all(type(m[k])is int and m[k]>=0 for k in KEYS[5:]),'model schema')
  need(m==dict(zip(KEYS,w)),'independent model/callbacks '+step['Label']);s=step['Snapshot'];publication(s,w);need(s['Frame']>last,'observation frame order');last=s['Frame']
 need(next(el for el in d['Steps'][16]['Snapshot']['Elements']if el['ID']==managed('slider'))['Focused'],'tab focus at slider')
 last=0
 for item,(label,target,typ,code,rejected)in zip(d['Inputs'],PACKETS):
  s=item['Before'];els=snapshot(s);inp=item['Input'];need(inp['Frame']==s['Frame']and s['Frame']>=last,'fresh ordered input frame');last=s['Frame']
  need(type(item['Rejected'])is bool and item['Rejected']==rejected,'exact refusal')
  need(inp['Target']==target and inp['Type']==typ and inp['Code']==code and inp['Modifiers']==''and inp['Rune']==(32 if code=='Spacebar'else 0)and inp['Delta']=={'X':0,'Y':0},'authored packet '+label)
  if not target:continue
  el=els.get(target);need(el is not None and el['Enabled']==(not rejected),'target eligibility')
  if typ=='KeyChord':
   if not rejected:need(el['Focused'],'actual keyboard focus')
   need(inp['Button']==('Left'if rejected else 'NoButton'),'key button')
  else:need(inp['Button']=='Left'and contains(el['Bounds'],inp['Position']),'actual pointer target')
 need(d['OriginalRefClosed']is True and d['PostCloseInputError']=='closed','original window closure/stale refusal')
 s=d['Session'];need(s['Started']is True and s['Closed']is True and s['Pending']is False and type(s['LiveWindows'])is int and s['LiveWindows']==0 and type(s['Issued'])is int and s['Issued']>=30,'terminal session')
 return {'result':'PASS_NATIVE_CHOICES','observations':23,'inputs':30,'callbacks':{'enable':2,'switch':2,'pin':2,'selection':6,'number':5,'ordinary_action':1},'known_font_diagnostics':warnings,'session':s,'physical_input_verified':False,'slider_drag_verified':False,'progress_pixels_verified':False}
