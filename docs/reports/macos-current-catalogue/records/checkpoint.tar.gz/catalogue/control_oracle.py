"""Independent authored control outcomes; synthetic controls are not native runs."""
import base64,json,math,re

def need(ok,why):
 if not ok:raise ValueError(why)

LABELS=['initial','pointer-menu-open','pointer-selection-once','keyboard-menu-open','rejected-selection-restored','actual-rejected-choice','escape-cancels','outside-release-consumed','outside-action-normal','keyboard-selection-once','typed-number-once','rejected-number-restored','step-after-rejection','invalid-number-no-proposal','number-correction','number-clamped','step-from-clamped','disabled-publication','disabled-no-proposals','reenabled-number','menu-before-close']
VALUES=[('basic',25,0,0,0,True),('basic',25,0,0,0,True),('advanced',25,1,0,0,True),('advanced',25,1,0,0,True),('advanced',25,2,0,0,True),('advanced',25,2,0,0,True),('advanced',25,2,0,0,True),('advanced',25,2,0,0,True),('advanced',25,2,0,1,True),('basic',25,3,0,1,True),('basic',42,3,1,1,True),('basic',42,3,2,1,True),('basic',43,3,3,1,True),('basic',43,3,3,1,True),('basic',55,3,4,1,True),('basic',100,3,5,1,True),('basic',99,3,6,1,True),('basic',99,3,6,1,False),('basic',99,3,6,1,False),('basic',100,3,7,1,True),('basic',100,3,7,1,True)]
MODEL_KEYS=['Selected','Number','SelectionRequests','NumberRequests','OutsideClicks','Enabled']
INPUTS=[]
def click(label):INPUTS.extend([label+'/MouseDown',label+'/MouseUp'])
def chord(label):INPUTS.append(label)
def text(label,value):INPUTS.extend([label+'/select-all',*[label+'/rune-'+str(i)for i in range(len(value))],label+'/enter']);click(label+'/refocus')
click('selector-open');click('choose-advanced')
for n in ['keyboard-open','menu-up','menu-reject-enter','reopen-rejected','escape-menu','open-outside-cancel']:chord(n)
click('outside-cancel');click('outside-normal')
for n in ['tab-to-selector','open-accept-keyboard','accept-menu-up','accept-menu-enter']:chord(n)
click('number-focus');text('number-42','42');chord('rejected-step');chord('accepted-step');text('invalid-number','bad');text('corrected-number','55');text('clamped-number','101');chord('step-down');chord('disabled-target-number');chord('disabled-target-selection');chord('disabled-ordinary-key');click('reenabled-number-focus');chord('reenabled-step');click('last-menu-open')
need(len(INPUTS)==57,'authored input count')

def managed(id):return'node:'+base64.urlsafe_b64encode(id.encode()).decode().rstrip('=')
def contains(rect,p):return rect['Min']['X']<=p['X']<rect['Max']['X']and rect['Min']['Y']<=p['Y']<rect['Max']['Y']
def rect_inside(rect,size):
 return 0<=rect['Min']['X']<rect['Max']['X']<=size['X']and 0<=rect['Min']['Y']<rect['Max']['Y']<=size['Y']
def snapshot(s):
 need(type(s['Frame'])is int and s['Frame']>0 and s['Size']['X']>0 and s['Size']['Y']>0 and math.isfinite(s['LogicalDPI'])and s['LogicalDPI']>0,'real completed geometry')
 for p in s.get('Popups')or[]:
  need(re.fullmatch('popup:'+str(s['Frame'])+r':\d+',p['ID'])and rect_inside(p['Bounds'],s['Size']),'popup frame/geometry')
  ids=set()
  for el in p.get('Items')or[]:
   need(el['Parent']==p['ID']and re.fullmatch(re.escape(p['ID'])+r':\d+',el['ID'])and el['ID']not in ids,'actual item incarnation')
   ids.add(el['ID'])
   if el['Enabled']:need(p['Interactive']and rect_inside(el['Bounds'],s['Size']),'eligible popup target')
 return[p for p in s.get('Popups')or[]if p['Kind']=='MenuStage']

def validate(raw,stderr=b''):
 need(len(raw)<=4<<20 and len(stderr)<=4<<20,'bounded result')
 reports=[];warnings=0
 for line,out in[(x,True)for x in raw.decode().splitlines()]+[(x,False)for x in stderr.decode().splitlines()]:
  if out and line.startswith('{'):reports.append(line);continue
  need(bool(re.fullmatch(r'\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ERROR lines\.Lines font style MUST be Monospace\. Setting that but should fix upstream \| cogentcore\.org/core/text/lines\.\(\*Lines\)\.SetFontStyle .*/text/lines/api\.go:145',line)),'unexpected console output')
  warnings+=1;need(warnings<=64,'known font diagnostic bound')
 need(len(reports)==1,'one JSON result')
 d=json.loads(reports[0]);need(d['Event']=='vellum.controls-native.result'and d['Result']=='PASS_NATIVE_CONTROLS'and not d['Error'],'successful control result')
 need([s['Label']for s in d['Steps']]==LABELS and[i['Label']for i in d['Inputs']]==INPUTS,'complete ordered authored scenario')
 last=0
 for i,(step,want)in enumerate(zip(d['Steps'],VALUES)):
  need(set(step['Model'])==set(MODEL_KEYS)and type(step['Model']['Enabled'])is bool and type(step['Model']['Selected'])is str and all(type(step['Model'][k])is int for k in ['SelectionRequests','NumberRequests','OutsideClicks'])and type(step['Model']['Number'])in[int,float]and math.isfinite(step['Model']['Number']),'model schema')
  need(step['Model']==dict(zip(MODEL_KEYS,want)),'independent model/callback counts '+step['Label'])
  s=step['Snapshot'];menus=snapshot(s);need(s['Frame']>last,'ordered observation frame');last=s['Frame']
  expected=1 if i in[1,3,5,20]else 0;need(len(menus)==expected,'actual menu lifecycle '+step['Label'])
  els={el['DomainID']:el for el in s['Elements']if el['DomainID']in['selection','number']}
  need(set(els)=={'selection','number'},'ordinary controls present')
  for id,el in els.items():need(el['ID']==managed(id)and el['Enabled']==want[-1]and rect_inside(el['Bounds'],s['Size']),'control publication')
  label={'basic':'Basic','advanced':'Advanced'}[want[0]]
  need(els['selection']['Value']==label and els['number']['Value']==want[1],'controlled semantics')
  if menus:
   p=menus[0];need(p['Interactive']and[x['Name']for x in p['Items']]==['Basic','Advanced'],'actual popup options, disabled omitted')
   need(all(x['Enabled']and x['Selected']==(x['Name']==label)for x in p['Items']),'actual controlled chooser projection')
 for item in d['Inputs']:
  before=item['Before'];menus=snapshot(before);inp=item['Input'];label=item['Label'];need(inp['Frame']==before['Frame'],'input capability frame')
  rejected=label in['disabled-target-number','disabled-target-selection'];need(item['Rejected']==rejected,'refusal receipt')
  typ='MouseDown'if label.endswith('/MouseDown')else'MouseUp'if label.endswith('/MouseUp')else'KeyChord';need(inp['Type']==typ,'authored packet type')
  no_target=label.startswith('outside-cancel/')or label=='disabled-ordinary-key'
  need(bool(inp['Target'])!=no_target,'qualified input target')
  if no_target:
   if typ.startswith('Mouse'):
    need(len(menus)==1 and not contains(menus[0]['Bounds'],inp['Position']),'outside cancel location')
   continue
  elements=before['Elements']+[el for p in before.get('Popups')or[]for el in p.get('Items')or[]]
  targets=[el for el in elements if el['ID']==inp['Target']];need(len(targets)==1,'fresh exact target')
  el=targets[0]
  if rejected:need(not el['Enabled'],'disabled refusal evidence');continue
  need(el['Enabled'],'eligible input')
  if typ=='KeyChord':need(el['Focused'],'actual focused keyboard target')
  else:need(contains(el['Bounds'],inp['Position']),'actual pointer bounds')
  if '/refocus/'in label:need(el['DomainID']=='number','authored numeric refocus target')
  if label.startswith('choose-advanced/'):need(el['Role']=='popup-item'and el['Name']=='Advanced'and inp['Target'].startswith('popup:'),'actual popup pointer, not semantic option')
 need(d['OriginalRefClosed']and d['PostCloseInputError']=='closed','original window retired and stale popup refused')
 s=d['Session'];need(s['Started']and s['Closed']and not s['Pending']and s['LiveWindows']==0 and s['Issued']>=57,'session terminal')
 return{'result':'PASS_NATIVE_CONTROLS','observations':21,'inputs':57,'selection_proposals':3,'numeric_proposals':7,'outside_actions':1,'known_font_diagnostics':warnings,'session':s,'physical_input_verified':False}
