"""Revalidate byte-identical full driver prerequisites; catalogue private copies checked separately."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;H=Q.parent/'macos-text-gutter-native-v1';M=Q.parent/'macos-m2-audit-9013a73';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert not(Q/'runtime-reuse.json').exists();r=read(H/'runtime-reuse.json');assert r['qualified_reuse']and r['compiled_and_prepared_paths']==7049 and all(sha(p)==v for p,v in r['inputs'].items())
assert(Q/'checked.mod').read_bytes()==(H/'checked.mod').read_bytes()and(Q/'checked.sum').read_bytes()==(H/'checked.sum').read_bytes()
for name in ['gallery-v1','vet-v1','build-v1']:
 d=read(Q/(name+'.json'));assert d['created']and d['exit_code']==0 and d['error']is None and not d['observation_errors']and d['logs_complete']and d['pins_stable']and not d['stop_at_exit']and d['owned']['terminal']and d['owned']['group_absent']and not d['owned']['errors']and all(sha(p)==v for p,v in d['source_pins'].items())
 for stream,info in d['logs'].items():
  p=Q/name/stream;assert sha(p)==info['sha256']and p.stat().st_size==info['bytes']
commit=read(M/'commit-result.json');assert commit['commit']=='1338b11022373c02ee3ab7940deff73bd9e02587'and not commit['runtime_changed']
paths=[Path(__file__),H/'runtime-reuse.json',M/'commit-result.json',Q/'checked.mod',Q/'checked.sum'];r['inputs'].update({str(p):sha(p)for p in paths});r['current_head']=commit['commit'];r['scope']+=' Current1338 checkpoint changed documentation/evidence only. Five already authored native records need current-runtime qualification and are not relabeled by this reuse proof. Fresh seven-private-Go-file catalogue configuration has full gallery race/vet/native build; only copied visibility metadata and geometry initialization differ. This proof launches no application.'
(Q/'runtime-reuse.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'qualified_reuse':True,'effective_paths':7049,'native_executed':False}))
