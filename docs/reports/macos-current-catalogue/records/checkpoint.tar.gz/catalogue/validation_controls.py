"""Synthetic discrimination for unchanged domain oracles plus current strict wrapper."""
from pathlib import Path
import copy,hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q));import validate as v
sources={'control':('macos-control-popup-a1f92bb/validation_refocus_controls.py','validate_refocus'),'choice':('macos-choice-catalogue-500cf80/validation_controls.py','validate'),'navigation':('macos-navigation-catalogue-d9eb5ab/validation_controls.py','validate'),'media':('macos-media-catalogue-db98a6b/validation_controls.py','validate'),'structure':('macos-acquisition-diagnostics-4ce6ba4/validation_controls.py','validate')}
def fixture(kind):
 path,alias=sources[kind];previous=sys.modules.get(alias);sys.modules[alias]=v.oracles[kind]
 try:m=v.module(kind+'_synthetic_controls',Q.parent/path)
 finally:
  if previous is None:sys.modules.pop(alias,None)
  else:sys.modules[alias]=previous
 d=m.fixture()
 def shift(obj):
  if type(obj)is dict:
   for k,x in obj.items():obj[k]=x*4+2 if k=='Frame'and type(x)is int else shift(x)
  elif type(obj)is list:return[shift(x)for x in obj]
  elif type(obj)is str and obj.startswith('popup:'):return re.sub(r'^popup:(\d+):',lambda m:'popup:'+str(int(m[1])*4+2)+':',obj)
  return obj
 d=shift(d);frames=sorted({s['Snapshot']['Frame']for s in d['Steps']}|{p['Before']['Frame']for p in d['Inputs']})
 d['Availability']=[dict(Index=i,Before=dict(Known=True,Visible=True,Sequence=1),BeforeIssued=f-1,FrameIssued=f,Outcome='completed',VisibilityError='',FrameError='')for i,f in enumerate(frames,1)]
 d['Session']['Issued']=frames[-1]+1
 return d
encode=lambda d:(json.dumps(d)+'\n').encode()
def main():
 assert not(Q/'validation-controls.json').exists();cases=[]
 def run(kind,name,d,expected,stdout=None,stderr=b''):
  error=None
  try:v.validate(kind,encode(d)if stdout is None else stdout,stderr);actual=True
  except(ValueError,TypeError,KeyError,UnicodeDecodeError,json.JSONDecodeError)as e:actual=False;error=str(e)
  assert actual==expected,(kind,name,actual,error);cases.append({'kind':kind,'name':name,'expected_accept':expected,'observed_accept':actual,'error':error})
 for kind in sources:
  good=fixture(kind);run(kind,'complete-positive',good,True)
  startup=copy.deepcopy(good);startup['Availability'].insert(0,dict(Index=1,Before=dict(Known=False,Visible=False,Sequence=0),BeforeIssued=0,FrameIssued=0,Outcome='refused',VisibilityError='closed',FrameError='closed'))
  for i,e in enumerate(startup['Availability'],1):e['Index']=i
  run(kind,'startup-refusal-positive',startup,True)
  changes={
   'missing-observation':lambda d:d['Steps'].pop(),
   'missing-input':lambda d:d['Inputs'].pop(),
   'wrong-model':lambda d:d['Steps'][-1]['Model'].__setitem__('unexpected',True),
   'pending-session':lambda d:d['Session'].__setitem__('Pending',True),
   'original-reference-live':lambda d:d.__setitem__('OriginalRefClosed',False),
   'missing-correlations':lambda d:d.__setitem__('Availability',[]),
   'over-budget-correlations':lambda d:d.__setitem__('Availability',d['Availability']*1025),
   'missing-frame-origin':lambda d:d['Availability'].pop(),
   'unknown-visibility':lambda d:d['Availability'][0]['Before'].__setitem__('Known',False),
   'failed-frame':lambda d:d['Availability'][0].__setitem__('Outcome','failed'),
   'unavailable-frame':lambda d:d['Availability'][0].__setitem__('Outcome','unavailable'),
   'hidden-error':lambda d:d['Availability'][0].__setitem__('FrameError','error'),
   'reused-request-tag':lambda d:d['Availability'][0].__setitem__('FrameIssued',d['Availability'][0]['BeforeIssued']),
   'wrong-correlation-index':lambda d:d['Availability'][0].__setitem__('Index',2),
   'last-snapshot-missing':lambda d:d['Session'].__setitem__('Issued',d['Availability'][-1]['FrameIssued']),
   'sequence-regression':lambda d:d['Availability'][-1]['Before'].__setitem__('Sequence',0),
  }
  for name,change in changes.items():
   bad=copy.deepcopy(good);change(bad);run(kind,name,bad,False)
  run(kind,'stderr-diagnostic',good,False,stderr=b'error\n')
  run(kind,'legacy-warning-rejected',good,False,stdout=b'2026/10/18 00:00:00 ERROR lines.Lines font style MUST be Monospace\n'+encode(good))
  run(kind,'duplicate-record',good,False,stdout=encode(good)*2)
  run(kind,'unknown-output',good,False,stdout=b'noise\n'+encode(good))
 paths=[Path(__file__),Q/'validate.py',Q/'oracles.json',*[Q/(k+'_oracle.py')for k in sources],*[Q.parent/p for p,_ in sources.values()],Q.parent/'macos-acquisition-diagnostics-4ce6ba4/validate.py']
 pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths};out={'synthetic_only':True,'native_executed':False,'cases':cases,'inputs':pins};(Q/'validation-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'synthetic_cases':len(cases),'positive_cases':sum(c['expected_accept']for c in cases),'all_expected':True,'native_executed':False}))
if __name__=='__main__':main()
