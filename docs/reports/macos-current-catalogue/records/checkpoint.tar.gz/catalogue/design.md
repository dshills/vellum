# Current native catalogue renewal — 1338b11 / stage87

Five earlier records qualify older shared runtimes. Current shared visibility,
disabled-editor publication and typography bytes differ, so this scope renews
only control57/21, choice30/23, navigation47/41, media71/42 and structure50/42:
255 inputs and169 observations total. H text68/33, I workspace432/54 and J
native docking/document outputs are not replayed. Existing authored actions,
independent literal domain/geometry/semantics/focus/callback/history expectations
and all previous failed/passing scopes stay unchanged. No product source, SDK,
prepared file or image golden is changed.

Actual current T Go/Objective-C compiles against the unchanged retained source-
builtSDK native archive786a, Go1.25.6/GOMAXPROCS2. Seven private Go overlay files:
start from three exact H copied-visibility helpers; add metadata-only Availability
fields and post-worker-join copies in four reports; one added
private init loads normal Core settings, asserts positive initialized zoom and
then disables geometry saving. No new actions, event reordering, acquisition
retry or drawable-readiness inference. Fixed1024 copied observations per process;
explicit FrameUnavailable remains fatal. The JSON validators are byte-identical
authored5oracles; the wrapper rejects all nonJSON output/oldfont warnings and
checks exact correlation schema/order/tags/origins.110 synthetic controls include
10 positives and100 negative mutations; synthetic data is not native evidence.

The full gallery race, affected defaultvet and native build pass this exact
private configuration. Full driver-root race reuse requires all7049 effective
compiled/prepared inputs still match G's original295.116s owned pass, with seven
proven byte-identical Go promotions. Fresh configuration checks remain separate.

Prepare one fixed5case native plan after internal source/controller review.
Independent exact-plan admission follows, then serial native processes under
shared LiveLease,30min launch deadline,120s watchdog and4MiB streams percase.
Whole C/T5521source/stage876277/SDK7880 and Core geometry hash/length metadata
are guarded before/after everycase; source/SDK/prepared/Coredata writes and IP
network denied. Each case owns a fresh temp root. First failure permanently
seals the case/campaign and skips remaining cases. Both successful and failed
older scopes retain their seals. No OS-input operator, inputsource/VoiceOver/
clipboard/settings changes, realfilepanels/human assistive-tech, nativepixels/
presentation/performance/resource/deallocation/fullMac claim. Catalogue current
qualification and a separately reviewed dedicated-contract audit are M2 work;
M3–M7 stay independent and unchanged.
