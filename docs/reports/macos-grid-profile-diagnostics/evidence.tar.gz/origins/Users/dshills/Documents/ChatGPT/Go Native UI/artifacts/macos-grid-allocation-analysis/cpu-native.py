"""Two bounded process-wide CPU profiles; never ordinary-frame qualification."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
g=module('cpu_diagnostic_owned_guard',W.parent/'macos-sdk-native-238b3b6/run.py');benchmark=module('cpu_diagnostic_frame_validator',T/'scripts/benchmark-grid.py')
def validate(records,case):
 samples=benchmark.validate_records(records,1000000,False,case['samples'],False,allow_profile=True,gpu_scene_rendering=case['gpu_requested'])
 for record in [records[0],records[1],records[-1]]:
  need(record.get('cpu_profile')is True and record.get('alloc_profile',False)is False and record.get('source_details',False)is False and record.get('input_details',False)is False,'exact CPU-only diagnostic identity')
  need(type(record.get('window_geometry_guard'))is int and record['window_geometry_guard']==1 and type(record.get('warmup_guard'))is int and record['warmup_guard']==1,'current geometry/warmup guards')
 need(records[0].get('cpu_profile_path')==case['profile'],'exclusive CPU profile path identity')
 need(records[1].get('warmup')==128 and records[1].get('warm_callbacks')==128,'exact unmeasured warmup')
 return samples

def finalize(root,d,seal=None,report=None,write=None):
 d['finalization_errors']=[]
 def status():d['result']='PASS_SCOPED_GRID_CPU_PROFILES'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_GRID_CPU_PROFILES'
 def failed(stage,error):d['finalization_errors'].append({'stage':stage,'type':type(error).__name__});status()
 try:(seal or (lambda:(root/'stop-live').touch()))();d['local_stop_present']=True
 except BaseException as e:failed('local-seal',e)
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();status()
 def terminal_report():
  payload={k:v for k,v in d.items()if k!='cases'};payload['result']='PENDING_EXCLUSIVE_RECEIPT';print(json.dumps(payload),flush=True)
 try:(report or terminal_report)()
 except BaseException as e:failed('terminal-report',e)
 def receipt():
  with(root/'receipt.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
 try:(write or receipt)()
 except BaseException as e:failed('exclusive-receipt',e)
 return d

def main():
 need(len(sys.argv)==1,'no native runtime overrides');plan=read(W/'cpu-plan.json');review=read(W/'cpu-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'separate native CPU readiness review');P=Path(plan['root']);R=Path(plan['native_root']);HEAD=plan['source_commit']
 need(read(P/'build-receipt.json')['result']=='PASS_CLEAN_CPU_DIAGNOSTIC_COMPILE_ONLY','clean release compile receipt')
 need(not any((R/n).exists()for n in ['receipt.json','stop-live','cpu-fixed','gpu-requested-fixed'])and not any((R/'profiles').iterdir()),'fresh native output/profile destinations')
 pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(R/'stop-live').exists()
 def clean():
  for root in[T,C]:need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20),'clean source boundary')
  need(all(sha(p)==h for p,h in {**plan['source_pins'],**plan['prepared_pins']}.items()),'full source/prepared identity')
  need(sha(plan['binary']['path'])==plan['binary']['sha256']and Path(plan['binary']['path']).stat().st_size==plan['binary']['bytes'],'release executable identity')
 need(stable()and not stopping(),'initial admission')
 d={'result':'INCOMPLETE','source_commit':HEAD,'producer_sha256':sha(__file__),'review_sha256':sha(W/'cpu-readiness.json'),'native_runtime_executed':False,'native_windows_verified':0,'physical_input_generated':False,'settings_changes':False,'ordinary_frame_qualification':False,'gpu_execution_qualified':False,'retained_native_memory_qualified':False,'scope':'process-wide CPU profiles include frame observers/serialization and GC; timings are diagnostic only','cases':[],'error':None}
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping(),'lease admission');clean()
   for case in plan['cases']:
    need(lease.held()and stable()and not stopping()and not Path(case['profile']).exists(),'per-case fresh admission');clean()
    out=R/case['label'];run=g.execute(case['argv'],T/'examples/loadedgrid',out,stopping,stable,timeout=180,limit=8<<20);record={'case':case,'run':run,'error':None};d['cases'].append(record);d['native_runtime_executed']|=run['created']
    try:
     need(run['created']and run['error']is None and run['exit_code']==0 and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'terminal native owned process and streams')
     records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];samples=validate(records,case)
     profile=Path(case['profile']);need(profile.is_file()and not profile.is_symlink()and 0<profile.stat().st_size<=64<<20,'bounded exclusive CPU profile')
     with profile.open('rb')as source:need(source.read(2)==b'\x1f\x8b','gzip CPU profile')
     record['validation']={'samples':len(samples),'callbacks':records[-1]['callbacks'],'native_window':records[1]['native_window'],'profile':{'path':str(profile),'bytes':profile.stat().st_size,'sha256':sha(profile)},'geometry_sha256':hashlib.sha256(json.dumps([s['geometry']for s in samples],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'ordinary_case':False};d['native_windows_verified']+=1
     clean();need(stable()and not stopping(),'per-case terminal pins/stops')
    except BaseException as e:record['error']={'type':type(e).__name__,'message':str(e)};raise
    finally:
     with(out/'receipt.json').open('x')as output:output.write(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'case':case['label'],'result':'CPU_PROFILE_COLLECTED','samples':len(samples),'seconds':run['seconds']}),flush=True)
   need(len(d['cases'])==2 and d['native_windows_verified']==2,'two fixed CPU diagnostic cases')
   a,b=[v['validation']for v in d['cases']];need(a['geometry_sha256']==b['geometry_sha256']and a['native_window']==b['native_window'],'same fixed geometry across rendering-mode diagnostics');d['matched_geometry']=True
   clean();need(lease.held()and stable()and not stopping(),'terminal lease/pins/stops');d['lease_held_through_cleanup']=True
 except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)}
 finally:finalize(R,d)
 need(d['error']is None and not d['finalization_errors'],'native CPU diagnostic failed or canceled')
if __name__=='__main__':main()
