"""Build the current release grid for two separately reviewed CPU diagnostics."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='30025cc538e7928fea27113a61a852ab91c5fe79';P=Path('/private/tmp/vellum-grid-cpu-diagnostic-30025cc');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
runner=W.parent/'macos-sdk-native-238b3b6/run.py';assert sha(runner)=='e76238012be63f58cbc5923e27f6fc227a3aca8443d85d64f466c0675382c7ac';spec=importlib.util.spec_from_file_location('grid_cpu_build_guard',runner);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
files={};prepared={}
for root in[T,C]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20)
 names=subprocess.check_output(['git','ls-files','-z'],cwd=root,timeout=20).decode().split('\0')[:-1];assert len(names)==4704
 for name in names:p=root/name;assert p.is_file()and not p.is_symlink();files[str(p)]=sha(p)
 local={}
 for name in ['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/name).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():local[str(p)]=sha(p)
 assert len(local)==6249;prepared.update(local)
assert all(files[str(T/n)]==files[str(C/n)]for n in names)
assert all(prepared[str(T/'drivers/cogent/build'/Path(p).relative_to(C/'drivers/cogent/build'))]==h for p,h in prepared.items()if p.startswith(str(C)))
P.mkdir(mode=0o700);(P/'source.json').write_text(json.dumps(files,indent=2)+'\n');(P/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n');(P/'native').mkdir(mode=0o700);(P/'native/profiles').mkdir(mode=0o700)
pins={**files,**prepared,str(Path(__file__).resolve()):sha(__file__),str(runner):sha(runner)};stable=lambda:all(sha(p)==h for p,h in pins.items())
prefix=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go'];d={'result':'INCOMPLETE','source_commit':HEAD,'native_runtime_executed':False,'commands':[],'error':None}
try:
 for label,args in [('build',prefix+['build','-p=1','-trimpath','-o',str(P/'loadedgrid'),'.']),('metadata',prefix+['version','-m','-json',str(P/'loadedgrid')])]:
  run=g.execute(args,T/'examples/loadedgrid',P/label,lambda:False,stable,timeout=300 if label=='build' else 30,limit=2<<20);d['commands'].append({'name':label,'run':run})
  assert run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
  print(json.dumps({'name':label,'seconds':run['seconds'],'exit_code':run['exit_code']}),flush=True)
 info=read(P/'metadata/stdout')
 settings={v['Key']:v['Value']for v in info['Settings']}
 assert settings['vcs.revision']==HEAD, 'clean build revision'
 assert settings['vcs.modified']=='false', 'clean build status'
 assert settings.get('-race')not in['true','1']and settings.get('-gcflags','')==''
 binary={'path':str(P/'loadedgrid'),'bytes':(P/'loadedgrid').stat().st_size,'sha256':sha(P/'loadedgrid')}
 cases=[{'label':label,'gpu_requested':gpu,'samples':1024,'profile':str(P/'native/profiles'/(label+'.cpu.pprof')),'argv':[binary['path'],'-perf','-rows=1000000','-perf-samples=1024','-perf-warmup=128','-perf-cpu-profile='+str(P/'native/profiles'/(label+'.cpu.pprof'))]+(['-gpu-scene']if gpu else[])}for label,gpu in [('cpu-fixed',False),('gpu-requested-fixed',True)]]
 plan={'source_commit':HEAD,'root':str(P),'native_root':str(P/'native'),'binary':binary,'cases':cases,'source_pins':files,'prepared_pins':prepared,'scope':'process-wide CPU diagnostics including observer overhead; no ordinary latency/GPU/retained-memory qualification'}
 with(W/'cpu-plan.json').open('x')as f:f.write(json.dumps(plan,indent=2)+'\n')
 d.update(result='PASS_CLEAN_CPU_DIAGNOSTIC_COMPILE_ONLY',binary=binary)
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(P/'build-receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
