"""Verify finished native diagnostic evidence and inspect saved CPU profiles."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('grid_cpu_offline',W/'cpu-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n);g=n.g;T=n.T;sha=n.sha;read=n.read
plan=read(W/'cpu-plan.json');P=Path(plan['root']);R=Path(plan['native_root']);receipt=read(R/'receipt.json');review=read(W/'cpu-readiness.json');O=W/'cpu-tops-v1';O.mkdir(mode=0o700)
assert receipt['result']=='PASS_SCOPED_GRID_CPU_PROFILES'and receipt['error']is None and not receipt['finalization_errors']and receipt['native_windows_verified']==2 and receipt['matched_geometry']and receipt['lease_held_through_cleanup']and(R/'stop-live').exists()
assert receipt['producer_sha256']==sha(W/'cpu-native.py')and receipt['review_sha256']==sha(W/'cpu-readiness.json')and [v['case']for v in receipt['cases']]==plan['cases']
pins={**review['inputs'],str(R/'receipt.json'):sha(R/'receipt.json'),str(Path(__file__).resolve()):sha(__file__)};cases=[]
for v in receipt['cases']:
 case=v['case'];run=v['run'];out=R/case['label'];assert v['error']is None
 assert run['argv']==case['argv']and run['created']and run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
 for name in['stdout','stderr']:
  p=out/name;assert p.stat().st_size==run['logs'][name]['bytes']and sha(p)==run['logs'][name]['sha256'];pins[str(p)]=sha(p)
 records=[json.loads(line)for line in(out/'stdout').read_bytes().splitlines()];samples=n.validate(records,case);assert len(samples)==1024
 profile=v['validation']['profile'];assert profile['path']==case['profile']and sha(profile['path'])==profile['sha256']and Path(profile['path']).stat().st_size==profile['bytes'];pins[profile['path']]=profile['sha256']
 absence=g.absent(run['pid']);cases.append({'label':case['label'],'samples':len(samples),'profile':profile,'terminal_owned_group':run['pid'],'terminal_group_absent':True,'reobserved_group_absent':absence})
assert all(sha(p)==h for p,h in pins.items());stable=lambda:all(sha(p)==h for p,h in pins.items())
(W/'cpu-analysis-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');d={'result':'INCOMPLETE','source_commit':plan['source_commit'],'native_runtime_executed_by_analyzer':False,'native_profiles_reconciled':2,'callbacks_reconciled':2048,'ordinary_qualification':False,'cases':cases,'commands':[],'error':None}
try:
 for case in plan['cases']:
  for mode in['flat','cum']:
   args=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','GOTOOLCHAIN=local','/opt/homebrew/bin/go','tool','pprof','-top','-nodecount=45','-symbolize=none']+(['-cum']if mode=='cum'else[])+[case['profile']]
   run=g.execute(args,T,O/(case['label']+'-'+mode),lambda:False,stable,timeout=60,limit=2<<20);d['commands'].append({'case':case['label'],'mode':mode,'run':run});assert run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'];print(json.dumps({'case':case['label'],'mode':mode,'exit_code':run['exit_code']}),flush=True)
 d['result']='RECONCILED_TWO_NATIVE_CPU_PROFILES_AND_OFFLINE_TOPS'
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(O/'receipt.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
