"""Bundle reviewed diagnostics without executable copies and prepare seven docs."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
W=Path(__file__).resolve().parent;A=W.parent/'macos-grid-allocation-analysis';S=W.parent/'macos-grid-native-cpu-sample';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-grid-cpu-diagnostic-30025cc');R=Path('/private/tmp/vellum-grid-native-cpu-sample-30025cc');HEAD='30025cc538e7928fea27113a61a852ab91c5fe79'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
r=read(S/'result-review.json');assert (r.get('results_ready')or r.get('result_ready'))and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
for root in(T,C):assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20)
files={};omitted=[];origins={}
def add(p):
 p=Path(p);assert p.is_file()and not p.is_symlink();data=p.read_bytes()
 if data[:4]in[b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe',b'\xbe\xba\xfe\xca',b'\xca\xfe\xba\xbf',b'\xbf\xba\xfe\xca',b'\xce\xfa\xed\xfe',b'\xfe\xed\xfa\xce']:
  omitted.append(dict(path=str(p),bytes=len(data),sha256=sha(p)));return
 key='origins/'+str(p).lstrip('/');files[key]=data;origins[key]=str(p)
for root in(A,S,P,R):
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():add(p)
for origin in {**read(A/'inputs.json'),**read(S/'readiness.json')['inputs']}:
 p=Path(origin)
 if any(p.is_relative_to(root)for root in(T,C)):continue
 add(p)
for name in('child_process.py','sdk_environment.py','benchmark-grid.py'):add(T/'scripts'/name)
for p in(W/'README.template.md',Path(__file__),W/'check-docs.py',W/'stage.py',W/'commit.py',W/'workspace-collision-correction.json'):add(p)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest(),origin=origins[k])for k,v in sorted(files.items())}
with(W/'evidence.tar.gz').open('xb')as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0)as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT)as archive:
   for name,data in sorted(files.items()):
    member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0;archive.addfile(member,io.BytesIO(data))
with(W/'evidence.manifest.json').open('x')as output:output.write(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(W/'evidence.tar.gz','r:gz')as archive:
 assert [m.name for m in archive]==sorted(manifest)
 for member in archive:
  assert member.isfile();data=archive.extractfile(member).read();assert len(data)==manifest[member.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
analysis=read(S/'analysis.json');phase=read(A/'phase-analysis.json');result=dict(schema='vellum-current-grid-profile-diagnostics-v1',source_commit=HEAD,source_files=4704,prepared_files=6249,native_apps=3,native_samplers=1,callbacks=3072,samples_per_app=1024,warmup_per_app=128,ordinary_frame_qualification=False,gpu_execution_qualified=False,native_cpu_attribution_established=False,retained_native_memory_qualified=False,full_macos_qualified=False,runtime_source_changed=False,provider_calls=0,result_review_sha256=sha(S/'result-review.json'),native_stack={k:v for k,v in analysis['native_wall_stack'].items()},diagnostic_phase_distributions=phase['cases'],evidence_archive=dict(bytes=(W/'evidence.tar.gz').stat().st_size,sha256=sha(W/'evidence.tar.gz'),members=len(manifest),expanded_bytes=sum(v['bytes']for v in manifest.values())),executables_omitted=list({v['path']:v for v in omitted}.values()),original_cpu_receipt_sha256=sha(P/'native/receipt.json'),native_sample_receipt_sha256=sha(R/'receipt.json'))
with(W/'result.json').open('x')as output:output.write(json.dumps(result,indent=2)+'\n')
report='docs/reports/macos-grid-profile-diagnostics';D=W/'draft';D.mkdir(mode=0o700)
new={report+'/'+name:(W/source).read_bytes()for name,source in[('README.md','README.template.md'),('result.json','result.json'),('evidence.manifest.json','evidence.manifest.json'),('evidence.tar.gz','evidence.tar.gz')]}
paragraph='''The [current grid profile diagnostics](reports/macos-grid-profile-diagnostics/README.md)
complete three CPU-profiled native apps and 3,072 callbacks on clean `30025cc`,
plus one exact-PID native stack sample. All owned groups close and are observed
absent. Go `cgocall` totals do not establish native function cost; the native
sample includes substantial waiting and AX work. Profiled phase distributions
remain diagnostic. Ordinary frame targets, memory/endurance, physical/human
workflows and full macOS acceptance remain open. No runtime source changes here.
'''
p='docs/implementation.md';old=(T/p).read_text();new[p]=(old+'\n'+paragraph).encode()
p='specs/macos-completion.md';old=(T/p).read_text();needle='## Latest unattended evidence\n';assert needle in old;new[p]=old.replace(needle,needle+'\n'+paragraph.replace('(reports/','(../docs/reports/'),1).encode()
p='docs/reports/README.md';old=(T/p).read_text();needle='The [implementation status](../implementation.md) describes the current framework.\n';assert needle in old;new[p]=old.replace(needle,needle+'\n- [Current grid profile diagnostics](macos-grid-profile-diagnostics/README.md)\n',1).encode()
assert len(new)==7
for name,data in new.items():dest=D/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
b=dict(base_commit=HEAD,sources={name:hashlib.sha256(data).hexdigest()for name,data in new.items()},draft_root=str(D),old={name:sha(T/name)if(T/name).exists()else None for name in new},source_files_after=4708,prepared_files=6249,native_runtime_sources_unchanged=True,provider_calls=0,result_review_sha256=sha(S/'result-review.json'))
with(W/'draft-binding.json').open('x')as output:output.write(json.dumps(b,indent=2)+'\n')
print(json.dumps(dict(result='PREPARED_PROFILE_DIAGNOSTIC_DOCUMENTS',files=len(new),archive=result['evidence_archive'])))
