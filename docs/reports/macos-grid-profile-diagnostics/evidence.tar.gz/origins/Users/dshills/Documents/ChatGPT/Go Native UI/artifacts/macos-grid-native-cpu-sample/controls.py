"""Non-GUI controls for exact ownership, one-shot launch, cancellation and joining."""
from pathlib import Path
import importlib.util, json, sys, tempfile, threading
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('sample_controller_controls',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
results=[]
def check(label,fn):
 fn();results.append(dict(name=label,pass_=True))
def refuse(fn):
 try:fn()
 except ValueError:return
 raise AssertionError('expected refusal')
argv=['/private/tmp/owned-vellum'];cwd=Path('/private/tmp/example')
owned=dict(pid=42,group=42,argv=argv,cwd=str(cwd))
def observe(pid):return b'42 42 /private/tmp/owned-vellum\n'
check('exact ownership accepted',lambda:m.need(m.target_pid(owned,argv,cwd,observe)==42,'PID'))
for label,key,value in [('wrong PID','pid',True),('wrong group','group',43),('wrong command','argv',['/other']),('wrong directory','cwd','/other')]:
 check(label,lambda key=key,value=value:refuse(lambda:m.target_pid({**owned,key:value},argv,cwd,observe)))
for label,value in [('missing process',b''),('reused PID/group',b'42 43 /private/tmp/owned-vellum'),('wrong executable',b'42 42 /other')]:
 check(label,lambda value=value:refuse(lambda:m.target_pid(owned,argv,cwd,lambda _:value)))
prefix = [dict(event='grid.perf.setup', rows=1000000, gpu_scene_rendering=True, cpu_profile=True), dict(event='grid.perf.ready', gpu_scene_rendering=True, cpu_profile=True, warmup=128, warm_callbacks=128, warmup_guard=1, window_geometry_guard=1), dict(event='grid.perf.sample', gpu_scene_rendering=True, index=0, callbacks=1)]
def measured(r): (r/'app/stdout').write_text(''.join(json.dumps(v)+'\n' for v in prefix))
with tempfile.TemporaryDirectory(prefix='controls-',dir=W)as tmp:
 root=Path(tmp);calls=[]
 def execute(*args,**kwargs):calls.append((args,kwargs));return dict(error=None,exit_code=0)
 def fixture(name,stop=lambda:False,stable=lambda:True,executor=execute):
  r=root/name;r.mkdir();(r/'app').mkdir();(r/'app/owned.json').write_text(json.dumps(owned));measured(r);x=m.Sampler(argv,cwd,r,stop,stable,observe,executor);x.started-=6;return x
 x=fixture('normal');x.poll();x.join();x.poll();x.join()
 check('one sampler only across repeated polls',lambda:m.need(len(calls)==1 and x.attempted and not x.thread.is_alive(),'one shot joined'))
 check('sampler argv exact PID no UI opening',lambda:m.need(calls[0][0][0]==['/usr/bin/sample','42','10','1','-mayDie','-file',str(root/'normal/native.sample.txt')],'argv'))
 x=fixture('stop',stop=lambda:True);check('stop prevents launch',lambda:m.need(x.poll()is True and x.thread is None,'stopped'))
 x=fixture('unstable',stable=lambda:False);check('changed pins prevent launch',lambda:refuse(x.poll));check('no launch after failed admission',lambda:m.need(x.attempted and x.thread is None,'failed admission terminal'))
 x=fixture('early');x.started=m.time.monotonic();check('threshold defers sample',lambda:m.need(x.poll()is False and x.thread is None,'delay'))
 x=fixture('missing');(x.root/'app/owned.json').unlink();check('no app means no sampler',lambda:m.need(x.poll()is False and x.thread is None,'missing'))
 x=fixture('wrong-process');x.observe=lambda _:b'';check('gone native target refuses attach',lambda:refuse(x.poll))
 x=fixture('oversize');(x.root/'native.sample.txt').write_bytes(b'x');x.root.joinpath('native.sample.txt').unlink();x.root.joinpath('native.sample.txt').symlink_to(root/'normal/app/owned.json');check('sample symlink rejected',lambda:refuse(x.poll))
 def boom(*args,**kw):raise ValueError('deliberate sampler failure')
 x=fixture('worker-failure',executor=boom)
 # Worker failures may be observed by the same poll or by join, depending on scheduling.
 try:x.poll()
 except ValueError:pass
 check('worker exception joined and surfaced',lambda:refuse(x.join));check('failed worker terminal',lambda:m.need(not x.thread.is_alive(),'worker ended'))
 x=fixture('bad-exit',executor=lambda *a,**kw:dict(error=None,exit_code=1))
 try:x.poll()
 except ValueError:pass
 x.join();check('sampler nonzero exit refused',lambda:refuse(x.poll))
 event=threading.Event();entered=threading.Event();exited=threading.Event()
 def cancelable(*args,**kw):
  entered.set();event.wait(2);exited.set();return dict(error=dict(type='cancel'),exit_code=-15)
 x=fixture('cancel',stop=event.is_set,executor=cancelable);x.poll();m.need(entered.wait(1),'worker started');event.set();m.need(x.poll()is True,'return stop');x.join()
 check('cancellation joins sampler worker',lambda:m.need(exited.is_set()and not x.thread.is_alive(),'joined'))
with tempfile.TemporaryDirectory(prefix='controls-held-',dir=W) as tmp:
 root=Path(tmp);(root/'app').mkdir();(root/'app/owned.json').write_text(json.dumps(owned));measured(root)
 held=threading.Event();entered=threading.Event();joined=threading.Event()
 def held_execute(*args,**kw):
  entered.set();held.wait(3);return dict(error=None,exit_code=0)
 x=m.Sampler(argv,cwd,root,lambda:False,lambda:True,observe,held_execute);x.started-=6;x.poll();m.need(entered.wait(1),'entered held worker')
 def joiner(): x.join();joined.set()
 j=threading.Thread(target=joiner);j.start();m.need(x.cancel.wait(1),'join canceled worker');m.need(not joined.is_set() and x.thread.is_alive(),'join retains ownership while held');held.set();j.join(2)
 check('held worker retains ownership until actual join',lambda:m.need(joined.is_set()and not j.is_alive()and not x.thread.is_alive(),'joined held worker'))
 x.pid=42;x.cancel.clear();x.observe=lambda _:b''
 check('worker final admission revalidates target',lambda:refuse(x.launch_stable))
 x.observe=observe;x.cancel.set()
 check('worker final admission refuses canceled app',lambda:m.need(x.launch_stable()is False,'no canceled launch'))
with tempfile.TemporaryDirectory(prefix='controls-prefix-',dir=W) as tmp:
 root=Path(tmp);(root/'app').mkdir()
 check('no native stdout defers sample',lambda:m.need(m.measurement_started(root)is False,'not ready'))
 measured(root);check('completed warmup and first callback admitted',lambda:m.need(m.measurement_started(root)is True,'ready'))
 (root/'app/stdout').write_text(json.dumps(prefix[0])+'\n'+json.dumps(prefix[1])+'\n'+json.dumps(prefix[2])[:-1])
 check('partial first callback defers sample',lambda:m.need(m.measurement_started(root)is False,'incomplete'))
 prefix[1]['warm_callbacks']=127;measured(root)
 check('wrong warmup refused',lambda:refuse(lambda:m.measurement_started(root)))
 prefix[1]['warm_callbacks']=128;prefix[2]['index']=1;measured(root)
 check('wrong first callback refused',lambda:refuse(lambda:m.measurement_started(root)))
result=dict(result='PASS_NON_GUI_NATIVE_SAMPLE_CONTROLS',native_runtime_executed=False,controls=results)
with(W/'controls.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
