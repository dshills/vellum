"""Offline phase distribution from CPU-profiled diagnostics, not qualification."""
from pathlib import Path
import hashlib, importlib.util, json, math, statistics, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('cpu_phase_analysis_validation',W/'cpu-native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
R=Path('/private/tmp/vellum-grid-cpu-diagnostic-30025cc/native')
r=m.read(R/'receipt.json');m.need(r['result']=='PASS_SCOPED_GRID_CPU_PROFILES'and r['error']is None and not r['finalization_errors'],'terminal CPU campaign')
results=[]
for case in r['cases']:
 path=R/case['case']['label']/'stdout';m.need(m.sha(path)==case['run']['logs']['stdout']['sha256'],'raw native log identity')
 records=[json.loads(l)for l in path.read_bytes().splitlines()];samples=m.validate(records,case['case'])
 stats={}
 for key in samples[0]['metrics']:
  values=sorted(x['metrics'][key]for x in samples)
  stats[key]=dict(median_ns=statistics.median(values),p95_ns=values[math.ceil(len(values)*.95)-1],p99_ns=values[math.ceil(len(values)*.99)-1])
 slow=sorted(samples,key=lambda x:x['metrics']['ui_work_ns'])[-math.ceil(len(samples)*.05):]
 results.append(dict(label=case['case']['label'],callbacks=len(samples),raw_sha256=m.sha(path),phases=stats,slowest_five_percent_mean_ns={key:statistics.mean(x['metrics'][key]for x in slow)for key in samples[0]['metrics']}))
out=dict(result='RECONCILED_DIAGNOSTIC_PHASE_DISTRIBUTIONS',scope='CPU-profiled frame observations include profiler and observer overhead; no ordinary frame-budget qualification or native function attribution',native_runtime_executed_by_analyzer=False,ordinary_frame_qualification=False,cases=results)
with(W/'phase-analysis.json').open('x')as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
