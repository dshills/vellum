"""Read-only offline sampled Go allocation analysis of an existing native pair."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-grid-intrinsic-native-599442a');T=Path('/private/tmp/vellum-macos-native-results-97aee13');O=W/'pprof-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
runner=W.parent/'macos-sdk-native-238b3b6/run.py';assert sha(runner)=='e76238012be63f58cbc5923e27f6fc227a3aca8443d85d64f466c0675382c7ac';spec=importlib.util.spec_from_file_location('grid_alloc_offline_guard',runner);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
O.mkdir(mode=0o700);pins={str(runner):sha(runner),str(Path(__file__).resolve()):sha(__file__),str(P/'native-receipt.json'):sha(P/'native-receipt.json'),str(P/'source.json'):sha(P/'source.json'),str(P/'build-receipt.json'):sha(P/'build-receipt.json')}
for flavor in ['baseline','candidate']:
 r=read(P/'runs'/(flavor+'-allocation')/'receipt.json');assert r['error']is None and not r['validation']['ordinary_case']and r['validation']['samples']==512
 for which in ['before','after']:
  p=r['validation']['profile_files'][which];assert sha(p['path'])==p['sha256']and Path(p['path']).stat().st_size==p['bytes'];pins[p['path']]=p['sha256']
 for f in ['receipt.json','stdout','stderr']:
  p=P/'runs'/(flavor+'-allocation')/f;pins[str(p)]=sha(p)
 for stream in ['stdout','stderr']:
  p=P/'runs'/(flavor+'-allocation')/stream;assert p.stat().st_size==r['run']['logs'][stream]['bytes']and sha(p)==r['run']['logs'][stream]['sha256']
(W/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(sha(p)==h for p,h in pins.items())
d={'result':'INCOMPLETE','native_runtime_executed':False,'commands':[],'error':None,'profiles_from_source':'599442af1bf037abc75ed90591ce71aac74f5849','current_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,timeout=20).decode().strip(),'profile_rate':524288,'scope':'sampled cumulative Go allocations, process/observer overhead included, not timing or native/retained memory'}
try:
 for flavor in ['baseline','candidate']:
  for metric in ['alloc_space','alloc_objects']:
   name=flavor+'-'+metric
   argv=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','GOTOOLCHAIN=local','/opt/homebrew/bin/go','tool','pprof','-top','-nodecount=35','-symbolize=none','-sample_index='+metric,'-base',str(P/'profiles'/(flavor+'.before.pprof')),str(P/'profiles'/(flavor+'.after.pprof'))]
   run=g.execute(argv,T,O/name,lambda:False,stable,timeout=60,limit=2<<20);d['commands'].append({'name':name,'run':run});print(json.dumps({'name':name,'exit_code':run['exit_code'],'seconds':run['seconds'],'error':run['error']}),flush=True)
   assert run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
 d['result']='PASS_OFFLINE_SAMPLED_ALLOCATION_TOPS'
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(O/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
