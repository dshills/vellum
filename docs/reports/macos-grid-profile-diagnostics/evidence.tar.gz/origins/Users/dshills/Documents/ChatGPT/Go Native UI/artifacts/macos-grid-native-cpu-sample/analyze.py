"""Reconcile closed native results and disjoint wall-stack observations offline."""
from pathlib import Path
import hashlib, importlib.util, json, re, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('native_sample_offline_utilities',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
g=m.g;R=m.R;r=m.read(R/'receipt.json');review=m.read(W/'readiness.json')
m.need(r['result']=='PASS_SCOPED_NATIVE_STACK_DIAGNOSTIC'and r['error']is None and not r['finalization_errors'],'sealed native campaign')
m.need(m.sha(W/'readiness.json')==r['review_sha256']and m.sha(W/'run.py')==r['producer_sha256'],'readiness and producer')
pins={**review['inputs'],str(R/'receipt.json'):m.sha(R/'receipt.json')}
for name in ('app','sampler'):
 run=r[name];m.need(m.terminal(run),'terminal owned command')
 for stream,expected in run['logs'].items():
  p=R/name/stream;m.need(p.stat().st_size==expected['bytes']and m.sha(p)==expected['sha256'],'exact raw command stream');pins[str(p)]=m.sha(p)
 for leaf in ('owned.json',):pins[str(R/name/leaf)]=m.sha(R/name/leaf)
for leaf,expected in r['validation']['profiles'].items():
 p=R/leaf;m.need(p.stat().st_size==expected['bytes']and m.sha(p)==expected['sha256'],'profile bytes');pins[str(p)]=m.sha(p)
m.need((R/'stop-live').exists(),'native campaign sealed')
observations={name:g.absent(r[name]['pid'])for name in ('app','sampler')}
records=[json.loads(l)for l in(R/'app/stdout').read_bytes().splitlines()]
case=dict(samples=1024,gpu_requested=True,profile=str(R/'sampled.cpu.pprof'));samples=m.cpu.validate(records,case)
lines=(R/'native.sample.txt').read_text().splitlines();begin=lines.index('Call graph:')+1
first=next(i for i in range(begin,len(lines))if re.match(r'^    \d+ Thread_',lines[i]))
end=next(i for i in range(first+1,len(lines))if re.match(r'^    \d+ Thread_',lines[i]))
header=re.match(r'^    (\d+) Thread_.*Main Thread',lines[first]);m.need(header is not None,'exact main thread')
total=int(header[1]);groups={'update':lambda s:'__vellumAXUpdate_block_invoke_2 'in s,'pending':lambda s:'__vellumAXUpdatePending_block_invoke_'in s,'commit':lambda s:s.startswith('vellumAXCommitSnapshot '),'validate':lambda s:s.startswith('vellumAXValidatedNodes '),'json_reader':lambda s:s.startswith('-[_NSJSONReader parseData:options:error:] '),'mach_port_wait':lambda s:s.startswith('__CFRunLoopServiceMachPort ')}
counts={k:0 for k in groups};stack=[];matches={k:[]for k in groups}
for i in range(first+1,end):
 match=re.match(r'^([ +!:\|]*)(\d+) (.*)$',lines[i])
 if not match:continue
 col=len(match[1]);n=int(match[2]);symbol=match[3]
 while stack and stack[-1][0]>=col:stack.pop()
 for key,predicate in groups.items():
  if predicate(symbol)and not any(predicate(ancestor[1])for ancestor in stack):counts[key]+=n;matches[key].append(dict(line=i+1,count=n,symbol=symbol))
 stack.append((col,symbol))
m.need(all(0<=v<=total for v in counts.values())and counts['validate']<=counts['commit']<=counts['update'],'disjoint inclusive native counts')
O=W/'cpu-tops-v1';m.need(not O.exists(),'new offline pprof destination');O.mkdir()
stable=lambda:all(m.sha(p)==h for p,h in pins.items());stopping=lambda:(O/'stop-analysis').exists()
commands=[]
for cumulative in (False,True):
 argv=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','GOTOOLCHAIN=local','/opt/homebrew/bin/go','tool','pprof','-top','-nodecount=45','-symbolize=none']+(['-cum']if cumulative else[])+[str(R/'sampled.cpu.pprof')]
 run=g.execute(argv,m.T,O/('cum'if cumulative else'flat'),stopping,stable,timeout=60,limit=1<<20);commands.append(run);m.need(m.terminal(run),'bounded offline pprof command')
out=dict(result='RECONCILED_NATIVE_STACK_AND_CPU_DIAGNOSTIC',source_commit=r['source_commit'],native_runtime_executed_by_analyzer=False,callbacks=len(samples),ordinary_frame_qualification=False,gpu_execution_qualified=False,native_cpu_attribution_established=False,native_wall_stack=dict(total_main_thread_observations=total,inclusive_disjoint_counts=counts,matches=matches,scope='Categories overlap. Inclusive descendants count once within each category. Wall-stack observations are not CPU percentages or elapsed-function timings.'),terminal_group_reobservations=observations,commands=commands,inputs=pins)
with(W/'analysis.json').open('x')as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ('commands','inputs','native_wall_stack')}));print(json.dumps(dict(main_observations=total,counts=counts)))
