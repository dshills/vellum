"""One owned native app and one exact-PID macOS sample; diagnostic evidence only."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, threading, time
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
A = W.parent / 'macos-grid-allocation-analysis'
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
R = Path('/private/tmp/vellum-grid-native-cpu-sample-30025cc')
STOP = Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
def need(ok, message):
    if not ok: raise ValueError(message)
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
cpu = module('native_stack_cpu_utilities', A / 'cpu-native.py')
g = cpu.g

def target_pid(owned, expected_argv, expected_cwd, observe):
    need(owned['argv'] == expected_argv and owned['cwd'] == str(expected_cwd), 'exact owned native command')
    pid = owned['pid']
    need(type(pid) is int and pid > 1 and owned['group'] == pid, 'own native process group')
    fields = observe(pid).decode().strip().split(None, 2)
    need(len(fields) == 3 and fields[:2] == [str(pid), str(pid)] and fields[2] == expected_argv[0], 'native PID/group/executable still present')
    return pid

def measurement_started(root):
    path = root / 'app/stdout'
    if not path.exists(): return False
    with path.open('rb') as source: prefix = source.read(64 << 10)
    lines = prefix.splitlines(keepends=True)
    if len(lines) < 3 or any(not line.endswith(b'\n') for line in lines[:3]): return False
    setup, ready, sample = [json.loads(line) for line in lines[:3]]
    need([r.get('event') for r in (setup, ready, sample)] == ['grid.perf.setup', 'grid.perf.ready', 'grid.perf.sample'], 'native measured prefix event order')
    need(all(r.get('rows', 1000000) == 1000000 and r.get('gpu_scene_rendering') is True and r.get('source_details', False) is False and r.get('input_details', False) is False and r.get('alloc_profile', False) is False for r in (setup, ready, sample)), 'native measured prefix identity')
    need(setup.get('cpu_profile') is True and ready.get('cpu_profile') is True and ready.get('warmup') == 128 and ready.get('warm_callbacks') == 128 and ready.get('warmup_guard') == 1 and ready.get('window_geometry_guard') == 1 and sample.get('index') == 0 and sample.get('callbacks') == 1, 'warmup complete and first measured callback')
    return True

class Sampler:
    """The outer app log pump keeps running while g.execute owns the sampler."""
    def __init__(self, argv, cwd, root, stopping, stable, observe=None, execute=None):
        self.argv, self.cwd, self.root = argv, cwd, root
        self.stopping, self.stable = stopping, stable
        self.observe = observe or (lambda pid: g.run_child(['/bin/ps', '-p', str(pid), '-o', 'pid=,pgid=,comm='], env=g.child_environment(), capture_output=True, check=True, timeout=5).stdout)
        self.execute = execute or g.execute
        self.started = time.monotonic(); self.attempted = False
        self.thread = None; self.run = None; self.failure = None; self.pid = None
        self.cancel = threading.Event()
    def poll(self):
        if self.stopping(): return True
        if self.failure is not None: raise self.failure
        stack = self.root / 'native.sample.txt'
        need(not stack.is_symlink() and (not stack.exists() or stack.stat().st_size <= 32 << 20), 'bounded native stack output')
        owned = self.root / 'app' / 'owned.json'
        if not self.attempted and owned.exists() and time.monotonic() - self.started >= 5 and measurement_started(self.root):
            self.attempted = True
            need(self.stable() and not self.stopping() and not stack.exists(), 'fresh sampler admission')
            self.pid = target_pid(read(owned), self.argv, self.cwd, self.observe)
            def work():
                try:
                    self.run = self.execute(['/usr/bin/sample', str(self.pid), '10', '1', '-mayDie', '-file', str(stack)], self.cwd, self.root / 'sampler', lambda: self.stopping() or self.cancel.is_set(), self.launch_stable, timeout=40, limit=1 << 20)
                except BaseException as error: self.failure = error
            self.thread = threading.Thread(target=work, name='owned-native-stack-sampler', daemon=False)
            self.thread.start()
        if self.run is not None:
            need(self.run['error'] is None and self.run['exit_code'] == 0, 'native sample command failed')
        return False
    def launch_stable(self):
        if not self.stable(): return False
        # g.execute calls stable twice before Popen, and once after retirement.
        # Before the sampler owns a PID, recheck its target at the launch boundary.
        if not (self.root / 'sampler/owned.json').exists():
            if self.stopping() or self.cancel.is_set(): return False
            need(target_pid(read(self.root / 'app/owned.json'), self.argv, self.cwd, self.observe) == self.pid, 'same native target at sampler launch')
            if self.stopping() or self.cancel.is_set(): return False
        return True
    def join(self):
        self.cancel.set()
        if self.thread is not None:
            # Never abandon a worker or release the enclosing lease while it
            # owns a sampler. Each wait is short; g.execute enforces the child
            # watchdog and independent retirement. Unexpected delays keep the
            # lease held until the worker has actually finished.
            while self.thread.is_alive(): self.thread.join(.25)
        if self.failure is not None: raise self.failure
        return self.run

def terminal(run):
    return run is not None and run['created'] and run['error'] is None and run['exit_code'] == 0 and not run['observation_errors'] and run['logs_complete'] and run['pins_stable'] and not run['stop_at_exit'] and run['owned']['terminal'] and run['owned']['group_absent'] and not run['owned']['errors']

def main():
    need(len(sys.argv) == 1, 'no runtime overrides')
    review = read(W / 'readiness.json'); plan = read(A / 'cpu-plan.json')
    need(review['execution_ready'] is True and not review['unresolved_findings'], 'separate native sample readiness review')
    pins = review['inputs']; stable = lambda: all(sha(p) == h for p, h in pins.items())
    stopping = lambda: STOP.exists() or (R / 'stop-live').exists()
    need(not R.exists() and not stopping() and stable(), 'new one-shot output and stable input')
    R.mkdir(mode=0o700)
    profile = R / 'sampled.cpu.pprof'
    case = dict(label='gpu-requested-fixed-native-sample', gpu_requested=True, samples=1024, profile=str(profile))
    case['argv'] = [plan['binary']['path'], '-perf', '-rows=1000000', '-perf-samples=1024', '-perf-warmup=128', '-perf-cpu-profile=' + str(profile), '-gpu-scene']
    def clean():
        for root in (C, T):
            need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, timeout=20).decode().strip() == plan['source_commit'] and not subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=root, timeout=20), 'clean exact source boundary')
        need(all(sha(p) == h for p, h in {**plan['source_pins'], **plan['prepared_pins']}.items()), 'full source/prepared identity')
        need(sha(plan['binary']['path']) == plan['binary']['sha256'], 'clean release binary identity')
    d = dict(result='INCOMPLETE', source_commit=plan['source_commit'], producer_sha256=sha(__file__), review_sha256=sha(W / 'readiness.json'), native_runtime_executed=False, physical_input_generated=False, settings_changes=False, ordinary_frame_qualification=False, gpu_execution_qualified=False, scope='Native stack occupancy and process-wide Go CPU diagnostics; sampling adds overhead. Stack occupancy is not CPU time.', error=None, finalization_errors=[])
    try:
        with g.LiveLease() as lease:
            need(lease.held() and not stopping() and stable(), 'lease admission'); clean()
            sampler = Sampler(case['argv'], T / 'examples/loadedgrid', R, stopping, stable)
            try:
                d['app'] = g.execute(case['argv'], sampler.cwd, R / 'app', sampler.poll, stable, timeout=180, limit=8 << 20)
                d['native_runtime_executed'] = d['app']['created']
            finally:
                # Keep lease through both independent process retirements and the worker join.
                d['sampler'] = sampler.join()
            need(terminal(d['app']) and terminal(d['sampler']), 'both owned groups/streams terminal')
            records = [json.loads(line) for line in (R / 'app/stdout').read_bytes().splitlines()]
            samples = cpu.validate(records, case)
            stack = R / 'native.sample.txt'
            need(stack.is_file() and not stack.is_symlink() and 0 < stack.stat().st_size <= 32 << 20, 'bounded nonempty native sample')
            text = stack.read_text()
            need('Process:' in text and 'loadedgrid [' + str(sampler.pid) + ']' in text and 'Call graph:' in text, 'sample belongs to exact owned native PID')
            need(profile.is_file() and not profile.is_symlink() and 0 < profile.stat().st_size <= 64 << 20, 'bounded CPU profile')
            d['validation'] = dict(callbacks=len(samples), native_window=records[1]['native_window'], sampled_pid=sampler.pid, profiles={p.name:dict(bytes=p.stat().st_size, sha256=sha(p)) for p in (profile, stack)})
            clean(); need(lease.held() and stable() and not stopping(), 'terminal source/lease/stops')
            d['lease_held_through_cleanup'] = True
    except BaseException as error: d['error'] = dict(type=type(error).__name__, message=str(error))
    finally:
        try: (R / 'stop-live').touch()
        except BaseException as error: d['finalization_errors'].append(dict(stage='seal', type=type(error).__name__))
        d['result'] = 'PASS_SCOPED_NATIVE_STACK_DIAGNOSTIC' if d['error'] is None and not d['finalization_errors'] else 'FAILED_OR_CANCELED_NATIVE_STACK_DIAGNOSTIC'
        try: print(json.dumps({**{k:v for k,v in d.items() if k not in ('app','sampler')}, 'result':'PENDING_EXCLUSIVE_RECEIPT'}), flush=True)
        except BaseException as error:
            d['finalization_errors'].append(dict(stage='report', type=type(error).__name__)); d['result'] = 'FAILED_OR_CANCELED_NATIVE_STACK_DIAGNOSTIC'
        with (R / 'receipt.json').open('x') as out: out.write(json.dumps(d, indent=2) + '\n')
    need(d['error'] is None and not d['finalization_errors'], 'native stack diagnostic failed or canceled')
if __name__ == '__main__': main()
