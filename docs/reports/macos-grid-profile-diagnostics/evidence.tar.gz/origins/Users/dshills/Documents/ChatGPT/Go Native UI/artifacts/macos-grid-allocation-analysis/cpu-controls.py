"""Non-GUI validator/finalization controls; synthetic flags are not CPU evidence."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys,tempfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('grid_cpu_controls',W/'cpu-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
source=Path('/private/tmp/vellum-grid-intrinsic-native-599442a/runs/candidate-allocation/stdout');base=[json.loads(line)for line in source.read_bytes().splitlines()]
for record in base:record['alloc_profile']=False
for record in[base[0],base[1],base[-1]]:record['cpu_profile']=True
case={'samples':512,'gpu_requested':True,'profile':'/private/tmp/vellum-control.cpu.pprof'};base[0]['cpu_profile_path']=case['profile']
results=[]
def check(name,mutate=None,want=True):
 records=copy.deepcopy(base)
 if mutate:mutate(records)
 accepted=True
 try:n.validate(records,case)
 except ValueError:accepted=False
 assert accepted==want,name;results.append({'name':name,'expected_accept':want,'pass':True})
check('synthetic-valid-current-CPU-identity')
for name,mutate in[
 ('CPU-disabled',lambda r:r[0].update(cpu_profile=False)),
 ('mixed-allocation',lambda r:r[0].update(alloc_profile=True)),
 ('mixed-source-details',lambda r:r[0].update(source_details=True)),
 ('profile-path-mismatch',lambda r:r[0].update(cpu_profile_path='/private/tmp/wrong.pprof')),
 ('wrong-count',lambda r:r[-1].update(samples=511)),
 ('wrong-warmup',lambda r:r[1].update(warmup=64,warm_callbacks=64)),
 ('noninteger-guard',lambda r:r[0].update(window_geometry_guard=True)),
 ('missing-native-window',lambda r:r[1].pop('native_window')),
 ('wrong-GPU-mode',lambda r:r[2].update(gpu_scene_rendering=False)),
 ('duplicate-callback',lambda r:r[2].update(callbacks=2)),
 ('wrong-profile-end',lambda r:r[-1].update(cpu_profile=False)),
]:check(name,mutate,False)
refused=False
try:n.benchmark.validate_records(base,1000000,False,512,False,gpu_scene_rendering=True)
except ValueError as e:refused='diagnostic CPU profile cannot qualify warm timing'in str(e)
assert refused;results.append({'name':'ordinary-runner-refuses-CPU-diagnostics','pass':True})
for fault in ['normal','seal','report','receipt','collision']:
 with tempfile.TemporaryDirectory(prefix='vellum-grid-cpu-finalize-')as directory:
  root=Path(directory);state={'error':None,'cases':[]};calls=[]
  def fail():raise OSError('injected')
  def seal():
   calls.append('seal')
   if fault=='seal':fail()
   (root/'stop-live').touch()
  def report():
   calls.append('report')
   if fault=='report':fail()
  def receipt():
   calls.append('receipt')
   if fault=='receipt':fail()
   with(root/'receipt.json').open('x')as output:output.write(json.dumps(state))
  if fault=='collision':(root/'receipt.json').write_text('preserve')
  n.finalize(root,state,seal,report,receipt)
  assert calls==['seal','report','receipt']
  if fault=='normal':assert state['result']=='PASS_SCOPED_GRID_CPU_PROFILES'and not state['finalization_errors']
  else:assert state['result']=='FAILED_OR_CANCELED_GRID_CPU_PROFILES'and len(state['finalization_errors'])==1
  if fault=='report':assert json.loads((root/'receipt.json').read_text())['result']=='FAILED_OR_CANCELED_GRID_CPU_PROFILES'
  if fault=='collision':assert(root/'receipt.json').read_text()=='preserve'
  results.append({'name':'finalization-'+fault,'pass':True})
d={'result':'PASS_NON_NATIVE_CPU_CAMPAIGN_CONTROLS','native_runtime_executed':False,'controls':results,'inputs':{str(Path(__file__).resolve()):hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),str(W/'cpu-native.py'):hashlib.sha256((W/'cpu-native.py').read_bytes()).hexdigest(),str(source):hashlib.sha256(source.read_bytes()).hexdigest(),str(n.T/'scripts/benchmark-grid.py'):hashlib.sha256((n.T/'scripts/benchmark-grid.py').read_bytes()).hexdigest()}}
with(W/'cpu-controls.json').open('x')as output:output.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'count':len(results)}))
