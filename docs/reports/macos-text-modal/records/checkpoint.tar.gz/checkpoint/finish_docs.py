from pathlib import Path
import json
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
z=json.loads((Q/'result.json').read_bytes());prefix=json.loads((Q/'failed-prefix-validation.json').read_bytes());assert z['result']=='FAILED_OR_CANCELED'and z['post_boundary_pass']and z['run']['exit_code']==1 and z['run']['owned']['group_absent']and(Q/'stop-live').exists()and not prefix['native_case_passed']
r=T/'docs/reports/macos-text-modal/records';r.mkdir(parents=True,exist_ok=False)
names=['focused-v1','focused-v2','style-v2','focused-v3','driver-final','gallery-final','vet-final','build-final','focused-final','style-final','gallery-final-v2','vet-final-v2','build-final-v2','validation-final','validation-final-v2','failure-validation']
checks={n:json.loads((Q/(n+'.json')).read_bytes())for n in names}
(r/'results.json').write_text(json.dumps({'base':'9854e5dd1f7cf1c1c084ab1d9038862954c8bddb','native':z,'failed_prefix':prefix,'checks':checks,'full_driver_qualified_reuse':json.loads((Q/'driver-reuse.json').read_bytes()),'sdk_refreshed':False,'closed_full_mac_gates':[]},indent=2)+'\n')
(T/'docs/reports/macos-text-modal/README.md').write_text('''# Text/editor/dialog catalogue and typed native failure

The normal gallery now has a Text and dialogs page using public editor.Model and
MultilineText. Project fields and the retained preferences dialog share public
constructors with the normal Controls page and the dedicated native consumer.
The intended record remains68Go FIFO inputs/33observations; it is not complete
on native Mac. Run `go run ./cmd/gallery -text-native-check` from the prepared
native module. A free, authorized desktop is required for native testing.

The fresh admitted native case **FAILED**, permanently sealed after35inputs and
19independently validated observations, through editor-tab. Accepted/rejected
single-line edits, disabled-field refusal, supplementary and combining-scalar
insertion, one extended-grapheme Backspace, two Undo/one Redo with exact shared-
journal counts, and actual Tab focus reach their expected states. The final
observed model is Atlas / A😀\né,2field requests,9editor changes,5Undo/1Redo
entries, with no composition. The actual scene is911x709 at162DPI. This prefix
is evidence from a failed case, not a complete native catalogue pass.

After the editor-disabled owner setup, the next measured Frame fails before a
snapshot/observation with actual `source=surface stage=unavailable attempts=1
first=occluded(196609) last=occluded(196609)`. The public typed unavailable error
propagates once; the consumer does not retry it or fabricate a completed frame.
Disabled-editor refusal, every modal step and planned final close remain untested
natively in this case. The producer exits1 in13.365seconds; session Closed=true,
Pending=false,LiveWindows=0,Issued=364. OriginalRefClosed=false and an empty
PostCloseInputError mean the planned success-path close check was not reached.
The owned group53452 is absent and whole source/prepared/SDK/binary post-boundary
checks pass while the desktop lease remains held. The error identifies this
run's unavailable drawable; it does not establish why it was occluded or diagnose
older sealed structural failures.

The full public Manual33-state record passes at160/162DPI, including all modal
steps. It has no native frame capability, so its stale case proves hidden-target
refusal only. An independently authored full-record oracle has one fabricated
positive and13negative controls. A separate failure-prefix oracle authenticates
all19models/35packets, measured centers/focus/order, exact error and retirement,
with one fabricated positive and7negative controls. These synthetic controls are
software evidence. Full driver offscreen race passes; its exact root/dependency
bytes remain unchanged after a gallery-only identity rename, with authenticated
qualified reuse. Current named font regression, full gallery race, driver/gallery
vet and a fresh native binary build pass. Initial passing font-correction logs,
the combined-gallery duplicate notes-ID failure and a validator-name controller
refusal remain preserved, not rewritten as successes.

The adapter now preserves the multiline backend's existing required Monospace
family after theme/node typography. UI family overrides previously caused repeated
correction logs. Size/weight/slant remain honored; proportional family selection
is still unsupported by this backend. A retained-widget theme/override/removal
regression and current software/native prefix have no font-correction diagnostics.
The new text-notes editor ID is independent of the existing notes document page;
both ordinary and compact roots are validated. No upstream preparation or SDK
bytes change.

This is controlled Go1.25.6/GOMAXPROCS2 CPU-scene Go routing over retained SDK
source-built archive786a. Native pixels/presentation, OS/physical input, IME,
human VoiceOver, display transitions, performance/resources and full M2/M5/M3–M7
remain open. There is no OS preference/input-source/clipboard change, SDK refresh,
old-scope replay or public release. Continue at the actual drawable availability/
ownership boundary before another complete structural/text/modal admission;
shown/nonminimized state alone is not a drawable-ready signal. Do not replay this
or older sealed cases or infer availability from a timer/repeated acquisition.

Internal source/controller and exact-plan reviews precede this run. One scoped
Anthropic Claude Sonnet5.5 Prism review and final internal review precede commit.
See [raw result](records/results.json).
''')
p=T/'drivers/cogent/cmd/gallery/README.md';p.write_text(p.read_text()+'''

## Text, editor history and dialogs

The ordinary Text and dialogs page uses public editor.Model with the shared
project field/preferences dialog. Command+Z/Shift+Command+Z use one journal;
Tab traverses focus. The backend requires its monospace family, so UI family
themes do not override it; size, weight and slant still apply.

```sh
go run ./cmd/gallery -text-native-check
```

This exclusive900x700 requested mode authors68Go FIFO inputs/33observations for
text acceptance/rejection/disabled state, exact Unicode/grapheme edits and
Undo/Redo, modal focus/background refusal, retained reopen, Escape/Apply,
hidden/stale refusal and closure with a modal. It shares the90-second scenario,
6-second join and independent1-second final-close bounds and disables process-
local geometry persistence. Typed drawable unavailability stops it without retry.
The native case currently fails after35inputs/19observations on an actual
occluded drawable; disabled-editor/modal/final-close native results remain open.
The complete software record passes at160/162DPI. See the
[text/modal result](../../../../docs/reports/macos-text-modal/README.md).
Go routing is separate from physical input, live IME, VoiceOver and native pixels.
''')
p=T/'specs/editor.md';p.write_text(p.read_text()+'''

## Current renderer font family and gallery integration

The managed multiline backend requires its monospace rich-font family. The
adapter preserves this existing invariant after theme/node styles; general UI
`Typography.Family` overrides do not select a proportional family for
`MultilineText`. Size, weight and slant remain configurable. This avoids repeated
downstream correction after style refresh. The ordinary
[gallery](../drivers/cogent/cmd/gallery/README.md) consumes public editor.Model;
full software routing and the independently validated failed native prefix in
[the text/modal result](../docs/reports/macos-text-modal/README.md) cover exact
Unicode edits, grapheme deletion and one Undo/Redo journal. The complete native
text/modal record remains open after actual drawable unavailability. Go FIFO
establishes no live IME, physical input or native pixels.
''')
for name in ['macos-completion.md','macos-delivery.md']:
 p=T/'specs'/name;p.write_text(p.read_text()+'''

### Text/editor/modal catalogue and unavailable consumer checkpoint

The [text/modal result](../docs/reports/macos-text-modal/README.md) adds an ordinary
public editor page/shared project field and dialog, plus the intended68-input/
33-state consumer. Full software160/162DPI, driver/gallery race, qualified
unchanged-root reuse, affected vet and build pass. The adapter preserves the
multiline renderer's existing required monospace family under UI typography.
The fresh native case **fails** at35inputs/19validated observations through
editor Tab on actual one-attempt occluded196609 acquisition. Typed unavailable
propagation/no retry and tracked session/owned-process cleanup pass. Disabled-
editor/modal/final-close native checks remain unqualified; the exact failed case
is sealed. No full M2/M5/M3–M7 gate closes or SDK/prepared bytes change. Continue
at the actual drawable availability/ownership boundary before another complete
structural/text/modal admission; do not infer readiness from shown state or
retry a sealed case. Earlier failed native cases retain their own unknown causes.
''')
p=T/'specs/control-acceptance.md';s=p.read_text();s+=''''

The [text/editor/modal result](../docs/reports/macos-text-modal/README.md) supplies
N-partial evidence for TextField/MultilineText through `gallery -text-native-check`:
the intended68/33 record fails after35inputs/19independent observations on actual
typed drawable unavailability. Accepted/rejected/disabled-field behavior,
Unicode/grapheme edits, journal Undo/Redo and editor Tab are validated in this
failed prefix. Disabled-editor/modal/final-close native results remain open;
full software33states pass160/162DPI. The case is permanently sealed without
retry. Physical/OS input, live IME, human accessibility and native pixels remain
separate; full M2/M5/M3–M7 and remaining structural acceptance stay open.
''';p.write_text(s)
print('Failure-authenticated report, gallery usage and acceptance specs written; no native pass claimed.')
