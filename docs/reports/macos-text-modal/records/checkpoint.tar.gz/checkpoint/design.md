# Text/editor/dialog catalogue scope

Add the normal gallery Text and dialogs page with an owned public editor.Model,
exact document bytes, shared single-line project field and preferences dialog.
One independently authored33-state68-input native Go FIFO script checks accepted/
rejected/disabled fields; supplementary and combining-scalar insertion, one
extended-grapheme Backspace, two Undo/one Redo with exact shared-journal counters;
Tab; disabled editor; modal focus/background refusal; retained reopen; exactly
one Escape dismissal/one Apply; hidden-target and old-frame refusal; closure
with the modal open. Policies alone are owner setup. No editor bytes/history
are installed by setup. Native keys require actual focus and pointers use current
measured centers. Every case fails closed on typed drawable unavailable.

Public Manual runs the same literal domain record at160/162DPI with independent
actual focus/value/retained-target checks; it has no native frame capability,
so its stale case qualifies hidden-target refusal only. Native Meta+A is verified;
Manual uses the current tested Meta/Control SelectAll binding without modifying it.
A separate Python oracle imports common bounded snapshot schema only; its model
and packet table are independently authored and mutation-tested. Neither software
nor native Go FIFO proves OS/physical input, IME, VoiceOver, native pixels or
presentation. The successful record closes only this named native subcase.

The initial passing Manual scope exposed repeated Lines.SetFontStyle diagnostic
corrections because applyStyle overwrote the multiline renderer invariant with
an inherited UI font family. Preserve rich.Monospace and clear CustomFont for
MultilineText after generic styles while retaining other typography. Existing
backend already enforced this restriction; document proportional-family limits.
Actual retained-widget theme/node override/removal regression passes, and the
repeat full Manual record has zero font correction diagnostics. No prepared
upstream or retainedSDK change. Existing catalogue/native scope seals remain.

Fresh source/controller review, stable race/vet/build/validator controls and a
separately bound exact plan admission precede the one native run. Shared lease,
120s owned process/fourMiB logs/whole boundary and permanent seal are retained.
One scoped Anthropic ClaudeSonnet5.5 Prism review and final internal review
precede commit. No OS settings/input sources/VoiceOver/clipboard changes.
