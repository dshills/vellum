from pathlib import Path
import json,hashlib
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((Q/'driver-final.json').read_bytes());assert r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
changed={k for k,v in r['source_pins'].items()if sha(k)!=v};go=['text_views.go','text_catalogue.go','text_catalogue_offscreen_test.go'];expected={str(T/'drivers/cogent/cmd/gallery'/n)for n in go}|{str(Q/'overlay.json')};assert changed==expected
for n in go:assert sha(Q/'versions'/('before-identity-'+n+'.txt'))==r['source_pins'][str(T/'drivers/cogent/cmd/gallery'/n)]
old=Q/'versions/pre-identity-overlay.json';assert sha(old)==r['source_pins'][str(Q/'overlay.json')]
a=json.loads(old.read_bytes())['Replace'];b=json.loads((Q/'overlay.json').read_bytes())['Replace'];addition={k:v for k,v in b.items()if a.get(k)!=v};assert len(addition)==1 and list(addition.values())==[str(T/'drivers/cogent/cmd/gallery/text_catalogue_test.go')]and all(b.get(k)==v for k,v in a.items())
inputs={str(Q/'driver-final.json'):sha(Q/'driver-final.json'),str(Path(__file__)):sha(__file__),str(old):sha(old),str(Q/'overlay.json'):sha(Q/'overlay.json')}
for k in r['source_pins']:inputs[k]=sha(k)
for stream,info in r['logs'].items():
 p=Q/'driver-final'/stream;assert sha(p)==info['sha256']and p.stat().st_size==info['bytes'];inputs[str(p)]=sha(p)
for n in go:p=Q/'versions'/('before-identity-'+n+'.txt');inputs[str(p)]=sha(p)
z={'qualified_reuse':True,'source_only':True,'full_driver_result':'PASS','original_receipt':str(Q/'driver-final.json'),'original_seconds':r['seconds'],'changed_source_pin_paths':sorted(changed),'new_overlay_mapping':addition,'reason':'Onlycmd/gallery identity literals and new gallery-only validation test changed. Root driver package and all compiled dependencies, including style.go/style_test.go, retain their exact qualified bytes; root does not importcmd/gallery. Whole SDK/prepared/overlay correspondence is separately required for native admission. Current named style test and fullgalleryrerun qualify the changed endpoint. No repeat broadroot suite is necessary for an unrelated gallery ID rename.','inputs':inputs};(Q/'driver-reuse.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps({k:v for k,v in z.items()if k!='inputs'}))
