from audit import *
plan=read(Q/'plan.json');s=source(T);pc=prepared(C);p=prepared(T);sdk=Path(plan['sdk']);sv=vector(sdk)
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD and not git(C,'status','--porcelain')
assert {n:v for n,v in s.items()if n.endswith('.go')}=={n:v for n,v in plan['candidate_source'].items()if n.endswith('.go')}
assert pc==p==plan['prepared']and sv==plan['sdk_files'];overlay_matches(s,p,sdk)
assert all(sha(k)==v for k,v in plan['pins'].items())and sha(plan['binary']['path'])==plan['binary']['sha256']
docs={'drivers/cogent/cmd/gallery/README.md','specs/editor.md','specs/control-acceptance.md','specs/macos-completion.md','specs/macos-delivery.md','docs/reports/macos-text-modal/README.md'};records='docs/reports/macos-text-modal/records/'
changed={n for n,v in s.items()if plan['candidate_source'].get(n)!=v};assert changed==docs|{n for n in s if n.startswith(records)}and set(s)>=set(plan['candidate_source'])
native=read(Q/'result.json');prefix=read(Q/'failed-prefix-validation.json');assert native['post_boundary_pass']and native['native_executed']and native['run']['exit_code']==1 and native['run']['owned']['group_absent']and(Q/'stop-live').exists()and prefix['result']=='VALIDATED_FAILED_PREFIX'and prefix['native_case_passed']is False
r={'all_Go_source':{n:v for n,v in s.items()if n.endswith('.go')},'Go_files':725,'prepared_files':len(p),'prepared_sha256':digest(p),'sdk_files':len(sv),'sdk_sha256':digest(sv),'source_files':len(s),'source_sha256':digest(s),'post_native_changed_paths':sorted(changed),'no_Go_after_native':True,'native_case_passed':False,'failed_prefix':[35,19],'native_scope_sealed':True};(Q/'boundary-final.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='all_Go_source'}))
