from pathlib import Path
import json
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');d=T/'drivers/cogent/cmd/gallery'
result=json.loads((Q/'driver-final.json').read_text());assert result['owned']['terminal']and result['owned']['group_absent']and result['pins_stable']
for name in ['text_views.go','text_catalogue.go','text_catalogue_offscreen_test.go']:
 p=d/name;(Q/'versions'/('before-identity-'+name+'.txt')).write_bytes(p.read_bytes());p.write_text(p.read_text().replace('"notes"','"text-notes"'))
for name in ['validate.py','validation_controls.py']:
 p=Q/name;(Q/'versions'/('before-identity-'+name)).write_bytes(p.read_bytes());p.write_text(p.read_text().replace("'notes'","'text-notes'"))
(d/'text_catalogue_test.go').write_text('''package main

import (
 "testing"
 "github.com/dshills/vellum/ui"
)

func TestTextCatalogueSharesValidOrdinaryControls(t *testing.T) {
 g:=newGallery();ordinary,compact:=g.view(),g.textCatalogueView()
 for _,view:=range []ui.Node{ordinary,compact}{if err:=ui.Validate(view);err!=nil{t.Fatal(err)}}
 for _,id:=range []string{"text-name","text-notes","text-preferences","preferences","dialog-name","apply","text-status"}{
  a,b:=node(ordinary,id),node(compact,id)
  if a.ID==""||a.Kind!=b.Kind||a.Text!=b.Text||a.Editor!=b.Editor||a.Disabled!=b.Disabled{t.Fatal("shared public constructor differs",id)}
 }
 before:=g.textModel();steps:=g.textScript()
 if before!=g.textModel()||len(steps)!=33{t.Fatal("script mutates model or changed record size")}
 packets:=0;seen:=map[string]bool{}
 for _,s:=range steps{
  if s.Label==""||seen[s.Label]{t.Fatal("ambiguous step",s.Label)};seen[s.Label]=true
  switch s.Kind{case "observe":case "click":packets+=2;case "key","refuse","background","retired","stale":packets++;case "replace":packets+=4+len([]rune(s.Text));default:t.Fatal("unknown scripted action",s.Kind)}
 }
 if packets!=68{t.Fatal("native input record changed",packets)}
 if node(ordinary,"notes").Kind!=ui.Column||node(ordinary,"text-notes").Kind!=ui.MultilineText{t.Fatal("document page and editor identity collide")}
}
''')
# The new regression is a compiler input, so the next owned checks bind it explicitly.
(Q/'versions/pre-identity-overlay.json').write_bytes((Q/'overlay.json').read_bytes())
overlay=json.loads((Q/'overlay.json').read_text());sdk=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2');overlay['Replace'][str(sdk/'drivers/cogent/cmd/gallery/text_catalogue_test.go')]=str(d/'text_catalogue_test.go');(Q/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
p=Q/'run.py';s=p.read_text().replace("'text_catalogue_offscreen_test.go']","'text_catalogue_offscreen_test.go','text_catalogue_test.go']").replace("'focused-v3','driver-final','gallery-final','vet-final','build-final'","'focused-final','style-final','gallery-final-v2','vet-final-v2','build-final-v2'").replace('plus6Go changes','plus7Go changes');p.write_text(s)
print('Renamed new editor identity; ordinary+compact validation and record-budget regression added.')
