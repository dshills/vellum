import copy,json,unittest
import validation_controls as c
import validate_failure as v

def fixture():
 d=c.fixture();d.update(Result='FAILED_NATIVE_TEXT',Error=v.ERROR,ActiveStep='editor-disabled',Unavailable=True,OriginalRefClosed=False,PostCloseInputError='');d['Steps']=d['Steps'][:19];d['Inputs']=d['Inputs'][:35];return d
class Controls(unittest.TestCase):
 def check(self,d):return v.validate((json.dumps(d)+'\n').encode(),(v.ERROR+'\n').encode())
 def test_positive(self):self.assertFalse(self.check(fixture())['native_case_passed'])
 def test_negatives(self):
  changes=[lambda d:d.update(Unavailable=False),lambda d:d.update(ActiveStep='modal-open'),lambda d:d['Steps'][-1]['Model'].update(Undo=6),lambda d:d['Inputs'].pop(),lambda d:d['Session'].update(Pending=True),lambda d:d.update(OriginalRefClosed=True),lambda d:next(e for e in d['Inputs'][-1]['Before']['Elements']if e['ID']==d['Inputs'][-1]['Input']['Target']).update(Focused=False)]
  for change in changes:
   with self.subTest(change=change):
    d=fixture();change(d)
    with self.assertRaises((ValueError,KeyError,TypeError)):self.check(d)
if __name__=='__main__':unittest.main(verbosity=2)
