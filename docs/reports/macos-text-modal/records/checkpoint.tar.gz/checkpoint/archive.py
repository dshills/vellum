from audit import *
import gzip,io,tarfile
R=T/'docs/reports/macos-text-modal/records';review=read(Q/'internal-prism-disposition.json');assert review['approved']and not review['unresolved_findings']
files={}
def add(p,n):
 p=Path(p);assert p.is_file()and not p.is_symlink()and n not in files and not n.startswith('/')and '..'not in Path(n).parts;files[n]=p
for n in read(R/'results.json')['checks']:
 add(Q/(n+'.json'),'checks/'+n+'.json')
 for stream in ['stdout','stderr','owned.json']:
  p=Q/n/stream
  if p.is_file():add(p,'checks/'+n+'/'+stream)
for p in sorted((Q/'versions').iterdir()):
 if p.is_file()and p.name!='unused-pass-docs-draft.py':add(p,'versions/'+p.name)
for n in ['stdout','stderr','owned.json']:add(Q/'case'/n,'native/'+n)
for n in ['initial-state.json','design.md','overlay.json','check.py','check_validation.py','check_failure.py','validate.py','validation_controls.py','validate_failure.py','failure_controls.py','driver_reuse.py','driver-reuse.json','run.py','plan.json','result.json','admission.json','stop-live','internal-source-review.json','boundary-initial.json','failed-prefix-validation.json','internal-native-result-review.json','finish_docs.py','review.py','review-scope.json','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','post-provider-docs.json','internal-prism-disposition.json','validation-controller-name-failure.json','apply_editor_identity_fix.py','audit.py','boundary.py','boundary-final.json','archive.py','ready_commit.py','post_promotion.py']:
 add(Q/n,'checkpoint/'+n)
for n in read(Q/'review-scope.json')['paths']:add(T/n,'source/'+n)
for n in read(Q/'post-provider-docs.json')['paths']:add(Q/'provider-source'/n,'provider-source/'+n)
add(R/'results.json','source/docs/reports/macos-text-modal/records/results.json')
add(Q.parent/'macos-acquisition-diagnostics-4ce6ba4/validate.py','retained/common-validator.py')
origins={n:str(p)for n,p in sorted(files.items())};(Q/'member-origins.json').write_text(json.dumps(origins,indent=2)+'\n');add(Q/'member-origins.json','checkpoint/member-origins.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(v['bytes']for v in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(v['bytes']<=10<<20 for v in manifest.values())
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as tar:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=read(Q/'prism.json');a={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'native_case_passed':False,'native_result':'FAILED_UNAVAILABLE_OCCLUDED','inputs_completed':35,'observations_completed':19,'intended_inputs':68,'intended_observations':33,'native_pixels_verified':False,'physical_input_verified':False,'closed_full_mac_gates':[],'provider':{'provider':'anthropic','model':'claude-sonnet-5-5','calls':p['coverage']['llmCalls'],'complete':p['coverage']['complete'],'cli_exit_code':read(Q/'prism-command.json')['exit_code'],'retained_findings':len(p['findings']),'discarded_comments':len(p['discarded']),'dispositions_sha256':sha(Q/'internal-prism-disposition.json')}}
(R/'archive.json').write_text(json.dumps(a,indent=2)+'\n');(Q/'archive-result.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a))
