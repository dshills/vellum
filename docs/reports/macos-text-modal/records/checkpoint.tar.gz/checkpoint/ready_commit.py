from audit import *
import tarfile
R=T/'docs/reports/macos-text-modal/records';review=read(Q/'internal-commit-review.json');scope=read(Q/'final-scope.json');proof=read(Q/'boundary-final.json');provider=read(Q/'review-scope.json');plan=read(Q/'plan.json')
assert review['approved']and review['commit_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items())
assert set(review['inputs'])>={str(Q/n)for n in ['ready_commit.py','post_promotion.py','audit.py','boundary-final.json','final-scope.json','prism.json']}|{str(R/n)for n in ['checkpoint.tar.gz','manifest.json','archive.json']}
assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==HEAD and not git(C,'status','--porcelain')and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
assert hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==scope['staged_diff_sha256']==review['staged_diff_sha256']
assert len(scope['paths'])==17 and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths'])and all(sha(T/n)==v for n,v in scope['files'].items())
assert {n for n,v in provider['files'].items()if sha(T/n)!=v}==set(read(Q/'post-provider-docs.json')['paths'])and all(sha(Q/'provider-source'/n)==v for n,v in provider['files'].items())
p=read(Q/'prism.json');c=p['coverage'];assert c['complete']and c['files']==13 and c['bytes']==53652 and c['llmCalls']==1 and not c['cacheHit']and not c['excluded']and not c['skipped']and not c['truncatedBytes']and not p['suppressed']
assert {f['id']for f in p['findings']}=={'73232be6c4870890'}and {f['finding']['id']for f in p['discarded']}=={'0934053c6cb45a5c'}and read(Q/'prism-command.json')['exit_code']==1
d=read(Q/'internal-prism-disposition.json');assert d['approved']and not d['unresolved_findings']and all(sha(k)==v for k,v in d['inputs'].items())
for n in ['focused-final','style-final','gallery-final-v2','vet-final-v2','build-final-v2','validation-final-v2','failure-validation']:
 r=read(Q/(n+'.json'));assert passing(r)and all(sha(k)==v for k,v in r['source_pins'].items())
reuse=read(Q/'driver-reuse.json');assert reuse['qualified_reuse']and all(sha(k)==v for k,v in reuse['inputs'].items())
s=source(T);assert {n:v for n,v in s.items()if n.endswith('.go')}==proof['all_Go_source']
assert prepared(C)==prepared(T)==plan['prepared']and vector(Path(plan['sdk']))==plan['sdk_files'];overlay_matches(s,plan['prepared'],Path(plan['sdk']))
assert all(sha(k)==v for k,v in plan['pins'].items())and sha(plan['binary']['path'])==plan['binary']['sha256']
native=read(Q/'result.json');prefix=read(Q/'failed-prefix-validation.json');assert native['result']=='FAILED_OR_CANCELED'and native['post_boundary_pass']and native['run']['exit_code']==1 and native['run']['owned']['group_absent']and(Q/'stop-live').exists()and prefix['native_case_passed']is False and(prefix['inputs'],prefix['observations'])==(35,19)
manifest=read(R/'manifest.json');seen=set();expanded=0
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile()and m.name in manifest and m.name not in seen and not m.name.startswith('/')and '..'not in Path(m.name).parts
  seen.add(m.name);expanded+=m.size;assert len(seen)<=256 and expanded<=32<<20 and m.size<=10<<20
  data=tar.extractfile(m).read();data.decode('utf8');assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
a=read(R/'archive.json');assert seen==set(manifest)and a['members']==len(seen)and a['expanded_bytes']==expanded and a['archive_sha256']==sha(R/'checkpoint.tar.gz')and a['manifest_sha256']==sha(R/'manifest.json')and a['archive_bytes']==(R/'checkpoint.tar.gz').stat().st_size<=8<<20
# The original provider diff lives inside the compressed evidence archive.
git(T,'diff','--cached','--check');print(git(T,'commit','-m','Add text editor gallery and preserve multiline font invariant').decode());head=git(T,'rev-parse','HEAD').decode().strip();assert not git(T,'status','--porcelain')and source(T)==s
print(git(C,'merge','--ff-only',head).decode());assert git(C,'rev-parse','HEAD').decode().strip()==head and not git(C,'status','--porcelain')and source(C)==s
r={'commit':head,'canonical_clean':True,'candidate_clean':True,'source_files':len(s),'source_sha256':digest(s),'native_executed':True,'native_case_passed':False,'failed_prefix':[35,19],'goal_complete':False};(Q/'commit-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
