from audit import *
import time
r=read(Q/'internal-native-result-review.json');scope=read(Q/'review-scope.json')
assert r['approved']and not r['unresolved_findings']and all(sha(k)==v for k,v in r['inputs'].items())
assert scope['staged_diff_sha256']==hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()
assert not(Q/'prism.json').exists()
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','160000','--max-diff-bytes','160000','--rules',str(Q/'prism-rules.json'),'--format','json','--out',str(Q/'prism.json')]
a=time.monotonic();p=run_child(argv,cwd=T,timeout=180,capture_output=True,check=False)
(Q/'prism.stdout').write_bytes(p.stdout);(Q/'prism.stderr').write_bytes(p.stderr)
z={'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-a,'staged_diff_sha256':scope['staged_diff_sha256'],'staged_diff_bytes':scope['bytes']};(Q/'prism-command.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps(z))
