from pathlib import Path
import importlib.util,json,signal,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('media_guard',Q.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
paths=[Path(__file__),Q/'validate.py',Q/'validation_controls.py',Q.parent/'macos-acquisition-diagnostics-4ce6ba4/validate.py',Path(h.__file__),h.GUARD];pins={str(p):h.sha(p)for p in paths}
name=sys.argv[1];assert name in ['validation-final','validation-final-v2']and not(Q/name).exists()
def interrupted(signum,frame):raise InterruptedError('media validation signal '+str(signum))
prior=signal.signal(signal.SIGTERM,interrupted)
try:r=h.g.execute(['/usr/bin/python3','-B','-m','unittest','-v','validation_controls'],Q,Q/name,lambda:False,lambda:all(h.sha(p)==v for p,v in pins.items()),timeout=30,limit=1<<20)
finally:signal.signal(signal.SIGTERM,prior)
r['source_pins']=pins;r['native_executed']=False;(Q/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
