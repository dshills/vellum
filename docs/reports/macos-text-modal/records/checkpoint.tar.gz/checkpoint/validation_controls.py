"""Fabricated discrimination controls, never native evidence."""
import copy,json,unittest
import validate as v

def box():return dict(Min=dict(X=10,Y=10),Max=dict(X=110,Y=40))
def element(id,value='',focused=False,enabled=True):return dict(ID=v.node(id),DomainID=id,Parent='',Role='button',Name=id,Value=value,Bounds=box(),Enabled=enabled,Focused=focused,Selected=False)
def snap(frame,w,index):
 els=[]
 if w['Modal']:
  els=[element('preferences'),element('dialog-name',w['Name']),element('apply')]
 else:
  els=[element('text-title'),element('text-preferences'),element('text-name',w['Name'],enabled=not w['DisableName']),element('text-notes',w['Note'],enabled=not w['DisableEditor']),element('text-status',f"Project {w['Name']} / edits {w['Edits']} / undo {w['Undo']} / redo {w['Redo']}")]
 for e in els:e['Focused']=e['ID']==v.node(v.ROWS[index][2])
 return dict(Frame=frame,Size=dict(X=900,Y=700),LogicalDPI=162,Elements=els,Popups=None,Grids=None,Trees=None,Canvases=None)
def fixture():
 d=dict(Event='vellum.text-native.result',Result='PASS_NATIVE_TEXT',Error='',ActiveStep='',Failed=None,Unavailable=False,Session=dict(Started=True,Closed=True,Pending=False,LiveWindows=0,Issued=300),OriginalRefClosed=True,PostCloseInputError='closed',Steps=[],Inputs=[])
 frame=0;old_apply=None
 for i,(label,_,_)in enumerate(v.ROWS):
  w=v.VALUES[i]
  for p in [p for p in v.PACKETS if p['label'].split('/')[0]==label]:
   frame+=1;s=snap(frame,w,i);target=next((e for e in s['Elements']if e['ID']==p['target']),None)
   if target is None and not p['reject']:target=element('temporary');target['ID']=p['target'];s['Elements'].append(target)
   if target is not None:target['Focused']=True;target['Enabled']=not p['reject']
   inp=dict(Frame=frame,Target=p['target'],Type=p['typ'],Code=p['code'],Rune=p['rune'],Modifiers=p['mods'],Button='Left'if p['typ']in['MouseDown','MouseUp']else'NoButton',Position=dict(X=60,Y=25)if p['typ']in['MouseDown','MouseUp']else dict(X=0,Y=0),Delta=dict(X=0,Y=0))
   if p.get('stale'):inp=copy.deepcopy(old_apply)
   if p['label']=='modal-apply/MouseDown':old_apply=copy.deepcopy(inp)
   d['Inputs'].append(dict(Label=p['label'],Before=s,Input=inp,Rejected=p['reject']))
  frame+=1;d['Steps'].append(dict(Label=label,Model=w.copy(),Snapshot=snap(frame,w,i)))
 return d
class Controls(unittest.TestCase):
 def validate(self,d):return v.validate((json.dumps(d)+'\n').encode(),b'')
 def test_positive(self):self.assertEqual(self.validate(fixture())['inputs'],68)
 def test_negatives(self):
  def step(d,label):return next(s for s in d['Steps']if s['Label']==label)
  def inp(d,label):return next(s for s in d['Inputs']if s['Label']==label)
  changes={
   'wrong journal':lambda d:step(d,'editor-undo-delete')['Model'].update(Undo=6),
   'split grapheme':lambda d:step(d,'editor-grapheme-delete')['Model'].update(Note='A😀\ne'),
   'extra callback':lambda d:step(d,'name-rejected')['Model'].update(NameRequests=3),
   'preview committed':lambda d:step(d,'editor-combining')['Model'].update(Composing=True),
   'wrong modal identity':lambda d:step(d,'modal-escape')['Model'].update(Dismisses=2),
   'focus absent':lambda d:next(e for e in step(d,'modal-open')['Snapshot']['Elements']if e['ID']==v.node('dialog-name')).update(Focused=False),
   'background eligible':lambda d:inp(d,'modal-background-refusal')['Before']['Elements'].append(element('text-preferences')),
   'pointer off center':lambda d:inp(d,'editor-focus/MouseDown')['Input'].update(Position=dict(X=11,Y=11)),
   'stale refreshed':lambda d:inp(d,'modal-stale-frame-refusal')['Input'].update(Frame=inp(d,'modal-stale-frame-refusal')['Before']['Frame']),
   'missing packet':lambda d:d['Inputs'].pop(),
   'refusal flag lost':lambda d:inp(d,'name-disabled-refusal').update(Rejected=False),
   'pending terminal':lambda d:d['Session'].update(Pending=True),
   'unavailable':lambda d:d.update(Unavailable=True),
  }
  for name,change in changes.items():
   with self.subTest(name=name):
    d=fixture();change(d)
    with self.assertRaises((ValueError,KeyError,TypeError)):self.validate(d)
if __name__=='__main__':unittest.main(verbosity=2)
