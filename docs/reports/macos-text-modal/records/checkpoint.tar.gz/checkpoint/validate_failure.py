"""Independent validation of the actual failed prefix; never upgrades it to a pass."""
import json
import validate as v
ERROR='cogent: desktop composition: gpu: measured render pass unavailable (source=surface stage=unavailable attempts=1 first=occluded(196609) last=occluded(196609))'

def validate(stdout,stderr):
 v.need(len(stdout)<=4<<20 and stderr==(ERROR+'\n').encode(),'exact typed unavailable console result')
 lines=[l for l in stdout.decode('utf8','strict').splitlines()if l.strip()];v.need(len(lines)==1,'single failed result');d=json.loads(lines[0])
 v.need(d['Event']=='vellum.text-native.result'and d['Result']=='FAILED_NATIVE_TEXT'and d['Error']==ERROR and d['ActiveStep']=='editor-disabled'and d['Unavailable']is True and d['Failed']is None,'exact terminal failure before disabled observation')
 v.need(len(d['Steps'])==19 and len(d['Inputs'])==35,'unmodified failed prefix counts');v.need([s['Label']for s in d['Steps']]==[r[0]for r in v.ROWS[:19]],'authored observation prefix');v.need([i['Label']for i in d['Inputs']]==[p['label']for p in v.PACKETS[:35]],'authored packet prefix')
 extent=None;last=0
 for index,(step,w)in enumerate(zip(d['Steps'],v.VALUES[:19])):
  v.need(step['Model']==w and all(type(step['Model'][k])is type(value)for k,value in w.items()),'literal prefix model '+step['Label']);snap=step['Snapshot'];v.publication(snap,w,index);v.need(snap['Frame']>last,'observed prefix frame order');last=snap['Frame'];size=(snap['Size'],snap['LogicalDPI']);extent=extent or size;v.need(size==extent,'stable prefix scene')
  floor=d['Steps'][index-1]['Snapshot']['Frame']if index else 0;v.need(all(floor<i['Before']['Frame']<snap['Frame']for i in d['Inputs']if i['Label'].split('/')[0]==step['Label']),'prefix input/observation interleaving')
 last=0
 for item,p in zip(d['Inputs'],v.PACKETS[:35]):
  snap=item['Before'];els=v.snapshot(snap);inp=item['Input'];v.need(snap['Frame']>last and(snap['Size'],snap['LogicalDPI'])==extent,'ordered current input snapshot');last=snap['Frame']
  v.need(inp['Frame']==snap['Frame']and inp['Target']==p['target']and inp['Type']==p['typ']and inp['Code']==p['code']and inp['Rune']==p['rune']and inp['Modifiers']==p['mods']and inp['Delta']==dict(X=0,Y=0)and item['Rejected']is p['reject'],'literal input prefix '+p['label'])
  v.need(inp['Button']==('Left'if p['typ']in['MouseDown','MouseUp']else'NoButton')and v.v.point(inp['Position']),'button/point schema')
  e=els.get(p['target']);v.need(e is not None and e['Enabled']==(not p['reject']),'current eligibility')
  if p['typ']=='KeyChord':v.need(e['Focused']and inp['Position']==dict(X=0,Y=0),'actual focused input')
  else:v.need(not v.v.empty(e['Bounds'])and inp['Position']=={k:(e['Bounds']['Min'][k]+e['Bounds']['Max'][k])//2 for k in ['X','Y']},'measured pointer center')
 v.need(d['OriginalRefClosed']is False and d['PostCloseInputError']=='','planned successful close not reached');s=d['Session'];v.need(s['Started']is True and s['Closed']is True and s['Pending']is False and s['LiveWindows']==0 and type(s['Issued'])is int and s['Issued']>=35,'tracked failure retirement')
 return dict(result='VALIDATED_FAILED_PREFIX',native_case_passed=False,observations=19,inputs=35,active_step='editor-disabled',failure='typed drawable unavailable: actual occluded196609,one attempt',scene=extent,session=s,modal_verified=False,disabled_editor_verified=False,physical_input_verified=False,native_pixels_verified=False)
