"""Independent text/modal oracle. Synthetic records never qualify native UI."""
from pathlib import Path
import importlib.util,json
COMMON=Path(__file__).resolve().parents[1]/'macos-acquisition-diagnostics-4ce6ba4/validate.py'
s=importlib.util.spec_from_file_location('catalogue_schema',COMMON);v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
need=v.need;node=v.node;snapshot=v.snapshot
INITIAL=dict(Name='Vellum',Note='Draft\nsecond line\n',Visible='Draft\nsecond line\n',NameRequests=0,Edits=0,Undo=0,Redo=0,Opens=0,Dismisses=0,Applies=0,Modal=False,RejectName=False,DisableName=False,DisableEditor=False,Dirty=False,Composing=False,Busy=False,Invalid=False)
ROWS=[
 ('initial',{},'text-name'),('name-accept',dict(Name='Atlas',NameRequests=1),''),('name-reject-policy',dict(RejectName=True),''),('name-rejected',dict(NameRequests=2),''),('name-disabled',dict(RejectName=False,DisableName=True),''),('name-disabled-refusal',{},''),('name-enabled',dict(DisableName=False),''),('editor-focus',{},'notes'),('editor-select-all',{},'notes'),
 ('editor-replace',dict(Note='A',Edits=1,Undo=1,Dirty=True),'notes'),('editor-supplementary',dict(Note='A😀',Edits=2,Undo=2),'notes'),('editor-newline',dict(Note='A😀\n',Edits=3,Undo=3),'notes'),('editor-base',dict(Note='A😀\ne',Edits=4,Undo=4),'notes'),('editor-combining',dict(Note='A😀\ne\u0301',Edits=5,Undo=5),'notes'),('editor-grapheme-delete',dict(Note='A😀\n',Edits=6,Undo=6),'notes'),('editor-undo-delete',dict(Note='A😀\ne\u0301',Edits=7,Undo=5,Redo=1),'notes'),('editor-undo-combining',dict(Note='A😀\ne',Edits=8,Undo=4,Redo=2),'notes'),('editor-redo-combining',dict(Note='A😀\ne\u0301',Edits=9,Undo=5,Redo=1),'notes'),('editor-tab',{},'text-preferences'),('editor-disabled',dict(DisableEditor=True),'text-preferences'),('editor-disabled-refusal',{},'text-preferences'),('editor-enabled',dict(DisableEditor=False),'text-preferences'),
 ('modal-open',dict(Modal=True,Opens=1),'dialog-name'),('modal-background-refusal',{},'dialog-name'),('modal-name-accept',dict(Name='Modal',NameRequests=3),''),('modal-refocus',{},'dialog-name'),('modal-escape',dict(Modal=False,Dismisses=1),''),('modal-retired-refusal',{},''),('modal-retained-reopen',dict(Modal=True,Opens=2),'dialog-name'),('modal-name-second',dict(Name='Final',NameRequests=4),''),('modal-apply',dict(Modal=False,Applies=1),''),('modal-stale-frame-refusal',{},''),('modal-before-close',dict(Modal=True,Opens=3),'dialog-name'),
]
VALUES=[];w=INITIAL.copy()
for label,delta,focus in ROWS:
 w={**w,**delta};w['Visible']=w['Note'];VALUES.append(w)
PACKETS=[]
def key(label,target,code,rune=0,mods=''):PACKETS.append(dict(label=label,target=node(target),typ='KeyChord',code=code,rune=rune,mods=mods,reject=False))
def click(label,target):
 for typ in ['MouseDown','MouseUp']:PACKETS.append(dict(label=label+'/'+typ,target=node(target),typ=typ,code='Unknown',rune=0,mods='',reject=False))
def replace(label,target,text):
 click(label,target);key(label+'/select-all',target,'A',97,'Meta')
 for i,r in enumerate(text):key(label+'/rune-'+str(i),target,'Unknown',ord(r))
 key(label+'/commit',target,'ReturnEnter')
def refuse(label,target,stale=False):PACKETS.append(dict(label=label,target=node(target),typ='MouseDown',code='Unknown',rune=0,mods='',reject=True,stale=stale))
replace('name-accept','text-name','Atlas');replace('name-rejected','text-name','Rejected');refuse('name-disabled-refusal','text-name');click('editor-focus','notes');key('editor-select-all','notes','A',97,'Meta');key('editor-replace','notes','A',65);key('editor-supplementary','notes','Unknown',ord('😀'));key('editor-newline','notes','ReturnEnter');key('editor-base','notes','E',101);key('editor-combining','notes','Unknown',0x301);key('editor-grapheme-delete','notes','Backspace');key('editor-undo-delete','notes','Z',122,'Meta');key('editor-undo-combining','notes','Z',122,'Meta');key('editor-redo-combining','notes','Z',90,'Meta|Shift');key('editor-tab','notes','Tab');refuse('editor-disabled-refusal','notes');click('modal-open','text-preferences');refuse('modal-background-refusal','text-preferences');replace('modal-name-accept','dialog-name','Modal');click('modal-refocus','dialog-name');key('modal-escape','dialog-name','Escape');refuse('modal-retired-refusal','dialog-name');click('modal-retained-reopen','text-preferences');replace('modal-name-second','dialog-name','Final');click('modal-apply','apply');refuse('modal-stale-frame-refusal','apply',True);click('modal-before-close','text-preferences')
need(len(ROWS)==33 and len(PACKETS)==68,'fixed text record counts')
def publication(s,w,i):
 els=snapshot(s)
 def get(id):
  e=els.get(node(id));need(e is not None and not v.empty(e['Bounds']),'visible '+id);return e
 focus=ROWS[i][2]
 if focus:need(get(focus)['Focused'],'actual observed focus '+focus)
 if w['Modal']:
  for id in ['preferences','dialog-name','apply']:get(id)
  need(get('dialog-name')['Value']==w['Name']and get('dialog-name')['Enabled'],'modal accepted field')
  for id in ['text-name','notes','text-preferences']:
   e=els.get(node(id));need(e is None or not e['Enabled'],'modal background eligibility '+id)
 else:
  get('text-title');get('text-preferences')
  for id,want in [('text-name',w['Name']),('notes',w['Note']),('text-status',f"Project {w['Name']} / edits {w['Edits']} / undo {w['Undo']} / redo {w['Redo']}")]:need(get(id)['Value']==want,'accepted publication '+id)
  need(get('text-name')['Enabled']==(not w['DisableName'])and get('notes')['Enabled']==(not w['DisableEditor']),'disabled text/editor state')
  for id in ['dialog-name','apply']:
   e=els.get(node(id));need(e is None or not e['Enabled']or v.empty(e['Bounds']),'retired dialog eligible '+id)
 return els

def validate(stdout,stderr):
 need(len(stdout)<=4<<20 and stderr==b'','bounded stdout and no console errors');lines=[line for line in stdout.decode('utf8','strict').splitlines()if line.strip()];need(len(lines)==1,'one result and no hidden diagnostics');d=json.loads(lines[0])
 need(d['Event']=='vellum.text-native.result'and d['Result']=='PASS_NATIVE_TEXT'and not d['Error']and not d['ActiveStep']and d['Failed']is None and d['Unavailable']is False,'completed text case')
 need([s['Label']for s in d['Steps']]==[r[0]for r in ROWS]and[p['Label']for p in d['Inputs']]==[p['label']for p in PACKETS],'exact authored record order')
 extent=None;last=0
 for i,(step,w)in enumerate(zip(d['Steps'],VALUES)):
  need(step['Model']==w and all(type(step['Model'][k])is type(value)for k,value in w.items()),'literal model '+step['Label']);s=step['Snapshot'];publication(s,w,i);need(s['Frame']>last,'observation frame order');last=s['Frame'];size=(s['Size'],s['LogicalDPI']);extent=extent or size;need(size==extent,'stable scene extent')
  floor=d['Steps'][i-1]['Snapshot']['Frame']if i else 0
  need(all(floor<p['Before']['Frame']<s['Frame']for p in d['Inputs']if p['Label'].split('/')[0]==step['Label']),'input/observation order')
 last=0;old_apply=None
 for item,p in zip(d['Inputs'],PACKETS):
  s=item['Before'];els=snapshot(s);inp=item['Input'];need((s['Size'],s['LogicalDPI'])==extent and s['Frame']>last,'current input frame order');last=s['Frame']
  need(inp['Target']==p['target']and inp['Type']==p['typ']and inp['Code']==p['code']and inp['Rune']==p['rune']and inp['Modifiers']==p['mods']and inp['Delta']==dict(X=0,Y=0)and item['Rejected']is p['reject'],'literal input '+p['label'])
  need(inp['Button']==('Left'if p['typ']in['MouseDown','MouseUp']else'NoButton')and v.point(inp['Position']),'typed button/position')
  if p.get('stale'):
   need(old_apply is not None and inp==old_apply and inp['Frame']<s['Frame'],'original stale apply capability retained');continue
  need(inp['Frame']==s['Frame'],'current frame capability')
  e=els.get(p['target'])
  if p['reject']:
   need(e is None or not e['Enabled'],'actual refused eligibility '+p['label']);continue
  need(e is not None and e['Enabled'],'current admitted target')
  if p['typ']=='KeyChord':need(e['Focused']and inp['Position']==dict(X=0,Y=0),'actual key focus')
  else:need(not v.empty(e['Bounds'])and inp['Position']=={k:(e['Bounds']['Min'][k]+e['Bounds']['Max'][k])//2 for k in ['X','Y']},'measured pointer center')
  if p['label']=='modal-apply/MouseDown':old_apply=inp.copy()
 need(d['OriginalRefClosed']is True and d['PostCloseInputError']=='closed','original ref retirement');s=d['Session'];need(s['Started']is True and s['Closed']is True and s['Pending']is False and s['LiveWindows']==0 and type(s['Issued'])is int and s['Issued']>=68,'session retirement')
 return dict(result='PASS_NATIVE_TEXT',observations=33,inputs=68,name_requests=4,editor_changes=9,undo=5,redo=1,dialog_opens=3,dismisses=1,applies=1,session=s,physical_input_verified=False,native_pixels_verified=False)
