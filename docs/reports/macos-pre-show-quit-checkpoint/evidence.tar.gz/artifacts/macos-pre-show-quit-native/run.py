"""Four fixed lifecycle checks; separate from performance qualification."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, signal, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = W.parent / 'macos-presentation-display104'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
def need(ok, message):
    if not ok: raise ValueError(message)
def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def write(path, data):
    with path.open('x') as f: f.write(json.dumps(data, indent=2)+'\n')
def objects(text):
    result = []; decoder = json.JSONDecoder()
    while text.strip():
        text = text.lstrip(); value, end = decoder.raw_decode(text)
        result.append(value); text = text[end:]
    return result
CASES = [('candidate-ordinary', 'candidate', 'UNTAGGED_ORDINARY_CLOSE'),
         ('candidate-after-show', 'candidate', 'UNTAGGED_CPU_BATCH_DEADLINE'),
         ('candidate-pre-show', 'candidate', 'UNTAGGED_PRE_SHOW_CPU_BATCH_DEADLINE'),
         ('baseline-pre-show', 'baseline', 'UNTAGGED_PRE_SHOW_CPU_BATCH_DEADLINE')]
def main():
    plan = read(W/'plan.json'); admission = read(W/'admission.json')
    need(admission['approved'] and admission['plan_sha256'] == sha(W/'plan.json'), 'root admission')
    need(not (W/'result.json').exists() and not (W/'stop-live').exists(), 'fresh four-case scope')
    c = load('native104boundary', P/'controller.py'); c.configure_binding()
    g = load('native_existing_owner', c.GUARD)
    lease = load('native_existing_lease', c.LEASE)
    baseline = read(P/'plan.json'); output = Path(plan['output'])
    need(not output.exists(), 'fresh output'); output.mkdir(mode=0o700)
    pins = {**plan['pins'], str(W/'plan.json'): sha(W/'plan.json'), str(W/'admission.json'): sha(W/'admission.json')}
    stop = [False]; deadline = datetime.datetime.fromisoformat(admission['last_launch_utc'])
    def flag(number, frame): stop[0] = True
    previous = {n: signal.signal(n, flag) for n in [signal.SIGINT, signal.SIGTERM]}
    result = {'result': 'FAILED_NATIVE_LIFECYCLE', 'cases': {}, 'error': None, 'performance_qualified': False}
    try:
        with lease.LiveLease() as held:
            geometry = c.geometry_state()
            def stopping(): return stop[0] or (W/'stop-live').exists() or not held.held() or datetime.datetime.now(datetime.timezone.utc) >= deadline
            def stable(): return all(sha(p) == v for p,v in pins.items()) and not stopping()
            try:
                for name, variant, case in CASES:
                    c.boundary(baseline); need(stable(), 'fresh source/SDK/lease/pins after scan')
                    tmp = output/(name+'-tmp'); tmp.mkdir(mode=0o700)
                    profile = '(version 1)(allow default)(deny network* (remote ip) (local ip))' + ''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))' for p in [c.C, c.T, c.SDK, c.CORE_DATA, P]) + ''.join('(deny file-write* (literal '+json.dumps(p)+'))' for p in pins)
                    env = {'PATH':'/usr/bin:/bin:/usr/sbin:/sbin', 'HOME':str(Path.home()), 'TMPDIR':str(tmp), 'GOMAXPROCS':'2', 'LANG':os.environ.get('LANG','en_US.UTF-8')}
                    argv = ['/usr/bin/sandbox-exec', '-p', profile, '/usr/bin/env', '-i', *[k+'='+v for k,v in env.items()], plan['binaries'][variant]['path'], '-case', case]
                    receipt = g.execute(argv, c.SDK/'drivers/cogent', output/name, stopping, stable, timeout=15, limit=1<<20)
                    result['cases'][name] = {'receipt': receipt}; write(output/(name+'-receipt.json'), receipt)
                    need(receipt['error'] is None and not receipt['observation_errors'] and receipt['logs_complete'] and receipt['pins_stable'] and not receipt['stop_at_exit'] and receipt['owned']['terminal'] and receipt['owned']['group_absent'] and not receipt['owned']['errors'], 'complete owned lifecycle observation')
                    records = objects((output/name/'stdout').read_text()); stderr = (output/name/'stderr').read_text()
                    if name == 'baseline-pre-show':
                        need(receipt['exit_code'] == 1 and len(records) == 1 and records[0].get('Event') == 'vellum.untagged-pre-show.entry' and records[0]['ShownAtEntry'] is False and records[0]['Credit']['Enabled'] and records[0]['Credit']['Active'] > 0 and records[0]['Credit']['NativePending'] == 0 and records[0]['Credit']['CPUFinished'] is False and records[0]['Credit']['Closed'] is False and records[0]['Credit']['Failure'] == '' and 'FAIL native untagged lifecycle hard watchdog; cleanup unqualified' in stderr, 'actual old-driver bounded failure counterfactual')
                        result['cases'][name]['result'] = 'EXPECTED_OLD_DRIVER_FAILURE_NO_NORMAL_CLEANUP'
                    else:
                        need(receipt['exit_code'] == 0 and len(records) == (2 if name == 'candidate-pre-show' else 1), 'corrected driver return/report')
                        report = records[-1]
                        need(report['Case'] == case and report['Result'] == 'PASS_NATIVE_UNTAGGED_LIFECYCLE' and report['Error'] == '' and report['RunReturned'] and report['WorkerJoined'] and report['Closed'] and report['CleanupObserved'] and not report['FrameMetricsEnabled'] and not report['PresentationMetricsEnabled'] and not report['LostPresentedCallbackVerified'], 'normal native lifetime evidence')
                        if name == 'candidate-pre-show': need(records[0]['ShownAtEntry'] is False and report['PreShow']['ShownAtEntry'] is False and report['PreShow']['Completed'], 'actual pre-show work')
                        result['cases'][name].update(result='PASS_NATIVE_LIFECYCLE', report=report)
                    c.boundary(baseline); need(c.geometry_state() == geometry and stable(), 'after-case source/SDK/geometry/lease'); print(name+' '+result['cases'][name]['result'], flush=True)
                result['result'] = 'PASS_NATIVE_QUIT_REGRESSION_WITH_OLD_DRIVER_NEGATIVE'
            except BaseException as error: result['error'] = {'type':type(error).__name__, 'message':str(error)}
            finally:
                try:
                    c.boundary(baseline); need(c.geometry_state() == geometry and held.held() and all(sha(p) == v for p,v in pins.items()) and not stop[0] and not (W/'stop-live').exists(), 'final source/SDK/geometry/lease/cancellation'); result['final_boundary_stable'] = True
                except BaseException as error: result.update(result='FAILED_NATIVE_LIFECYCLE', final_boundary_error={'type':type(error).__name__, 'message':str(error)})
    except BaseException as error: result.update(result='FAILED_NATIVE_LIFECYCLE', error={'type':type(error).__name__, 'message':str(error)})
    finally:
        (W/'stop-live').touch(); write(W/'result.json', result)
        for n,h in previous.items(): signal.signal(n,h)
    print(json.dumps({k:result.get(k) for k in ['result','error','final_boundary_stable']}))
    need(result['result'] == 'PASS_NATIVE_QUIT_REGRESSION_WITH_OLD_DRIVER_NEGATIVE', 'native regression scope failed; no retry')
if __name__ == '__main__': main()
