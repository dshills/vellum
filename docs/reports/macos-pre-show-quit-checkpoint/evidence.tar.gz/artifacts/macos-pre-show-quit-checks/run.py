"""Fixed headless overlay checks only. No native mode; root reviews inputs/plan first."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;X=W.parent;P=X/'macos-presentation-display104'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,why):
 if not ok:raise ValueError(why)
def write(path,value):
 with path.open('x')as f:f.write(json.dumps(value,indent=2)+'\n')
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load('reviewed104boundary',P/'controller.py');g=load('reviewed_owned_executor',c.GUARD)
RUNTIME={'drivers/cogent/driver.go','drivers/cogent/native_quit.go','drivers/cogent/native_quit_test.go'}
TARGET='drivers/cogent/cmd/window-lifetime-smoke/main.go'
PHASES=['candidate-race','candidate-vet','baseline-graph','baseline-build','baseline-metadata','candidate-graph','candidate-build','candidate-metadata']
def bound(record):
 need(type(record)is dict and set(record)=={'path','sha256'},'explicit frozen input record');p=Path(record['path'])
 need(p.is_absolute()and p.is_file()and all(not n.is_symlink()for n in[p,*p.parents])and p.stat().st_size<=16<<20,'bounded regular input')
 need(sha(p)==record['sha256'],'frozen input hash');return p
def prepare():
 need(not(W/'plan.json').exists(),'fresh preparation');b=c.configure_binding();baseline=read(P/'plan.json');c.boundary(baseline)
 supplied=read(W/'inputs.json');need(set(supplied)=={'proposal','consumer','runtime_files'}and set(supplied['runtime_files'])==RUNTIME,'fixed input scope')
 proposal=bound(supplied['proposal']);consumer=bound(supplied['consumer']);runtime={n:bound(v)for n,v in supplied['runtime_files'].items()}
 declared=read(proposal);need(declared['base_head']==b['head']and declared['base_binding_sha256']==sha(P/'binding.json'),'proposal actual104basis')
 need(declared['runtime_files']=={n:sha(p)for n,p in runtime.items()}and declared['consumer']['path']==str(consumer)and declared['consumer']['sha256']==sha(consumer),'exact declared runtime/consumer outputs')
 need(declared['Core104_unchanged']is True and declared['prepared_count']==6328,'no prepared/runtimeoverlay expansion')
 expected_source={str(proposal):sha(proposal),str(consumer):sha(consumer),**{str(p):sha(p)for p in runtime.values()}}
 need(not(c.SDK/'drivers/cogent/native_quit.go').exists()and not(c.SDK/'drivers/cogent/native_quit_test.go').exists(),'new overlay helpers must be absent from SDK')
 need(c.sha(c.LIB)==c.LIB_SHA,'actual source-built native archive')
 out=Path('/private/tmp/vellum-pre-show-quit-checks-'+b['head'][:7]);need(not out.exists(),'fresh private output');out.mkdir(mode=0o700)
 overlays={'baseline':{str(c.SDK/TARGET):str(consumer)},'candidate':{str(c.SDK/TARGET):str(consumer),**{str(c.SDK/n):str(p)for n,p in runtime.items()}}}
 for name,mapping in overlays.items():write(out/(name+'-overlay.json'),{'Replace':mapping})
 pins={**expected_source,**{str(p):sha(p)for p in[Path(__file__),W/'inputs.json',P/'controller.py',P/'plan.json',P/'binding.json',c.GUARD,c.HELPER,c.GO,c.LIB,out/'baseline-overlay.json',out/'candidate-overlay.json']}}
 tests=re.findall(r'^func (Test[A-Za-z0-9_]+)\(t \*testing.T\)',runtime['drivers/cogent/native_quit_test.go'].read_text(),re.M);need(tests==declared['new_controlled_test_methods']and len(tests)==len(set(tests))==10,'exact10new top-level test declarations')
 prior=X/'macos-display-backpressure-correction/headless/actual-result-review.json';need(read(prior)['commands']['driver-race']['top_level']=={'PASS':639,'FAIL':0,'SKIP':0},'actual driver baseline');pins[str(prior)]=sha(prior)
 plan={'scope':'HEADLESS_ONLY_NO_NATIVE_MODE','head':b['head'],'binding_sha256':sha(P/'binding.json'),'output':str(out),'SDK':str(c.SDK),'baseline':str(P/'plan.json'),'pins':pins,'phases':PHASES,'new_test_methods':tests,'expected_race_PASS':639+len(tests),'overlay_preimage':{'path':str(c.SDK/TARGET),'sha256':sha(c.SDK/TARGET)},'runtime_driver_preimage':{'path':str(c.SDK/'drivers/cogent/driver.go'),'sha256':sha(c.SDK/'drivers/cogent/driver.go')},'readonly_inputs':[str(proposal.parent),str(consumer.parent)],'native_executed':False}
 c.boundary(baseline);need(all(sha(p)==v for p,v in pins.items()),'preparation input drift');write(W/'plan.json',plan);print(json.dumps({'plan_sha256':sha(W/'plan.json'),'phases':PHASES,'native_admission':False}))
def objects(text):
 d=json.JSONDecoder();items=[]
 while text.strip():value,end=d.raw_decode(text.lstrip());items.append(value);text=text.lstrip()[end:]
 return items
def inspect(name,receipt,out,plan):
 text=(out/name/'stdout').read_text();sdk=Path(plan['SDK'])
 if name=='candidate-race':
  counts={key:len(re.findall(r'^--- '+key+r': ',text,re.M))for key in['PASS','FAIL','SKIP']};need(counts=={'PASS':plan['expected_race_PASS'],'FAIL':0,'SKIP':0},'exact complete driver population');return counts
 expected={'cogentcore.org/core':'drivers/cogent/build/upstream','github.com/dshills/vellum':'.','github.com/go-text/typesetting':'drivers/cogent/build/typesetting',**{'github.com/oliverbestmann/webgpu/libs-'+n:'drivers/cogent/build/libs-'+n for n in['android','darwin','ios','linux','windows']}}
 expected={k:str((sdk/v).resolve())for k,v in expected.items()}
 if name.endswith('-graph'):
  actual={};seen=set()
  for m in objects(text):
   need(type(m)is dict and type(m.get('Path'))is str and m['Path']not in seen,'unique graph module');seen.add(m['Path'])
   if m.get('Replace',{}).get('Dir'):actual[m['Path']]=str(Path(m['Replace']['Dir']).resolve())
  need(actual==expected,'exact8SDKlocal replacements');return actual
 if name.endswith('-metadata'):
  info=json.loads(text);need(info['GoVersion']=='go1.25.6'and info['Path']=='github.com/dshills/vellum/drivers/cogent/cmd/window-lifetime-smoke','actual compiler/main');settings={}
  main=info['Main'];need(main['Path']=='github.com/dshills/vellum/drivers/cogent'and main['Version']=='(devel)'and not main.get('Replace'),'actual driver main module')
  local={};seen=set()
  for m in info['Deps']:
   need(type(m)is dict and type(m.get('Path'))is str and m['Path']not in seen,'unique compiled dependency');seen.add(m['Path'])
   if 'Replace'in m:
    replacement=m['Replace'];need(type(replacement)is dict and type(replacement.get('Path'))is str and replacement.get('Version')=='(devel)'and m['Path']in expected,'actual local compiled replacement')
    destination=str((sdk/'drivers/cogent'/replacement['Path']).resolve());need(destination==expected[m['Path']],'compiled dependency escapes/misattributes SDK');local[m['Path']]=destination
  need({'cogentcore.org/core','github.com/dshills/vellum','github.com/go-text/typesetting','github.com/oliverbestmann/webgpu/libs-darwin'}<=set(local),'actual Darwin4compiled local modules')
  for item in info['Settings']:
   need(type(item)is dict and set(item)<={'Key','Value'}and type(item.get('Key'))is str and item['Key']not in settings and type(item.get('Value',''))is str,'strict build setting');settings[item['Key']]=item.get('Value','')
  need(settings.get('GOOS')=='darwin'and settings.get('GOARCH')=='arm64'and settings.get('CGO_ENABLED')=='1'and settings.get('-race')!='true'and settings.get('-tags')=='vellum_native_checks'and '-N'not in settings.get('-gcflags','')and '-l'not in settings.get('-gcflags',''),'optimized tagged native metadata');return {'settings':settings,'compiled_local_replacements':local,'main':main}
 return None
def run():
 plan=read(W/'plan.json');admit=read(W/'admission.json');need(admit['approved']and admit['plan_sha256']==sha(W/'plan.json'),'exact root headless admission');need(plan['phases']==PHASES and plan['scope']=='HEADLESS_ONLY_NO_NATIVE_MODE','fixed phases')
 need(not(W/'result.json').exists()and not(W/'stop-checks').exists(),'fresh single attempt');c.configure_binding();baseline=read(P/'plan.json');need(plan['head']==c.HEAD and plan['binding_sha256']==sha(P/'binding.json'),'current104association');out=Path(plan['output']);logs=out/'logs';logs.mkdir();stop=[False]
 def flag(sig,frame):stop[0]=True
 previous={s:signal.signal(s,flag)for s in[signal.SIGINT,signal.SIGTERM]};pins={**plan['pins'],str(W/'plan.json'):sha(W/'plan.json'),str(W/'admission.json'):sha(W/'admission.json')}
 def stopping():return stop[0]or(W/'stop-checks').exists()
 def stable():return all(sha(p)==v for p,v in pins.items())and not stopping()
 profile='(version 1)(allow default)(deny network* (remote ip) (local ip))'+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in[c.C,c.T,c.SDK,c.CORE_DATA,P,*plan['readonly_inputs']])+''.join('(deny file-write* (literal '+json.dumps(p)+'))'for p in pins)
 env={k:v for k,v in os.environ.items()if k in['HOME','USER','LANG']};env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin',CGO_ENABLED='1',GOMAXPROCS='2');result={'result':'FAILED_HEADLESS_CHECKS','commands':{},'error':None,'native_executed':False,'plan_sha256':sha(W/'plan.json'),'head':plan['head']}
 try:
  for name in PHASES:
   c.boundary(baseline);need(stable(),'prephase source/stop guard');variant='baseline'if name.startswith('baseline-')else'candidate';overlay=str(out/(variant+'-overlay.json'));binary=out/(variant+'-lifecycle')
   if name=='candidate-race':args=['test','-v','-race','-count=1','-p=1','-tags=offscreen','-timeout=900s','-overlay='+overlay,'./...'];timeout=960
   elif name=='candidate-vet':args=['vet','-p=1','-tags=offscreen','-overlay='+overlay,'./...'];timeout=180
   elif name.endswith('-graph'):args=['list','-overlay='+overlay,'-m','-json','all'];timeout=60
   elif name.endswith('-build'):args=['build','-p=1','-tags=vellum_native_checks','-overlay='+overlay,'-o',str(binary),'./cmd/window-lifetime-smoke'];timeout=240
   else:args=['version','-m','-json',str(binary)];timeout=30
   argv=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/bin/sh',str(c.HELPER),*args]
   receipt=g.execute(argv,c.SDK/'drivers/cogent',logs/name,stopping,stable,timeout=timeout,limit=1<<20);result['commands'][name]=receipt;write(out/(name+'-receipt.json'),receipt)
   need(c.passed(receipt),'owned phase failed; retain outputs/no retry');summary=inspect(name,receipt,logs,plan);result.setdefault('observations',{})[name]=summary;c.boundary(baseline);need(stable(),'postphase boundary/stop');print(name+' PASS',flush=True)
  result['binaries']={v:{'path':str(out/(v+'-lifecycle')),'bytes':(out/(v+'-lifecycle')).stat().st_size,'sha256':sha(out/(v+'-lifecycle'))}for v in['baseline','candidate']};result['result']='PASS_FIXED_HEADLESS_OVERLAY_CHECKS'
 except BaseException as e:result['error']={'type':type(e).__name__,'message':str(e)}
 finally:
  try:c.boundary(baseline);need(stable(),'final fullboundary/pins/cancellation');result['final_boundary_stable']=True
  except BaseException as e:result.update(result='FAILED_HEADLESS_CHECKS',final_boundary_error={'type':type(e).__name__,'message':str(e)})
  (W/'stop-checks').touch();write(W/'result.json',result)
  for s,h in previous.items():signal.signal(s,h)
 print(json.dumps({k:result.get(k)for k in['result','error','final_boundary_stable']}));need(result['result']=='PASS_FIXED_HEADLESS_OVERLAY_CHECKS','no retry after failed check')
if __name__=='__main__':
 need(sys.argv[1:]in[['prepare'],['run']],'headless prepare/run only');prepare()if sys.argv[1]=='prepare'else run()
