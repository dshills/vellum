"""Only the three cases never launched by the preserved failed first scope."""
from pathlib import Path
import hashlib, importlib.util, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
OLD = W.parent / 'macos-pre-show-quit-native'
OWNER_SHA = 'c2eb34001b3a9696a678d4a066d61b4a677ceb838e6be1024cab7550e3fdfa79'
CASES = [('candidate-pre-show', 'candidate', 'UNTAGGED_PRE_SHOW_CPU_BATCH_DEADLINE'),
         ('baseline-pre-show', 'baseline', 'UNTAGGED_PRE_SHOW_CPU_BATCH_DEADLINE'),
         ('candidate-after-show', 'candidate', 'UNTAGGED_CPU_BATCH_DEADLINE')]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())

def main():
    if len(sys.argv) != 1: raise ValueError('fixed continuation only')
    if sha(OLD/'run.py') != OWNER_SHA: raise ValueError('original reviewed owner changed')
    plan = read(W/'plan.json'); previous = read(OLD/'plan.json'); failed = read(OLD/'result.json')
    if failed['result'] != 'FAILED_NATIVE_LIFECYCLE' or list(failed['cases']) != ['candidate-ordinary']:
        raise ValueError('continuation requires exactly the first ordinary case attempted')
    if plan['binaries'] != previous['binaries'] or plan['output'] == previous['output']:
        raise ValueError('same binaries and separate output required')
    for path, digest in {**previous['pins'], **plan['preserved_failed_scope']}.items():
        if plan['pins'].get(path) != digest or sha(path) != digest:
            raise ValueError('original scope/source input changed')
    if plan['cases'] != [c[0] for c in CASES]: raise ValueError('three unrun cases only')
    spec = importlib.util.spec_from_file_location('reviewed_original_native_owner', OLD/'run.py')
    owner = importlib.util.module_from_spec(spec); spec.loader.exec_module(owner)
    owner.W = W
    owner.CASES = CASES
    owner.main()

if __name__ == '__main__': main()
