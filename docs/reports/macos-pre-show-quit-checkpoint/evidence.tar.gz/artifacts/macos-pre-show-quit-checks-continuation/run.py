"""Seven previously unrun headless phases; actual successful race is retained, never rerun."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-pre-show-quit-checks'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,why):
 if not ok:raise ValueError(why)
need(sha(OLD/'run.py')=='ce2dd4484d4311eee30f262e55323ec7ff6a2cbf4a6161beb83596bb328f21b5','exact original frozen seven-phase implementation')
s=importlib.util.spec_from_file_location('sealed_headless_overlay_runner',OLD/'run.py');o=importlib.util.module_from_spec(s);s.loader.exec_module(o)
PHASES=['candidate-vet','baseline-graph','baseline-build','baseline-metadata','candidate-graph','candidate-build','candidate-metadata']
need(o.PHASES==['candidate-race',*PHASES],'exact original remaining phases')
def prepare():
 need(not(W/'plan.json').exists(),'fresh continuation plan');binding=o.c.configure_binding();prior=o.read(OLD/'plan.json');r=o.read(OLD/'result.json');o.c.boundary(o.read(o.P/'plan.json'))
 need(prior['head']==binding['head']and prior['binding_sha256']==sha(o.P/'binding.json'),'same actual source/SDK association')
 need(r['result']=='FAILED_HEADLESS_CHECKS'and r['error']=={'type':'ValueError','message':'exact complete driver population'}and list(r['commands'])==['candidate-race']and r['native_executed']is False and r['final_boundary_stable']is True,'preserved controller count failure only')
 need(r['plan_sha256']==sha(OLD/'plan.json'),'actual old plan binding')
 oldout=Path(prior['output']);receipt_path=oldout/'candidate-race-receipt.json';receipt=o.read(receipt_path)
 need(receipt==r['commands']['candidate-race']and o.c.passed(receipt),'actual complete passing owned race receipt')
 audit_path=OLD/'first-phase-actual-review.json';audit=o.read(audit_path)
 need(audit['approved']is True and audit['accepted_actual_first_phase']is True and audit['controller_result_preserved']=='FAILED_HEADLESS_CHECKS','independent actual-race audit required')
 need(audit['plan_sha256']==sha(OLD/'plan.json')and audit['result_sha256']==sha(OLD/'result.json')and audit['receipt_sha256']==sha(receipt_path),'audit actual plan/result/receipt bindings')
 need(audit['root_package_PASS']==649 and audit['total_PASS']==782 and audit['FAIL']==0 and audit['SKIP']==0,'exact audited root649 plus133 other package methods')
 pins={**prior['pins'],**{str(p):sha(p)for p in[Path(__file__),OLD/'plan.json',OLD/'result.json',OLD/'admission.json',OLD/'stop-checks',receipt_path,audit_path]}}
 for channel,info in receipt['logs'].items():
  path=oldout/'logs/candidate-race'/channel;need(path.stat().st_size==info['bytes']and sha(path)==info['sha256'],'actual raw race output');pins[str(path)]=sha(path)
 text=(oldout/'logs/candidate-race/stdout').read_text();need({k:len(re.findall(r'^--- '+k+r': ',text,re.M))for k in['PASS','FAIL','SKIP']}=={'PASS':782,'FAIL':0,'SKIP':0},'actual complete recursive suite population')
 for method in prior['new_test_methods']:need(len(re.findall(r'^--- PASS: '+re.escape(method)+r' ',text,re.M))==1,'every ten new root controls passed once')
 need(audit['proposal_sha256']==pins[str(OLD.parent/'macos-pre-show-quit-correction/proposal.json')],'same reviewed candidate proposal')
 for path,digest in audit.get('inputs',{}).items():need(sha(path)==digest,'audited evidence drift');pins[path]=digest
 owned=oldout/'logs/candidate-race/owned.json';pins[str(owned)]=sha(owned)
 out=Path(str(oldout)+'-continuation');need(not out.exists(),'fresh continuation output');out.mkdir(mode=0o700)
 for name in['baseline','candidate']:
  source=oldout/(name+'-overlay.json');target=out/source.name;target.write_bytes(source.read_bytes());need(sha(source)==sha(target),'identical overlay');pins[str(target)]=sha(target)
 plan={**prior,'output':str(out),'phases':PHASES,'pins':pins,'prior_race':{'audit':str(audit_path),'audit_sha256':sha(audit_path),'old_result_sha256':sha(OLD/'result.json'),'root_PASS':649,'recursive_PASS':782,'FAIL':0,'SKIP':0,'rerun':False,'controller_status':'FAILED_HEADLESS_CHECKS'},'continuation_only':True}
 o.c.boundary(o.read(o.P/'plan.json'));need(all(sha(p)==h for p,h in pins.items()),'continuation input drift');o.write(W/'plan.json',plan);print(json.dumps({'plan_sha256':sha(W/'plan.json'),'phases':PHASES,'native_admission':False}))
if __name__=='__main__':
 need(sys.argv[1:]in[['prepare'],['run']],'headless prepare/run only')
 if sys.argv[1:]==['prepare']:prepare()
 else:
  plan=o.read(W/'plan.json');need(plan['continuation_only']is True and plan['phases']==PHASES and plan['prior_race']['rerun']is False,'fixed seven-phase continuation')
  o.W=W;o.PHASES=PHASES;o.run()
