# Tray lifecycle V4 correction review

Result: NEEDS_FIX. The frozen 31-file V4 snapshot resolves V1 nil-panic detection, accepted tray candidate tracking, asynchronous chooser-completion ACK, patch-order registration, actual C-string reply fixture coverage and retired owner-queued menu actions. The V1 certificate remains unchanged.

One remaining cancellation consumer at services_darwin.m109–114 has no producer/consumer pool or exception fence. If panel cancel/orderOut raises before completion acknowledges, the operation can remain retained and the exception escapes that dispatched block. This contradicts the explicit shared consumer-pool/terminal acknowledgement contract. The parent is repairing cancellation ACK separately from exceptional still-owned panel lifetime, with bounded retained panel ownership and persistent cleanup error. This is source-path analysis, not an observed Cocoa failure.

The core cleanup Goexit caveat remains outside the stated panic guarantee. No tests, builds, native functions, UI/pasteboard/settings, provider or Git operations were executed. V4 commands or final SDK results are not qualified by this source certificate; V5 will have separate approval.
