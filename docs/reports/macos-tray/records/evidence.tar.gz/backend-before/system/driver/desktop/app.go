// Copyright 2019 Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// based on golang.org/x/exp/shiny:
// Copyright 2015 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package desktop

import (
	"errors"
	"image"
	"log"
	"runtime"
	"time"

	"cogentcore.org/core/gpu"
	"cogentcore.org/core/gpu/gpudraw"
	"cogentcore.org/core/system"
	"cogentcore.org/core/system/composer"
	"cogentcore.org/core/system/driver/base"
	"github.com/go-gl/glfw/v3.4/glfw"
	"github.com/oliverbestmann/webgpu/wgpuglfw"
)

func Init() {
	// some operating systems require us to be on the main thread
	runtime.LockOSThread()

	TheApp.InitGPU()
	base.Init(TheApp, &TheApp.App)
}

// TheApp is the single [system.App] for the desktop platform
var TheApp = &App{AppMulti: base.NewAppMulti[*Window]()}

// App is the [system.App] implementation for the desktop platform
// NativeAttachment receives main-thread focus and teardown while the view is valid.
// Methods must not reenter the UI or call RunOnMain, which would deadlock.
type NativeAttachment interface {
	Focus(bool)
	Close()
}

type App struct {
	// lastScreenPoll is protected by Mu; each window has its own paint loop.
	lastScreenPoll time.Time

	// NativeAttach is configured before creating any windows. It runs on the
	// native main thread after surface creation and before show. On error the
	// partial attachment (if any) is closed and the window/resources are released.
	NativeAttach func(*Window) (NativeAttachment, error)
	base.AppMulti[*Window]

	// GPU is the system GPU used for the app
	GPU *gpu.GPU

	// Monitors are pointers to the glfw monitors corresponding to Screens.
	Monitors []*glfw.Monitor
}

// SendEmptyEvent sends an empty, blank event to global event processing
// system, which has the effect of pushing the system along during cases when
// the event loop needs to be "pinged" to get things moving along..
func (a *App) SendEmptyEvent() {
	desktopEvents.wake(glfw.PostEmptyEvent)
}

// MainLoop starts running event loop on main thread (must be called
// from the main thread).
func (a *App) MainLoop() {
	defer func() {
		a.StopMain()
		desktopEvents.stop(glfw.Terminate)
	}()
	queue, stopped := a.InitMainQueue()
	for {
		select {
		case <-stopped:
			return
		case f := <-queue:
			if !a.ExecuteMain(f) {
				return
			}
		default:
			glfw.WaitEventsTimeout(0.1) // timeout is essential on linux
		}
	}
}

// InitGPU initializes glfw, gpu, and the screens.
func (a *App) InitGPU() {
	if err := desktopEvents.start(glfw.Init); err != nil {
		log.Fatalln("system/driver/desktop failed to initialize glfw:", err)
	}
	glfw.SetMonitorCallback(a.MonitorChange)
	a.GetScreens()
}

func (a *App) NewWindow(opts *system.NewWindowOptions) (system.Window, error) {
	var window system.Window
	var err error
	if !a.RunOnMainIfOpen(func() { window, err = a.newWindowOnMain(opts) }) {
		return nil, base.ErrMainStopped
	}
	return window, err
}

// One admitted callback owns the complete native creation transaction. It does
// not redispatch to the main queue from inside that callback.
func (a *App) newWindowOnMain(opts *system.NewWindowOptions) (system.Window, error) {
	if a.NWindows() == 0 && system.UpdateLogicalDPIScaleFunc != nil {
		if ScreenDebug {
			log.Println("app first new window calling UpdateLogicalDPIScaleFunc")
		}
		system.UpdateLogicalDPIScaleFunc()
	}

	if opts == nil {
		opts = &system.NewWindowOptions{}
	}
	sc := a.ScreenSnapshot(opts.Screen)
	if sc == nil {
		return nil, errors.New("desktop: no screen available for new window")
	}
	opts.Fixup()

	w := &Window{
		WindowMulti:  base.NewWindowMulti[*App, *composer.ComposerDrawer](a, opts),
		ScreenWindow: sc.Name,
	}
	w.This = w

	var err error
	func() {
		err = w.newGlfwWindow(opts, sc)
	}()
	if err != nil {
		return nil, err
	}

	func() {
		surf := gpu.Instance().CreateSurface(wgpuglfw.GetSurfaceDescriptor(w.Glw))
		var fbsz image.Point
		fbsz.X, fbsz.Y = w.Glw.GetFramebufferSize()
		if fbsz == (image.Point{}) {
			fbsz = opts.Size
		}
		if a.GPU == nil {
			a.GPU = gpu.NewGPU(surf)
		}
		// no multisample and no depth
		sf := gpu.NewSurface(a.GPU, surf, fbsz, 1, gpu.UndefinedType)
		w.Draw = gpudraw.NewDrawer(a.GPU, sf)
		w.Compose = &composer.ComposerDrawer{Drawer: w.Draw}
		w.composerPointer.Store(w.Compose)
	}()

	if a.NativeAttach != nil {
		func() {
			w.Native, err = a.NativeAttach(w)
			if err != nil {
				w.releaseNativeResources()
			}
		}()
		if err != nil {
			return nil, err
		}
	}
	// w.Flgs.SetFlag(true, system.Focused) // starts out focused

	a.Mu.Lock()
	a.Windows = append(a.Windows, w)
	a.Mu.Unlock()

	w.Glw.SetPosCallback(w.Moved)
	w.Glw.SetSizeCallback(w.WinResized)
	w.Glw.SetFramebufferSizeCallback(w.FbResized)
	w.Glw.SetCloseCallback(w.OnCloseReq)
	// w.Glw.SetRefreshCallback(w.refresh)
	w.Glw.SetFocusCallback(w.Focused)
	w.Glw.SetIconifyCallback(w.Iconify)

	w.Glw.SetKeyCallback(w.KeyEvent)
	w.Glw.SetCharModsCallback(w.CharEvent)
	w.Glw.SetMouseButtonCallback(w.MouseButtonEvent)
	w.Glw.SetScrollCallback(w.ScrollEvent)
	w.Glw.SetCursorPosCallback(w.CursorPosEvent)
	w.Glw.SetCursorEnterCallback(w.CursorEnterEvent)
	w.Glw.SetDropCallback(w.DropEvent)
	w.Glw.SetInputMode(glfw.LockKeyMods, glfw.True)

	if !opts.StartHidden {
		w.Glw.Show()
	}
	func() {
		w.updateGeometry()
		w.constrainFrameOnMain(false) // constrain full frame on open
	}()

	go w.WinLoop() // start window's own dedicated publish update loop

	return w, nil
}

func (a *App) Clipboard(win system.Window) system.Clipboard {
	a.Mu.Lock()
	a.CtxWindow = win.(*Window)
	a.Mu.Unlock()
	return TheClipboard
}

func (a *App) Cursor(win system.Window) system.Cursor {
	a.Mu.Lock()
	a.CtxWindow = win.(*Window)
	a.Mu.Unlock()
	return TheCursor
}
