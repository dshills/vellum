"""Bind the reviewed tray checkpoint to offscreen receipts, never runtime acceptance."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
repo=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-tray')
report=repo/'docs/reports/macos-tray';records=report/'records'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((phase/'source-v5.json').read_text());files=source['sources']
assert len(files)==31 and all(sha(repo/n)==h for n,h in files.items())
assert set(subprocess.check_output(['git','diff','--name-only'],cwd=repo).decode().splitlines()) <= {'docs/reports/README.md'}
review=json.loads((phase/'source-review-v5.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings'] and review['files']==files
prepared=json.loads((phase/'prepared-identity.json').read_text())['files']
current={p.relative_to(repo/'drivers/cogent/build').as_posix():sha(p)for m in ['upstream','typesetting']for p in sorted((repo/'drivers/cogent/build'/m).rglob('*'))if p.is_file()}
assert current==prepared and len(current)==6174
checks=['root-final','root-vet','driver-v5','driver-vet-v5','backend-final','native-build-v5','prep-regression','duplicate-ack-probe','sdk-contract','sdk-vet','sdk-package-v5','sdk-check-v5','build-metadata-v5','native-load-commands-v5']
process={}
for n in checks:
 d=json.loads((phase/(n+'.json')).read_text());assert d['exit_code']==0 and d['error'] is None and d['live_tests'] is False,n
 for stream in ['stdout','stderr']:assert sha(phase/(n+'.'+stream))==d[stream+'_sha256']
 process[n]=d
sdk=json.loads((phase/'sdk-v5-identity.json').read_text());manifest=json.loads((phase/'private-sdk-v5-manifest.json').read_text())
assert sdk['verified_manifest_files']==6933 and sdk['source_freeze_all_match']
assert all(manifest['files'][n]==h for n,h in files.items()) and sha(phase/'private-sdk-v5.tar.gz')==sdk['sha256']
sdk_check=json.loads((phase/'sdk-check-v5.stdout').read_text())
assert sdk_check['archive_sha256']==sdk['sha256'] and sdk_check['verified_files']==6933 and sdk_check['digest_verified_against_expected'] and sdk_check['path_contains_spaces']
assert sdk_check['native_runtime']=='not executed' and sdk_check['public_distribution_audit']=='not certified'
prism=json.loads((phase/'prism-v1/prism.json').read_text());pp=json.loads((phase/'prism-v1/process.json').read_text());coverage=prism['coverage']
assert coverage['complete'] and coverage['files']==31 and coverage['chunks']>0 and not coverage['excluded'] and not coverage['skipped'] and coverage['truncatedBytes']==0
assert pp['source_index_stable'] and pp['exit_code']==1 and len(prism['findings'])==1 and pp['before']==files and pp['after']==files
assert pp['prism_sha256']==sha(phase/'prism-v1/prism.json')
disposition=json.loads((phase/'prism-disposition.json').read_text())
assert disposition['result']=='APPROVED_DISPOSITION' and disposition['status']=='RESOLVED_NO_CODE_CHANGE' and not disposition['unresolved_findings']
assert disposition['finding_id']==prism['findings'][0]['id']=='cc7bc1313447fdbf' and disposition['files']==files
assert disposition['prism_sha256']==sha(phase/'prism-v1/prism.json') and disposition['source_certificate']['sha256']==sha(phase/'source-review-v5.json')
probe=json.loads((phase/'duplicate-ack-provenance.json').read_text())
assert probe['final_source_unchanged'] and probe['index_unchanged'] and probe['temporary_fixture_removed']
assert probe['probe_sha256']==sha(phase/'duplicate-ack-probe.go.txt') and not (repo/'drivers/cogent/prism_duplicate_ack_probe_test.go').exists()
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
q={'result':'PASS_OFFSCREEN_MAC_TRAY','base_commit':source['base_commit'],'source':files,'prepared':prepared,'process':process,'sdk':sdk,'sdk_check':sdk_check,'prism_findings':1,'prism_findings_resolved':True,'prism_raw_exit':pp['exit_code'],'prism_disposition_sha256':sha(phase/'prism-disposition.json'),'duplicate_ack_probe':probe,'prism_coverage':coverage,'source_review_sha256':sha(phase/'source-review-v5.json'),'native_binary_sha256':sha(phase/'workbench-v5'),'live_tests':False,'status_bar_access':False,'pasteboard_access':False,'whole_macos_completion':False,'performance_acceptance':False,'distribution_audit':'pending'}
(phase/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(parents=True,exist_ok=False)
excluded={'workbench','workbench-final','workbench-v4','private-sdk.tar.gz','private-sdk-v5.tar.gz','workbench-v5'}
members={p.relative_to(phase).as_posix():{'size':p.stat().st_size,'sha256':sha(p)}for p in sorted(phase.rglob('*'))if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts}
archive=records/'evidence.tar.gz'
with archive.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0)as z,tarfile.open(fileobj=z,mode='w',format=tarfile.PAX_FORMAT)as t:
 for name in members:
  data=(phase/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';t.addfile(info,io.BytesIO(data))
index={'schema':1,'members':members,'archive_sha256':sha(archive),'excluded_binary_and_sdk_payloads':sorted(excluded)}
(records/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
checkpoint={'result':q['result'],'base_commit':q['base_commit'],'qualification_sha256':sha(phase/'qualification.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':1,'prism_findings_resolved':True,'archive':{'sha256':sha(archive),'members':len(members)},'live_tests':False,'status_bar_access':False,'pasteboard_access':False,'macos_completion':False}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
(report/'README.md').write_text(f'''# Mac tray and native service lifetime checkpoint

Vellum adds optional `app.TrayServices` and `Application.Tray()` with one Mac
menu-bar status item, title/tooltip/accessibility name, bounded PNG/template icon
and registered-command menu. Existing Services implementations remain compatible.
Updates reuse the owned native object; clearing removes only that item. This
extends the existing windowed lifecycle: final-window close still ends the app.
Capability flags describe the compiled transport, not native acceptance.

PNG input is at most 1 MiB/256×256; complete worker decoding rejects corrupt
bodies before native installation. Detached straight RGBA fits 18×18 points
without distorting aspect ratio. Menus allow 128 entries; labels/enabled state
are owner snapshots, and activation rechecks command availability and current
native ownership on owner drain. Replaced/cleared/shutdown tray and application
menu actions cannot activate stale commands. Accessible names resolve explicitly
or from tooltip/title; unnamed icon-only items are refused.

Chooser, application-menu and tray dispatch share eight process-wide credits,
separate from clipboard's four. Admission precedes encoding; canceled callers
retain their credit until native acknowledgement. JSON is at most 1 MiB, C string
results 64 KiB before Go copying. Worker/consumer autorelease pools explicitly
own detached data. Callback tokens do not wrap. Requests already accepted may
change native presentation despite caller cancellation; no rollback is promised.
The [contract](../../../specs/tray.md) records the exact limits and lifecycle.

Owned backend patch45 registers up to 16 main-thread cleanup hooks. Terminal
cleanup detaches hooks under the lock, runs them in LIFO order and guarantees
remaining hooks/termination despite a callback panic, including legacy nil panic.
The Mac hook closes service admission, cancels owned panels, restores the original
application menu and removes the status item before GLFW termination. Earlier
asynchronous cleanup errors remain observable; driver/model errors are joined.
Callback execution time and broader GPU/panic recovery are outside this contract.

Fifteen new test functions and extended existing service tests cover public
compatibility and bounds, full PNG
decoding/detached pixels, owner capture, actual Objective-C JSON/bitmap/alpha/
aspect conversion and producer retention/release, canceled admission/terminal
ACK, actual bounded C-to-Go reply copying, tray/menu callback retirement and
availability, independent public consumer scenarios, and injected backend
cleanup order/removal/capacity/panic/termination and injected native dismissal exceptions. Eleven preparation regression
tests pass, including exact pin/patch order. No fixture creates NSStatusItem,
opens NSMenu/panels, reads/writes clipboard or changes OS preferences.

Root race/vet, the complete final offscreen native-module race suite, driver vet,
owned desktop cleanup race tests, public consumer race/vet and native workbench
compilation pass. Root/backend/public-consumer receipts precede V5 only where
their source bytes are unchanged. The final V5 native suite/build includes the
menu retirement and native dismissal correction. Earlier checks and one failed test expectation
(disabled-command error reporting) remain distinct; that fixture was corrected.
The executable was compiled only, with Go 1.27.2 and local macOS 26.0 minimum/
SDK 27.0 load commands. This does not qualify older Macs. Duplicate-libobjc linker
warnings are preserved, without treating them as runtime evidence.

The private SDK verifies all 6933 manifest files with trusted archive digest
`{sdk['sha256']}`. All 31 final source hashes match. A relocated path with spaces,
in-SDK module replacements, external module checks, generated consumer race/vet/
build and full public consumer scenarios pass. Native runtime was not executed;
public distribution is not certified. All 6174 freshly prepared upstream and
typesetting files match this checkpoint.

Initial internal review preserves the legacy nil-panic, accepted-candidate
ownership/tracking, asynchronous completion ACK and preparation-order findings.
Bounded corrections add explicit panic detection, publish accepted native item
ownership before fallible setters, catch/retire panel completion failures, fence panel cancellation while bounding retained failed panels, fix
patch-order expectations and guard queued application-menu activation. This is
source-level review; no runtime leak is asserted. Final independent internal
review approves all 31 hashes. One Prism run uses Anthropic Claude Sonnet 5.5 with
complete 31-file/{coverage['chunks']}-chunk coverage. Its raw exit1 and one medium
conditional duplicate-ACK finding are preserved. Independent disposition confirms
that the existing Go bridge ignores retired completions, atomically retires each
operation once and never reuses exhausted tokens. No code change or repeated
provider review is needed; no finding remains unresolved. A separate temporary
adversarial Go fixture confirms repeated/concurrent C-reply acknowledgements,
stale-token isolation and exhaustion refusal under the race detector. Its source
and terminal receipt are preserved; final source/index remain unchanged and the
fixture is excluded from the final SDK.

The user's computer-free constraint remains in force. Actual status-item
visibility/object/bar-position retention, menu clicks/keyboard operation,
VoiceOver, dark-mode template appearance, mixed-DPI behavior and cleanup through
real window/loop termination remain deferred. No native UI/input/GPU/frame
performance or sustained-load acceptance occurred. Full Mac/P10, native human
acceptance, performance and public distribution gates remain open; this is one
reviewed implementation checkpoint toward the Mac framework.

[Checkpoint](records/checkpoint.json), [raw evidence](records/evidence.tar.gz)
and [member index](records/archive-index.json) bind this offscreen scope.
''')
print(json.dumps({'result':q['result'],'members':len(members),'archive_sha256':sha(archive),'report_sha256':sha(report/'README.md'),'checkpoint_sha256':sha(records/'checkpoint.json')}))
