"""Run one temporary adversarial fixture; preserve the final source/index unchanged."""
import hashlib,json,sys,subprocess
from pathlib import Path
repo=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-tray')
sys.path.insert(0,str(repo/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=json.loads((phase/'source-v5.json').read_text())['sources']
assert all(sha(repo/n)==h for n,h in files.items())
before=subprocess.check_output(['git','diff','--cached','--binary'],cwd=repo)
fixture=repo/'drivers/cogent/prism_duplicate_ack_probe_test.go'
payload=(phase/'duplicate-ack-probe.go.txt').read_bytes()
with fixture.open('xb')as f:f.write(payload)
try:
 result=run_child(['python3',str(phase/'run.py'),'duplicate-ack-probe','drivers/cogent','go','test','-race','-tags','offscreen','-run','^TestNativeServiceDuplicateAcknowledgementsProbe$','.'],cwd=repo,env=child_environment(runtime=False),timeout=240)
finally:
 assert fixture.read_bytes()==payload
 fixture.unlink()
 after=subprocess.check_output(['git','diff','--cached','--binary'],cwd=repo)
 record={'final_source_unchanged':all(sha(repo/n)==h for n,h in files.items()),'index_unchanged':before==after,'temporary_fixture_removed':not fixture.exists(),'probe_sha256':sha(phase/'duplicate-ack-probe.go.txt'),'scope':'Actual Go C-reply callback exercised with repeated/concurrent acknowledgements, stale prior tokens, and allocator exhaustion. Temporary test source excluded from final SDK/source set; no Cocoa service/UI dispatch.'}
 (phase/'duplicate-ack-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
 assert record['final_source_unchanged'] and record['index_unchanged'] and record['temporary_fixture_removed']
sys.exit(result.returncode)
