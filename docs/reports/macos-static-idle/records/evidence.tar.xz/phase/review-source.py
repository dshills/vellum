from pathlib import Path
import hashlib,json
from run import ROOT,PHASE
names=['docs/reports/macos-static-idle/README.md','specs/macos-completion.md']
(PHASE/'checkpoint-source.json').write_text(json.dumps({'sources':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}},indent=2)+'\n')
