from pathlib import Path
import hashlib,io,json,tarfile
from run import ROOT,PHASE,sha,identity
q=json.loads((PHASE/'qualification.json').read_text());assert q['result']=='PASS_SCOPED_STATIC_IDLE' and q['runs']==5
assert q['raw_samples_sha256']==sha(PHASE/'raw-samples.jsonl') and q['results_sha256']==sha(PHASE/'results.json') and q['producer_sha256']==sha(PHASE/'measure.py')
r=json.loads((PHASE/'static-idle-v1.json').read_text());assert r['exit_code']==0 and r['error'] is None and r['source_prepared_stable']
assert identity()['prepared']==json.loads((PHASE/'baseline.json').read_text())['prepared']
sources=json.loads((PHASE/'checkpoint-source.json').read_text())['sources'];assert len(sources)==2 and all(sha(ROOT/n)==h for n,h in sources.items())
review=json.loads((PHASE/'final-source-review.json').read_text());assert not review['findings'] and review['result']=='APPROVED_SOURCE'
assert review['reviewed_file_sha256']=={str(ROOT/n):h for n,h in sources.items()}
for f,h in review.get('reviewed_artifact_sha256',{}).items():assert sha(f)==h
process=json.loads((PHASE/'prism-v1/process.json').read_text());prism=json.loads((PHASE/'prism-v1/prism.json').read_text())
assert process['exit_code']==1 and process['error'] is None and process['source_index_stable'] and process['before']==process['after']==sources
assert prism['coverage']['complete'] and prism['coverage']['files']==2 and len(prism['findings'])==1 and prism['findings'][0]['id']=='12cdb0e882d65f3b'
records=ROOT/'docs/reports/macos-static-idle/records';records.mkdir()
suffixes={'.py','.txt','.json','.jsonl','.stdout','.stderr','.log','.md'}
members={'phase/'+f.relative_to(PHASE).as_posix():f.read_bytes() for f in sorted(PHASE.rglob('*')) if f.is_file() and f.suffix in suffixes}
members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz') as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
checkpoint={**q,'result':'REVIEWED_SCOPED_MAC_STATIC_IDLE','base_commit':identity()['commit'],'source':sources,'prepared_files':6202,'internal_review_sha256':sha(PHASE/'final-source-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':1,'prism_finding_disposition':'Pending internal verification of committed archive closure','prism_coverage_complete':True,'prism_sha256':sha(PHASE/'prism-v1/prism.json'),'process_receipt_sha256':sha(PHASE/'static-idle-v1.json'),'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),'archive_members':len(index),'archive_index_verified':True,'seal_producer_sha256':sha(__file__)}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n');print('Sealed',len(index),'members',checkpoint['archive_sha256'])
