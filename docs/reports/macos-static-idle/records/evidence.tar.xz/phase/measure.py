from pathlib import Path
import datetime, importlib.util, json, os, subprocess, time
from run import ROOT, PHASE, baseline, sha
spec=importlib.util.spec_from_file_location('native_benchmark', ROOT/'scripts/benchmark-native.py')
b=importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
before=baseline(); binary=PHASE/'hello'; digest=sha(binary)
build=json.loads((PHASE/'build-hello-v1.json').read_text()); assert build['exit_code']==0 and build['source_prepared_stable']
results=[]; original_sample=b.sample; raw=[]
def sample(pid):
    value=original_sample(pid)
    record={'run':len(results)+1,'pid':pid,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic_ns':time.monotonic_ns(),'sample':value}
    raw.append(record)
    with (PHASE/'raw-samples.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
    return value
b.sample=sample
for index in range(5):
    print('START',index+1,flush=True)
    result=b.run(binary,100,10); result['run']=index+1;results.append(result)
    (PHASE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    assert before==baseline() and sha(binary)==digest
    print('DONE',index+1,result['idle_cpu_percent_one_core'],flush=True)
assert len(raw)==10 and all(r['idle_sample_seconds']>=60 for r in results)
qualification={'result':'PASS_SCOPED_STATIC_IDLE','runs':5,'sampled_seconds':[r['idle_sample_seconds'] for r in results], 'idle_cpu_percent_one_core':[r['idle_cpu_percent_one_core'] for r in results], 'binary_sha256':digest,'baseline_sha256':sha(PHASE/'baseline.json'), 'raw_samples_sha256':sha(PHASE/'raw-samples.jsonl'),'results_sha256':sha(PHASE/'results.json'),'producer_sha256':sha(__file__),'scope':'Five independent ordinary hello processes; 60-second settled CPU/RSS observations within each 100-second idle. Startup endpoint is verified GPU readback, not first interactive presentation. Not primary1000-control workbench, wakeup/present counts, occluded/minimized, overnight/P11 or total native-memory qualification.'}
(PHASE/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n');print(json.dumps(qualification),flush=True)
