"""Fast-forward the reviewed local checkpoint, prepare pinned dependencies and verify bytes."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
scratch=Path('/private/tmp/vellum-large-data');canonical=Path('/Users/dshills/Development/projects/Vellum');phase=Path('/private/tmp/vellum-macos-static-idle');out=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-static-idle')
sys.path.insert(0,str(scratch/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
def git(root,*args):
 r=run_child(['git','-C',str(root),*args],env=env,capture_output=True,timeout=60);assert r.returncode==0,r.stderr;return r.stdout.decode().strip()
checkpoint=json.loads((scratch/'docs/reports/macos-static-idle/records/checkpoint.json').read_text());base=checkpoint['base_commit']
assert checkpoint['result']=='REVIEWED_SCOPED_MAC_STATIC_IDLE' and checkpoint['prism_coverage_complete'] and checkpoint['prism_findings']==0
assert not git(scratch,'status','--porcelain') and not git(canonical,'status','--porcelain')
assert git(canonical,'rev-parse','HEAD')==base
commit=git(scratch,'rev-parse','HEAD');assert git(scratch,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
names=git(scratch,'ls-files','-z').split('\0');expected={n:sha(scratch/n) for n in names if n}
prepared_expected=json.loads((phase/'baseline.json').read_text())['prepared']
assert all(expected.get(n)==h for n,h in checkpoint['source'].items())
out.mkdir(exist_ok=False,parents=True)
record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'source_files':len(expected),'scope':'Reviewed test-only static-idle observations: five independent native processes, each60s settledCPU/RSS. Not fullworkbench/wakeup/presentation/native-memory/P11 acceptance.'};started=time.monotonic()
try:
 git(canonical,'fetch',str(scratch),commit);assert git(canonical,'rev-parse','FETCH_HEAD')==commit
 git(canonical,'merge','--ff-only','FETCH_HEAD')
 with (out/'prepare.stdout').open('xb') as so,(out/'prepare.stderr').open('xb') as se:
  r=run_child(['python3','prepare.py'],cwd=canonical/'drivers/cogent',env=env,stdout=so,stderr=se,timeout=180)
 record['prepare_exit_code']=r.returncode;assert r.returncode==0
 prepared={f.relative_to(canonical/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting'] for f in sorted((canonical/'drivers/cogent/build'/m).rglob('*')) if f.is_file()}
 record.update({'prepared_files':len(prepared),'prepared_exact':prepared==prepared_expected,'tracked_exact':all(sha(canonical/n)==h for n,h in expected.items()),'canonical_clean':not git(canonical,'status','--porcelain'),'scratch_clean':not git(scratch,'status','--porcelain'),'archive_sha256':sha(canonical/'docs/reports/macos-static-idle/records/evidence.tar.xz')})
 assert len(prepared)==6202 and all(record[k] for k in ['prepared_exact','tracked_exact','canonical_clean','scratch_clean'])
 assert record['archive_sha256']==checkpoint['archive_sha256']
 record['result']='PASS_CANONICAL_PROMOTION'
finally:
 record['elapsed_seconds']=time.monotonic()-started;record['observed_head']=git(canonical,'rev-parse','HEAD');record['observed_status']=git(canonical,'status','--porcelain')
 (out/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n');(out/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record,indent=2))
