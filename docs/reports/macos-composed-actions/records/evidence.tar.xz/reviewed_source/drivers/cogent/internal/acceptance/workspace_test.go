package acceptance

import (
	"context"
	"errors"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/execution"
	"github.com/dshills/vellum/tasks"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
	"strings"
	"testing"
)

func TestWorkspaceCatalogAndFreshModelIsolation(t *testing.T) {
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	first, err := New(a, "first", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	second, err := New(a, "second", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	if first.Editor == second.Editor || first.Grid == second.Grid || first.Tree == second.Tree || first.Dock == second.Dock {
		t.Fatal("per-window mutable models aliased")
	}
	kinds := map[ui.Kind]bool{}
	labels := 0
	var inspect func(ui.Node)
	inspect = func(n ui.Node) {
		kinds[n.Kind] = true
		if n.Kind == ui.Label && strings.HasPrefix(n.ID, "dense-") {
			labels++
		}
		for _, child := range n.Children {
			inspect(child)
		}
	}
	if err = ui.Validate(first.View()); err != nil {
		t.Fatal(err)
	}
	inspect(first.View())
	for _, panel := range first.Dock.Panels {
		view := panel.View()
		if err = ui.Validate(view); err != nil {
			t.Fatal(err)
		}
		inspect(view)
	}
	if labels != DenseLabels {
		t.Fatalf("dense fixture has %d labels", labels)
	}
	for _, kind := range []ui.Kind{ui.Column, ui.Row, ui.Label, ui.Button, ui.Icon, ui.Image, ui.Extension, ui.Checkbox, ui.Switch, ui.ToggleButton, ui.ProgressBar, ui.Separator, ui.MenuButton, ui.RadioGroup, ui.SegmentedControl, ui.Selector, ui.Slider, ui.NumberField, ui.TextField, ui.MultilineText, ui.DataGrid, ui.DataTree, ui.Tabs, ui.Scroll, ui.Toolbar, ui.StatusBar, ui.FormGroup, ui.Disclosure, ui.SplitPane, ui.Dialog} {
		if !kinds[kind] {
			t.Errorf("accepted component %s missing", kind)
		}
	}
	before := second.Editor.Snapshot()
	var exerciseErr error
	if err = a.Do(func() { exerciseErr = first.Exercise() }); err != nil || exerciseErr != nil {
		t.Fatal(err, exerciseErr)
	}
	if first.Editor.Snapshot().History.RedoCount != 0 || first.Editor.Snapshot().History.UndoCount != 1 {
		t.Fatal("history replay failed")
	}
	if second.Editor.Snapshot() != before || second.Text() == first.Text() {
		t.Fatal("exercise mutated another workspace")
	}
}

func TestDisclosureUsesReservedWorkerAndJoinsRetirement(t *testing.T) {
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	w, err := New(a, "worker", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	executor, err := execution.NewManual(2)
	if err != nil {
		t.Fatal(err)
	}
	defer executor.Close()
	w.executor = executor
	if err = a.Open(app.Window{ID: "worker", Title: "worker", Width: 640, Height: 480, View: w.View}); err != nil {
		t.Fatal(err)
	}
	start := func(kind virtual.OutlineChangeKind) {
		t.Helper()
		var failure error
		if err = a.Do(func() { failure = w.disclose(virtual.OutlineChange{Kind: kind, ID: "n0"}) }); err != nil || failure != nil {
			t.Fatal(err, failure)
		}
		if w.workerError != nil {
			t.Fatal(w.workerError)
		}
	}
	// No builder runs before explicit worker selection; the old index stays live.
	var admissionError error
	if err = a.Do(func() { admissionError = w.disclose(virtual.OutlineChange{Kind: virtual.OutlineCollapse, ID: "n0"}) }); err != nil || admissionError != nil {
		t.Fatal(err, admissionError)
	}
	pending, _ := w.Tree.State()
	if !pending.Pending || pending.VisibleRows != 64 || w.State().Disclosures != 1 || w.State().WorkerActive != 1 {
		t.Fatal("builder ran on owner or credit missing", pending, w.State())
	}
	if err = a.Do(func() { admissionError = w.disclose(virtual.OutlineChange{Kind: virtual.OutlineExpand, ID: "n0"}) }); err != nil || !errors.Is(admissionError, tasks.ErrCapacity) {
		t.Fatal("capacity did not refuse before prepare", err, admissionError)
	}
	if _, err = executor.StepNext(context.Background()); err != nil {
		t.Fatal(err)
	}
	a.Drain()
	collapsed, _ := w.Tree.State()
	if collapsed.Pending || collapsed.VisibleRows != 60 || w.State().WorkerActive != 0 || w.State().Failure != nil {
		t.Fatal("accepted worker failed to complete/release", collapsed, w.State())
	}
	start(virtual.OutlineExpand)
	if _, err = executor.StepNext(context.Background()); err != nil {
		t.Fatal(err)
	}
	a.Drain()
	expanded, _ := w.Tree.State()
	if expanded.Pending || expanded.VisibleRows != 64 || w.State().WorkerActive != 0 || w.State().Disclosures != 2 {
		t.Fatal("expansion failed", expanded, w.State())
	}
	start(virtual.OutlineCollapse)
	if err = a.CloseWindow("worker"); err != nil {
		t.Fatal(err)
	}
	if _, err = executor.StepNext(context.Background()); err != nil {
		t.Fatal(err)
	}
	a.Drain()
	retired, _ := w.Tree.State()
	if !retired.Pending || retired.VisibleRows != 64 || w.State().WorkerActive != 0 {
		t.Fatal("retired worker committed or retained credit", retired, w.State())
	}
}

func TestRefusedPreparePreservesFirstFailureAcrossLaterSuccess(t *testing.T) {
	a, err := app.New(app.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	w, err := New(a, "failure", struct{}{})
	if err != nil {
		t.Fatal(err)
	}
	executor, err := execution.NewManual(2)
	if err != nil {
		t.Fatal(err)
	}
	defer executor.Close()
	w.executor = executor
	if err = a.Open(app.Window{ID: "failure", Title: "failure", Width: 640, Height: 480, View: w.View}); err != nil {
		t.Fatal(err)
	}
	var refused error
	if err = a.Do(func() { refused = w.disclose(virtual.OutlineChange{Kind: virtual.OutlineExpand, ID: "missing"}) }); err != nil || !errors.Is(refused, virtual.ErrTreeRange) {
		t.Fatal(err, refused)
	}
	first := w.State().Failure
	if first != refused {
		t.Fatal("original refusal not retained", first, refused)
	}
	if _, err = executor.StepNext(context.Background()); err != nil {
		t.Fatal(err)
	}
	a.Drain()
	if w.State().Failure != first || errors.Is(w.State().Failure, virtual.ErrTreeStale) || errors.Is(w.State().Failure, context.Canceled) || w.State().WorkerActive != 0 {
		t.Fatal("unprepared cancel or worker cancellation masked original refusal", w.State())
	}
	for _, kind := range []virtual.OutlineChangeKind{virtual.OutlineCollapse, virtual.OutlineExpand} {
		if err = a.Do(func() {
			w.models().Children[0].TreeDisclosure(ui.TreeDisclosureEvent{Change: virtual.OutlineChange{Kind: kind, ID: "n0"}})
		}); err != nil {
			t.Fatal(err)
		}
		if w.State().Failure != first {
			t.Fatal("successful callback cleared failure", w.State())
		}
		if _, err = executor.StepNext(context.Background()); err != nil {
			t.Fatal(err)
		}
		a.Drain()
		if w.State().Failure != first || w.State().WorkerActive != 0 {
			t.Fatal("successful completion cleared failure", w.State())
		}
	}
	state, _ := w.Tree.State()
	if state.Pending || state.VisibleRows != 64 {
		t.Fatal("later successful worker did not complete", state)
	}
}
