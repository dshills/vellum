# Composed native action acceptance

The all-component Mac lifecycle fixture now exercises actual in-process Cocoa
selectors across checkbox, switch, toggle, slider, number field, radio group,
segmented control, selector, button, disclosure heading, tabs, text field, modal
buttons and managed tree rows. Each window executes 20 steps. Direct owner model
setup and editor undo/redo remain separate from these native action observations.

A native queue admission cannot qualify a step. The runner posts an acknowledged
owner check behind each admitted action before retrying; exact callback counts
and accepted controlled values must match. Accepted non-idempotent presses wait
for native publication without resubmission. A callback request accepted by an
asynchronous tree worker is distinct from completed index/geometry publication.
The tree completion predicate additionally requires idle worker credit, a sealed
nonpending index, the expected visible count/disclosure state and matching native
scope/incarnation/generation/row metadata.

The tree retains 64 stored nodes, with four children under n0. Native selection
changes the active row to n0; collapse reduces visible rows to60 and expansion
restores64. Disclosure reserves one window-scoped task and its owner completion
credit before Prepare. The immutable builder runs off-owner in64-operation steps.
Capacity refusal preserves the earlier request; window retirement cancels the
worker and suppresses its later commit. Normal successful steps require the
worker and owner completion to release their credit before closing the window.

Actual results pending final validation.

Internal review caught an async retry hazard; owner acceptance now latches the
request while native completion awaits the worker and geometry. An injected held
completion regression requires exactly one perform. The first live run targets
the containing disclosure AXGroup and fails before completing any cycle, with
27 attempts and zero admissions. The corrected runner selects AXDisclosureTriangle
and tests same-domain group/heading ambiguity. A first unit fixture omitted
required window geometry and failed; the corrected fixture passes. Raw failures
are preserved. Every later action emits a bounded scalar record even on error.

These checks exercise native selector→owner→native-publication paths. They do not
synthesize physical pointer/key events, certify human VoiceOver/IME, validate menu
popup/tray/notifications/Finder workflows, move data views through a native modal,
or meet frame/pacing/input budgets. The earlier1000-cycle retention result is on
committedbf3b1b5 with its earlier fixture. This changed hierarchical/interacting
workload needs its own long campaign; five/twenty-cycle results do not transfer
that qualification or completeP6/P11. No OS preferences or clipboard are changed.
