from pathlib import Path
import json,hashlib,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-composed-actions');D=R/'docs/reports/macos-composed-actions/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());assert process['exit_code']==1 and not process['error']and process['source_index_stable']and review['coverage']['complete']and review['coverage']['files']==10 and len(review['findings'])==3
resolution=json.loads((P/'prism-resolutions.json').read_text());assert resolution['unresolved_findings']==0 and resolution['result']=='ALL_FINDINGS_RESOLVED_WITH_FOCUSED_VERIFICATION'
sources=json.loads((P/'final-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'internal-terminal-review.json').read_text());assert internal['result']=='APPROVED_EVIDENCE'and not internal['unresolved_findings']
summary=json.loads((P/'final-summary.json').read_text());assert summary['native_cycles']==30 and summary['native_action_steps']==600 and summary['final_source_native_cycles']==5 and summary['final_source_native_actions']==100 and summary['steps_per_cycle']==20
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.heap'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['composed_actions_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Native control/tree20stepinteraction pipeline; partialstepreceipts and originalfailedtarget/unitfixture; final25windows500steps, strictvalue/callback/asynccompletion checks, reviewedworkercreditlifetime, scopedtests/source/evidence/Prism. Binaries excluded; hashes retained.'},indent=2)+'\n')
q={'result':'REVIEWED_COMPOSED_NATIVE_ACTIONS','base_commit':summary['base_commit'],'sources':sources,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':1,'prism_coverage_complete':True,'prism_files':10,'prism_reported_findings':3,'prism_unresolved_findings':0,'native_cycles':30,'native_action_steps':600,'pre_correction_cycles':25,'pre_correction_steps':500,'final_source_cycles':5,'final_source_steps':100,'steps_per_cycle':20,'prepared_files':6204,'prepared_changed':False,'framework_api_changed':False,'new_1000_cycle_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
