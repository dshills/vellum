"""One authorized Anthropic review of the bounded source/spec/report checkpoint."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path
from run import ROOT, PHASE, sha

sys.path.insert(0, str(ROOT / 'scripts'))
from child_process import run_child

out = PHASE / 'prism-v1'
out.mkdir(exist_ok=False)
sources = json.loads((PHASE / 'checkpoint-source.json').read_text())['sources']
assert len(sources) == 10
assert all(sha(ROOT / n) == h for n, h in sources.items())
diff = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--'] + list(sources), cwd=ROOT)
assert set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '--'] + list(sources), cwd=ROOT).decode().splitlines()) == set(sources)
(out / 'staged.diff.txt').write_bytes(diff)
(out / 'inputs.json').write_text(json.dumps({'files': sources, 'diff_sha256': hashlib.sha256(diff).hexdigest(),
    'scope': 'Composed native control/tree action acceptance; strict acknowledged owner and async-completion separation, bounded window worker disclosures, per-step partial receipts, focused race/layout tests and25window500step actual Cocoa campaign. Framework APIs and prepared dependencies unchanged; binaries/bulk raw logs excluded.'}, indent=2) + '\n')
argv = ['/Users/dshills/Development/Go/bin/prism', 'review', 'staged', '--provider', 'anthropic',
        '--model', 'claude-sonnet-5-5', '--format', 'json', '--baseline', 'none',
        '--fail-on', 'medium', '--min-severity', 'medium', '--no-auto-exclude',
        '--paths', ','.join(sources), '--out', str(out / 'prism.json')]
started = time.monotonic()
code = 125
error = None
try:
    with (out / 'stdout.log').open('xb') as output, (out / 'stderr.log').open('xb') as errors:
        code = run_child(argv, cwd=ROOT, stdout=output, stderr=errors, timeout=480).returncode
except BaseException as exc:
    error = {'type': type(exc).__name__, 'message': str(exc)}
after = {n: sha(ROOT / n) for n in sources}
afterdiff = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--'] + list(sources), cwd=ROOT)
receipt = {'argv': argv, 'exit_code': code, 'error': error, 'elapsed_seconds': time.monotonic()-started,
           'before': sources, 'after': after, 'source_index_stable': sources == after and diff == afterdiff,
           'prism_sha256': sha(out / 'prism.json') if (out / 'prism.json').is_file() else None,
           'producer_sha256': sha(__file__)}
(out / 'process.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PRISM', code, 'stable', receipt['source_index_stable'], 'seconds', round(receipt['elapsed_seconds'], 1), flush=True)
sys.exit(code if error is None and receipt['source_index_stable'] else 125)
