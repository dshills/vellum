from pathlib import Path
import hashlib,json
from run_v3 import identity
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-composed-actions')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def load(n):return json.loads((P/(n+'.json')).read_text())
baseline=load('baseline-v3');old=load('baseline-v2');assert identity()==baseline and len(baseline['prepared'])==6204 and baseline['prepared']==old['prepared']
changed={n for n in set(old['selected_source'])|set(baseline['selected_source'])if old['selected_source'].get(n)!=baseline['selected_source'].get(n)};assert changed=={'drivers/cogent/internal/acceptance/workspace.go','drivers/cogent/internal/acceptance/workspace_test.go'}
checks={}
for n in ['interaction-corrected-race','final-acceptance-offscreen-race','final-native-command-vet','interaction-native-build-v2','prism-error-corrections-race','prism-error-corrections-build','final-error-paths-offscreen-race']:
 x=load(n);assert x['exit_code']==0 and not x['error']and x['source_delta_stable']and x['prepared_before']==x['prepared_after']==baseline['prepared']
 assert x['producer_sha256']==sha(P/'code_run.py')and x['source_commit']==baseline['commit']
 for channel in ['stdout','stderr']:assert x[channel+'_sha256']==sha(P/(n+'.'+channel))
 endpoint=baseline if n.startswith(('prism-','final-error-'))else old
 for file,digest in x['source_delta_after'].items():
  if Path(file).suffix in {'.go','.m','.h','.c','.mod','.sum','.patch','.py','.sh'}:assert endpoint['selected_source'].get(file)==digest
 checks[n]={k:x[k]for k in ['argv','exit_code','elapsed_seconds']}
expected=[('check','set','false','AXCheckBox'),('switch','press','','AXCheckBox'),('toggle','press','','AXCheckBox'),('check','set','true','AXCheckBox'),('slider','set','37','AXSlider'),('number','increment','','AXIncrementor'),('radio','set','a','AXRadioGroup'),('segment','set','b','AXRadioGroup'),('selector','set','a','AXPopUpButton'),('button','press','','AXButton'),('disclosure','collapse','','AXDisclosureTriangle'),('disclosure','expand','','AXDisclosureTriangle'),('tabs','set','about','AXTabGroup'),('tabs','set','live','AXTabGroup'),('tree:b3V0bGluZQ:row:bjA','press','','AXRow'),('tree:b3V0bGluZQ:row:bjA','collapse','','AXRow'),('tree:b3V0bGluZQ:row:bjA','expand','','AXRow'),('text','set','Cocoa composed edit','AXTextField'),('dialog-open','press','','AXButton'),('dialog-close','press','','AXButton')]
runs=[]
for n,count in [('native-actions-five-v2',5),('native-actions-twenty',20),('native-actions-five-final',5)]:
 v=3 if n.endswith('final')else 2
 endpoint=load('baseline-v'+str(v));binary=P/('window-cycle-v'+str(v));producer=P/('run_v'+str(v)+'.py')
 x=load(n);assert x['exit_code']==0 and not x['error']and x['source_prepared_stable']and x['source_commit']==baseline['commit']and x['baseline_sha256']==sha(P/('baseline-v'+str(v)+'.json'))and x['producer_sha256']==sha(producer)and x['authorization_sha256']=='0896c3d50e2557a1b1739bc22d7304e17b513bb8350990318dbf68f74fbcd369'and x['executable_sha256']==sha(binary)
 assert x['mode']=='live'and x['argv']==[str(binary),'-composed','-cycles='+str(count),'-sample-every='+str(5 if count==20 else 1),'-timeout='+('6m'if count==20 else '4m')]and x['timeout_seconds']==(480 if count==20 else 300)
 for channel in ['stdout','stderr']:assert x[channel+'_sha256']==sha(P/(n+'.'+channel))
 ev=[json.loads(line)for line in (P/(n+'.stdout')).read_text().splitlines()if line.startswith('{')];cycles=[e for e in ev if e.get('event')=='vellum.composed-cycle'];actions=[e for e in ev if e.get('event')=='vellum.native-action'];terminal=[e for e in ev if e.get('event')=='vellum.window-cycle.result'];assert len(cycles)==count and len(actions)==count*20 and len(terminal)==1
 assert [c['cycle']for c in cycles]==list(range(1,count+1))
 for i,c in enumerate(cycles):
  steps=actions[i*20:(i+1)*20];assert all(s['window']==f'native-cycle-{i:04d}'for s in steps)and [s['action']for s in steps]==c['native_actions']
  assert [(s['action']['Target'],s['action']['Kind'],s['action']['Value'],s['action']['NativeRole'])for s in steps]==expected
  assert all(s['action']['Attempts']>=s['action']['Admissions']>=1 and s['action']['OwnerAndNativeCompleted']for s in steps)
  assert c['native_tree_selection']and c['native_tree_disclosures']==2 and c['native_text_accepted']and c['editor_history_replayed']and c['grid_tree_completed']and c['modal_open_close']and c['tree_accessibility_completed']and c['tree_accessibility_rows']==18 and c['dense_defined']==c['dense_fully_visible']==1000 and c['all_dense_labels_fully_visible']and not c['full_p11_qualified']
 end=terminal[0];assert end['result']=='PASS_NATIVE_WINDOW_CYCLES'and end['completed_cycles']==end['requested_cycles']==count and end['rss_guard_bytes']==1<<30 and end['go_heap_guard_bytes']==512<<20 and end['samples_after_forced_gc']and not end['preferences_changed']and not end['clipboard_access']and not end['full_p11_qualified']
 clean=end['native_cleanup'];assert clean['MainThread']and clean['CleanupObserved']and clean['CallbacksStopped']and not clean['WindowTitles']and clean['NativeOutstanding']==clean['AccessibilityWindows']==clean['PendingCallbacks']==0
 runs.append({'name':n,'source_version':v,'exit_code':x['exit_code'],'baseline_sha256':x['baseline_sha256'],'source_prepared_stable':x['source_prepared_stable'],'selected_source_sha256':hashlib.sha256(json.dumps(endpoint['selected_source'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'prepared_sha256':hashlib.sha256(json.dumps(endpoint['prepared'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'raw_process_receipt':n+'.json','raw_stdout_sha256':x['stdout_sha256'],'ax_rows_per_cycle':18,'density_labels_per_cycle':1000,'cycles':count,'native_actions':len(actions),'attempts':sum(s['action']['Attempts']for s in actions),'admissions':sum(s['action']['Admissions']for s in actions),'elapsed_seconds':x['elapsed_seconds'],'terminal_cleanup':clean,'terminal_sample':end['samples'][-1]})
summary={'result':'PASS_COMPOSED_NATIVE_ACTION_PIPELINE','base_commit':baseline['commit'],'code_checks':checks,'runs':runs,'native_cycles':30,'native_action_steps':600,'prism_reviewed_version_cycles':25,'prism_reviewed_version_actions':500,'final_source_native_cycles':5,'final_source_native_actions':100,'post_prism_source_changes':sorted(changed),'steps_per_cycle':20,'prepared_files':6204,'prepared_changed':False,'new_1000_cycle_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'source_versions':'v2 has25windows500steps beforeerror-recording fixes; v3 has5windows100steps afterguardedPrepare/stickyfirsterror correction. Source and prepared endpoint digests are versioned, not conflated.','scope':'Actual in-process Cocoa selectors to acknowledged owner callbacks and completed native publication, including reserved window worker disclosure; no OS preferences or clipboard. Changed hierarchical/interacting fixture is not the earlier committed-source1000cycle workload.'}
(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
