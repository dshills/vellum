"""Locally fast-forward the reviewed checkpoint and verify exact tracked/prepared bytes."""
import hashlib
import json
import sys
import time
from pathlib import Path

scratch = Path('/private/tmp/vellum-large-data')
canonical = Path('/Users/dshills/Development/projects/Vellum')
phase = Path('/private/tmp/vellum-macos-scene-cost')
out = Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-native-validation')
base = 'f3caa2e668839395f0e7ed66f57d39f8e0941df7'
sys.path.insert(0, str(scratch/'scripts'))
from child_process import run_child
from sdk_environment import child_environment

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
env = {**child_environment(), 'GOCACHE': '/tmp/vellum-p0-cache/build',
       'GOMODCACHE': '/tmp/vellum-p0-cache/mod', 'GOPATH': '/tmp/vellum-p0-cache/gopath'}
commands = []
def git(root, *args):
    argv = ['git', '-C', str(root), *args]
    result = run_child(argv, env=env, capture_output=True, timeout=60)
    commands.append({'argv': argv, 'exit_code': result.returncode,
                     'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                     'stderr': result.stderr.decode(errors='replace')})
    assert result.returncode == 0, (argv, result.stderr)
    return result.stdout.decode()

assert not git(scratch, 'status', '--porcelain') and not git(canonical, 'status', '--porcelain')
assert git(canonical, 'rev-parse', 'HEAD').strip() == base
assert git(canonical, 'branch', '--show-current').strip() == 'codex/foundation-completion'
commit = git(scratch, 'rev-parse', 'HEAD').strip()
assert git(scratch, 'rev-list', '--parents', '-n', '1', 'HEAD').split() == [commit, base]
names = [n for n in git(scratch, 'ls-files', '-z').split('\0') if n]
expected = {n: sha(scratch/n) for n in names}
q = json.loads((phase/'qualification.json').read_text())
checkpoint_name = 'docs/reports/macos-native-validation/records/checkpoint.json'
checkpoint = json.loads((scratch/checkpoint_name).read_text())
assert q['base_commit'] == checkpoint['base_commit'] == base
assert q['result'] == checkpoint['result'] == 'REVIEWED_SCOPED_NATIVE_VALIDATION'
assert all(expected.get(n) == h for n, h in q['source'].items())
assert checkpoint['prism_provider'] == 'anthropic' and checkpoint['prism_model'] == 'claude-sonnet-5-5'
assert checkpoint['prism_coverage_complete'] and checkpoint['prism_findings'] == 0
assert sha(phase/'qualification.json') == checkpoint['qualification_sha256']
assert sha(__file__) == checkpoint['promotion_producer_sha256']
out.mkdir(parents=True, exist_ok=False)
(out/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
record = {'result': 'OBSERVED_CANONICAL_PROMOTION', 'base_commit': base, 'commit': commit,
          'scope': 'Reviewed native integer helper/test with451node validation-only benchmark and480separate profiled/native-sampled diagnostic events. Scoped real400cellCocoa/race/vet acceptance. No newordinarylatencycampaign; latest4/6ms targetfailure remains. No exactnativeCPU/allocation/GPU or fullP6/P11/Mac/human/physical/release qualification.'}
started = time.monotonic()
try:
    git(canonical, 'fetch', str(scratch), commit)
    assert git(canonical, 'rev-parse', 'FETCH_HEAD').strip() == commit
    git(canonical, 'merge', '--ff-only', 'FETCH_HEAD')
    assert git(canonical, 'rev-parse', 'HEAD').strip() == commit
    with (out/'prepare.stdout.log').open('xb') as output, (out/'prepare.stderr.log').open('xb') as errors:
        prepared_process = run_child(['python3', 'prepare.py'], cwd=canonical/'drivers/cogent', env=env,
                                     stdout=output, stderr=errors, timeout=180)
    record['prepare_exit_code'] = prepared_process.returncode
    assert prepared_process.returncode == 0
    prepared = {p.relative_to(canonical/'drivers/cogent/build').as_posix(): sha(p)
                for module in ['upstream', 'typesetting']
                for p in sorted((canonical/'drivers/cogent/build'/module).rglob('*')) if p.is_file()}
    tracked = {n: sha(canonical/n) for n in names}
    archive = canonical/'docs/reports/macos-native-validation/records/evidence.tar.xz'
    record.update({'prepared_files': len(prepared),
        'exact_qualified_prepared_match': prepared == json.loads((phase/'baseline.json').read_text())['prepared'],
        'tracked_files': len(tracked), 'exact_checkpoint_source_match': tracked == expected,
        'archive_sha256': sha(archive), 'archive_index_match': sha(archive) == checkpoint['archive_sha256'],
        'checkpoint_sha256': sha(canonical/checkpoint_name),
        'canonical_clean': not git(canonical, 'status', '--porcelain'),
        'scratch_clean': not git(scratch, 'status', '--porcelain')})
    assert len(prepared) == 6198 and all(record[n] for n in ['exact_qualified_prepared_match',
        'exact_checkpoint_source_match', 'archive_index_match', 'canonical_clean', 'scratch_clean'])
    record['result'] = 'PASS_CANONICAL_PROMOTION'
except BaseException as error:
    record['result'] = 'FAILED_CANONICAL_PROMOTION'
    record['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    for label, args in [('observed_head', ('rev-parse', 'HEAD')), ('observed_status', ('status', '--porcelain'))]:
        try:
            record[label] = git(canonical, *args).strip()
        except BaseException as error:
            record[label+'_error'] = {'type': type(error).__name__, 'message': str(error)}
    record['elapsed_seconds'] = time.monotonic()-started
    record['commands'] = commands
    (out/'canonical-promotion.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k != 'commands'}, indent=2))
