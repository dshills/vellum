# Native snapshot validation evidence review

APPROVED_EVIDENCE. No material findings in the bounded raw receipt, calculation and factual-claim review.

The four checkpoint leaves match their manifest and complete four-file Anthropic Claude Sonnet 5.5 Prism input/output (raw exit 0, no findings). Two native source leaves match the existing independent source approval. Captured 710-source/6,198-prepared endpoint maps are stable; this review does not reconstruct the full unchanged compiler or dependency closure.

Reparsed the two 120-event CPU-profile diagnostics and the 240-event profiled external-sample process: all have 128 guarded warmups and complete correlated events, with no ordinary latency samples. The owned five-second sampler starts after ready and its process/log/profile hashes match. Profiles expose sampled stack paths, including waits and NSNumber formatting; nested counts do not establish precise native CPU or allocation cost.

The original boundary oracle uses the original native implementation with the final new test fixture. Candidate focused race count 3, whole adapter race, vet, optimized build and stored 400-cell Cocoa AX acceptance are terminal successes with stable recorded source/prepared identities. The wrong-cwd first build did not launch and remains historical.

Independently parsed five observations in each of four benchmark batches. Selected original median is 2,249,098 ns/op (range 2,241,400–2,257,630); final candidate median is 1,935,903 ns/op (range 1,928,072–1,961,042). Earlier candidate batches overlap race/build work; selected v3 starts after those jobs terminate. The fixture has 451 nodes: 400 cells, 50 rows and one host. These are local native-validation observations; Go's zero allocation counters do not measure native allocation.

The final report/spec maintain the required limits: no new ordinary P6 campaign, no whole-frame or sustained improvement claim, no exact CPU/native-allocation attribution, and no physical GPU or full Mac/P11 acceptance. Main-queue native validation is outside recorded TotalUIWork and these observations cannot be subtracted from that total. Archive/index/checkpoint links are pending a separate packaging audit.

Only read/hash/stdlib JSON and arithmetic processing was performed. No source edits, test/build/prepare/native/UI/provider/Git execution. Exact reviewed identities are in evidence-review.json; own inert verifier and calculation output are retained separately.
