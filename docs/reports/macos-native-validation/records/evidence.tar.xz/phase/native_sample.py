"""Sample only the owned native child, as a separately labelled diagnostic."""
import json
import os
import subprocess
import time
from run import ROOT, PHASE, sha, baseline

before = baseline()
out = PHASE/'native-sample-v1'
out.mkdir(exist_ok=False)
binary = PHASE/'loadedgrid'
argv = [str(binary), '-perf', '-rows=10000', '-perf-samples=240', '-perf-warmup=128',
        '-gpu-scene', '-perf-cpu-profile='+str(out/'go-cpu.pprof')]
native = observer = None
record = {'result': 'UNCOMPLETED_DIAGNOSTIC', 'argv': argv, 'binary_sha256': sha(binary),
          'baseline_sha256': sha(PHASE/'baseline.json'), 'producer_sha256': sha(__file__),
          'scope': 'External native sampling perturbs one profiled fixed10k GPU-scene process. This is not ordinary latency, exact thread/native CPU accounting, GPU execution or full qualification.'}
started = time.monotonic()
try:
    with (out/'native.stdout').open('xb') as output, (out/'native.stderr').open('xb') as errors:
        native = subprocess.Popen(argv, cwd=ROOT, stdout=output, stderr=errors)
        assert os.getpgid(native.pid) == os.getpgrp()
        # Observe the saved ready record without changing the child workload.
        while time.monotonic()-started < 60:
            if native.poll() is not None:
                raise RuntimeError('native exited before guarded warm ready')
            assert (out/'native.stdout').stat().st_size <= 64 << 20
            lines = (out/'native.stdout').read_text().splitlines()
            ready = next((json.loads(line) for line in lines
                          if line.startswith('{') and '"grid.perf.ready"' in line), None)
            if ready:
                assert ready['warmup_guard'] == 1 and ready['warmup'] == ready['warm_callbacks'] == 128
                break
            time.sleep(.02)
        else:
            raise TimeoutError('guarded ready missing')
        sample_argv = ['/usr/bin/sample', str(native.pid), '5', '1', '-file', str(out/'native.sample.txt')]
        with (out/'sample.stdout').open('xb') as so, (out/'sample.stderr').open('xb') as se:
            observer = subprocess.Popen(sample_argv, stdout=so, stderr=se)
            assert os.getpgid(observer.pid) == os.getpgrp()
            sample_code = observer.wait(timeout=20)
        assert sample_code == 0, sample_code
        assert native.wait(timeout=90) == 0
        assert (out/'native.stdout').stat().st_size <= 64 << 20
        assert 0 < (out/'native.sample.txt').stat().st_size <= 64 << 20
        assert 0 < (out/'go-cpu.pprof').stat().st_size <= 64 << 20
        assert before == baseline()
        record.update({'result': 'PASS_OWNED_NATIVE_SAMPLE', 'native_exit_code': 0,
                       'sample_exit_code': sample_code, 'sample_argv': sample_argv,
                       'sample_started_after_guarded_warmup': True,
                       'owned_group': os.getpgrp(), 'native_pid': native.pid})
except BaseException as exc:
    record['result'] = 'FAILED_OWNED_NATIVE_SAMPLE'
    record['error'] = {'type': type(exc).__name__, 'message': str(exc)}
    raise
finally:
    for process in [observer, native]:
        if process is not None:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=5)
    record['elapsed_seconds'] = time.monotonic()-started
    record['files'] = {p.name: sha(p) for p in sorted(out.iterdir()) if p.is_file()}
    (out/'process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
