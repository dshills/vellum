"""Validate completed CPU diagnostics; no latency qualification or process launch."""
import importlib.util
import json
from run import ROOT, PHASE, sha, identity

spec = importlib.util.spec_from_file_location('benchmark', ROOT/'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)
assert identity() == json.loads((PHASE/'baseline.json').read_text())
sets = []
for name, gpu, profile in [('cpu-default-v1', False, 'default.pprof'), ('cpu-gpu-v1', True, 'gpu.pprof')]:
    receipt = json.loads((PHASE/(name+'.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['error'] is None and receipt['source_prepared_stable']
    assert all(sha(PHASE/(name+'.'+c)) == receipt[c+'_sha256'] for c in ['stdout', 'stderr'])
    records = [json.loads(line) for line in (PHASE/(name+'.stdout')).read_text().splitlines() if line.startswith('{')]
    samples = benchmark.validate_records(records, 10000, False, 120, False, allow_profile=True, gpu_scene_rendering=gpu)
    assert records[0]['cpu_profile'] and records[0]['cpu_profile_path'] == str(PHASE/profile)
    assert records[1]['warmup'] == records[1]['warm_callbacks'] == 128
    assert all(x['warmup_guard'] == 1 for x in records)
    assert 0 < (PHASE/profile).stat().st_size <= 64 << 20
    sets.append(samples)
assert all(a['geometry'] == b['geometry'] and a['source_callbacks'] == b['source_callbacks'] for a,b in zip(*sets))
q = {'result': 'PASS_SCOPED_CPU_DIAGNOSTICS', 'ordinary_samples': 0, 'profiled_samples': 240,
     'warm_target_met': False, 'binary_sha256': sha(PHASE/'loadedgrid'),
     'baseline_sha256': sha(PHASE/'baseline.json'), 'profiles': {n: sha(PHASE/n) for n in ['default.pprof','gpu.pprof']},
     'producer_sha256': sha(__file__), 'scope': 'Two fixed10k profiled native processes with exact paired geometry/callback work. Sampled process-wide Go/Cgo stacks include observers/native event loop and cannot establish exact C/native costs, GPU completion, ordinary latency or full P6/Mac qualification.'}
(PHASE/'profile-qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps(q))
