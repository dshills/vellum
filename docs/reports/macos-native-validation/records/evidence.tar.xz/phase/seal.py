"""Seal exact reviewed sources and terminal scoped native diagnostics."""
import hashlib, io, json, tarfile
from run import ROOT, PHASE, sha, identity

records=ROOT/'docs/reports/macos-native-validation/records'
base=json.loads((PHASE/'baseline.json').read_text())
candidate=json.loads((PHASE/'candidate-baseline-v1.json').read_text())
actual=identity()
assert actual['commit']==base['commit']==candidate['commit']
assert actual['selected_source']==candidate['selected_source'] and actual['prepared']==base['prepared']==candidate['prepared']
sources=json.loads((PHASE/'checkpoint-source.json').read_text())['sources']
assert all(sha(ROOT/n)==h for n,h in sources.items())
reviews={}
for name in ['source-review','evidence-review']:
    review=json.loads((PHASE/(name+'.json')).read_text())
    assert review.get('result',review.get('status')).startswith('APPROVED') and not review['findings']
    for key in ['reviewed_artifact_sha256','reviewed_file_sha256']:
        for filename,digest in review.get(key,{}).items(): assert sha(filename)==digest,filename
    reviews[name]=sha(PHASE/(name+'.json'))
required=['build-grid-v2','cpu-default-v1','cpu-gpu-v1','pprof-default-v1','pprof-gpu-v1',
          'pprof-default-cumulative-v1','pprof-gpu-draw-v1','pprof-gpu-geometry-v1','native-sample-live-v1',
          'uint-oracle-original-v1','uint-benchmark-original-v1','uint-candidate-race-v1',
          'uint-benchmark-candidate-v1','uint-benchmark-candidate-v2','uint-benchmark-candidate-v3',
          'adapter-race-v1','adapter-vet-v1','build-grid-candidate-v1','ax-native-candidate-v1']
receipts={}
for name in required:
    r=json.loads((PHASE/(name+'.json')).read_text())
    assert r['exit_code']==0 and r['error'] is None and r['source_commit']==base['commit']
    if 'source_prepared_stable' in r: assert r['source_prepared_stable']
    else: assert r['source_delta_stable'] and r['prepared_before']==r['prepared_after']==base['prepared']
    assert all(sha(PHASE/(name+'.'+c))==r[c+'_sha256'] for c in ['stdout','stderr'])
    receipts[name]=sha(PHASE/(name+'.json'))
prism=json.loads((PHASE/'prism-v1/prism.json').read_text())
process=json.loads((PHASE/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and process['error'] is None and process['source_index_stable']
assert process['before']==process['after']==sources and prism['coverage']['complete'] and prism['coverage']['files']==4
assert not prism['findings']
q={'result':'REVIEWED_SCOPED_NATIVE_VALIDATION','base_commit':base['commit'],'source':sources,
   'selected_source_files':710,'prepared_files':6198,'ordinary_samples':0,'profiled_samples':480,
   'qualifiers':{n:sha(PHASE/n) for n in ['profile-qualification.json','native-sample-qualification.json','benchmark-qualification.json']},
   'required_receipts':receipts,'reviews':reviews,'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5',
   'prism_findings':0,'prism_sha256':sha(PHASE/'prism-v1/prism.json'),
   'limits':['Validation-only sequential microbenchmarks and sampled native/Go diagnostics do not qualify exact native CPU/allocation, GPU execution or ordinary frame latency.',
             'Latest ordinary4/6ms targets remain failed; no new ordinary campaign.',
             'Scoped Cocoa400-cell/race/vet acceptance is not human VoiceOver/physical hardware, fullP6/P11/Mac/release or completecompiler/SDK/cache closure.']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(exist_ok=False)
for name in reviews: (records/(name+'.json')).write_bytes((PHASE/(name+'.json')).read_bytes())
suffixes={'.go','.m','.py','.md','.txt','.json','.stdout','.stderr','.log','.pprof'}
excluded={'endpoints.json','final-evidence-review.json','final-evidence-review.md'}
members={'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes() for p in sorted(PHASE.rglob('*'))
         if p.is_file() and p.suffix in suffixes and p.name not in excluded}
members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
index={n:{'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob)} for n,blob in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
    for n,blob in members.items():
        info=tarfile.TarInfo(n);info.size=len(blob);info.mode=0o644;archive.addfile(info,io.BytesIO(blob))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
endpoints={'qualification_sha256':sha(PHASE/'qualification.json'),'source_manifest_sha256':sha(PHASE/'checkpoint-source.json'),
           'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),
           'archive_members':len(members),'source':sources,'reviews':reviews,'prism_sha256':q['prism_sha256']}
(PHASE/'endpoints.json').write_text(json.dumps(endpoints,indent=2)+'\n')
print(json.dumps(endpoints,indent=2))
