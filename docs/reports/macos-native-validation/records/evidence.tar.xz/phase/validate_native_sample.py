"""Validate saved externally sampled diagnostics without relaunching them."""
import importlib.util
import json
from run import ROOT, PHASE, sha

spec=importlib.util.spec_from_file_location('benchmark',ROOT/'scripts/benchmark-grid.py')
b=importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
out=PHASE/'native-sample-v1'
receipt=json.loads((PHASE/'native-sample-live-v1.json').read_text())
process=json.loads((out/'process.json').read_text())
assert receipt['exit_code']==0 and receipt['error'] is None and receipt['source_prepared_stable']
assert process['result']=='PASS_OWNED_NATIVE_SAMPLE' and process['native_exit_code']==process['sample_exit_code']==0
assert all(sha(out/n)==h for n,h in process['files'].items())
records=[json.loads(line) for line in (out/'native.stdout').read_text().splitlines() if line.startswith('{')]
samples=b.validate_records(records,10000,False,240,False,allow_profile=True,gpu_scene_rendering=True)
assert records[0]['cpu_profile'] and all(x['warmup_guard']==1 for x in records)
assert records[1]['warmup']==records[1]['warm_callbacks']==128
assert len(samples)==240 and process['binary_sha256']==sha(PHASE/'loadedgrid')
assert process['baseline_sha256']==sha(PHASE/'baseline.json')
text=(out/'native.sample.txt').read_text()
assert f"loadedgrid [{process['native_pid']}]" in text
assert 'vellumAXValidatedNodes' in text and 'vellumAXUInt' in text and 'stringValue' in text
q={'result':'PASS_SCOPED_EXTERNAL_NATIVE_DIAGNOSTIC','ordinary_samples':0,'profiled_samples':240,
   'warm_target_met':False,'receipt_sha256':sha(PHASE/'native-sample-live-v1.json'),
   'process_sha256':sha(out/'process.json'),'sample_sha256':sha(out/'native.sample.txt'),
   'scope':'External sampler observes owned process after guarded warmup and perturbs this process. Stacks identify paths, not exact CPU cost, native allocation, GPU execution or ordinary latency qualification.'}
(PHASE/'native-sample-qualification.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps(q))
