// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"image"
	"image/draw"
	"math"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
)

const scrollCacheBudget = 32 << 20
const scrollCacheGroups = 64

type scrollKey struct {
	id   uint64
	part uint8
}
type scrollPixels struct {
	epoch    uint64
	position image.Point
	pixels   *image.RGBA
	used     uint64
	plan     *scrollPaintPlan
}

// ScrollStats describes the last raster replay. Counts are CPU pixel regions,
// never physical GPU transfers or presentation. CachedBytes is bounded per
// renderer; the renderer releases the complete cache on a size change.
type ScrollStats struct {
	Groups, FullRedraws, ReusedGroups int
	ReusedPixels, RedrawPixels        int
	CachedBytes                       int
	DescriptorBytes, PaintRefusals    int
}

func (rs *Renderer) ScrollStats() ScrollStats { return rs.scrollStats }

func scrollGroupEnd(r render.Render, start int) int {
	depth := 1
	for i := start + 1; i < len(r); i++ {
		switch r[i].(type) {
		case *render.ContextPush:
			depth++
		case *render.ContextPop:
			depth--
			if depth == 0 {
				return i
			}
		}
	}
	return -1
}

// Admit only fully covered rectangular uniform/text groups. Unknown sources,
// destination-dependent commands, path masks/filters, transforms, nested hints
// and writes outside the surface keep their existing complete replay behavior.
func scrollCommands(r render.Render, bounds image.Rectangle) bool {
	opaque := false
	for _, item := range r {
		switch x := item.(type) {
		case *render.ContextPush:
			if x != nil && x.Scroll != nil {
				return false
			}
		case *render.ContextPop:
		case *pimage.Params:
			if x == nil || x.Cmd != pimage.Draw || x.Mask != nil || x.Rect.Empty() || !x.Rect.In(bounds) || x.Op != draw.Src && x.Op != draw.Over {
				return false
			}
			u, ok := valueUniform(x.Source)
			if !ok {
				return false
			}
			// image.Uniform has finite bounds. Source positions outside them can
			// clip an apparently covering fill to nothing. Check before accepting
			// coverage, using subtraction within the known uniform bounds.
			source := u.Bounds()
			if x.SourcePos.X < source.Min.X || x.SourcePos.Y < source.Min.Y || x.SourcePos.X > source.Max.X-x.Rect.Dx() || x.SourcePos.Y > source.Max.Y-x.Rect.Dy() {
				return false
			}
			if !opaque {
				if x.Rect != bounds {
					return false
				}
				_, _, _, alpha := u.C.RGBA()
				opaque = alpha == 0xffff
			}
		case *render.Path:
			// Standard widget boxes retain a path even when both paints are disabled.
			// They clear raster scratch but produce no destination pixels.
			if x == nil || x.Context.Style.HasFill() || x.Context.Style.HasStroke() {
				return false
			}
		case *render.Text:
			if !opaque || x == nil || x.Text == nil || x.Context.Cumulative != math32.Identity2() || x.Context.Mask != nil || len(x.Context.ClipPath) != 0 || x.Context.Bounds.Rect.ToRect().Empty() || !x.Context.Bounds.Rect.ToRect().In(bounds) {
				return false
			}
			if _, ok := valueUniform(&image.Uniform{C: x.Text.Color}); !ok {
				return false
			}
			for _, source := range []image.Image{x.Text.SelectionColor, x.Text.HighlightColor} {
				if !scrollUniform(source) {
					return false
				}
			}
			for _, line := range x.Text.Lines {
				for _, shaped := range line.Runs {
					run, ok := shaped.(*shapedgt.Run)
					if !ok || run == nil || run.Face == nil || run.Math.Path != nil || run.Direction.IsVertical() || run.Decoration != 0 || !scrollUniform(run.FillColor) || !scrollUniform(run.StrokeColor) || !scrollUniform(run.Background) {
						return false
					}
				}
			}
		default:
			return false
		}
	}
	return opaque
}

func scrollUniform(source image.Image) bool {
	if source == nil {
		return true
	}
	_, ok := valueUniform(source)
	return ok
}

func scrollDifference(a, b, limit int) (int, bool) {
	if a >= b {
		difference := uint(a) - uint(b)
		if difference >= uint(limit) {
			return 0, false
		}
		return int(difference), true
	}
	difference := uint(b) - uint(a)
	if difference >= uint(limit) {
		return 0, false
	}
	return -int(difference), true
}

func (rs *Renderer) forgetScroll(key scrollKey) {
	if old := rs.scrollCache[key]; old != nil {
		rs.scrollBytes -= len(old.pixels.Pix)
		if old.plan != nil {
			rs.scrollPlanBytes -= old.plan.bytes
		}
		delete(rs.scrollCache, key)
	}
}

func (rs *Renderer) reserveScroll(bytes, descriptors int, key scrollKey) {
	for rs.scrollBytes+bytes > scrollCacheBudget || rs.scrollPlanBytes+descriptors > scrollPlanBudget || (rs.scrollCache[key] == nil && len(rs.scrollCache) >= scrollCacheGroups) {
		var oldest scrollKey
		age := uint64(math.MaxUint64)
		found := false
		for k, v := range rs.scrollCache {
			if k != key && v.used <= age {
				oldest, age, found = k, v.used, true
			}
		}
		if !found {
			break
		} // each admitted group individually fits both budgets
		rs.forgetScroll(oldest)
	}
	if rs.scrollCache == nil {
		rs.scrollCache = make(map[scrollKey]*scrollPixels)
	}
}

func (rs *Renderer) renderScroll(hint *render.ScrollSurface, commands render.Render) {
	rs.scrollStats.Groups++
	key := scrollKey{hint.ID, hint.Part}
	bounds := hint.Bounds
	w, h := bounds.Dx(), bounds.Dy()
	if hint.ID == 0 || hint.Epoch == 0 || w <= 0 || h <= 0 || !bounds.In(rs.image.Bounds()) || w > scrollCacheBudget/4 || h > scrollCacheBudget/4/w || !scrollCommands(commands, bounds) {
		rs.forgetScroll(key)
		rs.scrollStats.FullRedraws++
		rs.renderItems(commands, image.Rectangle{})
		return
	}
	var plan *scrollPaintPlan
	if hint.VerifyPaint {
		plan = rs.scrollPlan(commands)
		if plan == nil {
			rs.forgetScroll(key)
			rs.scrollStats.FullRedraws++
			rs.scrollStats.PaintRefusals++
			rs.renderItems(commands, image.Rectangle{})
			return
		}
	}
	replay := func(clip image.Rectangle) {
		if plan != nil {
			rs.replayScrollPlan(plan, clip)
		} else {
			if clip == bounds {
				clip = image.Rectangle{}
			}
			rs.renderItems(commands, clip)
		}
	}
	bytes := w * h * 4
	if rs.scrollClock == math.MaxUint64 {
		rs.scrollCache = nil
		rs.scrollBytes = 0
		rs.scrollPlanBytes = 0
		rs.scrollClock = 0
	}
	rs.scrollClock++
	old := rs.scrollCache[key]
	if old != nil && old.pixels.Bounds() != bounds {
		rs.forgetScroll(key)
		old = nil
	}
	overlap := image.Rectangle{}
	if old != nil && old.epoch == hint.Epoch {
		// Bound subtraction before computing it, so adversarial extreme offsets
		// cannot wrap into a plausible overlap. Large jumps simply repaint.
		dx, xok := scrollDifference(old.position.X, hint.Position.X, w)
		dy, yok := scrollDifference(old.position.Y, hint.Position.Y, h)
		if xok && yok {
			delta := image.Pt(dx, dy)
			overlap = bounds.Intersect(bounds.Add(delta))
			if !overlap.Empty() && hint.VerifyPaint && !sameScrollPaint(old.plan, plan, overlap, delta) {
				overlap = image.Rectangle{}
				rs.scrollStats.PaintRefusals++
			}
			if !overlap.Empty() {
				draw.Draw(rs.image, overlap, old.pixels, overlap.Min.Sub(delta), draw.Src)
			}
		}
	}
	if overlap.Empty() {
		rs.scrollStats.FullRedraws++
		rs.scrollStats.RedrawPixels += w * h
		replay(bounds)
	} else {
		rs.scrollStats.ReusedGroups++
		rs.scrollStats.ReusedPixels += overlap.Dx() * overlap.Dy()
		// Four disjoint rectangles cover the surface minus its overlap. Side
		// strips exclude top/bottom strips, so translucent text is never doubled.
		for _, dirty := range []image.Rectangle{
			image.Rect(bounds.Min.X, bounds.Min.Y, bounds.Max.X, overlap.Min.Y),
			image.Rect(bounds.Min.X, overlap.Max.Y, bounds.Max.X, bounds.Max.Y),
			image.Rect(bounds.Min.X, overlap.Min.Y, overlap.Min.X, overlap.Max.Y),
			image.Rect(overlap.Max.X, overlap.Min.Y, bounds.Max.X, overlap.Max.Y),
		} {
			if dirty.Empty() {
				continue
			}
			rs.scrollStats.RedrawPixels += dirty.Dx() * dirty.Dy()
			replay(dirty)
		}
	}
	descriptors := 0
	if plan != nil {
		descriptors = plan.bytes
	}
	if old != nil && old.plan != nil {
		rs.scrollPlanBytes -= old.plan.bytes
		old.plan = nil
	}
	extra := 0
	if old == nil {
		extra = bytes
	}
	rs.reserveScroll(extra, descriptors, key)
	if old == nil {
		old = &scrollPixels{pixels: image.NewRGBA(bounds)}
		rs.scrollCache[key] = old
		rs.scrollBytes += bytes
	}
	old.plan = plan
	rs.scrollPlanBytes += descriptors
	// Capture at the original group position, before later siblings paint. The
	// next replay restores these pixels after any preceding parent repaint.
	draw.Draw(old.pixels, bounds, rs.image, bounds.Min, draw.Src)
	old.epoch, old.position, old.used = hint.Epoch, hint.Position, rs.scrollClock
}
