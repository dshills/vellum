// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"slices"
	"unsafe"

	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
)

const scrollPlanBudget = 8 << 20
const scrollPlanMaxOps = 65536

type scrollPaintOp struct {
	kind       uint8 // uniform draw, glyph alpha mask, filled fixed path
	rect, clip image.Rectangle
	color      color.Color // only copied, comparable built-in value colors
	op         draw.Op
	mask       *image.Alpha // owned bytes; never the font's or shared glyph cache's mask
	path       Path         // owned fixed coordinates; no font, widget, model or shaped-run references
	winding    bool
}
type scrollPaintPlan struct {
	ops             []scrollPaintOp
	bytes           int
	failed, winding bool
}

func (p *scrollPaintPlan) reserve(deep int) bool {
	size := int(unsafe.Sizeof(scrollPaintOp{})) + deep
	if p.failed || deep < 0 || size > scrollPlanBudget-p.bytes || len(p.ops) == scrollPlanMaxOps {
		p.failed = true
		return false
	}
	p.bytes += size
	return true
}
func (p *scrollPaintPlan) addUniform(x *pimage.Params) {
	u, ok := valueUniform(x.Source)
	if !ok || !p.reserve(0) {
		p.failed = true
		return
	}
	p.ops = append(p.ops, scrollPaintOp{rect: x.Rect, clip: x.Rect, color: u.C, op: x.Op})
}
func (p *scrollPaintPlan) addMask(mask *image.Alpha, pos image.Point, clip image.Rectangle, fill image.Image) {
	u, ok := valueUniform(fill)
	if !ok || mask == nil {
		p.failed = true
		return
	}
	b := mask.Bounds()
	if b.Empty() {
		return
	}
	// The existing glyph cache only returns small masks. Refuse other mask sizes
	// before multiplying or allocating. Replay uses the exact copied mask bytes.
	if b.Dx() > glyphMaxSize || b.Dy() > glyphMaxSize || !p.reserve(b.Dx()*b.Dy()+int(unsafe.Sizeof(image.Alpha{}))) {
		p.failed = true
		return
	}
	own := image.NewAlpha(image.Rectangle{Max: b.Size()})
	for y := 0; y < b.Dy(); y++ {
		copy(own.Pix[y*own.Stride:], mask.Pix[mask.PixOffset(b.Min.X, b.Min.Y+y):][:b.Dx()])
	}
	p.ops = append(p.ops, scrollPaintOp{kind: 1, rect: b.Add(pos), clip: clip, color: u.C, op: draw.Over, mask: own})
}
func (p *scrollPaintPlan) addPath(path Path, clip image.Rectangle, fill image.Image) {
	if fill == nil || len(path) == 0 {
		return
	}
	u, ok := valueUniform(fill)
	if !ok || len(path) > scrollPlanBudget/4 || !p.reserve(len(path)*4) {
		p.failed = true
		return
	}
	hull := image.Rectangle{}
	first := true
	for i := 0; i < len(path); {
		n := pathCoordinates(PathCommand(path[i]))
		if n < 0 || i+n >= len(path) {
			p.failed = true
			return
		}
		for j := 1; j <= n; j += 2 {
			x, y := path[i+j], path[i+j+1]
			b := image.Rect(x.Floor()-1, y.Floor()-1, x.Ceil()+1, y.Ceil()+1)
			if first {
				hull = b
				first = false
			} else {
				hull = hull.Union(b)
			}
		}
		i += n + 1
	}
	p.ops = append(p.ops, scrollPaintOp{kind: 2, rect: hull, clip: clip, color: u.C, path: slices.Clone(path), winding: p.winding})
}
func pathCoordinates(cmd PathCommand) int {
	switch cmd {
	case PathMoveTo, PathLineTo:
		return 2
	case PathQuadTo:
		return 4
	case PathCubicTo:
		return 6
	case PathClose:
		return 0
	}
	return -1
}

// Capture follows the same text placement, selection/background, outline and
// cached-mask code as ordinary text replay. Those routines only record in this
// mode. The accepted plan is also the source of full/strip replay, so mutable
// font resources are not read again between the proof and the actual drawing.
func (rs *Renderer) scrollPlan(commands render.Render) *scrollPaintPlan {
	p := &scrollPaintPlan{bytes: int(unsafe.Sizeof(scrollPaintPlan{})), winding: rs.Scanner.UseNonZeroWinding}
	capture := *rs
	capture.Path = nil
	capture.scrollRecord = p
	for _, item := range commands {
		switch x := item.(type) {
		case *pimage.Params:
			p.addUniform(x)
		case *render.Text:
			for _, line := range x.Text.Lines {
				for _, r := range line.Runs {
					run := r.(*shapedgt.Run)
					if run.StrokeColor != nil {
						p.failed = true
					}
				}
			}
			if !p.failed {
				capture.RenderText(x)
			}
		}
		if p.failed {
			return nil
		}
	}
	// Trim allocation capacity so retained accounting includes all operation slots.
	exact := make([]scrollPaintOp, len(p.ops))
	copy(exact, p.ops)
	p.ops = exact
	return p
}

func (rs *Renderer) replayScrollPlan(p *scrollPaintPlan, clip image.Rectangle) {
	for _, op := range p.ops {
		rect := op.rect.Intersect(op.clip).Intersect(clip)
		if rect.Empty() {
			continue
		}
		source := &image.Uniform{C: op.color}
		switch op.kind {
		case 0:
			draw.Draw(rs.image, rect, source, image.Point{}, op.op)
		case 1:
			draw.DrawMask(rs.image, rect, source, image.Point{}, op.mask, rect.Min.Sub(op.rect.Min), draw.Over)
		case 2:
			rs.Scanner.SetClip(op.clip.Intersect(clip))
			rf := &rs.Raster.Filler
			rf.SetWinding(op.winding)
			rf.SetColor(source)
			op.path.AddTo(rf)
			rf.Draw()
			rf.Clear()
		}
	}
	// Preserve the text group's final winding state even when no strip needs it.
	rs.Scanner.SetWinding(p.winding)
}

func sameScrollPath(a, b Path, delta image.Point) bool {
	if len(a) != len(b) {
		return false
	}
	for i := 0; i < len(a); {
		if a[i] != b[i] {
			return false
		}
		n := pathCoordinates(PathCommand(a[i]))
		if n < 0 || i+n >= len(a) {
			return false
		}
		for j := 1; j <= n; j++ {
			shift := delta.X
			if j%2 == 0 {
				shift = delta.Y
			}
			if int64(a[i+j])+int64(shift)*64 != int64(b[i+j]) {
				return false
			}
		}
		i += n + 1
	}
	return true
}

// Compare the complete ordered operation stream affecting the overlap. Exposed
// cells may enter/leave, but every old paint in the overlap must have an equal
// translated current paint (including colors, masks, fixed outlines and clips).
// Pointer identities, face IDs, model stamps and hash collisions cannot admit reuse.
func sameScrollPaint(old, next *scrollPaintPlan, overlap image.Rectangle, delta image.Point) bool {
	if old == nil || next == nil {
		return false
	}
	previous := overlap.Sub(delta)
	ai, bi := 0, 0
	for {
		for ai < len(old.ops) && old.ops[ai].rect.Intersect(old.ops[ai].clip).Intersect(previous).Empty() {
			ai++
		}
		for bi < len(next.ops) && next.ops[bi].rect.Intersect(next.ops[bi].clip).Intersect(overlap).Empty() {
			bi++
		}
		if ai == len(old.ops) || bi == len(next.ops) {
			return ai == len(old.ops) && bi == len(next.ops)
		}
		a, b := &old.ops[ai], &next.ops[bi]
		if a.kind != b.kind || a.color != b.color || a.op != b.op || a.winding != b.winding || a.rect.Intersect(a.clip).Intersect(previous).Add(delta) != b.rect.Intersect(b.clip).Intersect(overlap) {
			return false
		}
		switch a.kind {
		case 1:
			if a.rect.Add(delta) != b.rect || a.mask.Rect != b.mask.Rect || !bytes.Equal(a.mask.Pix, b.mask.Pix) {
				return false
			}
		case 2:
			if a.clip.Intersect(previous).Add(delta) != b.clip.Intersect(overlap) || !sameScrollPath(a.path, b.path, delta) {
				return false
			}
		}
		ai++
		bi++
	}
}
