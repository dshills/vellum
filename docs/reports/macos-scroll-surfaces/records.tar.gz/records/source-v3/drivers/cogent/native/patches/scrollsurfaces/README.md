# Ordered scrolling surfaces

Stage 39 adds optional metadata to the existing painter ContextPush. The complete
original command stream remains in place, so SVG, PDF and other renderers retain
their order and fallback. Native raster replay restores an opaque rectangular
surface at its original painter position and redraws disjoint exposed strips.
It captures the result before later siblings paint, preserving their overlap.

The per-renderer cache retains at most 64 groups, 32 MiB of owned RGBA pixels and
8 MiB of detached actual-paint descriptors. Descriptor accounting includes mask
headers/pixels, fixed path data and operation slots, excluding Go allocator/map
metadata. Replacement capture temporarily overlaps old plans and builder/trim
allocations. Neither retained pixels nor descriptors reference widgets, models,
font faces, shaped runs, commands or borrowed glyph masks. Resize, eviction and
clock exhaustion retire both. Offsets are absolute integer output pixels with
checked signed subtraction; large jumps use full replay.

Native Grid panes request VerifyPaint. Capture follows the existing text renderer
on its originating owner, preserving glyph-data precedence and exact subpixel,
monospace, superscript/subscript, background and selection placement. It copies
actual alpha masks or fixed outline control points, known value colors and clips.
Ordered old operations translated into the overlap must exactly equal current
operations affecting that overlap; unknown/changed paints fall back. Full-mask
and full-outline comparison can conservatively reject safe reuse. The accepted
current plan also drives full/strip replay, closing the font/color checking-to-
drawing gap. The guard stops promptly at its descriptor/operation budget.

Uniform sources must really cover their destination within their finite bounds.
Unknown images/colors, transforms, masks, painting paths, blur, uncertain opaque
coverage and unsupported text use ordinary replay. Standard-box paths with both
fill and stroke disabled are harmless. SVG/bitmap, stroked, decorated, vertical
and math text are refused. Zero text clips are refused because the legacy raster
scanner interprets that rectangle as disabling clipping. Other callers may use
an explicit epoch promise; native Grid always uses the exact paint proof.

Quadratic/cubic filler curves flatten relative to their integer control hull and
restore its origin and terminal point exactly. The preceding absolute weighted
float calculation can change edges under integer translation. Some prior
antialias edge pixels intentionally change. Shaping, layout, glyph identities,
bounds and semantic geometry remain unchanged. Existing BSD attribution remains;
new tests and render metadata are MIT.

Tests compare exact emitted edges and prior-dispatch full-replay pixels, including
selected/bidi/combining text at four DPIs and four fractional phases; dirty parent
repaint and later overlaps; source bounds; signed extremes; resize/eviction;
changed ink, background, selection, clipping, physical phase, glyph output and
actual consumed mask bytes; capture limits; and real native-adapter frames.
The ordinary GPU image upload remains complete. This contract does not establish
strip-only GPU writes, physical GPU/presentation timing, native memory reclamation,
4/6 ms latency acceptance or complete Mac qualification.
