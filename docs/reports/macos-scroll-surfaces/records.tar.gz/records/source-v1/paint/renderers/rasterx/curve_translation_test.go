// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"math/rand"
	"testing"

	"golang.org/x/image/math/fixed"
)

type curveLines struct {
	*Filler
	points []fixed.Point26_6
}

func (r *curveLines) LineF(p fixed.Point26_6) { r.points = append(r.points, p); r.A = p }
func (r *curveLines) Line(p fixed.Point26_6)  { r.LineF(p) }
func (r *curveLines) JoinF()                  {}

func recordedCurve(points [4]fixed.Point26_6, cubic bool) []fixed.Point26_6 {
	r := &curveLines{Filler: &Filler{A: points[0]}}
	if cubic {
		r.CubeBezierF(r, points[1], points[2], points[3])
	} else {
		r.QuadBezierF(r, points[1], points[2])
	}
	return r.points
}

func TestCurveFlatteningExactIntegerTranslations(t *testing.T) {
	random := rand.New(rand.NewSource(319))
	for index := 0; index < 800; index++ {
		var points [4]fixed.Point26_6
		for i := range points {
			points[i] = fixed.Point26_6{X: fixed.Int26_6(random.Intn(32000) - 16000), Y: fixed.Int26_6(random.Intn(32000) - 16000)}
		}
		for _, cubic := range []bool{false, true} {
			original := recordedCurve(points, cubic)
			for _, delta := range []fixed.Point26_6{{64, 0}, {0, -64}, {37 * 64, -29 * 64}, {-251 * 64, 109 * 64}, {1 << 22, -1 << 22}} {
				translated := points
				for i := range translated {
					translated[i] = translated[i].Add(delta)
				}
				got := recordedCurve(translated, cubic)
				if len(got) != len(original) {
					t.Fatal("translation changed subdivision count", index, cubic, delta)
				}
				for i := range got {
					if got[i] != original[i].Add(delta) {
						t.Fatalf("translation changed edge: curve=%d cubic=%v delta=%v sample=%d got=%v want=%v", index, cubic, delta, i, got[i], original[i].Add(delta))
					}
				}
			}
		}
	}
}

func TestCurveRelativeCoordinateStaysInControlHull(t *testing.T) {
	for _, c := range []struct {
		origin, maximum fixed.Int26_6
		value           float32
		want            fixed.Int26_6
	}{{-100, 40, -1, -100}, {-100, 40, 0, -100}, {-100, 40, 87.75, -13}, {-100, 40, 141, 40}, {-1 << 31, 1<<31 - 1, 1 << 32, 1<<31 - 1}, {1<<31 - 100, 1<<31 - 1, 99, 1<<31 - 1}} {
		if got := relativeCurveCoordinate(c.origin, c.maximum, c.value); got != c.want {
			t.Fatal(c, got)
		}
	}
}
