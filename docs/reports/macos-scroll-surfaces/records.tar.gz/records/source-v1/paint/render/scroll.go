// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package render

import "image"

// ScrollSurface describes a complete rectangular painter group whose content
// moves by an integer number of output pixels. ID/Part identify one retained
// surface, without retaining its widget or domain model. Epoch must change when
// anything other than Position changes the group's pixels: data/order, selection,
// style/font resources, clipping, scale, editing, or layout. Zero ID/Epoch refuses
// caching. Bounds are in the destination raster's coordinates; Position is the
// accepted absolute scroll offset, not a delta from a possibly unrendered frame.
//
// The caller owns this promise. A renderer additionally validates supported
// commands and opaque coverage, bounds cache memory, and falls back to ordinary
// ordered rendering when reuse cannot be established. This hint never admits a
// partial GPU upload: the ordinary source image is still uploaded after drawing.
// The complete original command group is retained for other renderers and for
// repair; no cached commands or application references survive raster replay.
type ScrollSurface struct {
	ID       uint64
	Part     uint8
	Epoch    uint64
	Position image.Point
	Bounds   image.Rectangle
}
