// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"testing"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"cogentcore.org/core/text/textpos"
)

func TestScrollPaintChangesRefuseUnchangedEpoch(t *testing.T) {
	uc := units.Context{}
	uc.Defaults()
	style := rich.NewStyle()
	ts := text.NewStyle()
	ts.WhiteSpace = text.WrapNever
	ts.ToDots(&uc)
	shaper := shapedgt.NewShaperWithFonts(fonts.Embedded)
	lines := shaper.WrapLines(rich.NewText(style, []rune("Guard 012345 אבג é")), style, ts, math32.Vec2(240, 100))
	lines.Color = color.RGBA{R: 17, G: 31, B: 52, A: 255}
	paint := styles.NewPaint()
	bounds := image.Rect(11, 9, 191, 105)
	ctx := &render.Context{}
	ctx.Init(paint, &render.Bounds{Rect: math32.B2FromRect(bounds)}, nil)
	position := image.Point{}
	origin := math32.Vec2(19, 23)
	background := image.NewUniform(color.RGBA{R: 233, G: 237, B: 241, A: 255})
	actual := New(math32.Vec2(240, 160)).(*Renderer)
	reference := New(math32.Vec2(240, 160)).(*Renderer)
	frame := func() render.Render {
		return render.Render{
			pimage.NewDraw(image.Rect(0, 0, 240, 160), image.NewUniform(color.RGBA{R: 219, A: 255}), nil, image.Point{}, draw.Src),
			&render.ContextPush{Scroll: &render.ScrollSurface{ID: 1, Epoch: 1, Bounds: bounds, Position: position, VerifyPaint: true}},
			pimage.NewDraw(bounds, background, nil, bounds.Min, draw.Src),
			render.NewTextWithGeometry(lines, paint, ctx, origin.Sub(math32.FromPoint(position)), lines.InteractionLayout()),
			&render.ContextPop{},
			pimage.NewDraw(image.Rect(53, 31, 133, 49), image.NewUniform(color.RGBA{G: 171, A: 255}), nil, image.Point{}, draw.Src),
		}
	}
	check := func(label string, wantReuse bool) {
		t.Helper()
		items := frame()
		actual.Render(items)
		scrollReference(reference, items)
		if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
			t.Fatal(label, "pixel mismatch", actual.ScrollStats())
		}
		if (actual.ScrollStats().ReusedGroups == 1) != wantReuse {
			t.Fatal(label, "unexpected reuse", actual.ScrollStats())
		}
	}
	check("initial", false)
	position = image.Pt(3, 2)
	check("translate", true)
	mutations := []struct {
		name   string
		change func()
	}{
		{"ink", func() { lines.Color = color.NRGBA{R: 81, G: 91, B: 121, A: 123} }},
		{"background", func() { background.C = color.NRGBA{R: 191, G: 229, B: 221, A: 255} }},
		{"selection", func() {
			lines.SelectionColor = image.NewUniform(color.NRGBA{B: 221, A: 111})
			lines.SelectRegion(textpos.Range{Start: 0, End: 4})
		}},
		{"clip", func() { ctx.Bounds.Rect.Max.X -= 13 }},
		{"subpixel", func() { origin.X += .5 }},
		{"glyph-output", func() { run := lines.Lines[0].Runs[0].(*shapedgt.Run); run.Glyphs[0].XOffset += 64 }},
	}
	for _, m := range mutations {
		m.change()
		check(m.name, false)
		check(m.name+"-stable", true)
	}
	// Existing mask resources are mutable in Go. Verify the proof stores detached
	// bytes and notices a change in the exact mask ordinary replay would consume.
	cache := actual.scrollCache[scrollKey{1, 0}]
	if cache == nil || cache.plan == nil {
		t.Fatal("no retained proof")
	}

	run := lines.Lines[0].Runs[0].(*shapedgt.Run)
	glyph := &run.Glyphs[0]
	outline, ok := run.Face.GlyphDataOutline(glyph.GlyphID)
	if !ok {
		t.Fatal("fixture glyph has no outline")
	}
	glyphPos := origin.Sub(math32.FromPoint(position)).Add(lines.Offset).Add(lines.Lines[0].Offset).Add(math32.Vec2(math32.FromFixed(glyph.XOffset), -math32.FromFixed(glyph.YOffset)))
	scale := math32.FromFixed(run.Size) / float32(run.Face.Upem())
	if width, advance := math32.FromFixed(glyph.Width), math32.Abs(math32.FromFixed(glyph.Advance)); width > advance && run.Font.Style(&ctx.Style.Text).Family == rich.Monospace {
		scale *= .95 * advance / width
	}
	resource, maskPos := theGlyphCache.Glyph(run.Face, glyph, outline, scale, glyphPos)
	if resource == nil {
		t.Fatal("fixture actual glyph did not use a mask")
	}
	consumed := false
	for _, op := range cache.plan.ops {
		if op.kind == 1 && op.rect == resource.Rect.Add(maskPos) && !op.rect.Intersect(op.clip).Empty() && bytes.Equal(op.mask.Pix, resource.Pix) {
			consumed = true
		}
	}
	if !consumed {
		t.Fatal("exact current glyph mask not consumed by retained plan")
	}
	saved := bytes.Clone(resource.Pix)
	defer copy(resource.Pix, saved)
	for i := range resource.Pix {
		resource.Pix[i] ^= 0xff
	}
	items := frame()
	actual.Render(items)
	scrollReference(reference, items)
	if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
		t.Fatal("mutable mask pixel mismatch")
	}
	if actual.ScrollStats().ReusedGroups != 0 || actual.ScrollStats().PaintRefusals != 1 {
		t.Fatal("changed consumed mask incorrectly reused", actual.ScrollStats())
	}

	ctx.Bounds.Rect = math32.Box2{}
	items = frame()
	actual.Render(items)
	scrollReference(reference, items)
	if !bytes.Equal(actual.image.Pix, reference.image.Pix) || actual.ScrollStats().ReusedGroups != 0 || actual.ScrollStats().CachedBytes != 0 {
		t.Fatal("zero text clip did not use complete unclipped fallback", actual.ScrollStats())
	}

}

func TestScrollPaintPacketBudgetAndExactBytes(t *testing.T) {
	p := &scrollPaintPlan{}
	fill := image.NewUniform(color.RGBA{A: 255})
	mask := image.NewAlpha(image.Rect(0, 0, 128, 128))
	mask.Pix[0] = 131
	p.addMask(mask, image.Pt(3, 4), image.Rect(0, 0, 160, 160), fill)
	if p.failed || p.ops[0].mask.Pix[0] != 131 {
		t.Fatal("mask capture failed")
	}
	mask.Pix[0] = 19
	if p.ops[0].mask.Pix[0] != 131 {
		t.Fatal("retained source mask reference")
	}
	next := &scrollPaintPlan{}
	next.addMask(mask, image.Pt(3, 4), image.Rect(0, 0, 160, 160), fill)
	if sameScrollPaint(p, next, image.Rect(0, 0, 160, 160), image.Point{}) {
		t.Fatal("different actual mask admitted")
	}
	for !p.failed {
		p.addMask(mask, image.Point{}, image.Rect(0, 0, 160, 160), fill)
	}
	if p.bytes > scrollPlanBudget || len(p.ops) > scrollPlanMaxOps {
		t.Fatal("packet budget exceeded")
	}
	actual := New(math32.Vec2(240, 160)).(*Renderer)
	for i := uint64(1); i <= 80; i++ {
		items := scrollFrame(image.Rect(11, 9, 191, 105), image.Pt(120, 96), 1)
		hint := items[1].(*render.ContextPush).Scroll
		hint.ID = i
		hint.VerifyPaint = true
		actual.Render(items)
	}
	if actual.scrollPlanBytes > scrollPlanBudget || actual.scrollBytes > scrollCacheBudget || len(actual.scrollCache) > scrollCacheGroups {
		t.Fatal("retained aggregate budget exceeded")
	}
	actual.SetSize(units.UnitDot, math32.Vec2(241, 160))
	if len(actual.scrollCache) != 0 || actual.scrollPlanBytes != 0 || actual.scrollBytes != 0 {
		t.Fatal("resize did not retire proofs")
	}
}

func TestScrollPaintCaptureStopsAfterBudgetFailure(t *testing.T) {
	uc := units.Context{}
	uc.Defaults()
	style := rich.NewStyle()
	ts := text.NewStyle()
	ts.ToDots(&uc)
	lines := shapedgt.NewShaperWithFonts(fonts.Embedded).WrapLines(rich.NewText(style, []rune("Guard")), style, ts, math32.Vec2(200, 100))
	lines.Color = color.RGBA{A: 255}
	// The second run would panic on its nil font face if capture traversed it.
	run := *lines.Lines[0].Runs[0].(*shapedgt.Run)
	run.Face = nil
	lines.Lines[0].Runs = append(lines.Lines[0].Runs, &run)
	ctx := &render.Context{}
	ctx.Init(styles.NewPaint(), &render.Bounds{Rect: math32.B2(0, 0, 240, 160)}, nil)
	actual := New(math32.Vec2(240, 160)).(*Renderer)
	plan := &scrollPaintPlan{bytes: scrollPlanBudget, winding: true}
	actual.scrollRecord = plan
	actual.TextLinesWithGeometry(ctx, lines, math32.Vec2(10, 10), nil)
	if !plan.failed || len(plan.ops) != 0 {
		t.Fatal("capture did not stop at budget")
	}
}

func TestScrollPaintPathRetentionHasExactCapacity(t *testing.T) {
	p := &scrollPaintPlan{winding: true}
	var path Path
	path.Start(math32.Vec2(1, 2).ToFixed())
	path.Line(math32.Vec2(3, 4).ToFixed())
	path.Stop(true)
	p.addPath(path, image.Rect(0, 0, 10, 10), image.NewUniform(color.RGBA{A: 255}))
	if p.failed || len(p.ops) != 1 || cap(p.ops[0].path) != len(p.ops[0].path) {
		t.Fatal("retained path capacity exceeds accounted length")
	}
	path[1] += 64
	if p.ops[0].path[1] == path[1] {
		t.Fatal("retained borrowed path")
	}
}
