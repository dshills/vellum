// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"math"
	"math/rand"
	"testing"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"cogentcore.org/core/text/textpos"
)

// Replay the previous dispatch, ignoring the new hint. This oracle executes
// every original item at its original painter position, including later peers.
func scrollReference(rs *Renderer, items render.Render) {
	for i, item := range items {
		switch x := item.(type) {
		case *render.Path:
			rs.RenderPath(x)
		case *pimage.Params:
			if i+1 < len(items) {
				if next, ok := items[i+1].(*pimage.Params); ok && coveredUniformDraw(x, next) {
					continue
				}
			}
			x.Render(rs.image)
		case *render.Text:
			rs.RenderText(x)
		}
	}
}

func scrollPattern(bounds image.Rectangle, position image.Point, epoch uint64) render.Render {
	items := render.Render{pimage.NewDraw(bounds, image.NewUniform(color.RGBA{R: 19, G: 27, B: 35, A: 255}), nil, bounds.Min, draw.Src)}
	// The content is defined in stable world coordinates, not by a pooled slot.
	for y := -8; y < bounds.Dy()+16; y += 8 {
		for x := -12; x < bounds.Dx()+24; x += 12 {
			worldX := x + position.X/12*12
			worldY := y + position.Y/8*8
			r := image.Rect(bounds.Min.X+x-position.X%12, bounds.Min.Y+y-position.Y%8, bounds.Min.X+x-position.X%12+10, bounds.Min.Y+y-position.Y%8+6).Intersect(bounds)
			if r.Empty() {
				continue
			}
			c := color.RGBA{R: uint8(worldX*3 + int(epoch)), G: uint8(worldY * 7), B: uint8(worldX ^ worldY), A: 149}
			items = append(items, pimage.NewDraw(r, image.NewUniform(c), nil, r.Min, draw.Over))
		}
	}
	return items
}

func scrollFrame(bounds image.Rectangle, position image.Point, epoch uint64) render.Render {
	all := render.Render{pimage.NewDraw(image.Rect(0, 0, 240, 160), image.NewUniform(color.RGBA{R: uint8(epoch * 31), A: 255}), nil, image.Point{}, draw.Src)}
	all = append(all, &render.ContextPush{Scroll: &render.ScrollSurface{ID: 7, Part: 2, Epoch: epoch, Position: position, Bounds: bounds}})
	all = append(all, scrollPattern(bounds, position, epoch)...)
	all = append(all, &render.ContextPop{})
	// A fixed overlay intersects the surface. Capturing it into the scrolling
	// image, or composing the surface after the scene, would move/cover it.
	all = append(all, pimage.NewDraw(image.Rect(41, 27, 113, 71), image.NewUniform(color.RGBA{R: 241, G: 63, B: 7, A: 255}), nil, image.Point{}, draw.Src))
	return all
}

func TestScrollSurfaceOrderedPixelsAndActualReuse(t *testing.T) {
	actual := New(math32.Vec2(240, 160)).(*Renderer)
	reference := New(math32.Vec2(240, 160)).(*Renderer)
	bounds := image.Rect(11, 9, 191, 105)
	position := image.Pt(120, 96)
	epoch := uint64(1)
	random := rand.New(rand.NewSource(91))
	reused := 0
	for frame := 0; frame < 160; frame++ {
		if frame%23 == 0 {
			epoch++
		}
		if frame > 0 {
			position = position.Add(image.Pt(random.Intn(19)-9, random.Intn(13)-6))
		}
		items := scrollFrame(bounds, position, epoch)
		actual.Render(items)
		if actual.ScrollStats().CapturedPixels != actual.ScrollStats().RedrawPixels {
			t.Fatal("cache capture exceeded exposed/redrawn area", actual.ScrollStats())
		}
		scrollReference(reference, items)
		if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
			t.Fatalf("pixels differ at frame %d offset %v epoch %d", frame, position, epoch)
		}
		stats := actual.ScrollStats()
		if stats.ReusedGroups > 0 {
			reused++
			if stats.ReusedPixels+stats.RedrawPixels != bounds.Dx()*bounds.Dy() {
				t.Fatal("damage areas overlap or leave a hole", stats)
			}
		}
		if frame%23 == 0 && stats.FullRedraws != 1 {
			t.Fatal("changed content did not repair the complete surface", stats)
		}
		if stats.CachedBytes != 4*bounds.Dx()*bounds.Dy() {
			t.Fatal("unexpected cache retention", stats)
		}
	}
	if reused < 140 {
		t.Fatalf("oracle passed without effective reuse: %d", reused)
	}
}

func TestScrollSurfaceBoundsRepairAndUnsupportedFallback(t *testing.T) {
	actual := New(math32.Vec2(240, 160)).(*Renderer)
	reference := New(math32.Vec2(240, 160)).(*Renderer)
	bounds := image.Rect(11, 9, 191, 105)
	for i := 0; i < 5; i++ {
		items := scrollFrame(bounds, image.Pt(i*3, 16), 1)
		if i == 2 {
			// A destination-dependent blur cannot be drawn strip by strip.
			items = append(items[:len(items)-2], append(render.Render{pimage.NewBlur(bounds, 2)}, items[len(items)-2:]...)...)
		}
		if i == 3 {
			bounds = image.Rect(13, 11, 189, 101)
			items = scrollFrame(bounds, image.Pt(i*3, 16), 1)
		}
		actual.Render(items)
		if actual.ScrollStats().CapturedPixels != actual.ScrollStats().RedrawPixels {
			t.Fatal("cache capture exceeded exposed/redrawn area", actual.ScrollStats())
		}
		scrollReference(reference, items)
		if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
			t.Fatal("fallback or bounds repair changed pixels", i)
		}
		if i == 2 && actual.ScrollStats().CachedBytes != 0 {
			t.Fatal("unsupported group retained a stale cache")
		}
		if i == 3 && actual.ScrollStats().ReusedGroups != 0 {
			t.Fatal("changed bounds reused old pixels")
		}
	}
	actual.SetSize(units.UnitDot, math32.Vec2(250, 170))
	if actual.scrollBytes != 0 || len(actual.scrollCache) != 0 {
		t.Fatal("resize retained surfaces")
	}
}

func TestScrollSurfaceCheckedOffsetsAndBudgets(t *testing.T) {
	for _, c := range []struct {
		a, b, want int
		ok         bool
	}{{math.MaxInt, math.MaxInt - 1, 1, true}, {math.MinInt, math.MinInt + 1, -1, true}, {math.MinInt, math.MaxInt, 0, false}, {math.MaxInt, math.MinInt, 0, false}, {0, 10, 0, false}, {9, 0, 9, true}} {
		if got, ok := scrollDifference(c.a, c.b, 10); got != c.want || ok != c.ok {
			t.Fatal(c, got, ok)
		}
	}
	rs := New(math32.Vec2(240, 160)).(*Renderer)
	bounds := image.Rect(11, 9, 191, 105)
	for id := uint64(1); id <= 80; id++ {
		items := scrollFrame(bounds, image.Point{}, 1)
		items[1].(*render.ContextPush).Scroll.ID = id
		rs.Render(items)
		if len(rs.scrollCache) > scrollCacheGroups || rs.scrollBytes > scrollCacheBudget {
			t.Fatal("cache is unbounded")
		}
	}
	if len(rs.scrollCache) != scrollCacheGroups {
		t.Fatal("cache is not exercising eviction")
	}
	rs.scrollClock = math.MaxUint64
	rs.Render(scrollFrame(bounds, image.Point{}, 1))
	if rs.scrollClock != 1 || len(rs.scrollCache) != 1 {
		t.Fatal("clock exhaustion did not repair/reset cache")
	}
	items := scrollFrame(bounds, image.Point{}, 1)
	items[1].(*render.ContextPush).Scroll.Epoch = 0
	rs.Render(items)
	if len(rs.scrollCache) != 0 {
		t.Fatal("zero epoch retained a cache")
	}
}

func TestScrollSurfaceUniformSourceBoundsCannotAdmitParentPixels(t *testing.T) {
	actual := New(math32.Vec2(240, 160)).(*Renderer)
	reference := New(math32.Vec2(240, 160)).(*Renderer)
	bounds := image.Rect(11, 9, 191, 105)
	for _, sourceX := range []int{0, 1e9, math.MaxInt, -1e9 - 1, 1e9 - bounds.Dx() + 1, 0} {
		items := scrollFrame(bounds, image.Pt(3, 7), 1)
		items[0].(*pimage.Params).Source = image.NewUniform(color.RGBA{R: uint8(sourceX), G: 93, B: 211, A: 255})
		items[2].(*pimage.Params).SourcePos.X = sourceX
		actual.Render(items)
		if actual.ScrollStats().CapturedPixels != actual.ScrollStats().RedrawPixels {
			t.Fatal("cache capture exceeded exposed/redrawn area", actual.ScrollStats())
		}
		scrollReference(reference, items)
		if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
			t.Fatal("clipped uniform coverage captured/restored parent pixels", sourceX)
		}
		if sourceX != 0 && (actual.ScrollStats().ReusedGroups != 0 || actual.scrollBytes != 0) {
			t.Fatal("source clipping did not refuse caching", sourceX)
		}
	}
}

func TestScrollSurfaceShapedTextAndFractionalPhasePixels(t *testing.T) {
	for _, dpi := range []float32{96, 120, 144, 192} {
		for _, phase := range []float32{0, .25, .5, .75} {
			uc := units.Context{}
			uc.Defaults()
			uc.DPI = dpi
			style := rich.NewStyle()
			textStyle := text.NewStyle()
			textStyle.WhiteSpace = text.WrapNever
			textStyle.ToDots(&uc)
			shaper := shapedgt.NewShaperWithFonts(fonts.Embedded)
			lines := shaper.WrapLines(rich.NewText(style, []rune("0123456789 אבג é")), style, textStyle, math32.Vec2(240, 100))
			lines.Color = color.NRGBA{R: 17, G: 31, B: 52, A: 229}
			lines.SelectionColor = image.NewUniform(color.NRGBA{R: 91, G: 127, B: 179, A: 93})
			lines.SelectRegion(textpos.Range{Start: 0, End: 7})
			paint := styles.NewPaint()
			context := &render.Context{}
			bounds := image.Rect(11, 9, 191, 105)
			context.Init(paint, &render.Bounds{Rect: math32.B2FromRect(bounds)}, nil)
			actual := New(math32.Vec2(240, 160)).(*Renderer)
			reference := New(math32.Vec2(240, 160)).(*Renderer)
			for index, position := range []image.Point{{0, 0}, {7, 4}, {-3, 9}, {12, 1}, {12, 1}, {2, 0}, {0, 0}} {
				items := render.Render{pimage.NewDraw(image.Rect(0, 0, 240, 160), image.NewUniform(color.RGBA{R: 219, G: 181, B: 173, A: 255}), nil, image.Point{}, draw.Src), &render.ContextPush{Scroll: &render.ScrollSurface{ID: 1, Epoch: 1, Bounds: bounds, Position: position, VerifyPaint: true}}}
				items = append(items, pimage.NewDraw(bounds, image.NewUniform(color.RGBA{R: 233, G: 237, B: 241, A: 255}), nil, bounds.Min, draw.Src))
				origin := math32.Vec2(19+phase, 23+phase).Sub(math32.FromPoint(position))
				items = append(items, render.NewTextWithGeometry(lines, paint, context, origin, lines.InteractionLayout()), &render.ContextPop{})
				actual.Render(items)
				if actual.ScrollStats().CapturedPixels != actual.ScrollStats().RedrawPixels {
					t.Fatal("cache capture exceeded exposed/redrawn area", actual.ScrollStats())
				}
				scrollReference(reference, items)
				if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
					count := 0
					var first image.Point
					for y := 0; y < 160; y++ {
						for x := 0; x < 240; x++ {
							if actual.image.RGBAAt(x, y) != reference.image.RGBAAt(x, y) {
								if count == 0 {
									first = image.Pt(x, y)
								}
								count++
							}
						}
					}
					t.Log("different pixels", count, "first", first, "actual", actual.image.RGBAAt(first.X, first.Y), "full", reference.image.RGBAAt(first.X, first.Y), "stats", actual.ScrollStats())
					t.Fatalf("text pixels differ dpi=%v phase=%v frame=%d", dpi, phase, index)
				}
				if index > 0 && actual.ScrollStats().ReusedGroups != 1 {
					t.Fatal("text differential did not exercise reuse", dpi, phase, index, actual.ScrollStats())
				}
			}
		}
	}
}

func TestScrollRingWrappedCopiesExact(t *testing.T) {
	for _, bounds := range []image.Rectangle{image.Rect(-13, 7, -2, 16), image.Rect(5, -9, 6, -2), image.Rect(17, 23, 26, 24), image.Rect(3, 4, 4, 5)} {
		logical := image.NewRGBA(bounds)
		for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
			for x := bounds.Min.X; x < bounds.Max.X; x++ {
				logical.SetRGBA(x, y, color.RGBA{R: uint8(x*13 + y), G: uint8(x - y*7), B: uint8(x * y), A: uint8(31 + x + y)})
			}
		}
		for oy := 0; oy < bounds.Dy(); oy++ {
			for ox := 0; ox < bounds.Dx(); ox++ {
				offset := image.Pt(ox, oy)
				ring := image.NewRGBA(bounds)
				scrollRingCopy(logical, ring, bounds, offset, true)
				for _, region := range []image.Rectangle{bounds, image.Rect(bounds.Min.X, bounds.Min.Y, bounds.Min.X+1, bounds.Min.Y+1), image.Rect(bounds.Min.X+bounds.Dx()/3, bounds.Min.Y+bounds.Dy()/3, bounds.Max.X, bounds.Max.Y)} {
					actual := image.NewRGBA(bounds)
					reference := image.NewRGBA(bounds)
					draw.Draw(actual, bounds, image.NewUniform(color.RGBA{B: 219, A: 255}), image.Point{}, draw.Src)
					draw.Draw(reference, bounds, image.NewUniform(color.RGBA{B: 219, A: 255}), image.Point{}, draw.Src)
					scrollRingCopy(actual, ring, region, offset, false)
					draw.Draw(reference, region, logical, region.Min, draw.Src)
					if !bytes.Equal(actual.Pix, reference.Pix) {
						t.Fatal("wrapped restore", bounds, offset, region)
					}
					changed := image.NewRGBA(bounds)
					draw.Draw(changed, bounds, logical, bounds.Min, draw.Src)
					draw.Draw(changed, region, image.NewUniform(color.RGBA{R: 99, G: 71, B: 39, A: 167}), image.Point{}, draw.Src)
					scrollRingCopy(changed, ring, region, offset, true)
					scrollRingCopy(actual, ring, bounds, offset, false)
					if !bytes.Equal(actual.Pix, changed.Pix) {
						t.Fatal("wrapped partial store corrupted other pixels", bounds, offset, region)
					}
					scrollRingCopy(logical, ring, bounds, offset, true)
				}
			}
		}
	}
}
