"""Independent read-only versioned receipt and statistics audit, stdlib only."""
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HELPER = Path('/private/tmp/vellum-raster-coverage-protocol-review/final-receipts/audit.py')
s = importlib.util.spec_from_file_location('independent_statistics', HELPER)
h = importlib.util.module_from_spec(s)
s.loader.exec_module(h)
ROOT = Path('/private/tmp/vellum-large-data')
Q = Path('/private/tmp/vellum-scroll-surfaces')
OUT = Path(__file__).parent
h.ROOT, h.Q = ROOT, Q
read, text, record, sha, map_sha = h.data, h.text, h.record, h.sha, h.map_sha


def check_child(folder, child, expected=0):
    assert child['exit_code'] == expected and child['error'] is None
    assert child['log_sha256'] == sha(folder / (child['name'] + '.log'))


def main():
    phases = {'v3': 'integrated-checks-v3-retry', 'v4': 'final-checks-v4',
              'v5': 'final-checks-v5', 'v6': 'final-checks-v6'}
    sources, checks, reviews = {}, {}, {}
    for version, phase in phases.items():
        source = sources[version] = record(Q / ('source-' + version + '.json'))
        check = checks[version] = record(Q / phase / 'qualification.json')
        review = reviews[version] = record(Q / ('internal-integrated-review-' + version + '.json'))
        assert check['result'] == 'PASS' and check['source_before'] == check['source_after']
        assert len(check['source_before']) == 659 and len(check['prepared']) == 6146
        assert len(check['checks']) == {'v3': 13, 'v4': 7, 'v5': 7, 'v6': 10}[version]
        assert check['producer_sha256'] == sha(Q / phase / 'producer.py.txt')
        assert source['base_commit'] == '56d394fa0ce6084033ca86c79d3456b560e59d4c'
        assert review['reviewed_source_sha256'] == source['source_sha256']
        assert review['patch_sha256'] == source['patch_sha256']
        assert review['status'] == ('NEEDS_BUDGET_FIX' if version == 'v3' else 'APPROVED')
        if version != 'v3':
            assert review['findings'] == []
        else:
            assert len(review['findings']) == 1 and review['findings'][0]['id'] == 'SCROLL-PATH-CAPACITY'
            assert 'Fixed in v4' in review['findings'][0]['final_resolution']
        for path, value in source['source_sha256'].items():
            assert sha(Q / ('source-' + version) / path) == value, (version, path)
            if path in check['source_after']:
                assert check['source_after'][path] == value
        assert sha(Q / ('source-' + version) / 'drivers/cogent/native/patches/scrollsurfaces/0039-ordered-scroll-surfaces.patch') == source['patch_sha256']
        for path, value in source['prepared_output_sha256'].items():
            assert check['prepared']['drivers/cogent/build/upstream/' + path] == value
            assert sha(Q / ('source-' + version) / path) == value
        for child in check['checks']:
            check_child(Q / phase, child)
        assert len(check['generated_outputs_retained']) == (0 if version == 'v6' else 17)
        for generated in check['generated_outputs_retained']:
            assert sha(Q / phase / 'generated-test-images' / generated['path']) == generated['sha256']
            assert not (ROOT / generated['path']).exists()
        for name, value in check['binaries'].items():
            assert sha(Path('/private/tmp') / name) == value
    assert checks['v6']['prepared'] == checks['v5']['prepared']
    assert sources['v6']['prepared_output_sha256'] == sources['v5']['prepared_output_sha256']
    assert sources['v6']['patch_sha256'] == sources['v5']['patch_sha256']
    final_state = {'source': checks['v6']['source_after'], 'prepared': checks['v6']['prepared']}
    for path, expected in final_state['source'].items():
        assert sha(ROOT / path) == expected
    prepared = {str(p.relative_to(ROOT)): sha(p) for dep in ('upstream', 'typesetting')
                for p in sorted((ROOT / 'drivers/cogent/build' / dep).rglob('*')) if p.is_file()}
    assert prepared == final_state['prepared']
    current_source_paths = {str(ROOT / path) for path in final_state['source']}
    for path in list(h.FILES):
        if path in current_source_paths or path.startswith(str(ROOT / 'drivers/cogent/build') + '/'):
            del h.FILES[path]
    for path, value in sources['v6']['source_sha256'].items():
        target = ROOT / ('drivers/cogent/build/upstream/' + path if path.startswith('paint/') else path)
        assert sha(target) == value

    baseline = record(Q / 'baseline-link.json')
    assert baseline['result'] == 'PASS_PRECEDING_ARTIFACT_LINK'
    assert baseline['head'] == sources['v6']['base_commit']
    prior = record(baseline['qualified_build_path'])
    assert sha(baseline['qualified_build_path']) == baseline['qualified_build_sha256']
    assert prior['result'] == 'PASS' and prior['before'] == prior['after']
    assert baseline['source'] == prior['after']['source'] and baseline['prepared'] == prior['after']['prepared']
    assert baseline['binary_sha256'] == prior['binaries'][Path(baseline['binary_path']).name] == sha(baseline['binary_path'])
    assert len(baseline['source']) == 653 and len(baseline['prepared']) == 6140
    # Experimental v4/v5 emit hints without the new v6 opt-in branch.
    for version in ('v4', 'v5'):
        paint = text(Q / ('source-' + version) / 'drivers/cogent/grid_scroll.go')
        assert 'push.Scroll = &render.ScrollSurface' in paint and 'gridScrollReuseProperty' not in paint
    paint = text(ROOT / 'drivers/cogent/grid_scroll.go')
    assert 'enabled, _ := p.Scene.Property(gridScrollReuseProperty).(bool)' in paint
    assert paint.index('if !enabled {') < paint.index('start := len(*items)')
    assert 'p.Frame.RenderWidget()\n\t\treturn' in paint
    assert 'ExperimentalGridScrollReuse bool' in text(ROOT / 'drivers/cogent/driver.go')
    assert 'ExperimentalGridScrollReuse bool' in text(ROOT / 'drivers/cogent/manual.go')

    native = {}
    for version in ('v4', 'v5', 'v6'):
        proof = native[version] = record(Q / ('native-' + version) / 'qualification.json')
        state = {'source': checks[version]['source_after'], 'prepared': checks[version]['prepared']}
        assert proof['result'] == 'PASS' and proof['before'] == proof['after'] == state
        assert proof['qualified_build_sha256'] == sha(Q / phases[version] / 'qualification.json')
        assert proof['binaries'] == checks[version]['binaries']
        assert proof['producer_sha256'] == sha(Q / ('native-' + version) / 'producer.py.txt')
        assert len(proof['checks']) == 3
        for child in proof['checks']:
            check_child(Q / ('native-' + version), child)
        for name, count in (('fixed-10k', 10000), ('variable-million', 1000000)):
            events = [json.loads(line) for line in text(Q / ('native-' + version) / (name + '.log')).splitlines() if line.startswith('{')]
            assert [e['event'] for e in events] == ['grid.accessibility.pass', 'grid.accessibility.closed']
            assert events[0]['rows'] == count and events[0]['visible_minimum'] == 400 and events[0]['native_press_admitted'] is True
            assert events[0]['overlap_objects_reused'] > 0 and events[0]['replacement_objects_retired'] > 0
            assert events[1]['attachment_query_refused'] is True
        generic = json.loads(text(Q / ('native-' + version) / 'generic-ax.log'))
        assert generic['result'] == 'PASS' and generic['preferences_changed'] is False and generic['voiceover_tested'] is False
    pixel_log = text(Q / 'final-checks-v6/native-policy-pixel-race.log')
    frame_records = re.findall(r'frame=(\d+) dpi=(\d+) scroll=', pixel_log)
    assert len(frame_records) == 56
    assert sorted((int(f), int(dpi)) for f, dpi in frame_records) == sorted((f, dpi) for dpi in (96, 120, 144, 192) for f in range(14))
    assert '--- PASS: TestManagedGridScrollReuseDisabledByDefault ' in pixel_log
    for dpi in ('96', '120', '144', '192'):
        assert '--- PASS: TestManagedGridScrollReuseDisabledByDefault/' + dpi in pixel_log
    default_test = text(ROOT / 'drivers/cogent/grid_scroll_offscreen_test.go').split('func TestManagedGridScrollReuseDisabledByDefault', 1)[1]
    assert 'for frame := 0; frame < 3; frame++ {' in default_test

    negative = record(Q / 'legacy-kernel-negative-v4/qualification.json')
    assert negative['result'] == 'PASS_MEANINGFUL_NEGATIVE' and negative['before'] == negative['after']
    assert negative['before'] == native['v4']['before']
    assert negative['producer_sha256'] == sha(Q / 'legacy-kernel-negative-v4/producer.py.txt')
    check_child(Q / 'legacy-kernel-negative-v4', negative['check'], 1)
    neglog = text(Q / 'legacy-kernel-negative-v4/legacy-kernel.log')
    assert '--- FAIL: TestCurveFlatteningExactIntegerTranslations' in neglog
    assert '--- FAIL: TestScrollSurfaceShapedTextAndFractionalPhasePixels' in neglog
    assert 'build failed' not in neglog and 'setup failed' not in neglog and 'panic:' not in neglog
    assert sha(Q / 'legacy-kernel-negative-v4/fill.go') == negative['original_kernel_sha256']
    assert sha(Q / 'legacy-kernel-negative-v4/vellum-scroll-legacy-fill-with-helper.go.txt') == negative['legacy_source_sha256']
    assert read(Q / 'legacy-kernel-negative-v4/vellum-scroll-legacy-fill-with-helper.go.txt').startswith(read(Q / 'legacy-kernel-negative-v4/fill.go'))
    assert sha(Q / 'original-inputs/paint/renderers/rasterx/fill.go') == negative['original_kernel_sha256']
    record(Q / 'legacy-kernel-negative-v4/vellum-scroll-legacy-curve-overlay.json')

    cases = ['fixed-10000', 'fixed-1000000', 'variable-10000', 'variable-1000000']
    perf_proofs, recomputed, regressions = {}, {}, {}
    geometry_pairs, target_failures = 0, 0
    for version in ('v4', 'v5'):
        phase = 'performance-' + version
        proof = perf_proofs[version] = record(Q / phase / 'qualification.json')
        assert proof['result'] == 'PASS_MATCHED_COMPARISON'
        assert proof['before'] == proof['after'] == native[version]['after']
        assert proof['source_review_sha256'] == sha(Q / ('internal-integrated-review-' + version + '.json'))
        assert proof['producer_sha256'] == sha(Q / phase / 'producer.py.txt')
        assert proof['baseline_head'] == baseline['head']
        assert proof['samples'] == 4800 and proof['runs_per_case_build'] == 5 and proof['samples_per_run'] == 120 and proof['warmup'] == 128
        assert proof['benchmark_sha256'] == sha(ROOT / 'scripts/benchmark-grid.py')
        changed = sorted(p for p in baseline['source'].keys() | proof['before']['source'].keys()
                         if baseline['source'].get(p) != proof['before']['source'].get(p))
        owned = {p: v for p, v in sources[version]['source_sha256'].items() if p in proof['before']['source']}
        assert changed == proof['baseline_changed_paths'] == sorted(owned)
        assert all(proof['before']['source'][p] == value for p, value in owned.items())
        prep_changes = {p for p in baseline['prepared'].keys() | proof['before']['prepared'].keys()
                        if baseline['prepared'].get(p) != proof['before']['prepared'].get(p)}
        assert sorted(prep_changes) == proof['prepared_changed_paths']
        assert prep_changes == {'drivers/cogent/build/upstream/' + p for p in sources[version]['prepared_output_sha256']}
        assert len([p for p in prep_changes if p not in baseline['prepared']]) == 6
        assert proof['binaries']['baseline'] == baseline['binary_sha256']
        assert proof['binaries']['candidate'] == checks[version]['binaries']['vellum-scroll-candidate-' + version]
        expected = [(build, case, rep) for case in cases for rep in range(1, 6)
                    for build in (('baseline', 'candidate') if rep % 2 else ('candidate', 'baseline'))]
        assert [(r['build'], r['case'], r['repetition']) for r in proof['runs']] == expected
        all_runs = {build: {case: [] for case in cases} for build in ('baseline', 'candidate')}
        summary = record(Q / phase / 'summary.json')
        assert sha(Q / phase / 'summary.json') == proof['summary_sha256']
        for item in proof['runs']:
            build, case, rep = item['build'], item['case'], item['repetition']
            folder = Q / phase / build / case / ('run-' + str(rep))
            result = record(folder / 'result.json')
            assert sha(folder / 'result.json') == item['result_sha256'] and result['result'] == 'PASS' and result['exit_code'] == 0 and result['error'] is None
            assert sha(folder / 'native.log') == result['log_sha256']
            assert h.raw_records(folder / 'native.log') == result['records']
            count, variable = int(case.split('-')[1]), case.startswith('variable')
            binary = baseline['binary_path'] if build == 'baseline' else '/private/tmp/vellum-scroll-candidate-' + version
            assert result['argv'] == [binary, '-perf', '-rows=' + str(count), '-perf-samples=120', '-perf-warmup=128'] + (['-variable-rows'] if variable else [])
            samples = h.validate_run(result, count, variable)
            stats = h.distribution([s['metrics']['ui_work_ns'] for s in samples])
            assert stats['p95'] > 4000000 and stats['p99'] > 6000000
            target_failures += 1
            all_runs[build][case].append(samples)
        recalculated = {build: {case: {'timings_ns': h.summarize(samples)} for case, samples in values.items()} for build, values in all_runs.items()}
        assert summary == recalculated
        assert proof['warm_targets_ns'] == {'p95': 4000000, 'p99': 6000000} and proof['warm_target_met'] == {'baseline': False, 'candidate': False}
        recomputed[version] = recalculated
        regressions[version] = {case: 100 * (recalculated['candidate'][case]['timings_ns']['ui_work_ns']['pooled']['p95'] /
                                           recalculated['baseline'][case]['timings_ns']['ui_work_ns']['pooled']['p95'] - 1) for case in cases}
        assert all(v > 0 for v in regressions[version].values())
        for case in cases:
            for a, b in zip(all_runs['baseline'][case], all_runs['candidate'][case]):
                for first, second in zip(a, b):
                    assert first['geometry'] == second['geometry']
                    geometry_pairs += 1
        for build in all_runs:
            for height in ('fixed', 'variable'):
                for a, b in zip(all_runs[build][height + '-10000'], all_runs[build][height + '-1000000']):
                    for first, second in zip(a, b):
                        assert first['geometry'] == second['geometry']
                        geometry_pairs += 1
    assert geometry_pairs == 9600 and target_failures == 80

    values = record(Q / 'report-values.json')
    original_report = read(Q / 'report-generated-v1.md.txt')
    assert hashlib.sha256(original_report).hexdigest() == values['report_sha256']
    update = record(Q / 'report-doc-update.json')
    final_report_path = ROOT / 'docs/reports/macos-scroll-surfaces/README.md'
    final_report = text(final_report_path)
    assert update['before_sha256'] == values['report_sha256']
    assert update['after_sha256'] == sha(final_report_path)
    assert original_report.decode().count(update['removed']) == 1
    assert original_report.decode().replace(update['removed'], update['added'], 1) == final_report
    assert sha(Q / 'report-producer.py.txt') == values['producer_sha256']
    assert sha(ROOT / 'docs/implementation.md') == values['implementation_sha256']
    assert values['failed_both_processes'] == 80
    table = re.findall(r'^\| (v[45]) \| (fixed-\d+|variable-\d+) \| ([\d.]+) \| ([\d.]+) \| \+([\d.]+)% \|$', final_report, re.M)
    assert len(table) == 8
    for version, case, shown_base, shown_candidate, shown_change in table:
        b = recomputed[version]['baseline'][case]['timings_ns']['ui_work_ns']
        c = recomputed[version]['candidate'][case]['timings_ns']['ui_work_ns']
        assert shown_base == format(b['pooled']['p95'] / 1e6, '.3f')
        assert shown_candidate == format(c['pooled']['p95'] / 1e6, '.3f')
        assert shown_change == format(regressions[version][case], '.2f')
        declared = values['experiments'][version][case]
        assert declared['baseline'] == b and declared['experimental'] == c and declared['p95_regression_percent'] == regressions[version][case]
    assert 'not latency measurements of final default' in final_report
    assert 'No final default speedup is claimed' in final_report
    assert 'All 80 processes fail both' in final_report and 'intentionally change' in final_report
    assert 'Three final v6 default-mode Cocoa checks pass' in final_report
    implementation = text(ROOT / 'docs/implementation.md')
    assert 'by default' in implementation.split('## Ordered scroll-surface experiment', 1)[1]
    assert 'no default performance gain is claimed' in implementation

    # Historical failure/diagnostic classification remains separate from accepted ordinary experiments.
    initial_log = text(Q / 'integrated-checks-v3/raster-race.log')
    assert 'operation not permitted' in initial_log
    assert not (Q / 'integrated-checks-v3/qualification.json').exists()
    retirement = record(Q / 'test-output-retirement.json')
    assert retirement['result'] == 'PASS_OUTPUTS_SEPARATED'
    diagnostic = record(Q / 'preceding-source-diagnostics/qualification.json')
    assert diagnostic['result'] == 'PASS_DIAGNOSTIC_ONLY' and diagnostic['samples'] == 768
    assert diagnostic['before'] == diagnostic['after']
    assert diagnostic['binary_sha256'] == baseline['binary_sha256']
    assert diagnostic['qualified_build_sha256'] == baseline['qualified_build_sha256']
    assert sha(Q / 'preceding-source-diagnostics/producer.py.txt') == diagnostic['producer_sha256']
    for child in diagnostic['checks']:
        if child['name'] == 'run-1':
            assert child['exit_code'] == 0 and child['original_wrapper_exit_code'] == 1
            assert child['mode'] == 'offline recovery of complete native records'
            assert sha(Q / 'preceding-source-diagnostics/run-1.log') == child['log_sha256']
        else:
            check_child(Q / 'preceding-source-diagnostics', child)
    for rep in range(1, 4):
        run = record(Q / 'preceding-source-diagnostics' / ('run-' + str(rep) + '.json'))
        raw = h.raw_records(Q / 'preceding-source-diagnostics' / ('run-' + str(rep) + '.log'))
        assert raw == run['records'] and len(raw) == 259
        assert all(r.get('source_details') is True for r in raw)
    failure = record(Q / 'preceding-source-diagnostics/historical-postprocess-failure/postprocess-failure.json')
    assert failure['native_exit_code'] == 0 and failure['wrapper_exit_code'] != 0
    sha(Q / 'preceding-source-diagnostics/historical-postprocess-failure/run-1.log')
    sha(Q / 'preceding-source-diagnostics/historical-postprocess-failure/failed-producer.py.txt')

    for path, expected in list(h.FILES.items()):
        assert sha(path) == expected
    recipe_sha, helper_sha = sha(Path(__file__)), sha(HELPER)
    certificate = {
        'schema': 1, 'decision': 'APPROVED_RECEIPTS', 'status': 'APPROVED', 'findings': [],
        'reviewed_file_sha256': h.FILES,
        'versioned_checks': {v: {'qualification_sha256': h.FILES[str(Q / phase / 'qualification.json')],
                                'child_count': len(checks[v]['checks']), 'source_count': 659,
                                'prepared_count': 6146, 'source_review_status': reviews[v]['status']} for v, phase in phases.items()},
        'final_v6_identity': {'source_map_sha256': map_sha(final_state['source']),
                              'prepared_map_sha256': map_sha(final_state['prepared']),
                              'current_source_and_complete_prepared_set_rehashed': True,
                              'same_renderer_prepared_bytes_and_patch_as_v5': True,
                              'policy_default': False, 'native_children': 3,
                              'opted_in_software_frame_comparisons': 56, 'default_disabled_frames': 12,
                              'performance_measured': False},
        'experiments': {v: {'qualification_sha256': h.FILES[str(Q / ('performance-' + v) / 'qualification.json')],
                            'processes': 40, 'samples': 4800, 'five_runs_per_case_build': True,
                            'all_diagnostics_off': True, 'closed_128_warmups': True,
                            'all_11_distributions_recomputed': True,
                            'p95_regressions_percent': regressions[v],
                            'targets_met': {'baseline': False, 'candidate': False},
                            'experimental_enabled_build': True,
                            'final_default_v6_timing': False} for v in ('v4', 'v5')},
        'baseline': {'head': baseline['head'], 'artifact_sha256': baseline['binary_sha256'],
                     'source_count': 653, 'prepared_count': 6140,
                     'qualified_build_link': baseline['qualified_build_sha256'],
                     'fresh_build_at_this_checkpoint': False},
        'observations': {'total_processes': 80, 'ordinary_samples': 9600,
                         'full_geometry_equal_pairs': geometry_pairs,
                         'processes_failing_both_4ms_p95_6ms_p99_targets': 80,
                         'historical_generated_pngs_each_v3_v4_v5': 17,
                         'legacy_kernel_compiled_assertion_negative': True,
                         'v3_capacity_finding_preserved_and_corrected_v4': True,
                         'original_report_values_plus_one_final_native_sentence_lineage': True,
                         'diagnostic_run1': 'Raw completed records recovered offline after wrapper postprocessing failure; native exit0 is explicitly producer/terminal-attested, wrapper exit1 retained. Not an ordinary measurement qualification.'},
        'scope': 'Independent read-only raw log/result, versioned source/prepared/binary links, full statistics/geometry, targets and final report audit. Final v6 disabled-default policy is qualified by its own checks/live receipts; v4/v5 timings remain experimental historical builds.',
        'limits': ['No Go/tests, build, preparation, Git, provider, native/UI or OS-setting execution by reviewer; only this external verifier/statistics/certificate written.',
                   'Source approvals are inherited at their exact versions; v3 NEEDS_BUDGET_FIX is not promoted to final source approval.',
                   'Selected sources and complete prepared sets are not full compiler/SDK/cache/ambient runtime closure.',
                   'Intentionally changed curve antialias pixels are not whole old-pixel parity. Offscreen software/cache proofs are not native atlas/GPU or physical display qualification.',
                   'Final v6 default latency was not measured; experimental v4/v5 results must not be relabelled as such.',
                   'All80 ordinary processes fail both targets. No cache recommendation, default speedup, native/GPU memory/endurance/fullP6 or complete Mac/human-workflow acceptance.',
                   'Separate nested source diagnostics and historical postprocessing/setup failures are not ordinary warm qualification.',
                   'Prism, future archive and final audit/promotion gates are separate and not certified here.'],
        'recipe_sha256': recipe_sha, 'independent_helper_sha256': helper_sha,
    }
    (OUT / 'recomputed-statistics.json').write_text(json.dumps(recomputed, indent=2, sort_keys=True) + '\n')
    target = Q / 'internal-receipt-review-v6.json'
    target.write_text(json.dumps(certificate, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'decision': certificate['decision'], 'certificate': str(target),
                      'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'files': len(h.FILES),
                      'samples': 9600, 'p95_regressions_percent': regressions}, sort_keys=True))


if __name__ == '__main__':
    main()
