from pathlib import Path
import hashlib,json,os,sys
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');d=json.loads((q/'build-identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(q/'framework')==d['fixture_binary_sha256'] and os.access(q/'framework',os.X_OK);assert sha(Path(d['original_native_library']))==d['native_library_sha256']
recipe=d['overlay_recipe']['patches'];overlay=json.loads((q/'overlay.json').read_text())['Replace'];assert len(overlay)==len(recipe)==3
for r in recipe:
 v=d['overlay_identity'][r['file']];original=Path(v['original']);copy=Path(v['overlay']);assert sha(original)==v['original_sha256'];assert sha(copy)==v['overlay_sha256'];assert original.read_text().count(r['before'])==1;assert copy.read_text()==original.read_text().replace(r['before'],r['after']);assert overlay[str(original)]==str(copy)
for p in (t/'tools/macos-calibration/sourcecost').rglob('*.py'):compile(p.read_text(),str(p),'exec')
print('PASS exact3 compiler overlay locations; immutable original Go/native bytes; binary executable/hash; syntax. No public API/default/SDK change or native claim.')
