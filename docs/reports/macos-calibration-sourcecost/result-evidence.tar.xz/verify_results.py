from pathlib import Path
import json,hashlib,sys,types,datetime,importlib.util,tarfile
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-calibration-sourcecost';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());plan=load(q/'bound-plan.json');idx=load(q/'source-snapshot-index.json')
for name,h in plan['pins'].items():assert sha(q/idx[name]['copy'] if name in idx else Path(name))==h
p=t/'tools/macos-calibration/sourcecost/check.py';v=types.ModuleType('pinned_sourcecost_checker');v.__file__=str(p);exec(compile((q/idx[str(p)]['copy']).read_text(),str(p),'exec'),v.__dict__)
s=importlib.util.spec_from_file_location('sourcecost_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
result=load(q/'result.json');assert result['outcome']=='VALID_CPU_SOURCE_COST_DIAGNOSTIC' and len(result['cases'])==1;c=result['cases'][0];root=q/'pair1-sourcecost';lines=v.base.load(root/'native/stdout');assert len(lines)==1;actual=v.validate(lines[0],load(q/'match.json'));assert actual==c['validation']==load(root/'validation.json');assert c['geometry_before']==c['geometry_after'];assert all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
commands=[(c['native'],root/'native')]
for phase,folder in [('configuration_before','before'),('configuration_after','after')]:commands.extend((cmd,root/folder/k) for k,cmd in c[phase].items())
for cmd,folder in commands:
 assert cmd['exit_code']==0 and cmd['error'] is None and cmd['logs_complete'] and cmd['pins_stable'] and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['logs']['stderr']['bytes']==0
 for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
assert len(commands)==9
summary=load(q/'summary.json');assert summary['metrics']==actual and summary['source_records_all_phases']==248 and summary['source_kind_counts']=={'1':248};assert summary['elapsed_seconds']==(datetime.datetime.fromisoformat(result['finished_utc'])-datetime.datetime.fromisoformat(load(q/'started.json')['started_utc'])).total_seconds()<60
for name in ['preparation','refused','corrected-preparation','result']:
 index=r/(name+'-evidence-index.json');archive=r/(name+'-evidence.tar.xz')
 if not index.exists():continue
 d=load(index);assert sha(archive)==d['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(d['files'])
  for n,e in d['files'].items():b=tf.extractfile(n).read();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
print('PASS actual pinned classifier and all248 nested source records;128warmup120measured;9ownedgroupsretired;SDK8321/originalnative/source/binary/overlay/match/log identities;configuration/geometry;32.833s<60;archives verified;no ordinary latency acceptance')
