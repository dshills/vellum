from pathlib import Path
import json,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'))
s=importlib.util.spec_from_file_location('owned_sourcecost',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
f=t/'tools/macos-calibration/sourcecost/framework';files=[*f.iterdir(),q/'overlay.json',q/'overlay-identity.json',q/'desktop_session.go',q/'desktop_measurement.go'];pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()};argv=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/bin/sh',str(q.parent/'macos-app-examples/go-check'),'build','-overlay='+str(q/'overlay.json'),'-o',str(q/'framework'),'.']
r=g.execute(argv,f,q/'build',lambda:False,lambda:all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items()),timeout=180,limit=2<<20);(q/'build-receipt.json').write_text(json.dumps({'argv':argv,'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','error','seconds']}));assert r['exit_code']==0 and r['error'] is None and r['owned']['group_absent']
