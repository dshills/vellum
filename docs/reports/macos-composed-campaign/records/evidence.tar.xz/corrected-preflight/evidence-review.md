Approved the scoped source/evidence checkpoint: exact eight proposed leaves, no unresolved findings. Corrected621aca+five-leaf preflight passed33 action checks, four phases,16 one-second samples and four worker completions; strict native occlusion and actual cover constraints reconcile with raw/proof. Three docs were added after runtime.

Original c078 endurance and failed P3/P7 attempts remain separately bound. P7 equal bounding boxes do not establish root cause. Zero samples qualify60-second idle; overnight, app-wide wakeup/presents, native/GPU memory, physical/human workflows and fullMac/P4/P6/P11 remain open. One hidden inactive untitled500×500 Cocoa window remains.

Report statements are scoped/normative; archive/provider gates remain future. Review reused the approved large endurance certificate and read only small raw/source artifacts. No apps/tests/providers, process probes or heavy source scans were run during native benchmarks.
