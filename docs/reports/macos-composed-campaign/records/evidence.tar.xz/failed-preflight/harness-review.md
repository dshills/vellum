Approved the exact four-file soak harness for source correctness. Shared lease now spans prerequisite checks through native cleanup and terminal accounting; CPU-only contention/refusal evidence reconciles. No unresolved findings.

The current lifecycle must still finish and pass independent validation before any soak; overnight requires its own validated preflight. No positive soak or full idle/native/GPU/Mac qualification is granted. No tests or native apps were launched by this review.
