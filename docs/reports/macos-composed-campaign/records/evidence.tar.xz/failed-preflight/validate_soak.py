"""Raw soak proof; imports only the hash-bound, side-effect-free prior validator."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,math,sys
P=Path(__file__).resolve().parent;B=Path('/private/tmp/vellum-macos-composed-endurance')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(f):return json.loads(Path(f).read_text())
def need(v,msg):
 if not v:raise ValueError(msg)
def finite(v):return type(v)in[int,float]and math.isfinite(v)
def predecessor():
 manifest=read(P/'inputs.json');need(sha(B/'validate_live.py')==manifest['predecessor_validator_sha256'],'predecessor validator identity')
 spec=importlib.util.spec_from_file_location('vellum_prior_native_validator',B/'validate_live.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 proof=v.validate('composed-1000','full');need(proof['result']=='PASS_1000_COMPOSED_CONTROLS_CYCLES'and proof['base_commit']==manifest['source_commit'],'complete predecessor')
 return v
def state(s,phase):
 return s['Title']=='Vellum composed idle soak'and s['Key']is False and len(s['Frame'])==4 and all(finite(v)for v in s['Frame'])and s['Frame'][2]>0 and s['Frame'][3]>0 and ((s['Miniaturized']is True and s['OcclusionVisible']is False)if phase=='minimized'else(s['Visible']is True and s['Miniaturized']is False and s['OcclusionVisible']is(phase!='occluded')))
def terminal(s):
 need(all(s[k]is True for k in['MainThread','CleanupObserved','CallbacksStopped'])and s['WindowTitles']==[]and all(s[k]==0 for k in['NativeOutstanding','AccessibilityWindows','PendingCallbacks','MenuCallbacks','TrayCallbacks']),'terminal service inventory')
 need(all(w['Title']==''and all(w[k]is False for k in['Visible','Miniaturized','Key','OcclusionVisible'])and len(w['Frame'])==4 and all(finite(v)for v in w['Frame'])and w['Frame'][2]>=0 and w['Frame'][3]>=0 for w in s['Windows']),'hidden inactive windows')
 need(all(s['FilePanels'][k]==0 for k in['Tracked','Visible','Open','Save']),'file panels')
 need(s['Menu']=={'Owned':False,'OriginalRestored':False,'TargetRetired':True,'Items':[]},'menu inventory')
 t=s['Tray'];need(all(t[k]is False for k in['Present','Visible','Template'])and t['TargetRetired']is True and t['Identity']==0 and t['Items']==[]and all(t[k]==''for k in['Title','Tooltip','AccessibilityLabel'])and all(t[k]==0 for k in['ImageWidth','ImageHeight','PixelWidth','PixelHeight']),'tray inventory')
def validate(name,mode):
 need(mode in['preflight','overnight'],'mode');v=predecessor();manifest=read(P/'inputs.json')
 r=read(P/(name+'.json'));owned=read(P/(name+'-owned-process.json'));inputs=read(P/(name+'-inputs.json'));artifact=read(B/'binary-full.json')
 need(r['native_lease']=={'path':'/private/tmp/vellum-macos-live-oct15.lock','acquired':True,'held_through_cleanup':True}and r['artifacts_stable']is True,'exclusive cooperative live lease and reviewed artifacts')
 review=read(P/'harness-review.json');need(review['result']=='APPROVED_SOURCE_AND_HARNESS'and review['unresolved_findings']==[]and r['harness_review_sha256']==owned['harness_review_sha256']==sha(P/'harness-review.json')and all(sha(P/n)==h for n,h in review['sources'].items()),'reviewed soak harness')
 need(r['lease_source_sha256']==owned['lease_source_sha256']==manifest['lease_source_sha256']==sha(P/'live_lease.py'),'lease source binding')
 need(r['result']=='TERMINAL_NATIVE_RUN_OK'and r['mode']=='soak'and r['soak_mode']==mode and r['exit_code']==0 and r['error']is None and r['stop_reason']is None and r['cleanup_errors']==[],'native terminal')
 need(all(r[k]is True for k in['direct_child_terminal','group_absence_confirmed','inputs_stable','binary_stable','logs_complete','predecessor_group_reobserved_absent'])and r['stop_marker_at_exit']is False and r['post_terminal_group_members']==[],'retirement')
 need(r['pid']==r['process_group']==owned['pid']==owned['process_group']and type(r['pid'])is int and r['pid']>0,'owned pid')
 need(inputs['clean']is True and inputs['delta']=={} and inputs['commit']==manifest['source_commit']=='c078eb8e20f0e493ee063949f5fe7ee85e51bbe4'and len(inputs['prepared'])==6227,'source context')
 for key,file in[('qualification_inputs_sha256',P/'inputs.json'),('inputs_sha256',P/(name+'-inputs.json')),('producer_sha256',P/'run_soak.py'),('authorization_sha256',P/'live-authorization.json'),('binary_manifest_sha256',B/'binary-full.json'),('build_receipt_sha256',B/'native-build-committed.json'),('executable_sha256',B/'window-cycle-committed'),('predecessor_validation_sha256',B/'composed-1000-validation.json')]:need(r[key]==owned[key]==sha(file),'binding '+key)
 need(r['executable_sha256']==manifest['binary_sha256']==artifact['binary_sha256']and r['binary_manifest_sha256']==manifest['binary_manifest_sha256'],'manifest identity')
 before=read(B/'composed-1000-inputs.json');need(inputs['tracked']==before['tracked']and inputs['prepared']==before['prepared'],'same full source/prepared vectors')
 duration,quiet,settle,interval,timeout,watchdog=(40,1,1,2,100,180)if mode=='preflight'else(28800,60,10,300,28980,29100)
 args=[artifact['binary'],'-composed','-cycles=1','-sample-every=1',f'-timeout={"100s"if mode=="preflight"else"8h3m"}',f'-soak={"40s"if mode=="preflight"else"8h"}',f'-soak-quiet={quiet}s',f'-soak-settle={settle}s',f'-soak-interval={"2s"if mode=="preflight"else"5m"}']
 if mode=='overnight':args.append('-heap-profile='+str(P/(name+'.heap')))
 need(r['argv']==owned['argv']==args and r['watchdog_seconds']==owned['watchdog_seconds']==watchdog and r['cwd']==owned['cwd']==str(Path('/private/tmp/vellum-composed-controls/drivers/cogent')),'exact invocation')
 for ch in['stdout','stderr']:
  f=P/(name+'.'+ch);d=r['logs'][ch];need(d['sha256']==d['stream_sha256']==sha(f)and d['bytes']==f.stat().st_size,'raw '+ch)
 obs=r['group_observation'];need(obs['argv']==['ps','-axo','pid=,pgid=,comm=']and obs['exit_code']==0 and obs['stdout_bytes']>0 and obs['stderr_bytes']==0 and obs['stderr_sha256']==hashlib.sha256(b'').hexdigest()and obs['stdout_sha256']==r['group_observation_sha256'],'group observation')
 events=[]
 for line in(P/(name+'.stdout')).read_text().splitlines():
  if not line.strip():continue
  need(line.startswith('{'),'non-JSON stdout');events.append(json.loads(line))
 allowed={'vellum.native-action','vellum.composed-cycle','vellum.soak.phase','vellum.soak.phase-end','vellum.soak.sample','vellum.window-cycle.sample','vellum.window-soak.result'};need(all(e.get('event')in allowed for e in events),'event type')
 actions=[e for e in events if e['event']=='vellum.native-action'];cycles=[e for e in events if e['event']=='vellum.composed-cycle'];results=[e for e in events if e['event']=='vellum.window-soak.result'];memory=[e['sample']for e in events if e['event']=='vellum.window-cycle.sample'];samples=[e for e in events if e['event']=='vellum.soak.sample'];starts=[e for e in events if e['event']=='vellum.soak.phase'];ends=[e for e in events if e['event']=='vellum.soak.phase-end']
 need(len(actions)==33 and len(cycles)==len(results)==1 and all(a['window']=='soak'for a in actions),'native control counts')
 c=cycles[0];aa=c['native_actions'];need(aa==[a['action']for a in actions]and[(a['Target'],a['Kind'],a['Value'])for a in aa]==v.PLAN,'native action plan')
 for a in aa:need(a['OwnerAndNativeCompleted']is True and type(a['Attempts'])is int and type(a['Admissions'])is int and 1<=a['Admissions']<=a['Attempts']and finite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5.25 and a['NativeRole']and'FailureContext'not in a and'AttachmentRetirement'not in a,'completed action')
 need(c['cycle']==1 and c['native_action_plan']==2 and c['native_list_requests']==3 and c['native_canvas_selections']==2 and c['native_color_edits']==2 and c['native_breadcrumb_requests']==2 and c['native_tree_disclosures']==2 and c['tree_accessibility_rows']>0,'composed counts')
 need(all(c[k]is True for k in['native_list_rejected','native_breadcrumb_rejected','native_breadcrumb_truncated','native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])and c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and v.rect(c['root_screen_points'])and v.rect(c['density_clip_screen_points'])and c['full_p11_qualified']is False,'composed publication')
 phases=['visible','occluded','minimized','background'];need([e['phase']for e in starts]==[e['phase']for e in ends]==phases,'four ordered phases')
 need(all(e['event']=='vellum.native-action'for e in events[:33])and events[33]['event']=='vellum.composed-cycle','action prefix')
 cursor=34
 for phase in phases:
  need(events[cursor]['event']=='vellum.soak.phase'and events[cursor]['phase']==phase,'phase start order');cursor+=1
  while events[cursor]['event']=='vellum.window-cycle.sample':
   need(events[cursor+1]['event']=='vellum.soak.sample'and events[cursor+1]['phase']==phase and events[cursor]['sample']==events[cursor+1]['forced_gc_memory'],'ordered memory/sample pair');cursor+=2
  need(events[cursor]['event']=='vellum.soak.phase-end'and events[cursor]['phase']==phase,'phase end order');cursor+=1
 need(cursor==len(events)-1 and events[cursor]['event']=='vellum.window-soak.result','terminal event order')
 for j,role in[(15,'AXSlider'),(16,'AXTextField'),(24,'AXButton'),(25,'AXButton'),(27,'AXList'),(28,'AXList'),(29,'AXList'),(30,'AXButton'),(31,'AXButton')]:need(aa[j]['NativeRole']==role,'action native role')
 need(len(samples)==len(memory)>0 and memory==[s['forced_gc_memory']for s in samples],'sample/memory pairing')
 counts={};cpu={};commits=0;all_eligible=True
 for phase,start,end in zip(phases,starts,ends):
  ss=[s for s in samples if s['phase']==phase];need(ss and [s['sample']for s in ss]==list(range(1,len(ss)+1)),'sample sequence')
  need(start['requested_seconds']==duration/4 and end['samples']==len(ss)and finite(end['elapsed_seconds'])and end['elapsed_seconds']>=duration/4 and finite(end['process_cpu_seconds'])and end['process_cpu_seconds']>=0,'phase duration')
  for s in ss:
   need(state(s['start_state'],phase)and state(s['end_state'],phase),'observed phase state')
   elapsed,wall,used=s['elapsed_seconds'],s['wall_elapsed_seconds'],s['process_cpu_seconds'];need(all(finite(x)for x in[elapsed,wall,used])and elapsed>0 and wall>0 and used>=0,'CPU interval')
   need(abs(s['one_cpu_percent']-100*used/elapsed)<1e-8,'CPU arithmetic')
   eligible=quiet>=60 and elapsed>=60 and elapsed<=quiet+max(1,quiet/10)and abs(wall-elapsed)<=1
   need(s['cpu_60s_interval']is eligible and s['app_originated_wakeups_available']is False and s['present_count_available']is False and s['full_p11_qualified']is False,'measurement scope')
   utc0=datetime.datetime.fromisoformat(s['start_utc'].replace('Z','+00:00'));utc1=datetime.datetime.fromisoformat(s['end_utc'].replace('Z','+00:00'));need(abs((utc1-utc0).total_seconds()-wall)<.001,'wall interval')
   need(type(s['primary_paint_wakes'])is int and s['primary_paint_wakes']>=0,'paint counter')
   if phase=='background':commits+=1
   need(s['background_commits']==commits,'worker completion count')
   all_eligible=all_eligible and eligible
  need(end['background_commits']==commits,'phase worker count');counts[phase]=len(ss);cpu[phase]=[min(s['one_cpu_percent']for s in ss),max(s['one_cpu_percent']for s in ss)]
 need(commits==counts['background']and commits>0,'background work')
 result=results[0];need(events[-1]is result and result['result']=='PASS_NATIVE_WINDOW_SOAK'and result['requested_cycles']==result['completed_cycles']==1 and result['native_action_plan']==2 and result['composed_workspace']is True and result['dense_labels_per_composed_window']==1000 and result['samples']==memory,'final result')
 need(result['soak_config']=={k:int(n*1e9)for k,n in[('Duration',duration),('Quiet',quiet),('Settle',settle),('Interval',interval)]}and result['cooperative_timeout_seconds']==timeout and result['heap_profile_requested']==(mode=='overnight'),'soak config')
 need(result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20 and all(m['Completed']==0 and 0<m['HeapAlloc']<=512<<20 and 0<m['RSSBytes']<=1<<30 for m in memory),'sampled guards')
 need(all(result[k]is False for k in['full_p11_qualified','native_heap_qualified','gpu_memory_qualified','clipboard_access','preferences_changed'])and result['samples_after_forced_gc']is True and result['geometry_persistence_disabled_in_fixture']is True,'final scope');terminal(result['native_cleanup'])
 summary={'result':'PASS_SCOPED_SOAK_PREFLIGHT'if mode=='preflight'else'COMPLETE_OVERNIGHT_PHASE_TRACE','source_commit':inputs['commit'],'run_receipt_sha256':sha(P/(name+'.json')),'validator_sha256':sha(__file__),'mode':mode,'duration_requested_seconds':duration,'observed_phase_elapsed_seconds':sum(e['elapsed_seconds']for e in ends),'phase_samples':counts,'quiet_cpu_one_core_percent_ranges':cpu,'eligible_sixty_second_intervals':sum(s['cpu_60s_interval']for s in samples),'all_quiet_intervals_eligible':all_eligible,'sampled_idle_cpu_target_met':all_eligible and all(s['one_cpu_percent']<.5 for s in samples),'primary_paint_wakes_total':sum(s['primary_paint_wakes']for s in samples),'quiet_intervals_with_primary_paints':sum(s['primary_paint_wakes']>0 for s in samples),'background_commits':commits,'native_selector_actions':33,'total_attempts':sum(a['Attempts']for a in aa),'total_admissions':sum(a['Admissions']for a in aa),'native_cleanup':result['native_cleanup'],'owned_group_absence_confirmed':True,'full_idle_budget_qualified':False,'os_application_background_qualified':False,'continuously_observed_window_state_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'native_gpu_memory_qualified':False,'full_p11_qualified':False,'full_mac_qualified':False,'limits':['Window states are sampled at interval endpoints. Background names the allocating-worker phase; it does not certify OS application background.','Only the primary paint counter is available; app-wide wakeups/presents remain unavailable.','The native PASS labels fixture completion, separate from CPU eligibility and target attainment.','Forced-GC RSS/Go observations remain sampled safety checks, with no native/GPU attribution.']}
 if mode=='overnight':
  f=P/(name+'.heap');need(0<f.stat().st_size<=8<<20,'bounded heap profile');summary.update(heap_profile_sha256=sha(f),heap_profile_bytes=f.stat().st_size)
 return summary
if __name__=='__main__':
 name,mode=sys.argv[1:]
 try:result=validate(name,mode)
 except Exception as e:result={'result':'FAILED_VALIDATION','error':{'type':type(e).__name__,'message':str(e)},'validator_sha256':sha(__file__)}
 with(P/(name+'-validation.json')).open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result));sys.exit(1 if result['result']=='FAILED_VALIDATION'else 0)
