# Composed soak tooling review

APPROVED_SOURCE_AND_HARNESS. No unresolved findings. The JSON record binds both producers, small inputs, frozen dependencies and actual refusal receipts.

The controller refuses before native launch until the named1000-cycle predecessor is terminal, independently revalidated from raw proof and its owned group freshly absent. Overnight also requires its own revalidated preflight. Exact40-second and8-hour four-phase plans, stop/source/binary guards, bounded flushed logs, owned retirement/reaping and scoped raw-stream validation are retained. Existing controller and validator CLI failures demonstrate refusal only; no positive soak result exists.

Window states are endpoint samples; background is the allocating-worker phase. Only process CPU and primary-window paint counts are available. Preflight1-second intervals cannot qualify60-second CPU eligibility; full idle budget remains false for every outcome. No app-wide wakes/presents, continuous OS-background state, native/GPU budget, physical/human or fullMac/P11 acceptance is granted. The current lifecycle campaign must finish and validate before any soak launch. No runtime/test/provider calls were performed by reviewer.
