"""Sequential current release measurements; refuses unfinished native predecessors."""
import datetime,json,os,platform,sys,threading,time
import common as c

def main():
 c.need(sys.argv[1:]==['--run'],'explicit --run required');c.need(platform.system()=='Darwin','Mac only');c.need(not c.stopping(),'live stop marker')
 with c.LiveLease()as lease:
  c.need(not c.stopping(),'live stop marker after lease')
  prior=c.predecessors();inputs,build=c.build_inputs();q=c.read(c.P/'qualification-inputs.json')
  review=c.read(c.P/'harness-review.json');c.need(review['result']=='APPROVED_SOURCE_AND_HARNESS'and not review['unresolved_findings'],'internal harness approval')
  c.need(all(c.sha(c.P/n)==h for n,h in review['sources'].items())and all(c.sha(c.P/n)==h for n,h in q['harness_sources'].items()),'approved harness endpoint')
  c.need(c.sha(c.P/'live-authorization.json')==q['authorization_sha256'],'authorization identity')
  fixed_hashes={n:c.sha(c.P/n)for n in [*q['harness_sources'],'qualification-inputs.json','harness-review.json','live-authorization.json','inputs.json','build.json','loadedgrid']}
  def check_pins():c.need(all(c.sha(c.P/n)==h for n,h in fixed_hashes.items()),'reviewed artifact/authorization changed')
  check_pins();c.need(lease.held(),'exclusive live lease required');before=c.snapshot();c.need(before=={'commit':inputs['source_commit'],'clean':True,'tracked':inputs['tracked'],'prepared':inputs['prepared']},'frozen source/prepared vector')
  b=c.load('current_native_grid_benchmark',c.R/'scripts/benchmark-grid.py');actual_popen=b.subprocess.Popen;actual_retire=b.terminate_owned_group;actual_case=b.run_case
  lock=threading.RLock();done=threading.Event();owners=[];active={};current=None;reason=None;started=time.monotonic();plan=c.planned();ordinal=0
  receipt={'result':'STARTED_CURRENT_GRID_MEASUREMENTS','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'watchdog_seconds':2400,'inputs_sha256':c.sha(c.P/'inputs.json'),'build_receipt_sha256':c.sha(c.P/'build.json'),'binary_sha256':build['binary_sha256'],'producer_sha256':c.sha(__file__),'qualification_inputs_sha256':c.sha(c.P/'qualification-inputs.json'),'harness_review_sha256':c.sha(c.P/'harness-review.json'),'authorization_sha256':c.sha(c.P/'live-authorization.json'),'prior':prior,'native_application_executed':False,'stop_reason':None,'error':None,'cleanup_errors':[],'owners':[],'completed_cases':0,'inputs_stable':False,'full_mac_qualified':False,'native_lease':{'path':str(lease.path),'acquired':lease.held(),'held_through_cleanup':False},'raw_log_budget_scope':'Accepted campaign raw logs <=256MiB checked after each case. A failing next case may retain up to64MiB plus one64KiB chunk beyond the previously admitted total; metadata/results are additional.'}
  target=c.P/'run.json';target.open('x').close()
  def check_stop():
   nonlocal reason
   with lock:
    markers=c.stopping()
    if reason is None and markers:reason='human_return_or_stop_marker:'+','.join(markers)
    if reason is None and time.monotonic()-started>2400:reason='watchdog'
    c.need(reason is None,'native run canceled: '+str(reason))
  def launch(argv,**options):
   nonlocal current
   if not argv or argv[0]!=str(c.P/'loadedgrid'):return actual_popen(argv,**options)
   with lock:
    check_stop();check_pins();c.need(lease.held(),'live lease lost');c.need(current is not None and current.get('owner')is None,'one native producer per expected case')
    c.need(argv==current['argv']and options.get('start_new_session')is True,'exact owned native argv/session')
    p=actual_popen(argv,**options);entry={'process':p,'pid':p.pid,'process_group':p.pid,'case':current['relative'],'argv':list(argv),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retired':False,'lease_held':lease.held(),'attempts':[]};owners.append(entry);active[p.pid]=p;current['owner']=entry;receipt['native_application_executed']=True
    try:(c.P/entry['case']/'owned-start.json').open('x').write(json.dumps({k:v for k,v in entry.items()if k not in['process','attempts']},indent=2)+'\n')
    except BaseException:
     actual_retire(p);p.wait(timeout=5);raise
    return p
  def retire(p):
   entry=next((e for e in owners if e['process']is p),None);c.need(entry is not None,'retire only captured native owner')
   attempt={'pid':p.pid,'process_group':p.pid,'case':entry['case'],'argv':entry['argv'],'error':None,'direct_child_terminal':False,'group_absence_confirmed':False}
   try:
    actual_retire(p);p.wait(timeout=5);attempt['exit_code']=p.returncode;attempt['direct_child_terminal']=p.poll()is not None;attempt['group_observation']=c.require_absent(p.pid);attempt['group_absence_confirmed']=True;entry['retired']=True
    with lock:active.pop(p.pid,None)
   except BaseException as e:
    attempt['error']={'type':type(e).__name__,'message':str(e)};receipt['cleanup_errors'].append(attempt['error']);raise
   finally:
    entry['attempts'].append(attempt);(c.P/entry['case']/f"owned-retirement-{len(entry['attempts'])}.json").open('x').write(json.dumps(attempt,indent=2)+'\n')
  def run_case(binary,directory,rows,variable,samples,warmup,novel,timeout,**options):
   nonlocal current,ordinal
   check_stop();c.need(ordinal<len(plan),'bounded case plan');mode,pvar,prows,index=plan[ordinal]
   c.need(directory==c.case_path(mode,pvar,prows,index)and binary==c.P/'loadedgrid'and rows==prows and variable is pvar and samples==120 and warmup==128 and novel is False and timeout==180 and options=={'source_details':False,'gpu_scene_rendering':mode=='gpu'},'exact ordinary case')
   current={'argv':c.native_argv(mode,variable,rows),'relative':str(directory.relative_to(c.P)),'owner':None}
   try:
    result=actual_case(binary,directory,rows,variable,samples,warmup,novel,timeout,**options);c.need(current['owner']is not None and current['owner']['retired'],'case cleanup observed');check_stop();ordinal+=1;receipt['completed_cases']=ordinal;c.need(sum((c.P/e['case']/'native.log').stat().st_size for e in owners)<=256<<20,'total native output budget');return result
   finally:current=None
  def watch():
   nonlocal reason
   while not done.wait(.2):
    try:check_stop()
    except ValueError:
     with lock:processes=list(active.values())
     for p in processes:
      try:actual_retire(p)
      except BaseException as e:
       with lock:receipt['cleanup_errors'].append({'type':type(e).__name__,'message':str(e),'source':'stop watcher'})
     return
  worker=threading.Thread(target=watch,name='native-stop-watch',daemon=True)
  b.subprocess.Popen=launch;b.terminate_owned_group=retire;b.run_case=run_case
  try:
   worker.start()
   for mode in ['cpu','gpu']:
    check_stop();sys.argv=['benchmark-grid.py','--run','--binary',str(c.P/'loadedgrid'),'--output',str(c.P/mode),'--runs','5','--samples','120','--warmup','128','--timeout','180']+(['--gpu-scene']if mode=='gpu'else[]);b.main()
   c.need(ordinal==40 and len(owners)==40,'complete40-case plan');receipt['result']='MEASURED_CURRENT_GRID'
  except BaseException as e:receipt['result']='FAILED_CURRENT_GRID';receipt['error']={'type':type(e).__name__,'message':str(e)}
  finally:
   done.set()
   if worker.ident is not None:worker.join(timeout=2)
   for e in owners:
    if not e['retired']:
     try:retire(e['process'])
     except BaseException as error:receipt['cleanup_errors'].append({'type':type(error).__name__,'message':str(error),'source':'final recovery'})
   b.subprocess.Popen=actual_popen;b.terminate_owned_group=actual_retire;b.run_case=actual_case
   receipt['native_lease']['held_through_cleanup']=lease.held();receipt['watcher_joined']=not worker.is_alive();receipt['stop_reason']=reason;receipt['elapsed_seconds']=time.monotonic()-started;receipt['stop_markers_at_exit']=c.stopping();receipt['owners']=[{k:v for k,v in e.items()if k!='process'}for e in owners]
   try:receipt['inputs_stable']=c.snapshot()==before and c.sha(c.P/'loadedgrid')==build['binary_sha256']and all(c.sha(c.P/n)==h for n,h in fixed_hashes.items())
   except BaseException as e:receipt['cleanup_errors'].append({'type':type(e).__name__,'message':str(e),'source':'final source validation'})
   if receipt['cleanup_errors']or not receipt['inputs_stable']or reason is not None or receipt['stop_markers_at_exit']or not receipt['watcher_joined']:receipt['result']='FAILED_CURRENT_GRID'
   target.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in['result','completed_cases','elapsed_seconds','stop_reason','error','cleanup_errors','inputs_stable']}))
  c.need(receipt['result']=='MEASURED_CURRENT_GRID','current grid measurements did not complete')

if __name__=='__main__':main()
