"""Prepare exact frozen dependencies and build an optimized consumer; never run it."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys,time
R=Path('/private/tmp/vellum-benchmark-cleanup');S=Path('/private/tmp/vellum-composed-controls');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent;E=Path('/private/tmp/vellum-macos-composed-endurance')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
env={**child_environment(),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2'}
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=env,capture_output=True,timeout=30);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def tracked(root):return{n:sha(root/n)for n in git(root,'ls-files').splitlines()}
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()and not f.is_symlink()}
assert git(R,'rev-parse','HEAD')=='77ca764b2a7896058cc21872a742f3a57bdf058c'and not git(R,'status','--porcelain')
assert git(S,'rev-parse','HEAD')=='c078eb8e20f0e493ee063949f5fe7ee85e51bbe4'and not git(S,'status','--porcelain')
assert git(C,'rev-parse','HEAD')=='621aca2da91836631fc05b2a7b97f124d53518dd'and not git(C,'status','--porcelain')
rs=tracked(R);cs=tracked(C);assert set(rs)==set(cs)and {n for n in rs if rs[n]!=cs[n]}=={'docs/development.md'}
build=json.loads((E/'native-build-committed.json').read_text());sp=prepared(S);assert len(sp)==6227 and sp==build['prepared_before']==build['prepared_after']
for m in ['upstream','typesetting']:
 source=S/'drivers/cogent/build'/m;dest=R/'drivers/cogent/build'/m
 assert not dest.exists()and not any(f.is_symlink()for f in source.rglob('*'))
 shutil.copytree(source,dest)
assert prepared(R)==sp
inputs={'source_commit':git(R,'rev-parse','HEAD'),'source_root':str(R),'tracked':rs,'prepared':sp,'canonical_reference_commit':git(C,'rev-parse','HEAD'),'canonical_reference_differences':['docs/development.md'],'scope':'Complete observed repository/prepared bytes at build endpoints. Canonical differs only by reviewed command documentation. Not hermetic compiler/module-cache/SDK closure or loaded-executable attestation.','prepared_copy_source':str(S),'prior_build_receipt_sha256':sha(E/'native-build-committed.json'),'producer_sha256':sha(__file__),'native_application_executed':False}
(P/'inputs.json').open('x').write(json.dumps(inputs,indent=2)+'\n')
argv=['go','build','-trimpath','-o',str(P/'loadedgrid'),'.'];start=time.monotonic();d={'argv':argv,'cwd':str(R/'examples/loadedgrid'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs_sha256':sha(P/'inputs.json'),'producer_sha256':sha(__file__),'native_application_executed':False,'exit_code':None,'error':None}
try:
 with(P/'build.stdout').open('xb')as so,(P/'build.stderr').open('xb')as se:
  d['exit_code']=run_child(argv,cwd=R/'examples/loadedgrid',env=env,stdout=so,stderr=se,timeout=600).returncode
 assert d['exit_code']==0
 d['binary_sha256']=sha(P/'loadedgrid');d['binary_bytes']=(P/'loadedgrid').stat().st_size
 meta=run_child(['go','version','-m',str(P/'loadedgrid')],cwd=R,env=env,capture_output=True,timeout=10);assert meta.returncode==0
 (P/'binary-go-version.txt').open('xb').write(meta.stdout);d['binary_metadata_sha256']=sha(P/'binary-go-version.txt')
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)}
finally:
 d['elapsed_seconds']=time.monotonic()-start;d['tracked_stable']=tracked(R)==rs and not git(R,'status','--porcelain');d['prepared_stable']=prepared(R)==sp;d['stdout_sha256']=sha(P/'build.stdout');d['stderr_sha256']=sha(P/'build.stderr');(P/'build.json').open('x').write(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
assert d['exit_code']==0 and d['error']is None and d['tracked_stable']and d['prepared_stable']
