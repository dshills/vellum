"""CPU-only process-observation failure controls. No Vellum application launch."""
import os,subprocess,sys,types,unittest
from unittest import mock
import common as c
from child_process import terminate_owned_group

class ProcessProofTests(unittest.TestCase):
 def test_revalidation_allows_only_valid_utc_observation_metadata(self):
  import copy
  saved={'validated_utc':'2026-10-16T00:30:11.991110Z','actions':33000,'receipt_sha256':'a'*64,'cleanup':{'terminal':True},'samples':[1,2,3]}
  fresh={**saved,'validated_utc':'2026-10-16T01:00:00+00:00'}
  c.same_endurance_proof(fresh,saved)
  for key,value in [('actions',33001),('receipt_sha256','b'*64),('cleanup',{'terminal':1}),('samples',[1,3,2]),('new_evidence',True)]:
   with self.subTest(field=key),self.assertRaisesRegex(ValueError,'recorded endurance proof consistency'):c.same_endurance_proof({**fresh,key:value},saved)
  for stamp in [None,False,12,'','yesterday','2026-10-16T00:30:00','2026-10-16T01:30:00+01:00','2026-99-16T00:30:00Z']:
   for side in ['fresh','saved']:
    pair={'fresh':copy.deepcopy(fresh),'saved':copy.deepcopy(saved)};pair[side]['validated_utc']=stamp
    with self.subTest(stamp=stamp,side=side),self.assertRaisesRegex(ValueError,'UTC metadata'):c.same_endurance_proof(pair['fresh'],pair['saved'])
  missing={k:v for k,v in fresh.items()if k!='validated_utc'}
  with self.assertRaisesRegex(ValueError,'UTC metadata'):c.same_endurance_proof(missing,saved)
 def test_live_then_retired_owned_python_group(self):
  process=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
  try:
   observed=c.group_members(process.pid);self.assertEqual(observed['owned_group'],process.pid);self.assertTrue(any(p['pid']==process.pid for p in observed['owned_members']))
   with self.assertRaisesRegex(ValueError,'owned native process group remains'):c.require_absent(process.pid)
  finally:terminate_owned_group(process);process.wait(timeout=5)
  self.assertEqual(c.require_absent(process.pid)['owned_members'],[])
 def test_empty_or_malformed_table_cannot_prove_absence(self):
  for raw in [b'',b'12345 invalid S\n',b'broken\n']:
   with self.subTest(raw=raw),mock.patch.object(c,'command',return_value=raw),self.assertRaises(ValueError):c.require_absent(12345)
 def test_observation_error_cannot_prove_absence(self):
  for status,stderr in [(1,b''),(0,b'warning')]:
   with self.subTest(status=status,stderr=stderr),mock.patch.object(c,'run_child',return_value=types.SimpleNamespace(returncode=status,stdout=b'12345 12345 S\n',stderr=stderr)),self.assertRaisesRegex(ValueError,'observation command failed'):c.require_absent(12345)

class SerialAdmissionTests(unittest.TestCase):
 def test_both_controllers_refuse_an_owned_live_lease(self):
  from live_lease import LiveLease
  with LiveLease():
   for args in [[sys.executable,str(c.P/'run_perf.py'),'--run'],[sys.executable,str(c.S/'run_soak.py'),'soak-preflight','preflight']]:
    with self.subTest(controller=args[1]):
     result=c.run_child(args,capture_output=True,env=c.child_environment(),timeout=5)
     self.assertNotEqual(result.returncode,0);self.assertIn(b'another Vellum live fixture owns the shared lease',result.stderr)
  with LiveLease()as lease:self.assertTrue(lease.held())
 def test_reviewed_build_digests_are_enforced(self):
  q=c.read(c.P/'qualification-inputs.json');read=c.read
  for field in ['inputs_sha256','build_receipt_sha256','binary_sha256']:
   changed={**q,field:'0'*64}
   with self.subTest(field=field),mock.patch.object(c,'read',side_effect=lambda p:changed if p==c.P/'qualification-inputs.json'else read(p)),self.assertRaisesRegex(ValueError,'reviewed build/input/binary identity'):c.build_inputs()

if __name__=='__main__':unittest.main()
