"""Pure input/proof helpers and bounded observations; no native launch on import."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
from live_lease import LiveLease,LOCK_PATH
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-benchmark-cleanup');B=Path('/private/tmp/vellum-macos-composed-endurance');S=Path('/private/tmp/vellum-macos-composed-soak')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def need(v,why):
 if not v:raise ValueError(why)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def command(argv,timeout=10):
 d=run_child(argv,capture_output=True,env=child_environment(),timeout=timeout);need(d.returncode==0 and not d.stderr,'observation command failed');return d.stdout

def snapshot():
 names=command(['git','-C',str(R),'ls-files']).decode().splitlines()
 return {'commit':command(['git','-C',str(R),'rev-parse','HEAD']).decode().strip(),'clean':command(['git','-C',str(R),'status','--porcelain'])==b'','tracked':{n:sha(R/n)for n in names},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
def build_inputs():
 q=read(P/'qualification-inputs.json');need(q['inputs_sha256']==sha(P/'inputs.json')and q['build_receipt_sha256']==sha(P/'build.json')and q['binary_sha256']==sha(P/'loadedgrid'),'reviewed build/input/binary identity')
 i=read(P/'inputs.json');b=read(P/'build.json');need(b['exit_code']==0 and b['error']is None and b['tracked_stable']and b['prepared_stable'],'successful stable build')
 need(b['inputs_sha256']==sha(P/'inputs.json')and b['producer_sha256']==i['producer_sha256']==sha(P/'prepare_build.py'),'build input binding')
 need(b['argv']==['go','build','-trimpath','-o',str(P/'loadedgrid'),'.']and b['cwd']==str(R/'examples/loadedgrid'),'optimized build invocation')
 need(i['source_commit']=='77ca764b2a7896058cc21872a742f3a57bdf058c'and len(i['tracked'])==4467 and len(i['prepared'])==6227,'frozen source sizes')
 need(sha(P/'loadedgrid')==b['binary_sha256']and(P/'loadedgrid').stat().st_size==b['binary_bytes']>0,'built executable identity')
 for ch in['stdout','stderr']:need(sha(P/('build.'+ch))==b[ch+'_sha256'],'build '+ch)
 need(sha(P/'binary-go-version.txt')==b['binary_metadata_sha256'],'Go metadata')
 return i,b

def group_members(pid):
 need(type(pid)is int and pid>0,'owned group identity');raw=command(['ps','-axo','pid=,pgid=,stat='],5);need(bool(raw),'empty process observation');members=[]
 for line in raw.decode().splitlines():
  fields=line.split();need(len(fields)==3 and fields[0].isdecimal()and fields[1].isdecimal(),'malformed process observation')
  if int(fields[1])==pid:members.append({'pid':int(fields[0]),'pgid':pid,'state':fields[2]})
 return {'owned_group':pid,'argv':['ps','-axo','pid=,pgid=,stat='],'stdout_bytes':len(raw),'stdout_sha256':hashlib.sha256(raw).hexdigest(),'owned_members':members}
def require_absent(pid):
 obs=group_members(pid);need(not obs['owned_members'],'owned native process group remains');return obs

def planned():
 return [(mode,variable,rows,index)for mode in['cpu','gpu']for variable in[False,True]for rows in[10000,1000000]for index in range(1,6)]
def case_path(mode,variable,rows,index):return P/mode/f"{'variable'if variable else'fixed'}-{rows}"/f'run-{index}'
def native_argv(mode,variable,rows):return[str(P/'loadedgrid'),'-perf',f'-rows={rows}','-perf-samples=120','-perf-warmup=128']+(['-gpu-scene']if mode=='gpu'else[])+(['-variable-rows']if variable else[])
def same_endurance_proof(fresh,saved):
 # The validator creates new observation metadata on each raw revalidation.
 # Only this documented timestamp may differ; every evidence field must match.
 for proof in [fresh,saved]:
  need(type(proof)is dict and type(proof.get('validated_utc'))is str,'endurance proof UTC metadata')
  try:stamp=datetime.datetime.fromisoformat(proof['validated_utc'].replace('Z','+00:00'))
  except ValueError:raise ValueError('endurance proof UTC metadata')from None
  need(stamp.tzinfo is not None and stamp.utcoffset()==datetime.timedelta(0),'endurance proof UTC metadata')
 stable=lambda proof:json.dumps({k:v for k,v in proof.items()if k!='validated_utc'},sort_keys=True,separators=(',',':'),allow_nan=False)
 need(stable(fresh)==stable(saved),'predecessor recorded endurance proof consistency')
def predecessors():
 q=read(P/'qualification-inputs.json')
 for k,path in [('endurance_validator',B/'validate_live.py'),('soak_validator',S/'validate_soak.py')]:need(q[k+'_sha256']==sha(path),k+' identity')
 need((B/'composed-1000-validation.json').is_file()and(S/'soak-preflight-validation.json').is_file(),'terminal predecessor validations required')
 v=load('current_perf_prior_endurance',B/'validate_live.py');ep=v.validate('composed-1000','full');sv=load('current_perf_prior_soak',S/'validate_soak.py');sp=sv.validate('soak-preflight','preflight')
 same_endurance_proof(ep,read(B/'composed-1000-validation.json'))
 need(sp==read(S/'soak-preflight-validation.json'),'predecessor recorded soak proof consistency')
 need(ep['result']=='PASS_1000_COMPOSED_CONTROLS_CYCLES'and sp['result']=='PASS_SCOPED_SOAK_PREFLIGHT','predecessor qualification')
 need(not(S/'soak-overnight-owned-process.json').exists(),'overnight must follow performance; refuse any prior overnight launch')
 return {'endurance_validation_sha256':sha(B/'composed-1000-validation.json'),'soak_preflight_validation_sha256':sha(S/'soak-preflight-validation.json'),'prelaunch_groups':[require_absent(read(path)['process_group'])for path in[B/'composed-1000.json',S/'soak-preflight.json']]}

def stop_markers():return[P/'stop-live',B/'stop-live',S/'stop-live',Path('/private/tmp/vellum-macos-listbox/stop-live')]
def stopping():return[str(p)for p in stop_markers()if p.exists()]
