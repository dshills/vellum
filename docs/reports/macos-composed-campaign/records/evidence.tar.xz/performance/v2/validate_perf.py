"""Validate existing raw measurements without launching a native consumer."""
import hashlib,json,sys
import common as c

def validate():
 run=c.read(c.P/'run.json');q=c.read(c.P/'qualification-inputs.json');i,build=c.build_inputs();review=c.read(c.P/'harness-review.json')
 c.need(run['result']=='MEASURED_CURRENT_GRID'and run['completed_cases']==40 and run['error']is None and run['cleanup_errors']==[]and run['stop_reason']is None and run['stop_markers_at_exit']==[]and run['watcher_joined']is True and run['inputs_stable']is True and run['watchdog_seconds']==2400,'complete uncanceled run')
 c.need(run['native_lease']=={'path':str(c.LOCK_PATH),'acquired':True,'held_through_cleanup':True},'cooperative exclusive lease')
 c.need(run['native_application_executed']is True and run['full_mac_qualified']is False,'native scope')
 for k,path in [('inputs_sha256',c.P/'inputs.json'),('build_receipt_sha256',c.P/'build.json'),('producer_sha256',c.P/'run_perf.py'),('qualification_inputs_sha256',c.P/'qualification-inputs.json'),('harness_review_sha256',c.P/'harness-review.json'),('authorization_sha256',c.P/'live-authorization.json')]:c.need(run[k]==c.sha(path),'binding '+k)
 c.need(review['result']=='APPROVED_SOURCE_AND_HARNESS'and review['unresolved_findings']==[]and all(c.sha(c.P/n)==h for n,h in review['sources'].items())and all(c.sha(c.P/n)==h for n,h in q['harness_sources'].items()),'approved endpoint')
 c.need(run['binary_sha256']==build['binary_sha256']and c.snapshot()=={'commit':i['source_commit'],'clean':True,'tracked':i['tracked'],'prepared':i['prepared']},'observed source/binary closure')
 fresh_prior=c.predecessors()
 for key in ['endurance_validation_sha256','soak_preflight_validation_sha256']:c.need(run['prior'][key]==fresh_prior[key],'prior proof identity')
 old_groups=run['prior']['prelaunch_groups'];new_groups=fresh_prior['prelaunch_groups'];c.need(len(old_groups)==len(new_groups)==2,'predecessor observations')
 for old,new in zip(old_groups,new_groups):c.need(old['owned_group']==new['owned_group']and old['owned_members']==[]and old['stdout_bytes']>0 and old['argv']==new['argv'],'prior group absence endpoint')
 b=c.load('validated_current_native_benchmark',c.R/'scripts/benchmark-grid.py');plan=c.planned();owners=run['owners'];c.need(len(owners)==40,'owned process count');selected={};raw_results={};final_observations=[]
 for entry,(mode,variable,rows,index)in zip(owners,plan):
  path=c.case_path(mode,variable,rows,index);relative=str(path.relative_to(c.P));c.need(entry['case']==relative and entry['argv']==c.native_argv(mode,variable,rows)and type(entry['pid'])is int and entry['pid']>0 and entry['process_group']==entry['pid']and entry['retired']is True and entry['lease_held']is True and len(entry['attempts'])==1,'exact owned case')
  start=c.read(path/'owned-start.json');attempt=c.read(path/'owned-retirement-1.json');c.need(entry['attempts']==[attempt]and all(start[k]==entry[k]for k in['pid','process_group','case','argv','started_utc','lease_held'])and start['retired']is False,'owned receipt binding')
  c.need(attempt['pid']==attempt['process_group']==entry['pid']and attempt['case']==relative and attempt['argv']==entry['argv']and attempt['error']is None and attempt['exit_code']==0 and attempt['direct_child_terminal']is True and attempt['group_absence_confirmed']is True,'terminal case cleanup')
  obs=attempt['group_observation'];c.need(obs['owned_group']==entry['pid']and obs['argv']==['ps','-axo','pid=,pgid=,stat=']and obs['stdout_bytes']>0 and len(obs['stdout_sha256'])==64 and obs['owned_members']==[],'owned group observation')
  raw=(path/'native.log').read_bytes();c.need(0<len(raw)<=b.MAX_OUTPUT and raw.endswith(b'\n'),'complete bounded raw log');records=[]
  for line in raw.splitlines():
   c.need(len(line)<=b.MAX_LINE,'bounded raw line')
   try:value=json.loads(line)
   except(ValueError,UnicodeDecodeError):continue
   if isinstance(value,dict)and str(value.get('event','')).startswith('grid.perf.'):records.append(value)
  result=c.read(path/'result.json');c.need(result['result']=='PASS'and result['error']is None and result['exit_code']==0 and result['argv']==entry['argv']and result['records']==records and result['log_sha256']==hashlib.sha256(raw).hexdigest(),'raw/result case equality')
  samples=b.validate_records(records,rows,variable,120,False,gpu_scene_rendering=mode=='gpu');c.need(len(samples)==120 and len(records)==123,'sample count')
  c.need(records[0].get('cpu_profile')is False and records[0].get('alloc_profile')is False and records[0].get('source_details')is False and all(r.get('input_details')is False and type(r.get('warmup_guard'))is int and r['warmup_guard']==1 for r in records),'ordinary unprofiled guarded measurements')
  c.need(records[1]['warmup']==128,'unchanged warmup')
  key=(mode,variable,rows);selected.setdefault(key,[]).append(samples);raw_results.setdefault(key,[]).append(result);final_observations.append(c.require_absent(entry['pid']))
 c.need(sum((c.case_path(*case)/'native.log').stat().st_size for case in plan)<=256<<20,'total native output budget')
 summaries={};timings={}
 for mode in ['cpu','gpu']:
  report=c.read(c.P/mode/'summary.json');c.need(report['result']=='MEASURED'and report['binary_sha256']==build['binary_sha256']and report['runs']==5 and report['samples_per_run']==120 and report['warmup']==128 and report['gpu_scene_rendering']is(mode=='gpu')and report['source_details']is False and report['diagnostic']is False and report['novel']is False,'ordinary summary')
  c.need(report['warm_targets_ns']=={'p95':4000000,'p99':6000000}and report['selected_inputs_before']==report['selected_inputs_after']==b.selected_inputs(),'unchanged targets/selected source identities')
  c.need(set(report['cases'])=={f"{h}-{r}"for h in['fixed','variable']for r in[10000,1000000]},'four cases')
  timings[mode]={}
  for variable in[False,True]:
   for rows in[10000,1000000]:
    runs=selected[(mode,variable,rows)];name=f"{'variable'if variable else'fixed'}-{rows}";case=report['cases'][name]
    c.need(case['timings_ns']==b.summarize(runs)and case['runs']==raw_results[(mode,variable,rows)],'recomputed sample timings/raw runs')
    for field in['go_process_alloc_bytes','go_process_mallocs']:c.need(case[field]==b.distribution([s[field]for r in runs for s in r]),'Go work distribution')
    c.need(case['source_callbacks']=={k:b.distribution([s['source_callbacks'][k]for r in runs for s in r])for k in['Keys','Inverse','Cells']},'source work distributions')
    timings[mode][name]=case['timings_ns']['ui_work_ns']
   for small,large in zip(selected[(mode,variable,10000)],selected[(mode,variable,1000000)]):b.compare_geometry(small,large)
   name='variable'if variable else'fixed';small=report['cases'][f'{name}-10000']['timings_ns']['ui_work_ns']['pooled']['p95'];large=report['cases'][f'{name}-1000000']['timings_ns']['ui_work_ns']['pooled']['p95'];c.need(report['rowcount_p95_ratios'][name]==large/small,'rowcount ratio')
  c.need(report['warm_target_met']is b.warm_target_met(report['cases']),'target decision');summaries[mode]={'summary_sha256':c.sha(c.P/mode/'summary.json'),'machine_sha256':c.sha(c.P/mode/'machine.json'),'warm_target_met':report['warm_target_met']}
 return {'result':'COMPLETE_CURRENT_NATIVE_GRID_MEASUREMENTS','source_commit':i['source_commit'],'canonical_reference_commit_at_build':i['canonical_reference_commit'],'build_receipt_sha256':c.sha(c.P/'build.json'),'binary_sha256':build['binary_sha256'],'run_receipt_sha256':c.sha(c.P/'run.json'),'validator_sha256':c.sha(__file__),'native_processes':40,'samples':4800,'warmup_per_process':128,'modes':summaries,'ui_work_ns':timings,'fresh_predecessor_groups':fresh_prior['prelaunch_groups'],'final_group_observations':final_observations,'warm_targets_ns':{'p95':4000000,'p99':6000000},'full_p6_qualified':False,'full_mac_qualified':False,'native_gpu_memory_qualified':False,'physical_input_qualified':False,'limits':['CPU mode20 release processes then GPU mode20; current configuration measurements, no before/after optimization attribution.','Measured routed UI/frame elapsed work through submission; physical presentation/native GPU allocation are not available.','Source and prepared bytes observed at endpoints, not hermetic compiler/cache/SDK closure or loaded-executable attestation.','Group observations are bounded OS snapshots after measured work; no process observer runs in the measured native frame interval.','Overnight and human workflows have separate acceptance.']}

if __name__=='__main__':
 output=c.P/'validation.json'
 try:result=validate()
 except BaseException as e:result={'result':'FAILED_CURRENT_PERFORMANCE_VALIDATION','error':{'type':type(e).__name__,'message':str(e)},'validator_sha256':c.sha(__file__),'full_mac_qualified':False}
 output.open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in['result','error']if k in result}));sys.exit(0 if result['result']=='COMPLETE_CURRENT_NATIVE_GRID_MEASUREMENTS'else 1)
