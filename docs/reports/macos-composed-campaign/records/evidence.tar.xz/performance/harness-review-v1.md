Needs fix before launch: require mutual serial exclusion through the whole campaign, and enforce the qualification-pinned build/binary/input plus reviewed artifact identities immediately before launch and at terminal.

Current compile and three CPU-only observer tests reconcile; the real missing-predecessor CLI refused before any native launch. No positive performance evidence exists. Aggregate256MiB is currently an after-case check, not a strict on-write cap.
