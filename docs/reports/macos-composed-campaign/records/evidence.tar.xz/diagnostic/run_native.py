"""Owned, bounded composed native runs with exact observed input identities."""
from pathlib import Path
import datetime,hashlib,json,os,re,selectors,signal,subprocess,sys,time
R=Path('/private/tmp/vellum-soak-occlusion');P=Path(__file__).resolve().parent;B=P;E=Path('/private/tmp/vellum-macos-composed-endurance')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child,terminate_owned_group
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
def identity():
 names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n]
 delta=set(git('diff','HEAD','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
 return {'commit':git('rev-parse','HEAD'),'clean':not git('status','--porcelain'),'tracked':{n:sha(R/n)for n in names},'delta':{n:sha(R/n)for n in sorted(delta)},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
name,soak_mode=sys.argv[1:];assert soak_mode=='preflight'and re.fullmatch('[a-z][a-z0-9-]*',name)
mode='full';count,every=1,1
cooperative,watchdog,duration,quiet,settle,interval=('100s',180,'40s','1s','1s','2s')if soak_mode=='preflight'else('8h3m',29100,'8h','60s','10s','5m')
auth=P/'live-authorization.json';authorization=json.loads(auth.read_text());markers=[P/'stop-live',E/'stop-live',Path(authorization['stop_marker'])]
def stopped():return any(f.exists()for f in markers)
assert not stopped()
configuration=json.loads((P/'inputs.json').read_text());assert sha(P/'live_lease.py')==configuration['lease_source_sha256']and sha(auth)==configuration['authorization_sha256']and sha(P/'diagnostic-source-review.json')==configuration['source_review_sha256']
from live_lease import LiveLease
with LiveLease()as lease:
 assert not stopped()
 # This controller must never compete with the owned lifecycle campaign.
 predecessor=E/'composed-1000.json';predecessor_validation=E/'composed-1000-validation.json'
 assert predecessor.is_file()and predecessor_validation.is_file(), 'predecessor has no terminal validated result'
 pred=json.loads(predecessor.read_text());pv=json.loads(predecessor_validation.read_text())
 import importlib.util
 assert sha(E/'validate_live.py')==configuration['predecessor_validator_sha256']
 spec=importlib.util.spec_from_file_location('endurance_for_diagnostic',E/'validate_live.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
 assert prior.validate('composed-1000','full')['result']=='PASS_1000_COMPOSED_CONTROLS_CYCLES'
 configuration=json.loads((P/'inputs.json').read_text())
 assert pred['result']=='TERMINAL_NATIVE_RUN_OK'and pred['exit_code']==0 and pred['group_absence_confirmed']and pred['direct_child_terminal']and pv['result']=='PASS_1000_COMPOSED_CONTROLS_CYCLES'and pv['run_receipt_sha256']==sha(predecessor)
 observed=run_child(['ps','-axo','pid=,pgid=,comm='],env=child_environment(),capture_output=True,timeout=5)
 assert observed.returncode==0 and not observed.stderr and observed.stdout.strip()
 failed_receipt=Path('/private/tmp/vellum-macos-composed-soak/soak-preflight.json');failed=json.loads(failed_receipt.read_text())
 assert sha(failed_receipt)==configuration['failed_preflight_sha256']and failed['direct_child_terminal']and failed['group_absence_confirmed']
 for line in observed.stdout.decode().splitlines():
  fields=line.split(maxsplit=2);assert len(fields)==3 and fields[0].isdigit()and fields[1].isdigit()and fields[2]
  assert fields[1]not in[str(pred['process_group']),str(failed['process_group'])], 'prior native group is present'
 before=identity();build_name='native-build-v2';build=json.loads((B/(build_name+'.json')).read_text());binary=B/'window-cycle-v2'
 artifact_path=B/'binary.json';artifact=json.loads(artifact_path.read_text())
 assert sha(artifact_path)==configuration['binary_manifest_sha256']and sha(binary)==configuration['binary_sha256']and before['commit']==configuration['source_commit']
 assert artifact['build_receipt_sha256']==sha(B/(build_name+'.json'))and artifact['capture_producer_sha256']==sha(B/'freeze.py')and artifact['binary']==str(binary)and artifact['binary_sha256']==sha(binary)and artifact['binary_bytes']==binary.stat().st_size
 assert build['cwd']==str(R/'drivers/cogent')and build['producer_sha256']==sha(B/'code_run.py')and build['source_commit']==before['commit']and build['overlay_inputs_before']==build['overlay_inputs_after']=={}
 assert all(build[channel+'_sha256']==sha(B/(build_name+'.'+channel))for channel in ['stdout','stderr'])
 assert build['exit_code']==0 and build['error']is None and build['source_delta_stable']and build['prepared_before']==before['prepared']==build['prepared_after']and len(before['prepared'])==6227
 # A later clean commit may package the same reviewed leaves with evidence records.
 assert all(sha(R/n)==h for n,h in build['source_delta_before'].items())
 assert build['argv']==['go','build','-tags=vellum_native_checks','-o',str(binary),'./cmd/window-cycle-smoke']
 assert before==configuration['identity']and build['source_commit']==before['commit']and before['delta']==build['source_delta_before']
 inputs=P/(name+'-inputs.json')
 with inputs.open('x')as f:f.write(json.dumps(before,indent=2)+'\n')
 argv=[str(binary),'-composed',f'-cycles={count}',f'-sample-every={every}',f'-timeout={cooperative}']
 argv.extend([f'-soak={duration}',f'-soak-quiet={quiet}',f'-soak-settle={settle}',f'-soak-interval={interval}'])
 review=json.loads((P/'diagnostic-harness-review.json').read_text());assert review['result']=='APPROVED_SOURCE_AND_HARNESS'and not review['unresolved_findings']and all(sha(P/n)==h for n,h in review['sources'].items())
 pins={n:sha(P/n)for n in['run_native.py','live_lease.py','inputs.json','diagnostic-harness-review.json','live-authorization.json','diagnostic-source-review.json','freeze.py','code_run.py','binary.json','native-build-v2.json']}
 d={'harness_review_sha256':sha(P/'diagnostic-harness-review.json'),'lease_source_sha256':sha(P/'live_lease.py'),'native_lease':{'path':str(lease.path),'acquired':lease.held(),'held_through_cleanup':False},'artifacts_stable':False,'mode':'soak','soak_mode':soak_mode,'qualification_inputs_sha256':sha(P/'inputs.json'),'predecessor_validation_sha256':sha(predecessor_validation),'predecessor_group_reobserved_absent':True,'prelaunch_group_observation_sha256':hashlib.sha256(observed.stdout).hexdigest(),'argv':argv,'cwd':str(R/'drivers/cogent'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs_sha256':sha(inputs),'producer_sha256':sha(__file__),'authorization_sha256':sha(auth),'build_receipt_sha256':sha(B/(build_name+'.json')),'binary_manifest_sha256':sha(artifact_path),'executable_sha256':sha(binary),'watchdog_seconds':watchdog,'exit_code':None,'error':None,'stop_reason':None,'direct_child_terminal':False,'group_absence_confirmed':False,'inputs_stable':False,'binary_stable':False,'logs_complete':False,'cleanup_errors':[]}
 child=None;start=time.monotonic();counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()]
 try:
  with(P/(name+'.stdout')).open('xb')as so,(P/(name+'.stderr')).open('xb')as se,selectors.DefaultSelector()as ready:
   assert lease.held()and all(sha(P/n)==h for n,h in pins.items())and not stopped()and identity()==before and sha(binary)==d['executable_sha256']and sha(artifact_path)==d['binary_manifest_sha256']and sha(inputs)==d['inputs_sha256']
   child=subprocess.Popen(argv,cwd=R/'drivers/cogent',env=child_environment(runtime=True),stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
   d['pid']=child.pid;d['process_group']=child.pid
   (P/(name+'-owned-process.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'pid':child.pid,'mode':mode,'watchdog_seconds':watchdog}),flush=True)
   for i,pipe in enumerate([child.stdout,child.stderr]):ready.register(pipe,selectors.EVENT_READ,i)
   terminal_at=None
   while ready.get_map()or child.poll()is None:
    if stopped():d['stop_reason']='human-return-marker';raise InterruptedError(d['stop_reason'])
    if time.monotonic()-start>watchdog:d['stop_reason']='watchdog';raise TimeoutError(d['stop_reason'])
    if child.poll()is not None:
     if terminal_at is None:terminal_at=time.monotonic()
     if time.monotonic()-terminal_at>5:raise TimeoutError('pipe writers survived native direct child')
    for key,_ in ready.select(.2):
     data=os.read(key.fd,64<<10)
     if not data:ready.unregister(key.fileobj);continue
     i=key.data;limit=(64<<20)if i==0 else(4<<20);accepted=min(len(data),limit-counts[i])
     if accepted:
      if [so,se][i].write(data[:accepted])!=accepted:raise OSError('short log write')
      [so,se][i].flush()
      digests[i].update(data[:accepted]);counts[i]+=accepted
     if accepted!=len(data):raise OSError('native output byte bound exceeded')
   d['exit_code']=child.wait(timeout=5)
 except BaseException as error:
  d['error']={'type':type(error).__name__,'message':str(error)}
 finally:
  def failed(stage,error):d['cleanup_errors'].append({'stage':stage,'type':type(error).__name__,'message':str(error)})
  if child is not None:
   try:
    if child.poll()is None:
     try:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=5)
     except (ProcessLookupError,subprocess.TimeoutExpired):pass
    terminate_owned_group(child)
   except BaseException as error:failed('owned-group-retirement',error)
   try:
    if child.poll()is None:child.kill()
    d['exit_code']=child.wait(timeout=5);d['direct_child_terminal']=child.poll()is not None
   except BaseException as error:failed('direct-child-reap',error)
   for pipe in [child.stdout,child.stderr]:
    try:pipe.close()
    except BaseException as error:failed('pipe-close',error)
   try:
    observation_argv=['ps','-axo','pid=,pgid=,comm=']
    observed=run_child(observation_argv,env=child_environment(),capture_output=True,timeout=5)
    d['group_observation']={'argv':observation_argv,'exit_code':observed.returncode,'stdout_sha256':hashlib.sha256(observed.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(observed.stderr).hexdigest(),'stdout_bytes':len(observed.stdout),'stderr_bytes':len(observed.stderr)}
    if observed.returncode!=0 or observed.stderr or not observed.stdout.strip():raise OSError('unconfirmed process-group observation')
    rows=[]
    for line in observed.stdout.decode().splitlines():
     fields=line.split(maxsplit=2)
     if len(fields)!=3 or not fields[0].isdigit()or not fields[1].isdigit()or not fields[2]:raise OSError('malformed process-group observation')
     if fields[1]==str(child.pid):rows.append(line.strip())
    d['post_terminal_group_members']=rows;d['group_absence_confirmed']=not rows;d['group_observation_sha256']=hashlib.sha256(observed.stdout).hexdigest()
   except BaseException as error:failed('group-observation',error)
  for stage,fn in [('input-identity',lambda:identity()==before),('binary-identity',lambda:sha(binary)==d['executable_sha256'])]:
   try:d['inputs_stable'if stage=='input-identity'else'binary_stable']=fn()
   except BaseException as error:failed(stage,error)
  try:d['stop_marker_at_exit']=stopped()
  except BaseException as error:d['stop_marker_at_exit']=True;failed('stop-observation',error)
  try:
   d['logs']={channel:{'bytes':counts[i],'sha256':sha(P/(name+'.'+channel)),'stream_sha256':digests[i].hexdigest()}for i,channel in enumerate(['stdout','stderr'])}
   d['logs_complete']=all(x['sha256']==x['stream_sha256']for x in d['logs'].values())
  except BaseException as error:failed('log-digests',error)
  d['native_lease']['held_through_cleanup']=lease.held()
  try:d['artifacts_stable']=all(sha(P/n)==h for n,h in pins.items())
  except BaseException as error:failed('reviewed-artifact-identity',error)
  d['elapsed_seconds']=time.monotonic()-start
  d['result']='TERMINAL_NATIVE_RUN_OK'if d['exit_code']==0 and d['error']is None and d['stop_reason']is None and not d['stop_marker_at_exit']and d['inputs_stable']and d['binary_stable']and d['logs_complete']and d['direct_child_terminal']and d['group_absence_confirmed']and d['artifacts_stable']and d['native_lease']['held_through_cleanup']and not d['cleanup_errors']else'FAILED_OR_CANCELED_NATIVE_RUN'
  try:(P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
  except BaseException as error:d['result']='FAILED_OR_CANCELED_NATIVE_RUN';failed('receipt-write',error)
  print(json.dumps(d),flush=True)
 sys.exit(0 if d['result']=='TERMINAL_NATIVE_RUN_OK'else 1)
