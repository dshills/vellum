Approved the exact five-source diagnostic endpoint. SOAK-DIAGNOSTIC-01 is resolved: last successful target/cover DTOs and observation time survive later query failure; final query error is separately bounded.

Pair uniqueness/main-thread bounds, finite containment and strict native occlusion predicate are sound. Final tagged command race and build receipts bind these bytes/6227 unchanged prepared leaves. No actual diagnostic reproduction, geometry fix, idleCPU or fullMac acceptance is claimed.
