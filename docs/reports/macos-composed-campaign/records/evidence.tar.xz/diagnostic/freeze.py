"""Bind the observed diagnostic build, exact sources and bounded live controller."""
from pathlib import Path
import datetime,hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-soak-occlusion');E=Path('/private/tmp/vellum-macos-composed-endurance')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
read=lambda f:json.loads(Path(f).read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode().strip()
def write(name,data):
 with(P/name).open('x')as f:f.write(json.dumps(data,indent=2)+'\n')
names=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().rstrip('\0').split('\0')
delta=set(git('diff','HEAD','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
identity={'commit':git('rev-parse','HEAD'),'clean':not git('status','--porcelain'),'tracked':{n:sha(R/n)for n in names},'delta':{n:sha(R/n)for n in sorted(delta)},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for module in['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}}
b=read(P/'native-build-v2.json');review=read(P/'diagnostic-source-review.json')
assert review['result']=='APPROVED_SOURCE'and not review['unresolved_findings']and identity['delta']==review['sources']
assert b['exit_code']==0 and b['error']is None and b['source_delta_before']==b['source_delta_after']==identity['delta']and b['prepared_before']==b['prepared_after']==identity['prepared']and b['source_commit']==identity['commit']and b['producer_sha256']==sha(P/'code_run.py')
assert b['argv']==['go','build','-tags=vellum_native_checks','-o',str(P/'window-cycle-v2'),'./cmd/window-cycle-smoke']and b['cwd']==str(R/'drivers/cogent')and b['overlay_inputs_before']==b['overlay_inputs_after']=={}
assert all(b[c+'_sha256']==sha(P/('native-build-v2.'+c))for c in['stdout','stderr'])
binary={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'capture_producer_sha256':sha(__file__),'build_receipt_sha256':sha(P/'native-build-v2.json'),'source_review_sha256':sha(P/'diagnostic-source-review.json'),'binary':str(P/'window-cycle-v2'),'binary_sha256':sha(P/'window-cycle-v2'),'binary_bytes':(P/'window-cycle-v2').stat().st_size,'scope':'Post-build local output association with exact observed inputs; no hermetic compiler/cache/loaded-image claim.'}
write('binary.json',binary)
inputs={'source_commit':identity['commit'],'identity':identity,'binary_manifest_sha256':sha(P/'binary.json'),'binary_sha256':binary['binary_sha256'],'lease_source_sha256':sha(P/'live_lease.py'),'predecessor_validator_sha256':sha(E/'validate_live.py'),'failed_preflight_sha256':sha('/private/tmp/vellum-macos-composed-soak/soak-preflight.json'),'source_review_sha256':sha(P/'diagnostic-source-review.json'),'authorization_sha256':sha(P/'live-authorization.json'),'scope':'One diagnostic40s preflight, strict native occlusion, no overnight or performance qualification.'}
write('inputs.json',inputs)
print(json.dumps({'source_commit':identity['commit'],'changed_leaves':len(identity['delta']),'prepared_leaves':len(identity['prepared']),'binary_sha256':binary['binary_sha256']}))
