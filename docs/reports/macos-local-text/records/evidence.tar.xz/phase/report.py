from pathlib import Path
import hashlib,json
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-text-layout');dest=r/'docs/reports/macos-local-text';rec=dest/'records';rec.mkdir(parents=True,exist_ok=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((p/'comparison/summary.json').read_text());q=json.loads((p/'comparison/qualification.json').read_text());assert q['processes']==40 and q['ordinary_samples']==4800
summary={'result':'PASS_MATCHED_NATIVE_LOCAL_TEXT_COMPARISON','base_commit':json.loads((p/'baseline.json').read_text())['commit'],'processes':40,'samples':4800,'runs_per_binary_per_case':5,'warmup_callbacks_per_process':128,'samples_per_process':120,'gpu_scene_opt_in':True,'paired_geometry_exact':True,'latency_targets_met':False,'binary_sha256':q['binary_sha256'],'comparison_qualification_sha256':sha(p/'comparison/qualification.json'),'cases':{}}
lines=[]
for case in s['baseline']:
 a=s['baseline'][case];b=s['candidate'][case];u=a['timings_ns']['ui_work_ns']['pooled'];v=b['timings_ns']['ui_work_ns']['pooled'];aa=a['go_process_alloc_bytes']['mean']/2**20;bb=b['go_process_alloc_bytes']['mean']/2**20
 summary['cases'][case]={'baseline_ui_work_ns':u,'candidate_ui_work_ns':v,'baseline_mean_alloc_bytes':a['go_process_alloc_bytes']['mean'],'candidate_mean_alloc_bytes':b['go_process_alloc_bytes']['mean'],'baseline_mean_mallocs':a['go_process_mallocs']['mean'],'candidate_mean_mallocs':b['go_process_mallocs']['mean']}
 lines.append(f"| {case} | {u['p95']/1e6:.3f} / {v['p95']/1e6:.3f} | {u['p99']/1e6:.3f} / {v['p99']/1e6:.3f} | {u['mean']/1e6:.3f} / {v['mean']/1e6:.3f} | {aa:.3f} / {bb:.3f} |")
summary['limits']=['Single local host; opt-in GPU scene rendering only','Host UI work excludes queue wait/drawable acquisition, GPU completion and physical presentation','Process-wide Go allocation includes helpers/runtime; no native/private memory attribution','Complete P6, integrated P11, human accessibility and release acceptance remain open']
(rec/'review-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(dest/'README.md').write_text('''# Passive grid text layout

Owned patch 0055 removes duplicate shaping from an admitted local grid update.
Previously the ordinary Text updater shaped changed content using the old
allocation and the scheduled local sizing pass immediately shaped it again.
Passive labels now parse/update normally, clear old shaped runs before new rich
styles, and shape in the required sizing pass. The inline editor and ordinary
full-layout updates retain immediate shaping.

The Core helper refuses interactive text, full-layout fences, unrequested roots,
foreign/retired/detached roots or text, and wrong ancestors before mutation.
Caller must keep passive styles and size every updated label before paint.
Grid's existing styleDirty-to-layoutDirty relationship guarantees that pass.
The scoped updater flag restores on return; pending text shapes normally in
Render if a queued root is canceled before sizing. This changes no painter order,
GPU upload, row cache, document data or public Vellum API.

Internal review found and fixed the pre-paint input hazard by refusing interactive
Text. Real-shaper tests cover one scheduled shape, untouched interactive refusal,
ordinary fallback with immediate shape-consuming input, cancellation recovery,
foreign/root/global fences and restored updater scope. Grid race tests cover
local/full pixels, retained membership, editing and accessibility publication.
Formal preparation checks all 55 patch stages and produces exactly three reviewed
Core leaves plus the adapter change; other prepared leaves remain byte-identical.

The native release comparison uses 40 sequential Cocoa processes, five
alternating pairs per case, 128 guarded warmup callbacks and 120 samples per
process (4,800 total). All callback guards, paired geometry and exits pass;
every run and outlier is retained. Both binaries use the same observer and
opt-in GPU scene rendering. [Review summary](records/review-summary.json) records
binary identities, pooled results and scope.

| Case | Baseline / candidate p95 (ms) | Baseline / candidate p99 (ms) | Mean UI work (ms) | Mean Go allocation (MiB/sample) |
| --- | --- | --- | --- | --- |
'''+ '\n'.join(lines)+'''

Observed mean UI work improves 2.8–3.2%, p95 improves 4.9–8.5%, mean process Go
allocation falls 1.5–2.1%, and allocation count falls about 4.8–4.9%. These are
local pooled observations, not statistical proof across hosts. Both binaries
still miss the unchanged 4 ms p95 / 6 ms p99 targets. Host UI work excludes queue
wait and drawable acquisition, and does not measure GPU completion or physical
presentation. Default CPU rendering was not timed in this campaign.

The checkpoint uses internal source review and one bounded Prism review with
Anthropic Claude Sonnet 5.5. Raw overlay sources, superseded failed fixture run,
passing receipts, all native records and reviews are preserved in a SHA256-indexed
local archive after review. Complete P6, composed P11/endurance, native memory,
human input/accessibility, physical GPU/display and distribution gates remain open.
''')
f=r/'specs/grid-native.md';t=f.read_text();needle='Core admits at most 64 live local-layout roots';i=t.index(needle);t=t[:i]+'''Passive grid labels can defer the ordinary updater's allocation shape to the
admitted local sizing pass (owned patch 0055). Value/updater callbacks and rich
parsing still run; old shaped output is cleared before applying new rich styles.
Every updated label must remain passive and belong to the root's sizing set.
Interactive text, wrong/retired/detached roots, missing requests and full-layout
fences refuse without mutation and take the ordinary updater. Sizing clears the
pending state; Render restores allocation shaping if a queued pass is canceled.
This preserves inline editing's immediate shaping and complete scene paint.

'''+t[i:];f.write_text(t)
f=r/'specs/macos-completion.md';f.write_text(f.read_text()+'''
The [passive grid text checkpoint](../docs/reports/macos-local-text/README.md)
removes the updater shape that an admitted local sizing pass immediately replaces.
Interactive text keeps its ordinary updater path; canceled local requests restore
shaping before paint. Internal review and real-shaper/grid race checks qualify the
bounded behavior. A 40-process/4,800-sample native comparison shows roughly 3%
lower mean UI work and fewer allocations in all four fixed/variable 10k/1m cases.
The unchanged 4/6 ms targets still fail; complete P6, composed P11/endurance and
Mac release acceptance remain open.
''')
names=['drivers/cogent/grid.go','drivers/cogent/native/dependencies.json','drivers/cogent/prepare_test.py',*[f.relative_to(r).as_posix()for f in sorted((r/'drivers/cogent/native/patches/localtext').iterdir())],'specs/grid-native.md','specs/macos-completion.md','docs/reports/macos-local-text/README.md','docs/reports/macos-local-text/records/review-summary.json']
(p/'checkpoint-source.json').write_text(json.dumps({'sources':{n:sha(r/n)for n in names}},indent=2)+'\n');print('Report source leaves:',len(names))
