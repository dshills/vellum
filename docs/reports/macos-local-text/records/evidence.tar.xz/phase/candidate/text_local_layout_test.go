//go:build offscreen

// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/math32"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/abilities"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/text"
	"testing"
)

type textWrapProbe struct {
	shaped.Shaper
	calls int
}

func (p *textWrapProbe) WrapLines(tx rich.Text, style *rich.Style, ts *text.Style, size math32.Vector2) *shaped.Lines {
	p.calls++
	return p.Shaper.WrapLines(tx, style, ts, size)
}

func TestVellumLocalTextUpdateShapesOnceAndRefusesForeign(t *testing.T) {
	var tx *Text
	m, sc, roots := localFixture(t, 2)
	root := roots[0]
	rc := sc.renderContext()
	rc.Lock()
	tx = NewText(root).SetText("old value")
	tx.Styler(func(s *styles.Style) {
		s.Text.WhiteSpace = text.WhiteSpacePre
		s.SetAbilities(false, abilities.Focusable, abilities.Selectable, abilities.Clickable, abilities.Activatable, abilities.DoubleClickable, abilities.TripleClickable, abilities.Draggable, abilities.LongPressable, abilities.LongHoverable, abilities.Slideable)
	})
	tx.Update()
	rc.Unlock()
	drainManual(t, m)
	rc.Lock()
	defer rc.Unlock()
	probe := &textWrapProbe{Shaper: rc.textShaper}
	rc.textShaper = probe
	defer func() { rc.textShaper = probe.Shaper }()
	oldPaint := tx.PaintText()
	tx.SetText("new &lt;literal&gt;")
	if sc.UpdateTextForLocalLayout(root, tx) {
		t.Fatal("unrequested root admitted")
	}
	if tx.PaintText() != oldPaint {
		t.Fatal("refusal changed text")
	}
	if !sc.NeedsLocalLayout(root) {
		t.Fatal("local request rejected")
	}
	if sc.UpdateTextForLocalLayout(roots[1], tx) {
		t.Fatal("foreign subtree admitted")
	}
	if !sc.UpdateTextForLocalLayout(root, tx) {
		t.Fatal("admitted text refused")
	}
	if probe.calls != 0 || tx.PaintText() != nil || tx.localLayoutUpdate {
		t.Fatal("updater shaped early or retained scoped deferral", probe.calls)
	}
	tx.Style()
	tx.SizeUp()
	tx.SizeDown(0)
	tx.SizeFinal()
	if probe.calls != 1 || tx.PaintText() == nil || string(tx.TextRunes()) != "new <literal>" {
		t.Fatal("scheduled sizing did not produce exact new content once", probe.calls, string(tx.TextRunes()))
	}
	probe.calls = 0
	tx.SetText("cancelled deferred")
	if !sc.UpdateTextForLocalLayout(root, tx) {
		t.Fatal("second admitted text refused")
	}
	tx.Style()
	sc.clearLocalLayouts() // simulate request cancellation without a sizing pass
	tx.Render()
	if probe.calls != 1 || tx.PaintText() == nil || tx.localTextPending || string(tx.TextRunes()) != "cancelled deferred" {
		t.Fatal("cancelled local layout lost text fallback", probe.calls)
	}
	probe.calls = 0
	tx.SetText("ordinary next")
	tx.UpdateWidget()
	if probe.calls == 0 || tx.PaintText() == nil {
		t.Fatal("normal updater lost immediate shaping")
	}
	sc.setFlag(true, sceneNeedsLayout)
	oldPaint = tx.PaintText()
	if sc.UpdateTextForLocalLayout(root, tx) || tx.PaintText() != oldPaint {
		t.Fatal("full-layout fence bypassed")
	}
}

func TestVellumLocalTextUpdateRefusesInteractiveText(t *testing.T) {
	m, sc, roots := localFixture(t, 1)
	root := roots[0]
	rc := sc.renderContext()
	rc.Lock()
	tx := NewText(root).SetText("old interactive value")
	tx.Update()
	rc.Unlock()
	drainManual(t, m)
	rc.Lock()
	defer rc.Unlock()
	probe := &textWrapProbe{Shaper: rc.textShaper}
	rc.textShaper = probe
	defer func() { rc.textShaper = probe.Shaper }()
	if !tx.AbilityIs(abilities.Selectable) || !tx.AbilityIs(abilities.DoubleClickable) || !tx.AbilityIs(abilities.Slideable) {
		t.Fatal("fixture lacks ordinary text interactions")
	}
	if !sc.NeedsLocalLayout(root) {
		t.Fatal("local request rejected")
	}
	oldPaint := tx.PaintText()
	tx.SetText("new interactive value")
	if sc.UpdateTextForLocalLayout(root, tx) || tx.PaintText() != oldPaint || probe.calls != 0 || tx.localTextPending {
		t.Fatal("interactive refusal changed shaped content")
	}
	tx.UpdateWidget()
	if tx.PaintText() == nil || probe.calls == 0 || string(tx.TextRunes()) != "new interactive value" {
		t.Fatal("ordinary interactive fallback lost shaping")
	}
	// These shape-consuming paths are safe immediately, before a queued paint.
	tx.pixelToRune(tx.Geom.ContentBBox.Min)
	tx.selectWord(0)
}
