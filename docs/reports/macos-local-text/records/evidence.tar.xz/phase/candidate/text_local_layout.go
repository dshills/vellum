// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package core

import "cogentcore.org/core/styles/abilities"

// UpdateTextForLocalLayout runs a passive text's ordinary value/updater callbacks
// without allocation-based shaping that an admitted fixed-allocation pass will
// immediately replace. The caller styles the text normally afterward; its root
// must size every updated text before paint, including its ordinary fallback.
// If a queued root is cancelled or reparented, Render restores ordinary
// allocation shaping before consuming text. Interactive text is refused because
// its input handlers require shaped content before the next layout pass.
// Call only under this scene's originating render context. False leaves the text
// untouched so the caller can use the normal UpdateWidget path.
func (sc *Scene) UpdateTextForLocalLayout(root LocalLayoutRoot, tx *Text) bool {
	_, wb := sc.localLayoutIdentity(root)
	if wb == nil || tx == nil || tx.This == nil || tx.Scene != sc || sc.GlobalLayoutPending() || !sc.localLayoutAttached(wb) || !sc.localLayoutAttached(tx.AsWidget()) {
		return false
	}
	for _, ability := range []abilities.Abilities{
		abilities.Focusable, abilities.Selectable, abilities.Clickable, abilities.Activatable,
		abilities.DoubleClickable, abilities.TripleClickable, abilities.Draggable,
		abilities.LongPressable, abilities.LongHoverable, abilities.Slideable,
	} {
		if tx.AbilityIs(ability) {
			return false
		}
	}
	admitted := false
	for _, request := range sc.localLayouts {
		if request.root.AsWidget() == wb && request.parent == wb.Parent.AsTree() {
			admitted = true
			break
		}
	}
	if !admitted {
		return false
	}
	descendant := false
	for parent, depth := tx.Parent, 0; parent != nil && depth < localLayoutMaxAncestors; parent, depth = parent.AsTree().Parent, depth+1 {
		if parent.AsTree() == wb.AsTree() {
			descendant = true
			break
		}
	}
	if !descendant {
		return false
	}
	previous := tx.localLayoutUpdate
	tx.localLayoutUpdate = true
	defer func() { tx.localLayoutUpdate = previous }()
	// Old shaped content must not receive new rich-span styles before SizeUp.
	// The registered root guarantees its upcoming sizing/paint boundary.
	tx.paintText = nil
	tx.localTextPending = true
	tx.UpdateWidget()
	// An application updater may size eagerly; the final rich source still wins.
	tx.paintText = nil
	tx.localTextPending = true
	return true
}
