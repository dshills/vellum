"""Preserve exact reviewed source, scoped test evidence and every native run."""
from pathlib import Path
import hashlib,io,json,tarfile
from run import ROOT,PHASE,sha,identity
sources=json.loads((PHASE/'checkpoint-source.json').read_text())['sources'];assert len(sources)==11 and all(sha(ROOT/n)==h for n,h in sources.items())
formal=json.loads((PHASE/'formal-prepared.json').read_text());assert len(formal)==6204 and identity()['prepared']==formal
review=json.loads((PHASE/'final-source-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['findings'];assert review['reviewed_file_sha256']=={str(ROOT/n):h for n,h in sources.items()}
receipts={}
for name in ['formal-core-race-v1','formal-adapter-race-v1','formal-workbench-race-v2','formal-vet-v1','formal-prepare-test-v1']:
 r=json.loads((PHASE/(name+'.json')).read_text());assert r['error'] is None and r['prepared_before']==r['prepared_after']==formal
 for c in ['stdout','stderr']:assert sha(PHASE/(name+'.'+c))==r[c+'_sha256']
 if name=='formal-adapter-race-v1':
  assert r['exit_code']==1
  log=(PHASE/(name+'.stdout')).read_text();assert log.count('--- FAIL:')==1 and 'bind: operation not permitted' in log
  for before_or_after in ['before','after']:
   selected={n:h for n,h in r['source_delta_'+before_or_after].items()if not n.startswith(('docs/','specs/'))}
   if before_or_after=='before':before=selected
   else:assert selected==before
  assert {n for n,h in r['source_delta_after'].items()if r['source_delta_before'].get(n)!=h}=={'specs/grid-native.md','specs/macos-completion.md','docs/reports/macos-local-text/README.md','docs/reports/macos-local-text/records/review-summary.json'}
 else:assert r['exit_code']==0 and r['source_delta_stable']
 receipts[name]=sha(PHASE/(name+'.json'))
r=json.loads((PHASE/'native-comparison-v1.json').read_text());assert r['exit_code']==0 and r['error'] is None and r['source_prepared_stable']
comparison=json.loads((PHASE/'comparison/qualification.json').read_text());assert comparison['result']=='PASS_MATCHED_COMPARISON' and comparison['processes']==40 and comparison['ordinary_samples']==4800 and comparison['summary_sha256']==sha(PHASE/'comparison/summary.json')
process=json.loads((PHASE/'prism-v1/process.json').read_text());prism=json.loads((PHASE/'prism-v1/prism.json').read_text());assert process['exit_code']==0 and process['error'] is None and process['source_index_stable'] and process['before']==process['after']==sources;assert prism['coverage']['complete'] and prism['coverage']['files']==11 and not prism['findings']
q={'result':'REVIEWED_MAC_LOCAL_TEXT','base_commit':identity()['commit'],'source':sources,'prepared_files':6204,'prepared_manifest_sha256':sha(PHASE/'formal-prepared.json'),'processes':40,'ordinary_samples':4800,'gpu_scene_opt_in':True,'latency_targets_met':False,'required_receipts':receipts,'adapter_test_qualification':'Broad race suite passes all packages except sandbox-denied workbench Unix socket; exact failed package retry passes with socket permission. During broad suite only four report/spec leaves changed; all code and prepared files stayed exact. Raw failure retained.','comparison_sha256':sha(PHASE/'comparison/qualification.json'),'internal_review_sha256':sha(PHASE/'final-source-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':0,'prism_coverage_complete':True,'prism_sha256':sha(PHASE/'prism-v1/prism.json'),'limits':['Local opt-in GPU scene host observations; no GPU completion or physical presentation timing.','CompleteP6, integratedP11, physicalGPU/human/release acceptance remainopen.']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records=ROOT/'docs/reports/macos-local-text/records';suffixes={'.go','.py','.md','.txt','.json','.stdout','.stderr','.log','.patch','.png'}
members={'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes()for p in sorted(PHASE.rglob('*'))if p.is_file()and p.suffix in suffixes};members.update({'root/'+n:(ROOT/n).read_bytes()for n in sources})
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz')as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz')as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
checkpoint={**q,'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),'archive_members':len(index),'archive_index_verified':True,'qualification_sha256':sha(PHASE/'qualification.json'),'seal_producer_sha256':sha(__file__)}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n');print('Evidence verified:',len(index),'members')
