"""Persist only the reviewed overlay as a hash-pinned owned dependency stage."""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path('/private/tmp/vellum-large-data'); PHASE=Path('/private/tmp/vellum-macos-text-layout')
sha=lambda b:hashlib.sha256(b).hexdigest()
review=json.loads((PHASE/'overlay-source-review.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings']
overlay=json.loads((PHASE/'candidate-overlay.json').read_text())['Replace']
base=json.loads((PHASE/'baseline.json').read_text())['prepared']
prepared=ROOT/'drivers/cogent/build/upstream'
original={}; outputs={}; chunks=[]
for target,candidate in sorted(overlay.items()):
 if not Path(target).is_relative_to(prepared):
  assert Path(target) == ROOT/'drivers/cogent/grid.go'
  assert sha(Path(candidate).read_bytes()) == review['reviewed_file_sha256'][candidate]
  Path(target).write_bytes(Path(candidate).read_bytes())
  continue
 t=Path(target); c=Path(candidate); relative=t.relative_to(prepared).as_posix()
 before=t.read_bytes() if t.exists() else None; after=c.read_bytes()
 assert sha(after)==review['reviewed_file_sha256'][str(c)]
 assert (sha(before) if before is not None else None)==base.get('upstream/'+relative)
 original[relative]=sha(before) if before is not None else None; outputs[relative]=sha(after)
 chunks.extend(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+relative if before else '/dev/null',tofile='b/'+relative))
stage=ROOT/'drivers/cogent/native/patches/localtext'; stage.mkdir()
patch=stage/'0055-passive-local-text-layout.patch'; patch.write_text(''.join(chunks))
for name,content in [('original-hashes.json',original),('output-hashes.json',outputs)]:
 (stage/name).write_text(json.dumps(content,indent=2)+'\n')
(stage/'README.md').write_text("""# Passive local text layout

Patch 0055 lets an admitted fixed-allocation local root update passive Text
without the allocation shape that its required sizing pass immediately replaces.
Value/updater callbacks and ordinary styles remain active; old shaped runs are
cleared before new rich styles. The scoped updater flag restores on return.
Sizing clears pending state; Render restores ordinary allocation shaping if the
request is canceled before sizing. Normal/full-layout updates stay immediate.

The helper refuses interactive text, foreign/detached/retired roots and children,
unrequested roots, wrong ancestors and full-layout fences without mutation.
Caller must retain passive styles and size every updated label before paint.
Vellum grid's existing styleDirty-to-layoutDirty relationship provides this rule.
The inline editor takes the ordinary full path.

Actual-shaper regressions cover one scheduled shape, interactive refusal and
immediate input-safe fallback, cancellation recovery and ordinary updates.
Existing grid pixel/focus/editing tests and native paired measurements qualify
this bounded change; no full frame, physical GPU or Mac acceptance is implied.
New helpers/tests are MIT; upstream text.go preserves its existing notice.
Preparation verifies original/output hashes and the patch SHA256.
""")
manifest=ROOT/'drivers/cogent/native/dependencies.json'; m=json.loads(manifest.read_text())
upstream=next(d for d in m['dependencies'] if d['name']=='upstream')
upstream['stages'].append({'origin':'drivers/cogent/native/patches/localtext','inputs':'native/patches/localtext/original-hashes.json','outputs':'native/patches/localtext/output-hashes.json','patches':[{'file':'native/patches/localtext/'+patch.name,'sha256':sha(patch.read_bytes())}]})
manifest.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(outputs,indent=2))

test=ROOT/'drivers/cogent/prepare_test.py'
text=test.read_text();assert 'list(range(1, 55))' in text
test.write_text(text.replace('list(range(1, 55))','list(range(1, 56))'))
