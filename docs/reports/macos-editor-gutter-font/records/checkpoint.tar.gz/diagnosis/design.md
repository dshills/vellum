# Current-candidate M2 workspace qualification

M2's existing workspace evidence predates multiple native owner/focus/publication
fixes. Before claiming its representative-workflow criterion complete, recheck
the public consumer against actual current T Go and Objective-C plus stage86.
Use an external manifest resolving root/driver/prepared modules to T and only
native library module to retained source-built SDK786a. No Go replacement overlay,
checkout modfile mutation, SDK refresh or native application execution in checks.

Run existing public replay root, smoke and workspace offscreen race packages,
which include six frozen216-operation/27-capture records at batches1/7/64 and
10k/1M rows. Preserve immutable records/goldens. Check native consumer vet/build.
Use trusted owned guard, Go1.25.6/GOMAXPROCS2, network denied and T/SDK writes denied,
600s records watchdog/300s other checks/4MiB streams and complete pins/owned cleanup.
This establishes current software evidence only. Any native workspace renewal
requires its own reviewed fresh controller/plan/admission/live lease and cannot
reuse/reset older sealed scopes. No physical/IME/human/accessibility/pixels/
performance/resource/SDK/release/fullMac qualification follows from these checks.
