# Current M2 workspace images: isolated gutter-font conflict

Canonical and candidate runtime remain clean commit5e30a6c. No current product,
prepared dependency, SDK, record or golden is changed by these private probes.

The current Go1.25.6 root/smoke/workspace offscreen race command completes six
full216-operation/27-capture workspace cases (10k/1M, owner batches1/7/64).
Root and smoke pass. Workspace fails exactly12 image comparisons: notes-edited
and tabs-reordered in each case. No capture-data/model/focus/semantic/geometry
mismatch is reported. Original golden files remain unchanged. Whole owned child
finishes184.5666s/CLI1 with complete logs, stable pins and group40987 absent.
Consumer vet and native build pass10.1776s/12.9282s; no native workspace launches.

Private software comparisons preserve the exact frozen test and expectations:

- without-restyle-v1: omit only retained disabled-state restyling; FAIL63.099s,
  same image hashes. The component regex unintentionally also matches million
  rows, so this receipt covers10k and1M batch1, not onlyonecase.
- before-editor-v1: pre-D editor.go plus four PNG copies from Capture; FAIL15.037s,
  same image hashes, one10k/batch1 case. Current Dfix is not required for the failure.
- go127-v1: current product, historical Go1.27.2 compiler, diagnostic PNG copies;
  FAIL41.490s, identical aggregate pixel identities to Go1.25.6, one10k/batch1.
  PNG container bytes differ between encoders; that is not a pixel difference.
- grid-legacy-v1: original managed Text-widget body route, FAIL21.190s, same image
  hashes. One fewer Manual frame/progress unit is visible; no other capture mismatch.
- old-font-v1: omit only a328208's multiline global font-family override, retaining
  all other current product bytes and copying four PNGs; PASS23.095s, all27 original
  goldens and data checks, one10k/batch1 case. Original backend Monospace diagnostic
  returns repeatedly, so this counterfactual is not a proposed runtime rollback.

All probes have complete stable owned chains and absent groups. These are source/
software results, not native pixels or full six-case counterfactual qualification.

Independent RGBA decoding of old-font vs current-product Go1.27 diagnostic PNGs
finds exactly218 changed pixels inside[287,144,307,177] for each main-window image.
Only the two line-number glyphs in the editor gutter change. Inspector pixels
are identical; the document text, caret and remaining main-window pixels match.
See font-pixel-difference.json and the original before-editor-pixels, go127-pixels
and old-font-pixels directories. No diagnostic PNG is used as a new golden.

The passing historical prepared6250 vector is exactly preserved in retained
SDK0077 (sha096ccd4f583f73eada35d9b1ff8bfbb29df7db860281cb5e6c63b75d22548af5,
matching artifacts/macos-m2-workspace/result.json). Only16 old production Core Go
files differ from current stage86; textcore's body/layout/render source is unchanged.
The separate adapter style.go changea328208 forces rich.Monospace and clears
CustomFont for the whole multiline widget, including line-number gutter text.
The public editor contract requires a monospace body; reverting that invariant
merely to match images is inappropriate. Current renderLineNumber derives its
rich style from the same widget font. Review the actual Lines.SetFontStyle,
layout and line-number cache boundary before choosing the repair.

Next: independent causal review and a concrete compatible source approach that
preserves both the body font invariant and the frozen gutter typography. Consider
separating gutter UI typography from the body font supplied to Lines rather than
rewriting historical goldens. If this is impossible, make the rendering-version/
fixture migration decision explicit; do not silently regenerate expectations.
M2 stays partial; no performance threshold, SDK refresh or full Mac gate changes.

Separate fresh native text scope E is FAILED/sealed at name-rejected21inputs/3
source-asserted states, before disabled-editor/modal: knownVisiblefalse seq3 and
one actual surfaceoccluded196609 attempt terminate Frame. It does not qualify the
Dfix natively. E's internal result review independently accepts the evidence,
not a passing text/M2 record. No E replay is permitted.
