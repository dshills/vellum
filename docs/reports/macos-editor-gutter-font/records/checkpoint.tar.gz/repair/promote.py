"""Promote exactly reviewed body/gutter source and docs; SDK remains immutable."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=60,capture_output=True,check=True).stdout
def vector(root):
 d={}
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():d[p.relative_to(root).as_posix()]=sha(p)
 return d
def prepared(root):return{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
def passed(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
assert not(G/'promotion.json').exists();b=read(G/'boundary.json');review=read(G/'internal-product-review.json');assert review['approved']and review['source_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items())
for root in [C,T]:
 assert git(root,'rev-parse','HEAD').decode().strip()==b['head']and not git(root,'status','--porcelain')
 assert {n:sha(root/n)for n in b['source']}==b['source']and prepared(root)==b['prepared']
assert vector(SDK)==b['sdk']
for n in ['driver-v1','gallery-v1','workspace-v1','vet-v1','workspace-vet-v1','core-v3','core-fixture-baseline-v1','core-vet-remainder-v1','build-v1','prepare-v1','prepare-tests-v1']:
 r=read(G/(n+'.json'));assert passed(r)and r.get('font_invariant_diagnostics',0)==0
 assert all(sha(k)==v for k,v in r['source_pins'].items())
 for stream,info in r['logs'].items():
  p=G/n/stream;assert sha(p)==info['sha256']and p.stat().st_size==info['bytes']
assert read(G/'negative-v1.json')['exit_code']==1 and 'retained editor lost themed gutter typography'in(G/'negative-v1/stdout').read_text()
assert(G/'core-vet-v1/stderr').read_bytes()==(G/'core-vet-baseline-v1/stderr').read_bytes()
assert read(G/'prepare-v1.json')['prepared_exact']and read(G/'prepare-v1.json')['prepared_files']==6277 and read(G/'prepare-tests-v1.json')['prepared_unchanged']
mapping={p.relative_to(G/'payload').as_posix():p for p in(G/'payload').rglob('*')if p.is_file()}
mapping.update({'drivers/cogent/style.go':G/'style.go','drivers/cogent/style_test.go':G/'style_test.go'})
assert len(mapping)==13 and all(not p.is_symlink()for p in mapping.values())
for n,p in mapping.items():
 dst=T/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes())
# Only the five deterministic Core outputs are promoted. Canonical retains the
# old stage86 until its tracked manifest is fast-forwarded at the local commit.
for n,v in read(G/'stage87-patch.json')['outputs'].items():
 src=G/'preparation/build/upstream'/n;assert sha(src)==v;dst=T/'drivers/cogent/build/upstream'/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
expected=dict(b['prepared']);expected.update({'upstream/'+n:v for n,v in read(G/'stage87-patch.json')['outputs'].items()})
assert prepared(T)==expected and prepared(C)==b['prepared']and vector(SDK)==b['sdk']
assert set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(mapping)
git(T,'add','--',*sorted(mapping));git(T,'diff','--cached','--check');diff=git(T,'diff','--cached','--binary');(G/'promotion-staged.diff').write_bytes(diff)
out={'base':b['head'],'files':{n:sha(T/n)for n in sorted(mapping)},'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'bytes':len(diff),'prepared_files':len(expected),'prepared_sha256':hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'prepared_canonical_retains_stage86_until_commit':True,'sdk_unchanged':True,'native_executed':False,'provider_calls':0,'closed_full_mac_gates':[]}
(G/'promotion.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
