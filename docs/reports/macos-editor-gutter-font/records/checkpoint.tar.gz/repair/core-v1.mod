module cogentcore.org/core

go 1.25.6

require (
	github.com/Bios-Marcel/wastebasket/v2 v2.0.3
	github.com/Masterminds/semver/v3 v3.2.1
	github.com/Masterminds/vcs v1.13.3
	github.com/adrg/strutil v0.3.1
	github.com/alecthomas/chroma/v2 v2.23.0
	github.com/anthonynsimon/bild v0.14.0
	github.com/aymerick/douceur v0.2.0
	github.com/bramvdbogaerde/go-scp v1.6.0
	github.com/chewxy/math32 v1.11.2
	github.com/cogentcore/reisen v0.0.0-20240814194831-4d884b6e7666
	github.com/cogentcore/star-tex v0.7.2-0.20260625151004-a16970c7d698
	github.com/cogentcore/yaegi v0.0.0-20260116172027-700fbf8949f3
	github.com/coreos/go-oidc/v3 v3.17.0
	github.com/ericchiang/css v1.4.0
	github.com/faiface/beep v1.1.0
	github.com/fsnotify/fsnotify v1.9.0
	github.com/go-fonts/latin-modern v0.3.3
	github.com/go-gl/glfw/v3.4/glfw v0.1.0-pre.1.0.20260628091122-0bd588dc30cf
	github.com/go-text/typesetting v0.3.5-0.20260418130854-c41d02a44bec
	github.com/gomarkdown/markdown v0.0.0-20260417124207-7d523f7318df
	github.com/gorilla/websocket v1.5.3
	github.com/grokify/html-strip-tags-go v0.1.0
	github.com/h2non/filetype v1.1.3
	github.com/hack-pad/hackpadfs v0.2.4
	github.com/jackmordaunt/icns/v2 v2.2.7
	github.com/jeandeaual/go-locale v0.0.0-20250612000132-0ef82f21eade
	github.com/jinzhu/copier v0.4.0
	github.com/mattn/go-shellwords v1.0.12
	github.com/mitchellh/go-homedir v1.1.0
	github.com/muesli/termenv v0.16.0
	github.com/oliverbestmann/webgpu v1.36.1-0.20261006093257-de8bdd5d5976
	github.com/pelletier/go-toml/v2 v2.2.4
	github.com/stretchr/testify v1.11.1
	github.com/tdewolff/parse/v2 v2.8.5
	golang.org/x/crypto v0.54.0
	golang.org/x/exp v0.0.0-20260112195511-716be5621a96
	golang.org/x/image v0.44.0
	golang.org/x/net v0.57.0
	golang.org/x/oauth2 v0.28.0
	golang.org/x/sys v0.47.0
	golang.org/x/text v0.40.0
	golang.org/x/tools v0.48.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	codeberg.org/go-pdf/fpdf v0.11.1 // indirect
	git.sr.ht/~sbinet/overlayfs v0.1.1 // indirect
	github.com/aymanbagabas/go-osc52/v2 v2.0.1 // indirect
	github.com/davecgh/go-spew v1.1.2-0.20180830191138-d8f796af33cc // indirect
	github.com/dlclark/regexp2 v1.11.5 // indirect
	github.com/go-jose/go-jose/v4 v4.1.4 // indirect
	github.com/gobwas/glob v0.2.3 // indirect
	github.com/gorilla/css v1.0.1 // indirect
	github.com/hack-pad/go-indexeddb v0.3.2 // indirect
	github.com/hack-pad/safejs v0.1.1 // indirect
	github.com/hajimehoshi/oto v0.7.1 // indirect
	github.com/kr/pretty v0.3.1 // indirect
	github.com/lucasb-eyer/go-colorful v1.2.0 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/nfnt/resize v0.0.0-20180221191011-83c6a9932646 // indirect
	github.com/oliverbestmann/webgpu/libs-android v0.0.0-20260628152806-6b27e30a172e // indirect
	github.com/oliverbestmann/webgpu/libs-darwin v0.0.0-20260628152755-66a5dfa57f8d // indirect
	github.com/oliverbestmann/webgpu/libs-ios v0.0.0-20260628152757-fe2537e7ddac // indirect
	github.com/oliverbestmann/webgpu/libs-linux v0.0.0-20260628152803-421b8a341d08 // indirect
	github.com/oliverbestmann/webgpu/libs-windows v0.0.0-20260628152801-f47d1b682eb8 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/pmezard/go-difflib v1.0.1-0.20181226105442-5d4384ee4fb2 // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/rogpeppe/go-internal v1.13.1 // indirect
	golang.org/x/exp/shiny v0.0.0-20240416160154-fe59bbe5cc7f // indirect
	golang.org/x/mobile v0.0.0-20231127183840-76ac6878050a // indirect
	golang.org/x/mod v0.38.0 // indirect
	golang.org/x/sync v0.22.0 // indirect
	gopkg.in/check.v1 v1.0.0-20201130134442-10cb98267c6c // indirect
	modernc.org/knuth v0.5.5 // indirect
	modernc.org/token v1.1.0 // indirect
)

// The driver-owned scene compiler uses the pinned bounded-outline extension.
replace github.com/go-text/typesetting => ../typesetting

replace github.com/oliverbestmann/webgpu/libs-darwin => "/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2/drivers/cogent/build/libs-darwin"
replace github.com/go-text/typesetting => /private/tmp/vellum-macos-native-results-97aee13/drivers/cogent/build/typesetting
