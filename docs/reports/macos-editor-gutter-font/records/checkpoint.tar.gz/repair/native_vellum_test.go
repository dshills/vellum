package textcore

import (
	"cogentcore.org/core/core"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/lines"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/textpos"
	"image"
	"image/png"
	"io/fs"
	"os"
	"strings"
	"testing"
)

func nativeEditor(source string) *Editor {
	ed := NewEditor()
	original := ed.Lines
	ls := lines.NewLinesExact().SetString(source)
	ls.Autosave = false
	ls.Settings.EmacsUndo = false
	ed.SetLines(ls)
	original.Close()
	return ed
}
func TestVellumEditorNativeCompositionUndoCancel(t *testing.T) {
	original := "A\n👩‍💻\n"
	ed := nativeEditor(original)
	defer ed.Lines.Close()
	if !ed.SetEditingSelection(2, 2) {
		t.Fatal("selection")
	}
	if !ed.ApplyNativeEdit("A\nに👩‍💻\n", 3, 3, 2, 3, "mark") || !ed.ApplyNativeEdit("A\n日本👩‍💻\n", 4, 4, 2, 4, "mark") {
		t.Fatal("marked edits")
	}
	if !ed.ApplyNativeEdit("A\n日本👩‍💻\n", 4, 4, -1, -1, "insert") {
		t.Fatal("commit")
	}
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != original {
		t.Fatal("one composition undo", ed.Lines.String())
	}
	if len(ed.Lines.Redo()) == 0 || ed.Lines.String() != "A\n日本👩‍💻\n" {
		t.Fatal("redo")
	}
	state := ed.EditingState()
	ed.SetEditingSelection(4, 2)
	before := ed.EditingState()
	ed.ApplyNativeEdit("A\n取消👩‍💻\n", 4, 4, 2, 4, "mark")
	if !ed.ApplyNativeEdit(before.Text, 2, 2, -1, -1, "cancel") || ed.EditingState().Text != before.Text || ed.EditingState().Anchor != 4 || ed.EditingState().Focus != 2 {
		t.Fatal("cancel direction", ed.EditingState(), state)
	}
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != original {
		t.Fatal("cancel left undo records", ed.Lines.String())
	}
}
func TestVellumEditorNativeExternalEditAndReadonly(t *testing.T) {
	ed := nativeEditor("A\nB\n")
	defer ed.Lines.Close()
	ed.ApplyNativeEdit("Aに\nB\n", 2, 2, 1, 2, "mark")
	ed.Lines.InsertText(ed.Lines.EndPos(), []rune("X"))
	if _, _, active := ed.NativeCompositionRange(); active {
		t.Fatal("external edit did not seal preedit")
	}
	current := ed.Lines.String()
	if ed.ApplyNativeEditFrom("Aに\nB\n", "A\nB\n", 1, 1, -1, -1, "cancel") || ed.Lines.String() != current {
		t.Fatal("cancel erased shared edit")
	}
	if ed.ApplyNativeEditFrom("Aに\nB\n", "stale", 0, 0, -1, -1, "insert") || ed.Lines.String() != current {
		t.Fatal("stale shadow accepted")
	}
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != "Aに\nB\n" {
		t.Fatal("external undo")
	}
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != "A\nB\n" {
		t.Fatal("preedit undo")
	}
	ed.Lines.SetReadOnly(true)
	if ed.ApplyNativeEdit("bad", 0, 0, -1, -1, "insert") {
		t.Fatal("readonly buffer edited")
	}
	ed.Lines.SetReadOnly(false)
	for _, v := range []struct {
		text       string
		a, f, s, e int
		phase      string
	}{{"a", 2, 2, -1, -1, "insert"}, {"a\x00b", 0, 0, -1, -1, "insert"}, {"a", 0, 0, 1, 2, "mark"}, {"a", 0, 0, -1, -1, "unknown"}} {
		if ed.ApplyNativeEdit(v.text, v.a, v.f, v.s, v.e, v.phase) {
			t.Fatal("invalid snapshot accepted", v)
		}
	}
	if ed.Lines.String() != "A\nB\n" {
		t.Fatal("validation mutated buffer")
	}
}
func TestVellumEditorNativeFocusCommitAndExactPolicy(t *testing.T) {
	ed := nativeEditor("A\n")
	defer ed.Lines.Close()
	ed.ApplyNativeEdit("Aに\n", 2, 2, 1, 2, "mark")
	ed.editDone()
	if _, _, ok := ed.NativeCompositionRange(); ok {
		t.Fatal("focus commit remained marked")
	}
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != "A\n" {
		t.Fatal("focus commit undo")
	}
	if !ed.ApplyNativeEdit("", 0, 0, -1, -1, "insert") || ed.Lines.String() != "" {
		t.Fatal("empty snapshot")
	}
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != "A\n" {
		t.Fatal("empty undo")
	}
	legacy := NewEditor()
	defer legacy.Lines.Close()
	if legacy.ApplyNativeEdit("A\n", 1, 1, -1, -1, "insert") {
		t.Fatal("legacy newline policy silently changed")
	}
}

// Direct scene fixtures have no render context to create their text shaper.
// Always initialize it with bundled fonts before styling/layout; the optional
// system-font cache below remains an explicit extra, not required bootstrap.
// These package tests are serial. Restore the factory before any fixture input.
func configureEditorSceneShaper(b *core.Body) {
	previous := shaped.NewShaper
	defer func() { shaped.NewShaper = previous }()
	shaped.NewShaper = func() shaped.Shaper {
		return shapedgt.NewShaperWithFonts([]fs.FS{fonts.Default})
	}
	b.Scene.MakeTextShaper()
}

func TestVellumEditorNativeRenderedGeometry(t *testing.T) {
	b := core.NewBody()
	b.Scene.AddChild(b)
	ed := NewEditor(b)
	original := ed.Lines
	ls := lines.NewLinesExact().SetString("abc אבג é 👩‍💻\n\tA\tB\nlong words wrapping beyond the visible viewport\n")
	ls.Autosave = false
	ed.SetLines(ls)
	original.Close()
	defer ls.Close()
	ed.Styler(func(s *styles.Style) { s.Min.X.Em(16); s.Max.X.Em(16); s.Min.Y = units.Em(4); s.Max.Y = units.Em(4) })
	count := 0
	ed.SetNativeEditingListener(func(EditorEditingState) { count++ })
	configureEditorSceneShaper(b)
	if cache := os.Getenv("VELLUM_FONT_CACHE"); cache != "" {
		preload := shapedgt.NewShaperWithFonts(fonts.Embedded).(*shapedgt.Shaper)
		if err := preload.FontMap().UseSystemFonts(cache); err != nil {
			t.Fatal(err)
		}
		if err := b.Scene.MakeTextShaper().(*shapedgt.Shaper).FontMap().UseSystemFonts(cache); err != nil {
			t.Fatal(err)
		}
	}
	b.Scene.Resize(math32.Geom2DInt{Size: image.Pt(320, 130)})
	b.Scene.LayoutRenderScene()
	g := ed.NativeTextGeometry()
	if len(g.Cells) == 0 || len(g.Carets) == 0 || count == 0 {
		t.Fatal("render geometry missing")
	}
	if g.Viewport.Min.X <= float32(ed.renderBBox().Min.X) {
		t.Fatal("gutter included")
	}
	rs := []rune(ed.EditingState().Text)
	bounds := textpos.GraphemeBounds(rs)
	for _, c := range g.Cells {
		if !containsBoundary(bounds, c.Range.Start) || !containsBoundary(bounds, c.Range.End) {
			t.Fatal("interior grapheme cell", c)
		}
	}
	seenCarets := map[[2]int]bool{}
	for _, c := range g.Carets {
		k := [2]int{c.Rune, c.Line}
		if seenCarets[k] {
			t.Fatal("duplicate native strong caret", k)
		}
		seenCarets[k] = true
	}
	// A tab spans the entire whitespace advance rather than one glyph slot.
	tab := 14 // locate by source rather than assumptions about UTF-8 byte width
	for i, r := range rs {
		if r == '\t' {
			tab = i
			break
		}
	}
	found := false
	for _, c := range g.Cells {
		if c.Range.Start == tab {
			found = true
			if c.Rect.Size().X <= ed.charSize.X {
				t.Fatal("tab advance lost", c)
			}
		}
	}
	if !found {
		t.Fatal("tab fixture not visible")
	}
	originalX := g.Cells[0].Rect.Min.X
	g.Cells[0].Rect.Min.X += 100
	if ed.NativeTextGeometry().Cells[0].Rect.Min.X != originalX {
		t.Fatal("snapshot aliases mutable layout")
	}
	ed.scrollPos = 1.5
	ed.isScrolling = true
	ed.NeedsRender()
	b.Scene.LayoutRenderScene()
	g = ed.NativeTextGeometry()
	if len(g.Cells) == 0 || g.Cells[0].Line == 0 {
		t.Fatal("scroll did not refresh visible cells")
	}
	// Layout records painter actions; explicitly execute them before inspecting
	// pixels. Renderer.Image alone returns an untouched target.
	b.Scene.Renderer.Render(b.Scene.Painter.RenderDone())
	if dir := os.Getenv("VELLUM_EDITOR_EVIDENCE"); dir != "" {
		f, err := os.Create(dir + "/editor-scroll.png")
		if err != nil {
			t.Fatal(err)
		}
		err = png.Encode(f, b.Scene.Renderer.Image())
		f.Close()
		if err != nil {
			t.Fatal(err)
		}
	}
	ls.SetString("changed\n")
	if len(ed.NativeTextGeometry().Cells) != 0 {
		t.Fatal("stale geometry published")
	}
}
func containsBoundary(bounds []int, r int) bool {
	for _, b := range bounds {
		if b == r {
			return true
		}
	}
	return false
}

func TestVellumEditorNativeCancelRestoresFlagsAndSharedOwnership(t *testing.T) {
	ed := nativeEditor("A\n")
	defer ed.Lines.Close()
	ed.Lines.ClearNotSaved()
	ed.ApplyNativeEdit("Aに\n", 2, 2, 1, 2, "mark")
	if !ed.Lines.IsNotSaved() {
		t.Fatal("preedit not tracked")
	}
	if !ed.ApplyNativeEdit("A\n", 1, 1, -1, -1, "cancel") || ed.Lines.IsNotSaved() || ed.Lines.IsChanged() {
		t.Fatal("cancel dirtied clean buffer")
	}
	ed.ApplyNativeEdit("Aに\n", 2, 2, 1, 2, "mark")
	other := NewEditor()
	original := other.Lines
	other.SetLines(ed.Lines)
	original.Close()
	if other.ApplyNativeEdit("bad", 0, 0, -1, -1, "insert") {
		t.Fatal("second view stole composition")
	}
	ed.Lines.SetReadOnly(true)
	if ed.NativeEditingEnabled() {
		t.Fatal("readonly native client remains enabled")
	}
	if _, _, active := ed.NativeCompositionRange(); active {
		t.Fatal("readonly did not seal composition")
	}
	ed.Lines.SetReadOnly(false)
	if len(ed.Lines.Undo()) == 0 || ed.Lines.String() != "A\n" {
		t.Fatal("readonly transition lost undo")
	}
}

func TestVellumEditorNativeMetadataRevisionCache(t *testing.T) {
	ed := nativeEditor(strings.Repeat("abc é 👩‍💻\n", 1000))
	defer ed.Lines.Close()
	ed.EditingState()
	ptr := &ed.nativeRunes[0]
	revision := ed.nativeRevision
	for range 20 {
		ed.EditingState()
		ed.NativeCaretBounds()
		ed.NativeTextGeometry()
	}
	if ptr != &ed.nativeRunes[0] || revision != ed.nativeRevision {
		t.Fatal("unchanged document metadata rebuilt")
	}
	ed.Lines.InsertText(textpos.Pos{}, []rune("X"))
	state := ed.EditingState()
	if ed.nativeRevision == revision || !strings.HasPrefix(state.Text, "Xabc") {
		t.Fatal("cache missed buffer edit")
	}
}
func BenchmarkVellumEditorNativeCachedSnapshot(b *testing.B) {
	ed := nativeEditor(strings.Repeat("abc é 👩‍💻\n", 10000))
	defer ed.Lines.Close()
	ed.EditingState()
	b.ReportAllocs()
	b.ResetTimer()
	for range b.N {
		ed.EditingState()
	}
}

func TestVellumEditorNativeNoNetChangeRestoresFlags(t *testing.T) {
	for _, implicit := range []bool{false, true} {
		ed := nativeEditor("A\n")
		ed.Lines.ClearNotSaved()
		ed.ApplyNativeEdit("Aに\n", 2, 2, 1, 2, "mark")
		ed.ApplyNativeEdit("A\n", 1, 1, 1, 1, "mark")
		if implicit {
			ed.Lines.SetReadOnly(true)
		} else {
			ed.ApplyNativeEdit("A\n", 1, 1, -1, -1, "insert")
		}
		if ed.Lines.IsNotSaved() || ed.Lines.IsChanged() || len(ed.Lines.Undo()) != 0 {
			t.Fatal("no-net commit dirtied document", implicit)
		}
		ed.Lines.Close()
	}
}
