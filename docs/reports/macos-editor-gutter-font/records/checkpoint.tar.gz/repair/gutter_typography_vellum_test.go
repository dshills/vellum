// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
//go:build offscreen

package textcore

import (
	"context"
	"crypto/sha256"
	"errors"
	"image"
	"io/fs"
	"testing"
	"time"

	"cogentcore.org/core/core"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/lines"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
)

// Exercise the actual Manual style/layout/body/tab/gutter render caches under
// retained typography changes. Original frozen workspace images cover the
// historical gutter pixels independently of these structural assertions.
func TestVellumEditorBodyGutterTypography(t *testing.T) {
	for _, dpi := range []float32{160, 162} {
		t.Run(fmtDPI(dpi), func(t *testing.T) {
			clock := &ownedFixtureClock{now: time.Unix(1730000000, 0).UTC()}
			body := core.NewBody("editor body and gutter")
			ed := NewEditor(body)
			old := ed.Lines
			ed.SetLines(lines.NewLinesExact().SetString("\tiWiW Ω\nnext\n"))
			old.Close()
			size := float32(18)
			ed.Styler(func(s *styles.Style) {
				s.Font.Family = rich.Custom
				s.Font.CustomFont = "Noto Sans"
				s.Font.Size = units.Dp(size)
				s.Font.Weight = rich.Semibold
				s.Font.Slant = rich.Italic
			})
			m, err := body.NewWindow().RunManual(context.Background(), core.ManualWindowConfig{Size: image.Pt(640, 320), LogicalDPI: dpi, EventCapacity: 64, Now: func() time.Time { return clock.now }, AfterFunc: clock.After, NewShaper: func() (shaped.Shaper, error) { return shapedgt.NewShaperWithFonts([]fs.FS{fonts.Default}), nil }})
			if err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() {
				if err := m.Close(context.Background()); err != nil && !errors.Is(err, core.ErrManualCallback) && !errors.Is(err, lines.ErrManualViews) {
					t.Error(err)
				}
			})
			ownedDrain(t, m)
			if !ed.SetEditingSelection(3, 7) {
				t.Fatal("selection")
			}
			ed.NeedsRender()
			ownedDrain(t, m)
			accepted := ed.EditingState()
			var initial [32]byte
			var previousTab *shaped.Lines
			for i, wantSize := range []float32{18, 22, 18} {
				size = wantSize
				ed.Update()
				ownedDrain(t, m)
				ui := ed.Styles.Font
				document := ed.Lines.FontStyle()
				if ui.Family != rich.Custom || ui.CustomFont != "Noto Sans" || ui.Size.Value != wantSize || ui.Weight != rich.Semibold || ui.Slant != rich.Italic {
					t.Fatal("gutter lost UI typography", ui)
				}
				if document.Family != rich.Monospace || document.Weight != rich.Semibold || document.Slant != rich.Italic {
					t.Fatal("body inherited proportional UI family", document)
				}
				if ed.tabRender == nil || len(ed.tabRender.Source) == 0 || len(ed.lineNoRenders) == 0 || ed.lineNoRenders[0].lns == nil {
					t.Fatal("body tab or gutter was not actually rendered")
				}
				tab, _ := ed.tabRender.Source.Span(0)
				gutter, _ := ed.lineNoRenders[0].lns.Source.Span(0)
				if tab == nil || tab.Family != rich.Monospace || gutter == nil || gutter.Family != rich.Custom {
					t.Fatal("body/gutter shaping families", tab, gutter)
				}
				if i > 0 && ed.tabRender == previousTab {
					t.Fatal("font transition reused stale tab shape")
				}
				previousTab = ed.tabRender
				state := ed.EditingState()
				if state.Text != accepted.Text || state.Anchor != accepted.Anchor || state.Focus != accepted.Focus {
					t.Fatal("style changed accepted edit/selection", state, accepted)
				}
				pixels, err := m.Image(context.Background())
				if err != nil {
					t.Fatal(err)
				}
				digest := sha256.Sum256(pixels.Pix)
				if i == 0 {
					initial = digest
				}
				if i == 1 && digest == initial {
					t.Fatal("font size did not change completed pixels")
				}
				if i == 2 && digest != initial {
					t.Fatal("restored typography did not restore completed pixels")
				}
			}
		})
	}
}
func fmtDPI(v float32) string {
	if v == 160 {
		return "160dpi"
	}
	return "162dpi"
}
