package textcore

import (
	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/styles"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/lines"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/textpos"
	"image"
	"os"
	"strings"
	"testing"
)

func visualEditor(t *testing.T, text string, width float32) (*core.Body, *Editor) {
	t.Helper()
	b := core.NewBody()
	b.Scene.AddChild(b)
	ed := NewEditor(b)
	old := ed.Lines
	ls := lines.NewLinesExact().SetString(text)
	ls.Autosave = false
	ed.SetLines(ls)
	old.Close()
	t.Cleanup(ls.Close)
	ed.Styler(func(s *styles.Style) { s.Min.X.Em(width); s.Max.X.Em(width); s.Min.Y.Em(6); s.Max.Y.Em(6) })
	configureEditorSceneShaper(b)
	if cache := os.Getenv("VELLUM_FONT_CACHE"); cache != "" {
		pre := shapedgt.NewShaperWithFonts(fonts.Embedded).(*shapedgt.Shaper)
		if err := pre.FontMap().UseSystemFonts(cache); err != nil {
			t.Fatal(err)
		}
		if err := b.Scene.MakeTextShaper().(*shapedgt.Shaper).FontMap().UseSystemFonts(cache); err != nil {
			t.Fatal(err)
		}
	}
	b.Scene.Resize(math32.Geom2DInt{Size: image.Pt(400, 180)})
	b.Scene.LayoutRenderScene()
	return b, ed
}
func TestVellumEditorVisualArrowPointerSelection(t *testing.T) {
	_, ed := visualEditor(t, "abc אבג xyz\né 👩‍💻\n", 30)
	ed.SetEditingSelection(0, 0)
	for _, want := range []int{1, 2, 3, 4, 6, 5, 7} {
		ed.HandleEvent(events.NewKey(events.KeyChord, 0, key.CodeRightArrow, 0))
		if got := ed.EditingState().Cursor; got != want {
			t.Fatalf("right got %d want %d", got, want)
		}
		c, ok := ed.cachedVisualCaret(ed.CursorPos)
		if !ok || ed.charStartPos(ed.CursorPos) != c.Pos {
			t.Fatal("raster cursor differs from strong caret")
		}
	}
	for _, want := range []int{5, 6, 4, 3, 2, 1, 0} {
		ed.HandleEvent(events.NewKey(events.KeyChord, 0, key.CodeLeftArrow, 0))
		if got := ed.EditingState().Cursor; got != want {
			t.Fatalf("left got %d want %d", got, want)
		}
	}
	ed.SetEditingSelection(4, 4)
	ed.HandleEvent(events.NewKey(events.KeyChord, 0, key.CodeRightArrow, 1<<key.Shift))
	state := ed.EditingState()
	if state.Anchor != 4 || state.Focus != 6 {
		t.Fatal("logical selection lost", state)
	}
	for _, c := range ed.editorInteraction().Carets {
		if c.Line != 0 {
			continue
		}
		pt := c.Pos.Add(math32.Vec2(0, c.Height/2)).ToPointFloor().Sub(ed.Geom.ContentBBox.Min)
		got := ed.PixelToCursor(pt)
		// Integer pointer positions need only select the nearest shaped stop.
		if ed.nativeOffset(got) != c.Rune {
			t.Fatalf("pointer got %v want rune %d at %v", got, c.Rune, c.Pos)
		}
	}
}
func TestVellumEditorVisualWrapScrollQueuedEdit(t *testing.T) {
	b, ed := visualEditor(t, "abc אבג xyz more words wrapping here\nsecond\nthird\nfourth\nfifth\nsixth\n", 12)
	g := ed.editorInteraction()
	var boundary int
	found := false
	for _, a := range g.Carets {
		for _, c := range g.Carets {
			if a.Rune == c.Rune && a.Line+1 == c.Line {
				boundary = a.Rune
				found = true
				break
			}
		}
	}
	if !found {
		t.Fatal("no wrapped shared boundary")
	}
	ed.SetEditingSelection(boundary, boundary)
	// Choose upstream affinity, move right over the wrap, then reverse.
	for _, c := range g.Carets {
		if c.Rune == boundary {
			ed.rememberVisualCaret(c)
			break
		}
	}
	original := ed.visualState.line
	ed.cursorForward(1)
	if ed.EditingState().Cursor != boundary || ed.visualState.line != original+1 {
		t.Fatal("right did not cross to downstream wrap affinity")
	}
	ed.cursorBackward(1)
	if ed.EditingState().Cursor != boundary || ed.visualState.line != original {
		t.Fatal("wrap affinity did not reverse")
	}
	ed.Lines.SetString("new é 👩‍💻\nnext\n")
	ed.SetEditingSelection(0, 0)
	ed.cursorDown(1)
	if ed.CursorPos.Line != 1 {
		t.Fatal("vertical movement used stale text layout", ed.CursorPos)
	}
	ed.scrollPos = 0.5
	ed.isScrolling = true
	ed.NeedsRender()
	b.Scene.LayoutRenderScene()
	c := ed.editorInteraction().Carets[0]
	// Add scene/window translation and exercise the real relative-pointer path.
	b.Scene.SceneGeom.Pos = image.Pt(13, 19)
	ed.NeedsRender()
	b.Scene.LayoutRenderScene()
	c = ed.editorInteraction().Carets[0]
	ed.rememberVisualCaret(c)
	if ed.charStartPos(ed.nativePos(c.Rune)) != c.Pos.Sub(math32.FromPoint(b.Scene.SceneGeom.Pos)) {
		t.Fatal("raster cursor includes scene translation")
	}
	scenePoint := c.Pos.Sub(math32.FromPoint(b.Scene.SceneGeom.Pos)).Add(math32.Vec2(0, c.Height/2)).ToPointFloor()
	if got := ed.PixelToCursor(ed.PointToRelPos(scenePoint)); ed.nativeOffset(got) != c.Rune {
		t.Fatal("translated/scrolled pointer mismatch", got, c)
	}
}
func TestVellumEditorVisualDocumentEdges(t *testing.T) {
	_, ed := visualEditor(t, "אבג", 20)
	ed.SetEditingSelection(0, 0)
	ed.cursorForward(1)
	if ed.CursorPos != (textpos.Pos{}) {
		t.Fatal("right at RTL document start moved logically", ed.CursorPos)
	}
	ed.cursorBackward(1)
	if ed.CursorPos.Char != 1 {
		t.Fatal("left did not follow RTL visual carets", ed.CursorPos)
	}
}

func TestVellumEditorVisualPreferredColumn(t *testing.T) {
	_, ed := visualEditor(t, "abcdefghij\nx\nabcdefghij\n", 30)
	ed.SetEditingSelection(8, 8)
	ed.cursorDown(1)
	if ed.CursorPos.Char != 1 {
		t.Fatal("short line endpoint", ed.CursorPos)
	}
	ed.cursorDown(1)
	if ed.CursorPos.Char != 8 {
		t.Fatal("preferred visual X lost", ed.CursorPos)
	}
	ed.cursorUp(1)
	ed.cursorUp(1)
	if ed.CursorPos != (textpos.Pos{Line: 0, Char: 8}) {
		t.Fatal("preferred X did not reverse", ed.CursorPos)
	}
	ed.SetEditingSelection(2, 2)
	ed.cursorDown(1)
	ed.cursorDown(1)
	if ed.CursorPos.Char != 2 {
		t.Fatal("explicit selection did not reset preferred X", ed.CursorPos)
	}
}

func TestVellumEditorVisualBeyondViewport(t *testing.T) {
	b, ed := visualEditor(t, strings.Repeat("abc אבג xyz\n", 30), 30)
	ed.SetEditingSelection(6, 6)
	x := ed.charStartPos(ed.CursorPos).X
	for i := 1; i <= 20; i++ {
		ed.cursorDown(1)
		b.Scene.LayoutRenderScene()
		if ed.CursorPos.Line != i || math32.Abs(ed.charStartPos(ed.CursorPos).X-x) > 1 {
			t.Fatal("visual column lost across viewport", i, ed.CursorPos, "x", x, "got", ed.charStartPos(ed.CursorPos).X, "preferred", ed.visualState.preferredX, "scroll", ed.scrollPos, "affinity", ed.visualState.line, ed.visualState.offset)
		}
	}
}
func TestVellumEditorVisualReflowAffinity(t *testing.T) {
	b, ed := visualEditor(t, "many words that wrap across multiple narrow lines here", 12)
	g := ed.editorInteraction()
	c := g.Carets[len(g.Carets)-1]
	ed.SetEditingSelection(c.Rune, c.Rune)
	ed.rememberVisualCaret(c)
	ed.Styler(func(s *styles.Style) { s.Min.X.Em(40); s.Max.X.Em(40) })
	ed.Update()
	b.Scene.Resize(math32.Geom2DInt{Size: image.Pt(700, 180)})
	b.Scene.LayoutRenderScene()
	state := ed.EditingState()
	if _, ok := ed.editorInteraction().At(c.Rune, state.VisualLine); !ok {
		t.Fatal("obsolete wrapped affinity", state.VisualLine)
	}
}

func TestVellumEditorVisualWrappedIsolation(t *testing.T) {
	_, ed := visualEditor(t, "\u2067אבג\u2069abc many words wrapping here", 12)
	if ed.visualParagraphRTL(textpos.Pos{}) {
		t.Fatal("isolated RTL text changed LTR paragraph direction")
	}
	g := ed.editorInteraction()
	for _, a := range g.Carets {
		for _, b := range g.Carets {
			if a.Rune == b.Rune && a.Line+1 == b.Line {
				ed.SetEditingSelection(a.Rune, a.Rune)
				ed.rememberVisualCaret(a)
				ed.cursorForward(1)
				if ed.EditingState().Cursor != a.Rune || ed.visualState.line != b.Line {
					t.Fatal("wrong cross-line direction after isolate")
				}
				return
			}
		}
	}
	t.Fatal("missing wrapped boundary")
}
