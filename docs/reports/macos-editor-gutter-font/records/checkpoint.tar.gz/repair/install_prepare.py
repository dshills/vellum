"""Run actual candidate stage87 preparation; preserve canonical stage86 and SDK."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
s=importlib.util.spec_from_file_location('actual_preparation_guard',G.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
read=lambda p:json.loads(Path(p).read_bytes())
def vector(root):
 d={}
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():d[p.relative_to(root).as_posix()]=h.sha(p)
 return d
def prepared(root):return{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
b=read(G/'boundary.json');p=read(G/'promotion.json');assert not(G/'adopted-prepare.json').exists()and {n:h.sha(T/n)for n in p['files']}==p['files']
expected=dict(b['prepared']);expected.update({'upstream/'+n:v for n,v in read(G/'stage87-patch.json')['outputs'].items()})
assert prepared(T)==expected and prepared(C)==b['prepared']and vector(SDK)==b['sdk']and {n:h.sha(C/n)for n in b['source']}==b['source']
names=run_child(['git','ls-files','-z'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode().split('\0')[:-1]
pins={str(T/n):h.sha(T/n)for n in names};pins.update({str(q):h.sha(q)for q in [Path(__file__),G/'boundary.json',G/'promotion.json',G/'stage87-patch.json',Path(h.__file__),h.GUARD,h.GO]})
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOTOOLCHAIN':'local','GOWORK':'off','GOENV':'off','GOFLAGS':'-mod=readonly','GOPROXY':'off','GOSUMDB':'off','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(q))+'))'for q in [C,SDK])
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/opt/homebrew/bin/python3','-B',str(T/'drivers/cogent/prepare.py')],T/'drivers/cogent',G/'adopted-prepare',lambda:False,lambda:all(h.sha(q)==v for q,v in pins.items()),timeout=300,limit=8<<20)
r['prepared_exact']=prepared(T)==expected;r['prepared_files']=len(expected);r['canonical_source_prepared_unchanged']={n:h.sha(C/n)for n in b['source']}==b['source']and prepared(C)==b['prepared'];r['sdk_unchanged']=vector(SDK)==b['sdk'];r['source_pins']=pins;r['native_executed']=False
(G/'adopted-prepare.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned','prepared_exact','prepared_files','canonical_source_prepared_unchanged','sdk_unchanged']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']and r['prepared_exact']and r['canonical_source_prepared_unchanged']and r['sdk_unchanged']else 1)
