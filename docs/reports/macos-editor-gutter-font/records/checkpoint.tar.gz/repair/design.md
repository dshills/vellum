# Preserve editor body invariants and UI gutter typography

Current5e30a6c workspace software refresh fails twelve original frozen image
comparisons. Private old-font counterfactual restores all27 goldens10k/batch1;
exact PNG comparison isolates218 changed pixels to two line-number gutter glyphs.
Accepted a328208 whole-widget monospace override accidentally changes themed
chrome. Do not revert body monospace or regenerate records/goldens.

Normalize fresh rich styles at the textcore body boundary, used by styleSizes
before Lines.SetFontStyle/character sizing and by renderLine body/tab shaping.
Set body family Monospace and clear copied custom family, preserving all other
typography and leaving widget UI style and gutter renderLineNumber unchanged.
Full layout invalidates cached tab shape along with line/gutter shapes so retained
font/size/wrap changes cannot keep old tab metrics. Existing one-view/manual/native
ownership and document/history/selection lifecycle are unchanged. No new public API.

Remove the blanket adapter family override only together with the body patch.
Revise retained-widget typography regression to require themed gutter identity,
monospace Lines style and preserved size/weight/slant across changes/restoration.
Add actual Manual textcore render/cache/geometry coverage, not only helper mirrors.
Run original frozen workspace records unmodified, full driver/gallery race,
affected textcore regressions/vet/native build and deterministic stage87 preparation.
Review internally, then one Anthropic Claude Sonnet5.5 Prism checkpoint; commit
reviewed exact source/spec/evidence only. No SDK refresh or old native-scope replay.
Native text acceptance remains open after sealed E visibilityfalse/occluded yield.
Performance/endurance/native/human/release/Mac-complete claims remain separate.
