"""Promote exactly reviewed body/gutter source and docs; SDK remains immutable."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=60,capture_output=True,check=True).stdout
def vector(root):
 d={}
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():d[p.relative_to(root).as_posix()]=sha(p)
 return d
def prepared(root):return{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
def passed(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
b=read(G/'boundary.json'); review=read(G/'internal-product-review.json')
assert not(G/'promotion.json').exists()
assert review['approved'] and review['source_ready'] and not review['unresolved_findings'] and all(sha(k)==v for k,v in review['inputs'].items())
assert git(C,'rev-parse','HEAD').decode().strip()==b['head'] and not git(C,'status','--porcelain')
assert {n:sha(C/n) for n in b['source']}==b['source'] and prepared(C)==b['prepared'] and vector(SDK)==b['sdk']
assert git(T,'rev-parse','HEAD').decode().strip()==b['head'] and set(git(T,'diff','--name-only').decode().splitlines()) <= {'docs/reports/macos-editor-gutter-font/README.md'} and not git(T,'ls-files','--others','--exclude-standard')
mapping={p.relative_to(G/'payload').as_posix():p for p in (G/'payload').rglob('*') if p.is_file()}
mapping.update({'drivers/cogent/style.go':G/'style.go','drivers/cogent/style_test.go':G/'style_test.go'})
assert len(mapping)==13 and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(mapping)
assert all(sha(T/n)==sha(p) for n,p in mapping.items())
report='docs/reports/macos-editor-gutter-font/README.md'
old=(G/'report-before-whitespace-cleanup.md').read_bytes();new=(G/'payload'/report).read_bytes()
assert old.replace(b'identical. \n',b'identical.\n')==new and (T/report).read_bytes()==new
git(T,'add','--',report);git(T,'diff','--cached','--check')
expected=dict(b['prepared']);expected.update({'upstream/'+n:v for n,v in read(G/'stage87-patch.json')['outputs'].items()})
assert prepared(T)==expected
diff=git(T,'diff','--cached','--binary');(G/'promotion-staged.diff').write_bytes(diff)
out={'base':b['head'],'files':{n:sha(T/n)for n in sorted(mapping)},'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'bytes':len(diff),'prepared_files':len(expected),'prepared_sha256':hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'prepared_canonical_retains_stage86_until_commit':True,'sdk_unchanged':True,'native_executed':False,'provider_calls':0,'closed_full_mac_gates':[],'recovery':'Original promotion stopped on one trailing report space after exact source promotion/staging. This continuation verifies the exact partial state and changes only that space. Premature install_prepare attempt refused missing promotion.json before child creation.'}
(G/'promotion.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
