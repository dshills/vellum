"""Run deterministic preparation regression tests against the private stage87 payload."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;R=G/'preparation';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
s=importlib.util.spec_from_file_location('preparation_test_guard',G.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
read=lambda p:json.loads(Path(p).read_bytes())
p=read(G/'prepare-v1.json');assert p['exit_code']==0 and p['prepared_exact']and p['owned']['group_absent']and not(G/'prepare-tests-v1').exists()
file=R/'prepare_test.py';assert not file.exists();file.write_bytes((G/'payload/drivers/cogent/prepare_test.py').read_bytes())
pins=dict(p['source_pins']);pins.update({str(q):h.sha(q)for q in [Path(__file__),file,G/'payload/drivers/cogent/prepare_test.py',G/'prepare-v1.json']})
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOTOOLCHAIN':'local','GOWORK':'off','GOENV':'off','GOPROXY':'off','GOSUMDB':'off','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(q))+'))'for q in [C,T,SDK])
r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/opt/homebrew/bin/python3','-B','-m','unittest','-v','prepare_test'],R,G/'prepare-tests-v1',lambda:False,lambda:all(h.sha(q)==v for q,v in pins.items()),timeout=120,limit=4<<20)
v={m+'/'+q.relative_to(R/'build'/m).as_posix():h.sha(q)for m in ['upstream','typesetting']for q in(R/'build'/m).rglob('*')if q.is_file()}
r['source_pins']=pins;r['prepared_unchanged']=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()==p['prepared_sha256'];r['native_executed']=False
(G/'prepare-tests-v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned','prepared_unchanged']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']and r['prepared_unchanged']else 1)
