# Native text/modal acceptance after disabled publication repair

Run only the original full text/modal 68-input/33-state record on the clean
committed disabled editor publication fix. The prior S structural50/42 record
passed completely and is retained, not rerun here. S text failed at editor-disabled
with35 inputs/19 source-asserted states; its final Frame hit the deadline and
952 earlier Frames completed. S and every older scope stay immutable/sealed.

The product repair and six-case actual-publication regressions have internal
reviews, full driver-root/gallery race, vet/build and actual-source focused
checks, plus one complete Anthropic Claude Sonnet5.5 Prism call. Raw CLI1 retained
one hypothesized flag-side-effect concern. Independent review refuted it against
the exact compiled atomic flag implementation and existing eight-publication
quiet assertions, including composition mark/unmark. No repeated provider call.

Copy all three S private Go-only consumer overlays byte-for-byte so the build and
correlation instrumentation are unchanged; dispatch only -text-native-check.
The fixed1024 Visibility/request/outcome log is diagnostic, not readiness gating.
Use unchanged independent authored text oracle plus unchanged correlation oracle.
No input/model/focus/geometry/history/refusal expectation, acquisition retry,
settle loop, timeout, or disabled phase is weakened. Actual Frame unavailable
is terminal. A refused startup Visibility followed by Frame success conservatively
fails instrumentation; keep and seal it without inferring a product defect.

Qualify reuse of the full root race by exact735 effective compiler inputs and
byte-identical promotion of the two reviewed Go files. Recheck current gallery
race, vet and native build against actual T Objective-C, external pinned manifest,
Go1.25.6/GOMAXPROCS2, prepared stage86 and SDK786a. Existing synthetic oracle
controls remain required and are explicitly not native evidence.

After exact source/controller review, prepare a fresh immutable plan and obtain
separate admission. Hold shared LiveLease, one owned child,120-second watchdog,
4MiB streams and30-minute launch deadline rechecked immediately before launch.
Whole clean C/T tracked source, prepared dependencies, SDK, compiler and binary
boundaries must hold before/after. Always retire owned group and permanently
seal the one case/campaign on completion or failure. No OS-input operator,
input source, VoiceOver, clipboard or preference changes. No native product or
SDK/prepared mutation. Native Go FIFO routing does not prove physical pointer,
OS IME, human VoiceOver, pixels/presentation, resource/endurance or full Mac.
A passing record proceeds to M2 requirement audit, never automatic Mac closure.
