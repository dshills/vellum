from pathlib import Path
r=Path('/private/tmp/vellum-workspace-replay')
p=r/'examples/replay/workspace/backend_offscreen.go'
s=p.read_text().replace('if b.Fixture.Owner.Context().Err() != nil {\n\t\treturn app.ErrClosed\n\t}\n\tnative, err :=', 'if b.Fixture.Owner.Context().Err() != nil {\n\t\treturn app.ErrClosed\n\t}\n\t// Later segments bind the same immutable identity, while their live-window\n\t// set may legitimately reflect recorded closure. Each input checks liveness.\n\tif b.bound {\n\t\treturn nil\n\t}\n\tnative, err :=',1)
p.write_text(s)
p=r/'examples/replay/workspace/author_offscreen_test.go'
s=p.read_text().replace('p.checkpoints = append(p.checkpoints, result.Checkpoints...)','for i := range result.Checkpoints {\n\t\tresult.Checkpoints[i].Sequence = o.Sequence\n\t}\n\tp.checkpoints = append(p.checkpoints, result.Checkpoints...)')
s=s.replace('\tg = p.grid()\n\tg = p.grid()','\tg = p.grid()')
p.write_text(s)
