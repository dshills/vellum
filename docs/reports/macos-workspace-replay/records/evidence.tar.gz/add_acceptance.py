from pathlib import Path
import json, shutil
r=Path('/private/tmp/vellum-workspace-replay'); p=Path('/private/tmp/vellum-macos-workspace-replay')
for n in [10000,1000000]:
 shutil.copyfile(p/f'records-v3/{n}.json',r/f'examples/replay/workspace/records/{n}.json')
 # Keep the frozen completed observations, compacted without regenerating their contents.
 data=json.loads((p/f'records-v3/{n}.expected.json').read_text())
 (r/f'examples/replay/workspace/records/{n}.golden.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n')
(r/'examples/replay/workspace/records/bootstrap.json').unlink()
f=r/'examples/replay/workspace/model.go';s=f.read_text().replace('defer func() {\n\t\t\tf.gridRequest = virtual.GridProjectionRequest{}\n\t\t\tf.treeRequest = virtual.OutlineRequest{}\n\t\t}()', 'defer f.retireRequests()')
# gofmt currently used one-line body; accept either spelling.
s=s.replace('defer func() { f.gridRequest = virtual.GridProjectionRequest{}; f.treeRequest = virtual.OutlineRequest{} }()', 'defer f.retireRequests()')
a=s.index('\tif f.job == "query" {', s.index('func (f *Fixture) cancel()'));b=s.index('\tf.status = "Cancellation requested"',a)
s=s[:a]+'\tf.retireRequests()\n'+s[b:]
pos=s.index('\nfunc (f *Fixture) place(')
s=s[:pos]+'''
// There is one admitted task until its owner callback has returned. Retire its
// exact capability even on parent cancellation, worker failure or finish refusal.
func (f *Fixture) retireRequests() {
 _ = f.Grid.CancelProjection(f.gridRequest)
 _ = f.Tree.Cancel(f.treeRequest)
 f.gridRequest = virtual.GridProjectionRequest{}
 f.treeRequest = virtual.OutlineRequest{}
}
'''+s[pos:];f.write_text(s)
f=r/'examples/replay/workspace/backend_offscreen.go';s=f.read_text().replace('\tif !b.Executor.Snapshot().Idle() {','\tif b.Fixture.task != nil {\n\t\tselect { case <-b.Fixture.task.Done(): case <-ctx.Done(): return errors.Join(cleanupErr, ctx.Err()) }\n\t}\n\tif !b.Executor.Snapshot().Idle() {',1);f.write_text(s)
