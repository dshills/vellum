from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-workspace-replay');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((P/'checkpoint-source.json').read_text());sources=s['sources'];assert all(sha(R/n)==h for n,h in sources.items())
checks={};prepared=None
for name in ['root-race-v1','root-vet-v1','example-native-v1','example-vet-v1','adapter-race','adapter-vet','workspace-build','final-example-race','sdk-archive','sdk-relocation-v2']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_delta_stable'] and d['prepared_before']==d['prepared_after'] and d['overlay_inputs_before']==d['overlay_inputs_after']
 assert not d['live_tests'] and not d['headless_gpu_requested']
 if prepared is None:prepared=d['prepared_after']
 assert prepared==d['prepared_after'] and len(prepared)==6223
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'current_sources_matched':[n for n,h in sources.items()if d['source_delta_after'].get(n)==h]}
source_check=json.loads((P/'final-example-race.json').read_text());assert source_check['source_delta_after']==sources
fault=json.loads((P/'fault-control.json').read_text());assert fault['exit_code']==1 and fault['error']is None and fault['source_delta_stable'] and fault['overlay_inputs_before']==fault['overlay_inputs_after']
assert 'parent cancellation left grid request live' in (P/'fault-control.stdout').read_text() and 'parent cancellation left tree request live' in (P/'fault-control.stdout').read_text()
relocated=json.loads((P/'relocated-workspace.json').read_text());assert relocated['result']=='PASS_RELOCATED_WORKSPACE_CONSUMER' and relocated['source_stable'] and relocated['sources']==sources and all(c['exit_code']==0 for c in relocated['checks'])
logs=(P/'final-example-race.stdout').read_text();assert '--- PASS: TestReviewerBusyDriverClosePreservesBorrowedResourcesForRetry' in logs
for rows in [10000,1000000]:
 for batch in [1,7,64]:assert f'rows={rows} batch={batch} operations=216 checkpoints=27' in logs
native=P/'vellum-workspace';archive=P/'vellum-sdk.tar.gz';assert sha(archive)==relocated['archive_sha256']
out={'result':'PASS_SCOPED_WORKSPACE_SOFTWARE_CHECKS','base_commit':s['base_commit'],'sources':sources,'checks':checks,'prepared_files':6223,'prepared_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'native_binary_sha256':sha(native),'sdk_archive_sha256':sha(archive),'relocated_workspace_receipt_sha256':sha(P/'relocated-workspace.json'),'negative_control_receipt_sha256':sha(P/'fault-control.json'),'negative_control':'Removing terminal request cleanup fails both parent-cancellation subcases; production guards pass.','source_review_sha256':sha(P/'workspace-source-review-v1.json'),'records':{'rows':[10000,1000000],'columns':20,'stored_tree_nodes':100000,'operations_per_record':216,'captures_per_record':27,'batches':[1,7,64],'completed_checkpoint_comparisons':162},'native_binary_executed':False,'physical_pointer_qualified':False,'gpu_qualified':False,'full_mac_qualified':False,'full_P9_qualified':False,'full_P11_qualified':False,'performance_qualified':False,'public_distribution_qualified':False,'excluded_attempts':{'author-v1':'Authoring segmentation incorrectly rechecked initial live window count after recorded main-window closure.','author-v2':'Completed authoring but the proposed table cell could be clipped; revised to assert a fully visible cell and real selection.','fault-v1':'Incorrect fixture expectation: eligible bootstrap paints are legitimately drained at the current instant.','sdk-relocation':'Incorrect hash argument; refused before extraction/execution. Correct digest used in sdk-relocation-v2.'}}
(P/'summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['sources','checks']}))
