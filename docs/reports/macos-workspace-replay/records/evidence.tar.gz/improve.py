from pathlib import Path
r=Path('/private/tmp/vellum-workspace-replay')
p=r/'examples/replay/workspace/author_offscreen_test.go';s=p.read_text()
a=s.index('\tcell := g.Cells[0]');b=s.index('\tp.point(cell.Bounds',a)
s=s[:a]+'''\tvar cell cogent.GridCellInspection
\tfor _, c := range g.Cells {
\t\tif c.Column == 0 && !c.Bounds.Empty() && c.Bounds.In(g.Bounds) {
\t\t\tcell = c
\t\t\tbreak
\t\t}
\t}
\tif cell.Bounds.Empty() { t.Fatal("no fully visible frozen-column cell") }
'''+s[b:]
s=s.replace('p.scroll(center, 128, 480)','p.scroll(center, 128, -480)')
p.write_text(s)
p=r/'examples/replay/workspace/model.go';s=p.read_text()
s=s.replace('Title: strings.Title(id)', 'Title: map[string]string{"tree": "Outline", "canvas": "Canvas", "grid": "Table", "notes": "Notes", "properties": "Properties"}[id]')
s=s.replace('func(result jobResult, e error) {\n\t\tif f.canceled', 'func(result jobResult, e error) {\n\t\tdefer func() { f.gridRequest = virtual.GridProjectionRequest{}; f.treeRequest = virtual.OutlineRequest{} }()\n\t\tif f.canceled')
p.write_text(s)
p=r/'examples/replay/workspace/backend_offscreen.go';s=p.read_text().replace('\tvar driver *cogent.Manual','\tvar driver *cogent.Manual\n\tvar f *Fixture',1).replace('\t\tif !constructed {','\t\tif !constructed {\n\t\t\tif f != nil { f.Palette.Close() }',1).replace('\tf, err := New(a, ex, rows)','\tf, err = New(a, ex, rows)',1)
s=s.replace('func (b *Backend) Close(ctx context.Context) error {\n\tb.Fixture.Owner.Close()', 'func (b *Backend) Close(ctx context.Context) error {\n\tif ctx == nil { return replay.ErrInvalid }; if err := ctx.Err(); err != nil { return err }\n\tb.Fixture.Owner.Close()')
s=s.replace('\tcleanupErr = errors.Join(cleanupErr, b.Driver.Close(ctx))','\tif !b.Executor.Snapshot().Idle() { return errors.Join(cleanupErr, fmt.Errorf("workspace: accepted workers remain during closure")) }\n\tcleanupErr = errors.Join(cleanupErr, b.Driver.Close(ctx))')
p.write_text(s)
