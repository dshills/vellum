from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-workspace-replay');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
all_sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];review=json.loads((P/'checkpoint-review.json').read_text());summary=json.loads((P/'summary.json').read_text())
assert review['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not review['unresolved_findings'] and review['sources']==all_sources and summary['sources']==all_sources
assert summary['result']=='PASS_SCOPED_WORKSPACE_SOFTWARE_CHECKS' and not summary['native_binary_executed'] and not summary['full_mac_qualified']
assert all(sha(R/n)==h for n,h in all_sources.items())
provider_sources={n:h for n,h in all_sources.items() if not n.startswith('examples/replay/workspace/records/')}
assert len(provider_sources)==26 and len(all_sources)==30
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).decode().splitlines())==set(all_sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
diff=subprocess.check_output(['git','diff','--cached','--binary','--',*provider_sources],cwd=R)
out=P/'prism-v1';out.mkdir(exist_ok=False);(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':provider_sources,'all_checkpoint_sources':all_sources,'provider_excluded_record_files':{n:h for n,h in all_sources.items()if n not in provider_sources},'record_review_basis':'Internal reviewer read bound records/goldens; six unchanged-record software runs plus independent content/transition oracles and relocated examples qualified. Large JSON observations omitted from model transmission.','diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Integrated professional workspace public SDK consumer, actual stored 10k/million20field grid and100k tree, real worker sorting/filter/indexes, reserved completion/cancellation/exact request retirement, actual Workbench/grid/tree/editor/canvas routes, modal/history/independent window lifecycle. Version2 bounded wheel protocol keeps Version1 compatibility. Frozen216op27capture records across1/7/64, actual software goldens and independent assertions; targeted cancellation/refusal/newer-capability and busy-close tests, meaningful cleanup-removal negative control. Root/example/adapter race/vet, native compile only, private SDK integrity and relocated consumer replay/native compile. Internal source+evidence approved. No native launch, physical/GPU/display/performance/human/native-service or full Mac/P9/P11 qualification.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(provider_sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in all_sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary','--',*provider_sources],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':provider_sources,'all_checkpoint_sources':all_sources,'source_index_stable':after==all_sources and diff==afterdiff,'review_sha256':sha(P/'checkpoint-review.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
