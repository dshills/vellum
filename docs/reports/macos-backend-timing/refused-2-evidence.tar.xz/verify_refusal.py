from pathlib import Path
import json,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((p/'bound-plan.json').read_text());idx=json.loads((p/'source-snapshot-index.json').read_text())
for name,h in plan['pins'].items():assert sha(p/idx[name]['copy'] if name in idx else Path(name))==h
s=importlib.util.spec_from_file_location('sealed_backend_classifier',p/'source-snapshot/repo/tools/macos-calibration/backend/check.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
r=json.loads((p/'result.json').read_text());assert r['outcome']=='BLOCKED_BY_RETAINED_INVALID_CASE' and len(r['cases'])==2
count=0
for c in r['cases']:
 root=p/('pair1-'+c['kind']);doc=json.loads((root/'native/stdout').read_text());match=json.loads((p/'match.json').read_text())
 if c['kind']=='off':assert v.validate(doc,match,'off')==c['validation']
 else:
  try:v.validate(doc,match,'on');raise AssertionError('sealed refusal unexpectedly passed')
  except KeyError as e:assert e.args==((1,1),)
 assert c['geometry_before']==c['geometry_after']
 for key in c['configuration_before']:assert c['configuration_before'][key]['logs']['stdout']['sha256']==c['configuration_after'][key]['logs']['stdout']['sha256']
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((v,root/folder/k) for k,v in c[phase].items())
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['logs_complete'] and cmd['pins_stable']
  for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
  count+=1
assert count==18
print('PASS: sealed second attempt still rejected by original source;2native+16probe groups retired;all source snapshot/binary/library/log pins retained;no accepted pair')
