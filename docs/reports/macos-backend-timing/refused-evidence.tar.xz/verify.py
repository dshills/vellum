from pathlib import Path
import hashlib,json,subprocess,sys,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');b=t/'tools/macos-calibration/backend';root=Path('/private/tmp/vellum-backend-timing');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads((q/'build-identity.json').read_text())
assert sha(q/'framework')==d['framework_binary_SHA256'];assert sha(root/'libs-darwin/arm64/libwgpu_native.a')==d['archive_SHA256'];assert (root/'hal/src/metal/probe.rs').read_bytes()==(b/'probe.rs').read_bytes();assert sha(root/'hal/src/metal/mod.rs')==d['hal_patched_SHA256'];assert sha(root/'source/Cargo.lock')==d['diagnostic_Cargo_lock_SHA256'];assert (q/'match.json').read_bytes()==(q.parent/'macos-matched-calibration-v3/match.json').read_bytes()
for n in ['fixture.go','fixture_test.go']:assert (b/'framework'/n).read_bytes()==(b.parent/'framework'/n).read_bytes()
for p in [b.parent,b]:subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(p),'-p','check_test.py'],check=True)
for p in b.rglob('*.py'):compile(p.read_text(),str(p),'exec')
print('PASS: private observer archive/binary/source/lock/match identities; original view/routing reuse;18parent+9backend controls; no live qualification')
