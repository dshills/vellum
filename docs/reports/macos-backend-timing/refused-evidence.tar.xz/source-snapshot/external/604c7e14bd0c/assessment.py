"""Fresh default-path adapter around existing single-attempt orchestration.
No live effects during import/prepare. Historical controllers/evidence stay sealed.
"""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, signal, subprocess, sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
X = P.parent
SDK = Path('/private/tmp/vellum-doclinks-sdk-bd3cbc9/retained SDK/vellum-v0.1.0-alpha.2')
SOURCE = 'bd3cbc9ce2566955dae5dbb61385b0e1a9307eaa'
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
LEASE = X / 'macos-sdk-stage0079-abe67c6-cache-v2/shared/live_lease.py'
sys.path.insert(0, str(LEASE.parent))
sys.path.insert(0, str(T / 'scripts'))

def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m
c = load('previous_orchestration', X / 'macos-presentation-display105/controller.py')
need = c.need
g = load('existing_owned_executor', X / 'macos-sdk-native-238b3b6/run.py')
lease_module = load('current_lease', LEASE)
validator = load('strict_presentation_validator', SDK / 'scripts/check-presentation.py')
sha = c.sha
write = c.write

def arguments(case, binary, journal):
    return [v for v in c.arguments(case, str(binary), journal) if not v.startswith('-experimental-display-backpressure=')]

def expected(case):
    config = c.expected_config(case)
    config.pop('DisplayBackpressureNS')
    return config

def validate(case, path, binary_sha):
    journal = validator.load(path, sha(path))
    if journal['Config'] != expected(case):
        raise ValueError('default-path workload/config mismatch')
    return validator.validate(journal, SOURCE, binary_sha)

def sdk_vector():
    manifest = json.loads((SDK / 'SDK_MANIFEST.json').read_text())
    need(manifest['source'] == {'clean': True, 'commit': SOURCE}, 'assessment integrity check failed')
    actual = {p.relative_to(SDK).as_posix(): sha(p) for p in SDK.rglob('*') if p.is_file()}
    need(not any((p.is_symlink() for p in SDK.rglob('*'))), 'assessment integrity check failed')
    need(actual == {**manifest['files'], 'SDK_MANIFEST.json': sha(SDK / 'SDK_MANIFEST.json')}, 'assessment integrity check failed')
    return actual

def prepare():
    if (P / 'plan.json').exists():
        raise ValueError('fresh assessment required')
    sdk = sdk_vector()
    pins = {str(p): sha(p) for p in [Path(__file__), LEASE, Path(c.__file__), Path(g.__file__), SDK / 'scripts/check-presentation.py', T / 'scripts/child_process.py', T / 'scripts/sdk_environment.py']}
    binaries = {}
    for kind in ['grid', 'tree']:
        binary = P / ('native-' + kind)
        meta = subprocess.check_output([str(c.GO), 'version', '-m', str(binary)], text=True)
        (P / (kind + '-build-info.txt')).write_text(meta)
        need(meta.splitlines()[0].endswith('go1.25.6'), 'assessment integrity check failed')
        for setting in ['GOOS=darwin', 'GOARCH=arm64', 'CGO_ENABLED=1']:
            need(setting in meta, 'assessment integrity check failed')
        need('-race=true' not in meta and 'offscreen' not in meta and ('-N' not in meta), 'assessment integrity check failed')
        need(str(SDK / 'drivers/cogent/build/libs-darwin') in meta or '../../drivers/cogent/build/libs-darwin' in meta, 'assessment integrity check failed')
        binaries[kind] = {'path': str(binary), 'sha256': sha(binary), 'metadata': meta}
        pins[str(binary)] = sha(binary)
    native = SDK / 'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'
    need(sha(native) == c.LIB_SHA, 'assessment integrity check failed')
    plan = {'sdk_source': SOURCE, 'current_main_reference': '7047740e7d5ae5acf910d367cd3b16545aff2e70', 'sdk_root': str(SDK), 'sdk': sdk, 'pins': pins, 'native_library': {'path': str(native), 'sha256': sha(native)}, 'binaries': binaries, 'cases': c.CASES, 'experimental_backpressure': False, 'headless': True, 'maximum_rounds': 5, 'maximum_live_seconds': 1200, 'per_case_watchdog_seconds': 330, 'qualification_scope': 'bounded grid/tree subset; no whole Mac release claim'}
    write(P / 'plan.json', plan)
    print(json.dumps({'sdk_files': len(sdk), 'source': SOURCE, 'cases': c.CASES, 'experimental_backpressure': False}))

class Host:

    def __init__(self, plan, root, deadline, lease, stopped):
        self.plan, self.root, self.deadline, self.lease, self.stopped = (plan, root, deadline, lease, stopped)
        self.pins = plan['pins']
        self.last_validated = None

    def stopping(self):
        return self.stopped[0] or (P / 'stop-live').exists() or datetime.datetime.now(datetime.timezone.utc) >= self.deadline or (not self.lease.held())

    def stable(self):
        return all((sha(k) == v for k, v in self.pins.items()))

    def check(self):
        need(not self.stopping() and self.stable(), 'stop/deadline/lease/input drift')

    def finish(self):
        need(self.lease.held() and self.stable() and (sdk_vector() == self.plan['sdk']), 'final source/native/binary integrity')

    def geometry(self):
        return c.geometry_state()

    def command(self, argv, cwd, out, timeout):
        self.check()
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.parent / 'tmp'
        tmp.mkdir(exist_ok=True, mode=448)
        profile = '(version 1)(allow default)(deny network* (remote ip) (local ip))' + ''.join(('(deny file-write* (subpath ' + json.dumps(str(p)) + '))' for p in [C, T, SDK, c.CORE_DATA]))
        env = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': str(Path.home()), 'TMPDIR': str(tmp), 'GOMAXPROCS': '2', 'LANG': 'C.UTF-8'}
        argv = ['/usr/bin/sandbox-exec', '-p', profile, '/usr/bin/env', '-i', *[k + '=' + v for k, v in env.items()], *argv]
        r = g.execute(argv, cwd, out, self.stopping, lambda: self.stable() and (not self.stopping()), timeout=timeout, limit=16 << 20)
        r['owned_tmp_empty'] = not list(tmp.iterdir())
        write(out.parent / (out.name + '-command.json'), r)
        return r

    def probes(self, root):
        values = {}
        for name, argv in c.PROBES.items():
            r = self.command(argv, T, root / name, 60)
            need(c.passed(r) and r['logs']['stderr']['bytes'] == 0, 'configuration probe failure')
            values[name] = r
        return values

    def native(self, case, journal, out):
        return self.command(arguments(case, self.plan['binaries'][case['kind']]['path'], journal), SDK / 'examples' / ('loaded' + case['kind']), out, 330)

    def validate(self, case, path):
        v = validate(case, path, self.plan['binaries'][case['kind']]['sha256'])
        write(path.parent / 'validation.json', v)
        self.last_validated = v
        if case['paced'] and (not (v['paced_metrics']['cadence_threshold_met'] and v['paced_metrics']['input_latency_threshold_met'])):
            raise ValueError('paced default-path responsiveness failed; retain metrics and stop unchanged repetitions')
        return v

def run():
    plan = json.loads((P / 'plan.json').read_text())
    need(sdk_vector() == plan['sdk'], 'assessment integrity check failed')
    need(not (P / 'started.json').exists() and (not (P / 'stop-live').exists()), 'sealed campaign cannot restart')
    start = datetime.datetime.now(datetime.timezone.utc)
    deadline = start + datetime.timedelta(minutes=20)
    write(P / 'started.json', {'started_utc': start.isoformat(), 'deadline_utc': deadline.isoformat(), 'human_authorization': 'Yes, test when ready', 'features_frozen': True, 'experimental_backpressure': False})
    stopped = [False]
    previous = {sig: signal.signal(sig, lambda *_: stopped.__setitem__(0, True)) for sig in [signal.SIGINT, signal.SIGTERM]}
    results = []
    try:
        with lease_module.LiveLease() as lease:
            for n in range(1, 6):
                root = P / ('round' + str(n))
                root.mkdir()
                host = Host(plan, root, deadline, lease, stopped)
                result = c.execute_cases({'cases': plan['cases']}, host, root)
                results.append(result)
                print(json.dumps({'round': n, 'result': result['result'], 'completed': result['completed'], 'error': result['error']}), flush=True)
                if result['result'] != 'PASS_SCOPED_NATIVE_FEEDBACK_PREFLIGHT':
                    break
    finally:
        (P / 'stop-live').touch()
        write(P / 'result.json', {'rounds': results, 'release_qualified': False, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stopped': stopped[0]})
        for sig, handler in previous.items():
            signal.signal(sig, handler)
if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif sys.argv[1:] == ['run']:
        run()
    else:
        raise ValueError('prepare or run')
