from pathlib import Path
import json,importlib.util,sys,hashlib
sys.dont_write_bytecode=True
w=Path(__file__).resolve().parent;sys.path.insert(0,str(w.parent/'macos-grid-capture-repair/preflight-v2'))
s=importlib.util.spec_from_file_location('owned_go',w.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
f=Path('/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/backend/framework');pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in f.iterdir() if p.is_file()};lib=Path('/private/tmp/vellum-backend-timing/libs-darwin/arm64/libwgpu_native.a');pins[str(lib)]=hashlib.sha256(lib.read_bytes()).hexdigest()
argv=['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)','/bin/sh',str(w.parent/'macos-app-examples/go-check'),'build','-ldflags=-buildid='+pins[str(lib)],'-o',str(w/'framework'),'.']
r=g.execute(argv,f,w/'go-build-v2',lambda:False,lambda:all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items()),timeout=180,limit=2<<20)
(w/'go-build-v2-receipt.json').write_text(json.dumps({'argv':argv,'inputs':pins,'run':r},indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','error','seconds']}));assert r['exit_code']==0 and r['error'] is None and r['owned']['group_absent']
