from pathlib import Path
import hashlib,json
from run import ROOT as R,PHASE as P,sha
checks=['color-contract-race-v3','full-adapter-race-unrestricted','full-portable-race','portable-vet','adapter-vet','gallery-default-build','native-vet','color-native-build','native-color-actions']
receipts={}
for name in checks:
 j=json.loads((P/(name+'.json')).read_text())
 assert j['exit_code']==0 and j['error'] is None,name
 for ch in ['stdout','stderr']:assert sha(P/(name+'.'+ch))==j[ch+'_sha256']
 if j['mode']=='code':assert j['source_delta_stable'] and j['prepared_before']==j['prepared_after']
 else:assert j['source_prepared_stable'] and j['authorization_sha256']==sha(P/'testing-authorization.json')
 receipts[name]={'receipt_sha256':sha(P/(name+'.json')),'exit_code':j['exit_code'],'elapsed_seconds':j['elapsed_seconds']}
lines=[json.loads(s)for s in (P/'native-color-actions.stdout').read_text().splitlines()if s.startswith('{')]
steps=[s for s in lines if s.get('event')=='vellum.color.step'];assert len(steps)==8
assert [s['edit_callbacks']for s in steps]==[1,2,3,4,4,5,6,7]
assert [s['invalid_callbacks']for s in steps]==[0,0,0,0,1,1,1,1]
assert [s['accepted_hex']for s in steps]==['#0C60E0FF','#0C61E0FF','#0C61E000','#F001AB00','#F001AB00','#2501AB00','#2501AB00','#2501ABFF']
assert all(s['owner_and_native_completed']for s in steps)
result=[s for s in lines if s.get('event')=='vellum.color.result'];assert len(result)==1
result=result[0];assert result['result']=='PASS_NATIVE_COLOR_PICKER'and result['stable_field_identities']and result['disabled_refused']and result['hidden_refused']
cleanup=[s for s in lines if s.get('event')=='vellum.color.cleanup'];assert len(cleanup)==1 and cleanup[0]['observed']
c=cleanup[0]['native_cleanup'];assert all(c[k]for k in ['MainThread','CleanupObserved','CallbacksStopped'])
assert all(c[k]==0 for k in ['PendingCallbacks','NativeOutstanding','AccessibilityWindows'])and not c['WindowTitles']
source=json.loads((P/'native-code-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in source.items())
baseline=json.loads((P/'baseline.json').read_text());assert len(baseline['prepared'])==6204
assert all(baseline['selected_source'][n]==h for n,h in source.items())
for name in ['color-native-build','native-color-actions']:
 j=json.loads((P/(name+'.json')).read_text());assert j['baseline_sha256']==sha(P/'baseline.json')
for name in ['full-adapter-race-unrestricted','full-portable-race','portable-vet','adapter-vet','gallery-default-build','native-vet']:
 j=json.loads((P/(name+'.json')).read_text());assert all(j['source_delta_before'][n]==h for n,h in source.items())
build=json.loads((P/'color-native-build.json').read_text());live=json.loads((P/'native-color-actions.json').read_text())
assert build['argv'][-3:]==['-o',live['argv'][0],'./cmd/gallery']and live['argv'][1:]==['-color-smoke']
assert live['executable_sha256']==sha(live['argv'][0])
old=json.loads((P/'slider-original-regression.json').read_text());assert old['exit_code']==1 and old['error']is None and old['overlay_inputs_before']==old['overlay_inputs_after']
assert 'min={Value:20 Unit:em' in (P/'slider-original-regression.stdout').read_text()
summary={'result':'PASS_SCOPED_COLOR_PICKER_CHECKPOINT','base_commit':baseline['commit'],'checks':receipts,'native_code_source_sha256':sha(P/'native-code-source.json'),'steps':steps,'native_result':result,'native_cleanup':c,'prepared_files':6204,'prepared_changed':False,'general_slider_regression_original_failed':True,'preview_capture_sha256':sha(P/'color-picker.png'),'framework_api_added':'ui.ColorPicker owner-held managed-node composition','full_p6_qualified':False,'full_p11_qualified':False,'human_voiceover_qualified':False,'physical_input_qualified':False}
(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ['steps','checks']},indent=2))
