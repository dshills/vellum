from pathlib import Path
import json,hashlib,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-color-picker');D=R/'docs/reports/macos-color-picker/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text())
assert process['exit_code']==0 and not process['error']and process['source_index_stable']and review['coverage']['complete']and review['coverage']['files']==19 and not review['findings']
assert review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert len(sources)==19 and all(sha(R/n)==h for n,h in sources.items())
internal=json.loads((P/'internal-terminal-review.json').read_text());assert internal['result']=='APPROVED_EVIDENCE'and not internal['unresolved_findings']
summary=json.loads((P/'final-summary.json').read_text());assert summary['result']=='PASS_SCOPED_COLOR_PICKER_CHECKPOINT'and summary['native_result']['steps']==8 and summary['native_result']['edit_callbacks']==7 and summary['native_result']['invalid_callbacks']==1
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.png'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['color_picker_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Reusable inline color picker and general Slider sizing fix. Includes original failed layout/compile/fixture checks, original Slider overlay assertion, corrected full tests, native build/8step selector run and main-loop cleanup, visual PNG, internal source/evidence and one complete19filePrism review. Binaries excluded; hashes retained. Prepared dependencies unchanged.'},indent=2)+'\n')
q={'result':'REVIEWED_INLINE_COLOR_PICKER','base_commit':summary['base_commit'],'sources':sources,'internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':0,'prism_coverage_complete':True,'prism_files':19,'prism_provider_calls':review['coverage']['llmCalls'],'prism_reported_findings':0,'prism_unresolved_findings':0,'native_selector_steps':8,'native_edit_callbacks':7,'native_invalid_callbacks':1,'native_clean_teardown':True,'prepared_files':6204,'prepared_changed':False,'framework_api_added':'ui.ColorPicker owner-held ordinary managed-node composition','general_slider_style_fix':True,'full_p6_qualified':False,'full_p11_qualified':False,'physical_input_qualified':False,'human_voiceover_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
