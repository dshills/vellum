from pathlib import Path
import subprocess,sys
p=Path('/private/tmp/vellum-macos-color-picker');r=Path('/private/tmp/vellum-large-data')
for argv in [
 ['python3',str(p/'code_run.py'),'full-portable-race','.', 'go','test','-race','-count=1','./...'],
 ['python3',str(p/'code_run.py'),'portable-vet','.', 'go','vet','./...'],
 ['python3',str(p/'code_run.py'),'adapter-vet','drivers/cogent', 'go','vet','-tags=offscreen','./...'],
 ['python3',str(p/'code_run.py'),'gallery-default-build','drivers/cogent','go','build','-o',str(p/'gallery-default'),'./cmd/gallery'],
 ['python3',str(p/'code_run.py'),'native-vet','drivers/cogent','go','vet','-tags=vellum_native_checks','./cmd/gallery'],
 ['python3',str(p/'run.py'),'color-native-build','build','drivers/cogent','240','go','build','-tags=vellum_native_checks','-o',str(p/'gallery-native'),'./cmd/gallery']
]:
 code=subprocess.run(argv,cwd=r).returncode
 if code:sys.exit(code)
