from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-closable-tabs');U=R/'drivers/cogent/build/upstream'
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
(P/'prepared-baseline.json').write_text(json.dumps({f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()},indent=2)+'\n')
f=U/'core/tabs.go';s=f.read_text();where='\tCloseIcon icons.Icon\n';assert s.count(where)==2;i=s.index(where,s.index('type Tab struct'));s=s[:i]+s[i:].replace(where,where+'''\n // CloseRequest, when nonnil, owns close admission instead of native deletion.
 // The managed caller must retain a guarded callback through retirement. Nil
 // preserves ordinary unmanaged FunctionalTabs close behavior.
 CloseRequest func()
''',1)
old='''\t\t\t\tw.OnClick(func(e events.Event) {
\t\t\t\t\tts := tb.tabs()''';assert s.count(old)==1;s=s.replace(old,'''\t\t\t\tw.OnClick(func(e events.Event) {
     if tb.CloseRequest != nil {
      e.SetHandled()
      tb.CloseRequest()
      return
     }
\t\t\t\t\tts := tb.tabs()''');(P/'core-tabs.go').write_text(s);(P/'native-overlay.json').write_text(json.dumps({'Replace':{str(f):str(P/'core-tabs.go')}},indent=2)+'\n')
f=R/'ui/controls.go';s=f.read_text().replace('\tDisabled  bool\n','\tDisabled  bool\n',1);s=s.replace('\tSeparator bool','\t// Closable belongs only on Tabs and requires Node.TabClose.\n\tClosable bool\n\tSeparator bool',1)
needle='func ValidateControl(n Node) error {\n';s=s.replace(needle,needle+''' if n.Kind != Tabs && n.TabClose != nil { return fmt.Errorf("ui: TabClose belongs only on tabs") }
 for _, option := range n.Options {
  if option.Closable && (n.Kind != Tabs || n.TabClose == nil) { return fmt.Errorf("ui: closable tab requires Tabs and TabClose") }
 }
''');s=s.replace('// Accessibility carries semantic labels','''// TabCloseEvent proposes closing one stable page. The application accepts by
// removing its option/page and selecting a remaining page in the next view.
// ID is the Tabs node ID; PageID is the option/page ID. No native deletion runs.
type TabCloseEvent struct { ID, PageID string }

// Accessibility carries semantic labels''');f.write_text(s)
f=R/'ui/node.go';s=f.read_text().replace('\tSelectedID    string','\tSelectedID    string\n\tTabClose      func(TabCloseEvent)');f.write_text(s)
f=R/'drivers/cogent/controls.go';s=f.read_text().replace('\torder   []string\n}', '\torder   []string\n\tbindings map[string]*tabBinding\n\tvisible bool\n}',1);s=s.replace('buttons: map[string]*core.Tab{}}','buttons: map[string]*core.Tab{}, bindings: map[string]*tabBinding{}}',1)
s=s.replace('\t\tfor _, o := range r.node.Options {\n\t\t\tb := r.control.tabs.buttons[o.ID]', '\t\tsyncTabsPresentation(r)\n\t\tfor _, o := range r.node.Options {\n\t\t\tb := r.control.tabs.buttons[o.ID]',1)
s=s.replace('\t\t\tid := o.ID\n\t\t\tbutton.OnClick', '\t\t\tid := o.ID\n\t\t\tbinding := bindTab(r, id, button)\n\t\t\tbutton.OnClick',1)
s=s.replace('\t\t\t\t\tif !enabled || r.node.Change == nil {','\t\t\t\t\tif !enabled || r.node.Change == nil || r.control.tabs.bindings[id] != binding || !r.control.tabs.visible {',1)
s=s.replace('\t\t\tdelete(c.buttons, id)','\t\t\tif binding := c.bindings[id]; binding != nil { binding.closeEpoch.Store(nil) }\n\t\t\tdelete(c.bindings, id)\n\t\t\tdelete(c.buttons, id)',1);f.write_text(s)
f=R/'drivers/cogent/reconcile.go';s=f.read_text().replace('\tbindToolbarNavigation(next.r)','\tpublishTabVisibility(next.r, true)\n\tbindToolbarNavigation(next.r)',1);f.write_text(s)
# Existing bounded code-only runner; native admission variables remain filtered.
s=Path('/private/tmp/vellum-macos-gpu-covered/code_run.py').read_text().replace("p=Path('/private/tmp/vellum-macos-gpu-covered')","p=Path('/private/tmp/vellum-macos-closable-tabs')");(P/'code_run.py').write_text(s)
print('Portable metadata and native callback overlay created')
