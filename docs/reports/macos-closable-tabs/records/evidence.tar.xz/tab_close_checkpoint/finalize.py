from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-closable-tabs')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def delta():return sorted(set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()+subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines()))
old=json.loads((P/'prepared-final.json').read_text());final=json.loads((P/'prepared-final-v2.json').read_text());base=json.loads((P/'prepared-baseline.json').read_text());assert len(base)==6208 and len(final)==6209
repair=[n for n in old.keys()|final.keys() if old.get(n)!=final.get(n)];assert repair==['upstream/core/tabs_close_request_vellum_test.go']
a=json.loads((P/'adoption-inputs-v2.json').read_text());changed=[n for n in base.keys()|final.keys() if base.get(n)!=final.get(n)];assert set(changed)=={'upstream/'+n for n in a['outputs']}
for n,h in a['outputs'].items():assert final['upstream/'+n]==sha(R/'drivers/cogent/build/upstream'/n)==h
names=delta();code={n:sha(R/n) for n in names if n.endswith(('.go','.py'))};checks={}
for name in ['final-prepare-v2','final-adapter-race','final-adapter-race-v3','final-portable-race','final-sdk','final-adapter-vet','final-core-contract-v3','final-native-vet','final-preparation-tests-v2','final-native-build-v2','final-visual-route']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and d['error'] is None and d['source_delta_stable'] and not d['live_tests'] and not d['headless_gpu_requested'];assert d['prepared_after']==final or d['prepared_after']==old
 applicable={n:h for n,h in code.items() if not (name=='final-visual-route' and n=='drivers/cogent/cmd/gallery/documents_test.go')}
 old_test=sha(P/'pre-prism-cleanup-tab_close_test.go')
 for n,h in applicable.items():
  expected=old_test if n=='drivers/cogent/tab_close_test.go' and name!='final-adapter-race-v3' else h
  assert d['source_delta_after'][n]==expected,(name,n)
 assert d['overlay_inputs_before']==d['overlay_inputs_after']=={}
 for c in ['stdout','stderr']:assert sha(P/(name+'.'+c))==d[c+'_sha256']
 checks[name]={'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'argv':d['argv'],'receipt_sha256':sha(P/(name+'.json')),'prepared_version':'corrected-Core-test' if d['prepared_after']==final else 'before-Core-test-only-repair'}
neg={}
for name,msg in [('negative-private-v2','retired private close button acted on replacement'),('negative-dialog-v1','native dismissal left old close capability alive before owner drain'),('negative-native-v2','native close selected/deleted before owner admission')]:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==1 and d['error'] is None and d['source_delta_stable'] and msg in (P/(name+'.stdout')).read_text();assert d['prepared_before']==d['prepared_after']==final
 for c in ['stdout','stderr']:assert sha(P/(name+'.'+c))==d[c+'_sha256']
 assert d['overlay_inputs_before']==d['overlay_inputs_after'];neg[name]={'expected_assertion':msg,'receipt_sha256':sha(P/(name+'.json'))}
build=json.loads((P/'final-native-build-v2.json').read_text());prev=json.loads((P/'final-native-build.json').read_text());assert not build['binary_launched'] and sha(build['produced_file'])==build['executable_sha256']==prev['executable_sha256']
sources={n:sha(R/n) for n in delta()};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':head,'sources':sources},indent=2)+'\n')
summary={'result':'PASS_SCOPED_CONTROLLED_TAB_CLOSE','base_commit':head,'sources':sources,'checks':checks,'negative_controls':neg,'prepared_before_files':6208,'prepared_after_files':6209,'two_reviewed_outputs_exact':True,'all_other_dependency_leaves_unchanged':True,'post_broad_check_repair':{'only_prepared_leaf':repair[0],'production_code_unchanged':True,'native_binary_byte_equal':True,'test_cleanup_fixed_after_Prism':True,'new_full_adapter_race_check':'final-adapter-race-v3'},'native_build_sha256':build['executable_sha256'],'native_build_bytes':build['produced_file_bytes'],'native_build_launched':False,'live_checks_run':False,'native_gpu_checks_run':False,'full_p6_qualified':False,'full_p11_qualified':False,'gpu_default_enabled':False};(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS',len(sources),'source files;',len(checks),'checks; 3 detected faults; prepared 6208->6209; no live qualification')
