NEEDS_FIX. Two concrete gaps remain: dismissed native dialogs do not revoke retained descendant tab-close capabilities, and unreserved tab-close: IDs can collide with generated manual targets.

The CloseRequest seam otherwise consumes before detached-parent access and prevents native deletion. Epoch/private-button and selection binding checks preserve owner-only requests; modifier guards protect window/editor chords. Exact V1 snapshots and hashes are in internal-candidate-v1/ and internal-candidate-review.json. No tests/build/native/UI/provider/Git execution was performed.
