from pathlib import Path
import hashlib,json,difflib
R=Path('/private/tmp/vellum-large-data');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-macos-closable-tabs');D=R/'drivers/cogent/native/patches/tabclose'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
f=P/'tabs_close_request_vellum_test.go';s=f.read_text();(P/'core-test-v1-compile-failure.go').write_text(s);assert 'current.Name' in s;f.write_text(s.replace('current.Name','current.AsTree().Name'))
for name in ['0058-controlled-tab-close-admission.patch','output-hashes.json']:(P/('pre-test-fix-'+name)).write_bytes((D/name).read_bytes())
manifest=R/'drivers/cogent/native/dependencies.json';(P/'pre-test-fix-dependencies.json').write_bytes(manifest.read_bytes())
ad=json.loads((P/'adoption-inputs.json').read_text());mapping={'core/tabs.go':P/'core-tabs-v2.go','core/tabs_close_request_vellum_test.go':f};chunks=[];outputs={}
for n,source in mapping.items():
 base=C/'drivers/cogent/build/upstream'/n;assert (sha(base)if base.exists()else None)==ad['inputs'][n]
 chunks.extend(difflib.unified_diff(base.read_text().splitlines(True)if base.exists()else[],source.read_text().splitlines(True),fromfile='a/'+n if base.exists()else'/dev/null',tofile='b/'+n));outputs[n]=sha(source)
patch=D/'0058-controlled-tab-close-admission.patch';patch.write_text(''.join(chunks));(D/'output-hashes.json').write_text(json.dumps(outputs,indent=2)+'\n')
d=json.loads(manifest.read_text());stage=d['dependencies'][0]['stages'][-1];assert stage['patches'][0]['file'].endswith(patch.name);stage['patches'][0]['sha256']=sha(patch);manifest.write_text(json.dumps(d,indent=2)+'\n');ad['outputs']=outputs;ad['patch_sha256']=sha(patch);(P/'adoption-inputs-v2.json').write_text(json.dumps(ad,indent=2)+'\n');print('Fixed owned Core test selector; implementation unchanged; new pins recorded')
