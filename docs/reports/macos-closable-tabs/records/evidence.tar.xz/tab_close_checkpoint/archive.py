from pathlib import Path
import hashlib,json,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-closable-tabs');D=R/'docs/reports/macos-closable-tabs/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];review=json.loads((P/'prism-v3/prism.json').read_text());process=json.loads((P/'prism-v3/process.json').read_text());internal=json.loads((P/'internal-final-review.json').read_text());summary=json.loads((P/'final-summary.json').read_text())
assert len(sources)==25 and all(sha(R/n)==h for n,h in sources.items())
assert process['exit_code']==0 and not process['error'] and process['source_index_stable'] and process['before']==process['after']==sources
assert review['coverage']['complete'] and review['coverage']['files']==len(sources) and not review['findings'] and review['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert internal['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not internal['unresolved_findings'] and internal['sources']==sources
assert summary['result']=='PASS_SCOPED_CONTROLLED_TAB_CLOSE' and summary['sources']==sources and not summary['live_checks_run']
D.mkdir(exist_ok=True);inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.log','.md','.patch','.png'}
for f in sorted(P.rglob('*')):
 if f.is_file() and not f.is_symlink() and '__pycache__' not in f.parts and f.suffix in allowed:inputs['tab_close_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['reviewed_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size} for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3) as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile() and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Stage58 controlled tab close; API, adapter, gallery and SDK fixture. Preserves original internal defects/compile failures, corrected scopes/pins, 11 passing gates, 3 failing faulty controls, offscreen PNG, Prism V1 cleanup finding, corrected test source, internal and final Anthropic reviews. Binaries excluded with hashes retained; no live qualification. Only prepared Core test accessor changed after broad gates; production source unchanged and native binaries byte equal.'},indent=2)+'\n')
q={**summary,'result':'REVIEWED_CONTROLLED_TAB_CLOSE','internal_review':'APPROVED_SOURCE_AND_EVIDENCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':0,'prism_coverage_complete':True,'prism_files':len(sources),'prism_provider_calls':review['coverage']['llmCalls'],'prism_initial_reported_findings':2,'prism_initial_finding_resolved':'latest-tree cleanup closure and full adapter race rerun; duplicate report prose removed and binding producer made non-mutating','prism_reported_findings':0,'prism_unresolved_findings':0,'physical_input_qualified':False,'human_voiceover_qualified':False,'fresh_endurance_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print('PASS indexed archive',len(inputs),'members',archive.stat().st_size,'bytes',sha(archive))
