package cogent

import (
	"html"
	"sync/atomic"

	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"cogentcore.org/core/icons"
	"cogentcore.org/core/tree"
	"github.com/dshills/vellum/ui"
)

type tabCloseScope struct{ closed atomic.Bool }
type tabCloseEpoch struct {
	marker byte
	scopes []*tabCloseScope
}

func tabCloseEpochLive(epoch *tabCloseEpoch) bool {
	if epoch == nil {
		return false
	}
	for _, scope := range epoch.scopes {
		if scope == nil || scope.closed.Load() {
			return false
		}
	}
	return true
}
func tabCloseSameScopes(a, b []*tabCloseScope) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

type tabBinding struct {
	button               *core.Tab
	closeEpoch           atomic.Pointer[tabCloseEpoch]
	closeWidget          atomic.Pointer[core.Button]
	presented            bool
	presentationType     core.TabTypes
	presentationLabel    string
	presentationClosable bool
	manualIncarnation    uint64 // manual originating-owner inspection only
}

func bindTab(r *record, id string, button *core.Tab) *tabBinding {
	binding := &tabBinding{button: button}
	r.control.tabs.bindings[id] = binding
	// Never restore nil after retirement: a late private close gesture must not
	// fall through to the backend's destructive unmanaged deletion path.
	button.CloseRequest = func(origin *core.Button) { queueTabCloseFrom(r, id, binding, origin) }
	button.OnFirst(events.KeyChord, func(e events.Event) {
		if e.IsHandled() || e.Modifiers() != 0 || !tabCloseEpochLive(binding.closeEpoch.Load()) {
			return
		}
		if e.KeyCode() != key.CodeBackspace && e.KeyCode() != key.CodeDelete {
			return
		}
		e.SetHandled()
		queueTabClose(r, id, binding)
	})
	return binding
}
func tabCloseEnabled(r *record, id string, binding *tabBinding) bool {
	if r == nil || r.control == nil || r.control.retired || r.control.disabled || r.control.tabs == nil || !r.control.tabs.visible || r.control.tabs.bindings[id] != binding || r.node.TabClose == nil {
		return false
	}
	for _, option := range r.node.Options {
		if option.ID == id {
			return option.Closable && !option.Disabled
		}
	}
	return false
}
func queueTabClose(r *record, id string, binding *tabBinding) {
	queueTabCloseFrom(r, id, binding, binding.closeWidget.Load())
}

func queueTabCloseFrom(r *record, id string, binding *tabBinding, origin *core.Button) {
	epoch := binding.closeEpoch.Load()
	if !tabCloseEpochLive(epoch) || origin == nil {
		return
	}
	postControl(r, func() {
		if !tabCloseEpochLive(epoch) || binding.closeEpoch.Load() != epoch || !tabCloseEnabled(r, id, binding) {
			return
		}
		r.node.TabClose(ui.TabCloseEvent{ID: r.node.ID, PageID: id})
		_ = r.control.a.Invalidate(r.control.window)
	})
}
func tabCloseButton(binding *tabBinding) *core.Button {
	if binding == nil || tree.IsNil(binding.button) {
		return nil
	}
	button, _ := binding.button.AsTree().ChildByName("close").(*core.Button)
	return button
}
func syncTabsPresentation(r *record) {
	typ := core.StandardTabs
	for _, o := range r.node.Options {
		if o.Closable {
			typ = core.FunctionalTabs
			break
		}
	}
	w := r.widget.(*core.Tabs)
	w.SetType(typ)
	for _, o := range r.node.Options {
		button := r.control.tabs.buttons[o.ID]
		binding := r.control.tabs.bindings[o.ID]
		label := html.EscapeString(o.Label)
		button.SetType(typ).SetText(label)
		icon := icons.None
		if o.Closable {
			icon = icons.Close
		}
		button.SetCloseIcon(icon)
		// Rebuild only the native tab's private artwork, preserving page widgets.
		if !binding.presented || binding.presentationType != typ || binding.presentationLabel != label || binding.presentationClosable != o.Closable {
			button.UpdateWidget()
			binding.presented = true
			binding.presentationType = typ
			binding.presentationLabel = label
			binding.presentationClosable = o.Closable
		}
		close := tabCloseButton(binding)
		if binding.closeWidget.Load() != close {
			binding.closeEpoch.Store(nil)
			binding.closeWidget.Store(close)
			binding.manualIncarnation = 0
		}
		if close != nil {
			close.Tooltip = html.EscapeString("Close " + o.Label)
		}
	}
}

// Reconciliation publishes owner-held visibility, so a callback drained by a
// different window never walks originating native widget parents. Hiding then
// showing a tab strip retires its previous close capability even if IDs recur.
// syncTabVisibility reuses the reconciler's existing ordered traversal. It
// publishes only owner values/atomic capabilities, never a second tree walk.
func syncTabVisibility(r *record, visible bool, scopes []*tabCloseScope) {
	if r.control == nil || r.control.tabs == nil {
		return
	}
	r.control.tabs.visible = visible
	for id, binding := range r.control.tabs.bindings {
		enabled := tabCloseEnabled(r, id, binding) && binding.closeWidget.Load() != nil
		if !enabled {
			binding.closeEpoch.Store(nil)
		} else if previous := binding.closeEpoch.Load(); previous == nil || !tabCloseSameScopes(previous.scopes, scopes) {
			binding.closeEpoch.Store(&tabCloseEpoch{scopes: append([]*tabCloseScope(nil), scopes...)})
		}
	}
}
func tabCloseID(tabs, page string) string {
	return "tab-close:" + accessibilityIDPart(tabs) + ":" + accessibilityIDPart(page)
}
func tabCloseAccessibility(r *record, option ui.Option, parent string, disabled bool) (accessibilityNode, accessibilityHandler) {
	binding := r.control.tabs.bindings[option.ID]
	n := accessibilityNode{ID: tabCloseID(r.node.ID, option.ID), Parent: parent, DomainID: option.ID, Role: "button", Name: "Close " + option.Label, Disabled: disabled || option.Disabled, Actions: []string{}}
	if n.Disabled || !tabCloseEnabled(r, option.ID, binding) {
		return n, nil
	}
	epoch := binding.closeEpoch.Load()
	n.Actions = []string{"press"}
	return n, func(action accessibilityAction) bool {
		if action.Kind != "press" || !tabCloseEpochLive(epoch) || binding.closeEpoch.Load() != epoch || !tabCloseEnabled(r, option.ID, binding) {
			return false
		}
		queueTabClose(r, option.ID, binding)
		return true
	}
}

const tabCloseContextProperty = "vellum.tab-close.context"

type tabCloseContext struct {
	visible bool
	scopes  []*tabCloseScope
}

// Independent managed roots inside an extension inherit its complete owner
// snapshot during originating reconciliation, never during queued delivery.
func tabCloseInheritedContext(r *record) (bool, []*tabCloseScope) {
	for parent := r.widget.AsTree().Parent; parent != nil; parent = parent.AsTree().Parent {
		if context, ok := parent.AsTree().Property(tabCloseContextProperty).(*tabCloseContext); ok && context != nil {
			return context.visible, context.scopes
		}
	}
	return true, nil
}
