"""Proceed once final review is present; stop on any failed gate."""
from pathlib import Path
import json,subprocess,time
P=Path('/private/tmp/vellum-macos-closable-tabs');end=time.monotonic()+120
while not all((P/n).is_file() for n in ['internal-final-review.json','internal-final-review.md']):
 if time.monotonic()>=end:raise TimeoutError('final internal review not ready')
 time.sleep(2)
d=json.loads((P/'internal-final-review.json').read_text());assert d['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not d['unresolved_findings'] and d['sources']==json.loads((P/'checkpoint-source.json').read_text())['sources']
for name in ['archive.py','commit.py']:subprocess.run(['python3',str(P/name)],check=True)
