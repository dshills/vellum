// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/events"
	"image"
	"testing"
)

func TestVellumTabCloseRequestOwnsDeletionBeforeParentLookup(t *testing.T) {
	tabs := NewTabs(NewBody("close request")).SetType(FunctionalTabs)
	_, a := tabs.NewTab("a")
	_, b := tabs.NewTab("b")
	tabs.SelectTabByName("a")
	called := 0
	b.CloseRequest = func(origin *Button) {
		called++
		if origin != b.AsTree().ChildByName("close") {
			t.Error("wrong private button origin")
		}
	}
	b.UpdateWidget()
	close := b.AsTree().ChildByName("close").(*Button)
	e := events.NewMouse(events.Click, events.Left, image.Point{}, 0)
	close.HandleEvent(e)
	current, _ := tabs.CurrentTab()
	if called != 1 || !e.IsHandled() || tabs.NumTabs() != 2 || current.AsTree().Name != "a" {
		t.Fatal("controlled close selected/deleted native page", called, e.IsHandled(), tabs.NumTabs())
	}
	// The seam precedes parent lookup, including a delayed event after detaching
	// the native Tab. A held callback can still identify its own private button.
	parent := b.Parent
	b.Parent = nil
	close.HandleEvent(events.NewMouse(events.Click, events.Left, image.Point{}, 0))
	b.Parent = parent
	if called != 2 {
		t.Fatal("detached close callback failed")
	}
	// Unmanaged nil seam preserves the existing active-tab deletion route.
	a.UpdateWidget()
	a.AsTree().ChildByName("close").(*Button).Send(events.Click)
	if tabs.NumTabs() != 1 {
		t.Fatal("nil close seam changed unmanaged behavior")
	}
}
