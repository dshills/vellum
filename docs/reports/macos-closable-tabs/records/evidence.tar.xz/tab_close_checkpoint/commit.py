from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-closable-tabs');D=R/'docs/reports/macos-closable-tabs/records'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
q=json.loads((D/'qualification.json').read_text());assert git('rev-parse','HEAD')==q['base_commit'] and q['prism_coverage_complete'] and q['prism_unresolved_findings']==0
assert all(sha(R/n)==h for n,h in q['sources'].items()) and sha(D/'evidence.tar.xz')==q['archive_sha256']
subprocess.run(['git','add','--',str(D.relative_to(R))],cwd=R,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
expected=set(q['sources'])|{(D/f).relative_to(R).as_posix() for f in ['qualification.json','evidence-index.json','evidence.tar.xz']};assert set(git('diff','--cached','--name-only').splitlines())==expected and len(expected)==28
output=subprocess.check_output(['git','commit','-m','feat(ui): add owner-controlled closable document tabs'],cwd=R).decode();assert not git('status','--porcelain');head=git('rev-parse','HEAD');assert git('rev-list','--parents','-n','1','HEAD').split()==[head,q['base_commit']]
(P/'commit-receipt.json').write_text(json.dumps({'result':'PASS_REVIEWED_CHECKPOINT_COMMIT','commit':head,'base_commit':q['base_commit'],'files':28,'source_files':25,'archive_sha256':q['archive_sha256'],'scratch_clean':True,'output':output},indent=2)+'\n');print(output);print(head)
