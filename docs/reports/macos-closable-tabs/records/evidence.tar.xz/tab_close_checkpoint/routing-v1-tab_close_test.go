package cogent

import (
	"cogentcore.org/core/core"
	"cogentcore.org/core/events"
	"cogentcore.org/core/styles/states"
	"github.com/dshills/vellum/ui"
	"testing"
)

func closeTabsFixture(handler func(ui.TabCloseEvent)) ui.Node {
	return ui.Node{ID: "tabs", Kind: ui.Tabs, SelectedID: "a", Options: []ui.Option{{ID: "a", Label: "First", Closable: true}, {ID: "b", Label: "Second", Closable: true}}, TabClose: handler, Children: []ui.Node{{ID: "a", Kind: ui.Column, Children: []ui.Node{{ID: "draft", Kind: ui.TextField, Text: "accepted"}}}, {ID: "b", Kind: ui.Column}}}
}
func TestTabCloseControlledRejectLatestAndPrivateBinding(t *testing.T) {
	a, _ := newAXTest(t, 32)
	host := core.NewFrame(core.NewBody("tabs"))
	first, latest, selections := 0, 0, 0
	n := closeTabsFixture(func(e ui.TabCloseEvent) {
		first++
		if e.ID != "tabs" || e.PageID != "b" {
			t.Error("wrong close event", e)
		}
	})
	n.Change = func(ui.ChangeEvent) { selections++ }
	r, err := reconcile(host, nil, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	defer disposeControlTree(r)
	oldPage := r.control.tabs.pages["b"]
	binding := r.control.tabs.bindings["b"]
	close := tabCloseButton(binding)
	if close == nil {
		t.Fatal("private close button absent")
	}
	close.Send(events.Click)
	if r.widget.(*core.Tabs).NumTabs() != 2 || r.node.SelectedID != "a" || !r.control.tabs.buttons["a"].StateIs(states.Selected) {
		t.Fatal("native close selected/deleted before owner admission")
	}
	n.TabClose = func(ui.TabCloseEvent) { latest++ }
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	a.Drain()
	if first != 0 || latest != 1 || selections != 0 || r.control.tabs.pages["b"] != oldPage {
		t.Fatal("rejection/latest/selection isolation", first, latest, selections)
	}
	// Hide/recreate only the close artwork; held old private buttons cannot act on
	// a current capability of the same still-retained tab.
	n.Options[1].Closable = false
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	n.Options[1].Closable = true
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	current := tabCloseButton(binding)
	if current == close || current == nil {
		t.Fatal("fixture did not replace private close button")
	}
	close.Send(events.Click)
	a.Drain()
	if latest != 1 {
		t.Fatal("retired private close button acted on replacement")
	}
	// Retire and readd a page with the same domain ID. Both queued close and tab
	// selection must retain the originating binding, never an ID-only lookup.
	current.Send(events.Click)
	binding.button.Send(events.Click)
	saved := n.Children[1]
	n.Options = n.Options[:1]
	n.Children = n.Children[:1]
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	n.Options = append(n.Options, ui.Option{ID: "b", Label: "Replacement", Closable: true})
	n.Children = append(n.Children, saved)
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	a.Drain()
	if latest != 1 || selections != 0 || r.control.tabs.bindings["b"] == binding {
		t.Fatal("stale tab request reached new binding")
	}
}
func TestTabCloseDisabledHiddenAndAcceptedReparent(t *testing.T) {
	a, _ := newAXTest(t, 32)
	host := core.NewFrame(core.NewBody("tabs"))
	calls := 0
	n := closeTabsFixture(func(ui.TabCloseEvent) { calls++ })
	root := ui.Node{ID: "root", Kind: ui.Disclosure, Text: "Documents", Checked: true, Children: []ui.Node{n}}
	r, err := reconcile(host, nil, root, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	defer disposeControlTree(r)
	tabs := findRecord(r, "tabs")
	binding := tabs.control.tabs.bindings["a"]
	close := tabCloseButton(binding)
	draft := findRecord(r, "draft").widget.(*core.TextField)
	if !draft.ApplyNativeEdit("pending draft", 13, 13, -1, -1, "insert") {
		t.Fatal("native draft setup failed")
	}
	close.Send(events.Click)
	root.Checked = false
	r, err = reconcile(host, r, root, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	a.Drain()
	if calls != 0 {
		t.Fatal("hidden close delivered")
	}
	root.Checked = true
	root.Children[0].Options[0].Disabled = true
	r, err = reconcile(host, r, root, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	close.Send(events.Click)
	a.Drain()
	if calls != 0 {
		t.Fatal("disabled option close delivered")
	}
	root.Children[0].Options[0].Disabled = false
	r, err = reconcile(host, r, root, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	// Accepted removal moves the original draft out before deleting the old page.
	next := ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "draft", Kind: ui.TextField, Text: "accepted"}, {ID: "tabs", Kind: ui.Tabs, SelectedID: "b", Options: []ui.Option{{ID: "b", Label: "Second", Closable: true}}, TabClose: n.TabClose, Children: []ui.Node{n.Children[1]}}}}
	close.Send(events.Click)
	a.Drain()
	if calls != 1 {
		t.Fatal("enabled close missing")
	}
	r, err = reconcile(host, r, next, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	if findRecord(r, "draft").widget != draft || draft.EditingState().Text != "pending draft" || findRecord(r, "tabs").widget.(*core.Tabs).NumTabs() != 1 {
		t.Fatal("accepted close destroyed retained reparented draft")
	}
	close.Send(events.Click)
	a.Drain()
	if calls != 1 {
		t.Fatal("late detached close reenabled unmanaged behavior")
	}
}
func TestTabCloseQueueRefusalConsumesWithoutDeleting(t *testing.T) {
	a, _ := newAXTest(t, 1)
	host := core.NewFrame(core.NewBody("tabs"))
	calls := 0
	n := closeTabsFixture(func(ui.TabCloseEvent) { calls++ })
	r, err := reconcile(host, nil, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	defer disposeControlTree(r)
	if err = a.Post(func() {}); err != nil {
		t.Fatal(err)
	}
	binding := r.control.tabs.bindings["a"]
	close := tabCloseButton(binding)
	e := events.NewMouse(events.Click, events.Left, 0, close.Geom.TotalBBox.Min)
	close.SendEvent(e)
	if !e.IsHandled() || r.widget.(*core.Tabs).NumTabs() != 2 {
		t.Fatal("saturated native close was destructive/unhandled")
	}
	a.Drain()
	r, err = reconcile(host, r, n, a, "ax")
	if err != nil {
		t.Fatal(err)
	}
	if calls != 0 || r.widget.(*core.Tabs).NumTabs() != 2 || r.widget.AsTree().Property("vellum.control-error") == nil {
		t.Fatal("queue refusal lost control state/error")
	}
}
