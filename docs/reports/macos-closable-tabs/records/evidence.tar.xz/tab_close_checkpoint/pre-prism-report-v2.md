# Controlled document tabs

The public Tabs descriptor now supports per-option Closable and a typed TabClose
owner callback. A close request preserves native selection, pages and drafts until
the application accepts removal in its next view. The last-page empty state belongs
to the application. The gallery demonstrates rejection, reopening and closing all
documents; the relocated SDK fixture consumes the public close API.

Owned Core patch 0058 delegates a managed close before parent/index lookup or
native deletion, consumes the gesture, and supplies the actual private button.
The nil seam retains unmanaged behavior; retired managed callbacks stay guarded.
Tab/private-button identity, immutable capabilities and atomic dialog lifetime
scopes reject stale requests. Independent Workbench roots inherit enclosing
visibility/scopes. Queued callbacks use owner snapshots and current callbacks,
without reading or modifying originating native trees during peer-window drains.
The normal existing reconcile traversal publishes capabilities; private artwork
rebuilds only when its presentation changes.

## Evidence and limits

Focused real software pointer and Delete/Backspace routing, semantic press,
selection isolation, rejected/accepted closes, draft reparenting, native-parent
retirement, disabled/hide/reopen guards and queue saturation pass. The complete
software screenshot captures the initial two document-tab close buttons with
readable labels and content; subsequent assertions establish rejected page retention. Native-object construction creates no window.
Three intentionally broken variants fail the destructive fallback, actual-private
button identity and dismissed-dialog capability assertions. Full adapter and
portable race tests, vet, preparation tests, 28 SDK fixtures and native build pass.
Internal source/evidence review and Prism Anthropic Claude Sonnet 5.5 review
precede commit. The first Prism review found deferred test cleanup capturing an
old reconciled root; closures now dispose the final tree and the full adapter
race rerun passes. A sandbox-only rerun passed the adapter package but could not
bind the workbench fixture socket; the final rerun used the required local access.
A follow-up review is required before commit.

The initial internal review found dialog dismissal and a private-ID collision.
The direct fix introduced atomic dialog lifetime tokens and reserved tab-close:.
A second review found Workbench panel roots dropping inherited scopes. The final
fix publishes immutable context at the Extension boundary and propagates it into
independent roots. Direct Dialog→Tabs and Dialog→Workbench→Tabs dismissal checks
pass under race, including refusal before owner drain and independent panel refresh.
Original reviews and defective source copies are retained. Initial compile errors
from incorrect key/test helper names are retained beside corrected checks. The
Core seam test initially referenced the wrong widget-name accessor; its corrected
race check passes. Only that prepared test leaf changed after the broad checks;
production source hashes remain identical, and both native builds are byte equal.
The temporary cache lacked a Core test dependency; the complete installed cache
was used for the corrected Core test. The
Core seam test initially referenced the wrong widget-name accessor; its corrected
race check passes. Only that prepared test leaf changed after the broad checks;
production source hashes remain identical, and both native builds are byte equal.
The temporary cache lacked a Core test dependency; the complete installed cache
was used for the corrected Core test. The
Core seam test initially referenced the wrong widget-name accessor; its corrected
race check passes. Only that prepared test leaf changed after the broad checks;
production source hashes remain identical, and both native builds are byte equal.
The temporary cache lacked a Core test dependency; the complete installed cache
was used for the corrected Core test.

Normal preparation reproduces the seam and one Core regression through all 58
patch numbers, adding one leaf (6,208 → 6,209) while preserving every other prepared
file. Raw producers, source versions, failures, screenshots, final results and
reviews will be retained in the indexed records archive before commit. Native
binaries are excluded with their hashes retained.

This checkpoint does not run a desktop window, OS input, preferences or clipboard.
Physical input, human VoiceOver, actual native attachment/long-run retention and
performance remain unqualified. Native 4/6 ms frame targets still fail; full
P6/P11, complete retention (prior run failed after 343 windows), native/GPU memory
and Mac distribution remain open. GPU scene rendering remains opt-in. The user has now authorized a quiet-machine
native test campaign, which will be recorded separately against committed source.
