APPROVED_SOURCE. TABS-01/02/03 resolved; prior NEEDS_FIX certificates are preserved.

The captured dialog scope closes before native parking. Fresh immutable Extension context is set before Sync, so independent Workbench panels inherit complete enclosing scopes; closed scopes force hidden state. Queued/native delivery reads captured atomics and owner fields only. The nested inert regression and matching parent race receipt establish the boundary. tab-close: is reserved.

Ten candidate leaves and two prepared Core outputs are bound. Later optional software PNG export is source-reviewed but not relabeled as executed by the earlier Workbench receipt. Whole owned patch/spec/gallery/SDK review and broader gates remain separate. No reviewer tests/build/native/UI/provider execution or live acceptance is claimed.
