"""Offline sampled process-allocation attribution; never timing qualification."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current_grid_scope',W/'run.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
r=json.loads((W/'result.json').read_text());q.h.need(r['result']=='MEASURED_FULL_CURRENT_TABLE_MATRIX_AND_SEPARATE_DIAGNOSTICS','completed native scope')
pins={str(Path(__file__)):q.h.sha(__file__),str(W/'run.py'):q.h.sha(W/'run.py'),str(W/'result.json'):q.h.sha(W/'result.json'),str(q.h.GO):q.h.sha(q.h.GO)}
inputs={}
for mode in['cpu','gpu']:
 for binary in['original','current']:
  name='allocation-'+mode+'-'+binary;p=W/(name+'-result.json');d=json.loads(p.read_text());q.h.need(d['result']=='PASS_SCOPED_CURRENT_GRID_CASE','successful allocation capture');pins[str(p)]=q.h.sha(p)
  for f in d['profiles'].values():q.h.need(q.h.sha(f['path'])==f['sha256'],'profile identity');pins[f['path']]=f['sha256']
  inputs[name]=d['profiles']
out=W/'pprof';q.h.need(not out.exists(),'fresh offline attribution');out.mkdir()
def stable():return all(q.h.sha(k)==z for k,z in pins.items())
commands=[]
for name,profiles in inputs.items():
 for metric,cumulative in[('alloc_space',False),('alloc_objects',False),('alloc_space',True)]:
  key=name+'-'+metric+('-cum'if cumulative else'')
  args=[str(q.h.GO),'tool','pprof','-top','-nodecount=40','-symbolize=none','-sample_index='+metric,'-base',profiles['before']['path']]
  if cumulative:args+=['-cum']
  args+=[profiles['after']['path']]
  argv=['/usr/bin/sandbox-exec','-p',q.h.PROFILE,'/usr/bin/env','GOPROXY=off','GOSUMDB=off','GOTOOLCHAIN=local',*args]
  d=q.g.execute(argv,q.h.T,out/key,lambda:(W/'stop-analysis').exists(),stable,timeout=60,limit=2<<20)
  commands.append({'name':key,'run':d});(out/'receipt.json').write_text(json.dumps({'native_executed':False,'scope':'Sampled cumulative Go allocations minus warmed baseline; includes observers, concurrent adapter and profile encoding, not framework-only/native/GPU/retained-memory or timing proof.','inputs':pins,'commands':commands},indent=2)+'\n')
  q.h.need(d['exit_code']==0 and d['error']is None and not d['observation_errors']and d['pins_stable']and d['logs_complete']and d['owned']['group_absent']and not d['owned']['errors'],'owned offline pprof '+key)
  print(json.dumps({'name':key,'exit_code':0,'group_absent':True}),flush=True)
