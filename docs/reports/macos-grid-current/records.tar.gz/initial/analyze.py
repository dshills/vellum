"""Recompute matrix distributions and paired geometry from retained raw streams."""
from pathlib import Path
import hashlib,json,math,statistics
W=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dist(values):
 x=sorted(values);assert x and all(type(v)is int and v>=0 for v in x)
 return {k:x[math.ceil(p*len(x))-1]for k,p in[('p50',.5),('p95',.95),('p99',.99),('max',1)]}
p=read(W/'plan.json');result=read(W/'result.json');assert result['result']=='MEASURED_FULL_CURRENT_TABLE_MATRIX_AND_SEPARATE_DIAGNOSTICS'
assert result['completed']==list(p['cases'])and(W/'stop-live').exists()
inputs={n:sha(W/n)for n in['plan.json','admission.json','result.json','analyze.py']}
groups={};summaries={};geometries={};ordinary_samples=0
for name,case in p['cases'].items():
 r=read(W/(name+'-result.json'));assert r['result']=='PASS_SCOPED_CURRENT_GRID_CASE'and r['case']==case and r['lease_held_through_cleanup']and(W/('stop-'+name)).exists()
 run=r['run'];assert run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
 for stream in['stdout','stderr']:
  f=W/name/stream;assert sha(f)==run['logs'][stream]['sha256']and f.stat().st_size==run['logs'][stream]['bytes'];inputs[str(f.relative_to(W))]=sha(f)
 assert not(W/name/'stderr').read_bytes()
 raw=[json.loads(x)for x in(W/name/'stdout').read_text().splitlines()if x.strip()]
 samples=[r for r in raw if r['event']=='grid.perf.sample'];assert len(samples)==120
 ui=dist([r['metrics']['ui_work_ns']for r in samples]);alloc=dist([r['go_process_alloc_bytes']for r in samples]);geo=[r['geometry']for r in samples]
 assert all(ui[k]==r['summary']['ui_work_ns'][k]for k in ui)
 assert all(alloc[k]==r['summary']['allocation_bytes'][k]for k in alloc)
 assert geo==r['summary']['geometry'];geometries[name]=geo
 end=next(e for e in raw if e['event']=='grid.perf.end')
 summary={'ui_work_ns':ui,'allocation_bytes':alloc,'terminal_heap_bytes':end['memory_after_measured_gc']['HeapAlloc'],'samples':120,'raw_sha256':sha(W/name/'stdout'),'owned_group':run['owned']['group'],'diagnostic':case['diagnostic'],'allocation_profile':case['allocation']}
 summaries[name]=summary
 if case['diagnostic']:
  assert r['summary']['diagnostic_surface_frames']==120
 elif not case['allocation']:
  assert not any(e['event']=='grid.surface.diagnostic'for e in raw)
  key=('gpu'if case['gpu']else'cpu')+('-variable-'if case['variable']else'-fixed-')+str(case['rows']);groups.setdefault(key,[]).append(summary);ordinary_samples+=120
 inputs[name+'-result.json']=sha(W/(name+'-result.json'))
paired=[]
for name,case in p['cases'].items():
 if case['rows']==1000000:
  other=name.replace('1000000','10000');assert geometries[name]==geometries[other],(name,'paired stored-row geometry differs');paired.append({'first':other,'second':name,'events':120})
table={}
for key,runs in groups.items():
 assert len(runs)==5
 table[key]={'runs':runs,'median_run_p95_ns':statistics.median(x['ui_work_ns']['p95']for x in runs),'median_run_p99_ns':statistics.median(x['ui_work_ns']['p99']for x in runs),'worst_run_p95_ns':max(x['ui_work_ns']['p95']for x in runs),'worst_run_p99_ns':max(x['ui_work_ns']['p99']for x in runs),'p95_4ms_pass_runs':sum(x['ui_work_ns']['p95']<=4000000 for x in runs),'p99_6ms_pass_runs':sum(x['ui_work_ns']['p99']<=6000000 for x in runs),'median_run_allocation_p50_bytes':statistics.median(x['allocation_bytes']['p50']for x in runs),'median_terminal_process_go_heap_bytes':statistics.median(x['terminal_heap_bytes']for x in runs)}
assert ordinary_samples==4800 and len(groups)==8 and len(paired)==24
d={'result':'RECOMPUTED_CURRENT_TABLE_MATRIX','source_commit':p['head'],'inputs':inputs,'cases':table,'all52_summaries':summaries,'paired_10k_million_geometry':paired,'ordinary_samples':ordinary_samples,'full_matrix_target_pass':all(v['p95_4ms_pass_runs']==v['p99_6ms_pass_runs']==5 for v in table.values()),'physical_input_qualified':False,'presentation_qualified':False,'resource_endurance_qualified':False,'full_mac_qualified':False,'scope':'Nearest-rank percentiles from each run, then median across five runs; no pooled percentiles. Eight observer-enabled route runs and four sampled allocation processes excluded from ordinary timing. Current Go code over retained SDK source-built native archive, not refreshed public SDK or default native archive qualification.'}
(W/'analysis.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'samples':ordinary_samples,'paired_geometry_cases':len(paired),'full_matrix_target_pass':d['full_matrix_target_pass'],'cases':{k:{n:v[n]for n in['median_run_p95_ns','median_run_p99_ns','p95_4ms_pass_runs','p99_6ms_pass_runs']}for k,v in table.items()}},indent=2))
