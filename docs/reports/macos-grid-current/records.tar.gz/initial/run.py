"""Current compiled Go route: full table matrix and separate allocation diagnostics."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
S=W.parent/'macos-grid-cell-surface-410a98c'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
prior=load('current_grid_prior',S/'native.py');h=prior.h;g=prior.g;b=prior.b;v=load('current_grid_validator',W/'validate.py')
HEAD='a2b4143578631cbc57f29fcc1ee18b513e4567a3'
sys.path.insert(0,str(h.T/'scripts'))
from child_process import run_child
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def vector(root):
 out={}
 for p in root.rglob('*'):
  h.need(not p.is_symlink(),'regular source tree '+str(p))
  if p.is_file():out[p.relative_to(root).as_posix()]=h.sha(p)
 return out
def source(root):
 h.need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean current checkout')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1]
 h.need(len(names)==5320,'bounded current tracked source')
 return {n:h.sha(root/n)for n in names}
def prepared(root):
 return {module+'/'+n:z for module in['upstream','typesetting']for n,z in vector(root/'drivers/cogent/build'/module).items()}
def cases():
 out={}
 for variable in[False,True]:
  for rows in[10000,1000000]:
   for gpu in[False,True]:
    key=('gpu'if gpu else'cpu')+('-variable-'if variable else'-fixed-')+str(rows)
    out['diagnostic-'+key]={'gpu':gpu,'variable':variable,'rows':rows,'diagnostic':True,'allocation':False,'binary':'diagnostic'}
 for rep in range(1,6):
  for variable in[False,True]:
   for rows in[10000,1000000]:
    for gpu in[False,True]:
     key=('gpu'if gpu else'cpu')+('-variable-'if variable else'-fixed-')+str(rows)
     out[key+'-run'+str(rep)]={'gpu':gpu,'variable':variable,'rows':rows,'diagnostic':False,'allocation':False,'binary':'current','repetition':rep}
 for gpu in[False,True]:
  for binary in['original','current']:
   out['allocation-'+('gpu-'if gpu else'cpu-')+binary]={'gpu':gpu,'variable':False,'rows':10000,'diagnostic':False,'allocation':True,'binary':binary}
 return out
CASES=cases()
def prepare():
 h.need(not(W/'plan.json').exists()and not(W/'stop-live').exists(),'fresh scope')
 old=json.loads((S/'native-plan.json').read_text());final=json.loads((S/'final-native/plan.json').read_text());sdk=Path(old['sdk'])
 h.need(vector(sdk)==old['sdk_files'],'retained SDK exact')
 current=source(h.C);h.need(source(h.T)==current,'C/T current source parity')
 dep=prepared(h.C);h.need(prepared(h.T)==dep==final['isolated_prepared'],'current exact stage80')
 installed=json.loads((S/'integration-installed-v4.json').read_text())
 h.need(all(h.sha(h.C/n)==z for n,z in installed['files'].items()),'committed reviewed source')
 # Complete diff classification establishes current Go runtime correspondence.
 changed=git(h.C,'diff','--name-only',h.HEAD,HEAD).decode().splitlines()
 runtime=[]
 for n in changed:
  if n.startswith(('docs/','specs/','scripts/'))or n.endswith('_test.go')or n.endswith('.py')or n.startswith('drivers/cogent/native/'):continue
  h.need(n in installed['files'] and h.sha(S/'integration'/n)==current[n],'current overlay runtime correspondence '+n);runtime.append(n)
 h.need(set(runtime)=={'drivers/cogent/grid.go','drivers/cogent/grid_geometry.go','drivers/cogent/grid_scroll.go','drivers/cogent/grid_surface.go'},'exact runtime delta classification')
 binaries={'original':old['binaries']['original'],'current':final['ordinary_binary'],'diagnostic':final['binary']}
 for value in binaries.values():h.need(h.sha(value['path'])==value['sha256'],'compiled binary pinned')
 # Builds predate test-only changes; require every production overlay byte.
 for receipt in['integrated-build-v3','integrated-diag-build-v2']:
  r=json.loads((S/(receipt+'.json')).read_text());h.need(r['exit_code']==0 and r['pins_stable']and r['logs_complete']and r['owned']['group_absent']and not r['owned']['errors'],'terminal build')
  for p in(S/'integration').rglob('*.go'):
   if not p.name.endswith('_test.go'):h.need(r['source_pins'].get(str(p))==h.sha(p),'compiled production overlay '+str(p))
 paths=[Path(__file__),W/'validate.py',W/'controls.py',W/'controls.json',h.GO,Path(h.__file__),h.GUARD,S/'native.py',S/'validate.py',prior.B/'run.py',prior.B/'validate.py',prior.B/'owned-executor.py',sdk/'scripts/benchmark-grid.py',h.T/'scripts/child_process.py',h.T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 paths+=[S/n for n in['integration-installed-v4.json','internal-final-review.json','internal-archive-review.json','committed.json','promoted-prepared.json','integrated-build-v3.json','integrated-diag-build-v2.json','integration/overlay.json','integrated-diagnostic-overlay.json','diagnostic-grid-geometry.go']]
 paths+=[p for p in(S/'integration').rglob('*.go')]
 now=datetime.datetime.now(datetime.timezone.utc)
 plan={'head':HEAD,'created_utc':now.isoformat(),'launch_deadline_utc':(now+datetime.timedelta(minutes=45)).isoformat(),'source':current,'prepared':dep,'sdk':str(sdk),'sdk_files':old['sdk_files'],'pins':{str(p):h.sha(p)for p in paths},'binaries':binaries,'runtime_delta':runtime,'cases':CASES,'scope':'8 observer-enabled functional route cases,40 separate ordinary runs (8cases x5freshprocesses x120samples/128warm),4 separate sampled allocation profile runs (old/current,CPU/GPU10kfixed). No diagnostics in ordinary timing; no physical input/presentation/M4 or full Mac claim. Current Go implementation over unchanged retained SDK with verified source-built786a native archive; not default checkout7d8 archive qualification or a refreshed SDK. Fresh shared lease, percase+scope stop,330s/8MiB streams/ownedgroup retirement. Any failure/cancel seals scope; no rerun. Results measured even when unchanged4ms/6ms targets fail.'}
 (W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(W/'plan.json'),'cases':len(CASES),'source_files':len(current),'prepared_files':len(dep),'native_executed':False}))
def run():
 raw=(W/'plan.json').read_bytes();araw=(W/'admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw);stop=W/'stop-live';sdk=Path(p['sdk'])
 h.need(a['approved']and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'reviewed exact scope');h.need(not stop.exists()and not(W/'result.json').exists(),'fresh execution')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==araw and all(h.sha(k)==z for k,z in p['pins'].items())and all(h.sha(e['path'])==e['sha256']for e in p['binaries'].values())
 def boundary():
  h.need(not stop.exists()and stable(),'stop and exact pins');h.need(source(h.C)==source(h.T)==p['source']and prepared(h.C)==prepared(h.T)==p['prepared']and vector(sdk)==p['sdk_files'],'whole current source/prepared/SDK unchanged')
 def interrupted(signum,frame):raise InterruptedError('matrix signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted);result={'result':'INCOMPLETE','error':None,'completed':[],'native_executed':False,'full_mac_qualified':False}
 try:
  with g.LiveLease()as lease:
   for name,case in p['cases'].items():
    boundary();h.need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease and launch deadline');h.need(not(W/(name+'-result.json')).exists()and not(W/('stop-'+name)).exists(),'fresh case')
    exe=p['binaries'][case['binary']];args=[exe['path'],'-perf','-rows='+str(case['rows']),'-perf-warmup=128','-perf-samples=120']
    if case['variable']:args+=['-variable-rows']
    if case['gpu']:args+=['-gpu-scene']
    if case['diagnostic']:args+=['-perf-source-details']
    prefix=W/(name+'-alloc')
    if case['allocation']:args+=['-perf-alloc-profile='+str(prefix)]
    cr={'case':case,'result':'INCOMPLETE','error':None}
    try:
     r=g.execute(args,sdk/'examples/loadedgrid',W/name,lambda:stop.exists()or(W/('stop-'+name)).exists(),stable,timeout=330,limit=8<<20);cr['run']=r;result['native_executed']|=r['created']
     h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned terminal case '+name)
     h.need(not(W/name/'stderr').read_bytes(),'empty native stderr');summary=v.validate((W/name/'stdout').read_text(),case,sdk)
     if case['allocation']:
      cr['profiles']={}
      for suffix in['before','after']:
       f=Path(str(prefix)+'.'+suffix+'.pprof');h.need(f.is_file()and not f.is_symlink()and 0<f.stat().st_size<=64<<20,'bounded profile');cr['profiles'][suffix]={'path':str(f),'bytes':f.stat().st_size,'sha256':h.sha(f)}
     boundary();h.need(lease.held(),'lease through cleanup');cr.update(result='PASS_SCOPED_CURRENT_GRID_CASE',summary=summary,lease_held_through_cleanup=True);result['completed'].append(name)
    except BaseException as e:cr.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
    finally:
     (W/('stop-'+name)).touch();cr['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/(name+'-result.json')).write_text(json.dumps(cr,indent=2)+'\n');print(json.dumps({'case':name,'result':cr['result'],'error':cr['error'],'completed':len(result['completed']),'p95_ms':cr.get('summary',{}).get('ui_work_ns',{}).get('p95',0)/1e6}),flush=True)
   result['result']='MEASURED_FULL_CURRENT_TABLE_MATRIX_AND_SEPARATE_DIAGNOSTICS'
 except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':result['result'],'completed':len(result['completed']),'error':result['error']}),flush=True)
 if result['error']:sys.exit(1)
if __name__=='__main__':h.need(sys.argv[1:]in[['prepare'],['run']],'known fixed phase');prepare()if sys.argv[1]=='prepare'else run()
