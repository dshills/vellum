"""Source-bound SDK table validation; diagnostics cannot qualify ordinary timing."""
from pathlib import Path
import hashlib,importlib.util,json

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def need(value,message):
 if not value:raise ValueError(message)

def validate(raw,case,sdk):
 b=load('surface_table_metrics',sdk/'scripts/benchmark-grid.py');events=[json.loads(x)for x in raw.splitlines()if x.strip()]
 ordinary=[x for x in events if x.get('event')!='grid.surface.diagnostic']
 if not case['diagnostic']:need(len(ordinary)==len(events),'no diagnostic in ordinary timing')
 rows=b.validate_records(ordinary,case['rows'],case['variable'],120,False,allow_source_details=case['diagnostic'],allow_alloc_profile=case.get('allocation',False),gpu_scene_rendering=case['gpu'])
 setup,ready,end=ordinary[0],ordinary[1],ordinary[-1]
 need(setup.get('alloc_profile',False) is case.get('allocation',False) and setup.get('source_details',False) is case['diagnostic'],'exact diagnostic mode')
 need(setup['go_version']=='go1.25.6' and setup['build_settings'].get('-race','false')!='true' and setup['build_settings'].get('GOOS')=='darwin' and setup['build_settings'].get('GOARCH')=='arm64','optimized minimum toolchain')
 need(setup['embedded_regular_font_sha256']==hashlib.sha256((sdk/'drivers/cogent/build/upstream/text/fonts/noto/NotoSans-Regular.ttf').read_bytes()).hexdigest(),'exact font')
 need(ready['warmup']==128 and setup['geometry_persistence_disabled_in_fixture'] is True,'closed warmup and no window persistence')
 window=ready['native_window'];need(window['render']['Size']=={'X':1519,'Y':1266} and window['window_logical_dpi']==162,'unchanged actual native fixture')
 matched=[];pending=[]
 for event in events:
  if event['event']=='grid.surface.diagnostic':pending.append(event)
  elif event['event']=='grid.perf.ready':pending=[]
  elif event['event']=='grid.perf.sample':
   if case['diagnostic']:
    exact=[x for x in pending if (x['generation'],x['frame'])==(event['generation'],event['frame'])]
    need(len(exact)==1,'one exact completed surface observation per measured frame');x=exact[0]
    need(x['complete'] is True and x['native_children']==x['native_body_cells']==0 and x['value_layouts']==x['shapes']==event['geometry']['materialized_cells'] and x['value_layouts']>=400,'actual positive value route without body widgets')
    details=event['native_sample']['SourceDetails'];records=details['Records']
    # Ticket diagnostics include intermediate compositions. Exactly the final
    # scene must prove a fresh update; an accepted earlier reuse is not fallback.
    final=[r for r in records if r['Composition']==details['Compositions'] and r['Kind']==1]
    need(len(final)==1,'exactly one final scene source')
    if case['gpu']:
     hosts=[r['SceneHost']for r in records if r['SceneHost']['Available']]
     need(hosts and all(h['DrawAccepted'] and not h['Fallback'] and h['InputWriteErrors']==0 for h in hosts),'all GPU compositions accepted without fallback or write error')
     h=final[0]['SceneHost']
     need(h['Available'] and h['DrawAccepted'] and not h['Reused'] and not h['Fallback'] and h['CaptureAttempted'] and h['EncodeAttempted'] and h['InputAttempted'] and h['InputWriteAttempts']==5 and h['InputWriteErrors']==0 and h['LogicalInputBytes']>0 and h['QueueSubmitAttempts']==1 and final[0]['ImageChanged'],'positive fresh final GPU scene route')
    else:
     need(all(not r['SceneHost']['Available']for r in records),'no GPU host in CPU source route')
     need(all(r['RasterAvailable']and r['CopyAvailable']and r['ImageChanged']and r['ImageWidth']>0 and r['ImageHeight']>0 and r['SetFromGoImageAttempts']==1 and r['LogicalUploadRGBABytes']==r['ImageWidth']*r['ImageHeight']*4 for r in final),'positive fresh final CPU raster and copy source')
    matched.append(x)
   pending=[]
 summary={'samples':len(rows),'ui_work_ns':b.distribution([r['metrics']['ui_work_ns']for r in rows]),'phase_ns':{k:b.distribution([r['metrics'][k]for r in rows])for k in b.METRICS},'allocation_bytes':b.distribution([r['go_process_alloc_bytes']for r in rows]),'terminal_heap_bytes':end['memory_after_measured_gc']['HeapAlloc'],'geometry':[r['geometry']for r in rows],'diagnostic_surface_frames':len(matched),'p95_target_met':None if case['diagnostic'] or case.get('allocation',False) else b.distribution([r['metrics']['ui_work_ns']for r in rows])['p95']<=4000000,'full_mac_qualified':False,'physical_input_qualified':False}
 return summary
