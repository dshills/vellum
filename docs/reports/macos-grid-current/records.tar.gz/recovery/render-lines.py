"""Inspect the sampled allocation site without rebuilding or running the app."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('render_lines_scope',W/'run.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
r=json.loads((W/'allocation-cpu-current-result.json').read_text());assert r['result']=='PASS_SCOPED_CURRENT_GRID_CASE'
source=q.S/'integration/drivers/cogent/grid_surface.go'
pins={str(Path(__file__)):q.h.sha(__file__),str(source):q.h.sha(source),str(q.h.GO):q.h.sha(q.h.GO),str(W/'allocation-cpu-current-result.json'):q.h.sha(W/'allocation-cpu-current-result.json')}
for p in r['profiles'].values():assert q.h.sha(p['path'])==p['sha256'];pins[p['path']]=p['sha256']
args=['/usr/bin/sandbox-exec','-p',q.h.PROFILE,'/usr/bin/env','GOPROXY=off','GOSUMDB=off','GOTOOLCHAIN=local',str(q.h.GO),'tool','pprof','-list=renderCellSurface','-source_path='+str(source.parent),'-symbolize=none','-sample_index=alloc_space','-base',r['profiles']['before']['path'],r['profiles']['after']['path']]
d=q.g.execute(args,q.h.T,W/'render-lines',lambda:False,lambda:all(q.h.sha(k)==z for k,z in pins.items()),timeout=60,limit=2<<20)
(W/'render-lines.json').write_text(json.dumps({'native_executed':False,'source':str(source),'inputs':pins,'run':d},indent=2)+'\n')
assert d['exit_code']==0 and d['error']is None and not d['observation_errors']and d['pins_stable']and d['logs_complete']and d['owned']['group_absent']and not d['owned']['errors']
print((W/'render-lines/stdout').read_text())
