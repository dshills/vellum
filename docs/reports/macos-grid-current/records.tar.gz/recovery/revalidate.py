"""Revalidate sealed raw diagnostics, preserving the original failed result."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;O=W.parent/'macos-grid-current-a2b4143'
s=importlib.util.spec_from_file_location('recovery_grid_scope',W/'run.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
def read(p):return json.loads(p.read_text())
p=read(O/'plan.json');r=read(O/'result.json');assert r['result']=='FAILED_OR_CANCELED'and len(r['completed'])==5 and r['error']['message']=='positive fresh GPU scene route'and(O/'stop-live').exists()
assert q.source(q.h.C)==q.source(q.h.T)==p['source']and q.prepared(q.h.C)==q.prepared(q.h.T)==p['prepared']and q.vector(Path(p['sdk']))==p['sdk_files']
inputs={**p['pins'],**{str(O/n):q.h.sha(O/n)for n in['plan.json','admission.json','result.json','stop-live']}}
results={}
for name,case in list(p['cases'].items())[:6]:
 f=O/(name+'-result.json');d=read(f);run=d['run']
 assert run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
 assert(O/('stop-'+name)).exists()
 for stream in['stdout','stderr']:
  leaf=O/name/stream;assert q.h.sha(leaf)==run['logs'][stream]['sha256']and leaf.stat().st_size==run['logs'][stream]['bytes'];inputs[str(leaf)]=q.h.sha(leaf)
 assert not(O/name/'stderr').read_bytes()
 summary=q.v.validate((O/name/'stdout').read_text(),case,Path(p['sdk']))
 assert summary['diagnostic_surface_frames']==120
 results[name]={'original_recorded_result':d['result'],'original_error':d['error'],'revalidated_final_composition':True,'summary':summary,'group':run['owned']['group'],'recorded_group_absent':True}
 inputs[str(f)]=q.h.sha(f);inputs[str(O/('stop-'+name))]=q.h.sha(O/('stop-'+name))
assert all(q.h.sha(k)==z for k,z in inputs.items())
d={'result':'REVALIDATED_SIX_PRIOR_RAW_RUNS_WITH_FINAL_COMPOSITION_CHECK','native_launched':False,'inputs':inputs,'runs':results,'scope':'Original failed scope/status and all raw bytes remain immutable. Revalidation proves a fresh final scene for each measured ticket; an accepted unchanged intermediate composition is allowed. Original sixth validation failure is preserved, not relabeled as a successful original run. No ordinary timing samples exist in prior scope. New native scope may run only the remaining46 cases after independent admission.'}
(W/'revalidation.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'raw_runs':6,'frames':720,'native_launched':False,'old_failed_scope_preserved':True}))
