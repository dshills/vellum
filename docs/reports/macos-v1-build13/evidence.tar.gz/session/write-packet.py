from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent;D=X.parents[1]/'deliveries/macos-v1-build13-20261027';W=Path('/private/tmp/vellum-macos-coherent-build13-20261027');T=R/'docs/reports/macos-v1-build13'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((X/'final-package.json').read_text());remote=json.loads((X/'reused-remote.json').read_text());head=record['source_commit'];assert all(c['exit_code']==0 for c in record['checks']+record['post_launch_checks'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
T.mkdir(parents=True)
for n in ('final-package.json','native-result.json','sdk-delta.json'):shutil.copyfile(X/n,T/n)
(T/'reused-ci.json').write_text(json.dumps(remote['ci'],indent=2)+'\n');(T/'SHA256SUMS').write_bytes((D/'SHA256SUMS').read_bytes())
for n in ('shell-b2.jpg','shell-a0-after-native-close.jpg'):shutil.copyfile(X/'native'/n,T/n)
assets=[{'file':record['sdk_archive'],'sha256':record['sdk_sha256'],'source_commit':head,'kind':'sdk'}]+[{'file':a['archive'],'sha256':a['archive_sha256'],'source_commit':head,'kind':'app','id':a['id'],'build':'13'} for a in record['apps']]
pub={'schema':1,'source_commit':head,'source_clean_at_production':True,'build':'13','local_delivery':D.name,'assets':assets,'checksum_file':{'file':'SHA256SUMS','sha256':sha(D/'SHA256SUMS')},'destination':{'repository':'dshills/vellum','release_id':remote['remote_release']['id'],'url':remote['remote_release']['url'],'existing_tag':'v1.0.0','existing_tag_commit':remote['remote_release']['target_commitish'],'tag_movement':False,'release_body':'RELEASE_BODY.md'},'historical_audit_sha256':record['audit_record_sha256'],'signing':'ad-hoc (-)','notarized':False,'publication_authorized':False,'uploaded':False,'scope':'Seven new payload archives plus SHA256SUMS, proposed for existing source release as explicitly disclosed build13 packaging revision from 64bf9cf. No tag movement. Prepared Core Go bytes include stage0108 in SDK and every app.'}
(T/'PUBLICATION_SET.json').write_text(json.dumps(pub,indent=2)+'\n');(D/'PUBLICATION_SET.json').write_text(json.dumps(pub,indent=2)+'\n')
private=D/'private';private.mkdir(exist_ok=True)
with tarfile.open(private/'PRE_SIGN_INPUTS.tar.gz','w:gz') as tar:
 for a in record['apps']:
  ad=W/a['id'];tar.add(ad/a['name'],arcname='apps/'+a['id']+'/binary',recursive=False);tar.add(ad/'notices',arcname='apps/'+a['id']+'/notices')
 for slug in ('forma','luma','pulse'):tar.add(W/'icons'/(slug+'.png'),arcname='icons/'+slug+'.png',recursive=False)
(private/'SHA256SUMS').write_text(sha(private/'PRE_SIGN_INPUTS.tar.gz')+'  PRE_SIGN_INPUTS.tar.gz\n')
(T/'private-inputs.json').write_text(json.dumps({'file':'private/PRE_SIGN_INPUTS.tar.gz','sha256':sha(private/'PRE_SIGN_INPUTS.tar.gz'),'scope':'Local-only retained pre-sign binaries, exact notice bodies/inventories and original icons; excluded from upload set.'},indent=2)+'\n')
# Preserve original attempts as evidence, not final status declarations.
items={}
for path in sorted(X.rglob('*')):
 if path.is_file() and path.name!='write-packet.log':items['session/'+str(path.relative_to(X))]=path
for a in record['apps']:
 ad=W/a['id']
 for name in ('build-inputs.json','link-observation.json','native.map'):items['apps/'+a['id']+'/'+name]=ad/name
 items['apps/'+a['id']+'/APP_MANIFEST.json']=ad/'exact'/(a['name']+'.app')/'Contents/Resources/APP_MANIFEST.json'
 items['apps/'+a['id']+'/INVENTORY.json']=ad/'notices/INVENTORY.json'
index=[]
with tarfile.open(T/'evidence.tar.gz','w:gz') as tar:
 for name,path in sorted(items.items()):tar.add(path,arcname=name,recursive=False);index.append({'file':name,'bytes':path.stat().st_size,'sha256':sha(path)})
(T/'evidence-index.json').write_text(json.dumps({'archive':'evidence.tar.gz','sha256':sha(T/'evidence.tar.gz'),'files':index},indent=2)+'\n')
(T/'README.md').write_text(f'''# Coherent macOS v1 build13 — final local candidates

The SDK and all six apps were freshly built from clean green commit
`{head}`. Every app was compiled from the newly exported and independently
verified SDK, including ordinary stage0108 preparation. Features, stable APIs,
backend, experimental options and release/performance policy are unchanged.
This report checkpoint changes no production code.

[Publication packet](PUBLICATION_PACKET.md) · [Exact upload set](PUBLICATION_SET.json)
· [Checksums](SHA256SUMS) · [Package record](final-package.json)
· [Native results](native-result.json) · [Reproduce](REPRODUCE.md).

## Verified

- All three workflows passed on this exact source: [Framework](https://github.com/dshills/vellum/actions/runs/40504082685), [Platform adapters](https://github.com/dshills/vellum/actions/runs/40504082565), [Stable root API](https://github.com/dshills/vellum/actions/runs/40504082914). [Reused results](reused-ci.json) do not claim CI for this later report-only commit.
- Fresh SDK:8,861 checksum-verified files, public producer guards, independent relocated consumer checks, and race-enabled extracted-SDK stage0108 regressions pass. Every SDK file still verifies after building all apps.
- Six builds select Vellum/Core/typesetting/native replacements inside that SDK. Actual external-link maps select native archive786aaad8…. Effective dependency versions/sums and all4,441 selected embeds per app match prior candidates. Original showcase icon PNGs regenerate identically.
- {len(record['checks'])} successful bounded production/consumer commands and12 post-launch strict signature checks. ZIP extraction, version1.0.0/build13, source metadata, pre-sign/signed executables, manifests, notices and archive hashes verify.
- All six exact ZIP-derived app copies render and close on Apple Silicon/macOS26.6.2. Notes uses a fresh disposable profile; the personal notebook is untouched. Widgets' managed Light/Dark controls retain original-color artwork. Forma's poster, Luma's image/filmstrip/histogram and Pulse's chart/table render.
- Shell: native close of edited B2 reveals untouched A0 **before any action in A**, then A closes via its application button. [B2](shell-b2.jpg), [A0](shell-a0-after-native-close.jpg). All six exact executable process paths are absent afterward. Exit codes were not collected and are not invented.

## Distribution delta

[SDK delta](sdk-delta.json) records all changed/added source files. Core's
stage0108 exposure repair and Shell's light chrome/background correction are
now present across the rebuilt delivery, without a manual SDK overlay.
**Prepared Go sources and all executable/archive bytes change.** The old mixed
source proposal and its archives retain their original identities.

All559 bundled dependency declaration/native-notice files, third-party inventory
and native archive are identical. Original notice bodies/component references
are preserved:418 files for Notes/Widgets/Shell,419 for Forma/Luma/Pulse. Only
artifact_sha256 is rebound to each new pre-sign binary; the old binding rejects
it. Both compiled Go Regular/Bold TTF arrays are found directly in each showcase
executable, and the original Bigelow & Holmes font notice remains included.

The collection labels pending/review-required remain unchanged collection
semantics. They are separate from the unchanged approved release/native audit
guard. The [historical audit record](../../../release/macos-v1-distribution-audit.json)
is byte-identical; its exact old binary approval is not silently extended to
these new archives. This final delta is disclosed for the separate owner decision.
No new upstream rights grant is inferred; existing pinned objc2 caveats remain.

## Retained observations and limitations

The deliberately background-launched Notes capture was initially blank; native
Raise displayed correct prose without a model edit. Both captures are retained.
The first Luma close action left its window/process running; a fresh observed
native close retired it. One separate fresh launch followed by a **single**
native close also retired normally. The first process-check failure, intermediate
AX/capture and passing control remain in evidence. No sole cause is assigned.

Two controller errors are retained: an unused historical packet lookup had the
wrong filename after four successful preparation commands; it was removed and
verified outputs reused. The tag check compared an annotated tag object instead
of its peeled commit; the assertion was corrected. Neither changed product
source or weakened a release guard. Successful unittest summaries and requested
codesign replacement messages can appear on stderr with exit0.

Sealed manifests retain producer-time target_runtime=unverified. Final
runtime_result fields in final-package.json refer to native-result.json;
raw pre-launch records retain capture-time not-yet-run values. The
[indexed evidence](evidence-index.json) retains controllers, original logs,
captures and link maps. Local pre-sign inputs are retained separately and are
excluded from the upload set. This is native AX/render/close evidence, not new
physical-pointer, performance, soak, exhaustive-widget or human IME/VoiceOver
qualification. Reuse unchanged prior verification within its original limits.

Other OS/hardware/displays, cross-window canvas drag and downloaded-quarantine
launch remain unqualified. Apps are **ad-hoc signed and unnotarized**. No signing
identity, notarization, security bypass, global setting change, upload, new tag
or tag movement occurred. The v1.0.0 source tag remains4b42fb8. Publication is
pending; the bytes are ready locally in research workspace
`deliveries/{D.name}/`. [Prism review](../../reviews/macos-v1-build13/README.md).
''')
(T/'PUBLICATION_PACKET.md').write_text(f'''# Final publication packet — build13, unpublished

[PUBLICATION_SET.json](PUBLICATION_SET.json) and [SHA256SUMS](SHA256SUMS) name the
exact **seven new payload archives**, all built from clean green source
`{head}`. Each app has version1.0.0/build13 and is compiled from the new SDK,
including stage0108. Use only durable `deliveries/{D.name}/` files.

## Proposed destination and text

Attach the seven payloads **plus SHA256SUMS** to the existing
[Vellum v1.0.0 source release](https://github.com/dshills/vellum/releases/tag/v1.0.0)
(release id424773085), as a disclosed build13 packaging revision. Use the exact
[proposed replacement release body](RELEASE_BODY.md). The observed release has
no attached assets. This is a proposal, not authorization to upload or overwrite.

The source tag stays at4b42fb8. Do not claim its automatic source archives contain
64bf9cf or stage0108. No native-module tags are proposed. Build13 filename
suffixes distinguish this set from held historical candidates.

The baseline approved audit remains byte-identical. The [report](README.md) and
[delta](sdk-delta.json) disclose repaired prepared-Go source and new binary/archive
identities. Original dependencies, embeds, native archive, artwork and notices
are unchanged; new exact executable bindings verify. Old exact-archive approval
is not inferred for these bytes. Both public producer guards remain enforced.

Apps use the **ad-hoc signed, unnotarized developer-download** route.
Downloaded-quarantine launch, human IME/VoiceOver and other hosts/displays remain
unqualified. Developer ID signing, notarization and security changes are excluded.

## Remaining final decision

The owner must authorize these exact payload hashes, checksum file, destination,
release text and disclosed route. No asset upload is performed by this checkpoint.
After authorization:

1. Recheck every local file by its named hash; recheck release id, existing assets and unchanged tag commit. Stop on unexpected conflicts rather than overwrite.
2. Upload only seven listed archives and SHA256SUMS. Exclude manifests, evidence, private pre-sign inputs and old candidate archives.
3. Download uploaded bytes, verify their hashes and update current links/status. Preserve the tag and historical audit/report bytes.

[Delivery instructions and limitations](DELIVERY_README.md).
publication_authorized=false and uploaded=false remain accurate.
''')
body=remote['prior_release_body'];start=body.index('## Downloads and distribution');end=body.index('## CI for this release commit',start)
replacement=f'''## Downloads — macOS ARM64 build13 packaging revision

The original v1.0.0 source tag remains **4b42fb89948b8abf0f2f65970fb5980987c1af0c**.
The attached SDK and all six apps are built from later green source
**{head}**. This is a disclosed build13 packaging revision with version1.0.0
metadata; the source tag and automatic tagged-source archives are unchanged.
The SDK and every app include the window-exposure repair.

Downloads: Vellum Notes, Vellum Mac Widgets, Vellum Mac Shell, Forma, Luma,
Pulse and a relocatable Darwin ARM64 SDK. Verify the exact archives using
SHA256SUMS before extraction. SDK consumers need Go1.25.6 and Xcode Command Line
Tools. Use the included scripts/new-app.py generator and SDK-local replacements;
do not run dependency preparation over the already prepared SDK.

The baseline distribution audit is owner-approved; dependency/native/font/artwork
notices are preserved. The final payload decision covers this disclosed revision
and exact hashes; it does not rewrite historical audit records. Apps are
**ad-hoc signed and unnotarized developer downloads**. Downloaded-quarantine
launch is unqualified. No Developer ID, notarization or security-policy change
is used. Human IME/VoiceOver, other hosts/displays and broader GPU workloads
remain unqualified. Notes is local plain text; the showcase data/artwork are
offline fixtures that reset on launch. Existing support limits remain in effect.

Independent SDK consumption, extracted-SDK exposure regressions, actual app
rendering/close, edited-B-to-untouched-A Shell exposure, signatures, exact notice
bindings and final checksums passed. Native AX/captures do not establish human
accessibility or physical-pointer qualification. One first Luma close observation
needed a fresh native target; an independent single-close control passed.

Build-source CI: [Framework](https://github.com/dshills/vellum/actions/runs/40504082685),
[Platform adapters](https://github.com/dshills/vellum/actions/runs/40504082565),
[Stable root API](https://github.com/dshills/vellum/actions/runs/40504082914).

'''
(T/'RELEASE_BODY.md').write_text(body[:start]+replacement+body[end:])
readme='''# Vellum macOS v1 — build13 local publication candidates

All seven archives were built from64bf9cfbb9cfb57d96e1aecd0adad01239ca3c7a.
Each app is version1.0.0/build13. No v1 native assets have been uploaded.

Verify in this directory before extraction: `shasum -a 256 -c SHA256SUMS`.
Extract an app ZIP with Archive Utility, then launch the extracted app. The
apps are ad-hoc signed and unnotarized; downloaded-quarantine launch is
unqualified. No security bypass is provided. private/ contains retained local
inputs, excluded from proposed downloads. Native checks used exact ZIP-derived
copies on Apple Silicon/macOS26.6.2.

- Notes: local plain-text notebook, folders/search, native toolbar, saving,
  recovery and Undo/Redo. Validation used a disposable profile; normal launches
  use the existing personal notebook. Preserve backups of important notebooks.
- Mac Widgets: existing Mac component catalogue and full-color toolbar examples;
  appearance switches are app-scoped.
- Mac Shell: independent A/B document toolbars. Edit B, then close it; A keeps
  its own count. The exposure repair is in this SDK and every app.
- Forma: poster/layers, colors, pan/zoom/fit and Undo/Redo. Luma: generated
  landscapes, filmstrip/looks/histogram. Pulse: fictional metrics, chart/table
  and filters. These demos reset on launch and use existing experimental GPU APIs.

SDK: extract vellum-v1.0.0-build13-darwin-arm64-sdk.tar.gz; keep its internal
vellum-v1.0.0 directory. Use Go1.25.6, Python3 and Xcode Command Line Tools.
From the SDK run `python3 scripts/new-app.py /absolute/new/app --module example.com/my-app`,
then build/run from that generated app. Replacements must resolve into the SDK.
It is already prepared: do not run prepare.sh or overlay a different native
library. scripts/check-sdk.py accepts --archive and the trusted --sha256 for
independent verification.

Known limits: other OS/hardware/displays, cross-window canvas drag, human
IME/VoiceOver, downloaded-quarantine launch and exhaustive physical-pointer
coverage are unqualified. Existing backend/performance policy is unchanged.
An initial background Notes capture needed native Raise; no model edit was
required. One Luma close attempt needed a fresh native target; a separate
single-close control passed. No product cause was established for the first
action. The final report retains the full observation. This build's source64bf9cf
is newer than the unchanged v1.0.0 source tag4b42fb8.
'''
(T/'DELIVERY_README.md').write_text(readme);(D/'README.md').write_text(readme)
(T/'REPRODUCE.md').write_text('''# Focused reproduction

Use a separate clean checkout at64bf9cfbb9cfb57d96e1aecd0adad01239ca3c7a,
Go1.25.6, Python3, patch and Xcode Command Line Tools on ARM64 macOS. Preserve
release/version.json and historical audit records. This later report commit
is not the product's source identity. Indexed evidence contains the actual
controlled-environment controllers/arguments and all attempt logs.

1. Export scripts/release-sdk.py --public with explicit --macos-gpu-library,
   --macos-gpu-sha256 and --macos-gpu-provenance. Pinned native archive:
   786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883.
   The old verified SDK supplies only this unchanged capsule; current Go source
   and prepared dependencies come from the clean source through normal preparation.
2. Run scripts/check-sdk.py with --archive and independently recorded --sha256;
   extract with checksum verification. In drivers/cogent/build/upstream run
   `go test -race ./core -run '^TestVellumExposure' -count=1`. Reuse green CI and
   unchanged input/history evidence rather than repeat broad qualification.
3. Build from the extracted SDK, -mod=readonly: examples/macapps ./cmd/notes,
   ./cmd/macshell; drivers/cogent ./cmd/gallery; examples/showcase ./cmd/forma,
   ./cmd/luma, ./cmd/pulse. Verify replacements resolve into that same SDK and
   actual link maps select its pinned native archive. Check unchanged module
   versions/sums, selected embeds, standard declarations, original icon/font bytes.
4. Preserve each corresponding original notice bundle. Rebind only artifact_sha256
   to the new pre-sign binary, after those comparisons. Keep the showcase Go-font
   notice. Mismatches must fail. Collection pending/review-required labels stay
   separate from the approved release/native audit guard.
5. Use unchanged scripts/package-app.py --public with explicit --binary,
   --notice-bundle, --version 1.0.0, --build-version 13, --sign-identity -, and
   the original generated --icon PNG for each showcase. Archive with
   `ditto -c -k --norsrc --noextattr --keepParent`; extract and run
   `codesign --verify --deep --strict`. Copy with ditto --norsrc --noextattr to
   a nonsynchronized temporary launch directory for exact-byte native checks.
6. Check source/pre-sign/signed/manifests/notice/archive hashes and Info.plist.
   Keep sealed target_runtime=unverified; record actual observations separately.
   Notes requires a disposable --data-dir and refusal of an existing Notes
   process. Never use the personal notebook for the smoke. Native Raise/render,
   normal close and exact process absence are bounded checks; reverify signatures
   and every SDK file afterward.

The local retained pre-sign inputs are pinned in private-inputs.json. They are
not download assets. Captured paths/timestamps identify this run. Fresh builds
in a different path/toolchain are not asserted bit-identical; generate a new
hash packet for different outputs. Only the present SHA256SUMS identifies these
proposed bytes. Nothing here uploads files, moves tags or changes release gates.
''')
p=R/'README.md';s=p.read_text();start=s.index('[final local packaging checks]');end=s.index('The candidates are ad-hoc signed',start);s=s[:start]+'''[coherent build13 packaging](docs/reports/macos-v1-build13/README.md)
now provides a fresh SDK and all six apps from green commit `64bf9cf`. Each app
is compiled from that SDK and includes the window-exposure repair. The
[final publication packet](docs/reports/macos-v1-build13/PUBLICATION_PACKET.md)
records exact hashes and the proposed destination; no v1 native download has been uploaded.
'''+s[end:];s=s.replace('[publication packet](docs/reports/macos-v1-public-packaging/PUBLICATION_PACKET.md)\nrecords matched notices, final checksums, a held fixture and the separate upload decision.','[publication packet](docs/reports/macos-v1-build13/PUBLICATION_PACKET.md)\nrecords the SDK and six build13 apps, matched notices, final checksums and the separate upload decision.');p.write_text(s)
p=R/'docs/macos-v1.md';s=p.read_text().replace('[Final public-mode candidates](reports/macos-v1-public-packaging/README.md)','[Coherent build13 public-mode candidates](reports/macos-v1-build13/README.md)');start=s.index('The [final packaging report]');end=s.index('## Consume the private SDK',start);s=s[:start]+'''The [build13 report](reports/macos-v1-build13/README.md) records a fresh SDK and
all six apps from green source64bf9cf. Each uses that same SDK, including the
exposure repair; bounded render/close checks, notice bindings and post-launch
signatures pass. The [final packet](reports/macos-v1-build13/PUBLICATION_PACKET.md)
records exact hashes, retained intermediate observations and the separate upload
decision. Apps remain ad-hoc signed and unnotarized; downloaded-quarantine is
unqualified. Older private/mixed-source packages retain their own identities.

'''+s[end:];p.write_text(s)
p=R/'docs/README.md';s=p.read_text().replace('- [Current macOS public packaging](reports/macos-v1-public-packaging/README.md): approved audit, final local candidates, launch results and separate publication decision.','- [Current coherent macOS build13](reports/macos-v1-build13/README.md): one green source for the SDK and six apps, local checks and final packet.\n- [Historical macOS public packaging](reports/macos-v1-public-packaging/README.md): prior mixed-source candidates and original checks.');p.write_text(s)
p=R/'docs/reports/README.md';s=p.read_text().replace('\n','\n\n- [Coherent macOS v1 build13](macos-v1-build13/README.md): same-green-commit SDK and six apps, native checks and final packet.\n',1);p.write_text(s)
p=R/'specs/macos-v1-release.md';p.write_text(p.read_text()+'''
## Coherent final public candidates — 27 October 2026

The owner requested a fresh SDK and all six apps from the same green source.
[Build13](../docs/reports/macos-v1-build13/README.md) pins clean64bf9cf: the SDK
is freshly exported and every executable is compiled from its verified extraction.
Stage0108 uses ordinary preparation, with no manual overlay. Reuse green CI;
run independent SDK and affected exposure checks, exact package/notice guards
and bounded native render/close checks. Disclose new prepared-Go/binary identities
and retain original notice bodies and historical audit decisions.

The final packet proposes seven archives plus SHA256SUMS as a disclosed build13
revision on the existing v1.0.0 release. Its source tag stays4b42fb8. This authorizes
local preparation/review/commit, not publication, new tags, audit rewrites,
signing identities or notarization. Features, stable API, backend, performance
gate and qualification limits remain frozen. Report-only commits never relabel
the build-source CI or artifacts.
''')
print(json.dumps({'report':str(T),'assets':len(assets),'evidence_files':len(index),'evidence_bytes':(T/'evidence.tar.gz').stat().st_size}))
