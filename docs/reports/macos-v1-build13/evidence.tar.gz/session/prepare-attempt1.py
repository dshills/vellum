from pathlib import Path
import os,sys,json,hashlib,importlib.util,subprocess,time,shutil,tarfile,copy
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum'); X=Path(__file__).resolve().parent
D=X.parents[1]/'deliveries/macos-v1-build13-20261027';W=Path('/private/tmp/vellum-macos-coherent-build13-20261027');W.mkdir(exist_ok=True)
OLD=X.parents[1]/'deliveries/macos-v1-public-candidates-20261027';INPUTS=X.parents[1]/'deliveries/macos-v1-distribution-audit-20261027'
HEAD='64bf9cfbb9cfb57d96e1aecd0adad01239ca3c7a'
sys.path.insert(0,str(R/'scripts'));from sdk_environment import child_environment
from child_process import run_child
import app_notices

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
checker=module('checker',R/'scripts/check-sdk.py');collector=module('collector',R/'scripts/distribution-inventory.py')
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',VELLUM_CACHE_DIR='/private/tmp/vellum-distribution-cache-20261027')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain')
checks=[]
def run(name,args,cwd=R):
 start=time.monotonic()
 with (X/(name+'.stdout')).open('wb') as out,(X/(name+'.stderr')).open('wb') as err:p=run_child([str(a) for a in args],cwd=cwd,env=env,stdout=out,stderr=err,timeout=600,log_limit_bytes=64<<20)
 checks.append({'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)});(X/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks[-1]),flush=True)
 if p.returncode:raise RuntimeError(name+': '+(X/(name+'.stderr')).read_text(errors='replace')[-2400:])
 return (X/(name+'.stdout')).read_text()
def root_json(t):return json.loads(t[t.rfind('\n{')+1:])
basearchive=OLD/'vellum-v1.0.0-darwin-arm64-sdk.tar.gz';assert sha(basearchive)=='0519cc8645616ac14489ee69d94efb07ab8dcccc1e56ed1f4be14976daa33ab3'
baseline=checker.verify_archive(basearchive,sha(basearchive));old=checker.extract_verified(basearchive,W/'baseline',baseline)
lib=old/'drivers/cogent/build/libs-darwin';native_sha='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883';assert sha(lib/'arm64/libwgpu_native.a')==native_sha
archive=D/'vellum-v1.0.0-build13-darwin-arm64-sdk.tar.gz'
result=root_json(run('sdk-public',[sys.executable,'-B',R/'scripts/release-sdk.py','--public','--output',archive,'--macos-gpu-library',lib/'arm64/libwgpu_native.a','--macos-gpu-sha256',native_sha,'--macos-gpu-provenance',lib/'PROVENANCE.json']))
assert sha(archive)==result['sha256'];v=checker.verify_archive(archive,sha(archive));sdk=checker.extract_verified(archive,W/'candidate',v);m=v['manifest'];assert m['source']=={'commit':HEAD,'clean':True} and m['private_build'] is False
assert sha(sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')==native_sha
oldfiles,newfiles=baseline['manifest']['files'],m['files'];delta={'baseline_archive_sha256':sha(basearchive),'source':m['source'],'added':sorted(newfiles.keys()-oldfiles.keys()),'removed':sorted(oldfiles.keys()-newfiles.keys()),'changed':sorted(n for n in oldfiles.keys()&newfiles.keys() if oldfiles[n]!=newfiles[n])}
# Source/patch changes are reviewed separately; dependency declarations and bundled native notices must be identical.
locked=[n for n in oldfiles if n.endswith(('go.mod','go.sum')) or n.startswith(('release/native-components/','THIRD_PARTY_NOTICES/'))]
assert all(newfiles.get(n)==oldfiles[n] for n in locked),[n for n in locked if newfiles.get(n)!=oldfiles[n]]
oldinv=json.loads((old/'THIRD_PARTY_INVENTORY.json').read_text());newinv=json.loads((sdk/'THIRD_PARTY_INVENTORY.json').read_text());assert oldinv==newinv
assert sha(sdk/'drivers/cogent/build/upstream/core/renderwindow.go')=='3960374de3a8b104f116865632f645f31ac999320151b1da22a4ba41a7b1412b'
delta.update(locked_files_unchanged=len(locked),inventory_unchanged=True,native_archive_sha256=native_sha);(X/'sdk-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
run('sdk-independent-consumer',[sys.executable,'-B',R/'scripts/check-sdk.py','--archive',archive,'--sha256',sha(archive)])
run('sdk-exposure-regression',['go','test','-race','./core','-run','^TestVellumExposure','-count=1'],sdk/'drivers/cogent/build/upstream')
assert sha(INPUTS/'PRE_SIGN_INPUTS.tar.gz')=='44ea387d626e9548e0cee9d8215d8179e3e16ffcfc3e950b1553cad9078ba678'
inputs=W/'inputs';inputs.mkdir();total=count=0
with tarfile.open(INPUTS/'PRE_SIGN_INPUTS.tar.gz','r|gz') as tar:
 for member in tar:
  count+=1;total+=member.size;assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts and count<2048 and member.size<128<<20 and total<1<<30
  target=inputs/member.name;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:shutil.copyfileobj(tar.extractfile(member),f)
GOROOT=Path(run('go-root',['go','env','GOROOT'],sdk).strip());baseline_packet=json.loads((R/'docs/reports/macos-v1-distribution/PACKET.json').read_text())
(X/'locations.json').write_text(json.dumps({'work':str(W),'sdk':str(sdk),'old_sdk':str(old),'delivery':str(D),'inputs':str(inputs),'source':HEAD},indent=2)+'\n')
(X/'preparation.json').write_text(json.dumps({'source_commit':HEAD,'sdk_archive':archive.name,'sdk_sha256':sha(archive),'verified_files':len(m['files']),'native_archive_sha256':native_sha,'audit_record_sha256':sha(R/'release/macos-v1-distribution-audit.json'),'checks':checks},indent=2)+'\n')
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain')
print(json.dumps({'complete':True,'sdk':str(sdk),'changed_files':delta['changed']}),flush=True)
