from pathlib import Path
import os,sys,json,hashlib,importlib.util,subprocess,time,shutil,copy
sys.dont_write_bytecode=True
R=Path('/Users/dshills/Development/projects/Vellum');X=Path(__file__).resolve().parent
D=X.parents[1]/'deliveries/macos-v1-build13-20261027';W=Path('/private/tmp/vellum-macos-coherent-build13-20261027');sdk=W/'candidate/vellum-v1.0.0';old=W/'baseline/vellum-v1.0.0';inputs=W/'inputs'
HEAD='64bf9cfbb9cfb57d96e1aecd0adad01239ca3c7a';sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
from child_process import run_child
import app_notices

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
checker=module('checker',R/'scripts/check-sdk.py');collector=module('collector',R/'scripts/distribution-inventory.py')
env=child_environment();env.update(PATH='/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin:'+os.environ['PATH'],GOCACHE='/private/tmp/vellum-distribution-cache-20261027/build',GOMODCACHE='/private/tmp/vellum-distribution-cache-20261027/mod',GOPATH='/private/tmp/vellum-distribution-cache-20261027/gopath',VELLUM_CACHE_DIR='/private/tmp/vellum-distribution-cache-20261027')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain')
checks=[]
def run(name,args,cwd=R):
 start=time.monotonic()
 with (X/(name+'.stdout')).open('wb') as out,(X/(name+'.stderr')).open('wb') as err:p=run_child([str(a) for a in args],cwd=cwd,env=env,stdout=out,stderr=err,timeout=600,log_limit_bytes=64<<20)
 checks.append({'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)});(X/'app-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks[-1]),flush=True)
 if p.returncode:raise RuntimeError(name+': '+(X/(name+'.stderr')).read_text(errors='replace')[-2400:])
 return (X/(name+'.stdout')).read_text()
def root_json(t):return json.loads(t[t.rfind('\n{')+1:])
manifest=json.loads((sdk/'SDK_MANIFEST.json').read_text());prep=json.loads((X/'preparation.json').read_text());assert manifest['source']=={'commit':HEAD,'clean':True}
packet=json.loads((R/'docs/reports/macos-v1-distribution/candidate-packet.json').read_text());newinv=json.loads((sdk/'THIRD_PARTY_INVENTORY.json').read_text());GOROOT=Path(run('go-root-apps',['go','env','GOROOT'],sdk).strip())
run('icons',['go','run','-mod=readonly','./cmd/artwork','-output',W/'icons'],sdk/'examples/showcase')
for slug in ('forma','luma','pulse'):assert sha(W/'icons'/(slug+'.png'))==sha(inputs/'icons'/(slug+'.png'))
configs=[('notes','Vellum Notes','com.dshills.vellum.notes.personal','examples/macapps','./cmd/notes'),('widgets','Vellum Mac Widgets','com.dshills.vellum.widgets.v1','drivers/cogent','./cmd/gallery'),('shell','Vellum Mac Shell','com.dshills.vellum.macshell.v1','examples/macapps','./cmd/macshell'),('forma','Forma','com.dshills.vellum.showcase.forma','examples/showcase','./cmd/forma'),('luma','Luma','com.dshills.vellum.showcase.luma','examples/showcase','./cmd/luma'),('pulse','Pulse','com.dshills.vellum.showcase.pulse','examples/showcase','./cmd/pulse')]
apps=[];(W/'launch').mkdir(exist_ok=True)
for slug,name,identifier,rel,target in configs:
 ad=W/slug;ad.mkdir();cwd=sdk/rel;baseline=next(a for a in packet['apps'] if a['id']==slug)
 graph=checker.decode_objects(run(slug+'-graph',['go','list','-mod=readonly','-deps','-json',target],cwd));mods=checker.decode_objects(run(slug+'-origins',['go','list','-mod=readonly','-m','-json','all'],cwd));oldmods=checker.decode_objects(run(slug+'-baseline-origins',['go','list','-mod=readonly','-m','-json','all'],old/rel))
 def modid(ms):return {m['Path']:{k:m[k] for k in ('Version','Sum') if k in m} for m in ms}
 assert modid(mods)==modid(oldmods)
 if rel=='drivers/cogent':
  expected={'github.com/dshills/vellum':sdk,'cogentcore.org/core':sdk/'drivers/cogent/build/upstream','github.com/go-text/typesetting':sdk/'drivers/cogent/build/typesetting',**{k:sdk/p for k,p in checker.native_linkers.replacements(manifest['native_gpu']).items()}}
  main=next(m for m in mods if m.get('Main'));assert main['Path']=='github.com/dshills/vellum/drivers/cogent' and Path(main['Dir']).resolve()==cwd.resolve();origins={main['Path']:str(cwd.relative_to(sdk))}
  for k,path in expected.items():
   m=next(m for m in mods if m['Path']==k);assert Path(m['Replace']['Dir']).resolve()==path.resolve();origins[k]=str(path.relative_to(sdk))
 else:origins=checker.check_origin(mods,sdk,manifest['release']['module'],manifest['native_gpu'])
 roots={p['Module']['Path']:Path(p['Module'].get('Replace',p['Module'])['Dir']).resolve() for p in graph if not p.get('Standard')};build=collector.package_inventory(graph,roots,{m['module']:m for m in newinv['modules']});std=collector.standard_library_inventory(graph,GOROOT)
 (ad/'build-inputs.json').write_text(json.dumps({'modules':modid(mods),'standard':std,**build},indent=2)+'\n')
 oldgraph=checker.decode_objects(run(slug+'-baseline-assets',['go','list','-mod=readonly','-deps','-json',target],old/rel));oldassets={(p['Module']['Path'],str(Path(p['Dir']).relative_to(Path(p['Module'].get('Replace',p['Module'])['Dir']))/f)):sha(Path(p['Dir'])/f) for p in oldgraph if not p.get('Standard') for f in p.get('EmbedFiles',[])};assets={(a['module'],a['file']):a['sha256'] for a in build['embedded_assets']};assert oldassets==assets
 generated=[{'package':p['ImportPath'],'files':{f:sha(Path(p['Dir'])/f) for f in p.get('GoFiles',[])}} for p in graph if p['ImportPath'].startswith('golang.org/x/image/font/gofont/')]
 binary=ad/name;linkmap=ad/'native.map';run(slug+'-build',['go','build','-mod=readonly','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',binary,target],cwd)
 observation=collector.native_link_observation(binary,linkmap,roots,build);(ad/'link-observation.json').write_text(json.dumps(observation,indent=2)+'\n');assert str(sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a').encode() in linkmap.read_bytes()
 source=inputs/'apps'/slug;assert sha(source/'binary')==baseline['source_binary_sha256'];assert sha(source/'INVENTORY.json')==baseline['notice_inventory_sha256'];ni=json.loads((source/'INVENTORY.json').read_text());notices=ad/'notices';notices.mkdir();shutil.copyfile(source/'INVENTORY.json',notices/'INVENTORY.json')
 for n in ni['files']:
  app_notices.notice_name(n);dest=notices/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(inputs/'shared-notices'/n,dest)
 app_notices.load(notices,baseline['source_binary_sha256'])
 try:app_notices.load(notices,sha(binary))
 except ValueError:pass
 else:raise AssertionError('old executable notice binding accepted rebuilt bytes')
 ni['artifact_sha256']=sha(binary);(notices/'INVENTORY.json').write_text(json.dumps(ni,indent=2,sort_keys=True)+'\n');app_notices.load(notices,sha(binary))
 fonts={}
 if slug in ('forma','luma','pulse'):
  root=Path('/private/tmp/vellum-distribution-cache-20261027/mod/golang.org/x/image@v0.44.0/font/gofont/ttfs');body=binary.read_bytes()
  for font in ('Go-Regular.ttf','Go-Bold.ttf'):
   data=(root/font).read_bytes();assert data in body;fonts[font]=sha(root/font)
  assert any(f['sha256']=='dc588a7ba9130043b67c2380cc03cc6644ed3557f6d5e8589b96acba1c64e343' for f in ni['files'].values())
 bundle=ad/(name+'.app');args=[sys.executable,'-B',R/'scripts/package-app.py','--public','--binary',binary,'--output',bundle,'--name',name,'--identifier',identifier,'--version','1.0.0','--build-version','13','--notice-bundle',notices,'--sign-identity','-']
 if slug in ('forma','luma','pulse'):args+=['--icon',W/'icons'/(slug+'.png')]
 produced=root_json(run(slug+'-public',args));assert produced['private_build'] is False and produced['native_distribution_audit']=='approved'
 archive=D/(name+'-build13.zip');run(slug+'-zip',['ditto','-c','-k','--norsrc','--noextattr','--keepParent',bundle,archive]);exactdir=ad/'exact';exactdir.mkdir();run(slug+'-extract',['ditto','-x','-k',archive,exactdir]);exact=exactdir/bundle.name;run(slug+'-signature',['codesign','--verify','--deep','--strict',exact]);am=json.loads((exact/'Contents/Resources/APP_MANIFEST.json').read_text());assert am['release_authorization']['source']=={'commit':HEAD,'clean':True} and not am['private_build'] and not am['notarized'] and am['source_binary_sha256']==sha(binary)
 targetpath=W/'launch'/bundle.name;run(slug+'-launch-copy',['ditto','--norsrc','--noextattr',exact,targetpath]);run(slug+'-launch-signature',['codesign','--verify','--deep','--strict',targetpath]);assert sha(targetpath/'Contents/MacOS'/name)==sha(exact/'Contents/MacOS'/name)
 app={'id':slug,'name':name,'identifier':identifier,'archive':archive.name,'archive_sha256':sha(archive),'source_commit':HEAD,'source_binary_sha256':sha(binary),'packaged_binary_sha256':sha(exact/'Contents/MacOS'/name),'notice_inventory_sha256':sha(notices/'INVENTORY.json'),'notice_files':len(ni['files']),'notice_components':len(ni['components']),'manifest_sha256':sha(exact/'Contents/Resources/APP_MANIFEST.json'),'native_archive_sha256':prep['native_archive_sha256'],'module_origins':origins,'module_records':len(mods),'embedded_assets':len(assets),'assets_unchanged':True,'dependency_identities_unchanged':True,'original_notice_bytes_unchanged':True,'generated_font_source':generated,'compiled_font_hashes':fonts,'private_build':False,'native_distribution_audit':'approved','notarized':False,'build':'13','launch_path':str(targetpath),'runtime_result':'not-yet-run'};apps.append(app);(X/'apps-progress.json').write_text(json.dumps(apps,indent=2)+'\n')
for n,h in manifest['files'].items():assert sha(sdk/n)==h,n
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain')
result={**prep,'schema':1,'build':'13','apps':apps,'checks':prep['checks']+checks,'publication_authorized':False,'uploaded':False,'notarized':False};(X/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':True,'apps':len(apps),'source':HEAD,'delivery':str(D)}),flush=True)
