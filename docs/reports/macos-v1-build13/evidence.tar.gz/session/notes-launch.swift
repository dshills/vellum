import AppKit
import Foundation
import CryptoKit
let path = "/private/tmp/vellum-macos-coherent-build13-20261027/launch/Vellum Notes.app"
let profile = "/private/tmp/vellum-macos-coherent-build13-20261027/disposable-notes"
let identifier = "com.dshills.vellum.notes.personal"
func fail(_ text: String) -> Never { fputs(text + "\n", stderr); exit(1) }
guard CommandLine.arguments.count == 1 else { fail("fixed app/profile only") }
guard NSRunningApplication.runningApplications(withBundleIdentifier:identifier).isEmpty else { fail("existing Notes process; launch refused") }
let url=URL(fileURLWithPath:path)
let binary=url.appendingPathComponent("Contents/MacOS/Vellum Notes")
let bytes=try Data(contentsOf:binary)
let digest=SHA256.hash(data:bytes).map{String(format:"%02x",$0)}.joined()
guard digest=="dade4d43aba1f3d9b4b1132624598ba7931366b1868a1e515b82a3e8a5cf2300" else { fail("unexpected signed binary") }
guard !FileManager.default.fileExists(atPath:profile) else { fail("disposable profile already exists") }
let config=NSWorkspace.OpenConfiguration();config.arguments=["--data-dir",profile];config.activates=false;config.createsNewApplicationInstance=true
var done=false;var failure:String?;var result:[String:Any]=[:]
NSWorkspace.shared.openApplication(at:url,configuration:config){app,error in
 if let error=error {failure=error.localizedDescription}
 else if let app=app,app.bundleIdentifier==identifier,app.bundleURL?.resolvingSymlinksInPath().path==url.resolvingSymlinksInPath().path {result=["pid":app.processIdentifier,"bundle":path,"data_directory":profile,"binary_sha256":digest,"launch":"success"]}
 else {failure="unexpected launched application"}
 done=true
}
let deadline=Date(timeIntervalSinceNow:15)
while !done && Date()<deadline {RunLoop.current.run(until:Date(timeIntervalSinceNow:0.1))}
guard done else {fail("launch completion timed out")}
if let error=failure {fail(error)}
let data=try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]);print(String(data:data,encoding:.utf8)!)
