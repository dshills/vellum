"""Promote one locally reviewed native checkpoint; never open a live app."""
import hashlib,json,sys,time
from pathlib import Path
scratch=Path('/private/tmp/vellum-large-data');canonical=Path('/Users/dshills/Development/projects/Vellum');phase=Path('/private/tmp/vellum-macos-post-ownership-live')
out=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-post-ownership')
base='1d91d848ac973e2b264c24e61c4a3beac34f7f08'
sys.path.insert(0,str(scratch/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
commands=[]
def git(root,*args):
 argv=['git','-C',str(root),*args];r=run_child(argv,env=env,capture_output=True,timeout=60)
 commands.append({'argv':argv,'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':r.stderr.decode(errors='replace')})
 assert r.returncode==0,(argv,r.stderr);return r.stdout.decode()
assert not git(scratch,'status','--porcelain') and not git(canonical,'status','--porcelain')
assert git(canonical,'rev-parse','HEAD').strip()==base
assert git(canonical,'branch','--show-current').strip()=='codex/foundation-completion'
commit=git(scratch,'rev-parse','HEAD').strip()
assert commit!=base and git(scratch,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
names=[n for n in git(scratch,'ls-files','-z').split('\0')if n];expected={n:sha(scratch/n)for n in names}
q=json.loads((phase/'qualification.json').read_text());assert q['base_commit']==base and q['result']=='REVIEWED_SCOPED_NATIVE_CHECKS_WITH_FAILED_LATENCY_TARGETS'
assert all(expected.get(n)==h for n,h in q['documentation_source'].items())
checkpoint_name='docs/reports/macos-post-ownership/records/checkpoint.json';checkpoint=json.loads((scratch/checkpoint_name).read_text())
assert checkpoint['base_commit']==base and checkpoint['prism_provider']=='anthropic' and checkpoint['prism_model']=='claude-sonnet-5-5'
assert checkpoint['prism_coverage_complete'] and checkpoint['prism_findings']>=0 and checkpoint['prism_findings_resolved']
assert sha(phase/'qualification.json')==checkpoint['qualification_sha256']
out.mkdir(parents=True,exist_ok=False);(out/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
record={'result':'OBSERVED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'scope':'Local documentation/evidence checkpoint for reviewed current native1000window cycles and40physicalfootprint samples,40sequential ordinary table processes4800samples with failed4/6ms targets, and4separate GPUroute diagnostic processes480records. Runtime source710/prepared6198 remain unchanged. Internal protocol/raw evidence/final archive reviews and one small AnthropicSonnet5.5 documentation review; raw1 medium missingrecord finding resolved by adding exact referenced records in this same commit. No allallocator/GPU reclamation, unsampledpeak, integratedP11, controlledspeedup or fullMac/distribution qualification.'};start=time.monotonic()
try:
 git(canonical,'fetch',str(scratch),commit);assert git(canonical,'rev-parse','FETCH_HEAD').strip()==commit
 git(canonical,'merge','--ff-only','FETCH_HEAD');assert git(canonical,'rev-parse','HEAD').strip()==commit
 terminal={'argv':['python3','prepare.py'],'cwd':str(canonical/'drivers/cogent'),'exit_code':None,'error':None};ps=time.monotonic()
 try:
  with(out/'prepare.stdout.log').open('xb')as so,(out/'prepare.stderr.log').open('xb')as se:r=run_child(terminal['argv'],cwd=canonical/'drivers/cogent',env=env,stdout=so,stderr=se,timeout=180)
  terminal['exit_code']=r.returncode
 except BaseException as error:
  terminal['error']={'type':type(error).__name__,'message':str(error)};raise
 finally:
  terminal['elapsed_seconds']=time.monotonic()-ps
  for n in ['stdout','stderr']:
   p=out/('prepare.'+n+'.log');terminal[n+'_sha256']=sha(p)if p.is_file()else None
  (out/'prepare-terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');record['prepare_exit_code']=terminal['exit_code'];record['prepare_error']=terminal['error']
 prepared={p.relative_to(canonical/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in sorted((canonical/'drivers/cogent/build'/module).rglob('*'))if p.is_file()}
 tracked={n:sha(canonical/n)for n in names};archive=canonical/'docs/reports/macos-post-ownership/records/evidence.tar.xz'
 record.update({'prepared_files':len(prepared),'exact_qualified_prepared_match':prepared==json.loads((phase/'baseline.json').read_text())['prepared'],'tracked_files':len(tracked),'exact_checkpoint_source_match':tracked==expected,'archive_sha256':sha(archive),'archive_index_match':sha(archive)==checkpoint['archive']['sha256'],'canonical_clean':not git(canonical,'status','--porcelain'),'scratch_clean':not git(scratch,'status','--porcelain'),'checkpoint_sha256':sha(canonical/checkpoint_name)})
 assert record['prepare_exit_code']==0 and len(prepared)==6198 and record['exact_qualified_prepared_match'] and record['exact_checkpoint_source_match'] and record['archive_index_match'] and record['canonical_clean'] and record['scratch_clean']
 record['result']='PASS_CANONICAL_PROMOTION'
except BaseException as error:
 record['result']='FAILED_CANONICAL_PROMOTION';record['error']={'type':type(error).__name__,'message':str(error)};raise
finally:
 for label,args in [('observed_head',('rev-parse','HEAD')),('observed_status',('status','--porcelain'))]:
  try:record[label]=git(canonical,*args).strip()
  except BaseException as error:record[label+'_error']={'type':type(error).__name__,'message':str(error)}
 record['elapsed_seconds']=time.monotonic()-start;record['commands']=commands
 (out/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items()if k!='commands'},indent=2))
