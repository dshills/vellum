# Independent 1,000-cycle native evidence review

APPROVED_EVIDENCE. No unresolved evidence mismatch.

This certificate covers only the completed owned window-cycle process. It does not assess the ongoing grid campaign. The recorded clean base is 1d91d848ac973e2b264c24e61c4a3beac34f7f08; all 710 selected source leaves and all 6,198 prepared leaves currently match the immutable baseline. Build/outer-monitor receipts, direct human availability authorization, reviewed final protocol, native executable and raw stdout/stderr identities agree. The initial nested-process-group NEEDS_FIX protocol/source is preserved; the completed process uses the corrected monitor within the outer owned watchdog group.

The outer process exits 0 in 187.90123195800697 seconds. Native monitoring exits 0 in 187.8048396660015 seconds. Raw native stdout contains exactly 41 post-GC sample records for cycles 0,25,...,1000 and one PASS_NATIVE_WINDOW_CYCLES terminal result with requested and completed cycles both 1,000. Every sample equals its copy in the terminal result. The native terminal cleanup reports no tracked windows, file panels, outstanding native requests, accessibility windows, pending callbacks or owned menu/tray objects; callbacks are stopped. These tracked inventories are not heap measurements.

All 40 retained vmmap invocations exit 0, target the owned native PID, and have exact raw stdout/stderr hashes. Their observed progress labels are 0,25,...,975. Each raw process/parent identity and each displayed physical-footprint value independently reparses to the producer record, using binary K/M/G/T units and preserving display precision. No final-cycle external sample is present or inferred.

| Observation | Result |
|---|---|
| Sampled physical footprint | 549.4–693.1 MiB; median 578.9; mean 585.6825; last 591.6 |
| Later-half sampled physical footprint | mean 594.23 MiB; first 586.1; last 591.6 |
| IOSurface resident row | 92.4 MiB in 39 samples; 102.6 MiB once at observed cycle 750; last 92.4 |
| IOSurface region count | 13–15; first 13; last 14 |
| Native post-GC RSS | 176.671875 → 315.171875 MiB; after cycle 25, 276.578125 → 315.171875 |
| Native post-GC Go heap | 28.727149963 → 62.701850891 MiB; after startup, about 62 MiB |

The physical/IOSurface observations show a bounded band for this fixture. They do not prove zero growth or complete native/GPU allocator reclamation. RSS grows, and historical ID tombstones intentionally remain. Every recorded RSS/Go-heap observation is below the fixture's 1 GiB/512 MiB guards; every external footprint sample is below the separate 4 GiB safety stop.

vmmap follows received progress while cycles continue, is non-atomic and perturbs the run. Forced GC also changes the workload. There is no final-cycle physical footprint, unsampled-peak, latency, full P11 or allocator attribution qualification. Prior huge 250/750-cycle measurements belong to a distinct older build; this certificate makes no matched single-patch causal comparison. Selected endpoint identities do not constitute a full compiler/module-cache/SDK closure.

Verifier: /private/tmp/vellum-cycle-evidence-review/verify.py.txt. Result: /private/tmp/vellum-cycle-evidence-review/verification.json. The reviewer performed only stdlib reads, hashes and raw record parsing; no tests, native/UI action, provider, Git or phase-producer execution, and no repository changes.
