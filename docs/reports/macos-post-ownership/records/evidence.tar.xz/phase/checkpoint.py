"""Close the provider's artifact-link finding before the local commit."""
import json
from run import ROOT, PHASE, sha, identity

records = ROOT / 'docs/reports/macos-post-ownership/records'
endpoints = json.loads((PHASE / 'endpoints.json').read_text())
review = json.loads((PHASE / 'final-evidence-review.json').read_text())
assert review.get('result', review.get('status')) == 'APPROVED_EVIDENCE'
assert review['endpoints'] == endpoints and not review['findings']
for name, digest in review['reviewed_artifact_sha256'].items():
    assert sha(name) == digest, name
baseline = json.loads((PHASE / 'baseline.json').read_text())
actual = identity()
assert actual['commit'] == baseline['commit']
assert actual['selected_source'] == baseline['selected_source'] and actual['prepared'] == baseline['prepared']
source = json.loads((PHASE / 'documentation-source.json').read_text())
assert all(sha(ROOT / n) == digest for n, digest in source['sources'].items())
assert sha(records / 'evidence.tar.xz') == endpoints['archive_sha256']
assert sha(records / 'evidence-index.json') == endpoints['index_sha256']
(records / 'evidence-review.json').write_bytes((PHASE / 'final-evidence-review.json').read_bytes())
checkpoint = {'result': 'REVIEWED_SCOPED_NATIVE_CHECKS_WITH_FAILED_LATENCY_TARGETS',
              'base_commit': baseline['commit'], 'runtime_baseline_sha256': sha(PHASE / 'baseline.json'),
              'source_manifest_sha256': endpoints['source_manifest_sha256'],
              'qualification_sha256': endpoints['qualification_sha256'],
              'archive': {'sha256': endpoints['archive_sha256'], 'members': endpoints['archive_members'],
                          'index_sha256': endpoints['index_sha256']},
              'cycle_review_sha256': endpoints['cycle_review_sha256'],
              'performance_review_sha256': endpoints['performance_review_sha256'],
              'evidence_review_sha256': sha(PHASE / 'final-evidence-review.json'),
              'prism_provider': 'anthropic', 'prism_model': 'claude-sonnet-5-5',
              'prism_coverage_complete': True, 'prism_findings': 1, 'prism_raw_exit_code': 1,
              'prism_sha256': endpoints['prism_sha256'], 'prism_findings_resolved': True,
              'provider_disposition': {'id': '472834ed908ce9f1', 'status': 'RESOLVED_REFERENCED_RECORDS_ADDED',
                                       'resolution': 'Referenced checkpoint, archive and member index are included in this same local commit.'},
              'native_cycles': 1000, 'vmmap_samples': 40, 'ordinary_samples': 4800,
              'ordinary_latency_targets_met': False, 'diagnostic_gpu_route_samples': 480,
              'prepared_files': 6198, 'selected_runtime_source_files': 710,
              'documentation_source': source['sources'],
              'promotion_producer_sha256': sha(PHASE / 'promote.py'),
              'checkpoint_producer_sha256': sha(__file__)}
(records / 'checkpoint.json').write_text(json.dumps(checkpoint, indent=2) + '\n')
for name in ['checkpoint.json', 'evidence.tar.xz', 'evidence-index.json']:
    assert (records / name).is_file() and (records / name).stat().st_size > 0
print('Reviewed checkpoint and all three referenced records exist; provider finding resolved.')
