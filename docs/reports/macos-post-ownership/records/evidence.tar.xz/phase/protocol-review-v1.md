# Post-ownership native protocol V1

NEEDS_FIX: the native monitor child starts a separate process group. The outer runner cannot kill that group when it times out or is interrupted, and SIGKILL prevents the monitor finally block from running. Inherit the outer owned group and make local monitor cleanup direct-child-only, or add a durable independent guardian before launch.

Other inspected measurement scopes are appropriately bounded. This reviewer ran no processes or native code. Vmmap observations are sampled, perturbing diagnostics; ordinary frame measurements and full acceptance remain separate.
