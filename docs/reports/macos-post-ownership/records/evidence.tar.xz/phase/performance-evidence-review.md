The current selected-source-bound performance/route evidence is APPROVED_EVIDENCE, with no numerical or protocol finding. This is shareable with the stated caveats, not a performance-acceptance approval.

All forty sequential release processes exit 0 and preserve all 4,800 ordinary samples. Each process has 128 guard-version-1 closed warmups, 120 unique completed tags/callbacks, strict mode identity and matching native/raw work totals. All eleven timing families, per-run/pooled nearest-rank percentiles, mean, sample SD/CV, run-p95 variation, allocation/malloc and source-counter distributions independently match the summaries. All outliers remain; every individual run misses both 4/6 ms targets.

| Case | Default p95 / p99 ms | GPU option p95 / p99 ms |
| --- | ---: | ---: |
| Fixed 10k | 8.060625 / 8.902541 | 7.944998 / 11.123834 |
| Fixed million | 7.952334 / 8.402206 | 7.719208 / 7.904749 |
| Variable 10k | 8.312877 / 11.724999 | 8.144087 / 9.050833 |
| Variable million | 8.014375 / 8.234126 | 7.829877 / 8.326543 |

Full observed geometry matches for 2,400 corresponding 10k/million sample pairs and 2,400 corresponding CPU/GPU sample pairs, including viewport, bounds, clipped counts, scale, layout hash and retained/materialized observations. The protocol preserves at least 400 clipped cells; this audit did not independently reconstruct every rectangle from native pixels.

The same binary 416ae873ad71b1115210435e349a5d764ead3f4c6c4b4a15d9d7a2218ccb9ecd is bound in both ordinary summaries and all four separate diagnostics. Current bytes match 710 selected source and 6,198 prepared identities. Approved protocol and terminal receipts match frozen producer/authorization/log hashes. Build argv and emitted/module metadata indicate default optimized, non-race Go 1.27.2; the build receipt does not itself store the output digest, and this is not a complete compiler/module-cache/SDK/static-native-library closure.

Four separate detailed processes contribute 480 main-scene records/480 compositions with unavailable raster/copy intervals and zero SetFromGoImage attempts/logical bytes. Their nested source timing is validated separately and never pooled with ordinary samples. This establishes only the tested numeric-table deferred route, not physical GPU transfers, successful hardware completion or general scene support.

CPU twenty processes ran before GPU twenty. This is not an interleaved or randomized mode comparison and supports no controlled speedup or causal historical comparison. One pre-live all-process snapshot reports 464.3% aggregate CPU (indexers plus other work, including an earlier test); load is about 25 on 14 CPUs, about 12 later. Human availability is not continuous host isolation. Raw process allocation includes observers; RSS is end-only, with no native/GPU/retained/peak attribution or display/input-to-photon timing.

The exact report/spec hashes and rounded performance table/route claims are verified. Cycle/memory inventory claims belong to the separate review. The original single two-file Prism receipt remains exit 1/one medium archive-link finding; the referenced records must be added and validated by the parent metadata seal. This performance certificate neither claims those pending records exist nor resolves that finding. No further provider call was executed.

This reviewer ran only standard-library read/hash/arithmetic code and wrote these audit artifacts. No repository producer, test, build, native/UI, provider or Git process was launched. The inert reader recipe is performance-evidence-reader.py.txt. Two early display-only reader attempts truncated metadata or assumed a dictionary where an unrelated observation was a list; bounded schema-specific rereads and the final independent reader completed successfully without changing source evidence.
