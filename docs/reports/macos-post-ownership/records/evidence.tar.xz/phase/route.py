"""Four separate GPU route diagnostics; never pool these into ordinary latency."""
from pathlib import Path
import importlib.util, json
from run import ROOT, PHASE, baseline, sha

spec = importlib.util.spec_from_file_location('benchmark', ROOT / 'scripts/benchmark-grid.py')
benchmark = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark)
before = baseline()
binary = PHASE / 'loadedgrid'
digest = sha(binary)
out = PHASE / 'gpu-route'
out.mkdir(exist_ok=False)
cases = {}
for variable in [False, True]:
    for rows in [10000, 1000000]:
        case = f"{'variable' if variable else 'fixed'}-{rows}"
        samples, process = benchmark.run_case(binary, out / case, rows, variable, 120, 128, False, 180,
                                              source_details=True, gpu_scene_rendering=True)
        assert process['result'] == 'PASS' and process['exit_code'] == 0
        assert before == baseline() and sha(binary) == digest
        records = [record for sample in samples for record in sample['native_sample']['SourceDetails']['Records']
                   if record['Kind'] == 1]
        assert len(records) == 120
        assert all(not r['RasterAvailable'] and not r['CopyAvailable'] and r['SetFromGoImageAttempts'] == 0
                   for r in records)
        cases[case] = {'samples': len(samples), 'main_scene_records': len(records),
                       'deferred_route': True, 'result_sha256': sha(out / case / 'result.json')}
        print(case, 'deferred route', len(records), flush=True)
result = {'result': 'PASS_SCOPED_GPU_ROUTE', 'binary_sha256': digest,
          'baseline_sha256': sha(PHASE / 'baseline.json'), 'producer_sha256': sha(__file__), 'cases': cases,
          'scope': 'Separate numeric-table source diagnostics. No ordinary latency, physical GPU completion/transfer count or broader scene qualification.'}
(out / 'qualification.json').write_text(json.dumps(result, indent=2) + '\n')
