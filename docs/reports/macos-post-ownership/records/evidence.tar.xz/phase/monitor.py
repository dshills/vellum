"""Observe only our native cycle child; stop at a sampled physical-footprint guard."""
from pathlib import Path
import datetime, json, os, re, selectors, subprocess, sys, time
from run import ROOT, PHASE, sha

LIMIT = 4 << 30
MAX_LOG = 16 << 20

def footprint(text):
    match = re.search(r'^Physical footprint:\s*([0-9.]+)([KMGT]?)', text, re.MULTILINE)
    if not match:
        raise ValueError('physical footprint unavailable')
    return int(float(match[1]) * 1024 ** ('KMGT'.find(match[2]) + 1 if match[2] else 0))

def main():
    binary = PHASE / 'window-cycle-smoke'
    argv = [str(binary), '-cycles=1000', '-sample-every=25', '-timeout=12m']
    record = {'argv': argv, 'executable_sha256': sha(binary), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'physical_footprint_sample_guard_bytes': LIMIT, 'observations': [], 'native_exit_code': None,
              'result': 'RUNNING', 'error': None, 'scope': 'Observed owned process vmmap physical footprint/IOSurface while cycles continue. Sampling is non-atomic and perturbs this diagnostic run; no latency, unsampled peak or allocation attribution claim.'}
    started = time.monotonic()
    process = None
    selector = selectors.DefaultSelector()
    pending = bytearray()
    total = 0
    observed = set()
    try:
        with (PHASE / 'cycle-native.stdout').open('xb') as output, (PHASE / 'cycle-native.stderr').open('xb') as errors:
            # Keep the native child in the outer runner's owned process group,
            # so a hard outer timeout also terminates native descendants.
            process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=errors, bufsize=0)
            record['owned_pid'] = process.pid
            record['owned_process_group'] = os.getpgid(process.pid)
            assert record['owned_process_group'] == os.getpgrp()
            selector.register(process.stdout, selectors.EVENT_READ)
            ended = False
            while not ended:
                if time.monotonic() - started > 750:
                    raise TimeoutError('cycle diagnostic watchdog expired')
                if not selector.select(.1):
                    continue
                data = os.read(process.stdout.fileno(), 65536)
                if not data:
                    break
                total += len(data)
                if total > MAX_LOG:
                    raise ValueError('native output budget exceeded')
                output.write(data)
                output.flush()
                pending.extend(data)
                while b'\n' in pending:
                    line, _, rest = pending.partition(b'\n')
                    pending = bytearray(rest)
                    try:
                        value = json.loads(line)
                    except (ValueError, UnicodeError):
                        continue
                    if value.get('event') == 'vellum.window-cycle.result':
                        record['native_result'] = value
                    if value.get('event') != 'vellum.window-cycle.sample':
                        continue
                    completed = value['sample']['Completed']
                    # Final cleanup can end the process before an external
                    # inspection starts. Earlier samples are the diagnostic
                    # observations; terminal acceptance comes from native JSON.
                    if completed >= 1000 or completed in observed:
                        continue
                    observed.add(completed)
                    query = ['/usr/bin/vmmap', '-summary', str(process.pid)]
                    began = time.monotonic()
                    # The observer also shares the outer owned group; its local
                    # subprocess timeout kills and joins this direct helper.
                    result = subprocess.run(query, timeout=10, capture_output=True)
                    for channel, blob in [('stdout', result.stdout), ('stderr', result.stderr)]:
                        (PHASE / f'vmmap-{completed}.{channel}').write_bytes(blob)
                    observation = {'after_observed_cycles': completed, 'native_sample': value['sample'], 'argv': query,
                                   'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - began,
                                   'stdout_sha256': sha(PHASE / f'vmmap-{completed}.stdout'),
                                   'stderr_sha256': sha(PHASE / f'vmmap-{completed}.stderr')}
                    record['observations'].append(observation)
                    if result.returncode != 0:
                        raise RuntimeError('owned-child vmmap failed')
                    observation['physical_footprint_bytes'] = footprint(result.stdout.decode(errors='replace'))
                    (PHASE / 'cycle-progress.json').write_text(json.dumps(record, indent=2) + '\n')
                    if observation['physical_footprint_bytes'] > LIMIT:
                        record['result'] = 'SAFETY_STOP_PHYSICAL_FOOTPRINT'
                        ended = True
                        break
            if pending and not ended:
                raise ValueError('incomplete native record at EOF')
            if ended:
                process.kill()
            process.wait(timeout=10)
            record['native_exit_code'] = process.returncode
            if not ended:
                native = record.get('native_result', {})
                assert process.returncode == 0 and native.get('result') == 'PASS_NATIVE_WINDOW_CYCLES' and native.get('completed_cycles') == 1000
                record['result'] = 'OBSERVED_1000_CYCLES_WITH_FOOTPRINT_SAMPLES'
    except BaseException as error:
        record['error'] = {'type': type(error).__name__, 'message': str(error)}
        record['result'] = 'FAILED_NATIVE_DIAGNOSTIC'
    finally:
        selector.close()
        if process is not None:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)
            record['observed_terminal_exit'] = process.returncode
            if process.stdout is not None:
                process.stdout.close()
        record['elapsed_seconds'] = time.monotonic() - started
        record['producer_sha256'] = sha(__file__)
        for channel in ['stdout', 'stderr']:
            path = PHASE / ('cycle-native.' + channel)
            record[channel + '_sha256'] = sha(path) if path.is_file() else None
        (PHASE / 'cycle-diagnostic.json').write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({k: v for k, v in record.items() if k not in ['observations', 'native_result']}), flush=True)
    if record['result'] != 'OBSERVED_1000_CYCLES_WITH_FOOTPRINT_SAMPLES':
        sys.exit(1)

if __name__ == '__main__':
    main()
