"""Bind terminal native measurements, independent audits and the small doc review."""
from pathlib import Path
import hashlib, json, subprocess, tarfile, io
from run import ROOT, PHASE, sha, identity

REPORT = ROOT / 'docs/reports/macos-post-ownership'
RECORDS = REPORT / 'records'
RECORDS.mkdir(exist_ok=True)
baseline = json.loads((PHASE / 'baseline.json').read_text())
actual = identity()
assert actual['commit'] == baseline['commit']
assert actual['selected_source'] == baseline['selected_source'] and actual['prepared'] == baseline['prepared']
source = json.loads((PHASE / 'documentation-source.json').read_text())
assert all(sha(ROOT / n) == digest for n, digest in source['sources'].items())
required = ['build-cycle-v1', 'build-grid-v1', 'cycle-monitor-v1', 'grid-default-v1', 'grid-gpu-v1', 'gpu-route-v1']
receipts = {}
for name in required:
    item = json.loads((PHASE / (name + '.json')).read_text())
    assert item['exit_code'] == 0 and item['error'] is None and item['source_prepared_stable']
    assert item['source_commit'] == baseline['commit'] and item['baseline_sha256'] == sha(PHASE / 'baseline.json')
    for channel in ['stdout', 'stderr']:
        assert sha(PHASE / (name + '.' + channel)) == item[channel + '_sha256']
    receipts[name] = sha(PHASE / (name + '.json'))
for name in ['cycle-evidence-review', 'performance-evidence-review']:
    review = json.loads((PHASE / (name + '.json')).read_text())
    assert review.get('result', review.get('status')) == 'APPROVED_EVIDENCE' and not review['findings']
    for filename, digest in review['reviewed_artifact_sha256'].items():
        assert sha(filename) == digest, filename
    (RECORDS / (name + '.json')).write_bytes((PHASE / (name + '.json')).read_bytes())
prism = json.loads((PHASE / 'prism-v1/prism.json').read_text())
process = json.loads((PHASE / 'prism-v1/process.json').read_text())
assert process['exit_code'] == 1 and process['error'] is None and process['source_index_stable']
assert process['before'] == process['after'] == source['sources']
assert prism['coverage']['complete'] and prism['coverage']['files'] == 2
assert len(prism['findings']) == 1 and prism['findings'][0]['id'] == '472834ed908ce9f1'
assert prism['findings'][0]['severity'] == 'medium'
ordinary = {}
for mode in ['grid-default', 'grid-gpu']:
    summary = json.loads((PHASE / mode / 'summary.json').read_text())
    assert summary['result'] == 'MEASURED' and summary['warm_target_met'] is False
    assert len(summary['cases']) == 4 and summary['runs'] == 5 and summary['samples_per_run'] == 120
    ordinary[mode] = {'summary_sha256': sha(PHASE / mode / 'summary.json'),
                      'target_met': False, 'ordinary_samples': 2400}
qualification = {'result': 'REVIEWED_SCOPED_NATIVE_CHECKS_WITH_FAILED_LATENCY_TARGETS',
                 'base_commit': baseline['commit'], 'runtime_baseline_sha256': sha(PHASE / 'baseline.json'),
                 'selected_source_files': 710, 'prepared_files': 6198, 'documentation_source': source['sources'],
                 'required_receipts': receipts, 'native_cycle_result': 'PASS_NATIVE_WINDOW_CYCLES',
                 'native_cycles': 1000, 'vmmap_samples': 40, 'ordinary': ordinary,
                 'gpu_route_samples': 480, 'cycle_review_sha256': sha(PHASE / 'cycle-evidence-review.json'),
                 'performance_review_sha256': sha(PHASE / 'performance-evidence-review.json'),
                 'prism_sha256': sha(PHASE / 'prism-v1/prism.json'), 'prism_raw_exit_code': 1,
                 'prism_findings': 1, 'provider_resolution': 'Add referenced checkpoint/archive/index in the same commit; final checkpoint verifies all three links and artifact identities.',
                 'limits': ['Sampled perturbed window-cycle memory is not all allocator/GPU reclamation, unsampled peak, integrated P11 or overnight qualification.',
                            'Sequential separate renderer campaigns under recorded background load are not a controlled renderer or historical speedup comparison.',
                            'Ordinary measured targets remain failed; diagnostics do not count GPU transfers/completion or broader scene eligibility.',
                            'Selected source/prepared/binary identities do not constitute full compiler/SDK/cache/static-native closure.',
                            'Human input/VoiceOver, cross-display, broader services/GPU loss and distribution/release remain open.']}
(PHASE / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
members = {}
suffixes = {'.json', '.stdout', '.stderr', '.log', '.txt', '.py', '.md'}
excluded = {'endpoints.json', 'final-evidence-review.json', 'final-evidence-review.md'}
for path in sorted(PHASE.rglob('*')):
    if path.is_file() and path.suffix in suffixes and path.name not in excluded:
        members['phase/' + path.relative_to(PHASE).as_posix()] = path.read_bytes()
for name in source['sources']:
    members['root/' + name] = (ROOT / name).read_bytes()
index = {name: {'sha256': hashlib.sha256(blob).hexdigest(), 'bytes': len(blob)} for name, blob in members.items()}
with tarfile.open(RECORDS / 'evidence.tar.xz', 'x:xz') as archive:
    for name, blob in members.items():
        info = tarfile.TarInfo(name); info.size = len(blob); info.mode = 0o644
        archive.addfile(info, io.BytesIO(blob))
(RECORDS / 'evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
endpoints = {'source_manifest_sha256': sha(PHASE / 'documentation-source.json'),
             'qualification_sha256': sha(PHASE / 'qualification.json'),
             'report_sha256': sha(REPORT / 'README.md'), 'spec_sha256': sha(ROOT / 'specs/macos-post-ownership.md'),
             'archive_sha256': sha(RECORDS / 'evidence.tar.xz'), 'index_sha256': sha(RECORDS / 'evidence-index.json'),
             'archive_members': len(members), 'cycle_review_sha256': qualification['cycle_review_sha256'],
             'performance_review_sha256': qualification['performance_review_sha256'],
             'prism_sha256': qualification['prism_sha256']}
(PHASE / 'endpoints.json').write_text(json.dumps(endpoints, indent=2) + '\n')
print(json.dumps(endpoints, indent=2))
