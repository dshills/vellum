from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;F=T/'docs/reports/macos-resolved-shapes'
a=json.loads((W/'assessment.json').read_text());assert a['result']=='REJECT_PRIVATE_OVERLAY' and not a['adoption_bar_met'];assert a['ordinary_samples_recomputed']==2400
assert not subprocess.check_output(['git','diff','HEAD','--','drivers/cogent','examples','go.mod','go.sum'],cwd=T)
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','drivers/cogent','examples'],cwd=T)
p=json.loads((W/'prism.json').read_text());assert p['coverage']['complete'] and p['coverage']['llmCalls']==1 and not p['findings']
assert json.loads((W/'internal-results-review.json').read_text())['approved'];proof=json.loads((W/'post-native-proof.json').read_text());assert proof['final_source_pins_match'] and proof['binary_pins_match']
checks={'result':a['result'],'source_base':a['source_base'],'runtime_changed':False,'prepared_changed':False,'ordinary_samples':2400,'novel_samples':480,'diagnostic_samples':240,'closed_mac_gates':[],'prism_calls':p['coverage']['llmCalls'],'prism_retained':len(p['findings']),'prism_discarded':len(p.get('discarded',[])),'prism_suppressed':len(p.get('suppressed',[])),'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for leaf in sorted(W.rglob('*')):
 assert not leaf.is_symlink(),leaf
 if not leaf.is_file() or '__pycache__'in leaf.parts or leaf.name.startswith('stop-'):continue
 data=leaf.read_bytes();assert len(data)<2<<20,(leaf,len(data));name=leaf.relative_to(W).as_posix();files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};sources[name]=leaf
assert len(files)<200 and sum(x['bytes']for x in files.values())<20<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<4<<20
record={'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
