from pathlib import Path
import json,hashlib,os,sys,time,subprocess
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
mode=sys.argv[1];go='/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go';common=['-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly','-overlay='+str(W/'overlay.json')]
shaper='cogentcore.org/core/text/shaped/shapers/shapedgt';core='cogentcore.org/core/core';driver='github.com/dshills/vellum/drivers/cogent'
if mode.startswith('focused'):args=[go,'test',*common,'-race','-tags=offscreen',shaper,'-run=TestVellumResolved','-count=1','-v','-timeout=4m']
elif mode=='shaper-full':args=[go,'test',*common,'-race','-tags=offscreen',shaper,'-count=1','-v','-timeout=4m']
elif mode=='core':args=[go,'test',*common,'-race','-tags=offscreen',core,'-run=TestVellumResolved|TestVellumLocalText|TestManual','-count=1','-v','-timeout=4m']
elif mode=='grid':args=[go,'test',*common,'-race','-tags=offscreen',driver,'-run=TestManagedGridKeyedLocalLayout|TestManagedGridCombinedScroll|TestManagedGridPanePaint|TestManagedGridInlineRetainedTheme','-count=1','-v','-timeout=4m']
elif mode=='gpu-offscreen':args=[go,'test',*common,'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','-count=1','-v','-timeout=4m']
elif mode=='driver-full':args=[go,'test',*common,'-race','-tags=offscreen',driver+'/...','-count=1','-timeout=7m']
elif mode=='vet':args=[go,'vet',*common,'-tags=offscreen',shaper,driver+'/...']
elif mode=='vet-driver':args=[go,'vet',*common,'-tags=offscreen',driver+'/...']
elif mode=='vet-upstream':args=[go,'vet',*common,'-composites=false','-tags=offscreen',shaper,'github.com/go-text/typesetting/shaping']
elif mode in ['build','build-diagnostic']:args=[go,'build',*common,'-trimpath','-buildvcs=false','-o','/private/tmp/vellum-ready-native-5482f9b/bin/'+('resolved-shapes-diagnostic' if mode=='build-diagnostic' else 'resolved-shapes'),'.']
else:raise ValueError(mode)
if mode=='build-diagnostic':
 common_overlay='-overlay='+str(W/'overlay.json');args[args.index(common_overlay)]='-overlay='+str(W/'diagnostic-overlay.json')
env=dict(os.environ,GOMAXPROCS='2',GOENV='off',GOWORK='off',GOTOOLCHAIN='local',GOPROXY='off');env.pop('GOFLAGS',None)
overlay=W/('diagnostic-overlay.json' if mode=='build-diagnostic' else 'overlay.json')
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [overlay,*map(Path,json.loads(overlay.read_text())['Replace'].values())]};start=time.monotonic();exitcode=1;error=None
try:
 with (W/(mode+'.stdout')).open('xb')as out,(W/(mode+'.stderr')).open('xb')as err:r=run_child(args,cwd=T/'examples/loadedgrid',env=env,stdout=out,stderr=err,timeout=480,log_limit_bytes=2<<20)
 exitcode=r.returncode
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items())
except BaseException as e:error={'type':type(e).__name__,'message':str(e)};exitcode=1
receipt={'argv':args,'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip(),'source_pins':pins,'exit_code':exitcode,'error':error,'seconds':time.monotonic()-start,'native_executed':False};(W/(mode+'-command.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['exit_code','error','seconds']}));
if exitcode:print((W/(mode+'.stderr')).read_text()[-4000:]);print((W/(mode+'.stdout')).read_text()[-4000:])
sys.exit(exitcode)
