from pathlib import Path
import datetime,hashlib,json,shutil,statistics,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');U=T/'drivers/cogent/build/upstream';M=W.parent/'macos-grid-matrix-bd672a6'
assert not (W/'plan.json').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip()=='4b0cfd7a823ea423f866db3e0668c60fe9da6731'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=T)
phases=['input_ns','owner_ns','reconcile_ns','layout_paint_ns','gather_ns','raster_upload_ns','encode_submit_ns'];analysis={'input_logs':{},'modes':{}}
for mode in ['gpu','cpu']:
 rowsall=[];tails=[];groups={True:[],False:[]}
 for p in sorted((M/mode/'fixed-10000').glob('run-*/native.log')):
  raw=p.read_bytes();analysis['input_logs'][str(p)]={'sha256':hashlib.sha256(raw).hexdigest(),'scope':'Alreadycommitted macos-grid-matrix records archive; do not duplicate'};rows=[]
  for line in raw.splitlines():
   try:d=json.loads(line)
   except (ValueError,UnicodeDecodeError):continue
   if d.get('event')=='grid.perf.sample':
    assert sum(d['metrics'][k] for k in phases)==d['metrics']['ui_work_ns'];rows.append(d)
  assert len(rows)==120
  rowsall+=rows;tails+=sorted(rows,key=lambda d:d['metrics']['ui_work_ns'])[113:]
  for d in rows:groups[d['index']%8==7].append(d)
 def avg(rows):return {k:statistics.mean(d['metrics'][k] for d in rows) for k in phases+['ui_work_ns']}
 analysis['modes'][mode]={'samples':len(rowsall),'tail_samples':len(tails),'horizontal_tail_samples':sum(d['index']%8==7 for d in tails),'mean_ns':avg(rowsall),'tail_mean_ns':avg(tails),'horizontal_mean_ns':avg(groups[True]),'vertical_only_mean_ns':avg(groups[False])}
analysis['scope']='35slowestframes(7/run) per600sample fixed10k mode. SumcomponentsverifiedPERFRAME. Meansofsameframes, notsumofmarginalpercentiles. Horizontalphase index%8==7 matchesexisting64eventtrajectory. Observationalphasecorrelation, notcallsitecausality orperformanceacceptance.'
(W/'tail-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
plan={'source_base':'4b0cfd7a823ea423f866db3e0668c60fe9da6731','conservative_investigation_start_utc':'2026-10-17T23:09:00Z','reassess_by_utc':'2026-10-18T00:39:00Z','selected_boundary':'Retain detached resolved-HarfBuzz shaping.Outputs after ordinary font/bidi/script segmentation. Avoid reshaping previously visited content when native grid widgets recycle on horizontal scroll. This is preparation/layout ownership, not paint-coordinate row caching.','invariants':['Font/script/language/fallback resolution always runs normally, including observable fontmap lookup state. NoFontMapepoch shortcut.','Key every actual shaping.Input: entire rune context+range, current resolved staticFont, size, direction, script, language, feature sequence, currentPpem. Variable/unsupported fonts refuse before cache. No borrowed string/slice pointer as content authority.','Cache owns cloned glyph arrays; clone again onreturn because wrapping/consumer mutation is permitted. Output.Face replaced with actualcurrent input.Face; retain immutableFontonly, not mutableFace/widget/source/model.','Bound owned key/glyph+conservative entry metadata8MiB,2048entries,8immutableFonts; oversized requests ordinary. Clear cache on explicit reset and owning-shaper retirement; no process/nativefontmemoryclaim.','Original shaping, wrapper, LinesBounds, paint, GPUencoding/shader, UI/source/semantics/workloads unchanged. No async work moved out of measuredframe.'], 'verification':['Independent originalHarfbuzz oracle across text/context/range/features/script/language/size/font/Ppem/direction and mutableoutputs.','Actual managed-grid fullreference pixels/geometry/shapedtext at supportedscales, edits/themes/donor reuse and lifetime.','Positive currentfixture resolved-run hits separately from ordinarytiming.','Full relevant race/vet and native correctness checks; fixed ordinary5pairs perCPU/GPU iffeasible, >=0.4ms medianrunp95lower and4/5pairedimprovements each, withouttail/retention/correctnessregression. Fullunchanged4/6msmatrix afteradoption.'],'stop':'Reject whole prototype ifactualrunhits ormaterialcompleteframe benefit cannotestablished. No row-cache/AX/packedupload/culling retuning or nativeplacementoperatorretry.'}
(W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
rel='text/shaped/shapers/shapedgt/shaper.go';dest=W/'source'/rel;shutil.copyfile(U/rel,dest)
print(json.dumps({'source_base':plan['source_base'],'next':'private resolved-run cache implementation','tail_analysis':{k:{'tail_samples':v['tail_samples'],'horizontal_tail_samples':v['horizontal_tail_samples']} for k,v in analysis['modes'].items()}}))
