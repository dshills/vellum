from pathlib import Path
import json
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;F=T/'docs/reports/macos-resolved-shapes';F.mkdir(parents=True,exist_ok=True)
a=json.loads((W/'assessment.json').read_text());assert a['result']=='REJECT_PRIVATE_OVERLAY'
text='''# Resolved shaping reuse: rejected performance prototype

The private resolved-shaping cache passes correctness and shows positive reuse,
but fails the frozen adoption requirement in both renderers. It is not added to
the framework. Production source, stage0079 and the ordinary baseline remain
unchanged at `4b0cfd7`; no full Mac gate closes. No cache tuning or another small
shaping, row-fragment, AX, upload or culling variant is queued.

## Decision and ordinary measurements

Five alternating baseline/candidate pairs per CPU/GPU mode use the existing
loaded-grid runner, fixed 10k rows, 128 warmup events and 120 measured events per
run, normal runtime parallelism and no race, profile or source-detail observer.
All 2,400 ordinary raw samples are recomputed using integer nearest-rank p95/p99.
Acceptance uses per-run values, not pooled samples. The frozen adoption bar is
at least 0.4 ms lower median run-p95 and four of five paired improvements in each
mode, with no median-p99 or p99-failure-count regression. It does not replace the
full 4 ms p95 / 6 ms p99 matrix.

| Mode | Baseline median run-p95 | Candidate | Reduction | Pairs improved | Baseline/candidate p99 failures >6 ms |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for mode in ['gpu','cpu']:
 c=a['cases'][mode];med=c['median_run_p95_ns'];f=c['p99_failed_runs'];text+=f"| {mode.upper()} | {med['baseline']/1e6:.6f} ms | {med['candidate']/1e6:.6f} ms | {c['median_run_p95_reduction_ns']/1e6:.6f} ms | {c['p95_improved_pairs']}/5 | {f['baseline']} / {f['candidate']} |\n"
text+='''
Every ordinary p95 fails 4 ms: ten GPU and ten CPU runs. Preserve all tails,
including CPU candidate pair 3 (p99 6.264207 ms), even though the median run-p99
and failure count improve. Run-p95/run-p99 values below are milliseconds.

| Mode/pair | Baseline p95 | Candidate p95 | Baseline p99 | Candidate p99 |
| --- | ---: | ---: | ---: | ---: |
'''
for mode in ['gpu','cpu']:
 c=a['cases'][mode]
 for i,(b,z) in enumerate(zip(c['runs']['baseline'],c['runs']['candidate']),1):text+=f"| {mode.upper()} {i} | {b['p95_ns']/1e6:.6f} | {z['p95_ns']/1e6:.6f} | {b['p99_ns']/1e6:.6f} | {z['p99_ns']/1e6:.6f} |\n"
text+='''
Separate novel-value controls add one baseline/candidate pair per mode (480
samples total). They pass the frozen regression guard, but cannot qualify five-run
performance or rescue ordinary adoption failure. Their p95/p99 values are:

| Novel mode | Baseline p95 / p99 | Candidate p95 / p99 |
| --- | ---: | ---: |
'''
for mode in ['gpu','cpu']:
 n=a['cases'][mode]['novel'];b=n['baseline'];z=n['candidate'];text+=f"| {mode.upper()} | {b['p95_ns']/1e6:.6f} / {b['p99_ns']/1e6:.6f} | {z['p95_ns']/1e6:.6f} / {z['p99_ns']/1e6:.6f} |\n"
text+='''
Ordinary allocations barely change: median of per-run p50 process-allocation
bytes is GPU 5,299,728 → 5,298,080 and CPU 3,693,752 → 3,691,264. These are not
live memory or the separate 1,000-control allocation acceptance workload.

## Selected boundary and input proof

Existing ordinary matrix logs show horizontal-scroll frames dominate the slowest
seven samples per run (GPU 29/35, CPU 32/35). This is phase correlation, not a
callsite or causality proof. `tail-analysis.json` records the exact prior archive
members and raw hashes; those logs are not duplicated in this archive.

The prototype retains resolved HarfBuzz `shaping.Output` after ordinary
font/bidi/script resolution, so recycled widgets can reuse previously visited
values. Font-map lookup/segmentation, wrapping, bounds, layout, paint and encoding
still run. No work is moved asynchronously outside the measured frame.

Keys prove the full binary rune context and range, exact fixed size, direction,
script, language, feature sequence, resolved immutable Font and requested/effective
Ppem. The existing HarfBuzz font LRU can retain an earlier mutable Face for the
same Font. `PreparedFace` performs its original admission/touch on every lookup;
keys include the actual retained Face's Ppem. Unsupported/variable/coordinate
inputs use original shaping. Retained entries own glyph arrays and key strings,
restore the current output Face and clone glyphs again on return. No mutable
Face, widget, model, callback or input slice is retained in the new cache.

Bounds are 8 MiB owned keys/glyphs plus conservative entry metadata, 2,048
entries, eight immutable Font references, and per-request bounds. This does not
bound immutable font backing tables or process memory. Explicit reset and owning
window retirement clear the cache; previously returned outputs remain detached.
The source overlay and tests are archived, not installed into prepared sources.

## Correctness, reuse and failures retained

- Focused independent original-HarfBuzz output regressions pass, including warm
  first-Face/LRU/eviction state, full-context/range/feature/size/font/Ppem changes,
  vertical/sideways directions, mutable output arrays, actual byte/entry/font
  eviction, unsupported CFF/coords and lifecycle retirement. A genuine Thai GPOS
  device-adjustment discriminator uses existing cached FreeSerif: changing the
  effective first-Face Ppem makes oracle glyphs differ and forces a cache miss.
  The font is not copied into the framework.
- Full shaper race, actual ManualWindow retirement, managed-grid pixel/oracle
  regressions across scales 96/120/144/192 and batches 1/7/64, and complete
  offscreen driver race pass. Driver race command takes 260.337 seconds. Separate
  default driver vet and native/diagnostic builds pass.
- Default upstream vet fails on inherited `run.go:36` unkeyed `textpos.Range`.
  The original failure is retained; affected shaper/typesetting vet passes with
  `-composites=false` explicitly. This is qualified vet evidence. Existing Cocoa
  deprecation and duplicate objc linker warnings remain in raw logs.
- Focused-v2 fails because font discovery seeded candidate HarfBuzz first-Face
  state while the oracle started empty. Controlled fixtures are corrected to
  equal empty initial state, without a production change. Final focused-v5
  passes and strengthens coordinate refusal to unchanged Hits/incremented Refused.
- Actual native GPU tests pass without skips, positively assert cache hits and
  preserve the existing text/path GPU readback and independent CPU oracle. The
  separate offscreen GPU package pass alone is not actual GPU evidence.
- Each CPU/GPU diagnostic run has 120 measured samples and 15 horizontal frames.
  Every horizontal frame satisfies at least ten eligible requests and an 80%
  hit fraction; aggregate horizontal reuse is 2,636 hits and zero misses per
  mode. Counters surround actual dirty-text sizing in a separate diagnostic
  binary; no filtered environment flag controls them. These clocks are excluded
  from performance acceptance.

## Execution and evidence boundaries

The initial native plan is rejected before execution for a terminal prerequisite
validation gap. Its source and review are retained. Corrected v2 validates exact
terminal GPU/diagnostics result, plan hash and prepared identity before dependent
phases. Independent internal review approves 17 source/controller/dependency pins,
three binaries and clean/prepared roots. All final phases complete before the
90-minute reassessment deadline. Source/prepared/binary identities remain equal
afterward; both C/T roots are clean. Sampled process inspection finds no matching
test executable, but runner cleanup attempts plus exit-zero are not a strict
owned-descendant/group absence proof.

This uses existing programmatic grid events and native GPU assertions. No physical
pointer/placement, visible presentation, IME, VoiceOver, display transition or
system preference qualification follows. No input-source, clipboard or preference
changes are made. Hardware is the recorded local M4 Pro/macOS 26.6.2 configuration;
display metadata is retained per campaign. Baseline and candidate geometries match.

`records.tar.gz` and `records.json` retain the exact private source/test overlays,
controllers, internal reviews, original failures, command logs, frozen plan/pins,
raw native logs and assessments. Key members are `assessment.json`,
`comparison-result.json`, `ordinary/{gpu,cpu}/{1..5}-{baseline,candidate}/native.log`,
`novel/{gpu,cpu}/{baseline,candidate}/native.log`, `diagnostic-assessment.json`,
`diagnostics/{gpu,cpu}/reuse.json`, `gpu.stdout` and `post-native-proof.json`.
No executable, SDK archive or font copy is included. One scoped Anthropic Claude
Sonnet 5.5 Prism review covers the completed rejection documentation; internal
source, execution, results and archive reviews are retained. M2 native, full M3,
M4, human M5, final SDK/rights M6 and M7 remain open.
'''
(F/'README.md').write_text(text)
p=T/'specs/macos-completion.md';s=p.read_text();mark='## Latest unattended evidence\n';assert mark in s;s=s.replace(mark,mark+'''
The [resolved-shaping checkpoint](../docs/reports/macos-resolved-shapes/README.md)
rejects a private cache despite positive actual dirty-sizing reuse in both CPU/GPU
modes (2,636 horizontal hits and zero misses each). Correctness/race, native GPU
readback, builds and qualified vet pass. Five ordinary pairs per mode improve
median run-p95 only GPU 4.596166 → 4.522458 ms (3/5 pairs) and CPU
5.480209 → 5.404167 ms (4/5), below the frozen 0.4 ms adoption bar. All twenty
ordinary p95s still fail 4 ms. Novel controls pass separately; all tails and prior
fixture/vet/admission failures remain retained. No runtime/prepared change or full
Mac gate closure. Stop this prototype without another cache/AX/culling variant;
complete other missing acceptance evidence before selecting another M3 redesign.
''',1);s=s.replace('M3 requires a separate architecture decision; independent\nM6 minimum-Go-toolchain compatibility is the next qualification task.','The subsequent resolved-shaping prototype is also rejected below its adoption\nbar. Minimum-Go source compatibility is now separately qualified; full M3 and\nfinal M6 acceptance remain open.');p.write_text(s)
p=T/'specs/macos-delivery.md';s=p.read_text();s=s.replace('**M3-A, tile culling and row fragments are complete and rejected.**','**M3-A, tile culling, row fragments and resolved shaping are rejected.**');needle='   now passes; final SDK/rights closure remains open.\n';assert needle in s;s=s.replace(needle,needle+'''   The [resolved-shaping checkpoint](../docs/reports/macos-resolved-shapes/README.md)
   then proves real CPU/GPU reuse and passes correctness, but ordinary median
   run-p95 improves only 0.074/0.076 ms, below the 0.4 ms adoption bar. Its whole
   private overlay is rejected; all twenty p95s fail 4 ms. No shape-cache or other
   small rejected-boundary tuning is queued. Complete missing tree/general UI
   qualification and independent M6 inventory work before choosing a new M3
   redesign; preserve the table failure and every other gate.
''',1);p.write_text(s)
print('Wrote report and updated two completion specifications')
