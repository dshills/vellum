"""Fixed existing GPU/benchmark runners; no physical input operator."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,signal,statistics,subprocess,sys,threading,_thread,time
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-ready-native-5482f9b');HEAD='4b0cfd7a823ea423f866db3e0668c60fe9da6731'
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment

def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('resolved_grid_runner',T/'scripts/benchmark-grid.py');lease=load('resolved_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def clean():need(all(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain')for root in [C,T]),'clean source identity')
def prepared(root):
 d={n+'/'+p.relative_to(root/'drivers/cogent/build'/n).as_posix():sha(p) for n in ['upstream','typesetting'] for p in (root/'drivers/cogent/build'/n).rglob('*')if p.is_file()}
 return {'files':len(d),'sha256':hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
def prepare():
 need(not (W/'native-plan.json').exists(),'fresh plan');clean()
 for mode in ['focused-v5','shaper-full','core','grid','driver-full','gpu-offscreen','vet-driver','vet-upstream','build','build-diagnostic']:need(json.loads((W/(mode+'-command.json')).read_text())['exit_code']==0,'passing '+mode)
 # New test-only controls need no repeat of commands that never compiled them.
 for mode in ['core','grid','driver-full','build','build-diagnostic']:
  for p,h in json.loads((W/(mode+'-command.json')).read_text())['source_pins'].items():
   if p.endswith('.go') and not p.endswith('_test.go'):need(sha(p)==h,'compiled production source '+p)
 old=json.loads((W.parent/'macos-ax-semantic-02f8dbe/binary-receipt.json').read_text());need(all(sha(C/'drivers/cogent'/n)==v for n,v in old['compiled_leaves'].items()),'baseline compiled leaves');need(not git(C,'diff','bd672a6',HEAD,'--','drivers/cogent','go.mod','examples/loadedgrid'),'baseline unchanged')
 pins={str(p):sha(p) for p in [Path(__file__),W/'check.py',W/'overlay.json',W/'diagnostic-overlay.json',T/'scripts/benchmark-grid.py',Path(lease.__file__),P/'loadedgrid.mod',P/'loadedgrid.sum',Path('/private/tmp/vellum-gpu-sdk-stage0077/relocated SDK/vellum-v0.1.0-alpha.2/drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')]}
 for name in ['overlay.json','diagnostic-overlay.json']:
  for v in json.loads((W/name).read_text())['Replace'].values():pins[v]=sha(v)
 trees={str(root):prepared(root)for root in [C,T]};need(all(v=={'files':6260,'sha256':'1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba'}for v in trees.values()),'prepared stage79')
 binaries={k:{'path':str(p),'sha256':sha(p)}for k,p in [('baseline',Path(old['path'])),('candidate',P/'bin/resolved-shapes'),('diagnostic',P/'bin/resolved-shapes-diagnostic')]};need(binaries['baseline']['sha256']==old['sha256'],'baseline binary')
 gpu_args=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go','test','-p=2','-modfile='+str(P/'loadedgrid.mod'),'-mod=readonly','-overlay='+str(W/'overlay.json'),'-race','-tags=offscreen','cogentcore.org/core/paint/renderers/gpuscene','-count=1','-v','-timeout=4m']
 plan={'source_base':HEAD,'prepared':trees,'inputs':pins,'binaries':binaries,'gpu_args':gpu_args,'diagnostics':{'rows':10000,'variable':False,'warmup':128,'samples':120,'modes':['gpu','cpu'],'required_horizontal_frames':15,'minimum_eligible_requests_each':10,'minimum_eligible_hit_fraction_each':.8,'observer':'Separate binary snapshots counters around only actual grid LocalLayout dirty-text sizing. Always compiled in, no filtered environment switch. No timing acceptance.'},'ordinary':{'pairs_per_mode':5,'modes':['gpu','cpu'],'alternating_order':True,'warmup':128,'samples':120,'rows':10000,'variable':False,'source_details':False,'race':False,'profile':False,'minimum_median_run_p95_reduction_ns':400000,'minimum_improved_pairs':4,'tail':'Candidate medianrunp99<=baseline; no greatercount ofp99>6ms. Preserveeveryoutlier.','novel':'Separate onebaseline/candidate pair perCPU/GPU mode: -perf-novel. Requirecandidatep95<=baseline+0.4ms andp99<=max(6ms,baselinep99); notfive-run acceptance.'},'stop':'Reject whole prototype on feasibility/adoption failure. No tuning into another architecture branch. Full4/6ms matrix remains afteradoption. Reassess by2026-10-18T00:39:00Z.','native_scope':'Existing programmatic grid event deque and native GPU assertions only; no physicalpointer/placementoperator/settings/clipboard changes.'}
 (W/'native-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Prepared plan '+sha(W/'native-plan.json'))
def run(phase):
 stop=W/('stop-'+phase);out=W/(phase+'-result.json');need(not stop.exists()and not out.exists(),'fresh phase')
 raw=(W/'native-plan.json').read_bytes();plan=json.loads(raw);admit=json.loads((W/'native-admission.json').read_text());need(admit['execution_ready']and admit['plan_sha256']==hashlib.sha256(raw).hexdigest(),'reviewed exact plan')
 if phase!='gpu':
  prior=json.loads((W/'gpu-result.json').read_text());need(prior['result']=='PASS' and prior['error'] is None and prior['plan_sha256']==hashlib.sha256(raw).hexdigest() and prior['prepared_after']==plan['prepared'],'terminal native GPU prerequisite')
 if phase=='comparison':
  prior=json.loads((W/'diagnostics-result.json').read_text());need(prior['result']=='MEASURED' and prior['error'] is None and prior['plan_sha256']==hashlib.sha256(raw).hexdigest() and prior['prepared_after']==plan['prepared'],'terminal diagnostics prerequisite')
  need(json.loads((W/'diagnostic-assessment.json').read_text())['comparison_admitted'],'positive horizontal reuse prerequisite')
 def boundary():
  need(not stop.exists(),'stop requested');need(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime(2026,10,18,0,39,tzinfo=datetime.timezone.utc),'90minute reassessment gate');clean();need(all(sha(p)==h for p,h in plan['inputs'].items()),'pinned source/controller changed');need(all(sha(d['path'])==d['sha256']for d in plan['binaries'].values()),'binary changed')
 d={'result':'INCOMPLETE','phase':phase,'source_base':HEAD,'plan_sha256':hashlib.sha256(raw).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':{},'error':None,'physical_pointer_tested':False};done=threading.Event()
 def watch():
  while not done.wait(.2):
   if stop.exists():_thread.interrupt_main();return
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('phase terminated')))
 try:
  boundary();need({str(root):prepared(root)for root in [C,T]}==plan['prepared'],'prepared before');need(all(os.environ.get(k)is None for k in ['GOMAXPROCS','GOMEMLIMIT','GOFLAGS']),'normal native env')
  with lease.LiveLease():
   threading.Thread(target=watch,daemon=True).start()
   if phase=='gpu':
    env=child_environment(runtime=True);env.update(GOMAXPROCS='2',GOPROXY='off',VELLUM_GPU_SCENE_TEST='1');started=time.monotonic()
    with (W/'gpu.stdout').open('xb')as stdout,(W/'gpu.stderr').open('xb')as stderr:r=run_child(plan['gpu_args'],cwd=T/'examples/loadedgrid',env=env,stdout=stdout,stderr=stderr,timeout=300,log_limit_bytes=2<<20)
    d.update(exit_code=r.returncode,seconds=time.monotonic()-started);need(r.returncode==0 and b'--- SKIP'not in(W/'gpu.stdout').read_bytes(),'actual GPU tests pass without skip');d['result']='PASS'
   else:
    d['displays']=b.metadata_command(['system_profiler','SPDisplaysDataType','-json'],15)
    for mode in ['gpu','cpu']:
     gpu=mode=='gpu'
     if phase=='diagnostics':
      boundary();directory=W/'diagnostics'/mode;samples,outcome=b.run_case(Path(plan['binaries']['diagnostic']['path']),directory,10000,False,120,128,False,180,source_details=True,gpu_scene_rendering=gpu)
      observers={}
      for line in(directory/'native.log').read_bytes().splitlines():
       try:x=json.loads(line)
       except(ValueError,UnicodeDecodeError):continue
       if x.get('event')=='resolved.shape.diagnostic':observers.setdefault(x['generation'],[]).append(x)
      rows=[]
      for x in samples:
       obs=observers.get(x['generation'],[]);need(1<=len(obs)<=4,'bounded sizing observers per generation')
       hit=miss=refused=0
       for o in obs:
        a,z=o['before'],o['after'];need(all(z[k]>=a[k]for k in ['Hits','Misses','Refused']),'monotonic counters');need(z['Bytes']<=8<<20 and z['Entries']<=2048 and z['Fonts']<=8,'bounded storage');hit+=z['Hits']-a['Hits'];miss+=z['Misses']-a['Misses'];refused+=z['Refused']-a['Refused']
       if gpu:
        hosts=[v['SceneHost']for v in x['native_sample']['SourceDetails']['Records']if v.get('SceneHost',{}).get('CaptureAttempted')];need(len(hosts)==1 and hosts[0]['DrawAccepted']and not hosts[0]['Fallback']and not hosts[0]['Reused'],'actual GPU capture')
       rows.append({'index':x['index'],'tag':x['tag'],'generation':x['generation'],'horizontal':x['index']%8==7,'hits':hit,'misses':miss,'refused':refused,'observers':obs})
      horizontal=[x for x in rows if x['horizontal']];feasible=len(horizontal)==15 and all(x['hits']+x['misses']>=10 and x['hits']/(x['hits']+x['misses'])>=.8 for x in horizontal)
      (directory/'reuse.json').write_text(json.dumps(rows,indent=2)+'\n');d['cases'][mode]={'exit_code':outcome['exit_code'],'samples':len(rows),'horizontal_frames':len(horizontal),'horizontal_hits':sum(x['hits']for x in horizontal),'horizontal_misses':sum(x['misses']for x in horizontal),'feasible':feasible};print(json.dumps({'mode':mode,**d['cases'][mode]}),flush=True)
     else:
      runs={'baseline':[],'candidate':[]};case={k:[]for k in runs}
      for pair in range(5):
       for label in(['baseline','candidate']if pair%2==0 else['candidate','baseline']):
        boundary();directory=W/'ordinary'/mode/f'{pair+1}-{label}';samples,outcome=b.run_case(Path(plan['binaries'][label]['path']),directory,10000,False,120,128,False,180,gpu_scene_rendering=gpu);need(b'resolved.shape.diagnostic'not in(directory/'native.log').read_bytes(),'diagnostic leaked');runs[label].append(samples);item={'directory':str(directory),'exit_code':outcome['exit_code'],'ui_work_ns':b.distribution([x['metrics']['ui_work_ns']for x in samples]),'alloc_bytes':b.distribution([x['go_process_alloc_bytes']for x in samples])};case[label].append(item);print(json.dumps({'mode':mode,'pair':pair+1,'build':label,'p95_ms':item['ui_work_ns']['p95']/1e6}),flush=True)
       b.compare_geometry(runs['baseline'][-1],runs['candidate'][-1])
      novel={};novel_data={}
      for label in['baseline','candidate']:
       boundary();directory=W/'novel'/mode/label;samples,outcome=b.run_case(Path(plan['binaries'][label]['path']),directory,10000,False,120,128,True,180,gpu_scene_rendering=gpu);novel_data[label]=samples;novel[label]={'exit_code':outcome['exit_code'],'directory':str(directory),'ui_work_ns':b.distribution([x['metrics']['ui_work_ns']for x in samples])}
      b.compare_geometry(novel_data['baseline'],novel_data['candidate'])
      d['cases'][mode]={'ordinary':case,'novel':novel}
    d['result']='MEASURED'
   boundary();d['prepared_after']={str(root):prepared(root)for root in[C,T]};need(d['prepared_after']==plan['prepared'],'prepared after')
   if phase=='diagnostics':
    assessment={'comparison_admitted':all(v['feasible']for v in d['cases'].values()),'cases':d['cases'],'scope':'Diagnostic counters only, no timing acceptance.'};(W/'diagnostic-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:done.set();stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'error':d['error']}),flush=True)
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in[['prepare'],['gpu'],['diagnostics'],['comparison']],'fixed phase');prepare()if sys.argv[1]=='prepare'else run(sys.argv[1])
