from pathlib import Path
import hashlib,json,statistics
W=Path(__file__).resolve().parent
r=json.loads((W/'comparison-result.json').read_text());assert r['result']=='MEASURED'
plan=json.loads((W/'native-plan.json').read_text());limit=plan['ordinary'];out={'source_base':r['source_base'],'cases':{},'runtime_changed':False,'closed_mac_gates':[],'ordinary_samples_recomputed':0}
def nr(values,p):
 values=sorted(values);return values[(len(values)*p+99)//100-1]
def read_case(directory):
 p=Path(directory)/'native.log';raw=p.read_bytes();rows=[]
 for line in raw.splitlines():
  try:d=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if d.get('event')=='grid.perf.sample':rows.append(d)
 assert len(rows)==120 and b'resolved.shape.diagnostic'not in raw
 values=[x['metrics']['ui_work_ns']for x in rows];alloc=[x['go_process_alloc_bytes']for x in rows]
 return {'samples':120,'p95_ns':nr(values,95),'p99_ns':nr(values,99),'alloc_p50_bytes':nr(alloc,50),'log_sha256':hashlib.sha256(raw).hexdigest()}
for mode in ['gpu','cpu']:
 case=r['cases'][mode];runs={k:[read_case(x['directory'])for x in case['ordinary'][k]]for k in ['baseline','candidate']};assert all(len(v)==5 for v in runs.values())
 for label in runs:
  for a,z in zip(runs[label],case['ordinary'][label]):assert a['p95_ns']==z['ui_work_ns']['p95']and a['p99_ns']==z['ui_work_ns']['p99']
 med={k:statistics.median(x['p95_ns']for x in v)for k,v in runs.items()};p99={k:statistics.median(x['p99_ns']for x in v)for k,v in runs.items()};fail99={k:sum(x['p99_ns']>6000000 for x in v)for k,v in runs.items()};improvements=sum(a['p95_ns']>z['p95_ns']for a,z in zip(runs['baseline'],runs['candidate']))
 novel={k:read_case(v['directory'])for k,v in case['novel'].items()};novel_ok=novel['candidate']['p95_ns']<=novel['baseline']['p95_ns']+400000 and novel['candidate']['p99_ns']<=max(6000000,novel['baseline']['p99_ns'])
 adopted=med['baseline']-med['candidate']>=400000 and improvements>=4 and p99['candidate']<=p99['baseline']and fail99['candidate']<=fail99['baseline']and novel_ok
 out['cases'][mode]={'runs':runs,'median_run_p95_ns':med,'median_run_p99_ns':p99,'p99_failed_runs':fail99,'p95_improved_pairs':improvements,'median_run_p95_reduction_ns':med['baseline']-med['candidate'],'novel':novel,'novel_guard_met':novel_ok,'adoption_bar_met':adopted,'p95_failed_runs':{k:sum(x['p95_ns']>4000000 for x in v)for k,v in runs.items()},'median_of_run_alloc_p50_bytes':{k:statistics.median(x['alloc_p50_bytes']for x in v)for k,v in runs.items()}};out['ordinary_samples_recomputed']+=1200
out['adoption_bar_met']=all(v['adoption_bar_met']for v in out['cases'].values());out['result']='ADMIT_FOR_PRODUCTION_CHECKPOINT'if out['adoption_bar_met']else'REJECT_PRIVATE_OVERLAY';out['scope']='Fiveordinarypairs perCPU/GPU; novelseparateonepair. Per-runintegernearestrank, no pooled acceptance. Fullmatrix stillrequiredafteradoption.'
(W/'assessment.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['result','adoption_bar_met','ordinary_samples_recomputed','cases']},indent=2))
