//go:build offscreen

package core

import (
	"cogentcore.org/core/math32"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"context"
	"testing"
)

func TestVellumResolvedShapesRetireWithManualWindow(t *testing.T) {
	m, sc, _ := localFixture(t, 1)
	sh, ok := sc.TextShaper().(*shapedgt.Shaper)
	if !ok {
		t.Fatalf("actual backend %T", sc.TextShaper())
	}
	sty := rich.NewStyle()
	ts := text.NewStyle()
	ts.FontSize.Dots = 16
	tx := rich.NewText(sty, []rune("recycled value 12345"))
	first := sh.WrapLines(tx, sty, ts, math32.Vec2(200, 30))
	sh.WrapLines(tx, sty, ts, math32.Vec2(200, 30))
	if s := sh.ResolvedShapeStats(); s.Hits == 0 || s.Entries == 0 {
		t.Fatal("actual shaper cache not exercised", s)
	}
	if err := m.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	if s := sh.ResolvedShapeStats(); s != (shapedgt.ResolvedShapeStats{}) {
		t.Fatal("window close retained derived cache", s)
	}
	if len(first.Lines) == 0 || len(first.Lines[0].Runs) == 0 {
		t.Fatal("close damaged detached prior output")
	}
}
