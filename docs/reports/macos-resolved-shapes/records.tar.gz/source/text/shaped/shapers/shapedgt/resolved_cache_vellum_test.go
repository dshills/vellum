package shapedgt

import (
	"bytes"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/text"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	td "github.com/go-text/typesetting-utils/opentype"
	"github.com/go-text/typesetting/di"
	"github.com/go-text/typesetting/font"
	ot "github.com/go-text/typesetting/font/opentype"
	"github.com/go-text/typesetting/font/opentype/tables"
	"github.com/go-text/typesetting/language"
	"github.com/go-text/typesetting/shaping"
	"golang.org/x/image/math/fixed"
	"reflect"
	"testing"
)

func resolvedFixture(t *testing.T) (*Shaper, shaping.Input) {
	t.Helper()
	sh := NewShaperWithFonts(fonts.Embedded).(*Shaper)
	sty := rich.NewStyle()
	ts := text.NewStyle()
	ts.FontSize.Dots = 16
	runs := sh.Shape(rich.NewText(sty, []rune("12345")), ts)
	if len(runs) == 0 {
		t.Fatal("no fixture font")
	}
	face := runs[0].(*Run).Face
	if !face.SupportsBoundedOutlines() {
		t.Fatal("fixture must exercise static cache")
	}
	sh.ClearResolvedShapeCache()
	return sh, shaping.Input{Text: []rune("12345"), RunEnd: 5, Size: fixed.I(16), Face: face, Direction: di.DirectionLTR, Script: language.Latin, Language: language.NewLanguage("en")}
}
func TestVellumResolvedShapesExactInputAndDetachedOutputs(t *testing.T) {
	sh, base := resolvedFixture(t)
	original := func(in shaping.Input) shaping.Output { return sh.shaper.Shape(in) }
	variants := []struct {
		name   string
		change func(*shaping.Input)
	}{
		{"base", func(*shaping.Input) {}},
		{"size", func(in *shaping.Input) { in.Size = fixed.I(23) }},
		{"fractional-size", func(in *shaping.Input) { in.Size = fixed.I(16) + 1 }},
		{"range", func(in *shaping.Input) { in.RunStart = 1; in.RunEnd = 4 }},
		{"context", func(in *shaping.Input) { in.Text = []rune("x12345y"); in.RunStart = 1; in.RunEnd = 6 }},
		{"rtl", func(in *shaping.Input) { in.Direction = di.DirectionRTL }},
		{"ttb", func(in *shaping.Input) { in.Direction = di.DirectionTTB }},
		{"btt", func(in *shaping.Input) { in.Direction = di.DirectionBTT }},
		{"sideways", func(in *shaping.Input) { in.Direction.SetSideways(true) }},
		{"language", func(in *shaping.Input) { in.Language = language.NewLanguage("ar") }},
		{"script", func(in *shaping.Input) { in.Script = language.Arabic }},
		{"feature", func(in *shaping.Input) {
			in.FontFeatures = []shaping.FontFeature{{Tag: ot.MustNewTag("kern"), Value: 0}}
		}},
		{"feature-order", func(in *shaping.Input) {
			in.FontFeatures = []shaping.FontFeature{{Tag: ot.MustNewTag("kern"), Value: 1}, {Tag: ot.MustNewTag("liga"), Value: 0}}
		}},
		{"unicode-context", func(in *shaping.Input) { in.Text = []rune("بabcب"); in.RunStart = 1; in.RunEnd = 4 }},
	}
	for _, tc := range variants {
		t.Run(tc.name, func(t *testing.T) {
			in := base
			tc.change(&in)
			want := original(in)
			first := sh.shapeResolved(in)
			before := sh.ResolvedShapeStats()
			second := sh.shapeResolved(in)
			after := sh.ResolvedShapeStats()
			if !reflect.DeepEqual(first, want) || !reflect.DeepEqual(second, want) || after.Hits != before.Hits+1 {
				t.Fatal("not exact original/hit", before, after)
			}
			if len(first.Glyphs) > 0 {
				first.Glyphs[0].GlyphID = 0xffffffff
			}
			if got := sh.shapeResolved(in); !reflect.DeepEqual(got, want) {
				t.Fatal("returned glyph mutation entered cache")
			}
		})
	}
	// Input, feature and context slices are mutable; keys must own their values.
	in := base
	in.Text = []rune("12345")
	in.FontFeatures = []shaping.FontFeature{{Tag: ot.MustNewTag("kern"), Value: 0}}
	sh.shapeResolved(in)
	in.Text[0] = '9'
	in.FontFeatures[0].Value = 1
	if got, want := sh.shapeResolved(in), original(in); !reflect.DeepEqual(got, want) {
		t.Fatal("mutable input aliased cache")
	}
	// Distinct current Faces of one immutable Font must be returned as current.
	other := base
	other.Face = font.NewFace(base.Face.Font)
	got := sh.shapeResolved(other)
	if got.Face != other.Face || !reflect.DeepEqual(got, original(other)) {
		t.Fatal("cached mutable Face retained")
	}
	// Pixel sizing and current Font identity are part of the input authority.
	base.Face.SetPpem(17, 18)
	if got, want := sh.shapeResolved(base), original(base); !reflect.DeepEqual(got, want) {
		t.Fatal("Ppem change stale")
	}
	base.Face.SetPpem(0, 0)
	copied := *base.Face.Font
	other.Face = font.NewFace(&copied)
	before := sh.ResolvedShapeStats()
	sh.shapeResolved(other)
	if sh.ResolvedShapeStats().Misses != before.Misses+1 {
		t.Fatal("Font identity omitted")
	}
}
func TestVellumResolvedShapesBoundsAndReset(t *testing.T) {
	sh, in := resolvedFixture(t)
	saved := sh.shapeResolved(in)
	for i := 0; i < resolvedCacheEntries+40; i++ {
		in.Text = []rune(fmt.Sprintf("%06d", i))
		in.RunEnd = len(in.Text)
		sh.shapeResolved(in)
		s := sh.ResolvedShapeStats()
		if s.Bytes > resolvedCacheBytes || s.Entries > resolvedCacheEntries || s.Fonts > resolvedCacheFonts {
			t.Fatal("unbounded", s)
		}
	}
	if sh.ResolvedShapeStats().Entries != resolvedCacheEntries {
		t.Fatal("entry eviction not exercised")
	}
	// Force byte eviction independently of entry count.
	for i := 0; i < 600; i++ {
		v := fmt.Sprintf("%06d", i)
		for len(v) < 250 {
			v += "1234567890"
		}
		in.Text = []rune(v[:250])
		in.RunEnd = 250
		sh.shapeResolved(in)
	}
	if s := sh.ResolvedShapeStats(); s.Bytes > resolvedCacheBytes || s.Entries >= resolvedCacheEntries {
		t.Fatal("byte eviction not exercised", s)
	}
	// Distinct immutable Font identities, never extra mutable Face ownership.
	for i := 0; i < resolvedCacheFonts+2; i++ {
		f := *in.Face.Font
		in.Face = font.NewFace(&f)
		sh.shapeResolved(in)
	}
	if s := sh.ResolvedShapeStats(); s.Fonts > resolvedCacheFonts {
		t.Fatal("font references unbounded", s)
	}
	sh.ClearResolvedShapeCache()
	if s := sh.ResolvedShapeStats(); s != (ResolvedShapeStats{}) {
		t.Fatal("reset retains state", s)
	}
	if len(saved.Glyphs) == 0 || saved.Face == nil {
		t.Fatal("reset invalidated prior owned result")
	}
}
func TestVellumResolvedShapesRefusalAndFullContextKey(t *testing.T) {
	sh, in := resolvedFixture(t)
	// Even outside the shaped range, a changed context must miss.
	in.Text = []rune("x123y")
	in.RunStart = 1
	in.RunEnd = 4
	sh.shapeResolved(in)
	before := sh.ResolvedShapeStats()
	in.Text[0] = 'z'
	sh.shapeResolved(in)
	if sh.ResolvedShapeStats().Misses != before.Misses+1 {
		t.Fatal("outside-run context omitted")
	}
	in.Text = make([]rune, resolvedCacheRunes+1)
	for i := range in.Text {
		in.Text[i] = 'a'
	}
	in.RunStart = 0
	in.RunEnd = len(in.Text)
	before = sh.ResolvedShapeStats()
	got, want := sh.shapeResolved(in), sh.shaper.Shape(in)
	if !reflect.DeepEqual(got, want) || sh.ResolvedShapeStats().Entries != before.Entries {
		t.Fatal("oversized request not ordinary")
	}
	in.Text = []rune("123")
	in.RunEnd = 3
	in.Face.SetCoords(nil)
	// Invalid ranges are the original shaper's clamped behavior, not cache rules.
	in.RunStart = -2
	if got, want := sh.shapeResolved(in), sh.shaper.Shape(in); !reflect.DeepEqual(got, want) {
		t.Fatal("range fallback changed")
	}
}

func TestVellumResolvedShapesWarmEffectiveFaceAndEviction(t *testing.T) {
	sh, base := resolvedFixture(t)
	// Seed a completely independent unchanged warm HarfBuzz instance.
	var oracle shaping.HarfbuzzShaper
	oracle.SetFontCacheSize(2)
	// Fixture font discovery seeded its own HB cache; start the controlled
	// warm sequence from equal empty oracle/candidate font caches.
	sh.shaper = shaping.HarfbuzzShaper{}
	sh.shaper.SetFontCacheSize(2)
	first := font.NewFace(base.Face.Font)
	requested := font.NewFace(base.Face.Font)
	first.SetPpem(13, 14)
	requested.SetPpem(22, 23)
	inputs := []shaping.Input{base, base, base, base, base, base}
	inputs[0].Face = first
	inputs[1].Face = requested
	inputs[2].Face = requested
	// Same Font with different current Face still shapes through retained first.
	for i, in := range inputs[:3] {
		if got, want := sh.shapeResolved(in), oracle.Shape(in); !reflect.DeepEqual(got, want) {
			t.Fatal("warm effective face differs", i)
		}
	}
	before := sh.ResolvedShapeStats()
	first.SetPpem(31, 32)
	if got, want := sh.shapeResolved(inputs[1]), oracle.Shape(inputs[1]); !reflect.DeepEqual(got, want) {
		t.Fatal("effective face mutation stale")
	}
	if sh.ResolvedShapeStats().Misses != before.Misses+1 {
		t.Fatal("effective Ppem omitted from proof")
	}
	// Evict via other actual immutable Fonts, establishing a different first Face.
	for i := 0; i < 3; i++ {
		f := *base.Face.Font
		in := base
		in.Face = font.NewFace(&f)
		if got, want := sh.shapeResolved(in), oracle.Shape(in); !reflect.DeepEqual(got, want) {
			t.Fatal("other font differs")
		}
	}
	if got, want := sh.shapeResolved(inputs[1]), oracle.Shape(inputs[1]); !reflect.DeepEqual(got, want) {
		t.Fatal("post-eviction first face differs")
	}
	// A zero-size HB font cache evicts on each Put; resolved hits must still
	// prepare the ordinary font lifecycle rather than preserving a phantom first.
	sh = &Shaper{}
	sh.shaper.SetFontCacheSize(0)
	oracle = shaping.HarfbuzzShaper{}
	oracle.SetFontCacheSize(0)
	for i := 0; i < 3; i++ {
		f := *base.Face.Font
		in := base
		in.Face = font.NewFace(&f)
		sh.shapeResolved(in)
		oracle.Shape(in)
	}
	for _, in := range []shaping.Input{inputs[0], inputs[1], inputs[0], inputs[1]} {
		if got, want := sh.shapeResolved(in), oracle.Shape(in); !reflect.DeepEqual(got, want) {
			t.Fatal("zero-cache differs")
		}
	}
}

func TestVellumResolvedKeyPreservesRuneBits(t *testing.T) {
	_, in := resolvedFixture(t)
	in.Text = []rune{0x110000, 'x'}
	in.RunEnd = 2
	a, ok := resolvedInputKey(in)
	if !ok {
		t.Fatal("fixture ineligible")
	}
	in.Text[0] = 0x110001
	b, _ := resolvedInputKey(in)
	if a == b {
		t.Fatal("non-Unicode rune context collapsed through UTF-8")
	}
}

func TestVellumResolvedShapesDeviceAdjustedEffectiveFace(t *testing.T) {
	raw, err := td.Files.ReadFile("common/FreeSerif.ttf")
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(raw)
	if hex.EncodeToString(sum[:]) != "5e10cec8df1d1e517db9870457af12d17f3ef8ec61f7954801997a29f5b795c4" {
		t.Fatal("device fixture identity")
	}
	first, err := font.ParseTTF(bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	if !first.SupportsBoundedOutlines() {
		t.Fatal("device fixture must enter static cache")
	}
	requested := font.NewFace(first.Font)
	first.SetPpem(149, 149)
	requested.SetPpem(149, 149)
	in := shaping.Input{Text: []rune("กุ"), RunEnd: 2, Face: first, Size: fixed.I(150), Direction: di.DirectionLTR, Script: language.Thai, Language: language.NewLanguage("th")}
	sh := &Shaper{}
	var oracle shaping.HarfbuzzShaper
	cold := oracle.Shape(in)
	if got := sh.shapeResolved(in); !reflect.DeepEqual(got, cold) {
		t.Fatal("cold device fixture differs")
	}
	in.Face = requested
	want := oracle.Shape(in)
	before := sh.ResolvedShapeStats()
	got := sh.shapeResolved(in)
	if !reflect.DeepEqual(got, want) || sh.ResolvedShapeStats().Hits != before.Hits+1 {
		t.Fatal("warm same-font fixture not exercised")
	}
	// The requested Face stays at149; ONLY the retained effective Face changes.
	first.SetPpem(150, 150)
	want = oracle.Shape(in)
	before = sh.ResolvedShapeStats()
	got = sh.shapeResolved(in)
	if reflect.DeepEqual(cold.Glyphs, want.Glyphs) {
		t.Fatal("real GPOS device fixture is not discriminating")
	}
	if !reflect.DeepEqual(got, want) || sh.ResolvedShapeStats().Misses != before.Misses+1 {
		t.Fatal("cached current-face-only authority returned stale device adjustment")
	}
}

func TestVellumResolvedShapesCoordsAndUnsupportedFontStayOrdinary(t *testing.T) {
	sh, in := resolvedFixture(t)
	sh.shapeResolved(in)
	in.Face.SetCoords([]tables.Coord{1})
	before := sh.ResolvedShapeStats()
	if got, want := sh.shapeResolved(in), sh.shaper.Shape(in); !reflect.DeepEqual(got, want) {
		t.Fatal("coords fallback differs")
	}
	if stats := sh.ResolvedShapeStats(); stats.Entries != before.Entries || stats.Hits != before.Hits || stats.Refused != before.Refused+1 {
		t.Fatal("coords must exercise ordinary refusal", stats, before)
	}
	raw, err := td.Files.ReadFile("common/Raleway-v4020-Regular.otf")
	if err != nil {
		t.Fatal(err)
	}
	in.Face, err = font.ParseTTF(bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	if in.Face.SupportsBoundedOutlines() {
		t.Fatal("unsupported CFF fixture must bypass")
	}
	before = sh.ResolvedShapeStats()
	if got, want := sh.shapeResolved(in), sh.shaper.Shape(in); !reflect.DeepEqual(got, want) {
		t.Fatal("CFF fallback differs")
	}
	if sh.ResolvedShapeStats().Entries != before.Entries {
		t.Fatal("unsupported retained")
	}
}
