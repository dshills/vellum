// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package shapedgt

import (
	"container/list"
	"encoding/binary"
	"slices"
	"strings"
	"unsafe"

	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/shaping"
)

const (
	resolvedCacheBytes   = 8 << 20
	resolvedCacheEntries = 2048
	resolvedCacheFonts   = 8
	resolvedCacheRunes   = 256
	resolvedCacheGlyphs  = 256
)

type resolvedKey struct {
	effectiveX, effectiveY   uint16
	font                     *font.Font
	text, features, language string
	start, end, size         int
	script                   uint32
	direction                uint8
	xPpem, yPpem             uint16
}

type resolvedEntry struct {
	key    resolvedKey
	output shaping.Output // Face is nil; mutable faces never enter the cache.
	bytes  int
}

// ResolvedShapeStats reports private preparation reuse, not paint/presentation.
// Bytes bounds owned keys/glyphs plus conservative per-entry metadata; it does
// not bound the immutable fonts' backing tables or whole-process retention.
type ResolvedShapeStats struct {
	Hits, Misses, Refused uint64
	Bytes, Entries, Fonts int
}

type resolvedShapeCache struct {
	entries map[resolvedKey]*list.Element
	fonts   map[*font.Font]int
	lru     list.List
	bytes   int
	stats   ResolvedShapeStats
}

// Ordinary segmentation and font resolution precede this boundary on EVERY
// call. Preserve their fallback, script/query state and callbacks. Cache only
// the deterministic resolved static-font shaping request; full context matters
// even outside RunStart:RunEnd. Never key rich-style runes through UTF-8 (their
// metadata may exceed Unicode); binary encoding preserves all input bits.
func resolvedInputKey(in shaping.Input) (resolvedKey, bool) {
	if in.Face == nil || !in.Face.SupportsBoundedOutlines() || len(in.Face.Coords()) != 0 ||
		len(in.Text) == 0 || len(in.Text) > resolvedCacheRunes ||
		in.RunStart < 0 || in.RunEnd <= in.RunStart || in.RunEnd > len(in.Text) ||
		in.Size <= 0 || len(in.FontFeatures) > 16 || len(in.Language) > 128 {
		return resolvedKey{}, false
	}
	var raw [resolvedCacheRunes * 4]byte
	for i, r := range in.Text {
		binary.LittleEndian.PutUint32(raw[i*4:], uint32(r))
	}
	var features [16 * 8]byte
	for i, f := range in.FontFeatures {
		binary.LittleEndian.PutUint32(features[i*8:], uint32(f.Tag))
		binary.LittleEndian.PutUint32(features[i*8+4:], f.Value)
	}
	x, y := in.Face.Ppem()
	return resolvedKey{font: in.Face.Font, text: string(raw[:len(in.Text)*4]),
		features: string(features[:len(in.FontFeatures)*8]), language: string(in.Language),
		start: in.RunStart, end: in.RunEnd, size: int(in.Size), script: uint32(in.Script),
		direction: uint8(in.Direction), xPpem: x, yPpem: y}, true
}

func (sh *Shaper) shapeResolved(in shaping.Input) shaping.Output {
	key, eligible := resolvedInputKey(in)
	if !eligible {
		if sh.resolved != nil {
			sh.resolved.stats.Refused++
		}
		return sh.shaper.Shape(in)
	}
	// Shape's own font LRU retains the first Face for a Font. Perform that
	// original admission/touch even on hits, and prove the effective state.
	effective := sh.shaper.PreparedFace(in.Face)
	if effective.Font != in.Face.Font || len(effective.Coords()) != 0 {
		return sh.shaper.Shape(in)
	}
	key.effectiveX, key.effectiveY = effective.Ppem()
	if sh.resolved == nil {
		sh.resolved = &resolvedShapeCache{entries: make(map[resolvedKey]*list.Element), fonts: make(map[*font.Font]int)}
	}
	c := sh.resolved
	if element := c.entries[key]; element != nil {
		c.stats.Hits++
		c.lru.MoveToFront(element)
		out := element.Value.(*resolvedEntry).output
		out.Face = in.Face
		out.Glyphs = slices.Clone(out.Glyphs)
		return out
	}
	c.stats.Misses++
	out := sh.shaper.Shape(in)
	if len(out.Glyphs) == 0 || len(out.Glyphs) > resolvedCacheGlyphs {
		return out
	}
	// Reserve conservative metadata before retaining any request/result. The
	// cache has no application, widget, mutable Face, callback or input slices.
	owned := out
	owned.Face = nil
	owned.Glyphs = slices.Clone(out.Glyphs)
	weight := 512 + int(unsafe.Sizeof(resolvedEntry{})) + len(key.text) + len(key.features) + len(key.language) + cap(owned.Glyphs)*int(unsafe.Sizeof(shaping.Glyph{}))
	if weight > resolvedCacheBytes {
		return out
	}
	for c.bytes+weight > resolvedCacheBytes || len(c.entries) >= resolvedCacheEntries || c.fonts[key.font] == 0 && len(c.fonts) >= resolvedCacheFonts {
		element := c.lru.Back()
		if element == nil {
			return out
		}
		entry := element.Value.(*resolvedEntry)
		delete(c.entries, entry.key)
		c.fonts[entry.key.font]--
		if c.fonts[entry.key.font] == 0 {
			delete(c.fonts, entry.key.font)
		}
		c.bytes -= entry.bytes
		c.lru.Remove(element)
	}
	key.language = strings.Clone(key.language) // input may be a tiny substring
	entry := &resolvedEntry{key: key, output: owned, bytes: weight}
	c.entries[key] = c.lru.PushFront(entry)
	c.fonts[key.font]++
	c.bytes += weight
	return out
}

// ResolvedShapeStats returns counters under the same mutex as Shape/WrapLines.
func (sh *Shaper) ResolvedShapeStats() ResolvedShapeStats {
	sh.Lock()
	defer sh.Unlock()
	if sh.resolved == nil {
		return ResolvedShapeStats{}
	}
	s := sh.resolved.stats
	s.Bytes, s.Entries, s.Fonts = sh.resolved.bytes, len(sh.resolved.entries), len(sh.resolved.fonts)
	return s
}

// ClearResolvedShapeCache retires derived glyph storage and immutable font
// references. Previously returned output remains detached and valid. Window
// retirement uses this optional capability; offline owners can clear it too.
func (sh *Shaper) ClearResolvedShapeCache() {
	sh.Lock()
	defer sh.Unlock()
	sh.resolved = nil
}
