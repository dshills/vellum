from pathlib import Path
p=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-resolved-shapes/README.md')
s=p.read_text().replace('afterward; both C/T roots are clean. Sampled process inspection finds no matching','afterward; both C/T roots are clean at the recorded terminal snapshots, before\nthese documentation edits. Sampled process inspection finds no matching').replace('No executable, SDK archive or font copy is included. One scoped Anthropic Claude\nSonnet 5.5 Prism review covers the completed rejection documentation; internal','No executable, SDK archive or font copy is included. One scoped Anthropic Claude\nSonnet 5.5 Prism review is planned for the completed rejection documentation; internal')
p.write_text(s)
