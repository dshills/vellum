from pathlib import Path
import json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=(T/'drivers/cogent/grid_retained.go').read_text();s=s.replace('"html"','"html"\n "encoding/json"\n "os"\n "cogentcore.org/core/text/shaped/shapers/shapedgt"')
needle='''	for text := range g.layoutDirty {''';assert s.count(needle)==1
s=s.replace(needle,''' beforeShapes := w.Scene.TextShaper().(*shapedgt.Shaper).ResolvedShapeStats()
'''+needle)
needle='''	w.Position()
	w.ApplyScenePos()
	return true''';assert s.count(needle)==1
s=s.replace(needle,''' afterShapes := w.Scene.TextShaper().(*shapedgt.Shaper).ResolvedShapeStats()
 _ = json.NewEncoder(os.Stdout).Encode(map[string]any{"event":"resolved.shape.diagnostic", "generation":g.projection.State.Generation, "dirty":len(g.layoutDirty), "before":beforeShapes,"after":afterShapes})
'''+needle)
p=W/'diagnostic-grid-retained.go';p.write_text(s)
d=json.loads((W/'overlay.json').read_text());d['Replace'][str(T/'drivers/cogent/grid_retained.go')]=str(p);(W/'diagnostic-overlay.json').write_text(json.dumps(d,indent=2)+'\n');print('Diagnostic counts ONLY actual grid local-sizing requests, per generation; no environment switch')
