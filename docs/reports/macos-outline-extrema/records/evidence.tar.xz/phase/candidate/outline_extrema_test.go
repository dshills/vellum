// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"math"
	"math/rand/v2"
	"reflect"
	"testing"

	"cogentcore.org/core/math32"
	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/font/opentype"
)

// Independent original point loop, including the actual identity matrix math.
func originalOutlineBounds(outline font.GlyphOutline, scale float32, pos math32.Vector2) (math32.Box2, bool) {
	b := math32.Box2{}
	points := 0
	for _, s := range outline.Segments {
		var n int
		switch s.Op {
		case opentype.SegmentOpMoveTo, opentype.SegmentOpLineTo:
			n = 1
		case opentype.SegmentOpQuadTo:
			n = 2
		case opentype.SegmentOpCubeTo:
			n = 3
		default:
			return b, false
		}
		for _, arg := range s.Args[:n] {
			p := math32.Vec2(arg.X*scale+pos.X, -arg.Y*scale+pos.Y)
			q := math32.Identity2().MulPoint(p)
			if points == 0 {
				b = math32.Box2{Min: q, Max: q}
			} else {
				b.ExpandByPoint(q)
			}
			points++
			if !scenePoint(p) || !scenePoint(q) {
				return b, false
			}
		}
	}
	return b, true
}

func TestVellumOutlineExtremaOriginalPointOracle(t *testing.T) {
	face := vellumOutlineFace(t)
	cache := &staticOutlineCache{}
	rng := rand.New(rand.NewPCG(7, 11))
	for _, letter := range "AgéÅfj0123456789" {
		gid, _ := face.NominalGlyph(letter)
		outline, ok := cache.ordinary(face, gid)
		if !ok {
			t.Fatal("outline")
		}
		positions := []math32.Vector2{math32.Vec2(0, 0), math32.Vec2(1<<16, 0), math32.Vec2(-(1 << 16), 0), math32.Vec2(math.Nextafter32(1<<16, float32(math.Inf(1))), 0)}
		for range 500 {
			positions = append(positions, math32.Vec2((rng.Float32()-.5)*(1<<18), (rng.Float32()-.5)*(1<<18)))
		}
		for _, scale := range []float32{0, .001, .015625, .1, 1, 2, 1000} {
			for _, pos := range positions {
				want, accepted := originalOutlineBounds(outline, scale, pos)
				got, available, valid := cache.identitySceneBounds(face.Font, gid, outline, scale, pos)
				if !available || valid != accepted || valid && (!reflect.DeepEqual(got, want) || 1+int(got.Size().X)+int(got.Size().Y) != 1+int(want.Size().X)+int(want.Size().Y)) {
					t.Fatal("bounds/admission drift", letter, scale, pos, got, want, available, valid, accepted)
				}
			}
		}
	}
}

func TestVellumOutlineExtremaExactOwnerAndRefusal(t *testing.T) {
	face := vellumOutlineFace(t)
	gid, _ := face.NominalGlyph('A')
	cache := &staticOutlineCache{}
	own, _ := cache.ordinary(face, gid)
	public, _ := face.GlyphDataOutline(gid)
	if _, available, _ := cache.identitySceneBounds(face.Font, gid, public, 1, math32.Vector2{}); available {
		t.Fatal("caller-owned outline trusted")
	}
	for _, scale := range []float32{-1, float32(math.NaN()), float32(math.Inf(1))} {
		if _, available, _ := cache.identitySceneBounds(face.Font, gid, own, scale, math32.Vector2{}); available {
			t.Fatal("nonmonotonic scale trusted")
		}
	}
	if _, available, valid := cache.identitySceneBounds(face.Font, gid, own, 1, math32.Vec2(float32(math.NaN()), 0)); !available || valid {
		t.Fatal("invalid position admitted")
	}
	cache.mu.Lock()
	cache.evict()
	cache.mu.Unlock()
	if _, available, _ := cache.identitySceneBounds(face.Font, gid, own, 1, math32.Vector2{}); available {
		t.Fatal("evicted outline metadata reused")
	}
	bad := font.GlyphOutline{Segments: append([]font.Segment(nil), own.Segments...)}
	bad.Segments[0].Op = opentype.SegmentOp(255)
	if measureOutlineExtrema(bad).valid {
		t.Fatal("unknown operation summarized")
	}
}

func BenchmarkVellumOutlineIdentityPreflight(b *testing.B) {
	face := vellumOutlineFace(b)
	gid, _ := face.NominalGlyph('Å')
	cache := &staticOutlineCache{}
	outline, _ := cache.ordinary(face, gid)
	pos := math32.Vec2(123.25, 456.5)
	b.Run("Original", func(b *testing.B) {
		b.ReportAllocs()
		for range b.N {
			if _, ok := originalOutlineBounds(outline, .02, pos); !ok {
				b.Fatal("refused")
			}
		}
	})
	b.Run("Cached", func(b *testing.B) {
		b.ReportAllocs()
		for range b.N {
			if _, available, valid := cache.identitySceneBounds(face.Font, gid, outline, .02, pos); !available || !valid {
				b.Fatal("refused")
			}
		}
	})
}
