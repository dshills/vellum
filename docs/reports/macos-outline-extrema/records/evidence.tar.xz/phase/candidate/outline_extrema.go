// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"math"

	"cogentcore.org/core/math32"
	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/font/opentype"
)

// Extrema belong to one cache-owned immutable outline, never a caller's slice.
// Four font-unit values plus validity are fixed per admitted entry; existing
// entry/font/segment bounds also bound this metadata. They retain no new owners.
type outlineExtrema struct {
	minX, minY, maxX, maxY float32
	valid                  bool
}

func measureOutlineExtrema(outline font.GlyphOutline) outlineExtrema {
	e := outlineExtrema{}
	points := 0
	for _, segment := range outline.Segments {
		var count int
		switch segment.Op {
		case opentype.SegmentOpMoveTo, opentype.SegmentOpLineTo:
			count = 1
		case opentype.SegmentOpQuadTo:
			count = 2
		case opentype.SegmentOpCubeTo:
			count = 3
		default:
			return outlineExtrema{}
		}
		for _, p := range segment.Args[:count] {
			if math.IsNaN(float64(p.X)) || math.IsInf(float64(p.X), 0) || math.IsNaN(float64(p.Y)) || math.IsInf(float64(p.Y), 0) {
				return outlineExtrema{}
			}
			if points == 0 {
				e.minX, e.maxX, e.minY, e.maxY = p.X, p.X, p.Y, p.Y
			} else {
				e.minX = min(e.minX, p.X)
				e.maxX = max(e.maxX, p.X)
				e.minY = min(e.minY, p.Y)
				e.maxY = max(e.maxY, p.Y)
			}
			points++
		}
	}
	e.valid = points > 0
	return e
}

func (e outlineExtrema) identityBounds(scale float32, pos math32.Vector2) (math32.Box2, bool) {
	// Positive scaling/addition are monotonic float32 operations. Each extremum
	// is an actual input point and uses the same arithmetic as the original loop.
	b := math32.Box2{Min: math32.Vec2(e.minX*scale+pos.X, -e.maxY*scale+pos.Y),
		Max: math32.Vec2(e.maxX*scale+pos.X, -e.minY*scale+pos.Y)}
	return b, scenePoint(b.Min) && scenePoint(b.Max)
}

func (cache *staticOutlineCache) identitySceneBounds(f *font.Font, gid font.GID, outline font.GlyphOutline, scale float32, pos math32.Vector2) (math32.Box2, bool, bool) {
	if scale < 0 || math.IsNaN(float64(scale)) || math.IsInf(float64(scale), 0) || len(outline.Segments) == 0 {
		return math32.Box2{}, false, false
	}
	cache.mu.Lock()
	defer cache.mu.Unlock()
	element := cache.entries[outlineKey{f, gid}]
	if element == nil {
		return math32.Box2{}, false, false
	}
	entry := element.Value.(outlineEntry)
	if !entry.extrema.valid || len(entry.outline.Segments) != len(outline.Segments) || &entry.outline.Segments[0] != &outline.Segments[0] {
		return math32.Box2{}, false, false
	}
	b, valid := entry.extrema.identityBounds(scale, pos)
	return b, true, valid
}
