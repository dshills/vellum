// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"container/list"
	"sync"
	"unsafe"

	"github.com/go-text/typesetting/font"
)

const (
	outlineCacheBytes   = 2 << 20
	outlineCacheEntries = 1024
	outlineCacheFonts   = 8
	outlineCacheGlyph   = 64 << 10
	outlineSegmentBytes = int(unsafe.Sizeof(font.Segment{}))
)

type outlineKey struct {
	font *font.Font
	gid  font.GID
}

type outlineEntry struct {
	key     outlineKey
	outline font.GlyphOutline
	cost    font.GlyphOutlineCost
	bytes   int
	extrema outlineExtrema
}

// staticOutlineCache belongs to one renderer and its private paint captures.
// All returned segments are private borrowed read-only data: GlyphOutline only
// reads them. Never return them through the public font retrieval methods (whose
// outputs can be mutated with Sideways). Static Font tables/backing snapshots
// are immutable; a replacement Font has a different key. Size, DPI, paint and
// transforms do not change font-unit outlines. Variable/encoded/CFF fonts bypass.
// Limits bound segment capacity, entry count and font references per renderer,
// not total process/native/font bytes or allocator/map metadata. Renderer GC
// releases its cache; resizing keeps these size-independent outlines reusable.
type staticOutlineCache struct {
	mu      sync.Mutex
	entries map[outlineKey]*list.Element
	fonts   map[*font.Font]int
	lru     list.List
	bytes   int
}

func (rs *Renderer) staticOutlines() *staticOutlineCache {
	if rs.outlineCache == nil {
		rs.outlineCache = &staticOutlineCache{}
	}
	return rs.outlineCache
}

func (cache *staticOutlineCache) ordinary(face *font.Face, gid font.GID) (font.GlyphOutline, bool) {
	if face.SupportsBoundedOutlines() {
		budget := font.NewGlyphOutlineBudget(1<<20, 1<<20)
		if outline, ok := cache.bounded(face, gid, budget); ok {
			return outline, true
		}
	}
	// Cache admission must not change CPU font support or cause dropped glyphs.
	return face.GlyphDataOutline(gid)
}

func (cache *staticOutlineCache) bounded(face *font.Face, gid font.GID, budget *font.GlyphOutlineBudget) (font.GlyphOutline, bool) {
	if !face.SupportsBoundedOutlines() {
		return face.GlyphDataOutlineBounded(gid, budget)
	}
	key := outlineKey{face.Font, gid}
	cache.mu.Lock()
	defer cache.mu.Unlock()
	if element := cache.entries[key]; element != nil {
		entry := element.Value.(outlineEntry)
		// Warmth must not bypass composite/point/traversal admission or the
		// caller's shared batch budget. Later geometry/scanner checks remain.
		if !entry.cost.Charge(budget) {
			return font.GlyphOutline{}, false
		}
		cache.lru.MoveToFront(element)
		return entry.outline, true
	}
	outline, cost, ok := face.GlyphDataOutlineBoundedCost(gid, budget)
	if !ok {
		return font.GlyphOutline{}, false
	}
	cache.retain(key, outline, cost)
	return outline, true
}

// retain is called under mu only with a successful getter's owned result.
func (cache *staticOutlineCache) retain(key outlineKey, outline font.GlyphOutline, cost font.GlyphOutlineCost) {
	// Check capacity before multiplication and before retaining the allocation.
	// Oversized-but-admitted outlines still render; cache limits never cause a
	// new GPU refusal. Store the getter's own allocation without an extra copy.
	if cap(outline.Segments) > outlineCacheGlyph/outlineSegmentBytes {
		return
	}
	weight := cap(outline.Segments) * outlineSegmentBytes
	if cache.entries == nil {
		cache.entries = make(map[outlineKey]*list.Element)
		cache.fonts = make(map[*font.Font]int)
	}
	for cache.bytes+weight > outlineCacheBytes || len(cache.entries) >= outlineCacheEntries ||
		(cache.fonts[key.font] == 0 && len(cache.fonts) >= outlineCacheFonts) {
		cache.evict()
	}
	cache.entries[key] = cache.lru.PushFront(outlineEntry{key: key, outline: outline, cost: cost, bytes: weight, extrema: measureOutlineExtrema(outline)})
	cache.fonts[key.font]++
	cache.bytes += weight
}

func (cache *staticOutlineCache) evict() {
	element := cache.lru.Back()
	entry := element.Value.(outlineEntry)
	cache.bytes -= entry.bytes
	delete(cache.entries, entry.key)
	cache.fonts[entry.key.font]--
	if cache.fonts[entry.key.font] == 0 {
		delete(cache.fonts, entry.key.font)
	}
	cache.lru.Remove(element)
}
