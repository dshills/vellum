"""Persist only the reviewed overlay as a hash-pinned owned dependency stage."""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path('/private/tmp/vellum-large-data'); PHASE=Path('/private/tmp/vellum-macos-outline-extrema')
sha=lambda b:hashlib.sha256(b).hexdigest()
review=json.loads((PHASE/'overlay-source-review.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings']
overlay=json.loads((PHASE/'candidate-overlay.json').read_text())['Replace']
base=json.loads((PHASE/'baseline.json').read_text())['prepared']
prepared=ROOT/'drivers/cogent/build/upstream'
original={}; outputs={}; chunks=[]
for target,candidate in sorted(overlay.items()):
 t=Path(target); c=Path(candidate); relative=t.relative_to(prepared).as_posix()
 before=t.read_bytes() if t.exists() else None; after=c.read_bytes()
 assert sha(after)==review['reviewed_file_sha256'][str(c)]
 assert (sha(before) if before is not None else None)==base.get('upstream/'+relative)
 original[relative]=sha(before) if before is not None else None; outputs[relative]=sha(after)
 chunks.extend(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+relative if before else '/dev/null',tofile='b/'+relative))
stage=ROOT/'drivers/cogent/native/patches/outlineextrema'; stage.mkdir()
patch=stage/'0053-cache-identity-outline-extrema.patch'; patch.write_text(''.join(chunks))
for name,content in [('original-hashes.json',original),('output-hashes.json',outputs)]:
 (stage/name).write_text(json.dumps(content,indent=2)+'\n')
(stage/'README.md').write_text('''# Identity outline extrema

Patch 0053 summarizes the used control-point extrema of retained immutable static
TrueType outlines. Exact identity-transform GPU scene preflight checks cached
corners with the original float32 arithmetic. The original segment, retrieval and
extent-product work charges remain unchanged. Other transforms, foreign backing,
eviction and invalid summaries use the original point loop. Cold successfully
retained outlines can use their newly computed summary too.

Font/GID and segment-backing identity guard access under the existing cache mutex.
Four scalar extrema and validity add bounded metadata within the existing entry
limit; the 2 MiB limit continues to count segment capacity only. No public mutable
font output is retained. CPU rendering, glyph-mask paths and GPU admission limits
remain unchanged; the scene renderer remains opt-in.

The independent oracle covers actual glyphs, coordinate boundaries and random
positions, integer extent equivalence, refusal and eviction. Native parity and
matched whole-frame measurements are recorded in the Mac outline-extrema report.
They do not qualify physical GPU faults, presentation or full Mac acceptance.
New helpers/tests are MIT; modified upstream files retain their original notices.
Preparation verifies each original/output hash and the patch SHA256.
''')
manifest=ROOT/'drivers/cogent/native/dependencies.json'; m=json.loads(manifest.read_text())
upstream=next(d for d in m['dependencies'] if d['name']=='upstream')
upstream['stages'].append({'origin':'drivers/cogent/native/patches/outlineextrema','inputs':'native/patches/outlineextrema/original-hashes.json','outputs':'native/patches/outlineextrema/output-hashes.json','patches':[{'file':'native/patches/outlineextrema/'+patch.name,'sha256':sha(patch.read_bytes())}]})
manifest.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(outputs,indent=2))
