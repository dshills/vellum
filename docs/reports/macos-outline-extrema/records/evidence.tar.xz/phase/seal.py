"""Seal bounded source, selected checks and all retained measurement observations."""
from pathlib import Path
import hashlib,io,json,tarfile
from run import ROOT,PHASE,sha,identity
sources=json.loads((PHASE/'checkpoint-source.json').read_text())['sources']
assert len(sources)==9 and all(sha(ROOT/n)==h for n,h in sources.items())
formal=json.loads((PHASE/'formal-prepared.json').read_text());assert len(formal)==6200 and identity()['prepared']==formal
review=json.loads((PHASE/'final-source-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['findings']
assert review['reviewed_file_sha256']=={str(ROOT/n):h for n,h in sources.items()}
for key in ['reviewed_artifact_sha256']:
 for path,digest in review.get(key,{}).items():assert sha(path)==digest,path
receipts={}
for name in ['formal-race-v1','formal-adapter-race-v2','formal-vet-v1','formal-prepare-test-v1']:
 r=json.loads((PHASE/(name+'.json')).read_text());assert r['exit_code']==0 and r['error'] is None and r['source_delta_stable']
 assert r['prepared_before']==r['prepared_after']==formal
 for c in ['stdout','stderr']:assert sha(PHASE/(name+'.'+c))==r[c+'_sha256']
 receipts[name]=sha(PHASE/(name+'.json'))
r=json.loads((PHASE/'comparison-v2.json').read_text());assert r['exit_code']==0 and r['error'] is None and r['source_prepared_stable']
comparison=json.loads((PHASE/'comparison/qualification.json').read_text());assert comparison['result']=='PASS_MATCHED_COMPARISON' and comparison['processes']==40 and comparison['ordinary_samples']==4800
assert comparison['gpu_scene_rendering'] and comparison['warm_target_met']=={'baseline':False,'candidate':False}
assert comparison['summary_sha256']==sha(PHASE/'comparison/summary.json')
process=json.loads((PHASE/'prism-v1/process.json').read_text());prism=json.loads((PHASE/'prism-v1/prism.json').read_text())
assert process['exit_code']==0 and process['error'] is None and process['source_index_stable'] and process['before']==process['after']==sources
assert prism['coverage']['complete'] and prism['coverage']['files']==9 and not prism['findings']
q={'result':'REVIEWED_MAC_OUTLINE_EXTREMA','base_commit':identity()['commit'],'source':sources,'prepared_files':6200,'prepared_manifest_sha256':sha(PHASE/'formal-prepared.json'),'processes':40,'ordinary_samples':4800,'gpu_scene_opt_in':True,'latency_targets_met':False,'required_receipts':receipts,'comparison_sha256':sha(PHASE/'comparison/qualification.json'),'internal_review_sha256':sha(PHASE/'final-source-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':0,'prism_coverage_complete':True,'prism_sha256':sha(PHASE/'prism-v1/prism.json'),'limits':['Elapsed host UI work excludes queue wait/drawable acquisition and does not measure GPU completion/presentation.','Default CPU performance, completeP6, integratedP11, physicalGPU/human/release acceptance remainopen.']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records=ROOT/'docs/reports/macos-outline-extrema/records';records.mkdir()
suffixes={'.go','.py','.md','.txt','.json','.stdout','.stderr','.log','.patch','.png'}
members={'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes() for p in sorted(PHASE.rglob('*')) if p.is_file() and p.suffix in suffixes}
members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz') as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
checkpoint={**q,'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),'archive_members':len(index),'archive_index_verified':True,'qualification_sha256':sha(PHASE/'qualification.json'),'seal_producer_sha256':sha(__file__)}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
print(json.dumps({k:v for k,v in checkpoint.items() if k not in ['source','required_receipts']},indent=2))
