"""Package tested sources and exact inert/compile receipts without runtime claims."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-metadata')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
read=lambda q:json.loads(q.read_bytes())
bound=read(p/'source.json');review=read(p/'source-review.json')
assert review['source_ready']is True and review['unresolved_findings']==[] and review['execution_ready']is False
assert review['source_binding_sha256']==sha(p/'source.json')
sources=review['sources'];assert len(sources)==8 and all(sha(r/n)==h==bound['source_files'][n]for n,h in sources.items())
names=[n for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r,timeout=30).decode().split('\0')if n]
assert {n:sha(r/n)for n in names}==bound['source_files']
assert all(sha(p/n)==h for n,h in review['reviewed_artifact_sha256'].items())
checks={}
for case in ['inert','adapter','vet','compile-native-tests','compile-native-commands']:
 v=read(p/(case+'.json'));assert v['result']=='PASS_INERT_OFFSCREEN_OR_COMPILE_ONLY_CHECK'and v['source_and_prepared_stable']and v['exit_code']==0 and v['error']is None and v['live_ui_gpu_or_settings_admitted']is False
 assert v['source_binding_sha256']==sha(p/'source.json')and v['producer_sha256']==sha(p/'check.py')
 for channel,meta in v['logs'].items():
  q=p/(case+'.'+channel);assert sha(q)==meta['sha256']and q.stat().st_size==meta['bytes']
 for n,meta in v.get('compiled_binaries',{}).items():assert sha(p/'outputs'/n)==meta['sha256']and(p/'outputs'/n).stat().st_size==meta['bytes']and meta['executed']is False
 checks[case]={'receipt_sha256':sha(p/(case+'.json')),'argv':v['argv'],'exit_code':0,'elapsed_seconds':v['elapsed_seconds'],'logs':v['logs'],'compiled_binaries':v.get('compiled_binaries',{})}
controls=read(p/'negative-controls.json');assert controls['result']=='BOTH_SERIALIZER_FAULTS_FAIL_INERT_REGRESSION'and controls['main_source_unchanged']and controls['live_ui_gpu_or_settings_admitted']is False
assert controls['producer_sha256']==sha(p/'negative_controls.py')and controls['source_binding_sha256']==sha(p/'source.json')and controls['positive_receipt_sha256']==sha(p/'inert.json')
for name,v in controls['records'].items():
 assert v['result']=='EXPECTED_INERT_ASSERTION_FAILURE'and v['exit_code']==1 and v['source_stable']
 for channel,meta in v['logs'].items():
  q=p/('control-'+name+'.'+channel);assert sha(q)==meta['sha256']and q.stat().st_size==meta['bytes']
 root=p/'controls'/name
 assert all(sha(root/n)==h for n,h in v['source_files'].items())
prepared={q.relative_to(r/'drivers/cogent/build').as_posix():sha(q)for m in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/m).rglob('*'))if q.is_file()and not q.is_symlink()}
assert prepared==bound['prepared']and len(prepared)==6230
entries={}
for n in ['baseline.json','source.json','check.py','negative_controls.py','negative-controls.json','prepare_report.py','source-review.json','source-review.md']+[case+'.'+ext for case in checks for ext in ['json','stdout','stderr']]+['control-'+name+'.'+ext for name in controls['records']for ext in ['stdout','stderr']]:entries['evidence/'+n]=(p/n).read_bytes()
for n in sources:entries['tested-source/'+n]=(r/n).read_bytes()
for name in controls['records']:
 n='drivers/cogent/native_window_snapshot.h';entries['controls/'+name+'/native_window_snapshot.h']=(p/'controls'/name/n).read_bytes()
index={n:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for n,data in sorted(entries.items())}
report=r/'docs/reports/macos-window-metadata';records=report/'records';records.mkdir(parents=True,exist_ok=False)
with(records/'evidence.tar.xz').open('xb')as f:
 with tarfile.open(fileobj=f,mode='w:xz',format=tarfile.USTAR_FORMAT)as archive:
  for n,data in sorted(entries.items()):
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
with(records/'archive-index.json').open('x')as f:json.dump(index,f,indent=2);f.write('\n')
q={'schema':1,'result':'PASS_SCOPED_WINDOW_METADATA_SERIALIZATION_AND_COMPILATION','base_commit':bound['base_commit'],'source_files':sources,'tested_source_files':len(bound['source_files']),'prepared_files':len(prepared),'checks':checks,'negative_controls':{'receipt_sha256':sha(p/'negative-controls.json'),'cases':list(controls['records']),'semantics':'Two actual Go assertion failures (exit1) from omitted availability and removed content-class UTF-8 limit; Foundation only.'},'internal_source_review_sha256':sha(p/'source-review.json'),'archive':{'file':'evidence.tar.xz','sha256':sha(records/'evidence.tar.xz'),'bytes':(records/'evidence.tar.xz').stat().st_size,'members':len(index)},'archive_index_sha256':sha(records/'archive-index.json'),'compiled_native_executables_included':False,'compiled_native_executables_executed':False,'native_class_or_window_server_query_executed':False,'native_check_decoder_cases_executed':False,'hidden_window_identity_observed':False,'native_ownership_or_leak_qualified':False,'ordinary_performance_or_memory_qualified':False,'full_mac_qualified':False,'os_settings_changed':False,'prism_review':'Small internally reviewed diagnostic checkpoint between provider reviews; significant GPU diagnostics checkpoint still pending native checks.'}
with(records/'qualification.json').open('x')as f:json.dump(q,f,indent=2);f.write('\n')
text='''# Sampled Cocoa window metadata

Opt-in native diagnostics now record runtime window/content-view class names,
the signed Cocoa window number and explicit metadata availability. Class names
are limited to 256 UTF-8 bytes; invalid/oversized metadata refuses the snapshot.
The existing 64-window and wire bounds remain. No history registry or retained
native object is introduced. See the [contract](../../../specs/native-window-lifecycle.md#sampled-cocoa-window-metadata).

The actual serializer and the Go DTO are shared with an inert Foundation
fixture. Two targeted race tests pass for original boolean state, exact signed
number boundaries, missing views, UTF-8 byte limits and legacy absent metadata.
Two isolated faulty copies fail the same Go regression at the intended assertion.
The complete offscreen adapter race suite and vet pass. Native-check tests and
the services/window-cycle commands compile; those executables were not run.
Existing Cocoa deprecation and duplicate Objective-C library warnings remain
in the raw logs.

[Qualification](records/qualification.json) and [archive index](records/archive-index.json)
bind the tested source endpoint, receipts, raw logs, controls, producers and
internal source review in [the evidence archive](records/evidence.tar.xz).
The initial baseline clone/copy was an inline tool command; its source/prepared
vectors are preserved, with no prebound saved stage producer claimed. Producers
retain their original private paths. Compiled native binaries are excluded.

Runtime class queries and native-check partial-decode cases remain unexecuted.
The old hidden untitled Cocoa window is still unidentified. Class names describe
types and Cocoa may reuse window numbers; these fields establish neither managed
ownership, lifetime identity, deallocation nor a leak. Historical raw records
stay unchanged. Native sampling, current-source lifecycle, performance/memory,
overnight, physical/human and distribution acceptance remain open. No live UI,
GPU application or OS setting was used. This is a small internally reviewed
checkpoint between significant Prism reviews; it does not complete the Mac goal.
'''
with(report/'README.md').open('x')as f:f.write(text)
print(json.dumps({'result':q['result'],'checks':len(checks),'negative_controls':len(controls['records']),'archive':q['archive']}))
