"""Bounded inert Foundation/offscreen checks or native compilation only."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-metadata')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def identity():
 names=[n for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r,timeout=30).decode().split('\0')if n]
 assert all((r/n).is_file()and not(r/n).is_symlink()for n in names)
 sources={n:sha(r/n)for n in names};prepared={}
 for module in ['upstream','typesetting']:
  for q in sorted((r/'drivers/cogent/build'/module).rglob('*')):
   assert not q.is_symlink()
   if q.is_file():prepared[q.relative_to(r/'drivers/cogent/build').as_posix()]=sha(q)
 return sources,prepared
if sys.argv[1:] == ['freeze']:
 sources,prepared=identity();base=json.loads((p/'baseline.json').read_bytes());assert prepared==base['prepared']
 v={'result':'FROZEN_WINDOW_METADATA_SOURCE_AND_PREPARED','base_commit':base['base_commit'],'source_files':sources,'prepared':prepared,'producer_sha256':sha(Path(__file__)),'native_execution_authorized':False}
 with(p/'source.json').open('x')as f:json.dump(v,f,indent=2);f.write('\n')
 print(json.dumps({'result':v['result'],'source_files':len(sources),'prepared_files':len(prepared)}));sys.exit(0)
case=sys.argv[1];bound=json.loads((p/'source.json').read_bytes());before=identity();assert before==(bound['source_files'],bound['prepared'])
cases={
 'inert':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=30s','-v','-run','^TestNativeWindowMetadata','.'],
 'adapter':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=120s','./...'],
 'vet':['go','vet','-p=1','-tags=offscreen','./...'],
 'compile-native-tests':['go','test','-c','-race','-p=1','-tags=vellum_native_checks','-o',str(p/'outputs/native-checks.test'),'.'],
 'compile-native-commands':['go','build','-p=1','-tags=vellum_native_checks','-o',str(p/'outputs'),'./cmd/services-smoke','./cmd/window-cycle-smoke'],
}
argv=cases[case];env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
assert 'VELLUM_GPU_SCENE_TEST'not in env
(p/'outputs').mkdir(exist_ok=True)
v={'case':case,'argv':argv,'cwd':str(r/'drivers/cogent'),'producer_sha256':sha(Path(__file__)),'source_binding_sha256':sha(p/'source.json'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':None,'error':None,'live_ui_gpu_or_settings_admitted':False,'inert_foundation_executed':case in ['inert','adapter']}
start=time.monotonic()
try:
 with(p/(case+'.stdout')).open('xb')as out,(p/(case+'.stderr')).open('xb')as err:
  v['exit_code']=run_child(argv,cwd=r/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20).returncode
except BaseException as e:v['error']={'type':type(e).__name__,'message':str(e)}
finally:
 v['source_and_prepared_stable']=identity()==before
 v.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 v['logs']={n:{'bytes':(p/(case+'.'+n)).stat().st_size,'sha256':sha(p/(case+'.'+n))}for n in ['stdout','stderr']}
 if case.startswith('compile-')and v['exit_code']==0:
  names=['native-checks.test']if case=='compile-native-tests'else['services-smoke','window-cycle-smoke']
  v['compiled_binaries']={n:{'bytes':(p/'outputs'/n).stat().st_size,'sha256':sha(p/'outputs'/n),'executed':False}for n in names}
 v['result']='PASS_INERT_OFFSCREEN_OR_COMPILE_ONLY_CHECK'if v['exit_code']==0 and not v['error']and v['source_and_prepared_stable']else'FAILED_CHECK'
 with(p/(case+'.json')).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
 print(json.dumps({k:v[k]for k in ['result','case','exit_code','error','elapsed_seconds','source_and_prepared_stable']}))
if v['result']=='FAILED_CHECK':sys.exit(1)
