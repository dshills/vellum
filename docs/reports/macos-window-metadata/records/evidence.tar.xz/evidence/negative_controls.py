"""Two isolated serializer faults, observed by the same inert Go regression."""
from pathlib import Path
import datetime,hashlib,json,shutil,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-metadata')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
read=lambda q:json.loads(q.read_bytes())
positive=read(p/'inert.json');assert positive['result']=='PASS_INERT_OFFSCREEN_OR_COMPILE_ONLY_CHECK'
header='drivers/cogent/native_window_snapshot.h'
faults={
 'availability':('@"IdentityAvailable":@YES,',''),
 'content-class-byte-limit':(' || [contentViewClass lengthOfBytesUsingEncoding:NSUTF8StringEncoding]>VELLUM_WINDOW_CLASS_BYTES_MAX',''),
}
bound=read(p/'source.json')
assert all(sha(r/n)==h for n,h in bound['source_files'].items())
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
assert 'VELLUM_GPU_SCENE_TEST'not in env
records={}
for name,(original,replacement)in faults.items():
 root=p/'controls'/name;assert not root.exists()
 shutil.copytree(r,root,ignore=shutil.ignore_patterns('.git','docs','specs','prototypes','.github','examples'))
 target=root/header;text=target.read_text();assert text.count(original)==1
 target.write_text(text.replace(original,replacement))
 def identity():
  rows={}
  for q in sorted(root.rglob('*')):
   assert not q.is_symlink()
   if q.is_file():rows[q.relative_to(root).as_posix()]=sha(q)
  return rows
 before=identity();argv=['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=30s','-v','-run','^TestNativeWindowMetadataInertProductionSerializer$','.']
 start=time.monotonic()
 with(p/('control-'+name+'.stdout')).open('xb')as out,(p/('control-'+name+'.stderr')).open('xb')as err:
  code=run_child(argv,cwd=root/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20).returncode
 stdout=(p/('control-'+name+'.stdout')).read_text();stderr=(p/('control-'+name+'.stderr')).read_text()
 failure='metadata or original state was lost'if name=='availability'else'invalid or oversized UTF-8 metadata was accepted'
 assert code==1 and failure in stdout and '--- FAIL: TestNativeWindowMetadataInertProductionSerializer'in stdout and 'build failed'not in stderr.lower()
 assert identity()==before
 records[name]={'result':'EXPECTED_INERT_ASSERTION_FAILURE','argv':argv,'cwd':str(root/'drivers/cogent'),'exit_code':code,'elapsed_seconds':time.monotonic()-start,'failure':failure,'source_files':before,'source_stable':True,'logs':{c:{'bytes':(p/('control-'+name+'.'+c)).stat().st_size,'sha256':sha(p/('control-'+name+'.'+c))}for c in ['stdout','stderr']},'live_ui_gpu_or_settings_admitted':False}
 assert all(sha(r/n)==h for n,h in bound['source_files'].items())
 print(json.dumps({'control':name,'result':records[name]['result'],'exit_code':code}),flush=True)
v={'schema':1,'result':'BOTH_SERIALIZER_FAULTS_FAIL_INERT_REGRESSION','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer_sha256':sha(Path(__file__)),'source_binding_sha256':sha(p/'source.json'),'positive_receipt_sha256':sha(p/'inert.json'),'records':records,'main_source_unchanged':True,'live_ui_gpu_or_settings_admitted':False}
with(p/'negative-controls.json').open('x')as f:json.dump(v,f,indent=2);f.write('\n')
