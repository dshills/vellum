"""One authorized interleaved experiment using the repository's native runner."""
from pathlib import Path
import _thread, datetime, hashlib, importlib.util, json, os, platform, signal, subprocess, sys, threading
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
C = Path('/Users/dshills/Development/projects/Vellum')
P = Path('/private/tmp/vellum-ready-native-5482f9b')
STOP = W/'stop'
HEAD = '5482f9ba5027fcf80b876a1d5a32a45b5d6aefd9'
def load(name, path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sys.path.insert(0,str(T/'scripts'))
b = load('existing_grid_benchmark',T/'scripts/benchmark-grid.py')
l = load('existing_live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20).decode().strip()
def require(ok, message):
    if not ok: raise ValueError(message)
build=json.loads((W.parent/'macos-ready-native-build/result.json').read_text())
report={'result':'INCOMPLETE','authorization':'Human: I am signing out. The machine is yours. Fresh comparison only; old global stop retained.',
        'source':build['source'],'baseline_scope':build['baseline_scope'],'binaries':build['binaries'],
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'samples':120,'warmup':128,
        'runs_per_case':5,'runtime_environment':{'GOMAXPROCS':os.environ.get('GOMAXPROCS'),'GOMEMLIMIT':os.environ.get('GOMEMLIMIT')},'cases':{},'error':None,'physical_pointer_tested':False,
        'scope':'Ordinary native table elapsed UI work; no compositor/GPU time or full Mac qualification.'}
class TargetNotMet(Exception): pass
finished=threading.Event()
def watch():
    while not finished.wait(.2):
        if STOP.exists(): _thread.interrupt_main(); return
signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(InterruptedError('comparison terminated')))
def boundary():
    require(not STOP.exists(),'live stop requested')
    for root in [C,T]:require(git(root,'rev-parse','HEAD')==HEAD and not git(root,'status','--porcelain'),'clean frozen source')
    for x in build['binaries'].values():require(sha(x['path'])==x['sha256'],'optimized executable changed')
try:
    require(not (W/'result.json').exists() and not STOP.exists(),'fresh one-shot comparison')
    boundary()
    with l.LiveLease():
        report['host']=platform.platform()
        report['machine']={k:b.metadata_command(v,15) for k,v in {
            'cpu':['sysctl','-n','machdep.cpu.brand_string'], 'displays':['system_profiler','SPDisplaysDataType','-json'],
            'power':['pmset','-g','custom']}.items()}
        report['processes_before']=subprocess.check_output(['ps','-axo','pid,pgid,comm'],text=True,timeout=10)
        threading.Thread(target=watch,daemon=True).start()
        # Each build has five observations per case. Alternate first build by run,
        # and reverse the starting order for the next workload.
        for mode in ['gpu','cpu']:
            for variable in [False,True]:
                geometry={10000:{'baseline':[],'candidate':[]},1000000:{'baseline':[],'candidate':[]}}
                for rows in [10000,1000000]:
                    key=f'{mode}-{"variable" if variable else "fixed"}-{rows}'
                    entry={'candidate':{'runs':[]}}
                    report['cases'][key]=entry
                    values={'baseline':[],'candidate':[]}
                    for repeat in range(5):
                        order=['candidate']
                        for label in order:
                            boundary()
                            data,outcome=b.run_case(Path(build['binaries'][label]['path']),W/key/f'{repeat+1}-{label}',rows,variable,120,128,False,180,gpu_scene_rendering=(mode=='gpu'))
                            values[label].append(data);geometry[rows][label].append(data)
                            entry[label]['runs'].append({'directory':str(W/key/f'{repeat+1}-{label}'),'exit_code':outcome['exit_code'],'result':outcome['result'],'log_sha256':outcome['log_sha256'],'elapsed_seconds':outcome['elapsed_seconds']})
                            stats=b.distribution([x['metrics']['ui_work_ns'] for x in data])
                            print(json.dumps({'case':key,'run':repeat+1,'build':label,'p95_ms':stats['p95']/1e6,'p99_ms':stats['p99']/1e6}),flush=True)
                    for label in ['candidate']:
                        entry[label]['timings_ns']=b.summarize(values[label])
                        entry[label]['target_met']=b.warm_target_met({key:entry[label]},novel=False,source_details=False)
                    (W/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
                    if not entry['candidate']['target_met']: raise TargetNotMet(key)
                for label in ['candidate']:
                    for small,large in zip(geometry[10000][label],geometry[1000000][label]):b.compare_geometry(small,large)
        boundary()
        report['result']='MEASURED'
        report['candidate_table_target_met']=all(v['candidate']['target_met'] for v in report['cases'].values())
except TargetNotMet as e:
    report['result']='MEASURED_TARGET_NOT_MET';report['stopped_workload']=str(e);report['candidate_table_target_met']=False
except BaseException as e:
    report['error']={'type':type(e).__name__,'message':str(e)};report['result']='FAILED_OR_CANCELED'
finally:
    finished.set();STOP.touch()
    report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (W/'result.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':report['result'],'error':report['error'],'candidate_table_target_met':report.get('candidate_table_target_met')}),flush=True)
if report['error']:sys.exit(1)
