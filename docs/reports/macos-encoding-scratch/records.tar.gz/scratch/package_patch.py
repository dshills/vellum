from pathlib import Path
import difflib,hashlib,json,subprocess
T=Path('/private/tmp/vellum-macos-native-results-97aee13');base=T/'drivers/cogent/build/upstream';W=Path(__file__).resolve().parent;original=Path('/private/tmp/vellum-encoding-scratch-5482f9b/original');stage=T/'drivers/cogent/native/patches/encodingscratch';stage.mkdir(exist_ok=True)
names=['paint/renderers/sceneplan/packet.go','paint/renderers/sceneplan/encoding_scratch.go','paint/renderers/sceneplan/encoding_scratch_test.go','paint/renderers/gpuscene/renderer.go','paint/renderers/gpuscene/renderer_encoding_test.go','paint/renderers/gpuscene/native_input_timing_test.go']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={};outputs={};patch=[]
for name in names:
 old=original/name;new=base/name;inputs[name]=sha(old)if old.exists()else None;outputs[name]=sha(new)
 patch.extend(difflib.unified_diff(old.read_text().splitlines(True)if old.exists()else [],new.read_text().splitlines(True),fromfile='a/'+name if old.exists()else '/dev/null',tofile='b/'+name,n=4))
text=''.join(patch);(stage/'0078-bounded-encoding-scratch.patch').write_text(text);(W/'source.diff').write_text(text)
for n,d in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (stage/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
m=T/'drivers/cogent/native/dependencies.json';d=json.loads(m.read_text());up=next(x for x in d['dependencies']if x['name']=='upstream');entry={'origin':'drivers/cogent/native/patches/encodingscratch','inputs':'native/patches/encodingscratch/original-hashes.json','outputs':'native/patches/encodingscratch/output-hashes.json','patches':[{'file':'native/patches/encodingscratch/0078-bounded-encoding-scratch.patch','sha256':sha(stage/'0078-bounded-encoding-scratch.patch')}]}
if up['stages'][-1].get('origin')==entry['origin']:up['stages'][-1]=entry
else:up['stages'].append(entry)
m.write_text(json.dumps(d,indent=2)+'\n')
(stage/'README.md').write_text('''# Bounded GPU encoding scratch

Stage 0078 lets the serialized GPU scene renderer borrow four scalar byte arrays
for its checked synchronous queue-input writes. Aggregate retained capacities
are at most 1 MiB. Counts/position scratch and mask lookups remain per call;
no packet, font, image, native handle or application closure is retained here.
Cross-shaped growth resets backing before replacement; accepted encodings larger
than the cache limit retain the ordinary detached allocation path. The limit
never changes the original packet byte, operation or tile-reference admission.

Encode and EncodeGPU still return detached output. EncodeGPUWithScratch explicitly
borrows only until the next scratch use/reset. Every nonempty logical word is
written, and empty output padding is zeroed. Renderer resize and Release drop
backing. The immutable replay journal owns Packet objects only; neither it nor
GPU retirement keeps an Encoded value. Checked queue writes copy input bytes
before returning. Refusal keeps the existing CPU reconstruction/fallback path.

Coverage compares exact bytes over mixed masks, pixels, spans and covered clears;
large/small and cross-shaped changes; exact/first-over-cap limits; original tile
refusals and recovery; detached ownership; and resize/repeated release. The native
checked-write test overwrites scratch with different data before waiting/readback,
then exercises actual write refusal and recovery. Native latency, complete memory
accounting and full Mac qualification remain separate requirements.
''')
print(json.dumps({'files':len(names),'diff_bytes':len(text.encode()),'patch_sha256':sha(stage/'0078-bounded-encoding-scratch.patch')}))
