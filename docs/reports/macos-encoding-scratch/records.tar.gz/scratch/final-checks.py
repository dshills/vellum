from pathlib import Path
import hashlib,json,statistics,re,subprocess,sys,time
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;sys.path.insert(0,str(T/'scripts'));from child_process import run_child
checks=[]
for name,argv in [('vet',['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go','vet','-p=2','-modfile=/private/tmp/vellum-ready-native-5482f9b/loadedgrid.mod','-mod=readonly','-tags','offscreen','cogentcore.org/core/paint/renderers/sceneplan','cogentcore.org/core/paint/renderers/rasterx','cogentcore.org/core/paint/renderers/gpuscene']),('diff-check',['git','diff','--check'])]:
 start=time.monotonic()
 with (W/(name+'-final.stdout')).open('xb')as out,(W/(name+'-final.stderr')).open('xb')as err:r=run_child(argv,cwd=T/'examples/loadedgrid'if name=='vet'else T,timeout=180,stdout=out,stderr=err)
 checks.append({'name':name,'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start});assert r.returncode==0,name
native=json.loads((W/'native-comparison.json').read_text());bench={}
for mode in ['detached','borrowed']:
 rows=[tuple(map(int,m))for m in re.findall(r'BenchmarkVellumEncodingScratch/'+mode+r'-2\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(W/'benchmark.stdout').read_text())];assert len(rows)==5;bench[mode]={'ns_per_op':statistics.median(x[0]for x in rows),'bytes_per_op':statistics.median(x[1]for x in rows),'allocs_per_op':statistics.median(x[2]for x in rows)}
native_values={}
for name,c in native['cases'].items():native_values[name]={'median_run_p95_ns':statistics.median(x['ui_work_ns']['p95']for x in c['runs']),'median_run_alloc_bytes':statistics.median(x['go_process_alloc_bytes']['p50']for x in c['runs']),'target_met':c['target_met']}
r={'result':'PASS_ENCODING_WORKSPACE_CHECKPOINT_CHECKS','checks':checks,'source':json.loads((T/'drivers/cogent/native/patches/encodingscratch/output-hashes.json').read_text()),'benchmark':bench,'native_comparison':native_values,'native_frame_budgets_qualified':False,'prism_retained_findings':0,'prism_discarded_medium_findings':1,'native_comparison_result':native['result']};(W/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
