"""Current-candidate diagnostics, separate from ordinary qualification samples."""
from pathlib import Path
import _thread,hashlib,importlib.util,json,signal,sys,threading
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');STOP=W/'stop-diagnostics'
sys.path.insert(0,str(T/'scripts'))
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('grid_diagnostics',T/'scripts/benchmark-grid.py');l=load('live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
build=json.loads((W.parent/'macos-ready-native-build/result.json').read_text());binary=Path(build['binaries']['candidate']['path'])
d={'result':'INCOMPLETE','source':build['source'],'binary':build['binaries']['candidate'],'cases':{},'qualification':False,'error':None}
done=threading.Event()
def watch():
 while not done.wait(.2):
  if STOP.exists():_thread.interrupt_main();return
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(InterruptedError('diagnostic terminated')))
try:
 assert not STOP.exists() and not (W/'diagnostics.json').exists()
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binaries']['candidate']['sha256']
 with l.LiveLease():
  threading.Thread(target=watch,daemon=True).start()
  for mode in ['cpu-profile','source-details']:
   assert not STOP.exists()
   output=W/mode
   samples,outcome=b.run_case(binary,output,10000,False,480 if mode=='cpu-profile' else 120,128,False,180,cpu_profile=str(W/'current.pprof') if mode=='cpu-profile' else None,source_details=mode=='source-details',gpu_scene_rendering=True)
   d['cases'][mode]={'result':outcome['result'],'log_sha256':outcome['log_sha256'],'directory':str(output),'timings_ns':b.summarize([samples])}
   print(json.dumps({'diagnostic':mode,'result':outcome['result']}),flush=True)
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binaries']['candidate']['sha256']
 d['result']='PASS_CURRENT_CANDIDATE_DIAGNOSTICS'
except BaseException as e:
 d['result']='FAILED_OR_CANCELED_DIAGNOSTICS';d['error']={'type':type(e).__name__,'message':str(e)}
finally:
 done.set();STOP.touch()
 with (W/'diagnostics.json').open('x') as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'error':d['error']}),flush=True)
if d['error']:sys.exit(1)
