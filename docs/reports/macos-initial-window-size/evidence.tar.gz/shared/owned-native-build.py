"""Build an unchanged, clean native grid fixture for external stack sampling."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-native-grid-stacks-c5045bc');T=Path('/private/tmp/vellum-macos-native-results-97aee13');COMMIT='c5045bc76a6d06c4f127957453fa3321719d46a8'
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sys.path.insert(0,'/private/tmp/vellum-empty-text-native-isolated-v2')
from live_lease import LiveLease
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=15)
def identity():
 assert git('rev-parse','HEAD').decode().strip()==COMMIT and not git('status','--porcelain','-z')
 names=git('ls-files','-z').decode().split('\0')[:-1];tracked={n:sha(T/n)for n in names};prepared={}
 for module in ['upstream','typesetting']:
  for p in(T/'drivers/cogent/build'/module).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():prepared[p.relative_to(T/'drivers/cogent/build').as_posix()]=sha(p)
 assert len(tracked)==4616 and len(prepared)==6243
 return dict(commit=COMMIT,tracked=tracked,prepared=prepared)
def main():
 P.mkdir(mode=0o700);before=identity();(P/'source.json').write_text(json.dumps(before,indent=2)+'\n')
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
 exe=P/'loadedgrid';argv=['go','build','-p=1','-trimpath','-o',str(exe),'.'];d=dict(argv=argv,cwd=str(T/'examples/loadedgrid'),source_commit=COMMIT,source_sha256=sha(P/'source.json'),producer_sha256=sha(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False);start=time.monotonic()
 with(P/'build.stdout').open('xb')as out,(P/'build.stderr').open('xb')as err:r=run_child(argv,cwd=d['cwd'],env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20)
 d.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_stable=identity()==before)
 if r.returncode==0:
  m=run_child(['go','version','-m',str(exe)],env=env,capture_output=True,timeout=20);assert m.returncode==0 and not m.stderr;(P/'go-version.txt').write_bytes(m.stdout)
  text=m.stdout.decode();assert 'vcs.revision='+COMMIT in text and 'vcs.modified=false'in text and 'CGO_ENABLED=1'in text
  d.update(binary=dict(path=str(exe),bytes=exe.stat().st_size,sha256=sha(exe)),metadata_sha256=sha(P/'go-version.txt'))
 d['logs']={n:dict(bytes=(P/n).stat().st_size,sha256=sha(P/n))for n in ['build.stdout','build.stderr']};(P/'build.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert d['exit_code']==0 and d['source_stable']
if __name__=='__main__':main()
