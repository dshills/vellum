"""Two serial owned grid fixtures; sample only the exact child after warmup."""
from pathlib import Path
import datetime,hashlib,json,os,selectors,signal,subprocess,sys,time
sys.dont_write_bytecode=True
from build import P,T,W,COMMIT,identity,sha,LiveLease,child_environment,run_child
from child_process import terminate_owned_group
STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
def need(ok,message):
 if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_bytes())
def absent(pid):
 need(type(pid)is int and pid>0,'owned group identity')
 r=run_child(['ps','-axo','pid=,pgid=,stat='],env=child_environment(),capture_output=True,timeout=5)
 need(r.returncode==0 and not r.stderr and r.stdout.strip(),'process observation')
 for line in r.stdout.decode().splitlines():
  f=line.split();need(len(f)==3 and f[0].isdecimal()and f[1].isdecimal(),'ps fields');need(int(f[1])!=pid,'owned group remains')
 return dict(group=pid,members=[],observation_sha256=hashlib.sha256(r.stdout).hexdigest())
def retire(child,label,errors):
 if child is None:return dict(created=False)
 d=dict(created=True,pid=child.pid,group=child.pid,terminal=False,group_absent=False)
 def failed(stage,e):errors.append(dict(process=label,stage=stage,type=type(e).__name__,message=str(e)))
 try:
  if child.poll()is None:
   try:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=5)
   except(ProcessLookupError,subprocess.TimeoutExpired):pass
 except BaseException as e:failed('graceful-retirement',e)
 try:terminate_owned_group(child)
 except BaseException as e:failed('forced-retirement',e)
 try:
  if child.poll()is None:child.kill()
 except BaseException as e:failed('fallback-kill',e)
 try:d['exit_code']=child.wait(timeout=5);d['terminal']=child.poll()is not None
 except BaseException as e:failed('reap',e)
 for pipe in [child.stdout,child.stderr]:
  if pipe is not None:
   try:pipe.close()
   except BaseException as e:failed('pipe-close',e)
 try:d['group_observation']=absent(child.pid);d['group_absent']=True
 except BaseException as e:failed('group-observation',e)
 return d
def main():
 need(len(sys.argv)==2 and sys.argv[1]in ['cpu','gpu'],'fixed case')
 case=sys.argv[1];review=read(W/'readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'native readiness')
 pins=review['inputs'];need(all(sha(p)==h for p,h in pins.items()),'review pins')
 build=read(P/'build.json');source=read(P/'source.json');exe=Path(build['binary']['path'])
 need(build['exit_code']==0 and build['source_stable']and build['source_commit']==source['commit']==COMMIT,'clean build')
 need(identity()==source,'source vector')
 def stable():return all(sha(p)==h for p,h in pins.items())and sha(exe)==build['binary']['sha256']
 def stopping():return STOP.exists()or(P/'stop-live').exists()
 need(not stopping(),'human-return marker')
 with LiveLease()as lease:
  need(stable()and lease.held()and not stopping(),'launch admission')
  if case=='gpu':
   prior=read(P/'cpu/receipt.json');need(prior['result']=='COMPLETED_STACK_DIAGNOSTIC'and prior['source_stable']and prior['pins_stable'],'prior CPU diagnostic');absent(prior['native']['pid']);absent(prior['sampler']['pid'])
  out=P/case;out.mkdir(mode=0o700);profile=out/'native-stacks.txt'
  argv=[str(exe),'-perf','-rows=1000000','-perf-samples=1024','-perf-warmup=128']+(['-gpu-scene']if case=='gpu'else[])
  d=dict(case=case,argv=argv,cwd=str(T/'examples/loadedgrid'),source_commit=COMMIT,build_sha256=sha(P/'build.json'),review_sha256=sha(W/'readiness.json'),producer_sha256=sha(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=None,cleanup_errors=[],native_runtime_executed=False,physical_input_generated=False,settings_changes=False,watchdog_seconds=180,source_stable=False,pins_stable=False)
  native=sampler=None;start=time.monotonic();sample_start=None;counts=[0,0];digests=[hashlib.sha256(),hashlib.sha256()];eof=[False,False];pending=b''
  try:
   with(out/'native.stdout').open('xb')as stdout,(out/'native.stderr').open('xb')as stderr,(out/'sample.stdout').open('xb')as sout,(out/'sample.stderr').open('xb')as serr,selectors.DefaultSelector()as ready:
    need(stable()and lease.held()and not stopping(),'final admission')
    native=subprocess.Popen(argv,cwd=d['cwd'],env={**child_environment(True),'GOMAXPROCS':'2'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    d.update(native_runtime_executed=True,native_pid=native.pid)
    with(out/'owned-native.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(event='native.started',case=case,pid=native.pid)),flush=True)
    for i,pipe in enumerate([native.stdout,native.stderr]):ready.register(pipe,selectors.EVENT_READ,i)
    terminal=None
    while ready.get_map()or native.poll()is None or(sampler is not None and sampler.poll()is None):
     need(not stopping(),'human-return marker')
     if time.monotonic()-start>180:raise TimeoutError('native watchdog')
     if sampler is not None:
      if sampler.poll()not in [None,0]:raise OSError('sampler failed')
      if time.monotonic()-sample_start>40 and sampler.poll()is None:raise TimeoutError('sampler watchdog')
      need(all((out/n).stat().st_size<=1<<20 for n in ['sample.stdout','sample.stderr']),'sampler log bound')
      need(not profile.exists()or profile.stat().st_size<=16<<20,'stack output bound')
     if native.poll()is not None:
      if terminal is None:terminal=time.monotonic()
      if ready.get_map()and time.monotonic()-terminal>5:raise TimeoutError('pipe writers survived native child')
     for key,_ in ready.select(.1):
      data=os.read(key.fd,64<<10)
      if not data:eof[key.data]=True;ready.unregister(key.fileobj);continue
      i=key.data;accepted=min(len(data),[64<<20,4<<20][i]-counts[i])
      if accepted:
       stream=[stdout,stderr][i];need(stream.write(data[:accepted])==accepted,'short native log write');stream.flush();counts[i]+=accepted;digests[i].update(data[:accepted])
      need(accepted==len(data),'native log bound')
      if i==0 and sampler is None:
       pending+=data;need(len(pending)<=256<<10,'warmup parser bound')
       while b'\n'in pending:
        line,pending=pending.split(b'\n',1);record=json.loads(line)
        if record.get('event')=='grid.perf.sample':
         need(record.get('index')==0 and record.get('warmup_guard')==1 and record.get('callbacks')==1,'first measured frame')
         need(native.poll()is None and not profile.exists()and not stopping(),'sampler target admission')
         sargv=['/usr/bin/sample',str(native.pid),'8','1','-mayDie','-file',str(profile)]
         sample_start=time.monotonic();sampler=subprocess.Popen(sargv,env=child_environment(False),stdout=sout,stderr=serr,start_new_session=True)
         d['sampler_argv']=sargv;d['sample_started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['trigger']=record;pending=b''
         with(out/'owned-sampler.json').open('x')as f:f.write(json.dumps(dict(pid=sampler.pid,group=sampler.pid,argv=sargv,target_pid=native.pid),indent=2)+'\n')
         print(json.dumps(dict(event='sampler.started',case=case,pid=sampler.pid,target=native.pid)),flush=True);break
    need(sampler is not None,'no measured frame/sampler')
    d['native_exit_code']=native.wait(timeout=5);d['sampler_exit_code']=sampler.wait(timeout=5)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   d['sampler']=retire(sampler,'sampler',d['cleanup_errors']);d['native']=retire(native,'native',d['cleanup_errors'])
   try:d['source_stable']=identity()==source;d['pins_stable']=stable()
   except BaseException as e:d['cleanup_errors'].append(dict(stage='source/pins',type=type(e).__name__,message=str(e)))
   try:
    d['logs']={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in ['native.stdout','native.stderr','sample.stdout','sample.stderr']}
    d['native_logs_complete']=all(eof)and all(d['logs'][n]['bytes']==counts[i]and d['logs'][n]['sha256']==digests[i].hexdigest()for i,n in enumerate(['native.stdout','native.stderr']))
    d['profile']=dict(bytes=profile.stat().st_size,sha256=sha(profile))if profile.exists()else None
   except BaseException as e:d['cleanup_errors'].append(dict(stage='output',type=type(e).__name__,message=str(e)))
   d.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),lease_held_through_cleanup=lease.held(),stop_marker_at_exit=stopping())
   good=d['error']is None and not d['cleanup_errors']and d.get('native_exit_code')==d.get('sampler_exit_code')==0 and d['native'].get('terminal')and d['native'].get('group_absent')and d['sampler'].get('terminal')and d['sampler'].get('group_absent')and d.get('native_logs_complete')and all(d['logs'][n]['bytes']<=1<<20 for n in ['sample.stdout','sample.stderr'])and d['source_stable']and d['pins_stable']and d.get('profile')is not None and 0<d['profile']['bytes']<=16<<20 and lease.held()and not stopping()
   d['result']='COMPLETED_STACK_DIAGNOSTIC'if good else'FAILED_OR_CANCELED_STACK_DIAGNOSTIC'
   with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
   print(json.dumps({k:d[k]for k in ['case','result','error','cleanup_errors','elapsed_seconds']}),flush=True)
  need(good,'stack diagnostic failed')
if __name__=='__main__':main()
