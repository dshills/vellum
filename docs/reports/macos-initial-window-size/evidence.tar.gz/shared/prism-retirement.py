"""Run the reviewed public release diagnostic, retaining partial failure evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import time

ROOT = Path('/private/tmp/vellum-native-attestation-probe-20261016')
STOP = Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def attempt(errors, label, function, default=None):
    try:
        return function()
    except Exception as error:
        errors.append(label + ': ' + type(error).__name__ + ': ' + str(error))
        return default


def group_absent(pid, observations=None):
    # On this host killpg(pgid, 0) can return EPERM during group retirement.
    # Neither EPERM nor ESRCH is used as an absence claim: inspect a fresh,
    # successful process-table snapshot and retain only this owned group.
    result = subprocess.run(['/bin/ps', '-axo', 'pid=,pgid=,stat='],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=2)
    entry = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 exit_code=result.returncode,
                 stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                 stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    if observations is not None:
        observations.append(entry)
    if result.returncode != 0 or len(result.stdout) > (1 << 20) or result.stderr:
        raise RuntimeError('owned group process-table snapshot failed')
    matches = []
    for line in result.stdout.decode('utf-8', errors='strict').splitlines():
        fields = line.split()
        if len(fields) != 3:
            raise ValueError('malformed process-table row')
        process, group = int(fields[0]), int(fields[1])
        if group == pid:
            matches.append(dict(pid=process, pgid=group, state=fields[2]))
    entry['owned_matches'] = matches
    return not matches


def retire_owned(child, errors, grace=1.0):
    """All groups here originate from this runner's start_new_session Popen.

    A direct child exiting does not prove its group is empty. Each operation is
    independently attempted so a failed signal/wait cannot skip later cleanup.
    """
    if child is None:
        return dict(terminal_exit_code=None, owned_group_absent=True)
    observations = []
    absent = attempt(errors, 'initial owned group observation', lambda: group_absent(child.pid, observations), False)
    for sig in [signal.SIGTERM, signal.SIGKILL]:
        if absent:
            break
        attempt(errors, 'owned group signal ' + str(sig), lambda: os.killpg(child.pid, sig))
        attempt(errors, 'owned direct child reap ' + str(sig), lambda: child.wait(timeout=grace))
        until = time.monotonic() + grace
        while time.monotonic() < until:
            absent = attempt(errors, 'owned group observation ' + str(sig), lambda: group_absent(child.pid, observations), False)
            if absent:
                break
            attempt(errors, 'owned group grace pause', lambda: time.sleep(min(0.05, grace)))
    # Group operations can fail independently of the direct child. Popen.kill
    # checks its own child identity/liveness and supplies a separate fallback.
    alive = attempt(errors, 'owned direct child liveness', child.poll)
    if alive is None:
        attempt(errors, 'owned direct child kill fallback', child.kill)
    code = attempt(errors, 'final owned direct child reap', lambda: child.wait(timeout=grace))
    absent = attempt(errors, 'final owned group observation', lambda: group_absent(child.pid, observations), False)
    return dict(terminal_exit_code=code, owned_group_absent=absent,
                owned_group_observations=observations)


def execute(config, out, stop, preflight_sha, review_sha):
    # Exclusive creation precedes execution. A collision never overwrites evidence.
    out.mkdir()
    errors = []
    start = time.monotonic()
    record = dict(schema='vellum.release-assertion-execution.v2', success=False,
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  preflight_sha256=preflight_sha, review_sha256=review_sha,
                  authentication_used=False, native_runtime_executed=False)
    child = None
    verified = False
    try:
        (out / 'run-verifier.py').write_bytes(Path(__file__).read_bytes())
        record['producer_sha256'] = sha(__file__)
        assert all(sha(p) == digest for p, digest in config['inputs'].items())
        assert not stop.exists()
        argv = [config['binary'], '-bundle', config['bundle'], '-zip', config['zip'],
                '-expected', config['expected'], '-out', str(out / 'trust'),
                '-unrelated-root', config['unrelated_root'],
                '-trust-responses', config['trust_responses'], '-meta', config['meta']]
        record['argv'] = argv
        env = {k: v for k, v in os.environ.items() if k in
               ['PATH', 'TMPDIR', 'LANG', 'LC_ALL', 'SSL_CERT_FILE', 'SSL_CERT_DIR']}
        env.update(HOME=str(ROOT / 'empty-home'), GH_CONFIG_DIR=str(ROOT / 'no-gh-config'),
                   XDG_CACHE_HOME=str(ROOT / 'xdg-cache'), GOMAXPROCS='2',
                   GH_PROMPT_DISABLED='1', GH_NO_UPDATE_NOTIFIER='1',
                   GH_NO_EXTENSION_UPDATE_NOTIFIER='1', NO_COLOR='1')
        with (out / 'stdout.json').open('xb') as stdout, (out / 'stderr').open('xb') as stderr:
            child = subprocess.Popen(argv, env=env, cwd=ROOT, stdout=stdout, stderr=stderr,
                                     start_new_session=True)
            record['owned_pid'] = child.pid
            while child.poll() is None:
                if stop.exists():
                    raise RuntimeError('user return stop marker')
                if time.monotonic() - start > 120:
                    raise TimeoutError('owned verifier watchdog')
                if (out / 'stdout.json').stat().st_size > (4 << 20) or (out / 'stderr').stat().st_size > (64 << 10):
                    raise RuntimeError('owned verifier log limit exceeded')
                time.sleep(0.1)
            record['exit_code'] = child.wait()
        assert record['exit_code'] == 0, 'verifier failed; retain detailed output'
        result = json.loads((out / 'stdout.json').read_bytes())
        assert result['success'] is True and len(result['controls']) == 27
        assert all(c['passed'] is True for c in result['controls'])
        assert result['authentication_used'] is False and result['build_provenance_qualified'] is False
        verified = True
        record.update(positive_crypto_and_policy_verified=True, negative_controls_passed=27)
    except Exception as error:
        errors.append('execution: ' + type(error).__name__ + ': ' + str(error))
    finally:
        cleanup = attempt(errors, 'retirement routine', lambda: retire_owned(child, errors), {})
        record.update(cleanup)
        observed = {p: attempt(errors, 'terminal input hash ' + p, lambda p=p: sha(p))
                    for p in config['inputs']}
        record['terminal_input_sha256'] = observed
        record['inputs_stable'] = observed == config['inputs']
        record['stop_marker_absent'] = attempt(errors, 'terminal stop marker', lambda: not stop.exists(), False)
        limits_ok = True
        for name, limit in [('stdout.json', 4 << 20), ('stderr', 64 << 10)]:
            p = out / name
            size = attempt(errors, 'terminal log size ' + name, lambda p=p: p.stat().st_size)
            record[name + '_bytes'] = size
            limits_ok = limits_ok and size is not None and size <= limit
            record[name + '_sha256'] = attempt(errors, 'terminal log hash ' + name, lambda p=p: sha(p))
        trust_files = {}
        def snapshot_trust():
            for p in (out / 'trust').rglob('*'):
                if p.is_file():
                    trust_files[str(p.relative_to(out))] = attempt(errors, 'trust file hash ' + str(p), lambda p=p: sha(p))
        attempt(errors, 'terminal trust inventory', snapshot_trust)
        record.update(trust_files=trust_files, terminal_log_limits_passed=limits_ok,
                      elapsed_seconds=time.monotonic() - start,
                      completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        record['success'] = bool(verified and record.get('terminal_exit_code') == 0
                                 and record.get('owned_group_absent') is True
                                 and record['inputs_stable'] and record['stop_marker_absent']
                                 and limits_ok and not errors)
        record['errors'] = errors
        # Even a cleanup/hash/inventory failure reaches this independent attempt.
        def save_receipt():
            with (out / 'receipt.json').open('x') as f:
                json.dump(record, f, indent=2)
                f.write('\n')
        attempt(errors, 'terminal receipt emission', save_receipt)
        if errors:
            record['success'] = False
    return record


def main():
    config = json.loads((ROOT / 'preflight.json').read_text())
    review = json.loads((ROOT / 'preflight-review.json').read_text())
    assert review['execution_ready'] is True
    assert review['reviewed_input_sha256'] == config['inputs']
    assert review['preflight_sha256'] == sha(ROOT / 'preflight.json')
    record = execute(config, ROOT / 'verification-v3', STOP,
                     sha(ROOT / 'preflight.json'), sha(ROOT / 'preflight-review.json'))
    print(json.dumps(record))
    return 0 if record['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
