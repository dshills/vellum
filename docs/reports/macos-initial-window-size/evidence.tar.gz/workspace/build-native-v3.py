from pathlib import Path
import datetime,hashlib,json,plistlib,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-window-sizing-native-v3-20261017')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=T).decode().split('\0')[:-1]
 files={n:sha(T/n)for n in sorted(set(names))if(T/n).is_file()};prepared={}
 for module in ['upstream','typesetting']:
  for p in(T/'drivers/cogent/build'/module).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():prepared[p.relative_to(T/'drivers/cogent/build').as_posix()]=sha(p)
 return dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip(),files=files,prepared=prepared)
def main():
 P.mkdir(mode=0o700);O=P/'build';O.mkdir();before=identity();(O/'source.json').write_text(json.dumps(before,indent=2)+'\n')
 path=T/'drivers/cogent/build/upstream/system/driver/desktop/app.go';original=path.read_text();overlay=original.replace('"errors"','"errors"\n "encoding/json"\n "os"',1);marker='opts.FixupForScreen(sc)';assert overlay.count(marker)==1
 overlay=overlay.replace(marker,marker+'\n json.NewEncoder(os.Stderr).Encode(map[string]any{"event":"vellum.window.creation-options", "initial_dp":opts.InitialSizeDP,"raw_size":opts.Size,"screen":*sc,"screen_number":opts.Screen,"std_pixels":opts.StdPixels})',1)
 (O/'desktop-app.original.go').write_text(original);over=O/'desktop-app.overlay.go';over.write_text(overlay);op=O/'overlay.json';op.write_text(json.dumps({'Replace':{str(path):str(over)}},indent=2)+'\n')
 bundle=O/'window-size.app';contents=bundle/'Contents';exe=contents/'MacOS/window-size';exe.parent.mkdir(parents=True)
 with(contents/'Info.plist').open('xb')as f:plistlib.dump(dict(CFBundleIdentifier='com.vellum.windowsizing',CFBundleName='Vellum window sizing',CFBundleExecutable='window-size',CFBundlePackageType='APPL',CFBundleVersion='1',NSHighResolutionCapable=True),f)
 argv=['go','build','-race','-p=1','-trimpath','-overlay',str(op),'-o',str(exe),'./cmd/window-size-smoke'];start=time.monotonic();env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
 with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(T/'drivers/cogent'),env=env,stdout=out,stderr=err,timeout=420,log_limit_bytes=8<<20)
 d=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,source_stable=identity()==before,source_sha256=sha(O/'source.json'),producer_sha256=sha(__file__),native_runtime_executed=False,overlay_source_sha256=sha(over),original_source_sha256=sha(path),binary=dict(path=str(exe),sha256=sha(exe)if exe.exists()else None),plist_sha256=sha(contents/'Info.plist'),logs={n:dict(bytes=(O/n).stat().st_size,sha256=sha(O/n))for n in ['stdout','stderr']});(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert r.returncode==0 and d['source_stable']
if __name__=='__main__':main()
