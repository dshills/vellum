from pathlib import Path
import difflib,hashlib,json,subprocess
T=Path('/private/tmp/vellum-macos-native-results-97aee13');U=T/'drivers/cogent/build/upstream';W=Path(__file__).resolve().parent
files=['core/stage.go','core/mainstage.go','system/window.go','system/driver/desktop/app.go']
original={f:(U/f).read_text()for f in files}
(W/'before').mkdir(exist_ok=True)
for f,s in original.items():
 p=W/'before'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
p=U/'core/stage.go';s=p.read_text();at='\t// Resizable specifies whether a window on desktop platforms can'
s=s.replace(at,'''\t// InitialSizeDP is an optional initial client-size request in density-independent
	// units (160 per logical inch). It overrides content/screen-fraction sizing for
	// new desktop windows, but saved geometry and OS constraints take precedence.
	// It is applied before native show and is never a persistent layout minimum.
	InitialSizeDP math32.Vector2

'''+at);s=s.replace('// SetBackButton sets', '''// SetInitialSizeDP sets the initial client-size request for a new desktop window.
func (st *Stage) SetInitialSizeDP(width, height float32) *Stage {
	st.InitialSizeDP = math32.Vec2(width, height)
	return st
}

// SetBackButton sets''');p.write_text(s)
p=U/'core/mainstage.go';s=p.read_text();s=s.replace('if !TheApp.Platform().IsMobile() &&\n\t\t(st.NewWindow || !st.FullWindow || current == nil) {','''explicitInitial := st.NewWindow && TheApp.Platform() != system.Offscreen &&
		(&system.NewWindowOptions{InitialSizeDP: st.InitialSizeDP}).HasInitialSizeDP()
	if !explicitInitial && !TheApp.Platform().IsMobile() &&
		(st.NewWindow || !st.FullWindow || current == nil) {''',1)
a=s.index('func (st *Stage) newRenderWindow()');b=s.index('\n\twin := newRenderWindow(name, title, opts)',a)
s=s[:a]+'''// initialWindowOptions is the creation-options seam shared by real native
// creation and regression tests. A restored window keeps its saved pixel size.
func (st *Stage) initialWindowOptions(screen *system.Screen, saved *windowGeometry, savedScreen *system.Screen) *system.NewWindowOptions {
	opts := &system.NewWindowOptions{
		Title: st.Title, Icon: appIconImages(), Size: st.Scene.SceneGeom.Size,
		Pos: st.Pos, Screen: st.Screen, InitialSizeDP: st.InitialSizeDP,
	}
	if screen != nil {
		opts.Screen = screen.ScreenNumber
	}
	opts.Flags.SetFlag(!st.Resizable, system.FixedSize)
	opts.Flags.SetFlag(st.Maximized, system.Maximized)
	opts.Flags.SetFlag(st.Fullscreen, system.Fullscreen)
	if saved != nil && savedScreen != nil {
		opts.Screen = savedScreen.ScreenNumber
		opts.Size, opts.Pos = saved.Size, saved.Pos
		opts.InitialSizeDP = math32.Vector2{}
		if AllRenderWindows.FindName(st.Title) != nil {
			opts.Pos = opts.Pos.Add(image.Pt(20, 20))
		}
		opts.Flags.SetFlag(saved.Max, system.Maximized)
	}
	return opts
}

func (st *Stage) newRenderWindow() *renderWindow {
	name, title := st.Name, st.Title
	screen := st.targetScreen()
	screenName := ""
	if screen != nil {
		screenName = screen.Name
	}
	wgp, savedScreen := theWindowGeometrySaver.get(title, screenName)
	opts := st.initialWindowOptions(screen, wgp, savedScreen)
	if wgp != nil {
		theWindowGeometrySaver.settingStart()
	}'''+s[b:];p.write_text(s)
p=U/'system/window.go';s=p.read_text().replace('"image"','"image"\n "math"',1);s=s.replace('\t// Size specifies the dimensions','''	// InitialSizeDP requests a desktop client size in density-independent units.
	// A finite positive pair overrides Size/StdPixels at creation. Resolution uses
	// the same screen snapshot as native creation; it never sets a resize minimum.
	InitialSizeDP math32.Vector2
	// Size specifies the dimensions''',1)
a=s.index('\tscsz := sc.Geometry.Size() // window coords size',s.index('func (o *NewWindowOptions) Fixup()'));s=s[:a]+'''\to.FixupForScreen(sc)
}

// HasInitialSizeDP reports whether both initial request dimensions are usable.
func (o *NewWindowOptions) HasInitialSizeDP() bool {
	return o.InitialSizeDP.X > 0 && o.InitialSizeDP.Y > 0 &&
		!math.IsInf(float64(o.InitialSizeDP.X), 0) && !math.IsInf(float64(o.InitialSizeDP.Y), 0)
}

// initialSizePixels rounds DP to raw pixels and bounds before integer conversion.
// At least one window-manager unit is required by native window creation.
func (o *NewWindowOptions) initialSizePixels(sc *Screen) (image.Point, bool) {
	if !o.HasInitialSizeDP() || sc == nil || sc.PixelSize.X <= 0 || sc.PixelSize.Y <= 0 ||
		!(sc.LogicalDPI > 0) || !(sc.DevicePixelRatio > 0) ||
		math.IsInf(float64(sc.LogicalDPI), 0) || math.IsInf(float64(sc.DevicePixelRatio), 0) {
		return image.Point{}, false
	}
	dimension := func(dp float32, available int) int {
		limit := float64(min(available, math.MaxInt32))
		minimum := min(limit, max(1, math.Ceil(float64(sc.DevicePixelRatio))))
		pixels := math.Round(float64(dp) * float64(sc.LogicalDPI) / 160)
		return int(min(limit, max(minimum, pixels)))
	}
	return image.Pt(dimension(o.InitialSizeDP.X, sc.PixelSize.X), dimension(o.InitialSizeDP.Y, sc.PixelSize.Y)), true
}

// FixupForScreen resolves creation options using an already chosen screen snapshot.
// Desktop creation passes this same snapshot to GLFW, avoiding a second screen
// lookup with potentially different DPI, scale or geometry.
func (o *NewWindowOptions) FixupForScreen(sc *Screen) {
	if sc == nil { return }
	if size, ok := o.initialSizePixels(sc); ok {
		o.Size, o.StdPixels = size, false
	}
'''+s[a:];p.write_text(s)
p=U/'system/driver/desktop/app.go';s=p.read_text().replace('opts.Fixup()','opts.FixupForScreen(sc)',1);p.write_text(s)
p=T/'drivers/cogent/driver.go';s=p.read_text().replace('\n\t"cogentcore.org/core/styles/units"','');s=s.replace('w.body.Styler(func(s *styles.Style) { s.Min.Set(units.Dp(spec.Width), units.Dp(spec.Height)); s.Grow.Set(1, 1) })','configureInitialWindow(w.body, spec)');s=s.replace('w.body.NewWindow().SetUseMinSize(true).Run()','initialWindowStage(w.body, w.window).Run()');s+='''
// Initial dimensions belong to creation options, not persistent content minima.
func configureInitialWindow(body *core.Body, _ app.Window) {
	body.Styler(func(s *styles.Style) { s.Grow.Set(1, 1) })
}
func initialWindowStage(body *core.Body, spec app.Window) *core.Stage {
	return body.NewWindow().SetUseMinSize(false).SetInitialSizeDP(spec.Width, spec.Height)
}
''';p.write_text(s)
p=T/'app/app.go';s=p.read_text().replace('\tID, Title     string\n\tWidth, Height float32','''	ID, Title string
	// Width and Height are finite positive initial client-size requests. The
	// native desktop driver interprets them in density-independent units (Dp),
	// converts with the creation screen's logical DPI, and applies OS limits.
	// Saved geometry takes precedence. These fields never set a resize minimum.
	// Manual replay uses its explicit physical-pixel viewport instead.
	Width, Height float32''');p.write_text(s)
subprocess.run(['gofmt','-w',*[str(U/f)for f in files],str(T/'drivers/cogent/driver.go'),str(T/'app/app.go')],check=True)
