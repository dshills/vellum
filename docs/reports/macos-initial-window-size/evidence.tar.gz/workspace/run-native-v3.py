"""Two fixed serial native cases, observed by a bounded read-only exact-PID AX client."""
from pathlib import Path
import contextlib,datetime,hashlib,importlib.util,json,math,os,selectors,sys,time,subprocess
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-window-sizing-native-v3-20261017');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
build=module('sizing_build',W/'build-native-v3.py');sys.path.insert(0,str(W.parent/'macos-grid-native-stacks'));owned=module('owned_sizing',W.parent/'macos-grid-native-stacks/run.py');sha=build.sha
helper=Path('/private/tmp/vellum-external-ax-diagnostic-20261017/window-helper-build/window-readonly')
def read(p):return json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def main():
 case=sys.argv[1];need(case in ['small','large'],'fixed case');dims={'small':[320,240],'large':[640,400]}[case]
 review=read(W/'native-readiness-v3.json');need(review['execution_ready']and not review['unresolved_findings'],'review admission');pins=review['inputs'];stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(P/'stop-live').exists()
 b=read(P/'build/receipt.json');source=read(P/'build/source.json');need(b['exit_code']==0 and b['source_stable']and build.identity()==source,'frozen source/build');need(sha(b['binary']['path'])==b['binary']['sha256'],'binary binding')
 with owned.LiveLease()as lease:
  need(lease.held()and stable()and not stopping(),'lease/pins/stop admission')
  if case=='large':
   prior=read(P/'runs/small/receipt.json');need(prior['result']=='PASS_NATIVE_INITIAL_AND_SHRINK_READONLY_AX','previous case');[owned.absent(x['pid'])for x in prior['retirement'].values()]
  O=P/'runs'/case;O.mkdir(parents=True,mode=0o700);(O/'runtime').mkdir(mode=0o700);children={};streams={};terminal={};errors=[];start=time.monotonic();pending=b'';initial=None
  d=dict(case=case,requested_dp=dims,result='STARTED',error=None,cleanup_errors=errors,producer_sha256=sha(__file__),review_sha256=sha(W/'native-readiness-v3.json'),native_runtime_executed=False,physical_input_generated=False,settings_changed=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
  try:
   with contextlib.ExitStack()as stack,selectors.DefaultSelector()as selector:
    def launch(name,argv):
     need(stable()and lease.held()and not stopping(),'child admission');child=subprocess.Popen(argv,cwd=O/'runtime',env={**owned.child_environment(True),'GOMAXPROCS':'2'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);children[name]=child;d[name]=dict(pid=child.pid,argv=argv,started_seconds=time.monotonic()-start)
     if name=='native':d['native_runtime_executed']=True
     for suffix,pipe in [('stdout',child.stdout),('stderr',child.stderr)]:
      key=name+'.'+suffix;streams[key]=dict(file=stack.enter_context((O/key).open('xb')),count=0,digest=hashlib.sha256(),eof=False);selector.register(pipe,selectors.EVENT_READ,key)
     (O/('owned-'+name+'.json')).write_text(json.dumps(d[name],indent=2)+'\n');return child
    native=launch('native',[b['binary']['path'],'-width='+str(dims[0]),'-height='+str(dims[1])]);print(json.dumps(dict(event='native.started',case=case,pid=native.pid)),flush=True)
    while selector.get_map()or any(c.poll()is None for c in children.values()):
     now=time.monotonic();need(not stopping(),'human-return stop');need(now-start<30,'native watchdog')
     for name,c in children.items():
      if c.poll()is not None:
       terminal.setdefault(name,now);need(not any(x.data.startswith(name+'.')for x in selector.get_map().values())or now-terminal[name]<5,'surviving writer')
      elif name=='client':need(now-start-d['client']['started_seconds']<8,'AX helper watchdog')
     for key,_ in selector.select(.1):
      data=os.read(key.fd,64<<10);s=streams[key.data]
      if not data:s['eof']=True;selector.unregister(key.fileobj);continue
      accepted=min(len(data),(2<<20)-s['count']);need(s['file'].write(data[:accepted])==accepted,'short write');s['file'].flush();s['count']+=accepted;s['digest'].update(data[:accepted]);need(accepted==len(data),'log byte bound')
      if key.data=='native.stdout'and initial is None:
       pending+=data;need(len(pending)<256<<10,'parser bound')
       while b'\n'in pending:
        line,pending=pending.split(b'\n',1)
        if line.startswith(b'{'):
         event=json.loads(line)
         if event.get('event')=='vellum.window.initial':initial=event;need(event['pid']==native.pid and event['requested_dp']==dims and event['geometry_saver_disabled']is True,'initial fixture binding')
     if initial is not None and 'client'not in children:
      need(native.poll()is None,'native ended before AX query');launch('client',[str(helper),str(native.pid),b['binary']['path'],'Vellum initial window size check'])
     if initial is None:need(now-start<12,'native readiness watchdog')
    for name,c in children.items():d[name].update(exit_code=c.wait(timeout=5),terminal_seconds=terminal.get(name,time.monotonic())-start)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   d['retirement']={name:owned.retire(c,name,errors)for name,c in reversed(list(children.items()))}
   try:
    d['source_stable']=build.identity()==source;d['pins_stable']=stable();d['logs']={name:dict(bytes=(O/name).stat().st_size,sha256=sha(O/name),eof=s['eof'])for name,s in streams.items()};d['logs_complete']=bool(streams)and all(s['eof']and d['logs'][name]['bytes']==s['count']and d['logs'][name]['sha256']==s['digest'].hexdigest()for name,s in streams.items())
    need(d['error']is None and not errors and d['source_stable']and d['pins_stable']and d['logs_complete']and lease.held()and not stopping(),'runtime controls')
    need(all(d[n]['exit_code']==0 for n in ['native','client']),'child exit')
    def events(path):
     return [json.loads(l)for l in path.read_bytes().splitlines()if l.startswith(b'{')]
    nv=events(O/'native.stdout');creation=[e for e in events(O/'native.stderr')if e.get('event')=='vellum.window.creation-options'];need(len(creation)==1,'one creation');need([e['event']for e in nv]==['vellum.window.initial','vellum.window.resized','vellum.window.complete'],'fixture sequence');first,resized,complete=nv;opt=creation[0];sc=opt['screen'];dpr=sc['DevicePixelRatio'];raw=opt['raw_size'];wm={k:int(raw[k]/dpr)for k in ['X','Y']}
    need(dpr in [1,2],'live fixture comparison supports integral macOS DPR 1/2; fractional scale has pure regression coverage')
    expected={k:int(math.floor(dims[i]*sc['LogicalDPI']/160+.5)/dpr)*int(dpr) for i,k in enumerate(['X','Y'])}
    need(raw==expected,'independent DP conversion for fixture dimensions')
    need(opt['initial_dp']=={'X':dims[0],'Y':dims[1]}and opt['std_pixels']is False and opt['screen_number']==sc['ScreenNumber'],'actual creation request')
    need(first['window_size']==wm and first['pixel_size']==raw and first['render_geometry']['Size']==raw,'native/client/render creation sizes');need(first['screen']['LogicalDPI']==sc['LogicalDPI']and first['screen']['DevicePixelRatio']==dpr,'observed scale')
    need(all(resized['window_size'][k]==max(1,wm[k]//2)and resized['pixel_size'][k]<raw[k]for k in ['X','Y']),'later shrink')
    ax=read(O/'client.stdout');need(ax['result']=='pass'and ax['pid']==native.pid and ax['trusted']is True and ax['actions_performed']is False and ax['settings_changed']is False and ax['complete_bounded_walk']is True,'AX exact owned read');need(os.path.samefile(ax['executable'],b['binary']['path']),'AX executable identity');roots=[n for n in ax['nodes']if n.get('AXRole')=='AXWindow'];need(len(roots)==1 and roots[0]['screen_frame'][2]>0 and roots[0]['screen_frame'][3]>0,'separate external outer frame');need(b'DATA RACE'not in(O/'native.stderr').read_bytes(),'race report')
    d.update(result='PASS_NATIVE_INITIAL_AND_SHRINK_READONLY_AX',creation=opt,initial=first,resized=resized,ax_outer_frame=roots[0]['screen_frame'],outer_frame_units='macOS AX screen coordinates; not physical pixels',ax_result=ax['result'])
   except BaseException as e:
    if d['error']is None:d['error']=dict(type=type(e).__name__,message=str(e))
    d['result']='FAILED_PRESERVED_RUNTIME'
   d.update(seconds=time.monotonic()-start,lease_held_through_cleanup=lease.held(),stop_marker_at_exit=stopping(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
  need(d['result']=='PASS_NATIVE_INITIAL_AND_SHRINK_READONLY_AX','native sizing case failed')
if __name__=='__main__':main()
