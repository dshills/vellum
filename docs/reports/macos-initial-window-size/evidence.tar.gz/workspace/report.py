"""Package bounded sizing evidence after source checkpoint; no process/UI action."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-window-sizing-native-v3-20261017');OLD=Path('/private/tmp/vellum-window-sizing-native-20261017');CHECKS=Path('/private/tmp/vellum-window-sizing-checks');D=T/'docs/reports/macos-initial-window-size'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
commit=read(W/'commit-receipt.json');assert commit['result']=='REVIEWED_SOURCE_COMMITTED_AND_INTEGRATED'
review=read(W/'final-review.json');assert review['commit_ready']and not review['unresolved_findings']
D.mkdir();members={};excluded={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file()or'__pycache__'in p.parts:continue
  name=label+p.relative_to(root).as_posix()
  if p.name=='window-size'and p.parent.name=='MacOS':excluded[name]=dict(sha256=sha(p),bytes=p.stat().st_size,reason='compiled executable excluded; exact binary/source/build/runtime hashes retained');continue
  members[name]=p
add('workspace/',W);add('native/',P);add('pre-queue-guard-native/',Path('/private/tmp/vellum-window-sizing-native-v2-20261017'));add('unused-pre-guard-build/',OLD);add('checks/',CHECKS)
# Preserve the read-only client and the shared ownership helpers used by this run.
for name,path in {
 'ax-client/window-readonly.swift':W.parent/'macos-external-ax-diagnostic/window-readonly.swift',
 'ax-client/build-receipt.json':Path('/private/tmp/vellum-external-ax-diagnostic-20261017/window-helper-build/receipt.json'),
 'shared/owned-native-runner.py':W.parent/'macos-grid-native-stacks/run.py',
 'shared/owned-native-build.py':W.parent/'macos-grid-native-stacks/build.py',
 'shared/live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),
 'shared/child_process.py':T/'scripts/child_process.py',
 'shared/sdk_environment.py':T/'scripts/sdk_environment.py',
 'shared/commit-guard.py':W.parent/'macos-grid-native-stacks/commit-pending.py',
 'shared/prism-retirement.py':Path('/private/tmp/vellum-native-attestation-probe-20261016/run-verifier.py')}.items():
 assert path.is_file()and not path.is_symlink();members[name]=path
for name,path in {
 'external-ax-helper':Path('/private/tmp/vellum-external-ax-diagnostic-20261017/window-helper-build/window-readonly'),
 'prism-cli':Path('/Users/dshills/Development/Go/bin/prism')}.items():
 excluded[name]=dict(sha256=sha(path),bytes=path.stat().st_size,reason='external executable excluded; source/build or review identity retained')
# Bound artifacts and keep archive generation independent of filesystem metadata.
assert len(members)<200
expanded=sum(p.stat().st_size for p in members.values());assert expanded<32<<20
manifest={'files':{name:dict(bytes=p.stat().st_size,sha256=sha(p))for name,p in members.items()},'excluded_executables':excluded,'count':len(members),'expanded_bytes':expanded}
(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in members.items():
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();assert len(entries)==len(members)
 for entry in entries:
  assert entry.isfile()and hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==manifest['files'][entry.name]['sha256']
results={n:read(P/'runs'/n/'receipt.json')for n in ['small','large']}
result=dict(status='REVIEWED_INITIAL_NATIVE_WINDOW_SIZE_CHECKPOINT',source_commit=commit['commit'],base_commit=commit['parent'],source_binding_sha256=sha(W/'final-binding.json'),source_payload_files=12,source_payload_bytes=read(W/'final-binding.json')['staged_diff_bytes'],source_payload_sha256=read(W/'final-binding.json')['staged_diff_sha256'],provider_binding_sha256=sha(W/'binding.json'),provider_payload_bytes=32466,post_provider_change='diagnostic fixture only: wait native queue publication before reads; final source/native revalidation internal',owned_patch='0074-initial-client-size.patch',owned_patch_sha256=sha(T/'drivers/cogent/native/patches/initialsize/0074-initial-client-size.patch'),tests={n:{k:read(CHECKS/n/'receipt.json')[k]for k in ['exit_code','seconds','source_stable']}for n in ['prepare','focused','prepare-v2','focused-v2','prepare-v3','focused-v3','prepare-unit','driver','vet','root','prepare-v4','focused-v4']},native={n:dict(result=r['result'],receipt_sha256=sha(P/'runs'/n/'receipt.json'),requested_dp=r['requested_dp'],screen=r['creation']['screen'],creation_raw_pixels=r['creation']['raw_size'],initial=r['initial'],resized=r['resized'],ax_outer_frame=r['ax_outer_frame'],native_exit_code=r['native']['exit_code'],client_exit_code=r['client']['exit_code'],seconds=r['seconds'])for n,r in results.items()},binary=read(P/'build/receipt.json')['binary'],diagnostic_overlay=dict(path='system/driver/desktop/app.go',effect='logs chosen screen and resolved scalar creation options before native creation',sha256=read(P/'build/receipt.json')['overlay_source_sha256'],source_metadata='b3c1c2 dirty candidate, explicit logging overlay; source bytes match committed implementation, binary not relabeled as clean committed build'),review=dict(source_sha256=sha(W/'source-review-v3.json'),native_readiness_sha256=sha(W/'native-readiness-v3.json'),result_sha256=sha(W/'result-review-v3.json'),final_sha256=sha(W/'final-review.json'),prism_receipt_sha256=sha(W/'prism/receipt.json'),prism_raw_sha256=sha(W/'prism/prism.json'),provider='anthropic',model='claude-sonnet-5-5',invocations=1),evidence=dict(file='evidence.tar.gz',sha256=sha(D/'evidence.tar.gz'),compressed_bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded,manifest_sha256=sha(D/'evidence.manifest.json')),physical_input_verified=False,performance_qualified=False,full_macos_qualified=False)
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(D/'README.md').write_text(f'''# Initial native window sizing — macOS

Source checkpoint `{commit['commit']}` makes explicit `app.Window.Width`/`Height`
Dp initial client-size requests. They bypass the adapter's former permanent
`Body.Min` and upstream screen-fraction sizing. Saved geometry and OS limits keep
precedence. Conversion, constraints and native creation share a chosen screen
snapshot before Show. See [the contract](../../../specs/windows-services.md).

## Verified

| Request (Dp) | Initial client/render pixels | Later client pixels | Separate AX outer frame |
|---|---|---|---|
| 320 × 240 | 324 × 243 | 162 × 121 | 324 × 275 |
| 640 × 400 | 648 × 405 | 324 × 202 | 648 × 437 |

Both native processes selected screen 0, LG HDR DQHD, 5120 × 1440 raw pixels,
DPR 1 and logical DPI 162. The observed request conversion is `Dp × 162 / 160`.
Each actual creation-options record equals the initial native client and render
size. AX outer frames include decorations and use macOS screen coordinates;
they are recorded separately and never inferred to be physical pixels. Both
race-instrumented native cases and exact-PID/executable/title read-only AX
clients exited 0; all four owned process groups were reaped and absent. Source,
prepared bytes, reviewed pins and log EOF/hash checks stayed stable. No physical
input, AX actions, input-source/VoiceOver/clipboard or OS-setting changes occurred.

The live build contains the exact candidate source plus an explicitly recorded
logging-only desktop overlay for the chosen screen/options before GLFW. Its Go
metadata is the dirty candidate based on b3c1c2, not a clean binary rebuilt at the
new commit. The original source, overlay, binaries' hashes, commands, raw runtime
records and review pins are retained. Compiled executables are excluded from the
archive with their hashes and sizes. The first build remains identified as unused. An earlier two-case campaign
passed; its raw results remain preserved separately. After the provider review,
an adjacent fixture-startup gap was fixed by waiting for native queue publication.
The final fixture was rebuilt and reran the same two validations in a new reviewed
campaign. No runtime receipt or validation was overwritten.

## Automated checks and review

Final focused offscreen race tests exercise the actual creation-options seam,
DPI/DPR/zoom, distinct small requests, rounding, tiny fractional scaling, extreme
finite sizes through final native integer conversion, saved precedence, legacy
unset/fullscreen behavior, independent sizing contexts, and actual adapter body
stylers. Fresh owned preparation verifies stage 0074 input/output/patch hashes.
Full adapter offscreen race (106.23 s), portable module race (26.65 s), module vet
and preparation tests passed before the final generator tag and diagnostic-only
fixture guards. Final focused race (35.23 s) and native build bind the final bytes.

The first focused attempt failed on a missing math32 import and an uninitialized
system-test app fixture; those logs remain preserved. Internal review then found
a fractional-DPR zero-size and float32 integer-overflow boundary. Final native
bounds and regression coverage resolve those findings. Fixture startup/cleanup
and evidence-producer terminal observations were also corrected before execution.
Internal source/readiness/result and final checkpoint reviews accompany one
Prism review using Anthropic Claude Sonnet 5.5 (12 files, 32,466-byte diff, one
chunk/call). Its two medium findings assumed non-idempotent Close and
unsynchronized native dispatch. Independent inspection refuted those stated
mechanisms: Close is mutex-protected/idempotent, synchronous queue acknowledgment
orders captured output, and SetWinSize marshals GLFW to main. The separate real
pre-publication fixture hazard was fixed and revalidated after that provider call.
Production adapter/patch/spec bytes were unchanged by this last fixture guard. See [result.json](result.json),
[evidence manifest](evidence.manifest.json) and [raw evidence](evidence.tar.gz).

## Limits and next gate

These are two small, minimal-content windows on the current display, followed by
programmatic resizing. Live comparisons admit integral macOS DPR 1/2; this run
observed DPR 1. Fractional scale and synthetic secondary-screen checks are pure
regressions. Physical drag/resize, cross-display movement/hotplug, content stress,
live saved-geometry restoration, screen readers and broad native interoperability
remain open. Manual replay retains its physical viewport and Workbench retains
its OS-client-unit later-resize path; neither was redefined by this change.

All prior 4 ms p95 / 6 ms p99 failures remain failures at their recorded viewport.
A corrected initial viewport changes the workload and does not demonstrate an
algorithmic speedup or retroactively qualify old binaries. The next performance
comparison must record actual initial/client/render dimensions and display scale.
Full macOS completion and public release remain open.
''')
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Initial native window sizing](macos-initial-window-size/README.md): Dp creation contract, two measured native client sizes/shrinks, separate outer AX frames, bounded conversion regressions and review evidence.\n')
p=T/'docs/implementation.md';p.write_text(p.read_text()+'''\n## Initial native window sizing checkpoint\n\nExplicit native Window dimensions now request initial Dp client size before Show,\nwithout becoming body minima or invoking screen-fraction sizing. Saved geometry\nand OS limits retain precedence. Two measured native size/shrink checks and\nread-only external outer-frame observations pass on the current display;\nfractional-scale/boundary/restore tests are automated. See the\n[report](reports/macos-initial-window-size/README.md). Existing performance and\nphysical/cross-display/complete macOS gates remain open.\n''')
p=T/'specs/macos-completion.md';p.write_text(p.read_text()+'''\n## Initial native window sizing checkpoint\n\n[Current source and native evidence](../docs/reports/macos-initial-window-size/README.md)\nqualifies two small Dp initial client requests and later programmatic shrinking\non the current display, with separate read-only AX outer frames. Owned stage0074\nremoves persistent initial body minima and screen-fraction override, converts at\ncreation with one chosen screen snapshot, preserves saved geometry precedence,\nand bounds final native dimensions. Automated tests cover scale/zoom, synthetic\nsecondary screen, tiny fractional and extreme sizes plus restore options.\n\nThis does not close physical resize/drag/cross-display, live saved restoration,\nloaded/native performance or full Mac qualification. Historical 4/6ms failures\nretain their original workload and failure status. New performance comparisons\nmust report actual initial/client/render geometry and screen scale.\n''')
print(json.dumps(dict(report=str(D),members=len(members),archive_sha256=sha(D/'evidence.tar.gz'),compressed_bytes=(D/'evidence.tar.gz').stat().st_size)))
