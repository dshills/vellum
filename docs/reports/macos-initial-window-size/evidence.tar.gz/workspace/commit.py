"""Commit exact reviewed sizing source, fast-forward canonical and reprepare its owned modules."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-window-sizing-native-v3-20261017')
spec=importlib.util.spec_from_file_location('sizing_commit_guard',W.parent/'macos-grid-native-stacks/commit-pending.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W
original_env=m.child_environment
m.child_environment=lambda runtime=False:{**original_env(runtime),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
sha=m.sha;read=lambda p:json.loads(Path(p).read_bytes());need=lambda x:None if x else (_ for _ in()).throw(ValueError('commit admission failed'))
def prepared(root):
 return {p.relative_to(root/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in(root/'drivers/cogent/build'/module).rglob('*')if p.is_file()}
def main():
 output=W/'commit-receipt.json';need(not output.exists());d=dict(result='INCOMPLETE',producer_sha256=sha(__file__),mutations=[],error=None)
 try:
  b=read(W/'final-binding.json');r=read(W/'final-review.json');need(r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()))
  d['before']=dict(candidate=m.observation(T),canonical=m.observation(C));admit=dict(candidate=m.git_admission(T),canonical=m.git_admission(C));d['git_admission']=admit
  need(d['before']['candidate']['head']==d['before']['canonical']['head']==b['base_commit']);need(d['before']['candidate']['branch']=='codex/macos-native-results'and d['before']['canonical']['branch']=='codex/foundation-completion');need(m.clean(C)and not m.git(T,'diff','--name-only')and not m.git(T,'ls-files','--others','--exclude-standard'))
  need(set(m.git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources']));need(all(sha(T/p)==h and hashlib.sha256(m.git(T,'show',':'+p)).hexdigest()==h for p,h in b['sources'].items()));need(hashlib.sha256(m.git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256'])
  source=read(P/'build/source.json');need(all(sha(T/p)==h for p,h in source['files'].items())and prepared(T)==source['prepared']);need((P/'stop-live').exists())
  message=W/'source-commit-message.txt';message.write_text('fix(macos): honor initial client window size at native creation\n\nTreat Window Width/Height as Dp initial client requests, removing persistent body minima and screen-fraction override. Resolve request with the native creation screen snapshot before Show; retain saved geometry and OS precedence. Bound rounding/conversion through final native dimensions.\n\nAdd owned patch 0074, creation-options and adapter regressions, explicit size specification, and a bounded native smoke command. Verified offscreen race/vet/preparation and two native race-instrumented size/shrink cases with separate read-only AX outer frames. Reviewed internally and once with Prism Anthropic Claude Sonnet 5.5; physical/cross-display/performance qualification remains open.\n')
  need(m.git_admission(T)==admit['candidate']and m.git_admission(C)==admit['canonical']);m.mutation(T,'source-commit',['git','commit','--file',str(message)],d)
  commit=m.git(T,'rev-parse','HEAD').decode().strip();need(m.clean(T)and m.git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit']);need(set(m.git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources']))
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==admit['canonical']);m.mutation(C,'source-fast-forward',['git','merge','--ff-only',commit],d)
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==commit)
  # The owned preparation entry point lives in the driver module.
  m.mutation(C/'drivers/cogent','prepare-canonical',['python3','prepare.py'],d)
  files=m.git(T,'ls-files','-z').decode().split('\0')[:-1];need(len(files)==4635 and all(sha(T/p)==sha(C/p)for p in files));need(prepared(C)==prepared(T)==source['prepared']);need(m.clean(T)and m.clean(C))
  d.update(result='REVIEWED_SOURCE_COMMITTED_AND_INTEGRATED',commit=commit,parent=b['base_commit'],source_files=len(files),prepared_files=len(source['prepared']),both_clean=True,canonical_promoted=True,prepared_modules_rebuilt=True,binding_sha256=sha(W/'final-binding.json'),review_sha256=sha(W/'final-review.json'),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  failed=False
  for label,root in [('candidate',T),('canonical',C)]:
   try:d[label+'_terminal']=m.observation(root)
   except BaseException as e:failed=True;d[label+'_observation_error']=dict(type=type(e).__name__,message=str(e))
  if failed:d.update(result='FAILED_TERMINAL_OBSERVATION',both_clean=False)
  output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
  if failed and d['error']is None:raise RuntimeError('terminal observation failed')
if __name__=='__main__':main()
