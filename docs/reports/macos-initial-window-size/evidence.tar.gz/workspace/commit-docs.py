from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('sizing_source_finish',W/'commit.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);m=base.m;T=base.T;C=base.C;sha=m.sha;read=base.read;need=base.need
output=W/'documentation-commit-receipt.json';need(not output.exists());d=dict(result='INCOMPLETE',producer_sha256=sha(__file__),mutations=[],error=None)
try:
 b=read(W/'documentation-binding.json');r=read(W/'documentation-review.json');need(r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()));d['before']=dict(candidate=m.observation(T),canonical=m.observation(C));d['git_admission']=dict(candidate=m.git_admission(T),canonical=m.git_admission(C))
 need(d['before']['candidate']['head']==d['before']['canonical']['head']==b['base_commit']and m.clean(C));need(not m.git(T,'diff','--name-only')and not m.git(T,'ls-files','--others','--exclude-standard'));need(set(m.git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources']));need(all(sha(T/p)==h and hashlib.sha256(m.git(T,'show',':'+p)).hexdigest()==h for p,h in b['sources'].items()));need(hashlib.sha256(m.git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256']);need(base.prepared(T)==base.prepared(C))
 message=W/'documentation-commit-message.txt';message.write_text('docs(macos): record reviewed initial window sizing evidence\n\nPreserve source/spec/review bindings, initial and final bounded native size/shrink campaigns, separate external AX outer frames, original failed offscreen attempts and provider finding dispositions. Keep physical/cross-display/performance/full Mac gates open.\n')
 need(m.git_admission(T)==d['git_admission']['candidate']);m.mutation(T,'docs-commit',['git','commit','--file',str(message)],d);commit=m.git(T,'rev-parse','HEAD').decode().strip();need(m.clean(T)and m.git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit']);need(set(m.git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources']))
 need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==d['git_admission']['canonical']);m.mutation(C,'docs-fast-forward',['git','merge','--ff-only',commit],d)
 files=m.git(T,'ls-files','-z').decode().split('\0')[:-1];need(len(files)==4639 and all(sha(T/p)==sha(C/p)for p in files)and base.prepared(T)==base.prepared(C));need(m.clean(T)and m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==commit)
 d.update(result='REVIEWED_SIZING_SOURCE_AND_EVIDENCE_INTEGRATED',commit=commit,source_commit=b['base_commit'],source_files=len(files),prepared_files=len(base.prepared(T)),both_clean=True,canonical_promoted=True,review_sha256=sha(W/'documentation-review.json'),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
finally:
 failed=False
 for label,root in [('candidate',T),('canonical',C)]:
  try:d[label+'_terminal']=m.observation(root)
  except BaseException as e:failed=True;d[label+'_observation_error']=dict(type=type(e).__name__,message=str(e))
 if failed:d.update(result='FAILED_TERMINAL_OBSERVATION',both_clean=False)
 output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 if failed and d['error']is None:raise RuntimeError('terminal observation failed')
