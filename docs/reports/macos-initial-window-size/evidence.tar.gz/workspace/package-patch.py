from pathlib import Path
import difflib,hashlib,json,subprocess
T=Path('/private/tmp/vellum-macos-native-results-97aee13');U=T/'drivers/cogent/build/upstream';W=Path(__file__).resolve().parent
files=['core/stage.go','core/mainstage.go','system/window.go','system/driver/desktop/app.go','core/window_initial_vellum_test.go','system/window_initial_vellum_test.go']
subprocess.run(['gofmt','-w',*[str(U/f)for f in files],str(T/'drivers/cogent/driver.go'),str(T/'drivers/cogent/window_initial_test.go')],check=True)
P=T/'drivers/cogent/native/patches/initialsize';P.mkdir(exist_ok=True)
sha=lambda s:hashlib.sha256(s).hexdigest()
inputs={};outputs={};patch=''
for f in files:
 old=W/'before'/f;new=U/f
 a=old.read_text()if old.exists()else'';b=new.read_text()
 inputs[f]=sha(old.read_bytes())if old.exists()else None
 outputs[f]=sha(new.read_bytes())
 patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+f if old.exists()else'/dev/null',tofile='b/'+f))
(P/'0074-initial-client-size.patch').write_text(patch)
for name,d in [('original-hashes.json',inputs),('output-hashes.json',outputs)]: (P/name).write_text(json.dumps(d,indent=2)+'\n')
m=T/'drivers/cogent/native/dependencies.json';d=json.loads(m.read_text());stages=d['dependencies'][0]['stages'];stage={'origin':'drivers/cogent/native/patches/initialsize','inputs':'native/patches/initialsize/original-hashes.json','outputs':'native/patches/initialsize/output-hashes.json','patches':[{'file':'native/patches/initialsize/0074-initial-client-size.patch','sha256':sha((P/'0074-initial-client-size.patch').read_bytes())}]}
if stages[-1]['origin']==stage['origin']:stages[-1]=stage
else:assert stages[-1]['patches'][-1]['file'].endswith('0073-native-input-fixture-headroom.patch');stages.append(stage)
m.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'files':files,'patch_bytes':len(patch.encode()),'sha256':stage['patches'][0]['sha256']}))
