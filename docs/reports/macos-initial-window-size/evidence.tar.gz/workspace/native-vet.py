from pathlib import Path
import importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('sizing_final_build',W/'build-native-v3.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
O=W/'native-vet';O.mkdir();source=b.identity();(O/'source.json').write_text(json.dumps(source,indent=2)+'\n');start=time.monotonic();argv=['go','vet','-p=1','./cmd/window-size-smoke'];env={**b.child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=b.run_child(argv,cwd=str(b.T/'drivers/cogent'),env=env,stdout=out,stderr=err,timeout=120,log_limit_bytes=2<<20)
d=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,source_stable=b.identity()==source,source_sha256=b.sha(O/'source.json'),producer_sha256=b.sha(__file__),native_runtime_executed=False,logs={n:dict(bytes=(O/n).stat().st_size,sha256=b.sha(O/n))for n in ['stdout','stderr']});(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert r.returncode==0 and d['source_stable']
