from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-window-sizing-checks')
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=T).decode().split('\0')[:-1]
 return {n:sha(T/n)for n in sorted(set(names))if(T/n).is_file()}
name=sys.argv[1];commands={'prepare':(['python3','prepare.py'],T/'drivers/cogent'),'focused':(['go','test','-race','-p=1','-count=1','-tags=offscreen','-run','TestInitialWindow|TestStageInitial|TestWindowOptions|TestNewWindowSizing|TestSameWindowStage','cogentcore.org/core/system','cogentcore.org/core/core','.'],T/'drivers/cogent'),'driver':(['go','test','-race','-p=1','-count=1','-tags=offscreen','.'],T/'drivers/cogent'),'root':(['go','test','-race','-p=1','./...'],T),'vet':(['go','vet','-p=1','-tags=offscreen','./...'],T/'drivers/cogent'),'prepare-unit':(['python3','-m','unittest','prepare_test'],T/'drivers/cogent')}
argv,cwd=commands[name.split('-v')[0]];P.mkdir(exist_ok=True);O=P/name;O.mkdir();before=source();(O/'source.json').write_text(json.dumps(before,indent=2)+'\n')
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
start=time.monotonic()
with (O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:r=run_child(argv,cwd=str(cwd),env=env,stdout=out,stderr=err,timeout=600,log_limit_bytes=8<<20)
d={'argv':argv,'cwd':str(cwd),'exit_code':r.returncode,'seconds':time.monotonic()-start,'source_stable':source()==before,'source_sha256':sha(O/'source.json'),'producer_sha256':sha(__file__),'logs':{n:{'bytes':(O/n).stat().st_size,'sha256':sha(O/n)}for n in ['stdout','stderr']},'native_ui_executed':False};(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));assert r.returncode==0 and d['source_stable']
