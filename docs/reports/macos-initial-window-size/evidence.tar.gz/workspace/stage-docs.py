from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
names=sorted(set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()))
assert len(names)==7 and not git('diff','--cached','--name-only')
assert all(n in ['docs/implementation.md','docs/reports/README.md','specs/macos-completion.md']or n.startswith('docs/reports/macos-initial-window-size/')for n in names)
sources={n:sha(T/n)for n in names};git('add','--',*names);diff=git('diff','--cached','--binary');(W/'documentation-staged.diff').write_bytes(diff)
b=dict(base_commit=git('rev-parse','HEAD').decode().strip(),sources=sources,staged_diff_sha256=sha(W/'documentation-staged.diff'),staged_diff_bytes=len(diff),producer_sha256=sha(__file__));(W/'documentation-binding.json').write_text(json.dumps(b,indent=2)+'\n');print(json.dumps(dict(files=len(names),staged_bytes=len(diff),sha256=b['staged_diff_sha256'])))
