"""One provider checkpoint for the exact internally reviewed sizing endpoint."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,importlib.util
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');O=W/'prism'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
b=read(W/'binding.json');r=read(W/'result-review.json');assert r['prism_ready']and not r['unresolved_findings']
assert all(sha(T/p)==h for p,h in b['sources'].items())and not git('diff','--name-only')
payload=git('diff','--cached','--binary');assert hashlib.sha256(payload).hexdigest()==b['staged_diff_sha256']and len(payload)==b['staged_diff_bytes']<40000
O.mkdir(mode=0o700);(O/'payload.diff').write_bytes(payload)
rules={'focus':['Review actionable correctness in this initial native desktop client-size contract. The .patch file is a nested owned-dependency source diff: review its added Go code and tests as implementation, not opaque data. Public app.Window Width/Height retain Dp intent, now explicit initial client requests rather than Body.Min plus upstream screen60-80percent policy. Saved geometry clears InitialSizeDP and retains existing precedence. Manual replay uses separate physical viewport opts unchanged; Workbench later OS client resize path unchanged.',
'Desktop newWindowOnMain applies first-window DPI preferences, chooses one locked ScreenSnapshot, calls opts.FixupForScreen(sc), then passes the SAME snapshot to GLFW creation before Show. Explicit request bypasses content sizing; unset upstream/dialog rules retain their behavior. Dp converts to nearest raw pixel using logicalDPI/160, bounds before integer conversion and after legacy constraint round-trip. Bounds preserve tiny fractional-DPR native minimum and float32-representable native integer limit. Stage field set tag avoids generated setter conflict.',
'Internal review found zero-size tiny fractional-DPR and float32 overflow boundary; fixed with final bounds plus tests through final WindowSizeFromPixels. Fixture readiness and worker-cleanup joins were hardened. Final focused offscreen race and clean pinned preparation pass, full driver offscreen race/root race/vet passed before final generator tag and diagnostic fixture-only guard changes. Two current native race-instrumented cases and exactPID/executable/title read-only AX queries passed with selected screen/options overlay explicitly recorded; later shrink and process cleanup observed. Native fixture admits current integral macOS DPR1/2; fractional/syntheticsecondary DPI coverage is pure tests. No physical pointer/key, cross-display, general performance, previous-results requalification, saved preferences writes or release qualification claimed.']}
(O/'rules.json').write_text(json.dumps(rules,indent=2)+'\n')
binary=Path('/Users/dshills/Development/Go/bin/prism');old=Path('/private/tmp/vellum-native-attestation-probe-20261016');assert sha(binary)==read(old/'prism-staged-v3/receipt.json')['binary_sha256']
spec=importlib.util.spec_from_file_location('sizing_prism_retirement',old/'run-verifier.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
argv=[str(binary),'review','staged','--paths',','.join(b['sources']),'--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','40000','--max-diff-bytes','40000','--rules',str(O/'rules.json'),'--format','json','--out',str(O/'prism.json')]
env=os.environ.copy();env.update(GOENV='off',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod',GOCACHE='/Users/dshills/Library/Caches/go-build',GOPATH='/Users/dshills/Development/Go',GOPROXY='off',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly -p=1',GOMAXPROCS='2',PYTHONDONTWRITEBYTECODE='1')
d=dict(argv=argv,provider='anthropic',model='claude-sonnet-5-5',binary_sha256=sha(binary),binding_sha256=sha(W/'binding.json'),result_review_sha256=sha(W/'result-review.json'),producer_sha256=sha(__file__),payload_sha256=sha(O/'payload.diff'),payload_bytes=len(payload),files=len(b['sources']),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=None);errors=[];child=None;start=time.monotonic()
try:
 with(O/'stdout').open('xb')as out,(O/'stderr').open('xb')as err:
  child=subprocess.Popen(argv,cwd=T,env=env,stdout=out,stderr=err,start_new_session=True);d['owned_pid']=child.pid
  while child.poll()is None:
   if time.monotonic()-start>240:raise TimeoutError('Prism watchdog')
   if(O/'stdout').stat().st_size>8<<20 or(O/'stderr').stat().st_size>8<<20:raise RuntimeError('Prism output bound')
   time.sleep(.1)
  d['exit_code']=child.wait()
except BaseException as e:errors.append(type(e).__name__+': '+str(e))
finally:
 d.update(runner.retire_owned(child,errors));after=runner.attempt(errors,'terminal staged diff',lambda:git('diff','--cached','--binary'))
 source_stable=runner.attempt(errors,'terminal source hashes',lambda:all(sha(T/p)==h for p,h in b['sources'].items()))
 binary_stable=runner.attempt(errors,'terminal Prism binary',lambda:sha(binary)==d['binary_sha256'])
 log_bound=runner.attempt(errors,'terminal log bounds',lambda:all((O/n).stat().st_size<=8<<20 for n in ['stdout','stderr']))
 if log_bound is False:errors.append('terminal Prism log byte limit exceeded')
 artifacts={n:runner.attempt(errors,'terminal artifact '+n,lambda n=n:sha(O/n)if(O/n).exists()else None)for n in ['prism.json','stdout','stderr']}
 d.update(errors=errors,seconds=time.monotonic()-start,sources_stable=source_stable is True,staged_diff_stable=after is not None and hashlib.sha256(after).hexdigest()==b['staged_diff_sha256'],binary_stable=binary_stable is True,terminal_logs_within_bound=log_bound is True,artifacts=artifacts)
 (O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:d[k]for k in ['exit_code','errors','seconds','sources_stable','staged_diff_stable','owned_group_absent','artifacts']}));assert d['exit_code']in[0,1]and not errors and d['sources_stable']and d['staged_diff_stable']and d['binary_stable']and d['owned_group_absent']and d['terminal_logs_within_bound']
