from pathlib import Path
import hashlib,json,subprocess
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=T,timeout=20)
assert git('rev-parse','HEAD').decode().strip()=='b3c1c20819ffc3ccda28b6d1e58f92ed53ae6056'
assert not git('diff','--cached','--name-only')
names=sorted(set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()))
assert len(names)==12,names
expected=['app/app.go','drivers/cogent/cmd/window-size-smoke/main.go','drivers/cogent/driver.go','drivers/cogent/native/README.md','drivers/cogent/native/dependencies.json','drivers/cogent/native/patches/initialsize/0074-initial-client-size.patch','drivers/cogent/native/patches/initialsize/README.md','drivers/cogent/native/patches/initialsize/original-hashes.json','drivers/cogent/native/patches/initialsize/output-hashes.json','drivers/cogent/prepare_test.py','drivers/cogent/window_initial_test.go','specs/windows-services.md']
assert names==expected
sources={n:sha(T/n)for n in names}
git('add','--',*names)
assert not git('diff','--name-only')
for n in names:assert hashlib.sha256(git('show',':'+n)).hexdigest()==sources[n]
diff=git('diff','--cached','--binary');(W/'staged.diff').write_bytes(diff)
b=dict(base_commit=git('rev-parse','HEAD').decode().strip(),sources=sources,staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(diff),files=len(sources),producer_sha256=sha(__file__));(W/'binding.json').write_text(json.dumps(b,indent=2)+'\n');print(json.dumps({k:b[k]for k in ['base_commit','files','staged_diff_bytes','staged_diff_sha256']}))
