import ApplicationServices
import AppKit
import Foundation

struct Failure: Error { let message: String }
let began = DispatchTime.now().uptimeNanoseconds
var calls: [[String: Any]] = []
var rows: [[String: Any]] = []
var phase = "arguments"
func emit(_ result: [String: Any]) {
    if let data = try? JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]),
       let text = String(data: data, encoding: .utf8) { print(text) }
}
func elapsed() -> UInt64 { DispatchTime.now().uptimeNanoseconds - began }
func need(_ condition: Bool, _ message: String) throws {
    if !condition { throw Failure(message: message) }
}
func attribute(_ node: AXUIElement, _ name: String, _ index: Int, required: Bool = false) throws -> CFTypeRef? {
    try need(elapsed() < 6_000_000_000 && calls.count < 2048, "bounded traversal exhausted")
    var value: CFTypeRef?
    let start = DispatchTime.now().uptimeNanoseconds
    let status = AXUIElementCopyAttributeValue(node, name as CFString, &value)
    calls.append(["node": index, "attribute": name, "status": status.rawValue,
                  "elapsed_ns": DispatchTime.now().uptimeNanoseconds - start])
    if required { try need(status == .success && value != nil, "required attribute \(name) unavailable: \(status.rawValue)") }
    return status == .success ? value : nil
}
func frame(_ node: AXUIElement, _ index: Int) throws -> [Double]? {
    guard let position = try attribute(node, "AXPosition", index), let size = try attribute(node, "AXSize", index),
          CFGetTypeID(position) == AXValueGetTypeID(), CFGetTypeID(size) == AXValueGetTypeID() else { return nil }
    var p = CGPoint.zero, s = CGSize.zero
    guard AXValueGetValue(unsafeBitCast(position, to: AXValue.self), .cgPoint, &p),
          AXValueGetValue(unsafeBitCast(size, to: AXValue.self), .cgSize, &s) else { return nil }
    let result = [Double(p.x), Double(p.y), Double(s.width), Double(s.height)]
    return result.allSatisfy { $0.isFinite } ? result : nil
}
let trusted = AXIsProcessTrusted()
if CommandLine.arguments.count == 2 && CommandLine.arguments[1] == "--trust-only" {
    emit(["event": "vellum.window.readonly-ax-trust", "trusted": trusted, "prompt": false]); exit(trusted ? 0 : 2)
}
var result: [String: Any] = ["event": "vellum.window.readonly-ax", "result": "failure", "trusted": trusted,
                            "prompt": false, "actions_performed": false, "settings_changed": false]
do {
    try need(trusted && CommandLine.arguments.count == 4, "trusted caller, PID, executable and title required")
    guard let pid = Int32(CommandLine.arguments[1]), pid > 0 else { throw Failure(message: "invalid PID") }
    let expected = URL(fileURLWithPath: CommandLine.arguments[2]).resolvingSymlinksInPath().path
    let title = CommandLine.arguments[3]
    result["pid"] = pid; result["executable"] = expected; result["expected_title"] = title
    phase = "executable"
    guard let app = NSRunningApplication(processIdentifier: pid), let executable = app.executableURL else { throw Failure(message: "owned application unregistered") }
    try need(executable.resolvingSymlinksInPath().path == expected, "executable mismatch")
    let application = AXUIElementCreateApplication(pid)
    phase = "windows"
    try need(AXUIElementSetMessagingTimeout(application, 0.5) == .success, "application timeout refused")
    guard let windows = try attribute(application, "AXWindows", -1, required: true) as? [AXUIElement] else { throw Failure(message: "window type mismatch") }
    try need(windows.count <= 8, "window count limit")
    var matches: [AXUIElement] = [], titles: [String] = []
    for window in windows {
        try need(AXUIElementSetMessagingTimeout(window, 0.25) == .success, "window timeout refused")
        guard let current = try attribute(window, "AXTitle", -1, required: true) as? String else { throw Failure(message: "title type mismatch") }
        titles.append(current); if current == title { matches.append(window) }
    }
    result["window_titles"] = titles
    try need(matches.count == 1, "owned window missing or ambiguous")
    phase = "children"
    var queue = [matches[0]], visited: [AXUIElement] = [], cursor = 0
    while cursor < queue.count {
        try need(visited.count < 64 && queue.count <= 128, "node count limit")
        let node = queue[cursor]; cursor += 1
        if visited.contains(where: { CFEqual($0, node) }) { continue }
        try need(AXUIElementSetMessagingTimeout(node, 0.25) == .success, "node timeout refused")
        var actual: pid_t = 0
        try need(AXUIElementGetPid(node, &actual) == .success && actual == pid, "node PID mismatch")
        let index = visited.count; visited.append(node)
        var row: [String: Any] = ["index": index]
        for name in ["AXRole", "AXTitle", "AXDescription", "AXIdentifier", "AXEnabled"] {
            if let value = try attribute(node, name, index, required: name == "AXRole") {
                if let string = value as? String { row[name] = String(string.prefix(4096)) }
                else if let number = value as? NSNumber { row[name] = number }
            }
        }
        if let bounds = try frame(node, index) { row["screen_frame"] = bounds }
        rows.append(row)
        if let children = try attribute(node, "AXChildren", index) as? [AXUIElement] {
            try need(queue.count + children.count <= 128, "queue count limit"); queue.append(contentsOf: children)
        }
    }
    try need(rows.count > 1, "owned tree empty")
    result["result"] = "pass"; result["complete_bounded_walk"] = true
} catch { result["error"] = String(describing: error) }
result["phase"] = phase; result["calls"] = calls; result["nodes"] = rows; result["elapsed_ns"] = elapsed()
emit(result)
exit(result["result"] as? String == "pass" ? 0 : 1)
