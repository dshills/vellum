# Rich Mac clipboard V2 source review

Result: APPROVED_SOURCE, findings empty. All 17 immutable source-v2 files and current selected files match the freeze map. Five paths changed from V1; the prior NEEDS_FIX certificate remains unchanged.

The Go decoder checks raw count and payload u32 values against their limits before int conversion. Admitted values fit a 32-bit int; explicit 0xffffffff cases now refuse safely before allocation or slicing. This resolves CLIP-V1-01 without changing native wire format or accepted 64-bit behavior.

Production copying now goes through clipWithWire: a worker-side producer autoreleasepool copies input, a strong asynchronous block capture retains detached NSData, and producer exceptions/refusals produce a terminal callback. The delayed-consumer fixture invokes the same producer without native dispatch/pasteboard access, overwrites/frees input, verifies exact copied bytes after producer return and checks weak-reference release after consumer disposal. That meaningfully addresses the producer-lifetime advisory without claiming a demonstrated prior leak.

The shared parser accepts an injected resolver for its fixture. Two distinct valid MIME names are deliberately mapped to the same native type and refused by the actual deduplication core. This proves the alias policy rather than availability of any particular OS alias. Production clipParse still uses the real MIME resolver.

Dispatcher/admission/cancellation/shutdown code is byte-identical to V1, and clipRead/clipWrite functions are byte-identical. The optional public Services contract, payload caps, legacy Mac text route and deferred-live documentation remain unchanged. No extra live/data handling semantics were introduced by the corrections.

Recorded driver-v2 focused clipboard race, driver-vet-v2 and native-build-v2 receipts pass; V2 SDK packaging also has a separate zero exit. Their raw log hashes were verified. Complete offscreen-suite/relocated SDK checks are separate pending parent gates and are not inferred here. Compilation and parser/queue fixtures do not establish real text/PNG/HTML/custom-MIME roundtrip, first-item/change-count behavior or external interoperability.

No reviewer implementation execution, test/build/prepare, pasteboard read/write, UI/input/preferences/screenshot, provider or Git operation occurred. This is selected-source approval, not complete compiler/SDK closure, redistribution, performance or full Mac acceptance.
