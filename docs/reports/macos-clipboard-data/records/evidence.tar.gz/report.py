import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
repo=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-clipboard-data')
report=repo/'docs/reports/macos-clipboard-data';records=report/'records'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((phase/'source-v2.json').read_text());files=source['sources']
assert all(sha(repo/n)==h for n,h in files.items())
assert not subprocess.check_output(['git','diff','--name-only'],cwd=repo)
review=json.loads((phase/'source-review-v2.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings'] and review['files']==files
prepared=json.loads((phase/'prepared-identity.json').read_text())['files']
current={p.relative_to(repo/'drivers/cogent/build').as_posix():sha(p) for m in ['upstream','typesetting'] for p in sorted((repo/'drivers/cogent/build'/m).rglob('*')) if p.is_file()}
assert current==prepared and len(current)==6172
checks=['root-tests-authorized','root-vet','driver-v2','driver-offscreen-v2','driver-vet-v2','native-build-v2','sdk-contract','sdk-vet','sdk-package-v2','sdk-check-v2','build-metadata','native-load-commands']
process={}
for n in checks:
 d=json.loads((phase/(n+'.json')).read_text());assert d['exit_code']==0 and d['error'] is None and d['live_tests'] is False,n
 for stream in ['stdout','stderr']:assert sha(phase/(n+'.'+stream))==d[stream+'_sha256']
 process[n]=d
sdk=json.loads((phase/'sdk-v2-identity.json').read_text());manifest=json.loads((phase/'private-sdk-v2-manifest.json').read_text())
assert sdk['verified_manifest_files']==6914 and sdk['source_freeze_all_match']
assert all(manifest['files'][n]==h for n,h in files.items())
assert sha(phase/'private-sdk-v2.tar.gz')==sdk['sha256']
sdk_check=json.loads((phase/'sdk-check-v2.stdout').read_text())
assert sdk_check['archive_sha256']==sdk['sha256'] and sdk_check['verified_files']==6914 and sdk_check['digest_verified_against_expected'] and sdk_check['path_contains_spaces']
assert sdk_check['native_runtime']=='not executed' and sdk_check['public_distribution_audit']=='not certified'
prism=json.loads((phase/'prism-v1/prism.json').read_text());prism_process=json.loads((phase/'prism-v1/process.json').read_text());coverage=prism['coverage']
assert coverage['complete'] and coverage['files']==17 and coverage['chunks']>0 and not coverage['excluded'] and not coverage['skipped'] and coverage['truncatedBytes']==0
assert prism_process['source_index_stable'] and prism_process['exit_code']==0 and not prism['findings']
assert prism_process['before']==files and prism_process['after']==files
q={'result':'PASS_OFFSCREEN_MAC_CLIPBOARD','base_commit':source['base_commit'],'source':files,'prepared':prepared,'process':process,'sdk':sdk,'sdk_check':sdk_check,'prism_findings':0,'prism_findings_resolved':True,'prism_coverage':coverage,'source_review_sha256':sha(phase/'source-review-v2.json'),'native_binary_sha256':sha(phase/'workbench-v2'),'live_tests':False,'pasteboard_access':False,'whole_macos_completion':False,'performance_acceptance':False,'distribution_audit':'pending'}
(phase/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records.mkdir(parents=True,exist_ok=False)
excluded={'workbench','workbench-final','workbench-v2','private-sdk.tar.gz','private-sdk-v2.tar.gz'}
members={p.relative_to(phase).as_posix():{'size':p.stat().st_size,'sha256':sha(p)}for p in sorted(phase.rglob('*'))if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts}
archive=records/'evidence.tar.gz'
with archive.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0)as z,tarfile.open(fileobj=z,mode='w',format=tarfile.PAX_FORMAT)as t:
 for name in members:
  data=(phase/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';t.addfile(info,io.BytesIO(data))
index={'schema':1,'members':members,'archive_sha256':sha(archive),'excluded_binary_and_sdk_payloads':sorted(excluded)}
(records/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
checkpoint={'result':q['result'],'base_commit':q['base_commit'],'qualification_sha256':sha(phase/'qualification.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':0,'prism_findings_resolved':True,'archive':{'sha256':sha(archive),'members':len(members)},'live_tests':False,'pasteboard_access':False,'macos_completion':False}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
(report/'README.md').write_text(f'''# Mac clipboard data checkpoint

Vellum adds optional `app.ClipboardServices` and `Application.Clipboard()` without
changing the existing Services interface. The Mac adapter transports exact text,
PNG, HTML and custom MIME bytes in one item. Reads request explicit formats from
the first item, preserve order, omit missing formats and check the board's change
count. Writes prepare one validated item before replacement. Text follows the
UTF-8/no-NUL contract; PNG/HTML/binary data remain opaque, without image conversion
or sanitization. Custom MIME resolution uses the OS registry, with native alias
collisions refused before board access.

Requests have 1..16 formats, at most 127 ASCII MIME bytes, 8 MiB per representation
and 16 MiB aggregate. Four process-wide credits are admitted before encoding.
Canceled callers return promptly; queued native work retains its credit through
terminal acknowledgement. Shutdown closes admission and releases callers even
if the main queue stops. Mac plain-text methods now share this bounded transport.
Inputs are copied before delayed native consumption; results are caller owned.
Cocoa entry and consumer pools define the native payload lifetime explicitly.

Cancellation may race an executing native call and cannot guarantee unchanged
clipboard state. The native clear/write pair is not transactional and failure
may leave an empty board. Cocoa may materialize an external provider before its
length can be checked; framework data limits do not bound provider time/memory.
These implementation limits are part of the [contract](../../../specs/clipboard.md).

Two root clipboard test functions, seven driver clipboard functions (including
actual Objective-C parser/ownership fixtures), and one independent public API
consumer pass. Tests cover malformed/truncated/trailing wires, unsigned length
limits, invalid text/MIME, payload totals, ordered-subset response validation,
detached results, canceled stalled queues, shutdown/application lifetime,
optional legacy compatibility, injected distinct-MIME/native-type collisions,
and copied payload retention/release across a drained producer pool. The alias
fixture injects type resolution; it does not qualify actual OS aliases.

Root race/vet, the complete final offscreen native-module race suite, driver vet,
public-consumer checks and native workbench compilation pass. The executable was
compiled only, with Go 1.27.2; its recorded local load commands specify macOS26.0
minimum/SDK27.0. This is local compilation evidence, not an older-Mac promise.
Linker duplicate-libobjc warnings are retained. Initial root/native-module runs
failed only where the sandbox refused existing private Unix-socket binding;
authorized headless retries pass. All receipts remain distinct.

The final private SDK verifies all 6914 manifest file identities with trusted
digest `{sdk['sha256']}`. All 17 source hashes match. The relocated path contains
spaces; all four module replacements remain inside the SDK. External module
verification, generated consumer race/vet/build and full public API scenarios
pass. Native runtime is explicitly not executed and distribution remains not
certified. All 6172 prepared upstream/typesetting files match this checkpoint.

Internal V1 review identifies unsafe u32-to-int conversion on 32-bit hosts and
records Cocoa worker ownership/alias-fixture advisories. V2 checks raw unsigned
lengths before conversion and adds a shared producer pool with delayed-consumer
ownership and resolver-injected alias tests. Independent V2 source review
approves all 17 final files. One Prism run uses Anthropic Claude Sonnet 5.5,
complete 17-file/{coverage['chunks']}-chunk coverage, raw exit0 and zero findings.
No repeated provider review was run.

This checkpoint never reads/writes NSPasteboard, opens native UI, changes OS
preferences or runs live input/GPU/frame performance checks. Clipboard methods
are implemented and statically compiled; actual text/PNG/HTML/custom-MIME
roundtrips, cross-app interoperation, OS aliases, multiple-item consistency and
change-count races remain deferred until the user explicitly says the computer
is free. Other platforms report the extension unavailable while retaining their
existing text services. Full Mac/P10, performance, native human acceptance and
public distribution gates remain open.

[Checkpoint](records/checkpoint.json), [raw evidence](records/evidence.tar.gz)
and [member index](records/archive-index.json) bind this offscreen scope.
''')
print(json.dumps({'result':q['result'],'members':len(members),'archive_sha256':sha(archive),'report_sha256':sha(report/'README.md'),'checkpoint_sha256':sha(records/'checkpoint.json')}))
