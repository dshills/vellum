import json,sys,time,hashlib
from pathlib import Path
repo=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-clipboard-data')
sys.path.insert(0,str(repo/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
name=sys.argv[1];cwd=repo/str(sys.argv[2]);argv=sys.argv[3:]
env={**child_environment(runtime=False),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
record={'argv':argv,'cwd':str(cwd),'exit_code':None,'error':None,'live_tests':False};start=time.monotonic()
try:
 with (phase/(name+'.stdout')).open('xb') as so,(phase/(name+'.stderr')).open('xb') as se:
  result=run_child(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=240)
  record['exit_code']=result.returncode
except BaseException as e:record['error']={'type':type(e).__name__,'message':str(e)}
finally:
 record['elapsed_seconds']=time.monotonic()-start
 for channel in ['stdout','stderr']:
  p=phase/(name+'.'+channel);record[channel+'_sha256']=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 (phase/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record))
 if record['exit_code']!=0 or record['error'] is not None:sys.exit(1)
