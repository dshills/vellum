"""Package a Darwin factory correction in the owned core pin; no cache mutation."""
import difflib, hashlib, json, shutil
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-autorelease');driver=r/'drivers/cogent';stage=driver/'native/patches/autorelease'
stage.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
app_path='system/driver/desktop/app.go';original=(driver/'build/upstream'/app_path).read_bytes()
(p/'app-original.go').write_bytes(original)
changed=original.decode().replace('\n\t"github.com/oliverbestmann/webgpu/wgpuglfw"','').replace('wgpuglfw.GetSurfaceDescriptor(w.Glw)','nativeSurfaceDescriptor(w.Glw)')
assert changed!=original.decode() and 'wgpuglfw'not in changed
payload={app_path:changed.encode()}
for name in ['surface_darwin.go','surface_other.go','surface_layer_darwin.h']:
    payload['system/driver/desktop/'+name]=(p/name).read_bytes()
inputs={n:sha(original)if n==app_path else None for n in payload};outputs={n:sha(b)for n,b in payload.items()}
diff=[]
for n,b in payload.items():
    old=original.decode().splitlines(keepends=True)if n==app_path else[]
    diff.extend(difflib.unified_diff(old,b.decode().splitlines(keepends=True),fromfile='a/'+n if old else'/dev/null',tofile='b/'+n))
name='0047-scoped-native-layer-ownership.patch';patch=''.join(diff).encode();(stage/name).write_bytes(patch)
for n,d in [('original-hashes.json',inputs),('output-hashes.json',outputs)]:
    (stage/n).write_text(json.dumps(d,indent=2)+'\n')
module=Path('/tmp/vellum-p0-cache/mod/github.com/oliverbestmann/webgpu@v1.36.1-0.20261006093257-de8bdd5d5976')
shutil.copy2(module/'LICENSE',stage/'LICENSE.apache-2.0.txt')
(stage/'provenance.json').write_text(json.dumps({'module':'github.com/oliverbestmann/webgpu','version':module.name.split('@')[1],'source':'wgpuglfw/surface_darwin.go','source_sha256':sha((module/'wgpuglfw/surface_darwin.go').read_bytes()),'license_file':'LICENSE.apache-2.0.txt','license_sha256':sha((stage/'LICENSE.apache-2.0.txt').read_bytes()),'modification':'Driver-owned Darwin shim replaces unpooled layer factory with a local autorelease pool; non-Darwin delegates to unchanged wgpuglfw. No module-cache replacement/mutation.'},indent=2)+'\n')
manifest_path=driver/'native/dependencies.json';manifest=json.loads(manifest_path.read_text());prefix='native/patches/autorelease'
assert not any(s['inputs']==prefix+'/original-hashes.json'for s in manifest['dependencies'][0]['stages'])
manifest['dependencies'][0]['stages'].append({'origin':'drivers/cogent/'+prefix,'inputs':prefix+'/original-hashes.json','outputs':prefix+'/output-hashes.json','patches':[{'file':prefix+'/'+name,'sha256':sha(patch)}]})
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
tests=driver/'prepare_test.py';text=tests.read_text();assert text.count('list(range(1, 47))')==1;tests.write_text(text.replace('list(range(1, 47))','list(range(1, 48))'))
print(json.dumps({'patch_sha256':sha(patch),'outputs':outputs,'expected_prepared_files':6181}))
