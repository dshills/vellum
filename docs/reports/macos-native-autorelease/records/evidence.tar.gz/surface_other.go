//go:build !darwin

// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package desktop

import (
	"github.com/go-gl/glfw/v3.4/glfw"
	"github.com/oliverbestmann/webgpu/wgpu"
	"github.com/oliverbestmann/webgpu/wgpuglfw"
)

func nativeSurfaceDescriptor(window *glfw.Window) *wgpu.SurfaceDescriptor {
	return wgpuglfw.GetSurfaceDescriptor(window)
}
