//go:build darwin

// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package desktop

/*
#cgo CFLAGS: -x objective-c
#cgo LDFLAGS: -framework Cocoa -framework QuartzCore
#include "surface_layer_darwin.h"
*/
import "C"

import (
	"unsafe"

	"github.com/go-gl/glfw/v3.4/glfw"
	"github.com/oliverbestmann/webgpu/wgpu"
)

func nativeSurfaceDescriptor(window *glfw.Window) *wgpu.SurfaceDescriptor {
	return &wgpu.SurfaceDescriptor{MetalLayer: &wgpu.SurfaceSourceMetalLayer{
		Layer: C.vellumMetalLayerFromWindow(unsafe.Pointer(window.GetCocoaWindow())),
	}}
}
