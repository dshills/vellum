// Derived from webgpu/wgpuglfw/surface_darwin.go, Apache-2.0.
// Vellum modification: scope temporary Cocoa ownership with a local pool.
// The upstream license and pinned provenance accompany owned patch 0047.
#import <Cocoa/Cocoa.h>
#import <QuartzCore/CAMetalLayer.h>

static void *vellumMetalLayerFromWindow(void *nativeWindow) {
 @autoreleasepool {
  NSWindow *window = (__bridge NSWindow *)nativeWindow;
  NSView *view = window.contentView;
  // No view means no owner after pool drainage. Never return a dangling layer.
  if(!view)return NULL;
  [view setWantsLayer:YES];
  CAMetalLayer *layer = [CAMetalLayer layer];
  // NSView.layer is strong. The view owns the borrowed descriptor pointer after
  // this temporary pool drains; surface teardown precedes view destruction.
  [view setLayer:layer];
  return (__bridge void *)layer;
 }
}
