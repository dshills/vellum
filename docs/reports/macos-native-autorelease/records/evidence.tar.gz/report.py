"""Seal scoped native ownership tests; measured graphics memory remains open."""
import hashlib, io, json, os, shutil, tarfile
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-autorelease');out=r/'docs/reports/macos-native-autorelease'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
source=read('source-final.json')['sources'];base=read('source-final.json')['base_commit'];reviewed=read('source-prism.json')['sources']
assert len(source)==14 and len(reviewed)==10 and all(source[n]==h for n,h in reviewed.items()) and all(sha(r/n)==h for n,h in source.items())
cert=read('source-review-final.json');cert_source={Path(n).relative_to(r).as_posix():h for n,h in cert['reviewed_source_sha256'].items()}
assert cert['status']=='APPROVED_SOURCE' and cert_source==source and cert['source_manifest_sha256']==sha(p/'source-final.json') and not cert['findings']
provider=read('prism-v1/prism.json');process=read('prism-v1/process.json')
assert process['exit_code']==0 and process['error']is None and process['source_index_stable'] and process['before']==process['after']==reviewed
assert provider['coverage']['complete'] and provider['coverage']['files']==10 and not provider['findings']
assert provider['coverage']['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
prepared={f.relative_to(r/'drivers/cogent/build').as_posix():sha(f)for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
assert len(prepared)==6181
stage=r/'drivers/cogent/native/patches/autorelease';outputs=json.loads((stage/'output-hashes.json').read_text())
assert len(outputs)==4 and all(prepared['upstream/'+n]==h for n,h in outputs.items())
old=read('owned-prepare.json')['prepared_before'];assert len(old)==6178 and {n for n in old if old[n]!=prepared[n]}=={'upstream/system/driver/desktop/app.go'}
assert set(prepared)-set(old)=={'upstream/'+n for n in outputs if n!='system/driver/desktop/app.go'}
assert read('owned-prepare-v2.json')['prepared_after']==prepared
receipts={};groups={'final':source};failed={'pool-baseline','pool-fixed','pool-baseline-final'}
final={'pool-final','pool-baseline-final','native-build','driver-offscreen-race','prepare-tests'}
for f in sorted(p.glob('*.json')):
    d=json.loads(f.read_text())
    if 'source_delta_stable'not in d:continue
    name=f.stem;assert d['exit_code']==int(name in failed) and d['error']is None and d['source_delta_stable'] and not d['live_tests'] and d['source_commit']==base
    assert d['source_delta_before']==d['source_delta_after']
    matches=[k for k,v in groups.items()if v==d['source_delta_before']]
    group=matches[0]if matches else'historical_'+hashlib.sha256(json.dumps(d['source_delta_before'],sort_keys=True).encode()).hexdigest()[:12]
    groups[group]=d['source_delta_before']
    for channel in ['stdout','stderr']:assert sha(p/(name+'.'+channel))==d[channel+'_sha256']
    if name in final:assert group=='final' and d['prepared_before']==d['prepared_after']==prepared
    receipts[name]={'sha256':sha(f),'raw_exit_code':d['exit_code'],'source_group':group,'exact_final_prepared_input':name in final}
assert len(receipts)==10
def checks(name):
    rows=[json.loads(line)for line in(p/(name+'.stdout')).read_text().splitlines()]
    assert len(rows)==2 and [v['fixture']for v in rows]==['surface_pool','input_pool']
    for v in rows:
        assert v['compile_exit']==0 and not v['live_tests'] and v['binary_sha256'] and v['compile_stderr']==''
        assert all(sha(Path(n))==h for n,h in v['inputs'].items())if name in ['pool-final','pool-baseline-final']else True
        v['observation']=json.loads(v['run_stdout'])
    return rows
fixed=checks('pool-final');surface,input_=fixed
assert surface['run_exit']==input_['run_exit']==0 and surface['run_stderr']==input_['run_stderr']==''
assert surface['observation']=={'fixture':'surface_pool','exit':0,'temporaries':0,'live_layer_standins':0,'created':64,'retired':64,'nil_window_and_view_passed':True,'windows_created':0,'gpu_drawables_acquired':0}
assert input_['observation']=={'fixture':'input_pool','exit':0,'temporaries':0,'live_views':0,'factory_calls':901,'requested_cycles':100,'completed_cycles':100,'windows_created':0,'input_sources_changed':False}
baseline=checks('pool-baseline-final');assert all(v['run_exit']==1 for v in baseline)
assert not baseline[0]['observation']['nil_window_and_view_passed'] and baseline[0]['observation']['created']==2
assert baseline[1]['observation']['completed_cycles']==0 and baseline[1]['observation']['temporaries']==2
original=checks('pool-baseline');assert all(v['run_exit']==1 for v in original) and 'temporary=1 layers=1'in original[0]['run_stderr']
bad=checks('pool-fixed');assert bad[0]['run_exit']==1 and bad[0]['observation']['temporaries']==0 and bad[0]['observation']['live_layers']==2 and bad[1]['run_exit']==0
binary=p/'window-cycle-smoke-owned';assert binary.is_file()
provenance=json.loads((stage/'provenance.json').read_text());assert sha(stage/provenance['license_file'])==provenance['license_sha256']
q={'result':'PASS_SCOPED_NATIVE_OWNERSHIP_HEADLESS','base_commit':base,'source':source,'source_groups':groups,'prepared':prepared,'stage_outputs':outputs,'receipts':receipts,'headless_surface':surface['observation'],'headless_input':input_['observation'],'source_review_sha256':sha(p/'source-review-final.json'),'prism_source':reviewed,'prism_raw_exit_code':0,'prism_findings':0,'prism_static_leaves_internally_verified':read('source-prism.json')['excluded_static_leaves'],'native_build_sha256':sha(binary),'final_owned_source_native_window_executed':False,'actual_cocoa_layer_deallocation_qualified':False,'native_memory_qualified':False,'gpu_memory_qualified':False,'full_p11_qualified':False,'macos_completion':False,'quiet_window_expired':True,'next_live_tests_deferred':True,'preferences_changed':False,'input_sources_changed':False,'source_scopes':'Final14 repository leaves and all6181 prepared identities. Provider selects10 implementation/test/registration/docs leaves;4 static pin/provenance/copied-license leaves internally verified. No compiler/cache/SDK full closure.','initial_fixture_failure':'Real CAMetalLayer oracle incorrectly assumed immediate CA deallocation: rawexit1 with temporary0 and two live CA layers, input100pass. Corrected oracle uses countedNSObject stand-ins. Earlier normal-view baseline fails temporaryretirement; finalbaseline layer fails nilguard first and input completes0, not100.','native_followup':'Earlier IOSurface/physical-footprint growth remains unresolved until actual quiet-host live campaign; localpool correction and headless references do not prove native graphics reclamation.'}
(p/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records=out/'records';records.mkdir(parents=True,exist_ok=False);shutil.copy2(Path(__file__),records/'archive-producer.py.txt')
files={}
for folder,dirs,names in os.walk(p):
    dirs[:]=sorted(d for d in dirs if not d.endswith('.app')and not(Path(folder)/d).is_symlink())
    for name in sorted(names):
        f=Path(folder)/name
        if f.is_file()and not f.is_symlink()and f.suffix in ['.json','.stdout','.stderr','.py','.txt','.log','.go','.m','.h']:
            files[f.relative_to(p).as_posix()]=f.read_bytes()
index={n:hashlib.sha256(b).hexdigest()for n,b in files.items()};(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=records/'evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
    for n,b in sorted(files.items()):
        info=tarfile.TarInfo(n);info.size,info.mode,info.mtime=len(b),0o644,0;tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive)as tf:actual={m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest()for m in tf.getmembers()if m.isfile()}
assert actual==index
(out/'README.md').write_text('''# Mac native autorelease ownership: headless correction

Owned patch 0047 replaces the desktop Darwin surface factory with a locally
pooled shim. It captures the content view, refuses a nil window/view before
creating a layer, installs the layer on the strong NSView.layer property, and
returns its borrowed pointer after temporary drainage. Existing normal surface
teardown still precedes view destruction. Non-Darwin delegates to prior wgpuglfw.
The source provenance and Apache-2.0 license are retained; no module-cache files
are edited. Fresh preparation verifies 6,181 files: exactly one previous core
file changes, and three factory/header leaves are added.

Ten input bridge/shared-publication paths now establish local pools. Independent
source review verifies that removing only those wrappers and two ownership
comments reproduces the parent byte-for-byte. Validation, callbacks, retained
state, geometry sort/copy/release and strdup statements remain unchanged. Stored
text copies and retained geometry buffers survive nested pools; Go callbacks
copy UTF-8 values before returning. Malloc replies survive native pool drainage.

## Exact final headless checks

The actual prepared layer header and actual input source compile in isolated,
bounded Objective-C fixtures. Faithful strong-property NSObject stand-ins and
main-thread-only sentinels verify reference ownership; original factory IMPs are
captured before replacement and restored on cleanup. The layer fixture passes
nil-window/no-view refusal, 64 creations/replacements and caller-held references,
then reports zero temporaries/live stand-ins and 64 retirements. The input fixture
completes 100 of 100 cycles with 901 observed factory calls, zero temporaries and
zero views after close. It covers committed text, geometry copying/retention,
early refusal, retained caller data, caret/settle and owned inactive replies.
Admission callbacks are stubs; composition remains unmarked. Other diagnostic
probe/query/environment pool bodies are source-reviewed but not all executed.

The final source adapter offscreen race suite, native-consumer compile and all
11 preparation tests pass. Five final receipts bind all 14 selected source files
and all 6,181 prepared identities, with no source/prepared changes during checks.
Compilation retains the existing duplicate -lobjc warning. No native window,
NSApplication/event loop, GPU drawable, IME/input source, clipboard or user
preference is created or changed. Refusal beeps are replaced only inside the
headless fixture translation unit; production behavior is preserved.

## Failures and review remain distinct

The original normal-view factory baseline fails with an undrained PoolWitness;
the original input baseline fails on attachment before its loop. Both raw exits
remain 1. A first fixed-layer fixture also exits 1: it incorrectly assumes
immediate real CAMetalLayer deallocation, despite observing zero temporaries.
CoreAnimation can defer native cleanup; the corrected ownership oracle uses
counted NSObject stand-ins. Its input fixture passes 100 cycles. That failed
surface oracle is preserved and is not an adopted-runtime failure or memory pass.

The final baseline layer fixture fails the newly checked nil-view invariant first
(two unowned stand-ins); its input fixture records zero completed of 100 requested
cycles. Neither historical failure qualifies a completed loop. Intermediate V2
headless results retain their prior source/input hashes and are not relabeled as
final checks. The archive preserves ten raw receipts/logs and version groups.

Internal review approves 14 exact source/spec/pin/license files and four decoded
patch outputs. One Prism review with Anthropic Claude Sonnet 5.5 selects all ten
implementation/test/registration/doc leaves, covers them in two chunks, returns
exit 0 with no findings, and uses 22,910 input / 3,085 output tokens. Four static
pin/provenance/copied-license leaves are verified internally. The indexed archive
retains source maps, original/v1 bridge/header fixtures, review results and raw
process records. Binaries, caches and desktop snapshots are excluded. This covers
selected source/all prepared identities, not a full compiler/cache/SDK closure.

## Live memory gate remains open

These checks prove temporary and retained-reference behavior under inert fixture
contracts. They do not prove actual CAMetalLayer/drawable/IOSurface deallocation,
preedit/IME behavior, display presentation or resolution of the measured native
physical-footprint growth. No quiet-host live process runs in this phase. Further
live/input/performance work remains deferred while the user uses the computer.
Actual physical-footprint/native-GPU acceptance, full P11/endurance, latency,
human interaction, cross-display and public distribution gates remain open.
''')
print(json.dumps({'result':q['result'],'qualification_sha256':sha(p/'qualification.json'),'archive_sha256':sha(archive),'archive_members':len(index),'receipts':len(receipts)}))
