from pathlib import Path
import hashlib,json,re
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
b=json.loads((W/'binding.json').read_bytes());checked=[]
for n,h in b['sources'].items():
 p=T/n
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 if p.suffix!='.md':continue
 for match in re.finditer(r'\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)',p.read_text()):
  target=match[1]
  if target.startswith(('http:','https:','mailto:','#')):continue
  path=(p.parent/target.split('#')[0]).resolve();assert path.exists(),(n,target);checked.append(dict(source=n,target=target))
out=W/'doc-links.json'
with out.open('x')as f:json.dump(dict(result='PASS',links=len(checked),checked=checked,sources=b['sources'],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),f,indent=2);f.write('\n')
print(json.dumps(dict(result='PASS',local_links=len(checked))))
