"""Commit the exact reviewed packaged software replay evidence checkpoint and fast-forward canonical."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-sdk-replay-238b3b6');N=W
spec=importlib.util.spec_from_file_location('viewport_commit_guard',W.parent/'macos-grid-native-stacks/commit-pending.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W
sha=m.sha;read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def prepared(root):
 return {p.relative_to(root/'drivers/cogent/build').as_posix():sha(p)for module in ['upstream','typesetting']for p in(root/'drivers/cogent/build'/module).rglob('*')if p.is_file()}
def main():
 output=W/'commit-receipt.json';need(not output.exists(),'new receipt');d=dict(result='INCOMPLETE',producer_sha256=sha(__file__),mutations=[],error=None)
 try:
  b=read(W/'binding.json');r=read(W/'final-review.json');need(r['commit_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'final review pins')
  d['before']=dict(candidate=m.observation(T),canonical=m.observation(C));admit=dict(candidate=m.git_admission(T),canonical=m.git_admission(C));d['git_admission']=admit
  need(d['before']['candidate']['head']==d['before']['canonical']['head']==b['base_commit'],'base heads');need(d['before']['candidate']['branch']=='codex/macos-native-results'and d['before']['canonical']['branch']=='codex/foundation-completion','branches')
  need(m.clean(C)and not m.git(T,'diff','--name-only')and not m.git(T,'ls-files','--others','--exclude-standard'),'clean external changes');need(set(m.git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['sources']),'staged names')
  need(all(sha(T/p)==h and hashlib.sha256(m.git(T,'show',':'+p)).hexdigest()==h for p,h in b['sources'].items()),'staged bytes');need(hashlib.sha256(m.git(T,'diff','--cached','--binary')).hexdigest()==b['staged_diff_sha256'],'staged diff')
  source=read(P/'source.json');need(all(sha(T/n)==h for n,h in source['files'].items()if n not in b['sources']),'unchanged source outside documentation');need(prepared(T)==prepared(C)==source['prepared'],'prepared bytes');need(read(P/'receipt.json')['result']=='NINE_PACKAGED_SOFTWARE_REPLAYS_EXECUTED'and read(P/'tools-complete.json')['all_tools_terminal']and read(W/'analysis.json')['result']=='PASS_PACKAGED_SOFTWARE_REPLAY_MATRIX'and read(N/'result-review.json')['result_accepted'],'completed reviewed software replay checks')
  message=W/'commit-message.txt'
  with message.open('x')as out:out.write('docs(macos): qualify packaged SDK software replay consumers\n\nRecord nine already compiled offscreen consumers at dispatch batches1/7/64, with 10k/1M workspace rows and a 100k-node outline. All1449 operations and189 captures pass, including162 exact frozen workspace captures, cross-batch small-fixture equality and independent data/history/cancellation/placement/lifetime checks.\n\nPreserve SDK238b source versus current documentation d4b07d0, raw outputs and bounded cleanup evidence. Internal result/documentation review; no production change or extra provider call. Software routing does not qualify native/physical workflows, performance, memory, public distribution or full Mac completion.\n')
  need(m.git_admission(T)==admit['candidate']and m.git_admission(C)==admit['canonical'],'unchanged Git admission');m.mutation(T,'checkpoint-commit',['git','commit','--file',str(message)],d)
  commit=m.git(T,'rev-parse','HEAD').decode().strip();need(m.clean(T)and m.git(T,'rev-parse','HEAD^').decode().strip()==b['base_commit'],'candidate commit');need(set(m.git(T,'diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(b['sources']),'committed names')
  need(m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']and m.git_admission(C)==admit['canonical'],'canonical admission');m.mutation(C,'checkpoint-fast-forward',['git','merge','--ff-only',commit],d)
  files=m.git(T,'ls-files','-z').decode().split('\0')[:-1];need(len(files)==4664 and all(sha(T/p)==sha(C/p)for p in files),'integrated file parity');need(prepared(T)==prepared(C)==source['prepared'],'integrated prepared parity');need(m.clean(T)and m.clean(C)and m.git(C,'rev-parse','HEAD').decode().strip()==commit,'final clean heads')
  d.update(result='REVIEWED_PACKAGED_SOFTWARE_SDK_EVIDENCE_COMMITTED_AND_INTEGRATED',commit=commit,parent=b['base_commit'],source_files=len(files),prepared_files=len(source['prepared']),both_clean=True,canonical_promoted=True,binding_sha256=sha(W/'binding.json'),review_sha256=sha(W/'final-review.json'),software_result_review_sha256=sha(N/'result-review.json'),native_runtime_executed=False,public_distribution=False,provider_calls=0,full_macos_qualified=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  failed=False
  for label,root in [('candidate',T),('canonical',C)]:
   try:d[label+'_terminal']=m.observation(root)
   except BaseException as e:failed=True;d[label+'_observation_error']=dict(type=type(e).__name__,message=str(e))
  if failed:d.update(result='FAILED_TERMINAL_OBSERVATION',both_clean=False)
  with output.open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps(d),flush=True)
  if failed and d['error']is None:raise RuntimeError('terminal observation failed')
if __name__=='__main__':main()
