"""Retain packaged SDK software replay evidence separately from native checks."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-sdk-replay-238b3b6');T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'docs/reports/macos-current-sdk';BASE=Path('/private/tmp/vellum-current-sdk-238b3b6')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']and r['report_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'reviewed results and producer')
a=read(W/'analysis.json');provenance=read(W/'provenance.json');sdk=Path(provenance['sdk_root']);need(a['result']=='PASS_PACKAGED_SOFTWARE_REPLAY_MATRIX'and a['operations']==1449 and a['checkpoints']==189 and read(P/'tools-complete.json')['all_tools_terminal'],'exact terminal result')
members={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'evidence symlink')
  if p.is_file()and'__pycache__'not in p.parts:members[label+p.relative_to(root).as_posix()]=p
add('controller/',W);add('checks/',P)
for name in ['child_process.py','sdk_environment.py']:members['helpers/'+name]=T/'scripts'/name
members['helpers/owned-runner.py']=W.parent/'macos-sdk-native-238b3b6/run.py';members['helpers/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
members['sdk/SDK_MANIFEST.json']=sdk/'SDK_MANIFEST.json';members['sdk/build-receipt.json']=BASE/'entrypoints/receipt.json'
for n in ['managed-replay','workspace-replay']:add('sdk/build/'+n+'/',BASE/'entrypoints'/n)
source=['replay/runner.go','examples/replay/native.go','examples/replay/native_record.go','examples/replay/native_test.go','examples/replay/fixture.go','examples/replay/fixture.json','examples/replay/native-record.json','examples/replay/workspace/backend_offscreen.go','examples/replay/workspace/model.go','examples/replay/workspace/replay_offscreen_test.go','examples/replay/cmd/native/main.go','examples/replay/cmd/workspace-replay/main.go']+[f'examples/replay/workspace/records/{rows}{suffix}'for rows in[10000,1000000]for suffix in['.json','.golden.json']]
for n in source:members['sdk/source/'+n]=sdk/n
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<160 and expanded<32<<20,'bounded evidence')
manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},count=len(members),expanded_bytes=expanded,excluded_artifacts=dict(private_sdk=provenance['archive'],compiled_binaries={k:v['binary']for k,v in provenance['binaries'].items()},extracted_sdk=dict(path=str(sdk),manifest_sha256=provenance['manifest_sha256'],files=7411)))
with(D/'software-evidence.manifest.json').open('x')as f:f.write(json.dumps(manifest,indent=2)+'\n')
with(D/'software-evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,p in members.items():
    data=p.read_bytes();need(hashlib.sha256(data).hexdigest()==manifest['files'][n]['sha256'],'archive input drift');entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'software-evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive member integrity')
result=dict(status='REVIEWED_PACKAGED_SOFTWARE_REPLAY_MATRIX',analysis=a,provenance=provenance,result_review_sha256=sha(W/'result-review.json'),evidence=dict(file='software-evidence.tar.gz',sha256=sha(D/'software-evidence.tar.gz'),bytes=(D/'software-evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded),provider_calls=0,native_runtime_executed=False,physical_input_generated=False,performance_qualified=False,public_distribution=False,full_macos_qualified=False)
with(D/'software-replays.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
p=D/'README.md';text=p.read_text();need('## Packaged software replay follow-up'not in text,'new subsection');p.write_text(text+'''

## Packaged software replay follow-up

The existing `managed-replay` and `workspace-replay` SDK executables, both built
with `offscreen`, run nine cases without rebuilding or launching native windows.
The small managed fixture runs at dispatch batches 1, 7 and 64. The professional
workspace runs at the same batches with both 10,000 and 1,000,000 stored rows,
twenty numeric fields per row and a 100,000-node outline after project loading.
All cases together complete 1,449 recorded operations and 189 captures.

The six workspace cases compare every one of their 162 complete captures against
the SDK's unchanged frozen records: model, geometry, semantics, UTF-16 ranges,
focus and software-image hashes. The small fixture's nine captures are equal
across all three batches (27 capture observations); these comparisons use the
first observed batch, without claiming a separate frozen small-fixture golden.
Progress/transport counters remain outside cross-batch semantic equality.

Independent contract checks derive stored-byte hashes and numeric sort/filter
results. They also check routed two-axis selection, canceled worker installation,
outline collapse/expand/filter, Unicode notes, tab ordering, placement preview
and single commit, canvas selection/pan/zoom, same-object Undo/Redo, independent
notes history, modal background isolation and surviving inspector lifetime.
Twelve deliberate corrupted or incomplete capture controls are refused. Source
records and golden files are read unchanged; none are authored by acceptance.

All nine owned processes exit with status zero, both raw streams reach EOF and
each process group is observed absent. Complete current tracked/prepared source,
all 7,411 SDK file hashes, the private archive and both binaries remain unchanged.
Runtime source stays `238b3b6`; `d4b07d0` is the separate documentation endpoint
present in both clean checkouts during these runs.

The workspace runs retain a repeated existing `lines.Lines` diagnostic that
requires Monospace font style and applies its own correction. Managed small-
fixture stderr is empty. This checkpoint does not fix the workspace font-style
warning; its raw stderr remains part of the evidence alongside successful
frozen-capture comparisons.

These are software-rendered routed widget checks through the public SDK. They
do not qualify Cocoa/physical input, native/GPU presentation or memory, timing
budgets, full professional/native P9/P11, release distribution or full Mac
completion. Internal result and documentation reviews cover this test-only
checkpoint; the existing stage 0075 Prism review remains unchanged.

See [software results](software-replays.json), [software manifest](software-evidence.manifest.json)
and [software raw evidence](software-evidence.tar.gz). Earlier compilation and
native hello evidence keep their separate source and qualification scopes.
''')
for n in ['docs/implementation.md','specs/macos-completion.md']:
 p=T/n;text=p.read_text();text+='''

## Packaged public SDK software replay

The [SDK replay follow-up]('''+('reports/macos-current-sdk/README.md'if n.startswith('docs/')else'../docs/reports/macos-current-sdk/README.md')+''')
executes both already compiled offscreen replay commands at batches 1, 7 and 64,
including the professional workspace with 10k/1M stored rows and a 100k-node
outline. All nine cases complete 1,449 operations and 189 captures; 162 workspace
captures match unchanged frozen model/layout/semantics/text/image records.
Independent data, history, cancellation, placement and window-lifetime checks
pass. Runtime source remains SDK `238b3b6`, distinct from current documentation
endpoint `d4b07d0`. This advances packaged software routing evidence; native and
physical workflows, timing/memory budgets, full P9/P11 and Mac release remain open.
''';p.write_text(text)
print(json.dumps(dict(result='SOFTWARE_SDK_REPORT_GENERATED',files=6,members=len(members),expanded_bytes=expanded,archive_bytes=(D/'software-evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'software-evidence.tar.gz'))))
