"""Verify raw runs against frozen captures and independent domain assertions."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
from run import W,P,T,C,read,sha,need,identity,g
from oracles import workspace,managed
def common(result,record,count):
 need(result['Applied']==len(record['operations'])and result['QuiescentNow']is True,'complete operation list and quiescence');res=result['Residual'];need(all(type(res[k])is int and res[k]==0 for k in['Ready','Running','Awaiting','DueTimers'])and res['Blocked']is False,'no currently ready residual work')
 points=result['Checkpoints'];captures=[o for o in record['operations']if o['kind']=='capture'];need(len(points)==len(captures)==count,'exact capture count')
 for p,o in zip(points,captures):need(p['Sequence']==o['sequence']and p['Label']==o['label']and p['Window']==o['window'],'capture record identity')
 return points
def main():
 receipt=read(P/'receipt.json');need(receipt['result']=='NINE_PACKAGED_SOFTWARE_REPLAYS_EXECUTED'and len(receipt['cases'])==9 and all(receipt[k]is True for k in['source_stable','sdk_stable','pins_stable']),'completed raw execution')
 a=read(W/'provenance.json');sdk=Path(a['sdk_root']);source=read(P/'source.json');need(identity(T)==identity(C)==source,'current source unchanged');g.sdk_valid(a)
 results=[];managed_first=None;controls=[]
 for case in receipt['cases']:
  out=P/'runs'/case['label'];run=case['run'];need(read(out/'receipt.json')==case and all(sha(out/n)==run['logs'][n]['sha256']and(out/n).stat().st_size==run['logs'][n]['bytes']for n in['stdout','stderr']),'raw log and case integrity');need(run['owned']['group_absent']and run['owned']['terminal']and run['exit_code']==0,'owned process terminal')
  raw=read(out/'stdout');rows=case['rows'];batch=case['batch'];replay=sdk/'examples/replay'
  if rows is None:
   record=read(replay/'native-record.json');need(raw['Kind']=='actual-managed-software-replay'and raw['Batch']==batch and raw['FixtureSHA256']==sha(replay/'fixture.json')and raw['RecordSHA256']==sha(replay/'native-record.json'),'managed fixture identity');points=common(raw['Result'],record,9);managed(points)
   if managed_first is None:managed_first=points
   else:need(points==managed_first,'managed cross-batch exact checkpoints')
   extra=dict(cross_batch_equal=True,frozen_workspace_golden_compared=False)
  else:
   record=read(replay/f'workspace/records/{rows}.json');points=common(raw,record,27);golden=read(replay/f'workspace/records/{rows}.golden.json');need(points==golden,'full frozen workspace checkpoint equality');oracle=workspace(rows,points);extra=dict(frozen_golden_sha256=sha(replay/f'workspace/records/{rows}.golden.json'),independent_oracle=oracle)
   if batch==1:
    # Distinct deliberate corruptions exercise oracle sensitivity beyond a golden comparator.
    for label,field,value in [('opened','DataSHA256','0'*64),('sorted','FirstValue','invalid'),('filtered','FirstKey','row:invalid'),('notes-edited','Editor',{}),('placement-redone','Canvas',{}),('surviving-inspector','Name','wrong')]:
     bad=copy.deepcopy(points);target=next(p for p in bad if p['Label']==label);target['Data']['Model'][field]=value
     try:workspace(rows,bad)
     except (ValueError,KeyError):controls.append(dict(rows=rows,label=label,result='REFUSED_CORRUPTED_CAPTURE'))
     else:raise ValueError('oracle accepted corrupted '+label)
  results.append(dict(label=case['label'],entrypoint=case['entrypoint'],rows=rows,batch=batch,operations=len(record['operations']),checkpoints=len(points),stdout_sha256=sha(out/'stdout'),checkpoints_sha256=hashlib.sha256(json.dumps(points,sort_keys=True,separators=(',',':')).encode()).hexdigest(),**extra))
 analysis=dict(result='PASS_PACKAGED_SOFTWARE_REPLAY_MATRIX',source_commit=a['source_commit'],current_checkout_commit=a['current_checkout_commit'],producer_sha256=sha(__file__),cases=results,processes=9,operations=sum(c['operations']for c in results),checkpoints=sum(c['checkpoints']for c in results),frozen_workspace_comparisons=162,managed_cross_batch_checkpoints=27,oracle_corruption_controls=controls,source_stable=True,sdk_stable=True,native_runtime_executed=False,physical_input_generated=False,performance_qualified=False,public_distribution=False,full_macos_qualified=False)
 with(W/'analysis.json').open('x')as f:f.write(json.dumps(analysis,indent=2)+'\n')
 print(json.dumps({k:v for k,v in analysis.items()if k not in['cases','oracle_corruption_controls']}))
if __name__=='__main__':main()
