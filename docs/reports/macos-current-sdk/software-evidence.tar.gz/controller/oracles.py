"""Independent contract checks complement exact frozen workspace captures."""
import hashlib,struct
def need(ok,msg):
 if not ok:raise ValueError(msg)
def data_oracle(rows):
 period=10007;raw=b''.join(struct.pack('<20I',*[(r*97+c*13+7)%period for c in range(20)])for r in range(period));cycles,tail=divmod(rows,period);h=hashlib.sha256()
 for _ in range(cycles):h.update(raw)
 h.update(raw[:tail*80]);indexes=range(min(rows,period));best=max(indexes,key=lambda r:(r*97+7)%period);allowed=[r for r in range(period)if'7'in str((r*97+20)%period)];count=cycles*len(allowed)+sum(r<tail for r in allowed);filtered=max((r for r in allowed if r<rows),key=lambda r:(r*97+7)%period)
 return dict(sha256=h.hexdigest(),best_row=best,best=(best*97+7)%period,filter_count=count,filter_row=filtered,filter_best=(filtered*97+7)%period)
def workspace(rows,points):
 need(len(points)==27 and len({p['Label']for p in points})==27,'27 distinct workspace checkpoints')
 all={p['Label']:p['Data']for p in points};models={n:v['Model']for n,v in all.items()};images={p['Label']:p['ImageSHA256']for p in points}
 for p in points:need(p['Data']['Windows']and len(p['ImageSHA256'])==64 and not p['Data']['Model']['Failure'],'complete workspace observation')
 m=models['opened'];need(m['Loaded']is True and m['StoredRows']==rows and m['StoredColumns']==20 and m['StoredTreeNodes']==100000 and m['Grid']['Stamp']['Rows']==rows and m['Tree']['VisibleRows']==100000 and m['Name']=='North Star','real stored fixture')
 oracle=data_oracle(rows);need(m['DataSHA256']==oracle['sha256'],'independent stored bytes')
 m=models['property-edited'];need(m['Name']=='Harbor'and m['History']['UndoCount']==1 and m['History']['Dirty']is True,'property history')
 sorted=models['sorted'];need(sorted['Sorted']is True and sorted['FirstKey']==f"row:{oracle['best_row']:07d}"and sorted['FirstValue']==str(oracle['best']),'numeric sort')
 selected=models['grid-scrolled-selected'];grid=selected['Grid'];need(grid['Active']['RowKey'].startswith('row:')and grid['Active']['ColumnID']=='c00'and grid['Selection']['CapturedRows']==1 and grid['Viewport']['ScrollX']>0 and grid['Viewport']['ScrollY']!=sorted['Grid']['Viewport']['ScrollY'],'routed two-axis selection');index=int(grid['Active']['RowKey'][4:]);need(0<=index<rows and selected['ActiveValue']==str((index*97+7)%10007),'active cell oracle')
 m=models['cancel-delivered'];need(m['Filtered']is False and m['Grid']['Stamp']==grid['Stamp']and m['Grid']['Active']==grid['Active']and m['Task']['OwnerDone']is True and m['Task']['Canceled']is True and len(m['Outcomes'])>=3 and m['Outcomes'][2]==dict(Kind='query',Result='canceled'),'canceled worker installation')
 m=models['filtered'];need(m['Filtered']is True and m['Grid']['Stamp']['Rows']==oracle['filter_count']and m['FirstKey']==f"row:{oracle['filter_row']:07d}"and m['FirstValue']==str(oracle['filter_best']),'filter oracle')
 need(models['tree-collapsed']['Tree']['VisibleRows']==1 and models['tree-expanded']['Tree']['VisibleRows']==100000 and models['tree-filtered']['Tree']['VisibleRows']==2 and models['tree-filtered']['Tree']['Pending']is False,'outline indexes')
 notes=models['notes-edited']['Editor'];need(notes['Text']=='Notes Ω\n'and notes['Selection']['Focus']==8 and notes['Composing']is False,'Unicode notes')
 m=models['tabs-reordered'];need(m['Layout']['root']['second']['first']['tabs']==['canvas','notes','grid']and m['Editor']['Text']==notes['Text'],'tab drag content')
 before=models['placement-preview'];placed=models['placed'];need(not before['Canvas']['Objects']and len(placed['Canvas']['Objects'])==1 and placed['Canvas']['Objects'][0]['ID']=='block-1'and placed['History']['UndoCount']==2 and images['placement-preview']!=images['placed'],'single placement preview/commit')
 m=models['canvas-navigated'];need(m['Canvas']['View']['Zoom']!=placed['Canvas']['View']['Zoom']and m['Canvas']['View']['Center']!=placed['Canvas']['View']['Center']and m['Canvas']['Selected']=='block-1','canvas navigation')
 need(not models['placement-undone']['Canvas']['Objects']and models['placement-redone']['Canvas']['Objects']==placed['Canvas']['Objects'],'same-object placement undo/redo')
 m=models['undone'];need(m['Name']=='North Star'and m['History']['Dirty']is False and m['History']['UndoCount']==0 and not m['Canvas']['Objects']and m['Editor']['Text']=='Notes Ω\n','independent document history')
 need(models['modal-open']['Modal']is True and models['modal-closed']['Modal']is False and models['modal-open']['Canvas']['View']==models['modal-closed']['Canvas']['View'],'modal background isolation')
 survivor=all['surviving-inspector'];need(len(survivor['Windows'])==1 and survivor['Windows'][0]['ID']=='inspector'and survivor['Model']['Name']=='North Star','independent inspector lifetime')
 return oracle
def managed(points):
 need(len(points)==9 and len({p['Label']for p in points})==9,'nine distinct managed captures')
 for p in points:need(len(p['ImageSHA256'])==64 and p['Data']['Elements'],'software image and measured elements')
 last=points[-1]['Data'];m=last['Model'];need(m['Property']=='North Star'and m['Sorted']is True and m['Selected']=='r-alpha'and m['Dirty']is False and m['WorkerCleanups']==1 and len(m['Results'])==1 and m['Results'][0]['Outcome']=='canceled','managed final model and worker cleanup')
 need(m['UIAttempts']and last['Viewport']==dict(Min=dict(X=0,Y=0),Max=dict(X=860,Y=620)),'managed UI routing and viewport')
