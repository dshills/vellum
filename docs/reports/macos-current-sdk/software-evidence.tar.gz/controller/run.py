"""Execute existing SDK software replay binaries; no native windows or rebuilds."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-sdk-replay-238b3b6');BASE=Path('/private/tmp/vellum-current-sdk-238b3b6');HEAD='d4b07d06c57f3045c7a56eb731bd760fefbf7f4a';SDK_SOURCE='238b3b619e5ef274c218cb62d0b348e44e3fcaf8'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
guard_path=W.parent/'macos-sdk-native-238b3b6/run.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
need(sha(guard_path)=='e76238012be63f58cbc5923e27f6fc227a3aca8443d85d64f466c0675382c7ac','reviewed generic owned-child helper')
g=module('sdk_replay_owned_guard',guard_path)
from child_process import run_child
def identity(root):
 def git(*args):return run_child(['git',*args],cwd=root,capture_output=True,check=True,timeout=20).stdout
 need(git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-z'),'clean current checkout')
 names=git('ls-files','-z').decode().split('\0')[:-1];files={};prepared={}
 for n in names:
  p=root/n;need(p.is_file()and not p.is_symlink(),'tracked regular file');files[n]=sha(p)
 for name in ['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/name).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 need(len(files)==4661 and len(prepared)==6246,'source counts');return dict(commit=HEAD,files=files,prepared=prepared)
def prepare():
 P.mkdir(mode=0o700);a=read(W.parent/'macos-current-sdk-238b3b6/analysis.json');receipt=read(BASE/'entrypoints/receipt.json');sdk=Path(receipt['sdk_root'])
 provenance=dict(source_commit=SDK_SOURCE,current_checkout_commit=HEAD,sdk_root=str(sdk),manifest_sha256=sha(sdk/'SDK_MANIFEST.json'),archive=dict(path=str(BASE/'sdk.tar.gz'),sha256=a['archive']['sha256']),binaries={n:a['demos'][n]for n in['managed-replay','workspace-replay']},entrypoints_receipt_sha256=sha(BASE/'entrypoints/receipt.json'))
 need(a['source_commit']==SDK_SOURCE and receipt['result']=='ALL_REMAINING_DOCUMENTED_SDK_ENTRYPOINTS_COMPILE','verified packaged build')
 for name,v in provenance['binaries'].items():need(v['tags']=='offscreen'and sha(v['binary']['path'])==v['binary']['sha256']and receipt['entrypoints'][name]['complete']is True,'software executable identity')
 need(sha(BASE/'sdk.tar.gz')==provenance['archive']['sha256'],'private archive integrity');g.sdk_valid(provenance)
 source=identity(T);need(identity(C)==source,'source parity');(P/'source.json').write_text(json.dumps(source,indent=2)+'\n');(W/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 paths=[Path(__file__),W/'analyze.py',W/'oracles.py',W/'provenance.json',P/'source.json',guard_path,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),BASE/'entrypoints/receipt.json',W.parent/'macos-current-sdk-238b3b6/analysis.json',sdk/'SDK_MANIFEST.json',BASE/'sdk.tar.gz']+[Path(v['binary']['path'])for v in provenance['binaries'].values()]
 pins={str(p.resolve()):sha(p)for p in paths};(W/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps(dict(prepared=True,source_commit=SDK_SOURCE,current_checkout_commit=HEAD,native_runtime_executed=False,pins=len(pins))))
def main():
 need(sys.argv[1:]in[['prepare'],['run']],'fixed phase')
 if sys.argv[1]=='prepare':prepare();return
 need(not(P/'receipt.json').exists()and not(P/'runs').exists(),'fresh output only')
 a=read(W/'provenance.json');source=read(P/'source.json');pins=read(W/'inputs.json');stable=lambda:all(sha(p)==h for p,h in pins.items())
 need(stable()and identity(T)==identity(C)==source,'initial integrity');g.sdk_valid(a);(P/'runs').mkdir()
 d=dict(result='INCOMPLETE',source_commit=SDK_SOURCE,current_checkout_commit=HEAD,producer_sha256=sha(__file__),inputs_sha256=sha(W/'inputs.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False,physical_input_generated=False,public_distribution=False,full_macos_qualified=False,error=None,cases=[],observation_errors=[])
 try:
  plan=[('managed-replay',None,b)for b in[1,7,64]]+[('workspace-replay',rows,b)for rows in[10000,1000000]for b in[1,7,64]]
  for name,rows,batch in plan:
   label=f'{name}-{rows or "small"}-b{batch}';argv=[a['binaries'][name]['binary']['path'],'-batch',str(batch)]+(['-rows',str(rows)]if rows else[])
   run=g.execute(argv,Path(a['sdk_root'])/'examples/replay',P/'runs'/label,lambda:False,stable,timeout=360 if rows else 45,limit=8<<20)
   record=dict(label=label,entrypoint=name,rows=rows,batch=batch,run=run);d['cases'].append(record)
   with(P/'runs'/label/'receipt.json').open('x')as f:f.write(json.dumps(record,indent=2)+'\n')
   need(run['created']and run['error']is None and not run['observation_errors']and run['exit_code']==0 and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and run['logs_complete']and run['pins_stable'],'owned software replay failed '+label)
   print(json.dumps(dict(case=label,result='SOFTWARE_REPLAY_EXECUTED',seconds=run['seconds'],stdout_bytes=run['logs']['stdout']['bytes'])),flush=True)
  d['result']='NINE_PACKAGED_SOFTWARE_REPLAYS_EXECUTED'
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 finally:
  for label,fn in [('source_stable',lambda:identity(T)==identity(C)==source),('sdk_stable',lambda:g.sdk_valid(a)is None),('pins_stable',stable)]:
   try:d[label]=fn()
   except BaseException as e:d[label]=False;d['observation_errors'].append(dict(stage=label,type=type(e).__name__,message=str(e)))
  if d['observation_errors']or not all(d.get(n)for n in['source_stable','sdk_stable','pins_stable']):d['result']='FAILED_SOFTWARE_REPLAY_INTEGRITY'
  d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with(P/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k!='cases'}),flush=True)
 need(d['result']=='NINE_PACKAGED_SOFTWARE_REPLAYS_EXECUTED','replay run failed')
if __name__=='__main__':main()
