"""Reconcile the current SDK archive, source origins, consumer and demo receipts."""
from pathlib import Path
import hashlib,importlib.util,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
c=module('current_sdk_inspection_guard',W/'check.py');demo=module('current_sdk_demo_guard',W/'demos.py');P,T,C=c.P,c.T,c.C;sha,read,need=c.sha,c.read,c.need
packager=module('current_sdk_source_selection',T/'scripts/release-sdk.py');checker=module('current_sdk_verified_archive',T/'scripts/check-sdk.py')
source=read(P/'source.json');need(c.identity(T)==c.identity(C)==source,'source endpoints')
checks={}
for name in['package','relocate']:
 out=P/name;d=read(out/'receipt.json');need(d['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK'and d['exit_code']==0 and d['error']is None and d['source_stable']is True and d['canonical_stable']is True,'passing '+name)
 need(d['source_sha256']==sha(P/'source.json')and d['producer_sha256']==sha(W/'check.py'),'check provenance')
 for channel,v in d['logs'].items():need(sha(out/channel)==v['sha256']and(out/channel).stat().st_size==v['bytes']<=8<<20,'raw '+name)
 checks[name]=dict(receipt_sha256=sha(out/'receipt.json'),seconds=d['seconds'],validation=d['validation'])
archive=P/'sdk.tar.gz';digest=read(P/'package/receipt.json')['archive']['sha256'];verified=checker.verify_archive(archive,digest);manifest=verified['manifest'];prefix=verified['prefix']+'/'
need(manifest['private_build']is True and manifest['source']==dict(commit=c.COMMIT,clean=True)and manifest['untracked_files']==[]and manifest['release']['module']=='github.com/dshills/vellum','private clean namespace')
expected={n:sha(p)for n,p in packager.source_files(T)};actual=manifest['files'];need(all(actual.get(n)==h for n,h in expected.items()),'every selected source byte')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();need(all(m.isfile()for m in members)and len(members)==len(actual)+1,'regular archive leaves');inventory=json.load(tar.extractfile(prefix+'THIRD_PARTY_INVENTORY.json'))
generated={'PRIVATE_BUILD.txt','THIRD_PARTY_INVENTORY.json'}
for item in inventory['modules']:
 for notice in item['license_files']:
  name='THIRD_PARTY_NOTICES/'+notice['notice'];need(actual[name]==notice['sha256'],'notice digest association');generated.add(name)
need(set(actual)==set(expected)|generated and not(set(expected)&generated),'exact source/generated inventory');need(manifest['files']==read(P/'demos/manifest.json')['files'],'same demo archive manifest')
dr=read(P/'demos/receipt.json');need(dr['result']=='INCOMPLETE'and dr['error']==dict(type='ValueError',message='demo command replay/metadata')and all(dr[k]is True for k in['source_stable','canonical_stable','sdk_stable','archive_stable']),'preserved incomplete first matrix');need(dr['source_sha256']==sha(P/'source.json')and dr['producer_sha256']==sha(W/'demos.py')and dr['archive_sha256']==digest,'demo provenance');sdk=Path(dr['sdk_root']);need(' 'in str(sdk),'relocated spaces');demo.snapshot(sdk,verified)
cr=read(P/'entrypoints/receipt.json');need(cr['result']=='ALL_REMAINING_DOCUMENTED_SDK_ENTRYPOINTS_COMPILE'and cr['error']is None and cr['count']==5 and all(cr[k]is True for k in['source_stable','canonical_stable','sdk_stable','archive_stable']),'remaining command compilation');need(cr['producer_sha256']==sha(W/'entrypoints.py')and cr['original_demo_receipt_sha256']==sha(P/'demos/receipt.json')and cr['source_sha256']==sha(P/'source.json')and cr['archive_sha256']==digest and cr['sdk_root']==str(sdk),'command provenance')
compiled={};selected={n:v for n,v in dr['examples'].items()if v['complete']};need(list(selected)==demo.NAMES[:8],'eight inherited app builds');pending=cr['entrypoints'];need(set(pending)=={'viewport3d','workspace','workspace-smoke','managed-replay','workspace-replay'},'five documented remaining entrypoints')
for name,record,root,command_count in [(n,v,P/'demos',4)for n,v in selected.items()]+[(n,v,P/'entrypoints',5)for n,v in pending.items()]:
 need(record['complete']is True and len(record['commands'])==command_count,'complete demo '+name)
 job=root/name;expected_origins={'github.com/dshills/vellum':'.','github.com/dshills/vellum/drivers/cogent':'drivers/cogent','cogentcore.org/core':'drivers/cogent/build/upstream','github.com/go-text/typesetting':'drivers/cogent/build/typesetting'};need(record['origins']==expected_origins,'exact module origins '+name)
 for command in record['commands']:
  label=command['command'];part=job/label;need(command['exit_code']==0 and Path(command['cwd']).resolve().is_relative_to(sdk.resolve()),'demo command outcome '+name)
  for channel,v in command['logs'].items():need(sha(part/channel)==v['sha256']and(part/channel).stat().st_size==v['bytes']<=8<<20,'demo raw '+name)
 need(sha(record['binary']['path'])==record['binary']['sha256']and Path(record['binary']['path']).stat().st_size==record['binary']['bytes'],'demo binary '+name);compiled[name]=dict(binary=record['binary'],origins=record['origins'],target=record.get('target','.'),tags=record.get('tags'),example=record.get('example',name))
need(len(compiled)==13,'nine applications plus four replay commands')
root=dr['examples']['replay'];need(root['complete']is False and root['commands'][-1]['exit_code']==1 and root['commands'][-1]['command']=='metadata','first root-library check remains failed')
for command in root['commands']:
 for channel,v in command['logs'].items():need(sha(P/'demos/replay'/command['command']/channel)==v['sha256'],'root-library raw retained')
with Path(cr['root_library']['path']).open('rb')as f:need(f.read(8)==b'!<arch>\n','actual Go library archive')
need(sha(cr['root_library']['path'])==cr['root_library']['sha256'],'root library hash')
metadata=read(T/'drivers/cogent/native/dependencies.json');stages=metadata['dependencies'][0]['stages'][-2:];patches=[patch for stage in stages for patch in stage['patches']];need([Path(x['file']).name[:4]for x in patches]==['0074','0075'],'owned stages74/75')
for item in patches:need(actual['drivers/cogent/'+item['file']]==item['sha256'],'owned patch included')
for name in['packet.go','tile_binning_vellum_test.go']:
 rel='upstream/paint/renderers/sceneplan/'+name;need(actual['drivers/cogent/build/'+rel]==source['prepared'][rel],'stage75 prepared output included')
need(checks['relocate']['validation']['verified_files']==len(actual)and checks['relocate']['validation']['archive_sha256']==digest,'consumer exact archive')
result=dict(status='CURRENT_PRIVATE_SDK_AND_DEMOS_RECONCILED',source_commit=c.COMMIT,source_files=len(source['files']),prepared_files=len(source['prepared']),source_sha256=sha(P/'source.json'),archive=dict(sha256=digest,bytes=archive.stat().st_size,manifest_files=len(actual),regular_members=len(members),selected_source_files=len(expected),generated_files=len(generated),private_build=True,version=manifest['release']['version'],namespace=manifest['release']['module']),inventory=dict(modules=len(inventory['modules']),distribution_audit=inventory['distribution_audit'],scope=inventory['scope']),checks=checks,demos=compiled,compiled_demo_applications=9,compiled_replay_commands=4,first_matrix_result='INCOMPLETE',first_matrix_failure_requalified=False,first_matrix_failure='Root replay package is a Go library; executable metadata check refused it. Correct documented cmd entrypoints built separately.',entrypoints_receipt_sha256=sha(P/'entrypoints/receipt.json'),owned_patch_stages=['0074','0075'],demo_receipt_sha256=sha(P/'demos/receipt.json'),inspector_sha256=sha(__file__),native_runtime_executed=False,public_distribution=False,independent_authenticity_verified=False,full_macos_qualified=False)
with(W/'analysis.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in['status','source_commit','archive','inventory']}|dict(compiled_demos=len(compiled),native_runtime_executed=False)))
