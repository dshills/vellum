"""Save reviewed private-SDK consumption evidence, excluding the SDK and binaries."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-current-sdk-238b3b6');D=T/'docs/reports/macos-current-sdk'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']and r['report_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'reviewed results/report producer')
a=read(W/'analysis.json');need(a['archive']['manifest_files']==7411 and len(a['demos'])==13 and a['source_commit']=='238b3b619e5ef274c218cb62d0b348e44e3fcaf8','exact result scope');need(read(P/'checks-complete.json')['all_tools_terminal']is True,'terminal checks')
members={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'artifact symlink')
  if p.is_file()and'__pycache__'not in p.parts:members[label+p.relative_to(root).as_posix()]=p
add('controller/',W)
for name in['source.json','checks-complete.json']:members['checks/'+name]=P/name
for folder in['package','relocate']:add('checks/'+folder+'/',P/folder)
for name in['manifest.json','receipt.json']:members['checks/demos/'+name]=P/'demos'/name
for name in['drawing','editor','grid','hello','imaging','loadedgrid','loadedtree','placement','replay']:add('checks/demos/'+name+'/',P/'demos'/name)
members['checks/entrypoints/receipt.json']=P/'entrypoints/receipt.json'
for name in['viewport3d','workspace','workspace-smoke','managed-replay','workspace-replay']:add('checks/entrypoints/'+name+'/',P/'entrypoints'/name)
sdk=Path(read(P/'entrypoints/receipt.json')['sdk_root'])
for name in['SDK_MANIFEST.json','THIRD_PARTY_INVENTORY.json','PRIVATE_BUILD.txt']:members['archive-records/'+name]=sdk/name
for name in['release-sdk.py','check-sdk.py','child_process.py','sdk_environment.py','artifact_io.py']:members['source/scripts/'+name]=T/'scripts'/name
for name in['examples/replay/README.md','release/version.json','LICENSE','drivers/cogent/native/dependencies.json']:members['source/'+name]=T/name
excluded={'private-sdk':dict(path=str(P/'sdk.tar.gz'),bytes=(P/'sdk.tar.gz').stat().st_size,sha256=sha(P/'sdk.tar.gz'),reason='Private SDK artifact remains outside Git; manifest and digest retained. Not published.'),'relocated-source-tree':dict(path=str(sdk),manifest_files=7411,manifest_sha256=sha(sdk/'SDK_MANIFEST.json'),reason='Verified extracted SDK source remains outside Git; exact complete manifest is included.')}
for name,info in a['demos'].items():excluded['compiled/'+name]={**info['binary'],'reason':'Compilation evidence only; executable excluded.'}
library=read(P/'entrypoints/receipt.json')['root_library'];excluded['root-replay-library']={**library,'reason':'Original library/executable classification failure preserved; compiled archive excluded.'}
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<250 and expanded<16<<20,'evidence bounds');D.mkdir()
manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},excluded_artifacts=excluded,count=len(members),expanded_bytes=expanded);(D/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with(D/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,p in members.items():
    data=p.read_bytes();need(len(data)==manifest['files'][n]['bytes']and hashlib.sha256(data).hexdigest()==manifest['files'][n]['sha256'],'archive drift');entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive verification')
result=dict(status='REVIEWED_CURRENT_PRIVATE_SDK_CONSUMPTION',analysis=a,review_sha256=sha(W/'result-review.json'),provider_calls_this_phase=0,provider_basis='No implementation changes; current shipping stage75 was reviewed internally and once with Prism Anthropic Claude Sonnet5.5 in source29ec8c9.',evidence=dict(file='evidence.tar.gz',sha256=sha(D/'evidence.tar.gz'),bytes=(D/'evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded,manifest_sha256=sha(D/'evidence.manifest.json')),native_runtime_executed=False,public_distribution=False,full_macos_qualified=False);(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for name,item in a['demos'].items():
 target='examples/'+item['example']+(''if item['target']=='.'else'/'+item['target'][2:]);rows.append(f"| {name} | `{target}` | `{item['tags']}` |"if item['tags']else f"| {name} | `{target}` | default |")
(D/'README.md').write_text('''# Current private SDK consumption — macOS

The clean framework at `238b3b619e5ef274c218cb62d0b348e44e3fcaf8` packages as
a private development SDK. A generated independent consumer passes race tests,
vet and native compilation after extraction into a path containing spaces. The
public API contract module also passes race tests and vet. Nine demo applications
and four documented replay/workspace commands compile from the same extracted
SDK. Native consumer and demo executables were compiled without launching them.

## Archive and dependency identity

The private `v0.1.0-alpha.2` archive has SHA256
`94dd1a1de78085ae705d17e587128b83bff0bbf442fb9f1f12ed348d5ba56f32`
and contains 7,411 hashed files plus its manifest. All 7,310 selected source files
match the clean tracked/prepared inputs; 101 generated marker, inventory and
notice files match their recorded associations. The recorded before/after snapshots of both source checkouts contain identical
4,654 tracked and 6,246 prepared files.

Both owned stages 0074/0075, their checksummed patch files and the current
sceneplan encoder/test outputs are present. Local replacements for Vellum, its
Cogent driver, CogentCore and typesetting resolve to the exact directories inside
the extracted SDK. External Go modules use the existing cache and pass Go module
verification. This is a relocatable development SDK with external dependencies;
it is not an offline runtime installer. The supplied digest establishes integrity
against this local producer, rather than independent artifact authenticity.

## Compiled entrypoints

| Entry | SDK path | Build tags |
|---|---|---|
'''+ '\n'.join(rows)+'''

The first demo runner incorrectly assumed that every example module root was an
executable. Eight applications compiled successfully before its executable-
metadata check refused the replay root, which correctly builds as a Go library
archive. That runner result remains incomplete. A separate run compiled the
remaining viewport application and the four documented replay commands with
their actual build tags. The earlier eight successful builds were revalidated;
their raw logs, the library result and the failed metadata check are preserved.
No framework source fix or reclassification of that failed check was needed.

## Scope and review

Packaging and relocation used bounded owned child commands, read-only Go module
mode, `GOWORK=off`, local toolchain/cache settings and `GOMAXPROCS=2`. The full
source, preparation, SDK contents and archive identities stayed unchanged.
Metadata records the executable import paths; every compiled binary is hashed.
This provides compilation evidence for placement, drawing, imaging, the 3D view,
data views, editor, workspaces and replay consumers through the packaged APIs.
It does not verify their live Cocoa behavior, GPU execution, physical interaction
or performance. Existing compiler deprecation/linker warnings remain in raw logs.

Internal result and documentation reviews cover this evidence-only checkpoint.
No additional Prism call is made: shipping stage 0075 already received one
Anthropic Claude Sonnet 5.5 review in `29ec8c9`. Public namespace and Vellum's MIT
choice remain recorded, while the 89-module declaration inventory still marks
distribution audit pending. Native component/rights closure, public release,
signing/notarization, native/GPU memory and full Mac qualification remain open.

The private SDK, extracted source and compiled outputs remain outside Git. This
report retains their identities plus all raw command output, SDK manifest,
inventory, controlled environment and producer source. Nothing was published.
See [structured results](result.json), [evidence manifest](evidence.manifest.json),
[raw evidence](evidence.tar.gz) and the [SDK contract](../../../specs/release.md).
''')
p=T/'docs/reports/README.md';p.write_text(p.read_text()+'\n- [Current private SDK consumption](macos-current-sdk/README.md): 7,411 hashed files, relocated consumer/API checks and 13 compiled entrypoints; no native execution or public distribution.\n')
p=T/'docs/implementation.md';p.write_text(p.read_text()+'''\n## Current private SDK consumption\n\n[Current SDK evidence](reports/macos-current-sdk/README.md) binds clean source\n238b3b6 to a private archive with 7,411 hashed files, including owned stages\n0074/0075. A relocated generated consumer and public API contracts pass their\nrace/vet/build scope. Nine demo applications and four replay/workspace commands\ncompile with replacements confined to the extracted SDK. No application runtime\nor public distribution is qualified by these checks.\n''')
p=T/'specs/macos-completion.md';text=p.read_text();needle='## Latest unattended evidence\n';need(needle in text,'completion insertion');text=text.replace(needle,needle+'''\nThe [current private SDK checkpoint](../docs/reports/macos-current-sdk/README.md)\nverifies 7,411 hashed files from clean `238b3b6`, including owned stages 0074/0075.\nThe relocated generated consumer passes race/vet/build checks, and the public API\ncontract module passes race/vet. Nine demo applications and four replay/workspace\ncommands compile from that SDK using only its local replacements. These are\nconsumption/compilation checks, with no native application execution or public\ndistribution. Native packaging/release gates and full Mac qualification remain open.\n''',1);p.write_text(text)
print(json.dumps(dict(report=str(D),members=len(members),expanded_bytes=expanded,archive_bytes=(D/'evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'evidence.tar.gz'))))
