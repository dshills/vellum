"""Compile every shipped native demo from the digest-verified relocated SDK."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
check=module('current_sdk_source_guard',W/'check.py');T,C,P=check.T,check.C,check.P;sha,read,need=check.sha,check.read,check.need
sdkcheck=module('current_sdk_archive_reader',T/'scripts/check-sdk.py')
from child_process import run_child
from sdk_environment import child_environment
NAMES=['drawing','editor','grid','hello','imaging','loadedgrid','loadedtree','placement','replay','viewport3d']
def snapshot(sdk,verified):
 files=verified['manifest']['files'];actual={p.relative_to(sdk).as_posix()for p in sdk.rglob('*')if p.is_file()};need(actual==set(files)|{'SDK_MANIFEST.json'},'exact relocated leaf set')
 need(all(not(sdk/n).is_symlink()and sha(sdk/n)==h for n,h in files.items()),'relocated SDK hashes')
 return dict(files=len(files),manifest_sha256=sha(sdk/'SDK_MANIFEST.json'))
def main():
 prior=read(P/'relocate/receipt.json');need(prior['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK','relocation prerequisite');source=read(P/'source.json');need(check.identity(T)==check.identity(C)==source,'clean source parity')
 archive=P/'sdk.tar.gz';digest=read(P/'package/receipt.json')['archive']['sha256'];need(sha(archive)==digest,'trusted private archive');out=P/'demos';out.mkdir(mode=0o700)
 verified=sdkcheck.verify_archive(archive,digest);base=out/'relocated SDK demos';base.mkdir();sdk=sdkcheck.extract_verified(archive,base/'extracted SDK',verified);before=snapshot(sdk,verified)
 modules=sorted(p.parent.name for p in(sdk/'examples').glob('*/go.mod'));need(modules==sorted(NAMES+['sdk-contract']),'exact shipped example modules');(out/'manifest.json').write_text(json.dumps(verified['manifest'],indent=2)+'\n')
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2','PYTHONDONTWRITEBYTECODE':'1'}
 d=dict(result='INCOMPLETE',error=None,producer_sha256=sha(__file__),source_sha256=sha(P/'source.json'),archive_sha256=digest,sdk_root=str(sdk),snapshot=before,examples={},native_runtime_executed=False,public_distribution=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());start=time.monotonic()
 try:
  binaries=out/'build outputs';binaries.mkdir()
  for name in NAMES:
   job=out/name;job.mkdir();cwd=sdk/'examples'/name;binary=binaries/name;commands=[('modules',['go','list','-m','-json','all']),('verify',['go','mod','verify']),('build',['go','build','-p=1','-trimpath','-o',str(binary),'.']),('metadata',['go','version','-m',str(binary)])];record=dict(commands=[],complete=False);d['examples'][name]=record
   for label,argv in commands:
    need(sha(archive)==digest,'archive stable before command');part=job/label;part.mkdir();t=time.monotonic()
    with(part/'stdout').open('xb')as stdout,(part/'stderr').open('xb')as stderr:r=run_child(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=180,log_limit_bytes=8<<20)
    item=dict(command=label,argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-t,logs={n:dict(bytes=(part/n).stat().st_size,sha256=sha(part/n))for n in['stdout','stderr']});record['commands'].append(item);need(r.returncode==0,'demo command '+name+'/'+label)
    if label=='modules':record['origins']=sdkcheck.check_origin(sdkcheck.decode_objects((part/'stdout').read_text()),sdk,verified['manifest']['release']['module'])
    if label=='metadata':
     text=(part/'stdout').read_text();need('CGO_ENABLED=1'in text and '\tpath\tgithub.com/dshills/vellum/examples/'+name in text,'native demo metadata '+name)
   need(snapshot(sdk,verified)==before,'demo source snapshot unchanged');record.update(complete=True,binary=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary)))
   print(json.dumps(dict(example=name,result='COMPILED_RELOCATED_NATIVE_DEMO',native_runtime_executed=False)),flush=True)
  d.update(result='ALL_SHIPPED_NATIVE_DEMOS_COMPILE_FROM_PRIVATE_SDK',count=len(NAMES))
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  errors=[]
  for label,fn in[('source_stable',lambda:check.identity(T)==source),('canonical_stable',lambda:check.identity(C)==source),('sdk_stable',lambda:snapshot(sdk,verified)==before),('archive_stable',lambda:sha(archive)==digest)]:
   try:d[label]=fn()
   except BaseException as e:d[label]=False;errors.append(dict(observation=label,type=type(e).__name__,message=str(e)))
  if errors or any(d[k]is not True for k in['source_stable','canonical_stable','sdk_stable','archive_stable']):d['result']='FAILED_DEMO_SOURCE_OBSERVATION'
  d.update(observation_errors=errors,seconds=time.monotonic()-start)
  with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:d[k]for k in['result','error','seconds','source_stable','canonical_stable','sdk_stable','archive_stable']}),flush=True)
  need(d['result']=='ALL_SHIPPED_NATIVE_DEMOS_COMPILE_FROM_PRIVATE_SDK','SDK demo compilation incomplete')
if __name__=='__main__':main()
