"""Finish demo compilation using the replay module's actual command entrypoints."""
from pathlib import Path
import datetime,importlib.util,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
c=module('sdk_entry_source_guard',W/'check.py');demo=module('sdk_original_demo_helpers',W/'demos.py');P,T,C=c.P,c.T,c.C;sha,read,need=c.sha,c.read,c.need
from child_process import run_child
from sdk_environment import child_environment
TARGETS=[('viewport3d','viewport3d','.',None),('workspace','replay','./cmd/workspace',None),('workspace-smoke','replay','./cmd/workspace-smoke','vellum_native_checks'),('managed-replay','replay','./cmd/native','offscreen'),('workspace-replay','replay','./cmd/workspace-replay','offscreen')]
def main():
 source=read(P/'source.json');need(c.identity(T)==c.identity(C)==source,'clean current source');prior=read(P/'demos/receipt.json');need(prior['result']=='INCOMPLETE'and prior['error']==dict(type='ValueError',message='demo command replay/metadata')and all(prior[k]is True for k in['source_stable','canonical_stable','sdk_stable','archive_stable']),'preserved first runner failure')
 need([n for n,v in prior['examples'].items()if v['complete']]==demo.NAMES[:8],'eight completed apps');partial=prior['examples']['replay'];need(partial['complete']is False and partial['commands'][-1]['command']=='metadata'and partial['commands'][-1]['exit_code']==1 and partial['commands'][-2]['exit_code']==0,'root library build facts')
 library=P/'demos/build outputs/replay'
 with library.open('rb')as f:need(f.read(8)==b'!<arch>\n','actual root Go archive, not executable')
 archive=P/'sdk.tar.gz';digest=read(P/'package/receipt.json')['archive']['sha256'];verified=demo.sdkcheck.verify_archive(archive,digest);sdk=Path(prior['sdk_root']);before=demo.snapshot(sdk,verified)
 out=P/'entrypoints';out.mkdir(mode=0o700);binaries=out/'build outputs';binaries.mkdir();env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2','PYTHONDONTWRITEBYTECODE':'1'}
 d=dict(result='INCOMPLETE',error=None,producer_sha256=sha(__file__),original_demo_receipt_sha256=sha(P/'demos/receipt.json'),source_sha256=sha(P/'source.json'),archive_sha256=digest,sdk_root=str(sdk),snapshot=before,root_library=dict(path=str(library),sha256=sha(library),bytes=library.stat().st_size,executable=False),entrypoints={},native_runtime_executed=False,public_distribution=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());start=time.monotonic()
 try:
  for name,example,target,tags in TARGETS:
   job=out/name;job.mkdir();cwd=sdk/'examples'/example;binary=binaries/name;opts=['-tags='+tags]if tags else[];expected_path='github.com/dshills/vellum/examples/'+example+(target[1:]if target!='.'else'');commands=[('modules',['go','list','-m','-json','all']),('package',['go','list','-json',*opts,target]),('verify',['go','mod','verify']),('build',['go','build','-p=1','-trimpath',*opts,'-o',str(binary),target]),('metadata',['go','version','-m',str(binary)])];record=dict(example=example,target=target,tags=tags,expected_import_path=expected_path,commands=[],complete=False);d['entrypoints'][name]=record
   for label,argv in commands:
    need(sha(archive)==digest,'archive before command');part=job/label;part.mkdir();t=time.monotonic()
    with(part/'stdout').open('xb')as stdout,(part/'stderr').open('xb')as stderr:r=run_child(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=180,log_limit_bytes=8<<20)
    record['commands'].append(dict(command=label,argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-t,logs={n:dict(bytes=(part/n).stat().st_size,sha256=sha(part/n))for n in['stdout','stderr']}));need(r.returncode==0,'command '+name+'/'+label)
    if label=='modules':record['origins']=demo.sdkcheck.check_origin(demo.sdkcheck.decode_objects((part/'stdout').read_text()),sdk,verified['manifest']['release']['module'])
    if label=='package':
     info=read(part/'stdout');need(info['Name']=='main'and info['ImportPath']==expected_path and Path(info['Dir']).resolve().is_relative_to(sdk.resolve()),'documented main entrypoint '+name);record['package']=dict(name=info['Name'],import_path=info['ImportPath'],directory=info['Dir'])
    if label=='metadata':need('\tpath\t'+expected_path+'\n'in(part/'stdout').read_text(),'matching executable import path')
   need(demo.snapshot(sdk,verified)==before,'SDK snapshot unchanged');record.update(complete=True,binary=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary)));print(json.dumps(dict(entrypoint=name,result='COMPILED_RELOCATED_COMMAND',tags=tags,native_runtime_executed=False)),flush=True)
  d.update(result='ALL_REMAINING_DOCUMENTED_SDK_ENTRYPOINTS_COMPILE',count=len(TARGETS))
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  errors=[]
  for label,fn in[('source_stable',lambda:c.identity(T)==source),('canonical_stable',lambda:c.identity(C)==source),('sdk_stable',lambda:demo.snapshot(sdk,verified)==before),('archive_stable',lambda:sha(archive)==digest)]:
   try:d[label]=fn()
   except BaseException as e:d[label]=False;errors.append(dict(observation=label,type=type(e).__name__,message=str(e)))
  if errors or any(d[k]is not True for k in['source_stable','canonical_stable','sdk_stable','archive_stable']):d['result']='FAILED_COMMAND_SOURCE_OBSERVATION'
  d.update(observation_errors=errors,seconds=time.monotonic()-start)
  with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:d[k]for k in['result','error','seconds','source_stable','canonical_stable','sdk_stable','archive_stable']}),flush=True);need(d['result']=='ALL_REMAINING_DOCUMENTED_SDK_ENTRYPOINTS_COMPILE','command compilation incomplete')
if __name__=='__main__':main()
