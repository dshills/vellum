"""Stage only the seven completed SDK evidence/documentation files."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
FILES=['docs/reports/macos-current-sdk/'+n for n in['README.md','result.json','evidence.manifest.json','evidence.tar.gz']]+['docs/reports/README.md','docs/implementation.md','specs/macos-completion.md']
BASE='238b3b619e5ef274c218cb62d0b348e44e3fcaf8'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'binding.json').exists()and not(W/'staged.diff').exists()
assert git(T,'rev-parse','HEAD').decode().strip()==git(C,'rev-parse','HEAD').decode().strip()==BASE
assert not git(C,'status','--porcelain','-z')and not git(T,'diff','--cached','--name-only')
changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(FILES)
sources={n:sha(T/n)for n in FILES};git(T,'add','--',*FILES)
assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(FILES)and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
assert all(sha(T/n)==h and hashlib.sha256(git(T,'show',':'+n)).hexdigest()==h for n,h in sources.items())
diff=git(T,'diff','--cached','--binary');(W/'staged.diff').write_bytes(diff)
d=dict(base_commit=BASE,sources=sources,files=len(FILES),staged_diff_sha256=hashlib.sha256(diff).hexdigest(),staged_diff_bytes=len(diff),producer_sha256=sha(__file__))
with(W/'binding.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(files=len(FILES),diff_bytes=len(diff),diff_sha256=d['staged_diff_sha256'])))
