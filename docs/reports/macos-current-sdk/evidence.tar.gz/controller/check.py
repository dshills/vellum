"""Package and check the clean current private SDK without native execution."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-current-sdk-238b3b6');COMMIT='238b3b619e5ef274c218cb62d0b348e44e3fcaf8'
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
def identity(root):
 need(git(root,'rev-parse','HEAD').decode().strip()==COMMIT and not git(root,'status','--porcelain','-z'),'clean exact source')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];files={};prepared={}
 for n in names:
  p=root/n;need(p.is_file()and not p.is_symlink(),'tracked regular file');files[n]=sha(p)
 for module in['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/module).rglob('*'):
   need(not p.is_symlink(),'prepared symlink')
   if p.is_file():prepared[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p)
 need(len(files)==4654 and len(prepared)==6246,'source/prepared count')
 return dict(commit=COMMIT,files=files,prepared=prepared)
def main():
 need(sys.argv[1:]in[['package'],['relocate']],'fixed SDK check');case=sys.argv[1];source=identity(T);need(identity(C)==source,'canonical parity')
 if case=='package':
  P.mkdir(mode=0o700);(P/'source.json').write_text(json.dumps(source,indent=2)+'\n')
 else:
  prior=read(P/'package/receipt.json');need(prior['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK'and prior['source_stable']and prior['canonical_stable']and read(P/'source.json')==source,'packaging prerequisite')
 out=P/case;out.mkdir(mode=0o700);archive=P/'sdk.tar.gz'
 argv=[sys.executable,str(T/'scripts/release-sdk.py'),'--output',str(archive)]if case=='package'else[sys.executable,str(T/'scripts/check-sdk.py'),'--archive',str(archive),'--sha256',sha(archive)]
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2','PYTHONDONTWRITEBYTECODE':'1'}
 d=dict(case=case,argv=argv,cwd=str(T),source_sha256=sha(P/'source.json'),producer_sha256=sha(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_runtime_executed=False,public_distribution=False,error=None,exit_code=None);start=time.monotonic()
 try:
  with(out/'stdout').open('xb')as stdout,(out/'stderr').open('xb')as stderr:d['exit_code']=run_child(argv,cwd=T,env=env,stdout=stdout,stderr=stderr,timeout=660,log_limit_bytes=8<<20).returncode
 except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 for name,root in[('source',T),('canonical',C)]:
  try:d[name+'_stable']=identity(root)==source
  except BaseException as e:d[name+'_stable']=False;d[name+'_observation_error']=dict(type=type(e).__name__,message=str(e))
 d.update(seconds=time.monotonic()-start,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n))for n in['stdout','stderr']})
 if archive.exists():d['archive']=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive))
 if d['exit_code']==0 and d['error']is None:
  try:
   value=json.loads((out/'stdout').read_bytes());d['validation']=value
   if case=='package':need(value['private_build']is True and value['sha256']==sha(archive),'private package result')
   else:need(value['event']=='vellum.sdk.relocated'and value['digest_verified_against_expected']is True and value['archive_sha256']==sha(archive)and value['source']['commit']==COMMIT and value['source']['clean']is True and value['path_contains_spaces']is True and value['native_runtime']=='not executed'and value['independent_authenticity_verified']is False,'private relocated result')
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
 d['result']='PASS_CURRENT_PRIVATE_SDK_CHECK'if d['exit_code']==0 and d['error']is None and d.get('source_stable')and d.get('canonical_stable')else'FAILED_CURRENT_PRIVATE_SDK_CHECK'
 with(out/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:d[k]for k in['case','result','exit_code','error','seconds','source_stable','canonical_stable']}),flush=True)
 need(d['result']=='PASS_CURRENT_PRIVATE_SDK_CHECK','SDK check failed')
if __name__=='__main__':main()
