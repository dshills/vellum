"""Capture current checkout and existing SDK provenance; no native launch."""
from pathlib import Path
import json, sys
sys.dont_write_bytecode=True
from run import W,T,C,P,HEAD,SDK_SOURCE,read,sha,need,identity,sdk_valid
P.mkdir(mode=0o700)
base=Path('/private/tmp/vellum-current-sdk-238b3b6'); analysis=read(W.parent/'macos-current-sdk-238b3b6/analysis.json'); demos=read(base/'demos/receipt.json')
need(analysis['source_commit']==SDK_SOURCE and demos['examples']['hello']['complete'] is True,'SDK build origin')
provenance=dict(source_commit=SDK_SOURCE,current_checkout_commit=HEAD,sdk_root=demos['sdk_root'],binary=analysis['demos']['hello']['binary'],archive=dict(path=str(base/'sdk.tar.gz'),sha256=analysis['archive']['sha256']),manifest_sha256=sha(Path(demos['sdk_root'])/'SDK_MANIFEST.json'),analysis_sha256=sha(W.parent/'macos-current-sdk-238b3b6/analysis.json'),demo_receipt_sha256=sha(base/'demos/receipt.json'))
need(sha(provenance['binary']['path'])==provenance['binary']['sha256'] and sha(base/'sdk.tar.gz')==provenance['archive']['sha256'],'compiled binary/archive integrity')
sdk_valid(provenance); source=identity(T);need(identity(C)==source,'source parity')
(P/'source.json').write_text(json.dumps(source,indent=2)+'\n');(W/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps(dict(prepared=True,native_runtime_executed=False,source_commit=SDK_SOURCE,current_checkout_commit=HEAD,binary=provenance['binary'])))
