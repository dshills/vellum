"""Append scoped native evidence to the SDK report; never package SDK binaries."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;N=W.parent/'macos-sdk-native-238b3b6';P=Path('/private/tmp/vellum-sdk-native-238b3b6');T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=T/'docs/reports/macos-current-sdk';S=Path('/private/tmp/vellum-current-sdk-238b3b6')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
r=read(W/'result-review.json');need(r['result_accepted']is True and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items()),'reviewed result')
d=read(P/'receipt.json');need(d['result']=='PASS_SCOPED_PRIVATE_SDK_NATIVE_SMOKE'and d['native_runtime_executed']is True and d['local_stop_present']is True,'native result')
need((P/'stop-live').exists(),'campaign sealed');a=read(N/'provenance.json');v=d['native_record'];members={}
def add(label,root):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'evidence symlink')
  if p.is_file()and'__pycache__'not in p.parts:members[label+p.relative_to(root).as_posix()]=p
add('controller/',N);add('native-check/',P)
members['review/result-review.json']=W/'result-review.json';members['producer/report.py']=Path(__file__)
sdk=Path(a['sdk_root'])
for name in ['SDK_MANIFEST.json','examples/hello/main.go','examples/hello/model.go','examples/hello/go.mod','examples/hello/go.sum']:
 if (sdk/name).exists():members['sdk-source/'+name]=sdk/name
for name in ['receipt.json','manifest.json']:members['sdk-build/'+name]=S/'demos'/name
add('sdk-build/hello/',S/'demos/hello')
for name in ['child_process.py','sdk_environment.py']:members['helpers/'+name]=T/'scripts'/name
members['helpers/live_lease.py']=Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
expanded=sum(p.stat().st_size for p in members.values());need(len(members)<120 and expanded<8<<20,'small evidence bounds')
manifest=dict(files={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in members.items()},count=len(members),expanded_bytes=expanded,excluded_artifacts=dict(sdk_archive=a['archive'],hello_binary=a['binary'],sdk_tree=dict(path=str(sdk),manifest_sha256=a['manifest_sha256'],files=7411)))
with(D/'native-evidence.manifest.json').open('x')as f:f.write(json.dumps(manifest,indent=2)+'\n')
with(D/'native-evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in members.items():
    data=p.read_bytes();need(hashlib.sha256(data).hexdigest()==manifest['files'][name]['sha256'],'archive drift');entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(D/'native-evidence.tar.gz','r:gz')as tar:
 entries=tar.getmembers();need(len(entries)==len(members),'archive member count')
 for e in entries:need(e.isfile()and hashlib.sha256(tar.extractfile(e).read()).hexdigest()==manifest['files'][e.name]['sha256'],'archive hash')
result=dict(status='REVIEWED_SCOPED_PRIVATE_SDK_NATIVE_SMOKE',source_commit=d['source_commit'],current_checkout_commit=d['current_checkout_commit'],provenance=a,receipt=d,result_review_sha256=sha(W/'result-review.json'),evidence=dict(file='native-evidence.tar.gz',sha256=sha(D/'native-evidence.tar.gz'),bytes=(D/'native-evidence.tar.gz').stat().st_size,members=len(members),expanded_bytes=expanded),provider_calls=0,public_distribution=False,full_macos_qualified=False)
with(D/'native-smoke.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
report=D/'README.md';text=report.read_text();old='SDK. Native consumer and demo executables were compiled without launching them.';need(text.count(old)==1,'original report intro')
text=text.replace(old,'SDK. Those checks compiled the native executables without launching them. A\nsubsequent scoped native hello check is recorded below.')
text+='''

## Native public hello follow-up

The already compiled hello executable from that exact relocated SDK opens a
native window, reads back its public GPUCanvas rectangle and exits normally
after a one-second quiet interval. Its single `vellum.native.ready` record
confirms the fixture disabled geometry persistence and completed three further
Snapshot calls. The check uses the example's center-pixel color predicate;
it does not compare the full image or observe physical screen presentation.

'''+f'The reported image is {v["width"]}×{v["height"]} pixels. Raw startup, readback and\nheap values are retained as single-process observations, with no latency or\nmemory-budget qualification. The executable SHA256 is\n`{a["binary"]["sha256"]}`.\n'+'''
Runtime source remains `238b3b6`; `e88941b` is the documentation checkpoint
present in both clean checkouts during this test. All 7,411 SDK file hashes,
the private archive, compiled binary and current tracked/prepared source remain
unchanged. The owned process exits with status zero, both output streams reach
EOF, its group is observed absent, and the local campaign stop marker is sealed.

Internal prelaunch review blocked an initial controller whose error handling
could skip cleanup or lose terminal evidence. The corrected controller passes
six ordinary cases (five launched children), six record-parser refusal checks,
four additional actual-child fault checks and one isolated fake-child check.
Three finalization cases and two stale-output admission refusals pass separately.
The initial blocked controller and its inaccurate original child-count field
are preserved separately. No native application ran under that blocked version.
The accepted controller uses the shared native lease, universal/local stop
markers, a 45-second watchdog, bounded raw logs and independent cleanup attempts.

This is one public example's native startup/readback/shutdown check. It does not
launch the other packaged demos or qualify physical pointer/keyboard input,
accessibility interaction, GPU memory, sustained performance, public distribution
or full Mac completion. No input-source, VoiceOver, clipboard or OS preference
settings are changed. Existing stage 0075 Prism review remains the implementation
review; this test-only follow-up receives internal result/documentation reviews.

See [native result](native-smoke.json), [native evidence manifest](native-evidence.manifest.json)
and [native raw evidence](native-evidence.tar.gz). The earlier consumption report
and its original evidence archive retain their separate scope.
'''
report.write_text(text)
for name,old,new in [
 ('docs/implementation.md','compile with replacements confined to the extracted SDK. No application runtime\nor public distribution is qualified by these checks.','compile with replacements confined to the extracted SDK. A subsequent bounded\nnative run of that SDK hello executable verifies its rectangle center-pixel\nreadback, three further snapshots and owned shutdown. Full demo runtime, physical\ninput, performance/memory and public distribution remain open.'),
 ('specs/macos-completion.md','consumption/compilation checks, with no native application execution or public\ndistribution. Native packaging/release gates and full Mac qualification remain open.','consumption/compilation checks. A subsequent scoped native hello run from that\nSDK verifies its rectangle center-pixel readback, three further snapshots and\nowned shutdown. Runtime source stays `238b3b6`, distinct from the `e88941b`\ndocumentation endpoint present during that test. Other demo runtime, physical\ninput, sustained performance, native/GPU memory, public distribution and full\nMac qualification remain open.')]:
 p=T/name;s=p.read_text();need(s.count(old)==1,'exact documentation paragraph '+name);p.write_text(s.replace(old,new))
print(json.dumps(dict(result='NATIVE_SDK_REPORT_GENERATED',files=6,members=len(members),expanded_bytes=expanded,archive_bytes=(D/'native-evidence.tar.gz').stat().st_size,archive_sha256=sha(D/'native-evidence.tar.gz'))))
