from pathlib import Path
import os,sys,json,hashlib,importlib.util,shlex
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;B=P/'review';B.mkdir(exist_ok=True)
sys.path.insert(0,str(P.parent.parent/'macos-sdk-stage0079-abe67c6-cache-v2/shared'))
s=importlib.util.spec_from_file_location('owned',P.parent.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);sys.modules[s.name]=g;s.loader.exec_module(g)
key=os.environ.get('ANTHROPIC_API_KEY');assert key,'existing Anthropic credential missing'
original=g.child_environment
def env(*args,**kwargs):
 e=original(*args,**kwargs)
 if args and args[0] is True:e['ANTHROPIC_API_KEY']=key
 return e
g.child_environment=env
source=P/'review-input.txt';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in [source,P/'main.m',P/'validate.py',P/'validate_test.py',P/'plan.txt']}
(B/'rules.json').write_text(json.dumps({'rules':[{'id':'scope','text':'Private macOS native Metal reference diagnostic;not shipping/framework qualification. NativeARC code has raw nextDrawable mode(receipt before acquisition) and direct CAMetalDisplayLink provided drawable mode(receipt at callback after acquisition);boundaries explicitlydifferent. All startup records preserved as phase0,zero feedback allowed only beforecohort;require at least one positive startup before firstwarmup,then128warmup+120measured withstrictpositive ordered feedback,no dropped records. Link records actualcallback/targetTimestamp/targetPresentationTimestamp plus shown.presentedTime. Fixed512records,rawstartup64/3sec,groupdeadlines,externalowned15secwatchdog. Callbackdataonlyread after dispatch_groupdrain;timeout process exits3without pretending cleanup. group strongARCowner. No OSfloor/releaseclaim,no thresholdchange. Nine synthetic classifier controls pass incllost/collapsed/earlystart/missingtarget/close/NaN. Review native lifetime/threading,correctreadinessandtimestamp/population/no falseclaim. This addresses identifiedmissing readiness/target evidence after all frameworkinterceptcandidatesrejected.'}]}))
argv=['/Users/dshills/Development/Go/bin/prism','review','snippet','--path','ready-reference.txt','--lang','text','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--chunk-bytes','240000','--max-diff-bytes','240000','--rules',str(B/'rules.json'),'--format','json','--out',str(B/'prism.json')]
r=g.execute(['/bin/sh','-c','cat '+shlex.quote(str(source))+' | '+shlex.join(argv)],'/private/tmp/vellum-macos-native-results-97aee13',B/'run',lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=180,limit=2<<20)
(B/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exit_code':r['exit_code'],'error':r['error'],'seconds':r['seconds']}))
