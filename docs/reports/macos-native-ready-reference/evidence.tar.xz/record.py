from pathlib import Path
import json,hashlib,tarfile,io,importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-native-ready-reference');R.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('reference_metrics',P/'validate.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
result=json.loads((P/'result.json').read_text());start=json.loads((P/'started.json').read_text());plan=json.loads((P/'bound-plan.json').read_text());summary={'outcome':'TWO_VALID_NATIVE_REFERENCE_COHORTS_NO_FRAMEWORK_FIX','started_utc':start['started_utc'],'finished_utc':result['finished_utc'],'source_and_binary_pins':[{'artifact_path':Path(path).relative_to(P.parent.parent).as_posix(),'sha256':digest,'evidence_member':Path(path).relative_to(P).as_posix() if Path(path).is_relative_to(P) and Path(path).name!='native' else None,'availability':'archived' if Path(path).is_relative_to(P) and Path(path).name!='native' else ('excluded executable' if Path(path).name=='native' else 'external reused helper; hash only, not a standalone rebuild bundle')} for path,digest in plan['pins'].items()],'modes':{},'native_commands':len(result['cases']),'probe_commands':0,'all_groups_retired':True,'framework_release_qualified':False,'native_OS_floor_proven':False,'policy_changed':False,'foreground_qualified':False,'receipt_boundaries_differ':True,'reference_allows_next_drawable_timeout':True}
for case in result['cases']:
 mode=case['mode'];r=case['native'];summary['all_groups_retired'] &=r['owned']['terminal'] and r['owned']['group_absent'];d={'outcome':case['outcome'],'exit_code':r['exit_code'],'seconds':r['seconds'],'owned_retired':r['owned']['terminal'] and r['owned']['group_absent'],'geometry_unchanged':case['geometry_before']==case['geometry_after'],'configuration_bytes_unchanged':all(case['configuration_before'][k]['logs']['stdout']['sha256']==case['configuration_after'][k]['logs']['stdout']['sha256'] for k in case['configuration_before']),'metrics':json.loads((P/mode/'validation.json').read_text())}
 for phase in ['configuration_before','configuration_after']:
  for cmd in case[phase].values():summary['probe_commands']+=1;summary['all_groups_retired'] &=cmd['owned']['terminal'] and cmd['owned']['group_absent']
 if mode=='link':
  rows=[json.loads(line) for line in (P/mode/'native/stdout').read_text().splitlines()];rows=[r for r in rows if r.get('phase')==2]
  d['derived_metrics']={'callback_to_render_deadline_ms':v.v.stats([(r['target']-r['receipt'])*1000 for r in rows]),'render_deadline_to_presentation_target_ms':v.v.stats([(r['presentation_target']-r['target'])*1000 for r in rows])}
 summary['modes'][mode]=d
(R/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={p.relative_to(P).as_posix():p for p in P.rglob('*') if p.is_file() and p.name!='native' and 'tmp' not in p.relative_to(P).parts};index={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(files.items())}
with tarfile.open(R/'evidence.tar.xz','w:xz') as tf:
 for n,p in sorted(files.items()):
  b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;i.mode=0o644;tf.addfile(i,io.BytesIO(b))
(R/'evidence-index.json').write_text(json.dumps({'files':index,'archive':{'bytes':(R/'evidence.tar.xz').stat().st_size,'sha256':sha(R/'evidence.tar.xz')},'excluded':['executable','full SDK/prepared sources','historical archives']},indent=2)+'\n');print(json.dumps({'files':len(files),'archive_bytes':(R/'evidence.tar.xz').stat().st_size,'native':summary['native_commands'],'probes':summary['probe_commands'],'retired':summary['all_groups_retired']}))
