import unittest,copy
from validate import validate
class ReferenceControls(unittest.TestCase):
 def data(self,mode='raw'):
  setup=[{'phase':0,'index':0,'receipt':.5,'acquired':.51 if mode=='raw' else 0,'target':0 if mode=='raw' else .52,'presentation_target':0 if mode=='raw' else .53,'shown':0},{'phase':0,'index':1,'receipt':.6,'acquired':.61 if mode=='raw' else 0,'target':0 if mode=='raw' else .62,'presentation_target':0 if mode=='raw' else .63,'shown':.65}]
  rows=setup
  for i in range(248):
   receipt=1+i/60;rows.append({'phase':1 if i<128 else 2,'index':i+2,'receipt':receipt,'acquired':receipt+.001 if mode=='raw' else 0,'target':0 if mode=='raw' else receipt+.01,'presentation_target':0 if mode=='raw' else receipt+.05,'shown':receipt+.05})
  return [{'event':'config','drawables':2,'vsync':True,'transactions':False,'size':[1519,1266],'scale':1},{'event':'reference','mode':mode,'receipt_boundary':'before nextDrawable' if mode=='raw' else 'provided-drawable callback;acquisition precedes receipt','warmup':128,'samples':120,'records':250}]+rows+[{'closed':True}]
 def test_valid_preserves_setup_failure_and_refuses_release_claim(self):
  d=validate(self.data(),'raw');self.assertEqual(d['setup_zero_indices'],[0]);self.assertEqual(d['measured_count'],120);self.assertFalse(d['framework_release_qualified']);self.assertGreater(d['measured_receipt_to_shown_ms']['p95'],33.3)
 def test_link_targets_separate_receipt_boundary(self):
  d=validate(self.data('provided-link'),'provided-link');self.assertEqual(d['callback_to_target_ms']['count'],120);self.assertFalse(d['native_OS_floor_proven'])
 def test_missing_measured_feedback(self):
  d=self.data();d[-2]['shown']=0
  with self.assertRaises(ValueError):validate(d,'raw')
 def test_collapsed_measured_feedback(self):
  d=self.data();d[-2]['shown']=d[-3]['shown']
  with self.assertRaises(ValueError):validate(d,'raw')
 def test_readiness_after_first_cohort(self):
  d=self.data();d[3]['shown']=20
  with self.assertRaises(ValueError):validate(d,'raw')
 def test_missing_warmup(self):
  d=self.data();d[5]['phase']=2
  with self.assertRaises(ValueError):validate(d,'raw')
 def test_missing_native_target(self):
  d=self.data('provided-link');d[-2]['target']=0
  with self.assertRaises(ValueError):validate(d,'provided-link')
 def test_closed_missing(self):
  d=self.data();d.pop()
  with self.assertRaises(ValueError):validate(d,'raw')
 def test_nonfinite_timestamp(self):
  d=self.data();d[-2]['shown']=float('nan')
  with self.assertRaises(ValueError):validate(d,'raw')
if __name__=='__main__':unittest.main()
