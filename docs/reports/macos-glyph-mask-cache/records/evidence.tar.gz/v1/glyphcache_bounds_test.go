// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"bytes"
	"io/fs"
	"sync"
	"testing"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/styles/units"
	"cogentcore.org/core/text/fonts"
	"cogentcore.org/core/text/rich"
	"cogentcore.org/core/text/shaped/shapers/shapedgt"
	"cogentcore.org/core/text/text"
	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/font/opentype"
	"github.com/go-text/typesetting/shaping"
)

func maskFixture(side int, id font.GID) (shaping.Glyph, font.GlyphOutline) {
	g := shaping.Glyph{GlyphID: id, Width: math32.ToFixed(float32(side)), Height: -math32.ToFixed(float32(side)), YBearing: math32.ToFixed(float32(side))}
	points := [][2]float32{{0, 0}, {float32(side), 0}, {float32(side), float32(side)}, {0, float32(side)}, {0, 0}}
	outline := font.GlyphOutline{}
	for i, point := range points {
		op := opentype.SegmentOpLineTo
		if i == 0 {
			op = opentype.SegmentOpMoveTo
		}
		outline.Segments = append(outline.Segments, font.Segment{Op: op, Args: [3]font.SegmentPoint{{X: point[0], Y: point[1]}}})
	}
	return g, outline
}

func maskBounds(t *testing.T, gc *glyphCache) {
	t.Helper()
	gc.Lock()
	defer gc.Unlock()
	if len(gc.faces) > 32 || len(gc.glyphs) != len(gc.faces) || gc.bytes < 0 || gc.bytes > 8<<20 {
		t.Fatalf("retained limits: faces=%d keys=%d bytes=%d", len(gc.faces), len(gc.glyphs), gc.bytes)
	}
	seen := map[*font.Face]bool{}
	total := 0
	for _, face := range gc.faces {
		if seen[face] || len(gc.glyphs[face]) == 0 {
			t.Fatal("FIFO and face map diverged")
		}
		seen[face] = true
		for _, mask := range gc.glyphs[face] {
			total += len(mask.Pix)
		}
	}
	if total != gc.bytes {
		t.Fatalf("charged=%d actual mask data=%d", gc.bytes, total)
	}
}

func TestVellumGlyphMaskFaceFIFOAndCallerOwnership(t *testing.T) {
	var gc glyphCache
	gc.init()
	faces := make([]*font.Face, 33)
	g, outline := maskFixture(20, 7)
	for i := range faces {
		faces[i] = &font.Face{}
	}
	held, placement := gc.Glyph(faces[0], &g, outline, 1, math32.Vec2(20.25, 30.5))
	before := bytes.Clone(held.Pix)
	if held.AlphaAt(10, 10).A == 0 {
		t.Fatal("empty geometry oracle")
	}
	for i := 1; i < 32; i++ {
		gc.Glyph(faces[i], &g, outline, 1, math32.Vector2{})
	}
	backing := gc.faces[:cap(gc.faces)]
	hit, hitPlacement := gc.Glyph(faces[0], &g, outline, 1, math32.Vec2(20.25, 30.5))
	if hit != held || hitPlacement != placement {
		t.Fatal("warm hit lost caller mask or placement")
	}
	gc.Glyph(faces[32], &g, outline, 1, math32.Vector2{})
	if backing[0] != nil || gc.glyphs[faces[0]] != nil || gc.faces[0] != faces[1] {
		t.Fatal("oldest admitted group not cleared/evicted; hit must not refresh FIFO")
	}
	if !bytes.Equal(before, held.Pix) {
		t.Fatal("eviction modified caller-held pixels")
	}
	fresh, freshPlacement := gc.Glyph(faces[0], &g, outline, 1, math32.Vec2(20.25, 30.5))
	if fresh == held || freshPlacement != placement || !bytes.Equal(fresh.Pix, before) {
		t.Fatal("regeneration changed pixels or reused evicted mask")
	}
	maskBounds(t, &gc)
}

func TestVellumGlyphMaskExactByteBoundaryAndSelfEviction(t *testing.T) {
	var gc glyphCache
	gc.init()
	face := &font.Face{}
	g, outline := maskFixture(60, 0) // 64*64 mask bytes: exact 8 MiB at 2,048 glyphs.
	held, _ := gc.Glyph(face, &g, outline, 1, math32.Vector2{})
	before := bytes.Clone(held.Pix)
	for i := 1; i < 2048; i++ {
		g.GlyphID = font.GID(i)
		gc.Glyph(face, &g, outline, 1, math32.Vector2{})
	}
	if gc.CacheSize() != 8<<20 || len(gc.glyphs[face]) != 2048 {
		t.Fatal("exact boundary evicted early")
	}
	maskBounds(t, &gc)
	backing := gc.faces[:cap(gc.faces)]
	g.GlyphID = 2048
	last, _ := gc.Glyph(face, &g, outline, 1, math32.Vector2{})
	if len(gc.glyphs[face]) != 1 || gc.CacheSize() != 4096 || backing[0] != nil {
		t.Fatal("self eviction failed to clear/relookup original face group")
	}
	if !bytes.Equal(held.Pix, before) || !bytes.Equal(last.Pix, before) {
		t.Fatal("byte eviction changed caller geometry")
	}
	maskBounds(t, &gc)
}

func TestVellumGlyphMaskConcurrentBounds(t *testing.T) {
	var gc glyphCache
	gc.init()
	faces := make([]*font.Face, 40)
	for i := range faces {
		faces[i] = &font.Face{}
	}
	var wg sync.WaitGroup
	for worker := 0; worker < 8; worker++ {
		wg.Add(1)
		go func(worker int) {
			defer wg.Done()
			for i := 0; i < 120; i++ {
				g, outline := maskFixture(20, font.GID(i%30))
				mask, _ := gc.Glyph(faces[(i+worker)%len(faces)], &g, outline, 1, math32.Vector2{})
				if mask == nil || mask.AlphaAt(10, 10).A == 0 {
					t.Error("concurrent render returned empty mask")
				}
				if size := gc.CacheSize(); size < 0 || size > 8<<20 {
					t.Errorf("concurrent byte bound=%d", size)
				}
			}
		}(worker)
	}
	wg.Wait()
	maskBounds(t, &gc)
}

func TestVellumGlyphMaskRefusalDoesNotRetainFaces(t *testing.T) {
	var gc glyphCache
	gc.init()
	for _, side := range []int{-5, 0, 3, 125, 200} {
		g, outline := maskFixture(side, 0)
		if mask, _ := gc.Glyph(&font.Face{}, &g, outline, 1, math32.Vector2{}); mask != nil {
			t.Fatalf("uncacheable side=%d admitted", side)
		}
	}
	if len(gc.faces) != 0 || len(gc.glyphs) != 0 || gc.CacheSize() != 0 {
		t.Fatal("refused masks retain face keys")
	}
}

func TestVellumGlyphMaskRealFontOriginalColdWarmAndEvictedPixels(t *testing.T) {
	var gc glyphCache
	var original referenceMaskCache
	gc.init()
	original.init()
	shaper := shapedgt.NewShaperWithFonts([]fs.FS{fonts.Default})
	checks := 0
	for _, size := range []float32{24, 48} {
		unitContext := units.Context{}
		unitContext.Defaults()
		style := text.NewStyle()
		style.FontSize = units.Dot(size)
		style.WhiteSpace = text.WrapNever
		style.ToDots(&unitContext)
		runs := shaper.Shape(rich.NewText(rich.NewStyle(), []rune("AgQjpMWé")), style)
		if len(runs) == 0 {
			t.Fatal("embedded font produced no shaped run")
		}
		for _, shaped := range runs {
			run, ok := shaped.(*shapedgt.Run)
			if !ok || run.Face == nil {
				t.Fatal("missing real outline face")
			}
			scale := math32.FromFixed(run.Size) / float32(run.Face.Upem())
			for i := range run.Glyphs {
				g := &run.Glyphs[i]
				outline, ok := run.Face.GlyphDataOutline(g.GlyphID)
				if !ok || len(outline.Segments) == 0 {
					t.Fatal("missing nonempty real glyph")
				}
				for _, pos := range []math32.Vector2{math32.Vec2(20, 60), math32.Vec2(20.25, 60.5), math32.Vec2(20.5, 60.25), math32.Vec2(-6.25, 44.75)} {
					want, placement := original.Glyph(run.Face, g, outline, scale, pos)
					cold, coldPlacement := gc.Glyph(run.Face, g, outline, scale, pos)
					warm, warmPlacement := gc.Glyph(run.Face, g, outline, scale, pos)
					if want == nil || cold == nil || warm != cold || coldPlacement != placement || warmPlacement != placement || cold.Bounds() != want.Bounds() || cold.Stride != want.Stride || !bytes.Equal(cold.Pix, want.Pix) {
						t.Fatal("original/cold/warm pixels or placement differ")
					}
					if bytes.Equal(want.Pix, make([]byte, len(want.Pix))) {
						t.Fatal("blank real glyph oracle")
					}
					retained := bytes.Clone(cold.Pix)
					for n := 0; n < 33; n++ {
						dummy, rect := maskFixture(20, 0)
						gc.Glyph(&font.Face{}, &dummy, rect, 1, math32.Vector2{})
					}
					if gc.glyphs[run.Face] != nil {
						t.Fatal("real face not evicted by 33 admissions")
					}
					fresh, freshPlacement := gc.Glyph(run.Face, g, outline, scale, pos)
					if fresh == cold || freshPlacement != placement || !bytes.Equal(fresh.Pix, want.Pix) || !bytes.Equal(cold.Pix, retained) {
						t.Fatal("original/regenerated pixels or held ownership differ")
					}
					maskBounds(t, &gc)
					checks++
				}
			}
		}
	}
	if checks != 72 {
		t.Fatalf("real-font cases=%d want72", checks)
	}
}
