"""Package a pinned glyph-cache patch; do not edit prepared/module-cache files."""
import difflib, hashlib, json
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-cache-bounds');root=r/'drivers/cogent';folder=root/'native/patches/glyphmask'
folder.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
prefix='paint/renderers/rasterx/'
original=(root/'build/upstream'/prefix/'glyphcache.go').read_bytes()
assert sha(original)=='902cbbd000b304e967617a307d06346d88eea7568292e7754d7a08ae0415540c'
(p/'glyphcache-original.go').write_bytes(original)
reference=p/'glyphcache_reference_test.go'
s=reference.read_text().replace('see oracle-inputs.json','see glyphcache-original-oracle.json');reference.write_text(s)
payload={prefix+n:(p/n).read_bytes()for n in ['glyphcache.go','glyphcache_bounds_test.go','glyphcache_retention_test.go','glyphcache_reference_test.go']}
oracle=json.loads((p/'oracle-inputs.json').read_text());oracle['original_path']=prefix+'glyphcache.go';oracle['license']='Cogent Core BSD-style original methods retained with copyright notice'
payload[prefix+'glyphcache-original-oracle.json']=(json.dumps(oracle,indent=2)+'\n').encode()
inputs={n:sha(original)if n.endswith('/glyphcache.go')else None for n in payload}
outputs={n:sha(b)for n,b in payload.items()}
patch=[]
for n,b in payload.items():
    old=original.decode().splitlines(keepends=True)if n.endswith('/glyphcache.go')else[]
    patch.extend(difflib.unified_diff(old,b.decode().splitlines(keepends=True),fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
patch_name='0046-bounded-glyph-mask-cache.patch';patch_bytes=''.join(patch).encode()
(folder/patch_name).write_bytes(patch_bytes)
for name,value in [('original-hashes.json',inputs),('output-hashes.json',outputs)]:
    (folder/name).write_text(json.dumps(value,indent=2)+'\n')
manifest_path=root/'native/dependencies.json';manifest=json.loads(manifest_path.read_text());stage='native/patches/glyphmask'
assert not any(x['inputs']==stage+'/original-hashes.json'for x in manifest['dependencies'][0]['stages'])
manifest['dependencies'][0]['stages'].append({'origin':'drivers/cogent/'+stage,'inputs':stage+'/original-hashes.json','outputs':stage+'/output-hashes.json','patches':[{'file':stage+'/'+patch_name,'sha256':sha(patch_bytes)}]})
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
(folder/'README.md').write_text('''# Bounded shared glyph-mask cache

Patch 0046 bounds strong face keys to 32 and retained mask pixel data to 8 MiB.
Whole face groups use FIFO admission order; hits do not refresh that order.
Eviction clears the backing-slice prefix and deletes all masks in that group;
current-face self eviction relooks up its map before storing the new mask.
Caller-held masks keep their pixels and lifetime through ordinary Go references.
Cacheable dimensions, key quantization, placement and rendering are unchanged.

The three test files cover original-compatible retention failures, exact byte
boundaries, self eviction, FIFO/hits, backing-prefix clearing, concurrent use,
caller ownership and 64 embedded real-font cold/warm/evicted pixel/placement
comparisons against original cache methods. The reference is generated from the
pinned pre-0046 file with type renaming and duplicate/global declarations removed;
its source hash and transformation are in glyphcache-original-oracle.json.
Original Cogent BSD-style notices remain; new Vellum tests carry MIT notices.

These bounds exclude parsed font size, map/allocator overhead, other caches,
temporary rendering and caller-held masks. The earlier native overlay experiment
reduced Go retention but still showed major IOSurface/physical-footprint growth.
This patch is not full P11 or native/GPU memory acceptance; live retesting is
deferred after the human quiet-host window. No module-cache mutation is used.
''')
print(json.dumps({'patch_sha256':sha(patch_bytes),'outputs':outputs,'expected_prepared_files':6178}))
