// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"testing"

	"cogentcore.org/core/math32"
	"github.com/go-text/typesetting/font"
	"github.com/go-text/typesetting/shaping"
)

// These assertions also compile against the pinned parent implementation, so
// its unbounded strong face keys and mask data can be reproduced directly.
func TestVellumGlyphMaskRetainedFaceAndMaskBounds(t *testing.T) {
	t.Run("face_keys", func(t *testing.T) {
		var gc glyphCache
		gc.init()
		g := shaping.Glyph{Width: math32.ToFixed(20), Height: -math32.ToFixed(20), YBearing: math32.ToFixed(20)}
		for n := 0; n < 33; n++ {
			gc.Glyph(&font.Face{}, &g, font.GlyphOutline{}, 1, math32.Vector2{})
		}
		if len(gc.glyphs) > 32 {
			t.Fatalf("retained face keys=%d; limit32", len(gc.glyphs))
		}
	})
	t.Run("mask_data", func(t *testing.T) {
		var gc glyphCache
		gc.init()
		face := &font.Face{}
		g := shaping.Glyph{Width: math32.ToFixed(60), Height: -math32.ToFixed(60), YBearing: math32.ToFixed(60)}
		for n := 0; n < 2049; n++ {
			g.GlyphID = font.GID(n)
			gc.Glyph(face, &g, font.GlyphOutline{}, 1, math32.Vector2{})
		}
		if bytes := gc.CacheSize(); bytes > 8<<20 {
			t.Fatalf("retained mask bytes=%d; limit8388608", bytes)
		}
	})
}
