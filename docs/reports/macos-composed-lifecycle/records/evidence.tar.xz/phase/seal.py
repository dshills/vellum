"""Preserve the reviewed source and scoped live/race evidence without broad acceptance claims."""
from pathlib import Path
import hashlib,io,json,tarfile
from run import ROOT,PHASE,sha,identity
source=json.loads((PHASE/'checkpoint-source.json').read_text())['sources'];assert len(source)==16 and all(sha(ROOT/n)==h for n,h in source.items())
implementation=json.loads((PHASE/'implementation-source.json').read_text());assert all(source[n]==h for n,h in implementation.items())
review=json.loads((PHASE/'internal-review.json').read_text());assert review['result']=='APPROVED_SOURCE'and not review['findings']and review['source']==implementation
prepared=identity()['prepared'];assert len(prepared)==6204
required=['disposal-race-v5','app-race-v2','density-layout-v5','final-fixture-race-v1','final-cycle-race-v5','final-adapter-race-v1','final-automation-race-v2','final-vet-v1','build-v12','module-verify-v4']
receipts={}
for name in required:
 d=json.loads((PHASE/(name+'.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['source_delta_stable'];assert d['prepared_before']==d['prepared_after']==prepared
 for c in ['stdout','stderr']:assert sha(PHASE/(name+'.'+c))==d[c+'_sha256']
 receipts[name]=sha(PHASE/(name+'.json'))
for name,message in [('app-original-v1','closed View capture retained'),('disposal-original-v3','failed rebuild retained unadopted panel binding')]:
 d=json.loads((PHASE/(name+'.json')).read_text());assert d['exit_code']==1 and d['error']is None and message in(PHASE/(name+'.stdout')).read_text();assert d['overlay_inputs_before']==d['overlay_inputs_after'];receipts[name]=sha(PHASE/(name+'.json'))
final_live=json.loads((PHASE/'final-native-v1.json').read_text());assert final_live['exit_code']==0 and final_live['error']is None and final_live['source_prepared_stable'];assert final_live['executable_sha256']==sha(PHASE/'window-cycle-v12')
live=json.loads((PHASE/'composed-visible-v3.json').read_text());assert live['exit_code']==0 and live['error']is None and live['source_prepared_stable'];assert sha(PHASE/'composed-visible-v3.stdout')==live['stdout_sha256']
raw=[json.loads(x)for x in(PHASE/'composed-visible-v3.stdout').read_text().splitlines()if x.startswith('{')];assert raw[-1]['result']=='PASS_NATIVE_WINDOW_CYCLES'and raw[-1]['completed_cycles']==5
cycles=[x for x in raw if x['event']=='vellum.composed-cycle'];assert len(cycles)==5 and all(x['dense_fully_visible']==1000 and x['all_dense_labels_fully_visible']for x in cycles)
process=json.loads((PHASE/'prism-v1/process.json').read_text());prism=json.loads((PHASE/'prism-v1/prism.json').read_text());assert process['exit_code']==1 and process['error']is None and process['source_index_stable']and process['before']==process['after'];assert prism['coverage']['complete']and prism['coverage']['files']==16
resolution=json.loads((PHASE/'prism-resolution.json').read_text());assert len(prism['findings'])==1 and prism['findings'][0]['id']==resolution['finding_id']and resolution['result']=='FIXED_EXACT_PRISM_SUGGESTION'
path=resolution['path'];assert source[path]==resolution['after_sha256']and process['before'][path]==resolution['before_sha256'];assert all(process['before'][n]==h for n,h in source.items()if n!=path)
restored=(ROOT/path).read_text().replace(resolution['after'],resolution['before']);assert hashlib.sha256(restored.encode()).hexdigest()==resolution['before_sha256']
q={'result':'REVIEWED_MAC_COMPOSED_LIFECYCLE_FOUNDATION','base_commit':identity()['commit'],'source':source,'implementation':implementation,'prepared_files':6204,'prepared_manifest_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True).encode()).hexdigest(),'selected_native_cycles':5,'full_composed_cycles_qualified':False,'native_live_receipt_sha256':sha(PHASE/'composed-visible-v3.json'),'native_binary_sha256':live['executable_sha256'],'final_build_sha256':sha(PHASE/'window-cycle-v12'),'final_native_receipt_sha256':sha(PHASE/'final-native-v1.json'),'final_native_cycles':2,'final_build_difference':'Test filename moved/original restored; exact Prism-suggested diagnostic join preserves simultaneous retirement failures; normal successful native behavior unchanged','required_receipts':receipts,'portable_scope':'Portable race suite other packages passed; automation Unix-socket failures were sandbox bind denial and exact package retry passes. Restored original app tests and new weak-reference test pass together.','internal_review_sha256':sha(PHASE/'internal-review.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':0,'prism_raw_findings':1,'prism_resolved_findings':1,'prism_raw_exit_code':1,'prism_resolution_sha256':sha(PHASE/'prism-resolution.json'),'prism_coverage_complete':True,'prism_sha256':sha(PHASE/'prism-v1/prism.json'),'limits':['Native AX frame containment is not physical pixel/primary-display/scale/presentation acceptance','Short diagnostic samples do not qualify long-run native/GPU allocation or fullP11','1000composedcycles, fullP6/P11/overnight/human/physical/distribution acceptance remainopen']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records=ROOT/'docs/reports/macos-composed-lifecycle/records';suffixes={'.go','.py','.md','.txt','.json','.stdout','.stderr','.log','.heap'}
members={'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes()for p in sorted(PHASE.rglob('*'))if p.is_file()and p.suffix in suffixes};members.update({'root/'+n:(ROOT/n).read_bytes()for n in source});index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz')as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz')as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes']and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
checkpoint={**q,'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),'archive_members':len(index),'archive_index_verified':True,'qualification_sha256':sha(PHASE/'qualification.json'),'seal_producer_sha256':sha(__file__)};(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n');print('Verified',len(index),'evidence members')
(PHASE/'formal-prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
