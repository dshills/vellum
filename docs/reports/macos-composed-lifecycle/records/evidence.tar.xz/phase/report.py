from pathlib import Path
import hashlib,json
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-composed-cycles');dest=r/'docs/reports/macos-composed-lifecycle';rec=dest/'records';rec.mkdir(parents=True,exist_ok=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def records(name):return [json.loads(x)for x in(p/(name+'.stdout')).read_text().splitlines()if x.startswith('{')]
old=records('retention-profile-v1');partial=records('retention-fixed-v1');final=records('composed-visible-v3')
result=final[-1];assert result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['completed_cycles']==5
cycles=[x for x in final if x['event']=='vellum.composed-cycle'];assert len(cycles)==5 and all(x['dense_fully_visible']==1000 and x['native_text_accepted']for x in cycles)
summary={'result':'PASS_FIVE_NATIVE_COMPOSED_PREFLIGHT_CYCLES','base_commit':'8a3e71eb4045d00ba6558f2bea9a2a98f2a1129a','selected_live_receipt':'composed-visible-v3','selected_executable_sha256':json.loads((p/'composed-visible-v3.json').read_text())['executable_sha256'],'selected_build':'build-v7','final_rebuild':'build-v8','final_rebuild_difference':'Only the unchanged new weak-reference regression moved to window_view_retention_test.go and original window_retention_test.go restored; production source identical','original_four_cycle_samples':[x['sample']for x in old if x['event']=='vellum.window-cycle.sample'],'intermediate_twenty_cycle_samples':[x['sample']for x in partial if x['event']=='vellum.window-cycle.sample'],'final_five_cycle_samples':result['samples'],'final_native_cleanup':result['native_cleanup'],'composed_observations':cycles,'limits':['Five-cycle preflight only; 1000composedcycles still required','Native AX frame containment, not physical pixel or primary1920x1080/100% geometry qualification','Modal AX publication/retirement, not independent modal scene inventory','Go post-GC/RSS samples, not native heap/GPU attribution or long-run leak freedom','FullP6/P11, overnight, physical/human/distribution gates remainopen']}
(rec/'review-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(dest/'README.md').write_text('''# Composed native lifecycle foundation

The all-component workspace exposed two ownership bugs. Docked panels keep
managed records outside descriptor Children; normal teardown did not retire those
editor/grid/tree bindings, retaining closed widget graphs. Disposal now walks
nested private panel records. Failed rebuilds retire unadopted parked records
before deleting their widgets. A retired dock revokes queued interactions and
refuses later admission. An explicit attached-host retry advances through fresh
native state without reviving old queued requests.

Application.CloseWindow also left a removed Window.View/CloseRequest closure in
the backing slice. slices.Delete clears that slot under the existing mutex,
preserving surviving order, ID tombstones, lifetime cancellation and cleanup.
A weak-reference regression verifies a captured Go object can be collected while
the survivor/application remain live. Original code overlays fail the view-capture
and failed dock rebuild regressions; final focused race checks pass. The new test
has its own filename and preserves the preexisting 1000-context retention tests.

The native window-cycle command adds -composed. Every fresh window owns the full
UI kind catalog, an editor/journal, managed grid and indexed outline, docked shared-
device GPU canvas, modal dialog and 1000 stable dense labels. It checks GPU readback,
owner editor history replay, completed grid/tree geometry and an actual Cocoa
controlled text request observed in the domain model. Modal target publication
and retirement are checked separately from window/resource cleanup. Queued owner
probes are revoked on timeout, and executing probes join before resource closure.
The mode permits a bounded45minute deadline; the original fixture remains20minutes.

A four-cycle diagnostic before the fixes shows post-GC heap28.7→183.4MiB,
approximately39MiB retained per cycle. After nested disposal, an intermediate
20-cycle run reports72.4MiB atcycle5 and77.3MiB atcycles15/20. After clearing the
window backing slot, the selected final five-cycle preflight reports28.7MiB
initially and40.9MiB aftercycle5, with175.8→320.5MiB RSS. These builds/layouts differ;
the observations support ownership corrections, not isolated numeric attribution
or a long-run memory qualification. The complete raw samples and limits are in
[review summary](records/review-summary.json).

All five final cycles report1000 dense label frames fully contained in both the
root and scroll viewport. This is actual native AX geometry, not pixel occlusion,
physical display scale or requested1920×1080 geometry certification. Earlier
fixture revisions had a zero-width scroll viewport; Grow plus explicit height
bounds correct it. The fixture waits for positive geometry after modal closure,
because scope publication can precede paint. The software geometry regression
uses actual standard controls/labels but substitutes native Extension allocation
placeholders, since Manual deliberately refuses custom extensions. It qualifies
only that layout portion; native composition is checked separately.

The full offscreen adapter race suite and vet pass. Portable race packages pass
with the automation Unix-socket package rerun under required local permissions;
the raw sandbox-denied run remains. The restored original retention tests plus
the new regression pass together. Internal review found and corrected failed-
rebuild and stale-interaction gaps. This checkpoint requires one bounded Prism
review with Anthropic Claude Sonnet5.5, with exact source/receipt evidence archived.

This advances composed fixture implementation and short native acceptance.
The1000-cycle workload, sustained/pacing/input/frame and native/GPU budgets,
overnight soak, required physical display variants, human accessibility and
Mac distribution gates remain open. Original4/6ms frame targets still fail.
''')
f=r/'specs/workbench-endurance.md';f.write_text(f.read_text()+'''
## All-component native lifecycle fixture

The native window-cycle command's `-composed` mode uses fresh editor/history,
managed grid and indexed outline, docked GPU canvas, modal and every accepted
UI kind, plus 1000 dense short labels. It retains the survivor/context/completion/
late-admission/native teardown checks. Actual Cocoa text changes count only after
controlled model acceptance; model history replay and grid/tree geometry stay
separate observations. Modal proof is native AX target presence/absence.

Density reports defined labels and frame containment within the measured root
and scroll viewport after geometry publication. Requested1920×1080 dimensions
are not effective geometry or100%scale qualification. Software tests replace
Extension content with allocation placeholders and qualify only controls/labels.
Composed deadlines are10seconds..45minutes; the original mode remains20minutes.

Workbench disposal recursively retires private panel records before widget
teardown, including unadopted records after a failed shape rebuild. It revokes
interaction generation and refuses retired queue admission/delivery. Ordinary
window removal clears backing slots holding View/CloseRequest closures. Domain
models remain application-owned. The [checkpoint](../docs/reports/macos-composed-lifecycle/README.md)
records short native observations;1000composedcycles and fullP11 remain required.
''')
f=r/'specs/macos-completion.md';f.write_text(f.read_text()+'''
The [composed lifecycle foundation](../docs/reports/macos-composed-lifecycle/README.md)
adds an all-kind workspace with1000 dense labels to the native window-cycle
runner. It fixes nested dock record retention, failed rebuild cleanup, retired
interaction delivery and a closed Window.View backing-slot reference. Original
regressions fail; final race/vet checks and five native composed preflight cycles
pass. Native frame containment is separate from pixel/physical/primary geometry.
The1000-cycle composed campaign, fullP6/P11/memory/overnight and Mac release gates
remain required.
''')
names=list(json.loads((p/'implementation-source.json').read_text()))+['specs/workbench-endurance.md','specs/macos-completion.md','docs/reports/macos-composed-lifecycle/README.md','docs/reports/macos-composed-lifecycle/records/review-summary.json'];(p/'checkpoint-source.json').write_text(json.dumps({'sources':{n:sha(r/n)for n in names}},indent=2)+'\n');print('Review leaves',len(names))
