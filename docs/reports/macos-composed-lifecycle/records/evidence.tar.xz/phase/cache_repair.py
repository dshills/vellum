"""Restore only missing pinned cache files; verify module bytes with Go afterward."""
from pathlib import Path
import hashlib,json,stat,zipfile
cache=Path('/tmp/vellum-p0-cache/mod');records=[]
def escape(s):return ''.join('!'+c.lower()if c.isupper()else c for c in s)
for archive in sorted((cache/'cache/download').rglob('*.zip')):
 if 'toolchain' in archive.parts:continue
 restored=[]
 with zipfile.ZipFile(archive)as z:
  for item in z.infolist():
   if item.is_dir():continue
   left,right=item.filename.split('@',1);version,relative=right.split('/',1);prefix=left+'@'+version;path=Path(relative);assert not path.is_absolute()and '..'not in path.parts
   target=cache/escape(prefix)/path
   if target.exists():continue
   assert not stat.S_ISLNK(item.external_attr>>16)
   parent=target.parent;ancestor=parent
   while not ancestor.exists():ancestor=ancestor.parent
   mode=stat.S_IMODE(ancestor.stat().st_mode);ancestor.chmod(mode|0o700)
   try:parent.mkdir(parents=True,exist_ok=True)
   finally:ancestor.chmod(mode)
   mode=stat.S_IMODE(parent.stat().st_mode);parent.chmod(mode|0o700)
   try:target.write_bytes(z.read(item));target.chmod(0o444)
   finally:parent.chmod(mode)
   restored.append({'path':target.relative_to(cache).as_posix(),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 if restored:records.append({'archive':str(archive),'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':restored})
Path('/private/tmp/vellum-macos-composed-cycles/cache-repair-all.json').write_text(json.dumps({'existing_files_overwritten':False,'modules_repaired':records},indent=2)+'\n');print('Restored',sum(len(r['files'])for r in records),'missing files in',len(records),'pinned archives')
