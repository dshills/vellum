//go:build darwin && cgo && !offscreen && vellum_native_checks

package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"

	"github.com/dshills/vellum/app"
	cogent "github.com/dshills/vellum/drivers/cogent"
	"github.com/dshills/vellum/drivers/cogent/internal/acceptance"
)

func exerciseComposed(ctx context.Context, a *app.Application, id string, w *acceptance.Workspace, cycle int) error {
	value, err := ownerProbe(ctx, a, func() ownerReply { return ownerReply{err: errors.Join(w.Exercise(), a.Invalidate(id))} })
	if err != nil || value.err != nil {
		return errors.Join(err, value.err)
	}
	if err = wait(ctx, func(inner context.Context) (bool, error) {
		value, e := ownerProbe(inner, a, func() ownerReply {
			grid, ge := cogent.InspectGrid(a, w.Grid)
			outline, te := cogent.InspectTree(a, w.Tree)
			if ge != nil || te != nil {
				return ownerReply{err: errors.Join(ge, te)}
			}
			if len(grid.Cells) == 0 || len(outline.Rows) == 0 || outline.Selected != "n1" {
				return ownerReply{err: errors.New("composed models lack completed geometry")}
			}
			return ownerReply{}
		})
		if e != nil {
			return false, e
		}
		if errors.Is(value.err, cogent.ErrGridLayout) || errors.Is(value.err, cogent.ErrTreeLayout) {
			return false, nil
		}
		return value.err == nil, value.err
	}); err != nil {
		return err
	}
	// Queue admission alone is not an accepted controlled native edit. Reinspect
	// and retry within one bounded operation when publication advances generation.
	const edited = "Cocoa composed edit"
	if err = wait(ctx, func(inner context.Context) (bool, error) {
		accepted := false
		value, e := ownerProbe(inner, a, func() ownerReply { accepted = w.Text() == edited; return ownerReply{} })
		if e != nil || value.err != nil {
			return false, errors.Join(e, value.err)
		}
		if accepted {
			return true, nil
		}
		inspection, e := cogent.InspectAccessibility(inner, id)
		if e != nil {
			return false, e
		}
		for _, element := range inspection.Elements {
			if element.ID == "text" || element.DomainID == "text" {
				_, e = cogent.PerformAccessibilityAction(inner, id, element.ID, "set", edited)
				return false, e
			}
		}
		return false, errors.New("composed Cocoa text target missing")
	}); err != nil {
		return err
	}
	// Exercise the real modal scene's creation and retirement in every cycle.
	for _, open := range []bool{true, false} {
		value, err = ownerProbe(ctx, a, func() ownerReply { w.SetDialog(open); return ownerReply{err: a.Invalidate(id)} })
		if err != nil || value.err != nil {
			return errors.Join(err, value.err)
		}
		if err = wait(ctx, func(inner context.Context) (bool, error) {
			inspection, e := cogent.InspectAccessibility(inner, id)
			if e != nil {
				return false, e
			}
			present := false
			for _, element := range inspection.Elements {
				if element.ID == "dialog-close" || element.DomainID == "dialog-close" {
					present = true
				}
			}
			return present == open, nil
		}); err != nil {
			return err
		}
	}

	var inspection cogent.AccessibilityInspection
	root, clip := [4]float64{}, [4]float64{}
	// Scope publication can precede the first main-scene geometry after a modal
	// closes. Await completed nonempty container geometry before observing labels.
	if err = wait(ctx, func(inner context.Context) (bool, error) {
		var e error
		inspection, e = cogent.InspectAccessibility(inner, id)
		if e != nil {
			return false, e
		}
		root, clip = [4]float64{}, [4]float64{}
		for _, element := range inspection.Elements {
			if element.DomainID == "root" {
				root = element.Frame
			}
			if element.DomainID == "density-scroll" {
				clip = element.Frame
			}
		}
		return root[2] > 0 && root[3] > 0 && clip[2] > 0 && clip[3] > 0, nil
	}); err != nil {
		return fmt.Errorf("composed density geometry: %w", err)
	}

	for _, e := range inspection.Elements {
		if e.DomainID == "root" {
			root = e.Frame
		}
		if e.DomainID == "density-scroll" {
			clip = e.Frame
		}
	}
	defined, visible := 0, 0
	for _, e := range inspection.Elements {
		key := e.DomainID
		if key == "" {
			key = e.ID
		}
		if len(key) != 10 || !strings.HasPrefix(key, "dense-") {
			continue
		}
		defined++
		if frameInside(e.Frame, root) && frameInside(e.Frame, clip) {
			visible++
		}
	}
	if defined != acceptance.DenseLabels {
		return fmt.Errorf("composed catalog contains %d of %d dense labels", defined, acceptance.DenseLabels)
	}
	// Every cycle emits bounded scalar evidence; no 1000-node dump per cycle.
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "vellum.composed-cycle", "cycle": cycle + 1, "native_text_accepted": true, "editor_history_replayed": true, "grid_tree_completed": true, "modal_open_close": true, "dense_defined": defined, "dense_fully_visible": visible, "root_screen_points": root, "density_clip_screen_points": clip, "all_dense_labels_fully_visible": visible == acceptance.DenseLabels, "requested_logical_size": [2]int{1920, 1080}, "full_p11_qualified": false})
}
func frameInside(frame, bounds [4]float64) bool {
	return frame[2] > 0 && frame[3] > 0 && bounds[2] > 0 && bounds[3] > 0 && frame[0] >= bounds[0] && frame[1] >= bounds[1] && frame[0]+frame[2] <= bounds[0]+bounds[2]+.01 && frame[1]+frame[3] <= bounds[1]+bounds[3]+.01
}
