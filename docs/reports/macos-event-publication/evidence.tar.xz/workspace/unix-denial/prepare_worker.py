"""Reconstruct both dependencies in fresh owned output; leave checkouts untouched."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-event-publication-e96f642')
s=importlib.util.spec_from_file_location('owned_preparation',T/'drivers/cogent/prepare.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((W/'plan.json').read_bytes());binding=json.loads((W/'source-binding.json').read_bytes());out=P/'modules'
assert not out.exists()and not(P/'prepare-result.json').exists();out.mkdir()
manifest=json.loads((T/'drivers/cogent/native/dependencies.json').read_bytes())
for dependency in manifest['dependencies']:m.prepare_dependency(dependency,out/dependency['name'])
files={}
for path in out.rglob('*'):
 assert not path.is_symlink()
 if path.is_file():files[path.relative_to(out).as_posix()]=sha(path)
expected=dict(plan['baseline_prepared'])
for name,digest in binding['prepared_after'].items():expected['upstream/'+name]=digest
assert len(files)==6250 and files==expected
with(P/'prepare-result.json').open('x')as f:f.write(json.dumps(dict(result='PASS_RECONSTRUCTED_STAGE_0077',files=files,count=len(files),checkout_prepared_mutation=False),indent=2)+'\n')
print(json.dumps(dict(result='PASS_RECONSTRUCTED_STAGE_0077',files=len(files),checkout_prepared_mutation=False)))
