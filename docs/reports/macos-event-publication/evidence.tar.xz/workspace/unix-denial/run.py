"""Current public compute/HDR consumer of the exact source-built private GPU archive."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-event-publication-e96f642');T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='e96f642fd1a3620ff16ca7858f991a421fcf5fda'
OLD=W.parent/'macos-source-gpu-sdk-native';spec=importlib.util.spec_from_file_location('advanced_owned_parent',OLD/'run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
need,sha,read,g=h.need,h.sha,h.read,h.g
need(sha(OLD/'run.py')=='d995d9d2b4ca70ba98c8bdc753c550925cd0ca063a06b96438c76157c082c0f7','unchanged validated parent guard')
h.W,h.P=W,P
SDK=Path(read(OLD/'build.json')['sdk_root']);LIB=SDK/'drivers/cogent/build/libs-darwin';LIBSHA='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
CASES=['imaging'];GO=h.GO
ROOTS={'github.com/dshills/vellum':T,'github.com/dshills/vellum/drivers/cogent':T/'drivers/cogent','cogentcore.org/core':T/'drivers/cogent/build/upstream','github.com/go-text/typesetting':T/'drivers/cogent/build/typesetting','github.com/oliverbestmann/webgpu/libs-darwin':LIB}
MODULES=P/'modules';ROOTS['cogentcore.org/core']=MODULES/'upstream';ROOTS['github.com/go-text/typesetting']=MODULES/'typesetting'
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
def status():
 need(all(git(root,'rev-parse','HEAD').decode().strip()==HEAD for root in [T,C]),'unchanged source HEADs')
 need(not git(C,'status','--porcelain','-z'),'clean canonical')
 binding=read(W/'source-binding.json')
 changed=set(git(T,'diff','HEAD','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines())
 need(changed==set(binding['after']),'only intended source changes')
 need(all(sha(T/n)==v and (sha(C/n)if(C/n).exists()else None)==binding['before'][n]for n,v in binding['after'].items()),'reviewed source endpoint')
def stopped(phase):return h.STOP.exists() or(P/('stop-'+phase)).exists()
def command(args,native=False):return h.environment(native)+['GORACE=halt_on_error=1 exitcode=66 atexit_sleep_ms=0',*args]
def prepare():
 need(not P.exists() and not(W/'plan.json').exists() and not h.STOP.exists(),'fresh advanced consumers')
 review=read(W/'source-review.json');need(review['source_semantics_ready']and not review['unresolved_findings'],'source review resolved')
 status();names=git(C,'ls-files','-z').decode().split('\0')[:-1];need(names==git(T,'ls-files','-z').decode().split('\0')[:-1] and len(names)==4730,'source counts')
 pins={}
 for root in [C,T]:
  for name in names+([n for n,v in read(W/'source-binding.json')['before'].items()if v is None]if root==T else []):
   p=root/name;need(p.is_file()and not p.is_symlink(),'regular source');pins[str(p)]=sha(p)
  hidden=git(root,'ls-files','-v','-z').decode().split('\0');need(not[n for n in hidden if n and(n[0].islower()or n[0]=='S')],'no hidden source changes')
 prepared={}
 for root in [C,T]:
  vector={}
  for name in ['upstream','typesetting']:
   for p in(root/'drivers/cogent/build'/name).rglob('*'):
    need(not p.is_symlink(),'prepared symlink')
    if p.is_file():vector[p.relative_to(root/'drivers/cogent/build').as_posix()]=sha(p);pins[str(p)]=sha(p)
  need(len(vector)==6249 and(not prepared or vector==prepared),'equal prepared input vectors');prepared=vector
 manifest=read(SDK/'SDK_MANIFEST.json');need(manifest['source']==dict(clean=True,commit='3da753ed4e49ef18ca5ef2377c171efb970b46a1'),'retained clean SDK identity')
 for name,digest in h.sdk_identity(SDK,manifest).items():pins[str(SDK/name)]=digest
 need(sha(LIB/'arm64/libwgpu_native.a')==LIBSHA,'exact source-built static archive')
 # Compare the clean baseline with the retained SDK. Stage 0077 is separately
 # bound and compiled from a fresh reconstructed dependency output below.
 prefixes=('app/','automation/','ui/','canvas/','command/','history/','document/','editor/','execution/','replay/','tasks/','virtual/','workbench/','drivers/cogent/')
 counterparts=0
 for name,digest in manifest['files'].items():
  if name.startswith(prefixes) and not name.startswith('drivers/cogent/build/libs-darwin/'):
   expected=manifest['native_gpu']['go_mod_overlays'].get(name,{}).get('source_sha256',digest)
   need((C/name).is_file() and sha(C/name)==expected,'SDK/base framework counterpart '+name);counterparts+=1
 tools=[Path(__file__),W/'source-binding.json',W/'source-review.json',W/'controls.py',W/'controls.json',W/'prepare_worker.py',W/'source-installed.json',W/'original-prepared/events/source.go',OLD/'run.py',OLD/'build.json',OLD/'native.json',GO,Path('/opt/homebrew/bin/go'),h.PYTHON,h.CLANG,h.CLANG.parent/'ld',h.CLANG.parent.parent/'lib/libclang.dylib',h.SDK/'SDKSettings.json',W.parent/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),Path('/usr/bin/otool'),Path('/usr/bin/sandbox-exec')]
 for path in tools:pins[str(path)]=sha(path)
 P.mkdir(mode=0o700)
 for name in ['go-cache','go-tmp','temp']:(P/name).mkdir(mode=0o700)
 jobs=[]
 for name in CASES:
  cwd=T/'examples'/name;original=(cwd/'go.mod').read_text();start=original.index('replace (');end=original.index(')',start)+1
  need(original.count('replace (')==1 and not original[end:].strip(),'single final replacement block')
  block='replace (\n'+''.join(' '+module+' => '+json.dumps(str(path))+'\n'for module,path in ROOTS.items())+')'
  modfile=P/(name+'.mod');modfile.write_text(original[:start]+block+original[end:]);modfile.with_suffix('.sum').write_bytes((cwd/'go.sum').read_bytes())
  pins[str(modfile)]=sha(modfile);pins[str(modfile.with_suffix('.sum'))]=sha(modfile.with_suffix('.sum'))
  jobs.append(dict(name=name,cwd=str(cwd),modfile=str(modfile),binary=str(P/name),linkmap=str(P/(name+'.linkmap'))))
 coremod=P/'core.mod';coretext=(T/'drivers/cogent/build/upstream/go.mod').read_text();needle='replace github.com/go-text/typesetting => ../typesetting';need(coretext.count(needle)==1,'single core replacement');coremod.write_text(coretext.replace(needle,'replace github.com/go-text/typesetting => '+json.dumps(str(MODULES/'typesetting'))));coremod.with_suffix('.sum').write_bytes((T/'drivers/cogent/build/upstream/go.sum').read_bytes())
 drivermod=P/'driver.mod';drivertext=(T/'drivers/cogent/go.mod').read_text();start=drivertext.index('replace (');end=drivertext.index(')',start)+1;need(drivertext.count('replace (')==1 and not drivertext[end:].strip(),'single driver replacement block');drivermod.write_text(drivertext[:start]+'replace (\n'+''.join(' '+module+' => '+json.dumps(str(path))+'\n'for module,path in ROOTS.items()if module!='github.com/dshills/vellum/drivers/cogent')+')'+drivertext[end:]);drivermod.with_suffix('.sum').write_bytes((T/'drivers/cogent/go.sum').read_bytes())
 overlay=P/'old-source.json';overlay.write_text(json.dumps(dict(Replace={str(MODULES/'upstream/events/source.go'):str(W/'original-prepared/events/source.go')}),indent=2)+'\n')
 for path in [coremod,coremod.with_suffix('.sum'),drivermod,drivermod.with_suffix('.sum'),overlay]:pins[str(path)]=sha(path)
 h.exclusive(W/'plan.json',dict(source_commit=HEAD,inputs=pins,jobs=jobs,expected_origins={k:str(v)for k,v in ROOTS.items()},library_sha256=LIBSHA,sdk_source=manifest['source'],sdk_root=str(SDK),sdk_baseline_counterparts=counterparts,current_framework=True,new_sdk_archive=False,modified_source_binding_sha256=sha(W/'source-binding.json'),native_separate_review=True,baseline_tracked_files=4730,source_files_including_new_patch_files=4734,baseline_prepared=prepared,reconstructed_prepared_files=6250,core_modfile=str(coremod),driver_modfile=str(drivermod),counterfactual_overlay=str(overlay)))
 print(json.dumps(dict(result='PREPARED_ADVANCED_SOURCE_CONSUMERS',inputs=len(pins),framework_counterparts=counterparts,native_started=False)))
def module_identity(root):
 need(root.is_dir()and not root.is_symlink(),'regular reconstructed root')
 files={}
 for path in root.rglob('*'):
  need(not path.is_symlink()and(path.is_file()or path.is_dir()),'regular reconstructed member')
  if path.is_file():files[path.relative_to(root).as_posix()]=sha(path)
 return files
def build():
 phase='build';need(not(W/'build.json').exists() and not stopped(phase),'one-shot advanced build')
 pins,reviewsha=h.certificate('build');plan=read(W/'plan.json');admitted_modules=None
 stable=lambda:all(sha(p)==v for p,v in pins.items())and(admitted_modules is None or module_identity(MODULES)==admitted_modules)
 d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,readiness_sha256=reviewsha,commands=[],binaries=[],error=None,finalization_errors=[],native_execution='not_started')
 def run(label,args,cwd,timeout=180,negative=False):
  record=g.execute(command(args),cwd,P/label,lambda:stopped(phase),stable,timeout=timeout,limit=8<<20);d['commands'].append(dict(name=label,run=record));need(h.terminal(record)if not negative else(record['created']and record['exit_code']==1 and record['error']is None and not record['observation_errors']and record['logs_complete']and record['pins_stable']and not record['stop_at_exit']and record['owned']['terminal']and record['owned']['group_absent']and not record['owned']['errors']),'owned command '+label);return(P/label/'stdout').read_bytes()
 try:
  with g.LiveLease()as lease:
   need(lease.held() and stable() and not stopped(phase),'build admission');status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'))
   run('prepare-modules',[str(h.PYTHON),'-B',str(W/'prepare_worker.py')],T,180)
   prepared=read(P/'prepare-result.json');need(prepared['result']=='PASS_RECONSTRUCTED_STAGE_0077'and len(prepared['files'])==6250,'reconstructed dependency vector')
   admitted_modules=dict(plan['baseline_prepared'])
   admitted_modules.update({'upstream/'+name:digest for name,digest in read(W/'source-binding.json')['prepared_after'].items()})
   need(prepared['files']==admitted_modules and module_identity(MODULES)==admitted_modules,'freeze exact reconstructed membership and bytes')
   for name,digest in admitted_modules.items():h.pin_once(pins,MODULES/name,digest)
   h.pin_once(pins,P/'prepare-result.json')
   def pin_graph(label,args,cwd):
    packages=h.checker.decode_objects(run(label,args,cwd).decode());need(packages and not any(p.get('Incomplete')or p.get('Error')or p.get('DepsErrors')for p in packages),'complete test graph')
    skipped=[]
    for package in packages:
     for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles']:
      for value in package.get(field,[]):
       path=Path(value)if Path(value).is_absolute()else Path(package['Dir'])/value
       if not path.is_file():
        need(field=='GoFiles'and package.get('Name')=='main'and package['ImportPath'].endswith('.test')and path.name=='_testmain.go','only generated test-main source may lack a retained file');skipped.append(str(path));continue
       h.pin_once(pins,path)
     module=package.get('Module')or{};module=module.get('Replace')or module
     if module.get('GoMod'):h.pin_once(pins,module['GoMod'])
    return dict(packages=len(packages),generated_test_main_not_retained=skipped)
   core=MODULES/'upstream';coremod='-modfile='+plan['core_modfile']
   d['events_graph']=pin_graph('events-sources',[str(GO),'list','-race','-test',coremod,'-mod=readonly','-deps','-json','./events/...'],core)
   counterfactual=run('events-old-source-control',[str(GO),'test','-race','-count=1',coremod,'-mod=readonly','-overlay='+plan['counterfactual_overlay'],'-run=^TestSourceKeyPublicationOwnership$','./events'],core,180,True)
   negative=counterfactual+(P/'events-old-source-control/stderr').read_bytes()
   need(b'WARNING: DATA RACE'in negative and b'(*Source).Key'in negative and b'SetLocalOff'in negative and b'TestSourceKeyPublicationOwnership'in negative and b'build failed'not in negative,'old-source negative control identifies publication race')
   d['old_source_control']=dict(expected_exit_code=1,race_detected=True,source_overlay_sha256=sha(plan['counterfactual_overlay']))
   run('events-race',[str(GO),'test','-race','-count=1',coremod,'-mod=readonly','./events/...'],core,180)
   run('events-vet',[str(GO),'vet',coremod,'-mod=readonly','./events/...'],core,180)
   run('preparation-tests',[str(h.PYTHON),'-B',str(T/'drivers/cogent/prepare_test.py')],T,180)
   driver=T/'drivers/cogent';drivermod='-modfile='+plan['driver_modfile']
   modules=h.checker.decode_objects(run('driver-modules',[str(GO),'list',drivermod,'-mod=readonly','-m','-json','all'],driver).decode())
   need({m['Path']:m['Replace'].get('Dir')for m in modules if m.get('Replace')}=={k:v for k,v in plan['expected_origins'].items()if k!='github.com/dshills/vellum/drivers/cogent'},'exact driver module origins')
   d['driver_graph']=pin_graph('driver-sources',[str(GO),'list','-race','-tags=offscreen','-test',drivermod,'-mod=readonly','-deps','-json','./...'],driver)
   run('driver-race',[str(GO),'test','-race','-tags=offscreen','-count=1',drivermod,'-mod=readonly','./...'],driver,600)
   run('driver-vet',[str(GO),'vet','-tags=offscreen',drivermod,'-mod=readonly','./...'],driver,300)
   for job in plan['jobs']:
    name=job['name'];cwd=Path(job['cwd']);mod='-modfile='+job['modfile'];binary=Path(job['binary']);linkmap=Path(job['linkmap']);h.fresh_outputs(binary,linkmap)
    modules=h.checker.decode_objects(run(name+'-modules',[str(GO),'list',mod,'-mod=readonly','-m','-json','all'],cwd).decode())
    origins={m['Path']:m['Replace'].get('Dir')for m in modules if m.get('Replace')};need(origins==plan['expected_origins'],'exact five current/private module origins')
    packages=h.checker.decode_objects(run(name+'-sources',[str(GO),'list','-race',mod,'-mod=readonly','-deps','-json','.'],cwd).decode());need(packages and not any(p.get('Incomplete')or p.get('Error')or p.get('DepsErrors')for p in packages),'complete race package graph')
    for package in packages:
     for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles']:
      for value in package.get(field,[]):
       path=Path(value)if Path(value).is_absolute()else Path(package['Dir'])/value;h.pin_once(pins,path)
     module=package.get('Module')or{};module=module.get('Replace')or module
     if module.get('GoMod'):h.pin_once(pins,module['GoMod'])
    run(name+'-race',[str(GO),'test','-race','-count=1',mod,'-mod=readonly','./...'],cwd,600)
    run(name+'-vet',[str(GO),'vet',mod,'-mod=readonly','./...'],cwd,300)
    h.fresh_outputs(binary,linkmap)
    run(name+'-compile',[str(GO),'build','-race',mod,'-mod=readonly','-p=2','-buildvcs=true','-ldflags=-linkmode=external -extldflags=-Wl,-map,'+str(linkmap),'-o',str(binary),'.'],cwd,600)
    need(binary.is_file()and not binary.is_symlink()and 0<binary.stat().st_size<128<<20 and linkmap.is_file()and not linkmap.is_symlink(),'retained build pair');h.pin_once(pins,binary);h.pin_once(pins,linkmap)
    links=run(name+'-links',['/usr/bin/otool','-L',str(binary)],P,30).decode();need('libwgpu_native'not in links,'no WGPU dylib dependency')
    load=run(name+'-load',['/usr/bin/otool','-l',str(binary)],P,30).decode();need('minos 13.0'in load,'minimum macOS13')
    info=json.loads(run(name+'-metadata',[str(GO),'version','-m','-json',str(binary)],P,30));settings={}
    for item in info['Settings']:
     need(set(item)<={'Key','Value'}and item['Key']not in settings and type(item.get('Value',''))is str,'unique typed build settings');settings[item['Key']]=item.get('Value','')
    need(info['GoVersion']=='go1.27.2'and info['Path']=='github.com/dshills/vellum/examples/'+name and all(settings.get(k)==v for k,v in {'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':'1','-race':'true','vcs.revision':HEAD,'vcs.modified':'true'}.items()),'current modified-source race build identity')
    need([m.get('Replace',{}).get('Path')for m in info.get('Deps',[])if m['Path']=='github.com/oliverbestmann/webgpu/libs-darwin']==[str(LIB)],'embedded private module lineage')
    with binary.open('rb')as stream:header=stream.read(32)
    need(len(header)==32 and struct.unpack_from('<I',header)[0]==0xFEEDFACF and struct.unpack_from('<I',header,4)[0]==0x0100000C and struct.unpack_from('<I',header,12)[0]==2,'ARM64 MH_EXECUTE')
    framed=h.native_archive.archive_members(LIB/'arm64/libwgpu_native.a');mapping=h.native_archive.linker_objects(linkmap);selected=h.native_archive.selected_archive_members(mapping,LIB/'arm64/libwgpu_native.a',framed)
    need(framed['sha256']==LIBSHA and mapping['architecture']=='arm64'and selected and len(selected)==len([v for v in mapping['objects']if'libwgpu_native'in v]),'only exact source-built static members')
    inspection=W/('inspection-'+name+'.json');h.exclusive(inspection,dict(name=name,selected_members=selected,package_count=len(packages),origins=origins,metadata=info,static_archive_sha256=LIBSHA));h.pin_once(pins,inspection)
    d['binaries'].append(dict(name=name,path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary),linkmap=dict(path=str(linkmap),bytes=linkmap.stat().st_size,sha256=sha(linkmap)),private_static_members=len(selected),package_count=len(packages),race=True,minimum_macos='13.0'))
   status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'));need(stable()and not stopped(phase)and lease.held(),'terminal build closure')
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:h.finish(phase,d)
def validate(name,stdout,stderr):
 need(name=='imaging','fixed imaging summary')
 records=[json.loads(line)for line in stdout.splitlines()]
 need(len(records)==1 and type(records[0])is dict,'one imaging JSON summary');r=records[0]
 need(r.get('event')=='vellum.imaging.smoke'and r.get('result')=='pass'and r.get('geometry_persistence_disabled_in_fixture')is True,'actual isolated imaging success')
 for key in ['transparentTop','nativeAdmissionRefusals','explicitSyncThenAsync','partialAlpha','busyInsideCallback','independentResources','quietCancelRebuildClose']:need(r.get(key)is True,'imaging assertion '+key)
 need(r.get('exposure1')==dict(R=213,G=156,B=0,A=128)and r.get('exposure2')==dict(R=231,G=188,B=0,A=128),'quantitative exposure/alpha reference')
 close=r.get('normalClose');need(type(close)is dict,'normal close record')
 for key in ['nativeClosed','nativeDrawingLockRefused','windowLifetimeCanceled','appLifetimeCanceled','unregistered','programReleased']:need(close.get(key)is True,'normal close assertion '+key)
 need(type(close.get('callbackCount'))is int and close['callbackCount']==0,'no canceled/closed capture delivery')
 need(type(r.get('deliveryAfterResize'))is bool,'record actual scheduling overlap without requiring it')
 initial=r.get('initial');need(type(initial)is dict and initial.get('BufferBytes')==1048608 and initial.get('TextureBytes')==524288,'compute storage/uniform and float texture accounting')
 need(stderr==b'','no unexpected imaging diagnostics')
 return r
def native(name):
 phase='native-'+name;need(name in CASES and not(W/(phase+'.json')).exists()and not stopped(phase),'one-shot case')
 pins,reviewsha=h.certificate('native');admitted_modules=read(P/'prepare-result.json')['files'];stable=lambda:all(sha(p)==v for p,v in pins.items())and module_identity(MODULES)==admitted_modules;built=read(W/'build.json');need(built['result']=='PASS_BUILD'and not built['error']and not built['finalization_errors'],'terminal reviewed builds')
 binary=next(v for v in built['binaries']if v['name']==name)
 d=dict(result='INCOMPLETE',source_commit=HEAD,inputs=pins,readiness_sha256=reviewsha,error=None,finalization_errors=[],native_execution='not_started',physical_input_generated=False,settings_changes=False,full_macos_qualified=False)
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopped(phase),'native case admission');status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'))
   run=g.execute(command([binary['path'],'--smoke'],True),T/'examples'/name,P/phase,lambda:stopped(phase),stable,timeout=75,limit=2<<20)
   d['run']=run;d['native_execution']='created_not_qualified'if run['created']else'not_started';need(h.terminal(run),'owned native smoke '+name)
   d['record']=validate(name,(P/phase/'stdout').read_bytes(),(P/phase/'stderr').read_bytes());d['native_execution']='confirmed_by_source_assertions_and_summary'
   status();h.sdk_identity(SDK,read(SDK/'SDK_MANIFEST.json'));need(stable()and not stopped(phase)and lease.held(),'terminal native closure')
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:h.finish(phase,d)
if __name__=='__main__':
 need(sys.argv[1:]in[['prepare'],['build'],['native-imaging']],'fixed advanced phase')
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='build':build()
 else:native(sys.argv[1].removeprefix('native-'))
