from pathlib import Path
import difflib,hashlib,json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');V2=W.parent/'macos-imaging-native-e96f642-v2'
sha=lambda body:hashlib.sha256(body).hexdigest()
def main():
 assert not(W/'source-binding.json').exists()
 old=json.loads((V2/'source-binding.json').read_text())
 sources={name:(T/name).read_bytes()for name in old['after']}
 assert all(sha(sources[n])==h for n,h in old['after'].items())
 path='events/source.go';base=(T/'drivers/cogent/build/upstream'/path).read_bytes()
 assert base==(C/'drivers/cogent/build/upstream'/path).read_bytes()
 original=W/'original-prepared'/path;original.parent.mkdir(parents=True);original.write_bytes(base)
 s=base.decode();s=s.replace('if !ev.HasAnyModifier(key.NumLock)', 'if !key.HasAnyModifier(mods, key.NumLock)')
 old_line='if ev.Code < key.CodeLeftControl && (ev.HasAnyModifier(key.Control, key.Meta) || !mapped || ev.Code == key.CodeTab) {'
 new_line='if code < key.CodeLeftControl && (key.HasAnyModifier(mods, key.Control, key.Meta) || !mapped || code == key.CodeTab) {'
 assert s.count(old_line)==1;s=s.replace(old_line,new_line)
 s=s.replace('\tes.Deque.Send(ev)\n\n\tmrn, mapped := key.CodeRuneMap[code]', '\tes.Deque.Send(ev)\n\n\t// The consumer now owns ev and may mutate its Base. Use only producer\n\t// arguments for chord decisions after publication; even a Base value\n\t// receiver would copy concurrently mutable local-offset/handled fields.\n\tmrn, mapped := key.CodeRuneMap[code]',1)
 prepared={path:s.encode(),'events/source_key_ownership_vellum_test.go':(W/'source_key_ownership_test.go.txt').read_bytes()}
 patch=''
 for name,data in prepared.items():
  before=base.decode()if name==path else ''
  patch+=''.join(difflib.unified_diff(before.splitlines(True),data.decode().splitlines(True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
 directory='drivers/cogent/native/patches/eventpublication';prefix=directory+'/'
 sources[prefix+'0077-key-event-publication-ownership.patch']=patch.encode()
 sources[prefix+'original-hashes.json']=(json.dumps({path:sha(base),'events/source_key_ownership_vellum_test.go':None},indent=2)+'\n').encode()
 sources[prefix+'output-hashes.json']=(json.dumps({n:sha(b)for n,b in prepared.items()},indent=2)+'\n').encode()
 sources[prefix+'README.md']=('''# Key-event publication ownership

Stage 0077 ends Source.Key access to the event after Deque.Send transfers it to
the consumer. Chord decisions use the original code/modifier arguments. Calling
a Base value-receiver method on the published event copies mutable fields and
races with the render consumer's legitimate SetLocalOff/SetHandled mutations.
The original key/chord order, mapped keypad runes, NumLock, modifier behavior,
producer state and injected event clock remain unchanged. No lock, delayed
delivery, event clone, polling timer or broader source-serialization claim is added.

The producer/consumer regression acknowledges each of 128 ordinary keys and joins
its consumer. It exercises real deque ownership with bounded in-flight work.
A separate twelve-case matrix checks key/chord identity, order, modifiers/runes,
producer state and injected timestamps. Run the regression with the Go race
detector. An old-source counterfactual must expose the prior race; ordinary
success alone does not show that a test distinguishes the defect.

The native imaging exit-66 failure that exposed this race remains failed. New
source, race regressions and a fresh native result need independent review;
physical input, full IME/accessibility behavior and complete Mac qualification
are separate. Preparation binds exact input, patch and output hashes. Added
test code and owned edits are MIT; original upstream notices remain in place.
''').encode()
 name='drivers/cogent/native/dependencies.json';manifest=json.loads((C/name).read_text());stages=manifest['dependencies'][0]['stages'];assert stages[-1]['origin'].endswith('glyphplacement');stages.append(dict(origin=directory,inputs='native/patches/eventpublication/original-hashes.json',outputs='native/patches/eventpublication/output-hashes.json',patches=[dict(file='native/patches/eventpublication/0077-key-event-publication-ownership.patch',sha256=sha(patch.encode()))]));sources[name]=(json.dumps(manifest,indent=2)+'\n').encode()
 name='drivers/cogent/prepare_test.py';text=(C/name).read_text();assert text.count('list(range(1, 77))')==1;sources[name]=text.replace('list(range(1, 77))','list(range(1, 78))').encode()
 name='drivers/cogent/native/README.md';sources[name]=((C/name).read_text()+'''\nStage 77 (`patches/eventpublication`) ends producer reads of a key event after
queue publication. Chord decisions use immutable input values while the render
consumer owns mutable event fields. The owned race regression and key/chord
matrix preserve the original ordering, keypad/NumLock/modifier semantics and
injected timestamps. See [publication contract](patches/eventpublication/README.md).
''').encode()
 name='specs/native-dispatch.md';sources[name]=((C/name).read_text()+'''\n## Key-event ownership after queue publication

After `Source.Key` publishes the original key through `Deque.Send`, only the
consumer may mutate or copy that event. The producer derives any following
chord from its original code, rune and modifier arguments. This includes avoiding
value-receiver Base methods, which copy fields modified by render dispatch.
Stage 0077 preserves original-key-before-chord ordering, independent event
identity, keypad and NumLock rules, modifier handling, producer state and the
source's injected clock. It does not serialize unrelated producers or change
queue compression/priority. The joined producer/consumer race regression and
twelve-case chord matrix provide offscreen evidence; native/physical input
and broader IME/accessibility qualification remain separate.
''').encode()
 assert len(sources)==13
 for kind,values in [('draft',sources),('draft-prepared',prepared)]:
  for name,data in values.items():
   p=W/kind/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 before={name:sha((C/name).read_bytes())if(C/name).exists()else None for name in sources}
 for name in sources:
  if before[name]is not None:
   p=W/'original'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((C/name).read_bytes())
 binding=dict(base_commit=old['base_commit'],before=before,after={n:sha(b)for n,b in sources.items()},prepared_before={path:sha(base),'events/source_key_ownership_vellum_test.go':None},prepared_after={n:sha(b)for n,b in prepared.items()},initial_native_failure_sha256=sha((V2/'native-imaging.json').read_bytes()),initial_native_stderr_sha256='75684a5b225e7481af3735eed53ad1b5d619d89f32e01f037d3c5d1ac491f21f')
 (W/'source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
 print('Proposed thirteen source/test/spec leaves and two prepared outputs; no worktree mutation.')
if __name__=='__main__':main()
