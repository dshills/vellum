from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');OLD=W.parent/'macos-imaging-native-e96f642-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
b=json.loads((W/'source-binding.json').read_bytes());r=json.loads((W/'source-review.json').read_bytes());old=json.loads((OLD/'source-binding.json').read_bytes())
assert r['source_semantics_ready']and not r['unresolved_findings']
assert not(W/'source-installed.json').exists()and not git(C,'status','--porcelain','-z')and not git(T,'diff','--cached','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
assert set(git(T,'diff','--name-only').decode().splitlines())==set(old['after'])and all(sha(T/n)==h for n,h in old['after'].items())
assert all(git(root,'rev-parse','HEAD').decode().strip()==b['base_commit']for root in [C,T])
assert all(sha(W/'draft'/n)==h for n,h in b['after'].items())
assert all((sha(C/n)if(C/n).exists()else None)==h for n,h in b['before'].items())
for name in b['after']:
 p=T/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/'draft'/name).read_bytes())
assert all(sha(T/n)==h for n,h in b['after'].items())
changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(b['after'])
git(T,'diff','--check')
with(W/'source-installed.json').open('x')as out:out.write(json.dumps(dict(result='INSTALLED_REVIEWED_EVENT_PUBLICATION_SOURCE',files=len(changed),prepared_modules_unchanged=True,source_binding_sha256=sha(W/'source-binding.json')),indent=2)+'\n')
print('Installed reviewed thirteen-file source endpoint; prepared modules unchanged.')
