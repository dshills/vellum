from pathlib import Path
import hashlib,json,subprocess,shutil
W=Path(__file__).resolve().parent;OLD=W.parent/'macos-imaging-native-e96f642';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.loads((OLD/'source-binding.json').read_text());assert all(sha(T/n)==h for n,h in b['after'].items())
extra='examples/imaging/main_test.go';assert sha(T/extra)==sha(C/extra);b['before'][extra]=sha(C/extra)
shutil.copytree(OLD/'original',W/'original');p=W/'original'/extra;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((C/extra).read_bytes())
for name in b['before']:
 p=W/'prejoin'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
p=T/'examples/imaging/main.go';s=p.read_text();s=s.replace('result := make(chan error, 1)\n\tif smoke {','var result <-chan error\n\tif smoke {');old='\t\tgo func() {\n\t\t\tctx, cancel := context.WithTimeout(a.Context(), 50*time.Second)\n\t\t\tdefer cancel()\n\t\t\tresult <- imagingSmoke(ctx, a, first, second, nativeErrors)\n\t\t\ta.Close()\n\t\t}()\n';new='\t\tvar workerDone <-chan struct{}\n\t\tresult, workerDone = startSmokeWorker(a.Close, func() error {\n\t\t\tctx, cancel := context.WithTimeout(a.Context(), 50*time.Second)\n\t\t\tdefer cancel()\n\t\t\treturn imagingSmoke(ctx, a, first, second, nativeErrors)\n\t\t})\n\t\tdefer func() {\n\t\t\t// On native failure, cancel owner/window work before waiting. Joining\n\t\t\t// covers every post-launch return and precedes geometry restoration.\n\t\t\ta.Close()\n\t\t\t<-workerDone\n\t\t}()\n';assert s.count(old)==1;s=s.replace(old,new)
anchor='func run(smoke bool) error {';helper='// Result publication is distinct from complete worker/application cleanup.\n// The outer smoke watchdog remains active if shutdown or a worker gets stuck.\nfunc startSmokeWorker(stop func(), work func() error) (<-chan error, <-chan struct{}) {\n\tresult := make(chan error, 1)\n\tdone := make(chan struct{})\n\tgo func() {\n\t\tdefer close(done)\n\t\tdefer stop()\n\t\tresult <- work()\n\t}()\n\treturn result, done\n}\n\n';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor);p.write_text(s)
p=T/extra;s=p.read_text().replace('"image"','"image"\n"sync"');s+='\n'+(W/'join-test.go.txt').read_text();p.write_text(s)
for name in ['examples/imaging/README.md','specs/advanced-gpu.md']:
 p=T/name;p.write_text(p.read_text()+'\nEvery post-launch smoke return closes the application and joins the smoke worker\nbefore restoring the process-local geometry setting. Worker completion follows\nits context cleanup and application-close callback; receiving its result alone\nis not a completion barrier. The outer watchdog remains active during the join.\n')
subprocess.run(['/opt/homebrew/bin/gofmt','-w',str(T/'examples/imaging/main.go'),str(T/extra)],check=True)
for name in b['before']:
 p=W/'draft'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/name).read_bytes())
(W/'source-binding.json').write_text(json.dumps(dict(base_commit=b['base_commit'],before=b['before'],after={n:sha(T/n)for n in b['before']},initial_review_fix='IMAGING-WORKER-LIFETIME-01',original_source_review_sha256=sha(OLD/'source-review.json')),indent=2)+'\n')
print(json.dumps(dict(result='IMAGING_WORKER_COMPLETION_JOIN_INSTALLED',files=5,native_started=False)))
