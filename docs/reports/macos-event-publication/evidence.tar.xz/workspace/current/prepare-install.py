"""After commit, prepare both checkouts and compare the tested complete vector."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('postcommit_preparation_runtime',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
h,g,P,T,C,sha,read,need=m.h,m.g,m.P,m.T,m.C,m.sha,m.read,m.need
def vector(root):
 return {module+'/'+name:digest for module in ['upstream','typesetting']for name,digest in m.module_identity(root/'drivers/cogent/build'/module).items()}
def main():
 phase='prepare-install';need(not(W/(phase+'.json')).exists()and not m.stopped(phase),'fresh postcommit preparation')
 pins,reviewsha=h.certificate(phase);stable=lambda:all(sha(p)==v for p,v in pins.items())
 receipt=read(W/'commit-receipt.json');need(receipt['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED'and receipt['both_clean']and receipt['canonical_promoted']and receipt['checkout_preparation_pending']and not receipt['error']and not receipt['finalization_errors'],'completed reviewed source checkpoint')
 expected=read(m.DONORP/'prepare-result.json')['files'];baseline=read(m.DONOR/'plan.json')['baseline_prepared']
 d=dict(result='INCOMPLETE',source_commit=receipt['commit'],inputs=pins,readiness_sha256=reviewsha,commands=[],error=None,finalization_errors=[],native_execution='not_started',expected_prepared_files=6250,checkout_preparation_pending=True)
 def source_status():
  for root in [C,T]:
   need(m.git(root,'rev-parse','HEAD').decode().strip()==receipt['commit']and not m.git(root,'status','--porcelain','-z'),'clean committed checkout')
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not m.stopped(phase),'postcommit preparation admission');source_status()
   need(len(expected)==6250 and len(baseline)==6249 and vector(T)==vector(C)==baseline and m.module_identity(m.MODULES)==expected,'old checkout and tested new module vectors')
   for label,root in [('candidate',T),('canonical',C)]:
    need(not(root/'drivers/cogent/build/.prepare-lock').exists(),'no existing preparation owner')
    run=g.execute(h.environment()+[str(h.PYTHON),'-B',str(root/'drivers/cogent/prepare.py')],root,P/('prepare-install-'+label),lambda:m.stopped(phase),stable,timeout=180,limit=8<<20)
    d['commands'].append(dict(name='prepare-install-'+label,run=run));need(h.terminal(run),'owned preparation '+label)
    need(vector(root)==expected,'installed exact tested vector '+label);source_status()
   need(stable()and not m.stopped(phase)and lease.held()and vector(T)==vector(C)==expected,'terminal source/preparation closure')
   d.update(checkout_preparation_pending=False,both_prepared_equal_tested_vector=True,source_files=receipt['source_files'],prepared_files=6250)
 except BaseException as error:d['error']=dict(type=type(error).__name__,message=str(error))
 finally:h.finish(phase,d)
if __name__=='__main__':main()
