"""Install reviewed native evidence and stage the exact implementation checkpoint."""
from pathlib import Path
import hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='e96f642fd1a3620ff16ca7858f991a421fcf5fda'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=60)
def main():
 assert not(W/'binding.json').exists()
 review=read(W/'report-review.json');assert review['report_ready']and not review['unresolved_findings']and all(sha(p)==h for p,h in review['inputs'].items())
 assert not git(C,'status','--porcelain','-z')and not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
 assert all(git(root,'rev-parse','HEAD').decode().strip()==HEAD for root in [C,T])
 stage=read(W/'source-stage.json');assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(stage['files'])and hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==stage['staged_diff_sha256']
 assert all(sha(T/n)==h for n,h in stage['sources'].items())
 report=W/'report';manifest=read(report/'evidence.manifest.json');assert manifest['archive']==dict(bytes=(report/'evidence.tar.xz').stat().st_size,sha256=sha(report/'evidence.tar.xz'))
 assert read(report/'result.json')['result']=='PASS_STAGE_0077_AND_NATIVE_IMAGING'
 target=Path('docs/reports/macos-event-publication');assert not(T/target).exists()
 sources={n:(T/n).read_bytes()for n in stage['files']}
 sources.update({str(target/n):(report/n).read_bytes()for n in ['README.md','result.json','evidence.manifest.json','evidence.tar.xz']})
 name='docs/reports/README.md';text=(C/name).read_text();needle='- [Clean private SDK native consumer]';assert text.count(needle)==1
 sources[name]=text.replace(needle,'- [Key-event publication ownership and native imaging](macos-event-publication/README.md)\n\n'+needle,1).encode()
 paragraph='''The [key-event publication and imaging checkpoint](%s)
fixes the native race in which Source.Key read an event after queue ownership
transferred to the render consumer. Stage 0077 uses original code/modifier
arguments and preserves chord, keypad, NumLock and injected-clock semantics.
A joined 128-key producer/consumer regression reproduces the old-source race
and passes with the fix; a twelve-case chord matrix and preparation checks pass.
The isolated native imaging assertions cover compute/HDR/partial alpha, capture
lifetime, independent windows, resize/rebuild/minimize and closure, with the
worker joined before fixture geometry restoration. Original native exit66 and
the overly broad Unix-socket sandbox failure remain failed. Completed driver
package outcomes are reused exactly; the entire failed workbench package passes
under IP denial with Unix IPC allowed. One Anthropic Claude Sonnet 5.5 Prism
checkpoint covers thirteen source/test/spec leaves, with internal reviews.
Tests use a fresh pinned 6250-file dependency reconstruction and exact private
ARM64 static GPU linkage. SDK refresh, physical interaction, presentation,
ordinary latency, native/GPU memory, endurance, human input/accessibility,
component/rights closure, public release and full Mac qualification remain open.
'''
 name='docs/implementation.md';sources[name]=((C/name).read_text()+'\n'+paragraph%'reports/macos-event-publication/README.md').encode()
 name='specs/macos-completion.md';text=(C/name).read_text();needle='## Latest unattended evidence\n\n';assert text.count(needle)==1
 sources[name]=text.replace(needle,needle+paragraph%'../docs/reports/macos-event-publication/README.md'+'\n',1).encode()
 links=0
 for name,body in sources.items():
  if not name.endswith('.md'):continue
  for destination in re.findall(r'\[[^\]]*\]\(([^\n)]+)\)',body.decode()):
   destination=destination.strip('<>').split('#',1)[0]
   if not destination or ':'in destination or destination.startswith('/'):continue
   path=(C/name).parent.joinpath(destination).resolve();relative=str(path.relative_to(C));assert relative in sources or path.exists(),(name,destination);links+=1
 for name,body in sources.items():
  path=T/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
 changed=set(git(T,'diff','HEAD','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(sources)and len(sources)==20
 git(T,'add','--',*sorted(sources));git(T,'diff','--cached','--check')
 assert not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')and set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(sources)
 diff=git(T,'diff','--cached','--binary');(W/'staged.diff').write_bytes(diff)
 binding=dict(base_commit=HEAD,sources={n:sha(T/n)for n in sources},staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(diff),source_files=4738,prepared_files=6249,relative_file_links=links,source_provider_stage_sha256=sha(W/'source-stage.json'))
 assert len(git(T,'ls-files','-z').decode().split('\0')[:-1])==4738
 with(W/'binding.json').open('x')as output:output.write(json.dumps(binding,indent=2)+'\n')
 print(json.dumps(dict(result='STAGED_EXACT_TWENTY_CHECKPOINT_FILES',files=len(sources),bytes=len(diff),sha256=binding['staged_diff_sha256'],links=links)))
if __name__=='__main__':main()
