from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
b=json.loads((W/'source-binding.json').read_text());r=json.loads((W/'result-review.json').read_text());assert r['result_ready']and not r['unresolved_findings']
assert not(W/'source-stage.json').exists()and not git(T,'diff','--cached','--name-only')and not git(C,'status','--porcelain','-z')
assert git(T,'rev-parse','HEAD').decode().strip()==git(C,'rev-parse','HEAD').decode().strip()==b['base_commit']
assert (set(git(T,'diff','HEAD','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines()))==set(b['after'])and len(b['after'])==13
assert all(sha(T/n)==h for n,h in b['after'].items())
subprocess.run(['git','add','--',*b['after']],cwd=T,check=True,timeout=30)
assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(b['after'])and not git(T,'diff','--name-only')
raw=git(T,'diff','--cached','--binary');assert 0<len(raw)<120000
with(W/'source-staged.diff').open('xb')as out:out.write(raw)
d=dict(files=list(b['after']),sources=b['after'],staged_diff_bytes=len(raw),staged_diff_sha256=hashlib.sha256(raw).hexdigest(),base_commit=b['base_commit'],producer_sha256=sha(__file__))
with(W/'source-stage.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(result='STAGED_EXACT_THIRTEEN_SOURCE_SPEC_FILES',bytes=len(raw),sha256=d['staged_diff_sha256'])))
