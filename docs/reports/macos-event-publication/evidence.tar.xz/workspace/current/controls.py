"""Imaging summary controls: no model process or native application is executed."""
from pathlib import Path
import copy,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('imaging_controls',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
record=dict(event='vellum.imaging.smoke',result='pass',geometry_persistence_disabled_in_fixture=True,exposure1=dict(R=213,G=156,B=0,A=128),exposure2=dict(R=231,G=188,B=0,A=128),initial=dict(BufferBytes=1048608,TextureBytes=524288),deliveryAfterResize=False,normalClose=dict(callbackCount=0))
for key in ['transparentTop','nativeAdmissionRefusals','explicitSyncThenAsync','partialAlpha','busyInsideCallback','independentResources','quietCancelRebuildClose']:record[key]=True
for key in ['nativeClosed','nativeDrawingLockRefused','windowLifetimeCanceled','appLifetimeCanceled','unregistered','programReleased']:record['normalClose'][key]=True
encode=lambda value:(json.dumps(value)+'\n').encode()
checks=[]
for overlap in [False,True]:
 value=dict(record,deliveryAfterResize=overlap);assert m.validate('imaging',encode(value),b'')==value;checks.append('accepts actual overlap='+str(overlap))
cases=[]
value=copy.deepcopy(record);value['normalClose']['callbackCount']=1;cases.append(('rejects canceled callback delivery',encode(value),b''))
value=copy.deepcopy(record);value['exposure2']['A']=255;cases.append(('rejects lost partial alpha',encode(value),b''))
value=dict(record,geometry_persistence_disabled_in_fixture=1);cases.append(('rejects numeric isolation flag',encode(value),b''))
cases += [('rejects extra diagnostic',encode(record),b'unexpected GPU failure\n'),('rejects duplicate summary',encode(record)*2,b''),('rejects missing summary',b'',b'')]
for name,stdout,stderr in cases:
 try:m.validate('imaging',stdout,stderr)
 except ValueError:checks.append(name)
 else:raise AssertionError(name)
result=dict(result='PASS_IMAGING_SUMMARY_CONTROLS',count=len(checks),checks=checks,runner_sha256=m.sha(W/'run.py'),producer_sha256=m.sha(__file__),native_executed=False,child_process_created=False)
with(W/'controls.json').open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['checks']}))
