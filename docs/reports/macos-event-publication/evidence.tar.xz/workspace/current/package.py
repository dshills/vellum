"""Package scoped native imaging evidence, preserving the initial source finding."""
from pathlib import Path
import hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-event-transport-e96f642');T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=W/'report'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
MAX_MEMBERS=384;MAX_EXPANDED=256<<20;MAX_COMPRESSED=32<<20
def need(ok,msg):
 if not ok:raise ValueError(msg)
class BoundedWriter:
 def __init__(self,stream,bound):self.stream,self.bound=stream,bound
 def write(self,body):
  need(self.stream.tell()+len(body)<=self.bound,'compressed evidence byte bound')
  return self.stream.write(body)
 def tell(self):return self.stream.tell()
 def flush(self):return self.stream.flush()
def main():
 need(not R.exists(),'fresh evidence output')
 body=(W/'report-review.json').read_bytes();review_sha=hashlib.sha256(body).hexdigest();review=json.loads(body)
 need(review['report_ready']and not review['unresolved_findings'],'independent report review')
 stable=lambda:sha(W/'report-review.json')==review_sha and all(sha(p)==h for p,h in review['inputs'].items())
 need(stable(),'reviewed report closure')
 build=read(W/'build.json');native=read(W/'native-imaging.json');provider=read(W/'prism/receipt.json');assessment=read(W/'provider-assessment.json')
 need(build['result']=='PASS_BUILD'and native['result']=='PASS_NATIVE-IMAGING','actual scoped passes')
 need(provider['result']=='COMPLETE_SCOPED_PROVIDER_REVIEW'and provider['coverage']['llmCalls']==1,'one complete checkpoint review')
 need(assessment['assessment_complete']and assessment['accepted']and assessment['reporting_ready']and not assessment['source_change_required']and not assessment['additional_provider_call_required']and not assessment['unresolved_findings'],'independent provider finding disposition')
 need(assessment['raw_report_sha256']==sha(W/'prism/prism.json')and assessment['provider_cli_exit_code']==1,'raw provider finding and exit preserved')
 need('PENDING'not in(W/'README.final.md').read_text(),'completed report prose')
 entries={};runs=[]
 def add(name,path):
  p=Path(path);need(name not in entries and p.is_file()and not p.is_symlink()and p.stat().st_size<=32<<20,'unique regular bounded member');entries[name]=p
 for label,workspace in [('initial-source-review',W.parent/'macos-imaging-native-e96f642'),('native-race',W.parent/'macos-imaging-native-e96f642-v2'),('unix-denial',W.parent/'macos-event-publication-e96f642'),('current',W)]:
  for path in sorted(workspace.rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(workspace)
   if any(part.startswith('checkpoint-')or part in ['report','__pycache__','commit-logs']for part in relative.parts):continue
   if workspace!=W and relative.as_posix()in ['package.py','stage.py','stage-source.py','commit.py','checkpoint.py','prism_review.py','prism-rules.json','README.draft.md']:continue
   add('workspace/'+label+'/'+relative.as_posix(),path)
 for label,workspace,root,native_case in [('native-race',W.parent/'macos-imaging-native-e96f642-v2',Path('/private/tmp/vellum-imaging-native-e96f642-v2'),True),('unix-denial',W.parent/'macos-event-publication-e96f642',Path('/private/tmp/vellum-event-publication-e96f642'),False),('current',W,P,True)]:
  prior=read(workspace/'build.json');commands=list(prior['commands'])
  if native_case:commands.append(dict(name='native-imaging',run=read(workspace/'native-imaging.json')['run']))
  if label=='native-race':need(prior['result']=='PASS_BUILD'and read(workspace/'native-imaging.json')['result']=='FAILED_NATIVE-IMAGING'and commands[-1]['run']['exit_code']==66,'original native race failure preserved')
  if label=='unix-denial':need(prior['result']=='FAILED_BUILD'and commands[-1]['name']=='driver-race'and commands[-1]['run']['exit_code']==1,'original full driver command remains failed')
  for command in commands:
   run=command['run'];need(run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'retained command retirement')
   for name in ['stdout','stderr','owned.json']:
    path=root/command['name']/name
    if name in run['logs']:need(run['logs'][name]==dict(bytes=path.stat().st_size,sha256=sha(path)),'exact raw command log')
    add('runs/'+label+'/'+command['name']+'/'+name,path)
   runs.append(dict(phase=label,name=command['name'],exit_code=run['exit_code'],group=run['group'],seconds=run['seconds']))
  for item in prior['binaries']:add('linkmaps/'+label+'/'+item['name']+'.linkmap',item['linkmap']['path'])
  for name in ['imaging.mod','imaging.sum','driver.mod','driver.sum','core.mod','core.sum','old-source.json','prepare-result.json']:
   if(root/name).is_file():add('private-inputs/'+label+'/'+name,root/name)
 diagnostic=Path('/private/tmp/vellum-event-publication-e96f642/driver-race-diagnostic')
 for path in sorted(diagnostic.iterdir()):
  if path.is_file():add('supplementary-unsymbolized-diagnostic/'+path.name,path)
 binary=build['binaries'][0]
 sdk=Path(read(W/'plan.json')['sdk_root']);lib=sdk/'drivers/cogent/build/libs-darwin'
 for name in ['SDK_MANIFEST.json','THIRD_PARTY_INVENTORY.json']:add('sdk/'+name,sdk/name)
 for name in ['go.mod','libs.go','PROVENANCE.json']:add('sdk-capsule/'+name,lib/name)
 helpers={'retained_parent.py':W.parent/'macos-source-gpu-sdk-native/run.py','owned_process.py':W.parent/'macos-sdk-native-238b3b6/run.py','live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')}
 for name in ['child_process.py','sdk_environment.py','native_archive.py','native_gpu.py','check-sdk.py']:helpers[name]=T/'scripts'/name
 helpers.update({'prism-retirement-helper.py':W.parent/'macos-source-built-gpu-276a654/fetch_dependencies.py','commit-git-guard.py':W.parent/'macos-grid-native-stacks/commit-pending.py','historical-executor-controls-run.py':W.parent/'macos-sdk-native-238b3b6/blocked-v2/run.py'})
 for name,path in helpers.items():add('helpers/'+name,path)
 for label,workspace,stems in [('retained-sdk',W.parent/'macos-source-gpu-sdk-native',['controls']),('owned-executor',W.parent/'macos-sdk-native-238b3b6',['controls-v2','fault-controls','finalization-controls'])]:
  for stem in stems:
   for suffix in ['.py','.json']:add('reused-controls/'+label+'/'+stem+suffix,workspace/(stem+suffix))
 index={n:dict(bytes=p.stat().st_size,sha256=sha(p))for n,p in sorted(entries.items())}
 need(len(index)<=MAX_MEMBERS and sum(v['bytes']for v in index.values())<=MAX_EXPANDED,'finite evidence bounds')
 principal=[Path(binary['path']),Path('/private/tmp/vellum-imaging-native-e96f642-v2/imaging'),Path('/private/tmp/vellum-source-gpu-sdk-native/sdk.tar.gz'),lib/'arm64/libwgpu_native.a']
 excluded=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in principal]
 R.mkdir()
 with(R/'evidence.tar.xz').open('xb')as raw:
  with tarfile.open(fileobj=BoundedWriter(raw,MAX_COMPRESSED),mode='w:xz',preset=6)as archive:
   for name,path in sorted(entries.items()):
    data=path.read_bytes();need(hashlib.sha256(data).hexdigest()==index[name]['sha256'],'stable member origin')
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
 with tarfile.open(R/'evidence.tar.xz','r:xz')as archive:
  need(archive.getnames()==sorted(index),'exact archive members')
  for item in archive:
   data=archive.extractfile(item).read();need(len(data)==index[item.name]['bytes']and hashlib.sha256(data).hexdigest()==index[item.name]['sha256'],'archive readback identity')
 evidence=dict(files=index,archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz')),limits=dict(members=MAX_MEMBERS,expanded_bytes=MAX_EXPANDED,compressed_bytes=MAX_COMPRESSED,member_bytes=32<<20),excluded_principal_artifacts=excluded,other_exclusions='Caches, temp files and unrelated data omitted. Principal binary, private SDK and archive remain at recorded roots and are copied to the local checkpoint after commit.')
 (R/'evidence.manifest.json').write_text(json.dumps(evidence,indent=2)+'\n')
 result=dict(result='PASS_STAGE_0077_AND_NATIVE_IMAGING',source_commit=build['source_commit'],source_state='thirteen exact reviewed source/test/spec leaves before commit',new_sdk_archive=False,sdk_baseline_counterparts=7027,compiled_stage_0077_separately_bound=True,reused_reconstructed_prepared_files=6250,checkout_preparation='separate postcommit receipt; checkout prepared trees unchanged during tests',binary=binary,native_record=native['record'],runs=runs,donor_event_and_driver_review_sha256=sha(W.parent/'macos-event-publication-e96f642/result-review.json'),provider=provider,provider_assessment_sha256=sha(W/'provider-assessment.json'),provider_finding_dispositions=assessment['findings'],raw_provider_cli_exit_code=assessment['provider_cli_exit_code'],unresolved_provider_findings=assessment['unresolved_findings'],report_review_sha256=review_sha,distinct_summary_control_cases=8,summary_controls_reexecuted_without_recount=True,new_regression_roots=3,worker_subcases=2,chord_subcases=12,acknowledged_keys=128,guard_controls_reused=27,original_failed_endpoints_preserved=True,old_source_negative_control_expected_failure=True,driver_full_command_remains_failed=True,successful_driver_outcomes_reused_only_as_package_scoped_evidence=True,failed_workbench_package_rerun_whole=True,supplementary_native_sample='one unsymbolized sample; no causal or timing inference',settings_changes=False,physical_input_generated=False,presentation_qualified=False,ordinary_frame_latency_qualified=False,native_gpu_memory_qualified=False,endurance_qualified=False,full_macos_qualified=False,public_distribution_qualified=False)
 (R/'result.json').write_text(json.dumps(result,indent=2)+'\n');(R/'README.md').write_bytes((W/'README.final.md').read_bytes())
 need(stable(),'terminal report certificate/source stability')
 print(json.dumps(dict(result='PACKAGED_EVENT_PUBLICATION_AND_NATIVE_IMAGING_EVIDENCE',members=len(index),expanded_bytes=sum(v['bytes']for v in index.values()),archive=evidence['archive'])))
if __name__=='__main__':main()
