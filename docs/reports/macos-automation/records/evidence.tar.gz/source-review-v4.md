# Automation V4 UI-preservation leaf review

Result: APPROVED_SOURCE. All 26 frozen source-v4 snapshots and current selected files match the freeze map. Exactly one path differs from approved V3: drivers/cogent/cmd/workbench/main.go. Removing the three added component-prefix guard lines reproduces the V3 file byte-for-byte.

The UI-only selectID wrapper returns for non-component outline identities before invoking the strict component selector, so selecting project/group nodes does not turn a legitimate outline selection into an error status. Component IDs still pass through componentIndex, epoch exhaustion checks and the existing table/board selection updates. This is a narrow source-level preservation check, not a live UI claim.

The remote component.select action receives selectComponent directly at Workbench startup, not the permissive UI wrapper. It therefore continues to reject invalid/noncanonical component identities and advance the guarded selection revision on accepted changes. automation.go is unchanged.

All V3 protocol, transient-accept/backoff, lifetime tests and specs are unchanged. Provider finding 4086271e3b54a6eb remains ACCEPTED_FIXED under the preserved V3 source review. Raw Prism remains the earlier complete 25-file V2 review with exit 1/one valid finding; this V4 UI leaf was internally reviewed and was not sent in a new provider call.

The V4 Workbench test/native compile, package and relocated SDK check are separate parent gates. This certificate does not infer pending successes or relabel earlier V2/V3 artifact results as V4. No implementation execution, test, build, native UI/input/preferences, provider or Git operation was performed. Broader Mac/workflow/performance/distribution acceptance remains outside scope.
