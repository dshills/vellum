import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
repo=Path('/private/tmp/vellum-large-data');phase=Path('/private/tmp/vellum-macos-automation')
report=repo/'docs/reports/macos-automation';records=report/'records'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((phase/'source-v4.json').read_text())
assert all(sha(repo/n)==h for n,h in source['sources'].items())
assert not subprocess.check_output(['git','diff','--name-only'],cwd=repo)
review=json.loads((phase/'source-review-v4.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings'] and review['files']==source['sources']
assert json.loads((phase/'source-review-v3.json').read_text())['finding_resolution']=='ACCEPTED_FIXED'
prepared=json.loads((phase/'prepared-identity.json').read_text())['files']
current={p.relative_to(repo/'drivers/cogent/build').as_posix():sha(p) for m in ['upstream','typesetting'] for p in sorted((repo/'drivers/cogent/build'/m).rglob('*')) if p.is_file()}
assert current==prepared and len(current)==6172
checks=['root-final-v3','root-vet-v3','workbench-final-v4','workbench-vet-v4','native-build-v4','sdk-final-v3','sdk-vet-final','release-sdk-tests','sdk-package-v4','sdk-check-v4']
process={}
for n in checks:
 d=json.loads((phase/(n+'.json')).read_text());assert d['exit_code']==0 and d['error'] is None and d['live_tests'] is False,n
 for stream in ['stdout','stderr']:assert sha(phase/(n+'.'+stream))==d[stream+'_sha256']
 process[n]=d
sdk=json.loads((phase/'sdk-current-identity.json').read_text());manifest=json.loads((phase/'private-sdk-current-manifest.json').read_text())
assert sdk['files']==6904 and sdk['exact_final_sources_match']
assert all(manifest['files'][n]==h for n,h in source['sources'].items())
assert sha(phase/'private-sdk-current.tar.gz')==sdk['sha256']
raw=(phase/'sdk-check-v4.stdout').read_text();sdk_check=json.loads(raw[raw.rfind('\n{')+1:] if '\n{' in raw else raw)
assert sdk_check['archive_sha256']==sdk['sha256'] and sdk_check['verified_files']==6904 and sdk_check['digest_verified_against_expected'] and sdk_check['path_contains_spaces']
assert sdk_check['native_runtime']=='not executed' and sdk_check['public_distribution_audit']=='not certified'
prism=json.loads((phase/'prism-v1/prism.json').read_text());prism_process=json.loads((phase/'prism-v1/process.json').read_text())
assert prism['coverage']['complete'] and prism['coverage']['files']==25 and prism['coverage']['chunks']==5 and not prism['coverage']['excluded'] and not prism['coverage']['skipped'] and prism['coverage']['truncatedBytes']==0
assert prism_process['source_index_stable'] and prism_process['exit_code']==1 and len(prism['findings'])==1 and prism['findings'][0]['id']=='4086271e3b54a6eb'
v2=json.loads((phase/'source-v2.json').read_text())['sources'];assert prism_process['before']==v2 and prism_process['after']==v2
q={'result':'PASS_HEADLESS_MAC_AUTOMATION','base_commit':source['base_commit'],'source':source['sources'],'prepared':prepared,'process':process,'sdk':sdk,'sdk_check':sdk_check,'prism_findings':1,'prism_finding':'4086271e3b54a6eb','prism_resolved_by_internal_review':True,'source_review_sha256':sha(phase/'source-review-v4.json'),'native_binary_sha256':sha(phase/'workbench-v4'),'live_tests':False,'whole_macos_completion':False,'performance_acceptance':False,'distribution_audit':'pending'}
(phase/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
(phase/'reader-schema-incident.json').write_text(json.dumps({'result':'RESOLVED_READER_ASSUMPTION','incorrect_assumption':'SDK_MANIFEST.files values were treated as objects containing sha256; actual schema is a name-to-hex-string map.','source_changed':False,'corrected_identity_sha256':sha(phase/'sdk-current-identity.json')},indent=2)+'\n')
records.mkdir(parents=True,exist_ok=False)
excluded={'workbench','workbench-final','workbench-v3','workbench-v4','private-sdk.tar.gz','private-sdk-final.tar.gz','private-sdk-current.tar.gz'}
members={p.relative_to(phase).as_posix():{'size':p.stat().st_size,'sha256':sha(p)}for p in sorted(phase.rglob('*'))if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts}
archive=records/'evidence.tar.gz'
with archive.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0)as z,tarfile.open(fileobj=z,mode='w',format=tarfile.PAX_FORMAT)as t:
 for name in members:
  data=(phase/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';t.addfile(info,io.BytesIO(data))
index={'schema':1,'members':members,'archive_sha256':sha(archive),'excluded_binary_and_sdk_payloads':sorted(excluded)}
(records/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
checkpoint={'result':q['result'],'base_commit':q['base_commit'],'qualification_sha256':sha(phase/'qualification.json'),'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_coverage_complete':True,'prism_findings':1,'prism_findings_resolved':True,'archive':{'sha256':sha(archive),'members':len(members)},'live_tests':False,'macos_completion':False}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
(report/'README.md').write_text('''# Mac semantic automation checkpoint

Vellum now has an explicitly enabled Mac-local semantic endpoint. Applications
register typed queries/actions, provide a revision identity and start a private
Unix socket with a random capability. Ordinary imports/workbench startup open no
endpoint. `-automation` enables the workbench's named domain bindings and emits a
credential descriptor only to its invoking process.

The endpoint serializes domain work through Application.Post, checks expected
revisions, rejects malformed/stale/unknown requests and retains eight combined
transport/owner credits until accepted work skips/returns or its owner closes.
Socket/directory modes are 0600/0700. Response JSON and scalar audit retention are
bounded; callbacks own their allocations/time and explicitly redact their DTOs.
Cancellation is cooperative after handler entry, without rollback/deduplication.
Request contexts retire on connection completion; applications deliberately use
their application/window lifetime when admitting jobs that should outlive an RPC.

Workbench inspection reads selected or stable virtual component IDs without a
render/owner scan. Selection uses the shared validated UI selection function;
rotate/raise/Undo/Redo reuse command availability and document history. A literal
redacted document path accompanies count/availability metadata. Source, selection
and reference epochs prevent stale ABA requests. Epoch exhaustion refuses before
mutation. Native outline group selection retains its prior noncomponent behavior.
These DTOs describe application state, not current native frames or accessibility.

Twenty automation test functions cover real headless Mac sockets and injected
policy errors, including credentials/permissions, strict wire parsing, typed
actions, stale revisions, queue/credit retention, disconnect, half-close/second
message cancellation, window-scoped retirement, panic teardown, redaction, audit/
response limits, constructor/copy refusal and owned path replacement. Two actual
workbench domain tests and an independent public typed consumer also pass. Root
race/vet, the complete offscreen driver suite before the bounded correction, final
affected-workbench race/vet, native workbench compilation and the 28 SDK producer
tests pass. Final root/consumer checks cover the transport correction. Native
compiled binaries are never run by this checkpoint.

The final private SDK verifies all 6904 identities with trusted digest
`40705fd4dc37504741b5d76f69789760d6113618ecc572a0b96b306e11e35f2c`.
The extracted path contains spaces, all four module replacements remain inside
the SDK, and external module verification plus generated consumer race/vet/build
and public API scenarios pass. All 26 final source hashes match the shipped
manifest; all 6172 prepared bytes remain equal to the preceding checkpoint.
Native runtime is explicitly not executed; this is not independent authenticity,
redistribution rights, signing/notarization or full Mac qualification.

Internal V1 review found a client-dial deadline gap, zero-Registry panic and audit
publication after EOF. V2 fixes them with pre-dial cancellation, constructor/self
guards and pre-EOF terminal audit. One Prism run used Anthropic Claude Sonnet 5.5
with complete 25-file/five-chunk coverage and raw exit 1/one medium finding
4086271e3b54a6eb: transient accept errors retired the endpoint. Wrapped resource/
aborted/temporary accept errors now retry with cancellation-aware 5 ms through
1 s capped backoff; permanent errors remain observable through Server.Err.
Independent V3 review accepts that exact fix; V4 approves the final UI-preservation
leaf. No second provider review was run for the bounded corrections.

Initial development receipts remain distinct: workbench/consumer compile fixes,
two new-test attempts copying an active Server mutex, and a resolved manifest
reader schema assumption. Those failures are not final qualification. Copying
active synchronizing values remains unsupported; the final fixture snapshots
shared resources under lock without copying the live mutex. Original failing
source variants for every development receipt are not all frozen.

This checkpoint launches no native UI/input/performance campaign and changes no
clipboard, input source, VoiceOver, display or power preferences. Live checks stay
deferred until the user explicitly says the computer is free. Broader professional
automation/replay, human/native accessibility/input/services, sustained performance,
GPU/DPI/memory/lifetime and distribution acceptance remain open.

[Checkpoint](records/checkpoint.json), [raw evidence](records/evidence.tar.gz)
and [member index](records/archive-index.json) bind this headless source/tooling scope.
''')
print(json.dumps({'result':q['result'],'members':len(members),'archive_sha256':sha(archive),'report_sha256':sha(report/'README.md'),'checkpoint_sha256':sha(records/'checkpoint.json')}))
