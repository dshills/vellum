# Automation V1 source review

Result: NEEDS_FIX. This review binds the 20 immutable source-v1 snapshots and their freeze map, not the corrected checkout.

Call applies its one-minute limit only after dialing; a deadline-free connect can exceed the documented client limit. Zero Registry registration can assign a nil map and panic. The terminal audit is published after connection close, so successful Call and the immediate audit assertion can race publication. The latter is an observation/test timing issue, not a domain mutation defect.

The remaining bounded owner transport, combined-credit retention, strict envelope decoding, detached observations, command availability and monotonic Workbench source/selection/reference guards are coherent at the inspected V1 scope. No further blocking logic issue was established. Populated handle copies need an explicit unsupported-copy contract; a self identity guard does not permit copying an active mutex.

The parent is correcting these issues plus the known status/heading and exported-SDK whitelist fixture gaps. V1 is retained as NEEDS_FIX; it must not be relabeled as the later corrected version.

Recorded root/workbench/independent-SDK/full-offscreen-driver race and three vet receipts have zero exit codes and matching raw logs. Earlier unused-import and package-mismatch compile failures remain explicit. These are recorded headless results, without a reviewer rerun or compiler/SDK closure assertion. No native UI, provider, performance or broader Mac acceptance is certified.
