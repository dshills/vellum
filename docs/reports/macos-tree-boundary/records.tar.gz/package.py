from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,tarfile
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');F=T/'docs/reports/macos-tree-boundary';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((W/'plan.json').read_text());a=json.loads((W/'assessment.json').read_text());assert a['result']=='VERIFIED_FOUR_TREE_BOUNDARY_OBSERVATIONS'and(W/'stop-native').exists()
prism=json.loads((W/'prism.json').read_text());assert prism['coverage']['complete']and prism['coverage']['llmCalls']==1 and[x['id']for x in prism['findings']]==['c695e24c67b50baf'];assert json.loads((W/'prism-disposition.json').read_text())['addressed'];assert json.loads((W/'internal-results-review.json').read_text())['approved'];assert json.loads((W/'internal-prose-review.json').read_text())['approved'];assert json.loads((W/'internal-prism-closure.json').read_text())['approved']
shared=W/'shared';shared.mkdir();mapping={}
for i,(source,digest)in enumerate(sorted(p['pins'].items())):
 src=Path(source);assert sha(src)==digest;name=f'{i:02d}-'+src.name;shutil.copyfile(src,shared/name);mapping[source]={'stored':name,'sha256':digest}
sdk=Path(p['sdk']);shutil.copyfile(sdk/'SDK_MANIFEST.json',shared/'sdk-manifest.json');assert sha(shared/'sdk-manifest.json')==p['sdk_files']['SDK_MANIFEST.json'];(shared/'sources.json').write_text(json.dumps(mapping,indent=2)+'\n')
diff=subprocess.check_output(['git','diff','--cached','--binary'],cwd=T,timeout=30);(W/'final-docs.diff').write_bytes(diff)
checks={'scope':'Unchanged SDK4treeboundaryobservations,nextboundedretainedtree/local-layout decision only','source_sdk':p['source_sdk'],'calling_head':p['calling_head'],'ordinary_runs':2,'ordinary_samples_per_run':240,'diagnostic_runs':2,'diagnostic_samples_per_run':120,'warmup_per_run':128,'ordinary_p95_target_passes':0,'native_execution_failures':0,'postprocessor_failures_preserved':1,'prism_calls':1,'prism_raw_exit_code':1,'prism_retained_medium':1,'prism_addressed':['c695e24c67b50baf'],'closed_mac_gates':[],'prototype_implemented':False,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(W/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
files={};sources={}
for leaf in sorted(W.rglob('*')):
 assert not leaf.is_symlink(),leaf
 if not leaf.is_file()or '__pycache__'in leaf.parts or leaf.name.startswith('stop-')or leaf.name=='report-draft.md':continue
 assert leaf.stat().st_size<8<<20,(leaf,leaf.stat().st_size);name=leaf.relative_to(W).as_posix();files[name]={'bytes':leaf.stat().st_size,'sha256':sha(leaf)};sources[name]=leaf
assert len(files)<150 and sum(x['bytes']for x in files.values())<40<<20
archive=F/'records.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for name,leaf in sources.items():tar.add(leaf,arcname=name,recursive=False)
assert archive.stat().st_size<10<<20;record={'archive':archive.name,'archive_sha256':sha(archive),'files':files};(F/'records.json').write_text(json.dumps(record,indent=2)+'\n')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile()and member.name in files;data=tar.extractfile(member).read();assert len(data)==files[member.name]['bytes']and hashlib.sha256(data).hexdigest()==files[member.name]['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files),'sha256':record['archive_sha256']}))
