from pathlib import Path
import hashlib,importlib.util,json
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('tree_assessment',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);h=m.h
p=json.loads((W/'plan.json').read_text());sdk=Path(p['sdk']);m.clean();assert m.vector(sdk)==p['sdk_files'];assert h.sha(p['binary']['path'])==p['binary']['sha256'];assert all(h.sha(k)==v for k,v in p['pins'].items());assert not(W/'stop-native').exists()
assert not any(k in m.g.ordinary_environment()for k in ['GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GORACE'])
original=Path(h.GUARD).read_text();replacement=original.replace("env={**child_environment(True), 'GOMAXPROCS':'2'}",'env=ordinary_environment()');assert(W/'owned-executor.py').read_text().startswith(replacement)
runs={};layouts=None;groups={}
for name,case in m.CASES.items():
    d=json.loads((W/(name+'-result.json')).read_text());r=d['run'];assert d['result']=='PASS_SCOPED_TREE_FRAME_OBSERVATION' and d['error']is None and d['lease_held_through_cleanup'] is True
    assert r['created']and r['exit_code']==0 and not r['error']and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit'];assert r['pid']==r['group']==r['owned']['pid']==r['owned']['group'] and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
    assert r['argv']==[p['binary']['path'],*case['args']]and r['watchdog_seconds']==330 and(W/('stop-'+name)).exists()
    for channel in ['stdout','stderr']:
        f=W/name/channel;assert r['logs'][channel]=={'bytes':f.stat().st_size,'sha256':h.sha(f)}
    assert not(W/name/'stderr').read_bytes();summary=json.loads(json.dumps(m.v.validate((W/name/'stdout').read_text(),case,sdk)));assert summary==d['summary']
    if layouts is None:layouts=summary['phase_geometry']
    else:assert layouts==summary['phase_geometry'],name
    groups[name]=m.g.absent(r['group']);runs[name]={'seconds':r['seconds'],'pid':r['pid'],'summary':{k:v for k,v in summary.items()if k!='phase_geometry'}}
prepared={}
for root in [h.C,h.T]:
    files={n+'/'+f.relative_to(root/'drivers/cogent/build'/n).as_posix():h.sha(f)for n in ['upstream','typesetting']for f in(root/'drivers/cogent/build'/n).rglob('*')if f.is_file()};digest=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert len(files)==6260 and digest=='1d9861ac10a0d83f607a36fd70dc79f00ce51d427c792b30b6a1331c0c3451ba';prepared[str(root)]={'files':len(files),'sha256':digest}
d={'result':'VERIFIED_FOUR_TREE_BOUNDARY_OBSERVATIONS','source_sdk':p['source_sdk'],'calling_head':p['calling_head'],'runs':runs,'ordinary_samples':480,'diagnostic_samples':240,'geometry_matches_all_four_cases':True,'groups':groups,'prepared':prepared,'closed_mac_gates':[],'ordinary_acceptance_matrix_qualified':False,'full_tree_qualified':False,'full_mac_qualified':False}
(W/'assessment.json').write_text(json.dumps(d,indent=2)+'\n');(W/'stop-native').touch();print(json.dumps({'result':d['result'],'ordinary_samples':480,'diagnostic_samples':240,'groups_absent':len(groups)}))
