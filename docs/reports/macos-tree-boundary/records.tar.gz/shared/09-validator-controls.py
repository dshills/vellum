"""Pure validator controls using a labeled historical frame-shape fixture."""
from pathlib import Path
import copy, hashlib, importlib.util, json
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('tree_controls',W/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
q=json.loads((m.PRE/'consume-plan.json').read_text());sdk=Path(q['sdk']);raw=W/'control-fixture.stdout'
events=[json.loads(line) for line in raw.read_text().splitlines()];events[0]['go_version']='go1.25.6'
for e in events:
    e['gpu_scene_rendering']=False;e['source_details']=False
case=m.CASES['cpu-ordinary'];render=lambda e:'\n'.join(json.dumps(x) for x in e)
base=m.v.validate(render(events),case,sdk);assert base['samples']==240
mutations={}
for name in ['duplicate-callback','generation-drift','work-sum-drift','offset-drift','small-workload','missing-terminal','diagnostics-in-ordinary','wrong-font']:
    e=copy.deepcopy(events);row=e[4]
    if name=='duplicate-callback':row['tree_notifications']=2
    if name=='generation-drift':row['frame']['Generation']+=1
    if name=='work-sum-drift':row['frame']['TotalUIWorkNS']+=1
    if name=='offset-drift':row['geometry']['Viewport']['ScrollY']+=1
    if name=='small-workload':row['geometry']['ClippedRows']=63
    if name=='missing-terminal':e.pop()
    if name=='diagnostics-in-ordinary':row['frame']['SourceDetails']={}
    if name=='wrong-font':e[0]['font_sha256']='0'*64
    try:m.v.validate(render(e),case,sdk)
    except Exception as error:mutations[name]={'rejected':True,'type':type(error).__name__,'message':str(error)}
    else:raise AssertionError('accepted '+name)
d={'result':'PASS_PURE_TREE_VALIDATOR_CONTROLS','native_executed':False,'historical_fixture':str(raw),'historical_fixture_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'metadata_adaptation':'Only in-memory go_version=go1.25.6 and explicit CPU/ordinary requestflags added to historical frame-shape corpus for controls. No current native qualification from it. Rawtimings/geometry/callback/tickets unchanged.','cases':mutations,'baseline_samples':base['samples']};(W/'validator-controls.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'rejected':len(mutations),'native_executed':False}))
