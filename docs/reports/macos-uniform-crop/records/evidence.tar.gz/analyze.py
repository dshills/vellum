from pathlib import Path
import hashlib,json,re,statistics,subprocess
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-software-costs')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert len(prepared)==6221
generated=json.loads((P/'generated-test-images.json').read_text())['images']
def normalize(files):
 for n,h in generated.items():
  if n in files:assert files[n]==h
 return {n:h for n,h in files.items()if n not in generated}
receipts={}
for f in P.glob('*.json'):
 d=json.loads(f.read_text())
 if 'argv'not in d:continue
 assert d['source_commit']==base and not d['live_tests'] and not d['headless_gpu_requested'] and d['source_delta_stable'] and d['error']is None,f.name
 assert d['overlay_inputs_before']==d['overlay_inputs_after'],f.name
 for channel in ['stdout','stderr']:assert sha(P/(f.stem+'.'+channel))==d[channel+'_sha256'],f.name
 if not f.stem.startswith('prepare-v'):assert normalize(d['prepared_before'])==normalize(d['prepared_after']),f.name
 receipts[f.stem]={'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'receipt_sha256':sha(f),'prepared_files':len(d['prepared_after']),'source_delta_files':len(d['source_delta_after'])}
required=['baseline-profile-162-v3','candidate-profile-162','baseline-bench-v1','candidate-bench-v1','crop-unit-v1','crop-scroll-v1','raster-race-v1','raster-race-v2','raster-vet-v1','adapter-race-v1','adapter-vet-v1','loadedgrid-race-v1','native-build-v1','preparation-tests-v1','preparation-tests-v2','prepare-v1','prepare-v2','small-control-baseline','small-control-candidate']
assert all(receipts[n]['exit_code']==0 for n in required)
for n,phrase in [('fault-disabled','eligible=false want=true'),('fault-full-fill','subtraction changed overlap'),('fault-observer','scanner observed omitted fill')]:assert receipts[n]['exit_code']==1 and phrase in(P/(n+'.stdout')).read_text()
for n in ['baseline-profile','baseline-profile-162','baseline-profile-162-v2']:assert receipts[n]['exit_code']==1
final=json.loads((P/'raster-race-v2.json').read_text());assert normalize(final['prepared_before'])==normalize(final['prepared_after'])==prepared and final['source_delta_after']==json.loads((P/'tested-source.json').read_text())['sources'] and all(h==sources[n]for n,h in final['source_delta_after'].items()if n!='docs/reports/macos-uniform-crop/README.md')
prep1=json.loads((P/'prepare-v1.json').read_text());prep2=json.loads((P/'prepare-v2.json').read_text());before=prep1['prepared_before'];assert len(before)==6217 and normalize(prep1['prepared_after'])==normalize(prep2['prepared_before']) and len(prep1['prepared_after'])==6220 and prep2['prepared_after']==prepared
changes={n for n in before.keys()|prepared.keys()if before.get(n)!=prepared.get(n)}
outputs=json.loads((R/'drivers/cogent/native/patches/uniformcrop/output-hashes.json').read_text());assert changes=={'upstream/'+n for n in outputs} and all(prepared['upstream/'+n]==h for n,h in outputs.items())
for n in ['baseline-profile-162-v3','candidate-profile-162']:
 d=json.loads((P/(n+'.json')).read_text());assert d['prepared_before']==before
 line=re.search('SOFTWARE_PROFILE (.*)',(P/(n+'.stdout')).read_text()).group(1)
 if n.startswith('baseline'):oracle=line
 else:assert line==oracle
assert 'sha256=e984e91c4c85be13c95ff713a0d09821077434dd94cbcada96a8e3b5754b8fdb' in oracle
assert json.loads((P/'baseline-bench-v1.json').read_text())['prepared_before']==before
assert json.loads((P/'candidate-bench-v1.json').read_text())['prepared_before']==before
bench={}
for a,b,label in [('baseline-bench-v1','candidate-bench-v1','nested-grid-replay'),('small-control-baseline','small-control-candidate','small-cell-control')]:
 pair={}
 for n in [a,b]:
  rows=re.findall(r'\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(P/(n+'.stdout')).read_text());assert len(rows)==5
  assert all(int(r[2])==0 and int(r[3])==0 for r in rows)
  pair['baseline'if n==a else'candidate']={'samples_ns_per_op':[float(r[1])for r in rows],'iterations_per_sample':int(rows[0][0]),'median_ns_per_op':statistics.median(float(r[1])for r in rows),'bytes_per_op':0,'allocations_per_op':0}
 pair['observed_median_change_percent']=100*(pair['candidate']['median_ns_per_op']/pair['baseline']['median_ns_per_op']-1);bench[label]=pair
# Resolve even superseded temporary overlay inputs by bytes, retaining failed
# attempts without falsely claiming their current path still has those bytes.
by_hash={}
for f in P.rglob('*'):
 if f.is_file()and f.name!='window-cycle-smoke':by_hash.setdefault(sha(f),[]).append(f.relative_to(P).as_posix())
resolution={}
for name in receipts:
 d=json.loads((P/(name+'.json')).read_text())
 for path,h in d['overlay_inputs_before'].items():
  assert h in by_hash,(name,path,h)
  resolution.setdefault(h,{'recorded_paths':[],'retained_members':by_hash[h]})['recorded_paths'].append({'receipt':name,'path':path})
limits=['Human online: no controlled quiet-host timing, no live/native app or GPU execution.','Profile includes manual snapshots and observer work; not a frame budget measurement.','Fixed benchmark baseline then candidate, five samples; no native performance certification.','Existing failed 4/6ms native targets and current 123/1000 lifecycle failure remain open.','Full P4/P6/P9/P11, idle/overnight, physical/human checks, GPU/memory and distribution unqualified.']
summary={'result':'PASS_SCOPED_UNIFORM_CROP_CODE_CHECKS','base_commit':base,'sources':sources,'checks':receipts,'prepared_files':len(prepared),'prepared_delta':sorted(changes),'generated_test_images':{'count':len(generated),'source_files_unchanged':True,'not_visual_qualification':True},'implementation_matches_profile_candidate':sha(R/'drivers/cogent/build/upstream/paint/renderers/rasterx/uniform_crop.go')==sha(P/'uniform_crop.go'),'consumer_parity':oracle,'benchmarks':bench,'expected_faults_rejected':3,'failed_harness_attempts':['baseline-profile','baseline-profile-162','baseline-profile-162-v2'],'overlay_input_resolution':resolution,'native_binary_sha256':sha(P/'window-cycle-smoke'),'native_binary_executed':False,'live_tests':False,'full_mac_qualified':False,'limits':limits}
assert summary['implementation_matches_profile_candidate']
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'checks':len(receipts),'prepared_files':len(prepared),'benchmarks':bench}))
