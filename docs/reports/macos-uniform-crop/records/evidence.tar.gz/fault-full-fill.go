// Copyright (c) 2026 Vellum contributors.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"image"
	"image/draw"
	"math"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/ppath"
	"cogentcore.org/core/paint/render"
)

// A short lookahead removes only uniform pixels guaranteed to be replaced by
// the first subsequent drawing command. Items stay intact for future replays.
func (rs *Renderer) drawUncoveredUniform(items render.Render, index int, first *pimage.Params) bool {
	if !cropUniform(first, rs.image.Bounds(), false) || first.Rect.Dx()*first.Rect.Dy() < 4096 {
		return false
	}
	end := min(len(items), index+9)
	for next := index + 1; next < end; next++ {
		switch item := items[next].(type) {
		case *render.ContextPush:
			if item != nil && item.Scroll != nil {
				return false
			}
		case *render.ContextPop:
		case *render.Path:
			if !rs.cropNoPaintPath(item) {
				return false
			}
		case *pimage.Params:
			if !cropUniform(item, rs.image.Bounds(), true) {
				return false
			}
			overlap := first.Rect.Intersect(item.Rect)
			if overlap.Empty() || overlap.Dx()*overlap.Dy() < first.Rect.Dx()*first.Rect.Dy()/2 {
				return false
			}
			bands := [4]image.Rectangle{
				image.Rect(first.Rect.Min.X, first.Rect.Min.Y, first.Rect.Max.X, overlap.Min.Y),
				image.Rect(first.Rect.Min.X, overlap.Max.Y, first.Rect.Max.X, first.Rect.Max.Y),
				image.Rect(first.Rect.Min.X, overlap.Min.Y, overlap.Min.X, overlap.Max.Y),
				image.Rect(overlap.Max.X, overlap.Min.Y, first.Rect.Max.X, overlap.Max.Y),
			}
			for _, region := range bands {
				if region.Empty() {
					continue
				}
				command := *first
				command.Rect = first.Rect
				command.SourcePos = first.SourcePos.Add(region.Min.Sub(first.Rect.Min))
				command.Render(rs.image)
			}
			return true
		default:
			return false
		}
	}
	return false
}

func cropUniform(command *pimage.Params, target image.Rectangle, replace bool) bool {
	if command == nil || command.Cmd != pimage.Draw || command.Mask != nil || command.Rect.Empty() || !command.Rect.In(target) || (command.Op != draw.Src && command.Op != draw.Over) {
		return false
	}
	uniform, ok := valueUniform(command.Source)
	if !ok {
		return false
	}
	source := uniform.Bounds()
	// Checking by subtraction also excludes overflow when shifting subrects.
	if command.SourcePos.X < source.Min.X || command.SourcePos.Y < source.Min.Y || command.SourcePos.X > source.Max.X-command.Rect.Dx() || command.SourcePos.Y > source.Max.Y-command.Rect.Dy() {
		return false
	}
	if replace && command.Op == draw.Over {
		_, _, _, alpha := uniform.C.RGBA()
		return alpha == 65535
	}
	return true
}

// No user scanner callback, malformed path or transform is crossed. Normal box
// borders use at most five finite move/line/close segments with paint disabled.
// They still execute later, preserving clip and scratch-state transitions.
func (rs *Renderer) cropNoPaintPath(path *render.Path) bool {
	if path == nil || path.Context.Style.HasFill() || path.Context.Style.HasStroke() || path.Context.Cumulative != math32.Identity2() || len(path.Path) > 20 || len(path.Path)%4 != 0 || rs.Scanner == nil || rs.Raster == nil || rs.Raster.Filler.Scanner != rs.Scanner {
		return false
	}
	for i := 0; i < len(path.Path); i += 4 {
		command := path.Path[i]
		if (command != ppath.MoveTo && command != ppath.LineTo && command != ppath.Close) || path.Path[i+3] != command {
			return false
		}
		for _, coordinate := range path.Path[i+1 : i+3] {
			if math.IsNaN(float64(coordinate)) || math.IsInf(float64(coordinate), 0) || coordinate < -8192 || coordinate > 8192 {
				return false
			}
		}
	}
	return true
}
