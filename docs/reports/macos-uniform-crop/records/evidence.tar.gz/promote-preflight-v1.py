from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-software-costs');C=Path('/Users/dshills/Development/projects/Vellum');P=Path(__file__).resolve().parent
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-uniform-crop')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(root,*args):
 d=run_child(['git','-C',str(root),*args],env=child_environment(),capture_output=True,timeout=60);assert d.returncode==0,d.stderr;return d.stdout.decode().strip()
def prepared(root):return{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}
q=json.loads((R/'docs/reports/macos-uniform-crop/records/qualification.json').read_text());final=json.loads((P/'final-review.json').read_text())
assert q['result']=='PASS_SCOPED_UNIFORM_CROP_CHECKPOINT'and final['result']=='APPROVED_SOURCE_AND_EVIDENCE'and not final['unresolved_findings']
assert q['prism_findings']==0 and q['prism_coverage_complete'] and not q['native_binary_executed'] and not q['full_mac_qualified']
base=q['base_commit'];commit=git(R,'rev-parse','HEAD');assert git(R,'rev-list','--parents','-n','1','HEAD').split()==[commit,base]
assert not git(R,'status','--porcelain')and not git(C,'status','--porcelain')and git(C,'rev-parse','HEAD')==base
changed=set(git(R,'diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines());expected_changed=set(q['sources'])|{'docs/reports/macos-uniform-crop/records/'+n for n in ['qualification.json','evidence.tar.gz','archive-index.json']};assert changed==expected_changed and len(changed)==12
# Verify physical parent files too, catching hidden skip-worktree/assume-unchanged changes.
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree','HEAD'],cwd=C).split(b'\0'):
 if not row:continue
 meta,raw_name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=C/raw_name.decode();assert kind=='blob'and path.is_file()and not path.is_symlink();content=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==oid,raw_name.decode()
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')if n];expected={n:sha(R/n)for n in names};assert all(expected[n]==h for n,h in q['sources'].items())and final['sources']=={n:expected[n]for n in expected_changed}
pristine=json.loads((P/'baseline-profile-162-v3.json').read_text())['prepared_before'];assert len(pristine)==6217 and prepared(C)==pristine
wanted=prepared(R);assert len(wanted)==6221
O.mkdir(parents=True,exist_ok=True);start=time.monotonic();record={'result':'STARTED_CANONICAL_PROMOTION','base_commit':base,'commit':commit,'changed_files':sorted(changed),'scope':'Bounded CPU uniform background subtraction; offscreen qualification only. No native performance/full-Mac qualification.'}
try:
 git(C,'fetch',str(R),commit);assert git(C,'rev-parse','FETCH_HEAD')==commit;git(C,'merge','--ff-only','FETCH_HEAD')
 env={**child_environment(),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2'}
 with(O/'canonical-prepare.stdout').open('xb')as so,(O/'canonical-prepare.stderr').open('xb')as se:record['prepare_exit_code']=run_child(['python3','prepare.py'],cwd=C/'drivers/cogent',env=env,stdout=so,stderr=se,timeout=60).returncode
 assert record['prepare_exit_code']==0
 actual=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')if n]
 record.update({'tracked_files':len(expected),'tracked_exact':set(actual)==set(expected)and all(sha(C/n)==h for n,h in expected.items()),'prepared_files':6221,'prepared_exact':prepared(C)==wanted,'canonical_clean':not git(C,'status','--porcelain'),'scratch_clean':not git(R,'status','--porcelain'),'archive_sha256':sha(C/'docs/reports/macos-uniform-crop/records/evidence.tar.gz'),'final_review_sha256':sha(P/'final-review.json')})
 assert all(record[k]for k in ['tracked_exact','prepared_exact','canonical_clean','scratch_clean'])and record['archive_sha256']==q['archive_sha256'];record['result']='PASS_CANONICAL_PROMOTION'
finally:
 record['elapsed_seconds']=time.monotonic()-start;record['observed_head']=git(C,'rev-parse','HEAD');record['observed_status']=git(C,'status','--porcelain');(O/'canonical-promotion.json').write_text(json.dumps(record,indent=2)+'\n');(O/'promotion-producer.py.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps(record))
