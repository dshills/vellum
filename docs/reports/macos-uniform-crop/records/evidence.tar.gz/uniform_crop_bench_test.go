// Copyright (c) 2026 Vellum contributors.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"image"
	"image/color"
	"image/draw"
	"testing"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/ppath"
	"cogentcore.org/core/paint/render"
)

// Identical body runs against pristine and candidate Renderer.Render binaries.
// Large nested box backgrounds precede 486 small cell backgrounds; assertions
// and construction stay outside timing. This measures CPU replay only.
func BenchmarkUniformCropGrid(b *testing.B) {
	items := make(render.Render, 0, 2000)
	add := func(rect image.Rectangle) {
		items = append(items, &render.ContextPush{}, &pimage.Params{Cmd: pimage.Draw, Rect: rect, SourcePos: rect.Min, Op: draw.Src, Source: image.NewUniform(color.RGBA{27, 31, 41, 255})}, &pimage.Params{Cmd: pimage.Draw, Rect: rect, SourcePos: rect.Min, Op: draw.Over, Source: image.NewUniform(color.RGBA{39, 47, 59, 255})})
		path := &render.Path{Path: ppath.Path{ppath.MoveTo, 2, 3, ppath.MoveTo, ppath.LineTo, 7, 9, ppath.LineTo, ppath.Close, 2, 3, ppath.Close}}
		path.Context.Cumulative = math32.Identity2()
		items = append(items, path)
	}
	for i := range 6 {
		add(image.Rect(i*4, i*4, 1500-i*4, 1250-i*4))
	}
	for y := range 27 {
		for x := range 18 {
			add(image.Rect(24+x*70, 32+y*40, 94+x*70, 72+y*40))
			items = append(items, &render.ContextPop{})
		}
	}
	for range 6 {
		items = append(items, &render.ContextPop{})
	}
	rs := New(math32.Vec2(1500, 1250)).(*Renderer)
	want := coveredDrawRenderer(coveredDrawTarget(image.Rect(0, 0, 1500, 1250)))
	coveredDrawReference(want, coveredDrawCopies(items))
	rs.Render(items)
	if !imageEqualCropBenchmark(rs.image, want.image) {
		b.Fatal("benchmark replay pixels differ")
	}
	b.ReportAllocs()
	b.ResetTimer()
	for range b.N {
		rs.Render(items)
	}
}

func imageEqualCropBenchmark(a, b *image.RGBA) bool {
	for y := a.Rect.Min.Y; y < a.Rect.Max.Y; y++ {
		for x := a.Rect.Min.X; x < a.Rect.Max.X; x++ {
			if a.RGBAAt(x, y) != b.RGBAAt(x, y) {
				return false
			}
		}
	}
	return true
}
