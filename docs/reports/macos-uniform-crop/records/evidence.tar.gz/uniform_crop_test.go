// Copyright (c) 2026 Vellum contributors.
// SPDX-License-Identifier: MIT

package rasterx

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"math"
	"reflect"
	"testing"

	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/ppath"
	"cogentcore.org/core/paint/render"
)

func cropTestDraw(rect image.Rectangle, op draw.Op, c color.Color) *pimage.Params {
	return &pimage.Params{Cmd: pimage.Draw, Rect: rect, SourcePos: rect.Min, Op: op, Source: image.NewUniform(c)}
}

func cropTestPath() *render.Path {
	p := &render.Path{Path: ppath.Path{ppath.MoveTo, 2, 3, ppath.MoveTo, ppath.LineTo, 7, 9, ppath.LineTo, ppath.Close, 2, 3, ppath.Close}}
	p.Context.Cumulative = math32.Identity2()
	return p
}

func cropTestPair(bounds image.Rectangle) render.Render {
	return render.Render{cropTestDraw(bounds, draw.Over, color.NRGBA{17, 51, 93, 113}), cropTestPath(), &render.ContextPush{},
		cropTestDraw(bounds.Inset(4), draw.Src, color.NRGBA{91, 31, 11, 73}), &render.ContextPop{}}
}

func TestUniformCropPartialPixelAndStateParity(t *testing.T) {
	for _, origin := range []image.Point{{}, {-19, -11}, {13, 17}} {
		bounds := image.Rectangle{Min: origin, Max: origin.Add(image.Pt(112, 96))}
		for _, firstOp := range []draw.Op{draw.Src, draw.Over} {
			for _, lastOp := range []draw.Op{draw.Src, draw.Over} {
				for _, c := range []color.Color{color.NRGBA{12, 33, 71, 255}, color.NRGBA{21, 41, 81, 93}, color.RGBA64{1, 2, 3, 65535}, color.Alpha{255}} {
					for _, overlap := range []image.Rectangle{bounds, bounds.Inset(4), bounds.Add(image.Pt(13, -7)).Intersect(bounds)} {
						items := cropTestPair(bounds)
						items[0].(*pimage.Params).Op = firstOp
						last := items[3].(*pimage.Params)
						last.Rect, last.SourcePos, last.Op, last.Source = overlap, image.Pt(777, -987), lastOp, image.NewUniform(c)
						for replay := 0; replay < 3; replay++ {
							coveredDrawCompare(t, bounds, items)
						}
						// Check the intermediate subtraction itself, not just final
						// pixels that would also pass with the helper disabled.
						seed := coveredDrawTarget(bounds)
						before := append([]byte(nil), seed.Pix...)
						rs := coveredDrawRenderer(seed)
						eligible := lastOp == draw.Src
						if lastOp == draw.Over {
							_, _, _, a := c.RGBA()
							eligible = a == 65535
						}
						if got := rs.drawUncoveredUniform(items, 0, items[0].(*pimage.Params)); got != eligible {
							t.Fatalf("eligible=%v want=%v", got, eligible)
						}
						if eligible {
							expected := coveredDrawTarget(bounds)
							items[0].(*pimage.Params).Render(expected)
							for y := overlap.Min.Y; y < overlap.Max.Y; y++ {
								for x := overlap.Min.X; x < overlap.Max.X; x++ {
									off := seed.PixOffset(x, y)
									copy(expected.Pix[off:off+4], before[off:off+4])
								}
							}
							if !bytes.Equal(seed.Pix, expected.Pix) {
								t.Fatal("subtraction changed overlap, padding, or retained strips")
							}
						}
					}
				}
			}
		}
	}
}

func TestUniformCropChainsAndBorrowedSources(t *testing.T) {
	bounds := image.Rect(0, 0, 160, 128)
	items := cropTestPair(bounds)
	items = append(items, cropTestPath(), cropTestDraw(bounds.Inset(12), draw.Over, color.RGBA{3, 7, 19, 255}))
	seed := coveredDrawTarget(bounds)
	actual, expected := coveredDrawRenderer(seed), coveredDrawRenderer(coveredDrawTarget(bounds))
	a, b := coveredDrawCopies(items), coveredDrawCopies(items)
	for _, c := range []color.Color{color.NRGBA{11, 31, 71, 255}, color.NRGBA{11, 31, 71, 87}, color.Alpha{255}} {
		items[3].(*pimage.Params).Source.(*image.Uniform).C = c
		coveredDrawReference(expected, b)
		actual.Render(a)
		if !bytes.Equal(actual.image.Pix, expected.image.Pix) || !reflect.DeepEqual(a, b) {
			t.Fatal("borrowed source/repeated chain differs")
		}
	}
}

func TestUniformCropFallbacks(t *testing.T) {
	bounds := image.Rect(0, 0, 112, 96)
	for _, test := range []struct {
		name   string
		change func(render.Render)
	}{
		{"small", func(r render.Render) { r[0].(*pimage.Params).Rect = image.Rect(0, 0, 20, 20) }},
		{"first-mask", func(r render.Render) { r[0].(*pimage.Params).Mask = image.NewAlpha(bounds) }},
		{"last-mask", func(r render.Render) { r[3].(*pimage.Params).Mask = image.NewAlpha(bounds) }},
		{"first-source-clipped", func(r render.Render) { r[0].(*pimage.Params).SourcePos.X = image.White.Bounds().Max.X - 2 }},
		{"last-source-clipped", func(r render.Render) { r[3].(*pimage.Params).SourcePos.Y = image.White.Bounds().Max.Y - 2 }},
		{"sentinel", func(r render.Render) { r[0].(*pimage.Params).Rect = image.Rectangle{} }},
		{"outside-target", func(r render.Render) { r[0].(*pimage.Params).Rect = bounds.Add(image.Pt(1, 1)) }},
		{"image", func(r render.Render) { r[0].(*pimage.Params).Source = coveredDrawTarget(bounds) }},
		{"translucent-over", func(r render.Render) {
			p := r[3].(*pimage.Params)
			p.Op = draw.Over
			p.Source = image.NewUniform(color.NRGBA{1, 2, 3, 99})
		}},
		{"small-overlap", func(r render.Render) { r[3].(*pimage.Params).Rect = image.Rect(0, 0, 8, 8) }},
		{"set-pixel", func(r render.Render) { r[3].(*pimage.Params).Cmd = pimage.SetPixel }},
		{"scroll", func(r render.Render) { r[2].(*render.ContextPush).Scroll = &render.ScrollSurface{} }},
		{"painted-path", func(r render.Render) {
			p := r[1].(*render.Path)
			p.Context.Style.Fill.Color = image.White
			p.Context.Style.Fill.Opacity = 1
		}},
		{"transform", func(r render.Render) { r[1].(*render.Path).Context.Cumulative = math32.Scale2D(2, 2) }},
		{"oversize-path", func(r render.Render) { p := r[1].(*render.Path); p.Path = append(p.Path, p.Path...) }},
	} {
		t.Run(test.name, func(t *testing.T) {
			items := cropTestPair(bounds)
			test.change(items)
			rs := coveredDrawRenderer(coveredDrawTarget(bounds))
			before := append([]byte(nil), rs.image.Pix...)
			if rs.drawUncoveredUniform(items, 0, items[0].(*pimage.Params)) || !bytes.Equal(before, rs.image.Pix) {
				t.Fatal("fallback cropped or wrote pixels")
			}
			coveredDrawCompare(t, bounds, items)
		})
	}
	for _, at := range []int{0, 3} {
		items := cropTestPair(bounds)
		calls := 0
		items[at].(*pimage.Params).Source = image.NewUniform(coveredDrawColor{&calls})
		rs := coveredDrawRenderer(coveredDrawTarget(bounds))
		if rs.drawUncoveredUniform(items, 0, items[0].(*pimage.Params)) || calls != 0 {
			t.Fatal("custom color inspected")
		}
		coveredDrawCompare(t, bounds, items)
		if calls != 2 {
			t.Fatalf("lost custom source calls: %d", calls)
		}
	}
	for _, n := range []int{7, 8} {
		first := cropTestDraw(bounds, draw.Src, color.RGBA{1, 2, 3, 255})
		items := render.Render{first}
		for range n {
			items = append(items, &render.ContextPop{})
		}
		items = append(items, cropTestDraw(bounds.Inset(1), draw.Src, color.Alpha{99}))
		rs := coveredDrawRenderer(coveredDrawTarget(bounds))
		if got := rs.drawUncoveredUniform(items, 0, first); got != (n == 7) {
			t.Fatalf("lookahead n=%d got=%v", n, got)
		}
		coveredDrawCompare(t, bounds, items)
	}
}

type cropTestScanner struct {
	Scanner
	pixels   *image.RGBA
	observed [][]byte
}

func (s *cropTestScanner) Clear() {
	s.observed = append(s.observed, append([]byte(nil), s.pixels.Pix...))
	s.Scanner.Clear()
}

func TestUniformCropKeepsScannerObservers(t *testing.T) {
	bounds := image.Rect(0, 0, 112, 96)
	items := cropTestPair(bounds)
	a, b := coveredDrawRenderer(coveredDrawTarget(bounds)), coveredDrawRenderer(coveredDrawTarget(bounds))
	sa, sb := &cropTestScanner{Scanner: a.Scanner, pixels: a.image}, &cropTestScanner{Scanner: b.Scanner, pixels: b.image}
	a.Raster.Filler.Scanner = sa
	b.Raster.Filler.Scanner = sb
	a.Render(coveredDrawCopies(items))
	coveredDrawReference(b, coveredDrawCopies(items))
	if len(sa.observed) != 1 || !reflect.DeepEqual(sa.observed, sb.observed) || !bytes.Equal(a.image.Pix, b.image.Pix) {
		t.Fatal("scanner observed omitted fill")
	}
}

func TestUniformCropMalformedPathPanicParity(t *testing.T) {
	bounds := image.Rect(0, 0, 112, 96)
	for _, path := range []ppath.Path{{99, 0, 0, 99}, {ppath.MoveTo, 1}, {ppath.QuadTo, 1, 2, ppath.QuadTo}, {ppath.MoveTo, 1, 2, ppath.LineTo}, {ppath.MoveTo, float32(math.NaN()), 2, ppath.MoveTo}} {
		items := cropTestPair(bounds)
		items[1].(*render.Path).Path = path
		a, b := coveredDrawRenderer(coveredDrawTarget(bounds)), coveredDrawRenderer(coveredDrawTarget(bounds))
		if a.cropNoPaintPath(items[1].(*render.Path)) {
			t.Fatal("malformed path crossed")
		}
		capture := func(f func()) (panicText string) {
			defer func() {
				if v := recover(); v != nil {
					panicText = fmt.Sprint(v)
				}
			}()
			f()
			return
		}
		pa := capture(func() { a.Render(coveredDrawCopies(items)) })
		pb := capture(func() { coveredDrawReference(b, coveredDrawCopies(items)) })
		if pa != pb || !bytes.Equal(a.image.Pix, b.image.Pix) {
			t.Fatalf("panic/pixels differ for %v: %q != %q", path, pa, pb)
		}
	}
}
