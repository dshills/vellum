from pathlib import Path
import hashlib,json,subprocess,sys,time,os
R=Path('/private/tmp/vellum-software-costs');P=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
sources=json.loads((P/'checkpoint-source.json').read_text())['sources'];review=json.loads((P/'checkpoint-review.json').read_text());summary=json.loads((P/'summary.json').read_text())
assert len(sources)==9 and review['result']=='APPROVED_SOURCE_AND_EVIDENCE' and not review['unresolved_findings'] and review['sources']==sources and summary['sources']==sources
assert summary['result']=='PASS_SCOPED_UNIFORM_CROP_CODE_CHECKS' and not summary['native_binary_executed'] and not summary['full_mac_qualified']
assert all(sha(R/n)==h for n,h in sources.items())
diff=subprocess.check_output(['git','diff','--cached','--binary','--',*sources],cwd=R)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).decode().splitlines())==set(sources)
assert subprocess.check_output(['git','diff','--name-only'],cwd=R)==b''
out=P/'prism-v1';out.mkdir(exist_ok=False)
(out/'staged.diff.txt').write_bytes(diff)
(out/'inputs.json').write_text(json.dumps({'files':sources,'diff_sha256':hashlib.sha256(diff).hexdigest(),'scope':'Nine source/spec/report files. Pinned upstream patch64: bounded CPU uniform background subtraction crossing only known no-ink paths/plain markers; original painter/items preserved; source bounds, scanner identity and exact path structure guards. Software pixels/geometry, cache strips/full repair, panic/observer oracles; three injected defects rejected. Fixed identical-body benchmark and full adapter/consumer/raster/sceneplan race, vet, preparation and native compile. Generated upstream17 missing PNG baselines not visual qualification. Human online; no native launch/GPU or controlled timing, no native performance/fullMac qualification.'},indent=2)+'\n')
argv=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--format','json','--baseline','none','--fail-on','medium','--min-severity','medium','--no-auto-exclude','--paths',','.join(sources),'--out',str(out/'prism.json')]
start=time.monotonic();code=125;error=None
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:code=run_child(argv,cwd=R,env={**child_environment(),'ANTHROPIC_API_KEY':os.environ['ANTHROPIC_API_KEY']},stdout=so,stderr=se,timeout=480).returncode
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc)}
after={n:sha(R/n)for n in sources};afterdiff=subprocess.check_output(['git','diff','--cached','--binary','--',*sources],cwd=R)
record={'argv':argv,'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-start,'sources':sources,'source_index_stable':after==sources and diff==afterdiff,'review_sha256':sha(P/'checkpoint-review.json'),'producer_sha256':sha(__file__),'prism_sha256':sha(out/'prism.json')if(out/'prism.json').is_file()else None}
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['exit_code','error','elapsed_seconds','source_index_stable']}));sys.exit(code if error is None and record['source_index_stable'] else 125)
