// Copyright (c) 2026 Vellum contributors.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	"testing"

	"cogentcore.org/core/paint/pimage"
	"cogentcore.org/core/paint/render"
)

func TestUniformCropScrollFullAndStripReplay(t *testing.T) {
	bounds := image.Rect(11, 9, 191, 105)
	actual := coveredDrawRenderer(coveredDrawTarget(image.Rect(0, 0, 240, 160)))
	reference := coveredDrawRenderer(coveredDrawTarget(image.Rect(0, 0, 240, 160)))
	reused, repaired := 0, 0
	for frame := range 24 {
		position := image.Pt(frame*3, frame*2)
		epoch := uint64(frame/8 + 1)
		items := render.Render{&render.ContextPush{Scroll: &render.ScrollSurface{ID: 71, Epoch: epoch, Position: position, Bounds: bounds}},
			cropTestDraw(bounds, draw.Src, color.RGBA{11, 13, 17, 255}), cropTestPath(),
			cropTestDraw(bounds, draw.Src, color.RGBA{19, 27, 35, 255})}
		items = append(items, scrollPattern(bounds, position, epoch)[1:]...)
		items = append(items, &render.ContextPop{})
		actual.Render(coveredDrawCopies(items))
		scrollReference(reference, coveredDrawCopies(items))
		if !bytes.Equal(actual.image.Pix, reference.image.Pix) {
			t.Fatalf("scroll pixels differ at frame %d", frame)
		}
		stats := actual.ScrollStats()
		reused += stats.ReusedGroups
		repaired += stats.FullRedraws
		if stats.CapturedPixels != stats.RedrawPixels {
			t.Fatal("capture exceeds repaint", stats)
		}
	}
	if repaired != 3 || reused != 21 {
		t.Fatalf("cache path unexercised: full=%d reused=%d", repaired, reused)
	}
}

func TestUniformCropClippedReplay(t *testing.T) {
	bounds := image.Rect(0, 0, 112, 96)
	clip := image.Rect(9, 11, 99, 83)
	items := cropTestPair(bounds)
	a, b := coveredDrawRenderer(coveredDrawTarget(bounds)), coveredDrawRenderer(coveredDrawTarget(bounds))
	original := coveredDrawCopies(items)
	for _, item := range original {
		if p, ok := item.(*pimage.Params); ok {
			prior := p.Rect
			p.Rect = prior.Intersect(clip)
			p.SourcePos = p.SourcePos.Add(p.Rect.Min.Sub(prior.Min))
		}
	}
	coveredDrawReference(b, original)
	a.renderItems(coveredDrawCopies(items), clip)
	if !bytes.Equal(a.image.Pix, b.image.Pix) {
		t.Fatal("clipped strip replay differs")
	}
}
