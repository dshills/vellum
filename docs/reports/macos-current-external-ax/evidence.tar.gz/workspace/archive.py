"""Preserve scoped AX diagnostics and the failed original collector; no executables."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017');T=Path('/private/tmp/vellum-macos-native-results-97aee13');S=W.parent/'macos-grid-native-stacks'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
items={}
def add(prefix,root,names):
 for name in names:items[prefix+name]=root/name
add('workspace/',W,['trust-only.py','trust-only-v1-syntax-error.py','inspector.swift','build-native.py','window-readonly.swift','build-window-helper.py','run-native.py','run-native-v1-unexecuted.py','run-native-v2-unexecuted.py','analyze-native.py','validation-v2.py','validation-correction.json','reconcile-native.py','reconciliation-v1-error.json','native-readiness.json','native-analysis.json','result-review.json','archive.py'])
add('trust-only/',P,['receipt.json','build.stdout','build.stderr','trust.stdout','trust.stderr'])
add('native-build/',P/'native-build',['source.json','receipt.json','overlay.json','editor.metadata','editor.stdout','editor.stderr','placement.metadata','placement.stdout','placement.stderr','editor.app/Contents/Info.plist','placement.app/Contents/Info.plist','overlays/examples/editor/main.go','overlays/examples/placement/native_probe_darwin.go'])
add('original-fixture-source/',T,['examples/editor/main.go','examples/placement/native_probe_darwin.go'])
add('window-helper-build/',P/'window-helper-build',['receipt.json','build.stdout','build.stderr','trust.stdout','trust.stderr'])
for case in ['editor','placement']:
 add('native/'+case+'/',P/'runs'/case,['owned-native.json','owned-client.json','receipt.json','native.stdout','native.stderr','client.stdout','client.stderr'])
add('native/editor/',P/'runs/editor',['expected.txt'])
add('native/placement/probe/',P/'runs/placement/probe',['events.jsonl','latest.json'])
add('workspace/shared-runtime/',S,['run.py','build.py'])
add('repository/scripts/',T/'scripts',['child_process.py','sdk_environment.py','check-editor-accessibility.swift'])
add('shared/',Path('/private/tmp/vellum-empty-text-native-isolated-v2'),['live_lease.py'])
entries=[];buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0)as compressed:
 with tarfile.open(fileobj=compressed,mode='w')as tar:
  for name,path in sorted(items.items()):
   assert path.is_file()and not path.is_symlink(),str(path);data=path.read_bytes();assert data[:4]not in [b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf']
   header=tarfile.TarInfo(name);header.size=len(data);header.mode=0o600;header.mtime=0;tar.addfile(header,io.BytesIO(data));entries.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
compiled=[P/'inspector',P/'window-helper-build/window-readonly',P/'native-build/editor.app/Contents/MacOS/editor',P/'native-build/placement.app/Contents/MacOS/placement']
data=buffer.getvalue();(W/'evidence.tar.gz').write_bytes(data);manifest=dict(schema='vellum-current-external-ax-evidence-v1',archive_bytes=len(data),archive_sha256=hashlib.sha256(data).hexdigest(),expanded_bytes=sum(e['bytes']for e in entries),entries=entries,excluded_compiled_executables=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in compiled])
(W/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items()if k not in ['entries','excluded_compiled_executables']}|dict(entries=len(entries),compiled_executables_excluded=len(compiled))))
