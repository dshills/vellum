"""Compile and trust-check a read-only exact-PID/executable/window AX client."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017/window-helper-build')
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
P.mkdir();source=W/'window-readonly.swift';binary=P/'window-readonly';before=sha(source);env=child_environment(False);d=dict(producer_sha256=sha(__file__),source_sha256=before,error=None,native_window_launched=False,settings_changed=False,prompt=False)
try:
 for name,argv in [('build',['xcrun','swiftc',str(source),'-o',str(binary)]),('trust',[str(binary),'--trust-only'])]:
  with(P/(name+'.stdout')).open('xb')as stdout,(P/(name+'.stderr')).open('xb')as stderr:r=run_child(argv,env=env,stdout=stdout,stderr=stderr,timeout=60 if name=='build'else 5,log_limit_bytes=1<<20)
  d[name]=dict(argv=argv,exit_code=r.returncode,logs={n:dict(bytes=(P/(name+'.'+n)).stat().st_size,sha256=sha(P/(name+'.'+n)))for n in ['stdout','stderr']});assert r.returncode==0
 d.update(binary=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary)),trust_observation=json.loads((P/'trust.stdout').read_bytes()));assert d['trust_observation']['trusted']is True and d['trust_observation']['prompt']is False
except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
finally:
 d.update(source_stable=sha(source)==before,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
