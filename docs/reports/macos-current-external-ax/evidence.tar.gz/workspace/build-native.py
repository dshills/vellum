"""Build current native fixtures with explicit diagnostic-only Go overlays; no UI."""
from pathlib import Path
import datetime,hashlib,json,plistlib,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017');COMMIT='0f636c850ae1a66263bdcc1ecbaa6d8b2a1b0e9f'
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,timeout=20)
def identity():
 assert git('rev-parse','HEAD').decode().strip()==COMMIT and not git('status','--porcelain','-z')
 names=git('ls-files','-z').decode().split('\0')[:-1];tracked={n:sha(T/n)for n in names};prepared={}
 for module in ['upstream','typesetting']:
  for p in(T/'drivers/cogent/build'/module).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():prepared[p.relative_to(T/'drivers/cogent/build').as_posix()]=sha(p)
 assert len(tracked)==4625 and len(prepared)==6243
 return dict(commit=COMMIT,tracked=tracked,prepared=prepared)

def main():
 out=P/'native-build';out.mkdir();before=identity();(out/'source.json').write_text(json.dumps(before,indent=2)+'\n');overlays={};changes={}
 for path in ['examples/editor/main.go','examples/placement/native_probe_darwin.go']:
  original=(T/path).read_text();modified=original
  if '/editor/'in path:
   marker='\t"github.com/dshills/vellum/app"';assert original.count(marker)==1;modified=modified.replace(marker,'\t"cogentcore.org/core/core"\n'+marker)
   marker='func runAXFixture() error {\n';assert modified.count(marker)==1;modified=modified.replace(marker,marker+'\tprevious := core.DebugSettings.DisableWindowGeometrySaver\n\tcore.DebugSettings.DisableWindowGeometrySaver = true\n\tdefer func() { core.DebugSettings.DisableWindowGeometrySaver = previous }()\n')
   marker='"lifetime_seconds": 60';assert modified.count(marker)==1;modified=modified.replace(marker,marker+', "geometry_persistence_disabled_in_fixture": core.DebugSettings.DisableWindowGeometrySaver')
  else:
   marker='context.WithTimeout(context.Background(), 10*time.Minute)';assert original.count(marker)==1;modified=modified.replace(marker,'context.WithTimeout(context.Background(), 20*time.Second)')
  target=out/'overlays'/path;target.parent.mkdir(parents=True);target.write_text(modified);overlays[str(T/path)]=str(target);changes[path]=dict(original_sha256=sha(T/path),overlay_sha256=sha(target),overlay_path=str(target))
 overlay=out/'overlay.json';overlay.write_text(json.dumps({'Replace':overlays},indent=2)+'\n')
 env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOPROXY':'off','GOMAXPROCS':'2'}
 result=dict(base_commit=COMMIT,source_sha256=sha(out/'source.json'),overlay_sha256=sha(overlay),diagnostic_overlay=changes,producer_sha256=sha(__file__),native_runtime_executed=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),binaries={},error=None)
 try:
  for name,relative,tag in [('editor','examples/editor',None),('placement','examples/placement','vellum_placement_probe')]:
   bundle=out/(name+'.app');contents=bundle/'Contents';exe=contents/'MacOS'/name;exe.parent.mkdir(parents=True)
   plist=dict(CFBundleIdentifier='com.vellum.externalax.'+name,CFBundleName='Vellum AX '+name,CFBundleExecutable=name,CFBundlePackageType='APPL',CFBundleVersion='1',NSHighResolutionCapable=True)
   with(contents/'Info.plist').open('xb')as f:plistlib.dump(plist,f)
   argv=['go','build','-p=1','-trimpath','-overlay',str(overlay)]+(['-tags='+tag]if tag else[])+['-o',str(exe),'.'];start=time.monotonic()
   with(out/(name+'.stdout')).open('xb')as stdout,(out/(name+'.stderr')).open('xb')as stderr:r=run_child(argv,cwd=str(T/relative),env=env,stdout=stdout,stderr=stderr,timeout=420,log_limit_bytes=8<<20)
   entry=dict(argv=argv,cwd=str(T/relative),exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,logs={n:dict(bytes=(out/(name+'.'+n)).stat().st_size,sha256=sha(out/(name+'.'+n)))for n in ['stdout','stderr']});result['binaries'][name]=entry;assert r.returncode==0
   metadata=run_child(['go','version','-m',str(exe)],env=env,capture_output=True,timeout=20);assert metadata.returncode==0 and not metadata.stderr;(out/(name+'.metadata')).write_bytes(metadata.stdout);text=metadata.stdout.decode();assert 'vcs.revision='+COMMIT in text and 'CGO_ENABLED=1'in text
   entry.update(binary=dict(path=str(exe),bytes=exe.stat().st_size,sha256=sha(exe)),plist_sha256=sha(contents/'Info.plist'),metadata_sha256=sha(out/(name+'.metadata')),instrumented_fixture=True)
 except BaseException as e:result['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  result.update(source_stable=identity()==before,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 assert result['source_stable']
if __name__=='__main__':main()
