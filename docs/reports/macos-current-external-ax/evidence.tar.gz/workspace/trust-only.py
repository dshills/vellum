"""Compile the existing read-only inspector and query its existing trust, without UI."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017');W=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
P.mkdir(mode=0o700);source=T/'scripts/check-editor-accessibility.swift';h=sha(source);binary=P/'inspector';env=child_environment(False)
d=dict(result='INCOMPLETE',source_path=str(source),source_sha256=h,base_commit='e4d398a24fff8f9506ea837c206be7e6416aba7f',producer_sha256=sha(__file__),native_window_launched=False,prompt_requested=False,settings_changed=False,error=None,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());start=time.monotonic()
try:
 for name,argv in [('build',['xcrun','swiftc',str(source),'-o',str(binary)]),('trust',[str(binary),'--trust-only'])]:
  with(P/(name+'.stdout')).open('xb')as stdout,(P/(name+'.stderr')).open('xb')as stderr:r=run_child(argv,env=env,stdout=stdout,stderr=stderr,timeout=60 if name=='build'else 5,log_limit_bytes=1<<20)
  d[name]=dict(argv=argv,exit_code=r.returncode,logs={n:dict(bytes=(P/(name+'.'+n)).stat().st_size,sha256=sha(P/(name+'.'+n)))for n in ['stdout','stderr']})
  if name=='build':assert r.returncode==0
  else:
   assert r.returncode in [0,2];record=json.loads((P/'trust.stdout').read_bytes());assert record['event']=='vellum.editor.external-ax-trust'and record['prompt']is False and record['accessibility_trusted']==(r.returncode==0);d['trust_observation']=record
 d.update(result='TRUST_PRESENT'if d['trust_observation']['accessibility_trusted']else'TRUST_UNAVAILABLE',binary_sha256=sha(binary),source_stable=sha(source)==h);assert d['source_stable']
except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e));raise
finally:
 d.update(elapsed_seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Trust for this compiled helper only; no inference about CUA service identity or earlier timeout cause.')
 (P/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
