"""Correct the collector's path spelling and ID namespace assumptions; no runtime."""
from pathlib import Path
import base64,importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_readonly_runtime',W/'run-native.py');frozen=importlib.util.module_from_spec(spec);spec.loader.exec_module(frozen)
need=frozen.need;read=frozen.read;sha=frozen.sha
def validate(case,out,d):
 need(d['native']['exit_code']==(0 if case=='editor'else 1),'native expected exit')
 need(d['native']['terminal_native_elapsed_seconds']-d['native']['started_native_elapsed_seconds']>=(59.5 if case=='editor'else 19.5),'normal fixture lifetime')
 need(d.get('client',{}).get('exit_code')==0,'external AX client failure')
 client=read(out/'client.stdout');need(client.get('result')=='pass','external AX outcome')
 if case=='editor':
  need(client['pid']==d['native']['pid']and client['accessibility_trusted']is True and client['exact_value']is True and client['selection_utf16']==[1,2]and client['selected_text']=='😀'and client['combining_range_utf16']==[3,2]and client['final_line_range_utf16'][1]==0 and client['hebrew_visual_rtl']is True,'external editor assertions')
  return dict(external_ax=client,geometry_persistence_disabled=d['fixture']['geometry_persistence_disabled_in_fixture'],physical_input_verified=False)
 need(client['pid']==d['native']['pid']and client['trusted']is True and client['actions_performed']is False and client['settings_changed']is False and client['prompt']is False and client['complete_bounded_walk']is True,'read-only owned tree')
 need(client['expected_title']=='Vellum native placement probe'and os.path.samefile(client['executable'],d['native']['argv'][0])and sha(client['executable'])==d['native_binary_sha256'],'exact client target')
 need(all(c['status']in [0,-25205,-25212]for c in client['calls']),'unexpected external AX read status')
 nodes=client['nodes']
 for identifier,role in [('tool-block','AXButton'),('tool-connector','AXButton'),('tool-note','AXButton'),('drawing','AXGroup')]:
  native_id='node:'+base64.urlsafe_b64encode(identifier.encode()).decode().rstrip('=');matches=[n for n in nodes if n.get('AXIdentifier')==native_id];need(len(matches)==1 and matches[0].get('AXRole')==role and matches[0].get('AXTitle')=={'tool-block':'Block','tool-connector':'Connector','tool-note':'Note','drawing':'Component canvas'}[identifier],'expected placement semantics '+identifier);frame=matches[0].get('screen_frame');need(type(frame)is list and len(frame)==4 and frame[2]>0 and frame[3]>0,'positive placement geometry '+identifier)
 events=[json.loads(l)for l in(out/'probe/events.jsonl').read_bytes().splitlines()];need(events[-1]['event']=='placement.probe.closed','native closed record')
 final=events[-1];need(final['native_error']=='<nil>'and final['observer_error']=='<nil>'and final['deadline_error']=='context deadline exceeded','expected no-input diagnostic deadline')
 for event in events:
  need(event['geometry_persistence_disabled']is True,'placement persistence disabled');s=event['state'];need(not s['Objects']and not s['Gesture']['Active']and not s['Gesture']['Dragging']and s['History']['UndoCount']==0 and s['History']['RedoCount']==0 and all(s[k]==0 for k in ['SourceActivations','CanvasChanges','Removals','Next','Reserved']),'read-only state unchanged')
 return dict(external_ax=client,native_event_records=len(events),expected_no_input_deadline=True,placement_workflow_qualified=False,physical_input_verified=False)
