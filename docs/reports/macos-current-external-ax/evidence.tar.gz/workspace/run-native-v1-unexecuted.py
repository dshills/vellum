"""Two serial, stopped-on-return native fixtures observed by read-only AX clients."""
from pathlib import Path
import contextlib,datetime,hashlib,importlib.util,json,os,selectors,subprocess,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017');T=Path('/private/tmp/vellum-macos-native-results-97aee13');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
build=module('external_ax_build',W/'build-native.py')
sys.path.insert(0,str(W.parent/'macos-grid-native-stacks'));owned=module('owned_external_ax',W.parent/'macos-grid-native-stacks/run.py')
sha=build.sha

def need(ok,message):
 if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_bytes())
def validate(case,out,d):
 need(d['native']['exit_code']==(0 if case=='editor'else 1),'native expected exit')
 need(d['elapsed_seconds']>=(59.5 if case=='editor'else 19.5),'normal fixture lifetime')
 need(d.get('client',{}).get('exit_code')==0,'external AX client failure')
 client=read(out/'client.stdout');need(client.get('result')=='pass','external AX outcome')
 if case=='editor':
  need(client['pid']==d['native']['pid']and client['accessibility_trusted']is True and client['exact_value']is True and client['selection_utf16']==[1,2]and client['selected_text']=='😀'and client['combining_range_utf16']==[3,2]and client['final_line_range_utf16'][1]==0 and client['hebrew_visual_rtl']is True,'external editor assertions')
  return dict(external_ax=client,geometry_persistence_disabled=d['fixture']['geometry_persistence_disabled_in_fixture'],physical_input_verified=False)
 need(client['pid']==d['native']['pid']and client['trusted']is True and client['actions_performed']is False and client['settings_changed']is False and client['prompt']is False and client['complete_bounded_walk']is True,'read-only owned tree')
 need(client['expected_title']=='Vellum native placement probe'and client['executable']==d['native']['argv'][0],'exact client target')
 need(all(c['status']in [0,-25205,-25212]for c in client['calls']),'unexpected external AX read status')
 nodes=client['nodes']
 for identifier,role in [('tool-block','AXButton'),('tool-connector','AXButton'),('tool-note','AXButton'),('drawing','AXGroup')]:
  matches=[n for n in nodes if n.get('AXIdentifier')==identifier];need(len(matches)==1 and matches[0].get('AXRole')==role,'expected placement semantics '+identifier);frame=matches[0].get('screen_frame');need(type(frame)is list and len(frame)==4 and frame[2]>0 and frame[3]>0,'positive placement geometry '+identifier)
 events=[json.loads(l)for l in(out/'probe/events.jsonl').read_bytes().splitlines()];need(events[-1]['event']=='placement.probe.closed','native closed record')
 final=events[-1];need(final['native_error']=='<nil>'and final['observer_error']=='<nil>'and final['deadline_error']=='context deadline exceeded','expected no-input diagnostic deadline')
 for event in events:
  need(event['geometry_persistence_disabled']is True,'placement persistence disabled');s=event['state'];need(not s['Objects']and not s['Gesture']['Active']and not s['Gesture']['Dragging']and s['History']['UndoCount']==0 and s['History']['RedoCount']==0 and all(s[k]==0 for k in ['SourceActivations','CanvasChanges','Removals','Next','Reserved']),'read-only state unchanged')
 return dict(external_ax=client,native_event_records=len(events),expected_no_input_deadline=True,placement_workflow_qualified=False,physical_input_verified=False)

def main():
 need(len(sys.argv)==2 and sys.argv[1]in ['editor','placement'],'fixed diagnostic case');case=sys.argv[1];review=read(W/'native-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'execution review');pins=review['inputs']
 stable=lambda:all(sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(P/'stop-live').exists()
 receipt=read(P/'native-build/receipt.json');source=read(P/'native-build/source.json');need(receipt['error']is None and receipt['source_stable']and build.identity()==source,'exact current framework/build source')
 native=receipt['binaries'][case]['binary'];client_binary=read(P/'receipt.json')['binary_sha256']if case=='editor'else read(P/'window-helper-build/receipt.json')['binary']['sha256'];client_path=P/'inspector'if case=='editor'else P/'window-helper-build/window-readonly'
 need(sha(native['path'])==native['sha256']and Path(native['path']).stat().st_size==native['bytes']and sha(client_path)==client_binary,'binary bytes')
 need(stable()and not stopping(),'initial admission')
 with owned.LiveLease()as lease:
  need(lease.held()and stable()and not stopping(),'lease admission')
  if case=='placement':
   previous=read(P/'runs/editor/receipt.json');need(previous['result']=='PASS_READ_ONLY_EXTERNAL_AX','editor predecessor')
   for child in previous['retirement'].values():owned.absent(child['pid'])
  out=P/'runs'/case;out.mkdir(parents=True,mode=0o700);(out/'runtime').mkdir(mode=0o700)
  if case=='placement':(out/'probe').mkdir(mode=0o700)
  env={**owned.child_environment(True),'GOMAXPROCS':'2'}
  if case=='placement':env['VELLUM_NATIVE_PLACEMENT_PROBE']=str(out/'probe')
  start=time.monotonic();d=dict(case=case,result='STARTED',producer_sha256=sha(__file__),review_sha256=sha(W/'native-readiness.json'),source_sha256=sha(P/'native-build/source.json'),native_binary_sha256=native['sha256'],client_binary_sha256=client_binary,error=None,cleanup_errors=[],native_runtime_executed=False,physical_input_generated=False,settings_changed=False,fixture_overlay_explicit=True,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());children={};terminals={};streams={};ready_at=None;pending=b'';errors=d['cleanup_errors']
  try:
   with contextlib.ExitStack()as stack,selectors.DefaultSelector()as selector:
    def launch(name,argv):
     need(stable()and lease.held()and not stopping(),'child launch admission')
     child=subprocess.Popen(argv,cwd=out/'runtime',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);children[name]=child;d[name]=dict(pid=child.pid,argv=argv,started_native_elapsed_seconds=time.monotonic()-start)
     for suffix,pipe in [('stdout',child.stdout),('stderr',child.stderr)]:
      label=name+'.'+suffix;streams[label]=dict(file=stack.enter_context((out/label).open('xb')),count=0,digest=hashlib.sha256(),eof=False);selector.register(pipe,selectors.EVENT_READ,label)
     (out/('owned-'+name+'.json')).write_text(json.dumps(d[name],indent=2)+'\n');return child
    native_child=launch('native',[native['path']]+(['-ax-fixture']if case=='editor'else[]));d['native_runtime_executed']=True;print(json.dumps(dict(event='native.started',case=case,pid=native_child.pid)),flush=True)
    while selector.get_map()or any(c.poll()is None for c in children.values()):
     now=time.monotonic();need(not stopping(),'human-return stop');need(now-start<(80 if case=='editor'else 35),'native watchdog')
     for name,child in children.items():
      if child.poll()is not None:
       terminals.setdefault(name,now);need(not any(k.data.startswith(name+'.')for k in selector.get_map().values())or now-terminals[name]<5,'surviving pipe writer')
      elif name=='client':need(now-start-d['client']['started_native_elapsed_seconds']<(35 if case=='editor'else 8),'client watchdog')
     for key,_ in selector.select(.1):
      data=os.read(key.fd,64<<10);label=key.data;s=streams[label]
      if not data:s['eof']=True;selector.unregister(key.fileobj);continue
      accepted=min(len(data),(8<<20)-s['count']);need(s['file'].write(data[:accepted])==accepted,'short stream write');s['file'].flush();s['count']+=accepted;s['digest'].update(data[:accepted]);need(accepted==len(data),'stream byte bound')
      if label=='native.stdout'and case=='editor'and ready_at is None:
       pending+=data;need(len(pending)<=256<<10,'ready parser bound')
       while b'\n'in pending:
        line,pending=pending.split(b'\n',1)
        if line.startswith(b'EDITOR_AX_FIXTURE '):
         fixture=json.loads(line[len(b'EDITOR_AX_FIXTURE '):]);need(fixture['pid']==native_child.pid and fixture['lifetime_seconds']==60 and fixture['geometry_persistence_disabled_in_fixture']is True,'editor fixture identity/persistence');text=fixture['text'];need(type(text)is str and len(text.encode())<=4<<20 and '\0'not in text,'fixture text bound');(out/'expected.txt').write_bytes(text.encode());d['fixture']=fixture;ready_at=now
     if case=='placement'and ready_at is None and(out/'probe/latest.json').exists():
      path=out/'probe/latest.json';need(path.stat().st_size<=256<<10,'probe latest bound');record=read(path)
      if record.get('accessibility',{}).get('reachable')is True:
       need(record['geometry_persistence_disabled']is True,'placement fixture persistence');d['fixture_ready']=record;ready_at=now
     if ready_at is None:need(now-start<10,'native readiness watchdog')
     if ready_at is not None and 'client'not in children and now-ready_at>=.5:
      need(native_child.poll()is None,'native ended before external query')
      argv=[str(client_path),str(native_child.pid),str(out/'expected.txt')]if case=='editor'else[str(client_path),str(native_child.pid),native['path'],'Vellum native placement probe'];launch('client',argv);print(json.dumps(dict(event='client.started',case=case,pid=children['client'].pid)),flush=True)
     if case=='placement'and(out/'probe/events.jsonl').exists():need((out/'probe/events.jsonl').stat().st_size<=8<<20,'probe journal bound')
    for name,child in children.items():d[name]['exit_code']=child.wait(timeout=5)
  except BaseException as e:d['error']=dict(type=type(e).__name__,message=str(e))
  finally:
   d['retirement']={name:owned.retire(child,name,errors)for name,child in reversed(list(children.items()))}
   try:d['source_stable']=build.identity()==source;d['pins_stable']=stable()
   except BaseException as e:errors.append(dict(stage='source-observation',type=type(e).__name__,message=str(e)))
   d['logs']={label:dict(bytes=(out/label).stat().st_size,sha256=sha(out/label),eof=s['eof'])for label,s in streams.items()};d['logs_complete']=bool(streams)and all(s['eof']and d['logs'][label]['bytes']==s['count']and d['logs'][label]['sha256']==s['digest'].hexdigest()for label,s in streams.items());d.update(elapsed_seconds=time.monotonic()-start,lease_held_through_cleanup=lease.held(),stop_marker_at_exit=stopping(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
   try:
    need(d['error']is None and not errors and d.get('source_stable')and d.get('pins_stable')and d['logs_complete']and lease.held()and not stopping(),'diagnostic controls')
    need(set(children)=={'native','client'}and all(r['terminal']and r['group_absent']for r in d['retirement'].values()),'both owned groups retired');d['validation']=validate(case,out,d);d['result']='PASS_READ_ONLY_EXTERNAL_AX'
   except BaseException as e:
    if d['error']is None:d['error']=dict(type=type(e).__name__,message=str(e))
    d['result']='FAILED_OR_CANCELED_READ_ONLY_EXTERNAL_AX'
   (out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k]for k in ['case','result','error','cleanup_errors','elapsed_seconds']}),flush=True)
  need(d['result']=='PASS_READ_ONLY_EXTERNAL_AX','external AX diagnostic failed')
if __name__=='__main__':main()
