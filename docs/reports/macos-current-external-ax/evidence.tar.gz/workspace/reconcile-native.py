"""Reconcile preserved native output; original failed collection remains immutable."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017')
spec=importlib.util.spec_from_file_location('corrected_validation',W/'validation-v2.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);run=v.frozen;sha=run.sha
review=run.read(W/'native-readiness.json');assert review['execution_ready']and not review['unresolved_findings'];assert all(sha(p)==h for p,h in review['inputs'].items())
assert run.build.identity()==run.read(P/'native-build/source.json')
cases={};originals={}
for name in ['editor','placement']:
 out=P/'runs'/name;r=run.read(out/'receipt.json')
 if name=='editor':assert r['result']=='PASS_READ_ONLY_EXTERNAL_AX'and r['error']is None
 else:assert r['result']=='FAILED_OR_CANCELED_READ_ONLY_EXTERNAL_AX'and r['error']==dict(type='ValueError',message='exact client target')
 assert not r['cleanup_errors']and all(r[k]is True for k in ['native_runtime_executed','source_stable','pins_stable','logs_complete','lease_held_through_cleanup'])and r['stop_marker_at_exit']is False
 assert set(r['retirement'])=={'native','client'}and all(d['terminal']and d['group_absent']and d['exit_code']==r[n]['exit_code']for n,d in r['retirement'].items())
 fresh={n:run.owned.absent(d['pid'])for n,d in r['retirement'].items()}
 for path,item in r['logs'].items():assert(out/path).stat().st_size==item['bytes']and sha(out/path)==item['sha256']and item['eof']
 validation=v.validate(name,out,r)
 if name=='editor':assert validation==r['validation']
 client=validation['external_ax'];item=dict(original_receipt_sha256=sha(out/'receipt.json'),original_collection_result=r['result'],original_collection_error=r['error'],corrected_validation=validation,native_binary_sha256=r['native_binary_sha256'],client_binary_sha256=r['client_binary_sha256'],controller_elapsed_seconds=r['elapsed_seconds'],native_observed_lifetime_seconds=r['native']['terminal_native_elapsed_seconds']-r['native']['started_native_elapsed_seconds'],client_observed_lifetime_seconds=r['client']['terminal_native_elapsed_seconds']-r['client']['started_native_elapsed_seconds'],client_reported_query_elapsed_seconds=client['elapsed_ns']/1e9 if 'elapsed_ns'in client else None,fresh_group_absence=fresh)
 if name=='placement':
  a,b=client['executable'],r['native']['argv'][0];sa,sb=os.stat(a),os.stat(b);assert os.path.samefile(a,b)and sha(a)==sha(b)==r['native_binary_sha256'];item['current_alias_observation']=dict(client_spelling=a,launched_spelling=b,client_resolved=str(Path(a).resolve()),launched_resolved=str(Path(b).resolve()),device_inode_client=[sa.st_dev,sa.st_ino],device_inode_launched=[sb.st_dev,sb.st_ino],same_file=True,binary_sha256=sha(a),observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 cases[name]=item;originals[name]=sha(out/'receipt.json')
result=dict(schema='vellum-current-external-ax-reconciliation-v1',result='CORRECTED_VALIDATION_OF_PRESERVED_RUNTIME',framework_commit=run.build.COMMIT,cases=cases,original_receipts_unchanged=all(sha(P/'runs'/n/'receipt.json')==h for n,h in originals.items()),all_original_fifty_input_pins_unchanged=True,build_source_sha256=sha(P/'native-build/source.json'),native_build_receipt_sha256=sha(P/'native-build/receipt.json'),readiness_sha256=sha(W/'native-readiness.json'),correction_sha256=sha(W/'validation-correction.json'),validator_sha256=sha(W/'validation-v2.py'),producer_sha256=sha(__file__),fixture_overlay_explicit=True,source_implementation_changed=False,physical_pointer_keyboard_verified=False,placement_workflow_qualified=False,voiceover_tested=False,ime_tested=False,preferences_changed=False,cua_retry_performed=False,earlier_cua_timeout_cause='unassigned',full_macos_qualified=False,scope='Current read-only external text/range and palette/canvas identity/geometry. Original placement collector failure retained; corrected identity rules re-evaluate preserved output, without runtime replay.')
(W/'native-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(result=result['result'],framework_commit=result['framework_commit'],cases={k:{p:v[p]for p in ['original_collection_result','native_observed_lifetime_seconds','client_observed_lifetime_seconds','client_reported_query_elapsed_seconds']}for k,v in cases.items()},original_receipts_unchanged=result['original_receipts_unchanged'])))
