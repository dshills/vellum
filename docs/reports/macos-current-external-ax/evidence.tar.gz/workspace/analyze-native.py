"""Reconcile raw read-only AX outcomes without claiming physical workflow acceptance."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-external-ax-diagnostic-20261017')
spec=importlib.util.spec_from_file_location('readonly_ax_run',W/'run-native.py');run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
sha=run.sha
cases={}
for name in ['editor','placement']:
 out=P/'runs'/name;r=run.read(out/'receipt.json');assert r['result']=='PASS_READ_ONLY_EXTERNAL_AX'and r['error']is None and not r['cleanup_errors']
 assert all(r[k]is True for k in ['native_runtime_executed','source_stable','pins_stable','logs_complete','lease_held_through_cleanup'])and r['stop_marker_at_exit']is False
 assert set(r['retirement'])=={'native','client'}and all(v['terminal']and v['group_absent']for v in r['retirement'].values())
 for path,item in r['logs'].items():assert(out/path).stat().st_size==item['bytes']and sha(out/path)==item['sha256']and item['eof']
 validation=run.validate(name,out,r);assert validation==r['validation']
 client=r['validation']['external_ax'];case=dict(receipt_sha256=sha(out/'receipt.json'),native_binary_sha256=r['native_binary_sha256'],client_binary_sha256=r['client_binary_sha256'],controller_elapsed_seconds=r['elapsed_seconds'],native_observed_lifetime_seconds=r['native']['terminal_native_elapsed_seconds']-r['native']['started_native_elapsed_seconds'],client_observed_lifetime_seconds=r['client']['terminal_native_elapsed_seconds']-r['client']['started_native_elapsed_seconds'],client_reported_query_elapsed_seconds=client['elapsed_ns']/1e9 if 'elapsed_ns'in client else None,scope='read-only current native text/ranges'if name=='editor'else'bounded current native palette/canvas tree and geometry; expected no-input deadline')
 if name=='editor':case['external_ax']=client
 else:
  case['native_event_records']=validation['native_event_records'];case['read_calls']=len(client['calls']);case['read_errors']=[c for c in client['calls']if c['status']!=0];case['nodes']=client['nodes'];case['window_titles']=client['window_titles']
 cases[name]=case
result=dict(schema='vellum-current-external-ax-diagnostic-v1',framework_commit=run.build.COMMIT,cases=cases,source_sha256=sha(P/'native-build/source.json'),build_receipt_sha256=sha(P/'native-build/receipt.json'),review_sha256=sha(W/'native-readiness.json'),analyzer_sha256=sha(__file__),fixture_overlay_explicit=True,source_implementation_changed=False,physical_pointer_keyboard_verified=False,placement_workflow_qualified=False,voiceover_tested=False,ime_tested=False,preferences_changed=False,cua_retry_performed=False,earlier_cua_timeout_cause='unassigned',full_macos_qualified=False)
(W/'native-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(framework_commit=result['framework_commit'],cases={k:{p:v[p]for p in ['scope','controller_elapsed_seconds','native_observed_lifetime_seconds','client_observed_lifetime_seconds','client_reported_query_elapsed_seconds']}for k,v in cases.items()},physical_workflow_qualified=False)))
