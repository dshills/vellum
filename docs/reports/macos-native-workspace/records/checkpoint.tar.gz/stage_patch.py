"""Produce the independently hash-pinned Core origin routing patch, no checkout mutation."""
from pathlib import Path
import difflib,hashlib,json,shutil
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');I=W/'candidate';D=W/'install/drivers/cogent/native/patches/desktoprouting';D.mkdir(parents=True,exist_ok=True)
original={};output={};parts=[]
for n in ['core/scene.go','core/renderwindow.go','core/origin_custom.go','core/origin_custom_offscreen_test.go']:
 before=C/'drivers/cogent/build/upstream'/n;after=I/'prepared'/n
 old=before.read_bytes()if before.exists()else b'';new=after.read_bytes();original[n]=hashlib.sha256(old).hexdigest()if before.exists()else None;output[n]=hashlib.sha256(new).hexdigest()
 parts.append(''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+n if before.exists()else'/dev/null',tofile='b/'+n)))
p=D/'0081-window-origin-custom-routing.patch';p.write_text(''.join(parts))
(D/'original-hashes.json').write_text(json.dumps(original,indent=2)+'\n');(D/'output-hashes.json').write_text(json.dumps(output,indent=2)+'\n')
p=W/'install/drivers/cogent/native/dependencies.json';manifest=json.loads((C/'drivers/cogent/native/dependencies.json').read_text());manifest['dependencies'][0]['stages'].append({'origin':'drivers/cogent/native/patches/desktoprouting','inputs':'native/patches/desktoprouting/original-hashes.json','outputs':'native/patches/desktoprouting/output-hashes.json','patches':[{'file':'native/patches/desktoprouting/0081-window-origin-custom-routing.patch','sha256':hashlib.sha256((D/'0081-window-origin-custom-routing.patch').read_bytes()).hexdigest()}]});p.write_text(json.dumps(manifest,indent=2)+'\n')
(D/'README.md').write_text('''# Window-origin Custom routing (stage 81)

Adds an optional main-scene handler for Custom events before modal stage routing,
inside the existing render-context lock. Only the owning integration session\'s
private Custom requests are consumed. Ordinary Custom and every non-Custom event
retain normal popup/hit-test/capture routing. Install before native startup or
from its event loop; clear on teardown. A real software modal MenuStage regression
proves interception, fallback and revocation. It is routing evidence, not native
physical input or presentation qualification. No tracing lock spans the callback.
''')
p=W/'stage81-patch.json';p.write_text(json.dumps({'inputs':original,'outputs':output,'patch_sha256':hashlib.sha256((D/'0081-window-origin-custom-routing.patch').read_bytes()).hexdigest(),'native_executed':False},indent=2)+'\n')
print(p)
