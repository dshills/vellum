from pathlib import Path
W=Path(__file__).resolve().parent;I=W/'candidate'
p=I/'drivers/cogent/desktop_session.go';s=p.read_text().replace('r.node.Outline','r.node.Tree').replace('len(r.node.CanvasObjects)>0 && r.control.placement!=nil','r.control.placement!=nil');p.write_text(s)
p=I/'examples/replay/workspace/native.go';s=p.read_text().replace('"strings"','"strings"\n"sort"')
s=s.replace('ref:=refs[o.Window];receipt:=','if o.CheckRevision { var revision uint64; if e:=f.Owner.Do(func(){revision=f.Snapshot().HistoryRevision});e!=nil{return report,e};if revision!=o.ExpectedRevision{return report,fmt.Errorf("native operation %d revision: got %d want %d",o.Sequence,revision,o.ExpectedRevision)} }\nref:=refs[o.Window];receipt:=')
s=s.replace('for _,el:=range snap.Elements{if el.ID==id||el.ID==encoded||el.ID==qualified{if !el.Enabled||el.Bounds.Empty(){return el,cogent.ErrDesktopPending};return el,nil}}','for _,el:=range snap.Elements{if el.ID==id||el.ID==encoded||el.ID==qualified{return el,nil}}')
s=s.replace('in.Target=el.ID','if !el.Enabled||el.Bounds.Empty(){err=cogent.ErrDesktopPending;break}\nin.Target=el.ID')
s=s.replace('if !reflect.DeepEqual(actual,expected){return fmt.Errorf("native model mismatch at %s",got.Label)}','if !reflect.DeepEqual(actual,expected){return fmt.Errorf("native model mismatch at %s: %s",got.Label,nativeDifference(actual,expected))}')
s=s.replace('for _,w:=range want.Windows{if !ids[w.ID]{return fmt.Errorf("native window %s missing",w.ID)}}','''for _,w:=range want.Windows{
 if !ids[w.ID]{return fmt.Errorf("native window %s missing",w.ID)}
 var live cogent.DesktopSnapshot;for _,v:=range got.Windows{if v.ID==w.ID{live=v.Snapshot}}
 if w.FocusedID!="" { el,e:=nativeTarget(live,w.FocusedID);if e!=nil||!el.Focused{return fmt.Errorf("native focus %q missing at %s",w.FocusedID,got.Label)} }
 if len(live.Grids)!=len(w.Grids)||len(live.Trees)!=len(w.Trees){return fmt.Errorf("native composite publication count differs at %s",got.Label)}
 for _,g:=range live.Grids{
  if g.Scale<=0||g.Bounds.Empty()||g.Viewport!=got.Model.Grid.Viewport||g.RetainedCells>4096||len(g.Cells)>4096||g.Generation==0||g.Frames==0{return errors.New("invalid native grid geometry/state")}
  if math.Abs(float64(g.Bounds.Dx())/float64(g.Scale)-g.Viewport.Width-12)>2||math.Abs(float64(g.Bounds.Dy())/float64(g.Scale)-g.Viewport.Height-12)>2{return errors.New("native grid allocation/viewport disagreement")}
  for _,c:=range g.Cells{if !c.Bounds.Empty()&&!c.Bounds.In(g.Bounds){return errors.New("unclipped native grid cell")}}
 }
 for _,t:=range live.Trees{
  if t.Scale<=0||t.Bounds.Empty()||t.Viewport!=got.Model.Tree.Viewport||t.RetainedRows>128||len(t.Rows)>128||t.Generation==0||t.Frames==0{return errors.New("invalid native tree geometry/state")}
  for _,r:=range t.Rows{if !r.Bounds.Empty()&&!r.Bounds.In(t.Bounds){return errors.New("unclipped native tree row")}}
 }
 for _,c:=range live.Canvases{if c.View!=got.Model.Canvas.View||c.Bounds[2]<=0||c.Bounds[3]<=0||c.Generation==0||c.TotalObjects!=len(got.Model.Canvas.Objects){return errors.New("native canvas publication/model disagreement")}}
 }''')
s+='''
// nativeDifference is bounded diagnostic output; the original immutable domain
// oracle still decides success. It does not normalize unexpected values.
func nativeDifference(got,want any)string{
 a,_:=json.Marshal(got);b,_:=json.Marshal(want);var x,y any;_ =json.Unmarshal(a,&x);_=json.Unmarshal(b,&y)
 var visit func(string,any,any)string
 visit=func(path string,a,b any)string{
  if reflect.DeepEqual(a,b){return ""}
  am,aok:=a.(map[string]any);bm,bok:=b.(map[string]any)
  if aok&&bok{keys:=make([]string,0,len(am)+len(bm));seen:=map[string]bool{};for k:=range am{seen[k]=true};for k:=range bm{seen[k]=true};for k:=range seen{keys=append(keys,k)};sort.Strings(keys);for _,k:=range keys{if d:=visit(path+"."+k,am[k],bm[k]);d!=""{return d}}}
  aa,aok:=a.([]any);bb,bok:=b.([]any);if aok&&bok&&len(aa)==len(bb){for i:=range aa{if d:=visit(fmt.Sprintf("%s[%d]",path,i),aa[i],bb[i]);d!=""{return d}}}
  av,_:=json.Marshal(a);bv,_:=json.Marshal(b);if len(av)>128{av=av[:128]};if len(bv)>128{bv=bv[:128]};return fmt.Sprintf("%s got %s want %s",path,av,bv)
 }
 return visit("model",x,y)
}
'''
p.write_text(s)
