from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;I=W/'candidate';shutil.copytree(I,W/'versions/pre-multiline-constant-fix')
p=I/'examples/replay/workspace/native.go';s=p.read_text().replace('ui.Editor','ui.MultilineText');s=s.replace('if !e.Visible {\n\t\t\t\tcontinue\n\t\t\t}', 'if !e.Visible || strings.Contains(e.ID,"tree:") || strings.Contains(e.ID,"grid:") || strings.Contains(e.ID,"canvas-object:") {\n\t\t\t\tcontinue\n\t\t\t}')
s=s.replace('t.Generation == 0 || t.Frames == 0 {','t.Generation == 0 || t.Frames == 0 || t.Selected!=got.Model.Tree.Selected {');s=s.replace('for _, r := range t.Rows {\n\t\t\t\tif', 'for _, r := range t.Rows {\nif r.Selected!=(r.Key==got.Model.Tree.Selected){return errors.New("native outline row selection disagrees with model")}\n\t\t\t\tif')
s=s.replace('g.Generation == 0 || g.Frames == 0 {','g.Generation == 0 || g.Frames == 0 || !reflect.DeepEqual(g.Selection,got.Model.Grid.Selection) {');p.write_text(s)
p=I/'drivers/cogent/desktop_session_offscreen_test.go';p.write_text(p.read_text()+(W/'desktop_picture_test.draft').read_text())
