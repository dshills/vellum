"""Freeze bounded checkpoint evidence without binaries, caches or SDK copies."""
from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((W/'prism-command.json').read_text())['exit_code'] in [0,1]
assert json.loads((W/'internal-pre-prism-review.json').read_text())['approved']
files={}
def add(p,name=None):
 assert p.is_file()and not p.is_symlink(),str(p)
 b=p.read_bytes();assert len(b)<16<<20,str(p);files[name or p.relative_to(W).as_posix()]=b
for p in W.iterdir():
 if p.is_file()and p.suffix in ['.py','.json','.md','.diff','.stdout','.stderr']:add(p)
for name in ['candidate','baseline','versions','install']:
 root=W/name
 if root.exists():
  for p in root.rglob('*'):
   if p.is_file()and '__pycache__'not in p.parts:add(p)
for root in W.iterdir():
 if root.is_dir()and (root.name.startswith('native-v')or (root/'owned.json').exists()):
  for p in root.rglob('*'):
   if p.is_file()and p.name not in ['.DS_Store']and '__pycache__'not in p.parts:add(p)
# Producers imported by the owned execution harness, already read-only evidence.
for p in [W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py',W.parent/'macos-sdk-native-238b3b6/run.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),T/'scripts/child_process.py',T/'scripts/sdk_environment.py']:
 add(p,'support/'+p.parent.name+'/'+p.name)
paths=run_child(['git','diff','--cached','--name-only','-z','--diff-filter=ACMRT'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode().split('\0')[:-1]
for name in paths:
 b=run_child(['git','show',':'+name],cwd=T,timeout=30,capture_output=True,check=True).stdout;files['adopted/'+name]=b
manifest={'format':1,'base':'594bd37fa531a5160aec96a3c1b13aeefe3aa24e','files':{n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(files.items())},'excluded':'Native binaries, prepared whole-tree build directories, private consumer copies/caches, retained SDK and native archive. Their identities and qualified configurations are retained in raw plans/receipts. Source/evidence and imported support producers are included.','native_complete_cases':['cpu-10000','cpu-1000000'],'closed_full_mac_gates':[]}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();assert sum(map(len,files.values()))<120<<20
out=T/'docs/reports/macos-native-workspace/records';out.mkdir(parents=True,exist_ok=True);target=out/'checkpoint.tar.gz';assert not target.exists()
with target.open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tar:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(target,'r:gz')as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert member.isfile()and tar.extractfile(member).read()==files[member.name]
summary={'path':'checkpoint.tar.gz','sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'members':len(files),'uncompressed_file_bytes':sum(map(len,files.values())),'manifest_sha256':sha(files['MANIFEST.json']),'native_cases':2,'native_operations':432,'native_captures':54,'source_worktree_prepared_files':6263,'closed_full_mac_gates':[]}
(out/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
