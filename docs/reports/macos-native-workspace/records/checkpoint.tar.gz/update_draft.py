from pathlib import Path
import json
W=Path(__file__).resolve().parent;I=W/'candidate';p=I/'drivers/cogent/desktop_session.go';s=p.read_text();s=s.replace('"github.com/dshills/vellum/app"','"github.com/dshills/vellum/app"\n"github.com/dshills/vellum/ui"')
s=s.replace('Elements   []DesktopElement\n}', 'Elements   []DesktopElement\nGrids []GridInspection\nTrees []TreeInspection\nCanvases []CanvasInspection\n}')
s=s.replace('for ref, b := range s.windows {\n\t\tb.window = nil','for ref, b := range s.windows {\nif b.window != nil { b.window.body.Scene.SetOriginCustomHandler(nil); b.window.body.Scene.SetFrameTrace(nil); b.window.desktop = nil }\n\t\tb.window = nil')
s=s.replace('bounds := accessibilityBounds(w.root)\n\tbytes := 0','bounds := accessibilityBounds(w.root)\nfocus := map[string]accessibilityFocusTarget{}\naccessibilityNativeFocusTargets(w.root, "", focus)\nvisible := map[string]bool{}\n\tbytes := 0')
s=s.replace('for _, n := range nodes {\n\t\tif n.GridPending', 'for _, n := range nodes {\nvisible[n.ID] = true\nif target, ok := focus[n.ID]; ok { n.Focused = target.focused }\n\t\tif n.GridPending')
s=s.replace('\treturn out, nil\n}\n\nfunc desktopUnqualifiedInput', '''
 var collect func(*record,string) error
 retained:=0
 collect=func(r *record,prefix string)error{
  if r==nil{return nil}
  if visible[prefix+accessibilityManagedID(r.node.ID)] && r.control!=nil {
   if r.control.grid!=nil { g,e:=InspectGrid(r.control.a,r.node.Grid);if e!=nil{return errors.Join(ErrDesktopPending,e)};retained+=len(g.Cells)+len(g.Headers);if retained>8192{return ErrDesktopBudget};g.ID=prefix+g.ID;out.Grids=append(out.Grids,g) }
   if r.control.outline!=nil { t,e:=InspectTree(r.control.a,r.node.Outline);if e!=nil{return errors.Join(ErrDesktopPending,e)};retained+=len(t.Rows)+len(t.Pages);if retained>8192{return ErrDesktopBudget};t.ID=prefix+t.ID;out.Trees=append(out.Trees,t) }
   if len(r.node.CanvasObjects)>0 && r.control.placement!=nil { b:=r.control.placement;f:=b.frame.Load();if !canvasCompletedFrame(b,f){return ErrDesktopPending};c:=inspectCanvasFrame(b,f);retained+=len(c.Objects);if retained>8192{return ErrDesktopBudget};c.ID=prefix+c.ID;out.Canvases=append(out.Canvases,c) }
  }
  var failure error
  retainedWorkbenchRecords(r,func(panel string,child *record){if failure==nil{failure=collect(child,prefix+accessibilityWorkbenchNamespace(r.node.ID,panel))}})
  if failure!=nil{return failure}
  if edit:=gridEditingRecord(r);edit!=nil{if e:=collect(edit,prefix);e!=nil{return e}}
  for _,c:=range r.children{if e:=collect(c,prefix);e!=nil{return e}}
  return nil
 }
 if e:=collect(w.root,"");e!=nil{return out,e}
 return out,nil
}

// DesktopState is bounded terminal accounting, without retained window roots.
type DesktopState struct { Started, Closed, Pending bool; LiveWindows int; Issued uint64 }
func(s *DesktopSession) State() DesktopState {
 if s==nil || s.self!=s{return DesktopState{Closed:true}}
 s.mu.Lock();defer s.mu.Unlock();s.reapLocked()
 return DesktopState{Started:s.used,Closed:s.closed,Pending:s.pending!=nil,LiveWindows:len(s.windows),Issued:s.next}
}

func desktopUnqualifiedInput''')
s=s.replace('"github.com/dshills/vellum/ui"\n','') # traversal does not need ui
p.write_text(s)
p=I/'drivers/cogent/desktop_session_offscreen_test.go';s=p.read_text();s=s.replace('if _, err = m.Step(testContext, 1); err != nil {\n\t\tt.Fatal(err)\n\t}\n\tcancel()', 'step, stepErr := m.implementation.find("one").core.Step(testContext, 1)\nif stepErr != nil { t.Fatal(stepErr) }\nif step.Events != 1 || step.LastType != events.Custom || s.pending != r || r.kind != 2 || !r.binding.trace.Pending() || r.binding.trace.ReconcileTag() != 0 { t.Fatalf("not an in-flight dispatched originating frame: %+v",step) }\n\tcancel()')
p.write_text(s)
p=I/'examples/replay/workspace/backend_offscreen.go';s=p.read_text();a=s.index('\ttheme := ui.Theme{');b=s.index('\n\tconfig :=',a);s=s[:a]+'\ttheme := FixtureTheme()'+s[b:];s=s.replace('\n\t"image/color"','').replace('\n\t"github.com/dshills/vellum/ui"','');p.write_text(s)
p=I/'overlay.json';x=json.loads(p.read_text());sdk=json.loads((W/'scope.json').read_text())['sdk'];x['Replace'][sdk+'/examples/replay/workspace/native.go']=str(I/'examples/replay/workspace/native.go');p.write_text(json.dumps(x,indent=2)+'\n')
