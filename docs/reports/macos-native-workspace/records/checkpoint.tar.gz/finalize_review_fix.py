from pathlib import Path
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
p=T/'docs/reports/macos-native-workspace/README.md';s=p.read_text().replace('21 synthetic parser/result controls.','21 synthetic parser/result controls and the affected preparation suite after\nincluding stage81 in the pinned patch-order regression.');p.write_text(s)
run_child(['git','add','--','drivers/cogent/prepare_test.py','docs/reports/macos-native-workspace/README.md','scripts/check.sh'],cwd=T,timeout=30,capture_output=True,check=True)
r=run_child(['git','diff','--cached','--check'],cwd=T,timeout=30,capture_output=True);assert r.returncode==0,r.stdout+r.stderr
r=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,capture_output=True,check=True);(W/'pre-prism.diff').write_bytes(r.stdout);print('staged bytes',len(r.stdout))
