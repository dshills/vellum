"""Fresh, bounded native integration; no OS input/settings or sealed operator reuse."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W/'native-v1';I=W/'candidate'
s=importlib.util.spec_from_file_location('workspace_native_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
sys.path.insert(0,str(W));import validate as validator
HEAD='594bd37fa531a5160aec96a3c1b13aeefe3aa24e'
sys.path.insert(0,str(h.T/'scripts'));from child_process import run_child
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def vector(root):
 out={}
 for p in root.rglob('*'):
  h.need(not p.is_symlink(),'regular file vector')
  if p.is_file():out[p.relative_to(root).as_posix()]=h.sha(p)
 return out
def source(root):
 h.need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean current source')
 return {n:h.sha(root/n)for n in git(root,'ls-files','-z').decode().split('\0')[:-1]}
def prepared(root):return{module+'/'+n:z for module in['upstream','typesetting']for n,z in vector(root/'drivers/cogent/build'/module).items()}
def prepare():
 h.need(not N.exists(),'fresh scope');scope=json.loads((W/'scope.json').read_text());sdk=Path(scope['sdk']);review=json.loads((W/'internal-native-source-review-v2.json').read_text());h.need(review['approved']and not review['unresolved_findings'],'source review complete')
 h.need(all(h.sha(p)==z for p,z in review['inputs'].items()),'exact reviewed sources')
 checks=json.loads((W/'native-prerequisites.json').read_text())['checks']
 for name in checks:
  r=json.loads((W/(name+'.json')).read_text());h.need(r['created']and r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors'],'terminal passing check '+name)
  for p in I.rglob('*'):
   if p.is_file():h.need(r['source_pins'].get(str(p))==h.sha(p),'current checked overlay '+name+str(p))
 prepared_check=json.loads((W/'prepare-v1.json').read_text());h.need(prepared_check['exit_code']==0 and prepared_check['prepared_exact']and prepared_check['prepared_files']==6263,'exact stage81 preparation')
 cur=source(h.C);h.need(source(h.T)==cur,'clean current source parity');dep=prepared(h.C);h.need(prepared(h.T)==dep,'prepared parity')
 old=json.loads((W.parent/'macos-grid-paint-51dbe40/plan.json').read_text());h.need(vector(sdk)==old['sdk_files'],'retained SDK unchanged')
 paths=[p for p in I.rglob('*')if p.is_file()]+[W/n for n in ['native.py','validate.py','scope.json','check.py','native-prerequisites.json','internal-native-source-review-v2.json','contract-draft.md','validate.py','validation_controls.py','validation-controls-v2.json','prepare_check.py','prepare-v1.json','stage81-patch.json']]+[W/(n+'.json')for n in checks]+[Path(h.__file__),h.GUARD,h.GO,Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),h.T/'scripts/child_process.py',h.T/'scripts/sdk_environment.py']
 p={'head':HEAD,'source':cur,'prepared':dep,'sdk':str(sdk),'sdk_files':old['sdk_files'],'pins':{str(p):h.sha(p)for p in paths},'binary':{'path':str(W/'workspace-native'),'sha256':h.sha(W/'workspace-native')},'cases':{'cpu-10000':10000,'cpu-1000000':1000000},'launch_deadline_utc':scope['reassess_by_utc'],'watchdog_seconds':240,'stream_limit_bytes':16<<20,'scope':'Two default CPU-scene native processes, each complete216 immutable operation kinds/order with actual native compositions plus extra readiness frames,27 domain/semantic/geometry captures and terminal refs/worker/nativeinventory assertions. Native window and target capabilities are current native WindowRef/frame/exactID, not reused manual incarnation integers. Geometry anchors from independent authorCase semantics; no wholewindowratio fallback. Exact domain except independently validated nativeviewport dimensions and frozen<=1logicalpixelcamera bar; exactobjects/history/data/selection/editor/taborder/zoom/scroll. Initial 51ms nativewallwait only, manualworkerselection. Not deterministicReplay.Runner/physicalOSinput/IME/VoiceOver/presentation/performance/catalogue/SDK qualification. Shared exclusive lease; IPnetwork denied; no OS input/preferences; no sealedscope/operator reset/retry. Any failure seals scope and blocks secondcase. Source/prepared/SDK unchanged throughout. No public release.'}
 N.mkdir();(N/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':h.sha(N/'plan.json'),'cases':p['cases'],'native_executed':False}))
def run():
 raw=(N/'plan.json').read_bytes();araw=(N/'admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw);stop=N/'stop-live';sdk=Path(p['sdk'])
 h.need(a['approved']and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'reviewed exact plan');h.need(not stop.exists()and not(N/'result.json').exists(),'fresh execution')
 def stable():return (N/'plan.json').read_bytes()==raw and(N/'admission.json').read_bytes()==araw and all(h.sha(k)==z for k,z in p['pins'].items())and h.sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  h.need(not stop.exists()and stable(),'stop and pinned sources');h.need(source(h.C)==source(h.T)==p['source']and prepared(h.C)==prepared(h.T)==p['prepared']and vector(sdk)==p['sdk_files'],'whole checkout/prepared/SDK identity')
 def interrupted(signum,frame):raise InterruptedError('native controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted);result={'result':'INCOMPLETE','completed':[],'native_executed':False,'error':None,'closed_mac_gates':[]}
 try:
  with g.LiveLease()as lease:
   for name,rows in p['cases'].items():
    boundary();h.need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline');h.need(not(N/name).exists(),'fresh case')
    cr={'result':'INCOMPLETE','error':None,'rows':rows}
    try:
     argv=['/usr/bin/sandbox-exec','-p',h.PROFILE,p['binary']['path'],'-rows='+str(rows),'-timeout=3m']
     r=g.execute(argv,sdk/'examples/replay',N/name,lambda:stop.exists()or(N/('stop-'+name)).exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);cr['run']=r;result['native_executed']|=r['created']
     h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned native case succeeded')
     h.need(not(N/name/'stderr').read_bytes(),'empty native stderr');cr['summary']=validator.validate((N/name/'stdout').read_bytes(),rows)
     boundary();h.need(lease.held(),'lease through cleanup');cr['result']='PASS_NATIVE_AUTONOMOUS_WORKSPACE';result['completed'].append(name)
    except BaseException as e:cr.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
    finally:
     (N/('stop-'+name)).touch();(N/(name+'-result.json')).write_text(json.dumps(cr,indent=2)+'\n');print(json.dumps({'case':name,'result':cr['result'],'error':cr['error']}),flush=True)
   result['result']='PASS_NATIVE_WORKSPACE_RECORDS_DEFAULT_SCENE'
 except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(N/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 if result['error']:sys.exit(1)
if __name__=='__main__':h.need(sys.argv[1:]in[['prepare'],['run']],'fixed phase');prepare()if sys.argv[1]=='prepare'else run()
