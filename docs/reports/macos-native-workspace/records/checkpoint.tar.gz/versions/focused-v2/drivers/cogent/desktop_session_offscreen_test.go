//go:build offscreen

package cogent

import (
	"context"
	"errors"
	"image"
	"testing"
	"time"

	"cogentcore.org/core/events"
	"cogentcore.org/core/events/key"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
)

// This fixture exercises actual Core FIFO/hit-testing and composition on the
// manual software window. It is not native desktop or physical input evidence.
func desktopFixture(t *testing.T) (*DesktopSession, *Manual, *app.Application, *nativeWindow, *int) {
	t.Helper()
	clicks := new(int)
	m, a := simpleManual(t, manualConfig(t, 7), func() ui.Node {
		return ui.Node{ID: "root", Kind: ui.Column, Children: []ui.Node{{ID: "button", Kind: ui.Button, Text: "Place", Activate: func() { *clicks++ }}}}
	})
	unitSettle(t, m)
	w := m.implementation.find("one").state
	s := NewDesktopSession()
	if err := s.start(a); err != nil {
		t.Fatal(err)
	}
	if err := s.bind(w); err != nil {
		t.Fatal(err)
	}
	w.body.Scene.OnFirst(events.Custom, func(e events.Event) {
		// The production driver drains/refreshed owner work before session handling.
		m.implementation.custom(w, e)
		if err := m.implementation.refresh(m.implementation.find("one")); err != nil {
			t.Fatal(err)
		}
		s.handle(w, e)
	})
	t.Cleanup(func() { s.retire(w); s.close() })
	return s, m, a, w, clicks
}
func desktopPump(t *testing.T, s *DesktopSession, m *Manual, r *desktopRequest) desktopReply {
	t.Helper()
	for range 256 {
		if _, err := m.Step(testContext, 7); err != nil {
			t.Fatal(err)
		}
		s.mu.Lock()
		s.reapLocked()
		s.mu.Unlock()
		select {
		case out := <-r.reply:
			return out
		default:
		}
	}
	t.Fatal("desktop request did not terminate")
	return desktopReply{}
}
func desktopFrame(t *testing.T, s *DesktopSession, m *Manual, w *nativeWindow) {
	t.Helper()
	r, err := s.submit(testContext, w.window.Ref(), 2, DesktopInput{})
	if err != nil {
		t.Fatal(err)
	}
	out := desktopPump(t, s, m, r)
	if out.err != nil {
		t.Fatal(out.err)
	}
}
func desktopRead(t *testing.T, s *DesktopSession, m *Manual, w *nativeWindow) DesktopSnapshot {
	t.Helper()
	r, err := s.submit(testContext, w.window.Ref(), 0, DesktopInput{})
	if err != nil {
		t.Fatal(err)
	}
	out := desktopPump(t, s, m, r)
	if out.err != nil {
		t.Fatal(out.err)
	}
	return out.snapshot
}
func TestDesktopCompositionSnapshotAndActualClick(t *testing.T) {
	s, m, _, w, clicks := desktopFixture(t)
	desktopFrame(t, s, m, w)
	snap := desktopRead(t, s, m, w)
	var id string
	var bounds image.Rectangle
	for _, el := range snap.Elements {
		if el.DomainID == "button" {
			id, bounds = el.ID, el.Bounds
		}
	}
	if id == "" || bounds.Empty() || snap.Frame == 0 {
		t.Fatal("no completed button geometry")
	}
	for _, typ := range []events.Types{events.MouseDown, events.MouseUp} {
		desktopFrame(t, s, m, w)
		snap = desktopRead(t, s, m, w)
		in := DesktopInput{Frame: snap.Frame, Target: id, Type: typ, Button: events.Left, Position: bounds.Min.Add(bounds.Size().Div(2))}
		r, err := s.submit(testContext, w.window.Ref(), 1, in)
		if err != nil {
			t.Fatal(err)
		}
		if out := desktopPump(t, s, m, r); out.err != nil {
			t.Fatal(out.err)
		}
	}
	unitSettle(t, m)
	if *clicks != 1 {
		t.Fatalf("clicks=%d", *clicks)
	}
	// Mutating a returned snapshot cannot alter a later inspection.
	snap.Elements[0].ID = "changed"
	desktopFrame(t, s, m, w)
	fresh := desktopRead(t, s, m, w)
	if fresh.Elements[0].ID == "changed" {
		t.Fatal("borrowed snapshot")
	}
}
func TestDesktopCanceledQueuedInputRemovedAndCapacityReusable(t *testing.T) {
	s, m, _, w, clicks := desktopFixture(t)
	desktopFrame(t, s, m, w)
	snap := desktopRead(t, s, m, w)
	ctx, cancel := context.WithCancel(context.Background())
	r, err := s.submit(ctx, w.window.Ref(), 1, DesktopInput{Frame: snap.Frame, Type: events.MouseDown, Button: events.Left, Position: image.Pt(20, 20)})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.submit(testContext, w.window.Ref(), 0, DesktopInput{}); !errors.Is(err, ErrDesktopBusy) {
		t.Fatalf("second admission: %v", err)
	}
	cancel()
	s.cancel(r)
	if out := <-r.reply; !errors.Is(out.err, context.Canceled) {
		t.Fatal(out.err)
	}
	source := w.source.Load()
	source.Deque.Mu.Lock()
	for _, e := range source.Deque.Back {
		if e, ok := e.(*desktopFIFO); ok && e.request == r {
			t.Error("canceled FIFO tombstone")
		}
	}
	source.Deque.Mu.Unlock()
	unitSettle(t, m)
	if *clicks != 0 {
		t.Fatal("canceled input delivered")
	}
	desktopRead(t, s, m, w)
}
func TestDesktopCanceledFramePreservesTraceTerminalAndOldFrameInvalid(t *testing.T) {
	s, m, _, w, _ := desktopFixture(t)
	desktopFrame(t, s, m, w)
	old := desktopRead(t, s, m, w)
	ctx, cancel := context.WithCancel(context.Background())
	r, err := s.submit(ctx, w.window.Ref(), 2, DesktopInput{})
	if err != nil {
		t.Fatal(err)
	}
	cancel()
	s.cancel(r)
	if s.pending != r || !r.binding.trace.Pending() {
		t.Fatal("cancellation prematurely retired undispatched trace")
	}
	out := desktopPump(t, s, m, r)
	if out.err == nil {
		t.Fatal("canceled frame succeeded")
	}
	in := DesktopInput{Frame: old.Frame, Type: events.MouseDown, Button: events.Left, Position: image.Pt(20, 20)}
	next, err := s.submit(testContext, w.window.Ref(), 1, in)
	if err != nil {
		t.Fatal(err)
	}
	if out := desktopPump(t, s, m, next); !errors.Is(out.err, ErrDesktopPending) {
		t.Fatalf("old frame admitted: %v", out.err)
	}
	desktopFrame(t, s, m, w)
	desktopRead(t, s, m, w)
}
func TestDesktopRevisionAndWindowRetirementRevokeCapabilities(t *testing.T) {
	s, m, a, w, _ := desktopFixture(t)
	desktopFrame(t, s, m, w)
	s.invalidate(w)
	r, err := s.submit(testContext, w.window.Ref(), 0, DesktopInput{})
	if err != nil {
		t.Fatal(err)
	}
	if out := desktopPump(t, s, m, r); !errors.Is(out.err, ErrDesktopPending) {
		t.Fatal(out.err)
	}
	desktopFrame(t, s, m, w)
	pending, err := s.submit(testContext, w.window.Ref(), 0, DesktopInput{})
	if err != nil {
		t.Fatal(err)
	}
	old := w.window.Ref()
	s.retire(w)
	if out := <-pending.reply; !errors.Is(out.err, ErrDesktopClosed) {
		t.Fatal(out.err)
	}
	if len(s.windows) != 0 || s.pending != nil || pending.binding.window != nil {
		t.Fatal("retained retired native window")
	}
	if _, err := s.submit(testContext, old, 0, DesktopInput{}); !errors.Is(err, ErrDesktopClosed) {
		t.Fatal(err)
	}
	if err := a.CloseWindow(old); err != nil {
		t.Fatal(err)
	}
	if err := a.Open(app.Window{ID: "one", Title: "replacement", Width: 400, Height: 240, View: func() ui.Node { return ui.Node{ID: "new", Kind: ui.Label} }}); err != nil {
		t.Fatal(err)
	}
	if _, err := s.submit(testContext, old, 0, DesktopInput{}); !errors.Is(err, ErrDesktopClosed) {
		t.Fatal("same-name replacement revived ref", err)
	}
	s.close()
	if s.owner != nil || len(s.windows) != 0 {
		t.Fatal("retained application")
	}
}
func TestDesktopInputRefusesOSServiceShortcutsAndInvalidInput(t *testing.T) {
	for _, in := range []DesktopInput{
		{Frame: 1, Type: events.KeyChord, Code: key.CodeC, Rune: 'c', Modifiers: key.Meta},
		{Frame: 1, Type: events.KeyChord, Code: key.CodeV, Rune: 'v', Modifiers: key.Control},
		{Frame: 1, Type: events.MouseDown, Button: events.Right},
		{Type: events.MouseDown, Button: events.Left},
		{Frame: 1, Type: events.WindowPaint},
	} {
		if validateDesktopInput(in) == nil {
			t.Fatalf("admitted %+v", in)
		}
	}
	if err := validateDesktopInput(DesktopInput{Frame: 1, Type: events.KeyChord, Code: key.CodeA, Rune: 'a', Modifiers: key.Meta}); err != nil {
		t.Fatal("select all refused", err)
	}
	s := NewDesktopSession()
	copy := *s
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if _, err := copy.submit(ctx, app.WindowRef{}, 0, DesktopInput{}); !errors.Is(err, ErrDesktopSession) {
		t.Fatal("copied session accepted", err)
	}
}
