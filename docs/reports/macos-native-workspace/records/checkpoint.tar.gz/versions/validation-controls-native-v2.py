"""Synthetic result-oracle refusal controls; executes no native UI."""
from pathlib import Path
import copy,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W));import validate as v
rows=10000;root=v.C/'examples/replay/workspace/records';record=json.loads((root/'10000.json').read_text());goldens=json.loads((root/'10000.golden.json').read_text())
base={'Event':'vellum.workspace-native.result','Result':'PASS_NATIVE_WORKSPACE_RECORD','Error':'','ScenarioJoined':True,'WorkerJoined':True,'Session':{'Started':True,'Closed':True,'Pending':False,'LiveWindows':0,'Issued':1},'Executor':{'Closed':True,'Pending':0,'Running':0,'Failed':0,'Accepted':7,'Completed':7},'Cleanup':{'MainThread':True,'CleanupObserved':True,'CallbacksStopped':True,'PendingCallbacks':0,'NativeOutstanding':0,'AccessibilityWindows':0,'WindowTitles':[],'FilePanels':{'Tracked':0},'Menu':{'Owned':False},'Tray':{'Present':False}},'Workflow':{'Event':'vellum.workspace-native-record.result','Result':'PASS_NATIVE_RECORD_DOMAIN_AND_ROUTING','Rows':rows,'Applied':216,'Operations':[{'Sequence':o['sequence'],'Kind':o['kind'],'Window':o.get('window',''),'Result':'APPLIED'}for o in record['operations']],'Captures':[{'Sequence':g['Sequence'],'Label':g['Label'],'Model':g['Data']['Model'],'Windows':[{'ID':w['ID'],'Snapshot':{'Frame':1,'Size':{'X':1600,'Y':1000},'LogicalDPI':160}}for w in g['Data']['Windows']]}for g in goldens]}}
cases=[]
def case(name,mutate,accept=False):
 d=copy.deepcopy(base);mutate(d);raw=json.dumps(d).encode();error=None
 try:v.validate(raw,rows);passed=True
 except BaseException as e:passed=False;error=str(e)
 assert passed==accept,(name,passed,error);cases.append({'name':name,'expected_accept':accept,'observed_accept':passed,'error':error})
case('synthetic-positive-control',lambda d:None,True)
case('partial-operations',lambda d:d['Workflow']['Operations'].pop())
case('domain-name-mismatch',lambda d:d['Workflow']['Captures'][0]['Model'].__setitem__('Name','unexpected'))
case('unrendered-frame',lambda d:d['Workflow']['Captures'][0]['Windows'][0]['Snapshot'].__setitem__('Frame',0))
case('native-reference-leak',lambda d:d['Session'].__setitem__('LiveWindows',1))
case('worker-not-joined',lambda d:d.__setitem__('WorkerJoined',False))
case('native-inventory-leak',lambda d:d['Cleanup'].__setitem__('NativeOutstanding',1))
case('unbounded-camera-change',lambda d:d['Workflow']['Captures'][0]['Model']['Canvas']['View']['Center'].__setitem__('X',10))
case('wrong-operation-order',lambda d:d['Workflow']['Operations'].reverse())
case('unexpected-retirement',lambda d:d['Workflow']['Operations'][1].__setitem__('Result','EXPECTED_WINDOW_RETIREMENT'))
raw=json.dumps(base).encode()
known=b'2026/10/18 00:42:02 ERROR lines.Lines font style MUST be Monospace. Setting that but should fix upstream | cogentcore.org/core/text/lines.(*Lines).SetFontStyle /bounded/sdk/text/lines/api.go:145\n'
for name,prefix,accept in [('known-fixture-font-diagnostic',known,True),('unexpected-log',b'ERROR unknown native error\n',False),('excess-fixture-font-diagnostics',known*65,False)]:
 error=None
 try:v.validate(prefix+raw,rows);passed=True
 except BaseException as e:passed=False;error=str(e)
 assert passed==accept,(name,passed,error);cases.append({'name':name,'expected_accept':accept,'observed_accept':passed,'error':error})
p=W/'validation-controls-v2.json';assert not p.exists();p.write_text(json.dumps({'synthetic':True,'native_executed':False,'cases':cases},indent=2)+'\n');print(json.dumps({'passed':len(cases),'native_executed':False}))
