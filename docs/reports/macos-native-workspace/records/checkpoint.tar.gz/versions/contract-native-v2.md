# Native workspace integration checkpoint (private draft)

The optional `cogent.DesktopSession` routes initialized Go pointer/key/scroll
packets through each original window's actual native FIFO. It supplies actual
FrameTrace composition barriers and detached completed accessibility, focus and
virtualized grid/tree/canvas geometry. One request across at most 64 live windows
is retained. State is retired with the original WindowRef and driver. It has no
OS event injection, global source state changes or scheduler control.

The `workspace-native` executable consumes the same immutable 216 operations and
27 captures at 10k/1M rows. It keeps explicit worker selection, command/history,
viewport, tree, notes, tabs, palette placement, modal routing and surviving-window
assertions. Authored frame operations and extra per-input barriers wait on native
composition. Advance waits native wall time. It is autonomous integration, not a
`replay.Backend`, deterministic `Replay.Runner`, physical pointer, IME, VoiceOver,
frame presentation or timing qualification.

Native window allocation may differ from the 160-DPI software fixture. Untargeted composite points use independently authored anchors from `authorCase`:
first fully visible frozen-column cell, root disclosure, notes-to-canvas tab
header drag, and canvas world points (32,-24)/(52,-4). They are resolved against
current completed native pane geometry; unknown or clipped cases refuse.
Explicit named targets use actual completed bounds. Logical table/tree scroll
is converted by native DPI; canvas zoom keeps the authored raw wheel magnitude.
Releases at the same authored point use the original down point. Domain objects/history/data/selection/editor/
tab order/zoom/scroll must match immutable goldens exactly. Actual viewport sizes
are measured and validated independently. Camera centers alone permit at most
one logical pixel of drift, frozen before first native run. Focus and matching
completed grid/tree publications must be present; published allocation/viewports
and clipped row/cell bounds are validated. Original software image hashes are
never repurposed as native images or regenerated.

Current status: no native process executed for this checkpoint. Draft has passed
focused routing/cancellation race tests and native consumer compilation. Broad
checks and internal source review are in progress. M2 remains open, as do the
native catalogue, performance targets, resource/endurance, physical/services/
display, final SDK and release audit gates. The retained SDK is unchanged; this
is a private source overlay against its separately identified native archive.

Manual incarnation integers are fixture-instance capabilities. Native admission
uses original native WindowRefs, a current completed-frame capability and exact
qualified target IDs. This run does not qualify historical manual-incarnation
stale/replacement behavior; those remain separately covered by Manual tests.
Desktop canvas publications separately expose copied actual painted objects and
preview state. The existing CanvasInspection.TotalObjects retains its annotated
accessibility-object meaning. Placement-preview must have active/dragging/
accepted block/drawing state at snapped (40,-20), followed by no active preview
and the same actual painted object/history on placement/undo/redo captures.

The result stream permits at most 64 exact, known inherited editor Monospace
fixture diagnostic lines before its single JSON report. Unknown log lines or
extra reports fail validation. Thirteen synthetic parser/result refusal controls
are separate from native execution evidence. They do not qualify native behavior.
