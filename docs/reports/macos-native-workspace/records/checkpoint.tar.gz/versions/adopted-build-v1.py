from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('adopted_build_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
I=W/'candidate';sdk=Path(json.loads((W/'scope.json').read_text())['sdk']);over=json.loads((I/'overlay.json').read_text())['Replace'];paths=list(T.glob('*.go'))
for base in [p for p in T.iterdir()if p.is_dir()and p.name not in ['docs','specs','prototypes','.git','.codex','.agents','drivers','examples']]+[T/'drivers/cogent',T/'examples/replay']:
 paths.extend(p for p in base.rglob('*.go')if 'build'not in p.relative_to(T).parts and 'native'not in p.relative_to(T).parts)
for p in paths:
 q=sdk/p.relative_to(T);value=over.get(str(q),str(q));assert value and Path(value).is_file()and Path(value).read_bytes()==p.read_bytes(),str(p)
for rel in ['go.mod','go.sum','drivers/cogent/go.mod','drivers/cogent/go.sum','examples/replay/go.mod','examples/replay/go.sum']:assert(T/rel).read_bytes()==(sdk/rel).read_bytes()
proof=W/'adoption-go-correspondence.json';proof.rename(W/'adoption-go-correspondence-initial.json')
proof.write_text(json.dumps({'files':len(paths),'mismatches':[],'excluded':'Historical prototype child modules absent from the SDK; generated Core/type source verified separately by whole6263-file preparation vector.','scope':'All root Go package directories and root Go files, driver excluding generated/native directories, replay module, and all three module manifests/sums match retained SDK plus tested overlay.'},indent=2)+'\n')
pins={str(p):h.sha(p)for p in paths};pins[str(Path(__file__))]=h.sha(__file__)
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$'}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),'build','-p=1','-tags=vellum_native_checks','-o',str(W/'workspace-native-adopted'),'./cmd/workspace-native']
r=h.g.execute(av,T/'examples/replay',W/'adopted-build',lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=300,limit=8<<20);r['source_pins']=pins;r['native_executed']=False;r['scope']='Actual source worktree native command compiles with its default native library; does not inherit SDK786a runtime qualification.'
(W/'adopted-build.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['owned']['group_absent']and not r['owned']['errors']else 1)
