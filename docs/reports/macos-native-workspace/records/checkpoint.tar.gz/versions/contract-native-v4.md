# Native workspace integration checkpoint (private draft)

The optional `cogent.DesktopSession` routes initialized Go pointer/key/scroll
packets through each original window's actual native FIFO. It supplies actual
FrameTrace composition barriers and detached completed accessibility, focus and
virtualized grid/tree/canvas geometry. One request across at most 64 live windows
is retained. State is retired with the original WindowRef and driver. It has no
OS event injection, global source state changes or scheduler control.

The `workspace-native` executable consumes the same immutable 216 operations and
27 captures at 10k/1M rows. It keeps explicit worker selection, command/history,
viewport, tree, notes, tabs, palette placement, modal routing and surviving-window
assertions. Authored frame operations and extra per-input barriers wait on native
composition. Advance waits native wall time. It is autonomous integration, not a
`replay.Backend`, deterministic `Replay.Runner`, physical pointer, IME, VoiceOver,
frame presentation or timing qualification.

Native window allocation may differ from the 160-DPI software fixture. Untargeted composite points use independently authored anchors from `authorCase`:
first fully visible frozen-column cell, root disclosure, notes-to-canvas tab
header drag, and canvas world points (32,-24)/(52,-4). They are resolved against
current completed native pane geometry; unknown or clipped cases refuse.
Explicit named targets use actual completed bounds. Logical table/tree scroll
is converted by native DPI; canvas zoom keeps the authored raw wheel magnitude.
Releases at the same authored point use the original down point. Domain objects/history/data/selection/editor/
tab order/zoom/scroll must match immutable goldens exactly. Actual viewport sizes
are measured and validated independently. Camera centers alone permit at most
one logical pixel of drift, frozen before first native run. Focus and matching
completed grid/tree publications must be present; published allocation/viewports
and clipped row/cell bounds are validated. Original software image hashes are
never repurposed as native images or regenerated.

Current status: v2 ran once and failed at capture41; that scope is sealed and
its 1M case was skipped. The corrected v3 adapter is unexecuted. Focused routing,
cancellation, native-oracle, compilation and vet checks pass; complete software
workspace records are running again before v3 source and execution review. M2 remains open, as do the
native catalogue, performance targets, resource/endurance, physical/services/
display, final SDK and release audit gates. The retained SDK is unchanged; this
is a private source overlay against its separately identified native archive.

Manual incarnation integers are fixture-instance capabilities. Native admission
uses original native WindowRefs, a current completed-frame capability and exact
qualified target IDs. This run does not qualify historical manual-incarnation
stale/replacement behavior; those remain separately covered by Manual tests.
Desktop canvas publications separately expose copied actual painted objects and
preview state. The existing CanvasInspection.TotalObjects retains its annotated
accessibility-object meaning. Placement-preview must have active/dragging/
accepted block/drawing state at snapped (40,-20), followed by no active preview
and the same actual painted object/history on placement/undo/redo captures.

Exactly one JSON report is required on stdout. Both streams may contain only
the exact known inherited editor Monospace diagnostics, under one combined
64-line bound. Unknown stderr, JSON on stderr and extra reports fail validation.
Seventeen synthetic parser/result controls are separate from native execution
evidence and do not qualify native behavior.

The first native scope (v2, one process) failed at capture41 because the authored
software Control+A is Home in the actual Mac keymap. The Mac framework mapping
is correct. Native transport now adapts only the independently authored Select
All intents at operations17/122 to Command+A, records the actual chord and checks
that its live binding is SelectAll. Records/goldens and global keymaps/settings
are unchanged. No other chord is adapted. A fresh source/binary/scope must be
reviewed before another native run. The old scope remains sealed; 1M was skipped.
Known inherited editor font diagnostics may be on stderr as in v2; both streams
have the exact-pattern/combined64-line bound, with unknown stderr rejected.

V2 proves tracked fixture/service/session and worker retirement plus process
group absence. Its terminal Cocoa snapshot includes one inactive untitled
NSKVONotifying_TUINSWindow; zero tracked resources does not mean zero Cocoa
windows or complete native-window deallocation. M4 remains open.
