"""Vet a real consumer package directory; Go vet cannot chdir into overlay-only dirs."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,re
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;I=W/'candidate';R=W/'consumer-vet-root-v3';sdk=Path(json.loads((W/'scope.json').read_text())['sdk'])
s=importlib.util.spec_from_file_location('workspace_vet_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
h.need(not R.exists()and not(W/'consumer-vet-v3.json').exists(),'fresh consumer vet root');shutil.copytree(sdk/'examples/replay',R)
for p in (I/'examples/replay').rglob('*'):
 if p.is_file():q=R/p.relative_to(I/'examples/replay');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(R/'workspace/capture_offscreen.go').unlink()
p=R/'go.mod';mod=p.read_text()
mod,count=re.subn(r'=>[ \t]+(\.\./\.\.(?:/[^\s]+)?)',lambda m:'=> '+json.dumps(str(sdk/m.group(1).removeprefix('../..').lstrip('/'))),mod)
h.need(count==5,'five exact relative SDK module replacements');p.write_text(mod)

pins={str(p):h.sha(p)for p in [*I.rglob('*'),*R.rglob('*'),Path(__file__),Path(h.__file__),h.GUARD,h.GO]if p.is_file()}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$'}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),'vet','-p=1','-overlay='+str(I/'overlay.json'),'-tags=vellum_native_checks','./workspace','./cmd/workspace-native']
r=h.g.execute(av,R,W/'consumer-vet-v3',lambda:(W/'stop-integration').exists(),lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=300,limit=8<<20);r['source_pins']=pins;r['native_ui_executed']=False;r['harness_note']='Physical private module copy + absolute local dependency replace paths because Go vet chdir rejects overlay-only new command directory; all implementation files byte-identical to candidate. RetainedSDK unchanged.'
(W/'consumer-vet-v3.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
