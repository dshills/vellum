"""Independent bounded result validation; synthetic controls are not native evidence."""
import json,math,re
from pathlib import Path
W=Path(__file__).resolve().parent
C=Path('/Users/dshills/Development/projects/Vellum')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def validate(raw,rows):
 need(len(raw)<=16<<20,'bounded JSON result')
 lines=raw.decode('utf-8').splitlines();reports=[];warnings=0
 for line in lines:
  if line.startswith('{'):reports.append(line);continue
  need(bool(re.fullmatch(r'\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2} ERROR lines\.Lines font style MUST be Monospace\. Setting that but should fix upstream \| cogentcore\.org/core/text/lines\.\(\*Lines\)\.SetFontStyle .*/text/lines/api\.go:145',line)),'unexpected non-JSON native output')
  warnings+=1;need(warnings<=64,'bounded known fixture font diagnostics')
 need(len(reports)==1,'exactly one result frame')
 d=json.loads(reports[0]);need(d['Event']=='vellum.workspace-native.result'and d['Result']=='PASS_NATIVE_WORKSPACE_RECORD'and not d['Error'],'native report success')
 need(d['ScenarioJoined']and d['WorkerJoined'],'joined scenario/workers')
 s=d['Session'];need(s['Started']and s['Closed']and not s['Pending']and s['LiveWindows']==0 and s['Issued']>0,'session retired')
 ex=d['Executor'];need(ex['Closed']and ex['Pending']==ex['Running']==ex['Failed']==0 and ex['Accepted']==ex['Completed']==7,'seven authored workers, terminal ledger')
 c=d['Cleanup'];need(c['MainThread']and c['CleanupObserved']and c['CallbacksStopped']and c['PendingCallbacks']==c['NativeOutstanding']==c['AccessibilityWindows']==0 and not c['WindowTitles']and c['FilePanels']['Tracked']==0 and not c['Menu']['Owned']and not c['Tray']['Present'],'native inventory retired')
 root=C/'examples/replay/workspace/records';record=json.loads((root/(str(rows)+'.json')).read_bytes());expected=json.loads((root/(str(rows)+'.golden.json')).read_bytes())
 w=d['Workflow'];need(w['Event']=='vellum.workspace-native-record.result'and w['Result']=='PASS_NATIVE_RECORD_DOMAIN_AND_ROUTING'and not w.get('Error')and w['Rows']==rows and w['Applied']==len(record['operations'])==216,'entire authored record')
 need(len(w['Operations'])==216 and len(w['Captures'])==len(expected)==27,'bounded complete routing/capture receipts')
 for o,r in zip(record['operations'],w['Operations']):
  need(r['Sequence']==o['sequence']and r['Kind']==o['kind']and r['Window']==o.get('window',''),'ordered operation identity')
  retirement=r['Result']=='EXPECTED_WINDOW_RETIREMENT';need(r['Result']=='APPLIED'or(retirement and o['sequence']==214 and o['kind']=='pointer-up'),'exactly admitted operation result')
 for g,c in zip(expected,w['Captures']):
  need(c['Sequence']==g['Sequence']and c['Label']==g['Label'],'capture identity')
  actual=json.loads(json.dumps(c['Model']));want=g['Data']['Model']
  for path in [('Grid','Viewport'),('Tree','Viewport'),('Canvas','View')]:
   a=actual[path[0]][path[1]];e=want[path[0]][path[1]]
   for dim in ['Width','Height']:need(isinstance(a[dim],(int,float))and math.isfinite(a[dim])and a[dim]>0,'positive recorded native dimensions');a[dim]=e[dim]
  for dim in ['X','Y']:
   v=actual['Canvas']['View']['Center'][dim];e=want['Canvas']['View']['Center'][dim];need(math.isfinite(v)and abs(v-e)<=1,'frozen camera bar');actual['Canvas']['View']['Center'][dim]=e
  need(actual==want,'immutable domain assertions '+g['Label'])
  need(sorted(v['ID']for v in c['Windows'])==sorted(v['ID']for v in g['Data']['Windows']),'exact surviving window set')
  for win in c['Windows']:
   snap=win['Snapshot'];need(snap['Frame']>0 and snap['Size']['X']>0 and snap['Size']['Y']>0 and math.isfinite(snap['LogicalDPI'])and snap['LogicalDPI']>0,'native frame/geometry capability')
 return {'rows':rows,'known_fixture_font_diagnostics':warnings,'operations':216,'captures':27,'native_scheduling':'autonomous','physical_input':False,'full_mac_qualified':False}
