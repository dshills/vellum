package core

import "cogentcore.org/core/events"

type originCustomHandler struct{ handle func(events.Event) bool }

// SetOriginCustomHandler installs an optional window-origin Custom handler on
// the main Scene. It runs with the native render context locked, before popup
// modality chooses a target Scene. Returning true consumes this Custom event;
// returning false preserves ordinary stage routing. Non-Custom input is never
// intercepted. Install before starting the window or from its event loop.
// Clear the hook during window teardown to release captured application state.
func (sc *Scene) SetOriginCustomHandler(handler func(events.Event) bool) {
	if handler == nil {
		sc.originCustom.Store(nil)
	} else {
		sc.originCustom.Store(&originCustomHandler{handle: handler})
	}
}
func (sc *Scene) dispatchOriginCustom(e events.Event) bool {
	if e.Type() != events.Custom {
		return false
	}
	h := sc.originCustom.Load()
	return h != nil && h.handle(e)
}
