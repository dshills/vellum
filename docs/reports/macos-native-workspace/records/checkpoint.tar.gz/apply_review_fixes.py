from pathlib import Path
import shutil,json
W=Path(__file__).resolve().parent;I=W/'candidate'
shutil.copytree(I,W/'versions/pre-review-fixes')
p=I/'examples/replay/workspace/native.go';s=p.read_text().replace('"github.com/dshills/vellum/app"','"github.com/dshills/vellum/app"\n"github.com/dshills/vellum/canvas"\n"github.com/dshills/vellum/ui"')
s=s.replace('var down image.Point','anchors:=nativeAnchors{}\nvar down image.Point')
a=s.index('\t\t\tscaleX, scaleY :=');b=s.index('\n\t\t\tswitch o.Kind',a);s=s[:a]+s[b:]
needle='\t\t\tif o.Kind == replay.PointerDown {'
a=s.index(needle)
s=s[:a]+'''            if !in.Type.IsKey() && o.Target=="" {
                if o.Kind==replay.PointerUp && downActive && image.Pt(int(o.X),int(o.Y))==downOriginal {in.Position=down} else {in.Position,err=anchors.point(o,snap);if err!=nil{break}}
            }
'''+s[a:]
s=s.replace('if len(live.Grids) != len(w.Grids)', '''expectedCanvases:=map[string]bool{}
for _,el:=range w.Elements{if el.Kind==ui.Canvas2D && el.Visible && !strings.Contains(el.ID,"canvas-object:"){expectedCanvases[el.ID]=true}}
if len(live.Canvases)!=len(expectedCanvases){return fmt.Errorf("native canvas publication count differs at %s",got.Label)}
for _,c:=range live.Canvases{if !expectedCanvases[c.ID]{return errors.New("unexpected native canvas publication")};delete(expectedCanvases,c.ID)}
if len(live.Grids) != len(w.Grids)''')
s+= '\n'+(W/'anchors.draft').read_text();p.write_text(s)
p=I/'examples/replay/cmd/workspace-native/main.go';s=p.read_text().replace('scenarioErr = errors.New("native scenario failed to join")','''out.Error = "fatal: native scenario failed to join; process exit avoids concurrent deferred cleanup"
        _ = json.NewEncoder(os.Stdout).Encode(out)
        os.Exit(3)''');p.write_text(s)
p=I/'drivers/cogent/desktop_session_offscreen_test.go';s=p.read_text();s=s.replace('copy := *s','copy := DesktopSession{self:s}');p.write_text(s)
for f in ['origin_custom.go','origin_custom_offscreen_test.go']:
 p=I/'prepared/core'/f;s=p.read_text();p.write_text('// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT\n'+s)
p=I/'examples/replay/workspace/native_test.go';s=(W/'native_test.draft').read_text().replace('"github.com/dshills/vellum/replay"','"github.com/dshills/vellum/replay"\n"github.com/dshills/vellum/ui"');s=s.replace('for _,el:=range w.Elements{if el.Visible{', '''for _,el:=range w.Elements{
 if el.Kind==ui.Canvas2D && el.Visible && !strings.Contains(el.ID,"canvas-object:"){snap.Canvases=append(snap.Canvases,cogent.CanvasInspection{ID:el.ID,Generation:1,View:want.Model.Canvas.View,Bounds:[4]float32{float32(el.Bounds.Min.X),float32(el.Bounds.Min.Y),float32(el.Bounds.Dx()),float32(el.Bounds.Dy())},TotalObjects:len(want.Model.Canvas.Objects)})}
 if el.Visible{''');p.write_text(s)
p=I/'overlay.json';x=json.loads(p.read_text());sdk=json.loads((W/'scope.json').read_text())['sdk'];x['Replace'][sdk+'/examples/replay/workspace/native_test.go']=str(I/'examples/replay/workspace/native_test.go');p.write_text(json.dumps(x,indent=2)+'\n')
p=I/'drivers/cogent/desktop_session.go';s=p.read_text().replace('"math"','"math"\n"slices"').replace('"github.com/dshills/vellum/app"','"github.com/dshills/vellum/app"\n"github.com/dshills/vellum/canvas"\n"github.com/dshills/vellum/placement"');s=s.replace('Canvases   []CanvasInspection','Canvases   []DesktopCanvasInspection');s=s.replace('func NewDesktopSession()', '''// DesktopCanvasInspection keeps the existing annotation count separate from
// actual painted objects and accepted placement preview. All values are detached.
type DesktopCanvasInspection struct { CanvasInspection; Objects []canvas.Rect; Selected string; Preview placement.State }

func NewDesktopSession()''');s=s.replace('retained += len(c.Objects)','retained += len(c.Objects)+len(f.picture.objects)');s=s.replace('out.Canvases = append(out.Canvases, c)','out.Canvases = append(out.Canvases, DesktopCanvasInspection{CanvasInspection:c,Objects:slices.Clone(f.picture.objects),Selected:f.picture.selected,Preview:f.picture.preview})');p.write_text(s)
p=I/'examples/replay/workspace/native.go';s=p.read_text().replace('c.TotalObjects != len(got.Model.Canvas.Objects)','!reflect.DeepEqual(c.Objects,got.Model.Canvas.Objects) || c.Selected!=got.Model.Canvas.Selected');s=s.replace('for _, c := range live.Canvases {\n\t\t\tif c.View', '''for _, c := range live.Canvases {
 if got.Label=="placement-preview" { p:=c.Preview;if !p.Active||!p.Dragging||!p.Accepted||p.ItemID!="block"||p.TargetID!="drawing"||p.Position!=(canvas.Point{X:40,Y:-20})||p.Preview.Width!=80||p.Preview.Height!=50{return errors.New("accepted placement preview absent from completed canvas picture")} }else if c.Preview.Active{return errors.New("placement preview retained after completion")}
\t\t\tif c.View''');p.write_text(s)
p=I/'examples/replay/workspace/native_test.go';s=p.read_text().replace('"github.com/dshills/vellum/ui"','"github.com/dshills/vellum/ui"\n"github.com/dshills/vellum/canvas"\n"github.com/dshills/vellum/placement"').replace('cogent.CanvasInspection{ID:el.ID,Generation:1,View:want.Model.Canvas.View,Bounds:[4]float32{float32(el.Bounds.Min.X),float32(el.Bounds.Min.Y),float32(el.Bounds.Dx()),float32(el.Bounds.Dy())},TotalObjects:len(want.Model.Canvas.Objects)}','cogent.DesktopCanvasInspection{CanvasInspection:cogent.CanvasInspection{ID:el.ID,Generation:1,View:want.Model.Canvas.View,Bounds:[4]float32{float32(el.Bounds.Min.X),float32(el.Bounds.Min.Y),float32(el.Bounds.Dx()),float32(el.Bounds.Dy())}},Objects:want.Model.Canvas.Objects,Selected:want.Model.Canvas.Selected,Preview:func()placement.State{if c.Label=="placement-preview"{return placement.State{Active:true,Dragging:true,Accepted:true,ItemID:"block",TargetID:"drawing",Position:canvas.Point{X:40,Y:-20},Preview:canvas.Rect{Width:80,Height:50}}};return placement.State{}}()}');p.write_text(s)
