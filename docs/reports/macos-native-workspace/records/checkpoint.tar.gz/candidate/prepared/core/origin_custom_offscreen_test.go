// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
//go:build offscreen

package core

import (
	"cogentcore.org/core/events"
	"context"
	"testing"
)

func TestOriginCustomSurvivesModalPopupAndPreservesRouting(t *testing.T) {
	m, b, _ := manualFixture(t, func(b *Body) { NewButton(b).SetText("main") })
	drainManual(t, m)
	popup := NewScene("origin-popup")
	NewButton(popup).SetText("popup")
	stage := NewPopupStage(MenuStage, popup, b).Run()
	if !stage.Modal {
		t.Fatal("fixture not modal")
	}
	drainManual(t, m)
	origin, popupCount, mainCount := 0, 0, 0
	b.Scene.OnFirst(events.Custom, func(events.Event) { mainCount++ })
	popup.OnFirst(events.Custom, func(events.Event) { popupCount++ })
	b.Scene.SetOriginCustomHandler(func(e events.Event) bool {
		ce := e.(*events.CustomEvent)
		if ce.Data != "owned" {
			return false
		}
		origin++
		return true
	})
	source := m.window.SystemWindow.Events()
	source.Custom("owned")
	drainManual(t, m)
	source.Custom("ordinary")
	drainManual(t, m)
	if origin != 1 || popupCount != 1 || mainCount != 0 {
		t.Fatalf("origin=%d popup=%d main=%d", origin, popupCount, mainCount)
	}
	b.Scene.SetOriginCustomHandler(nil)
	source.Custom("owned")
	drainManual(t, m)
	if origin != 1 || popupCount != 2 {
		t.Fatal("cleared origin hook retained authority")
	}
	if err := m.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}
