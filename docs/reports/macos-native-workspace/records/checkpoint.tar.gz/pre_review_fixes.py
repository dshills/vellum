from pathlib import Path
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
(T/'scripts/check.sh').chmod(0o755);(W/'install/scripts/check.sh').chmod(0o755)
p=T/'docs/reports/macos-native-workspace/README.md';s=p.read_text().replace('the full driver race suite 275.961s','the complete driver-root package (`.`) race 275.961s').replace('Internal source/execution/results and checkpoint reviews, raw streams, exact\ninputs, controls and Prism disposition are retained in the\n[evidence archive](records/checkpoint.tar.gz), indexed by its adjacent manifest.','Before commit, retain internal source/execution/results and checkpoint reviews,\nraw streams, exact inputs, controls and Prism disposition in the\n[evidence archive](records/checkpoint.tar.gz), indexed by its adjacent manifest.');p.write_text(s)
run_child(['git','add','--','scripts/check.sh','docs/reports/macos-native-workspace/README.md'],cwd=T,timeout=30,capture_output=True,check=True)
r=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,capture_output=True,check=True);(W/'pre-prism.diff').write_bytes(r.stdout);print('staged bytes',len(r.stdout))
