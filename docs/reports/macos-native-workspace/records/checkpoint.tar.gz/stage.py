from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
p=T/'docs/reports/macos-native-workspace/README.md';s=p.read_text()
for a,b in {'at most64':'at most 64','intents17/122':'intents 17/122','At10k':'At 10k','are239546':'are 239546','at1M':'at 1M','The1M':'The 1M','are623':'are 623','software624':'software 624','emits18':'emits 18','denied,240':'denied, 240','and16MiB':'and 16 MiB','base`':'base `','Go1.25.6':'Go 1.25.6','suite275':'suite 275','race\n12':'race\n12','race167':'race 167','methods29':'methods 29','vectors. Installed':'vectors. Installed','preparation\npasses':'preparation\npasses','worktree:6,263':'worktree: 6,263','capture41':'capture 41','passes41':'passes 41','fails46':'fails 46','Both10k':'Both 10k','their1M':'their 1M','Rows |216':'Rows | 216'}.items():s=s.replace(a,b)
p.write_text(s)
p=T/'specs/macos-delivery.md';s=p.read_text();s=s.replace("Next complete M2's full native workspace integration at 10k/1M\nrows; the existing 18-action smoke is insufficient.","The full native workspace record now passes at both row counts; next close\nM2's remaining native catalogue coverage.")
p.write_text(s)
p=T/'specs/macos-completion.md';s=p.read_text().replace('## M2 headless workspace and catalogue','## M2 workspace and catalogue').replace('Native integration, physical/human workflows and','Native catalogue integration, physical/human workflows and').replace('Next close full native M2 workspace integration, then make a materially different','Next close the remaining native M2 catalogue coverage, then make a materially different');p.write_text(s)
# Improve new status prose without touching qualified Go source.
for rel in ['specs/macos-delivery.md','specs/macos-completion.md','specs/desktop-integration.md']:
 p=T/rel;s=p.read_text()
 for a,b in {'all216':'all 216','and27':'and 27','both10k':'both 10k','intents17':'intents 17','at10k':'at 10k','at1M':'at 1M'}.items():s=s.replace(a,b)
 p.write_text(s)
a=json.loads((W/'adopted-source.json').read_text());paths=a['source_paths']+[n for n in a['removed'] if n in run_child(['git','ls-files','-z'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode().split('\0')]+a['installed']+['docs/README.md','docs/reports/macos-native-workspace/README.md','specs/macos-delivery.md','specs/macos-completion.md']
run_child(['git','add','--',*paths],cwd=T,timeout=30,capture_output=True,check=True)
r=run_child(['git','diff','--cached','--check'],cwd=T,timeout=30,capture_output=True);assert r.returncode==0,r.stdout+r.stderr
r=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,capture_output=True,check=True);(W/'pre-prism.diff').write_bytes(r.stdout)
print(run_child(['git','diff','--cached','--stat'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode());print('STAGED DIFF BYTES',len(r.stdout))
