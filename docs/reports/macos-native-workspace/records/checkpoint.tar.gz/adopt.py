from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');I=W/'candidate'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def git(*args):return run_child(['git',*args],cwd=T,timeout=30,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='594bd37fa531a5160aec96a3c1b13aeefe3aa24e' and not git('status','--porcelain')
r=json.loads((W/'native-v5/result.json').read_text());assert r['completed']==['cpu-10000','cpu-1000000'] and not r['error'] and (W/'native-v5/stop-live').exists()
paths=['drivers/cogent/desktop_session.go','drivers/cogent/desktop_session_offscreen_test.go','drivers/cogent/driver.go','examples/replay/cmd/workspace-native/main.go','examples/replay/workspace/backend_offscreen.go','examples/replay/workspace/capture.go','examples/replay/workspace/native.go','examples/replay/workspace/native_test.go','examples/replay/workspace/native_viewport.go','examples/replay/workspace/records.go','examples/replay/workspace/transport.go']
for name in paths:
 p=I/name;q=T/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(T/'examples/replay/workspace/capture_offscreen.go').unlink()
for p in (W/'install').rglob('*'):
 if p.is_file():
  q=T/p.relative_to(W/'install');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
assert all((T/n).read_bytes()==(I/n).read_bytes() for n in paths)
(W/'adopted-source.json').write_text(json.dumps({'head':git('rev-parse','HEAD').decode().strip(),'native_source_exact':True,'source_paths':paths,'removed':['examples/replay/workspace/capture_offscreen.go'],'installed':[p.relative_to(W/'install').as_posix()for p in(W/'install').rglob('*')if p.is_file()],'sdk_changed':False},indent=2)+'\n')
print(git('diff','--stat').decode())
