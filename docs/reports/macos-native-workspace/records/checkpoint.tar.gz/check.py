"""Headless checks for the corrected integration; prototype evidence stays frozen."""
from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;name,kind,variant=sys.argv[1:];I=W/variant;s=importlib.util.spec_from_file_location('surface_integrated_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sdk=Path(json.loads((W/'scope.json').read_text())['sdk']);h.need(kind in ['focused','driver-all','core','vet','example','native-build','escape','records','native-oracles','consumer-build','consumer-vet'],'known paint check');h.need(variant in ['baseline','candidate'],'fixed variant')
pins={str(p):h.sha(p)for p in [*I.rglob('*'),Path(__file__),Path(h.__file__),Path(h.GUARD),h.GO]if p.is_file()}
cwd=sdk/'drivers/cogent';prefix=['-p=1','-overlay='+str(I/'overlay.json'),'-tags=offscreen']
if kind in ['focused','driver-all','core','example','records','native-oracles']:
 args=['test','-race','-count=1',*prefix,'-timeout=8m']
 if kind=='focused':args+=['-run','^TestDesktop']
 if kind=='core':cwd=sdk/'drivers/cogent/build/upstream';args+=['-run','^TestOriginCustom','./core']
 elif kind=='native-oracles':cwd=sdk/'examples/replay';args+=['-run','^TestNative','./workspace']
 elif kind=='records':cwd=sdk/'examples/replay';args+=['./workspace']
 elif kind=='example':cwd=sdk/'examples/loadedgrid';args+=['./...']
 else:args+=['.']
elif kind=='vet':args=['vet',*prefix,'./...']
else:args=['build','-p=1','-overlay='+str(I/'overlay.json'),'-o',str(W/('grid-'+variant)),'.'];cwd=sdk/'examples/loadedgrid'
if kind=='consumer-build':args=['build','-p=1','-overlay='+str(I/'overlay.json'),'-o',str(W/'workspace-native-v5'),'-tags=vellum_native_checks', './cmd/workspace-native'];cwd=sdk/'examples/replay'
if kind=='consumer-vet':args=['vet','-p=1','-overlay='+str(I/'overlay.json'),'-tags=vellum_native_checks','./workspace','./cmd/workspace-native'];cwd=sdk/'examples/replay'
if kind=='escape':args.insert(1,'-gcflags=github.com/dshills/vellum/drivers/cogent=-m=1')
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','LANG':os.environ.get('LANG','en_US.UTF-8')}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args]
def interrupt(signum,frame):raise InterruptedError('integration check signal '+str(signum))
old=signal.signal(signal.SIGTERM,interrupt)
try:
 r=h.g.execute(av,cwd,W/name,lambda:(W/'stop-integration').exists(),lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=600,limit=8<<20);r['source_pins']=pins;r['native_ui_executed']=False;(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and r['owned']['errors']==[]else 1)
finally:signal.signal(signal.SIGTERM,old)
