from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('adopted_prepare_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
paths=[T/'drivers/cogent/prepare.py',T/'drivers/cogent/native/dependencies.json']+list((T/'drivers/cogent/native/patches/desktoprouting').rglob('*'));pins={str(p):h.sha(p)for p in paths if p.is_file()}
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOTOOLCHAIN':'local','GOWORK':'off','GOENV':'off','GOFLAGS':'-mod=readonly','GOPROXY':'off','GOSUMDB':'off','PYTHONDONTWRITEBYTECODE':'1'}
av=['/usr/bin/sandbox-exec','-p',h.PROFILE,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],'/opt/homebrew/bin/python3','-B',str(T/'drivers/cogent/prepare.py')]
r=h.g.execute(av,T,W/'adopted-prepare',lambda:False,lambda:all(h.sha(p)==z for p,z in pins.items()),timeout=300,limit=8<<20)
actual={m+'/'+p.relative_to(T/'drivers/cogent/build'/m).as_posix():h.sha(p)for m in ['upstream','typesetting']for p in(T/'drivers/cogent/build'/m).rglob('*')if p.is_file()}
expected={m+'/'+p.relative_to(W/'preparation/build'/m).as_posix():h.sha(p)for m in ['upstream','typesetting']for p in(W/'preparation/build'/m).rglob('*')if p.is_file()}
r['prepared_exact']=actual==expected;r['prepared_files']=len(actual);r['source_pins']=pins
(W/'adopted-prepare.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','prepared_files','prepared_exact','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['prepared_exact']and r['owned']['group_absent']and not r['owned']['errors']else 1)
