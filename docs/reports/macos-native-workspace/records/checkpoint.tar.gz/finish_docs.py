from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
review=json.loads((W/'internal-prism-disposition.json').read_text());assert review['approved']and not review['unresolved_findings']
p=T/'specs/macos-delivery.md';s=p.read_text().replace('| M2 | Complete headless and native workspace records; native catalogue open |','| M2 | Partial; headless and native workspace records pass, native catalogue open |');p.write_text(s)
p=T/'docs/reports/macos-native-workspace/README.md';s=p.read_text().replace('21 synthetic parser/result controls and the affected preparation suite after\nincluding stage81 in the pinned patch-order regression.','21 synthetic parser/result controls and all 11 affected preparation tests after\nincluding stage81 in the pinned patch-order regression.')
s=s.replace('Before commit, retain internal source/execution/results and checkpoint reviews,\nraw streams, exact inputs, controls and Prism disposition in the\n[evidence archive](records/checkpoint.tar.gz), indexed by its adjacent manifest.','''Internal source/execution/results and staged checkpoint reviews, raw streams,
exact inputs, controls and Prism disposition are retained in the
[evidence archive](records/checkpoint.tar.gz), indexed by its adjacent manifest.

One Prism CLI invocation uses Anthropic Claude Sonnet 5.5 over all 27 staged files
and 131,736 bytes: five chunks/five LLM calls, complete coverage, no excluded or
skipped files, truncation or suppression. Its initial exit 1 reflects four medium
findings. Independent assessment leaves no runtime blocker:
input cancellation permits already dispatched effects; real driver retirement
releases pending requests; fatal unjoined shutdown intentionally emits incomplete diagnostics and avoids
potentially blocking lock-taking reads; readiness waits on actual FIFO/composition rather than an
immediate-success loop. All five provider-discarded findings are also assessed;
the M2 label receives an editorial clarification to “Partial.” No runtime Go
change or second provider invocation follows. The archive retains full rationale
and the unmodified provider response; this is not a claim Prism returned zero
findings. Internal review also restores the executable check-script mode, fixes
the preparation test's stage endpoint, and corrects test/evidence wording.''');p.write_text(s)
p=T/'docs/reviews/macos-native-workspace/README.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('''# Native workspace implementation review

The [checkpoint report](../../reports/macos-native-workspace/README.md) contains
actual outcomes and scope. Internal reviews cover source, exact native admission,
raw/domain results, source adoption and the staged checkpoint. Final native
coverage is two CPU-scene cases, 432 operations and 54 captures; catalogue/full
M2 and the remaining Mac gates stay open.

Prism uses Anthropic Claude Sonnet 5.5 in one CLI invocation: 27 files, 131,736
bytes, five chunks and five LLM calls, no exclusion/skipping/truncation/suppression.
The CLI exits1 with four medium findings. Independent source assessment requires
none of the four proposed runtime changes: documented partial effects after cancellation are permitted;
real native retirement owns pending release; fatal unjoined failure must avoid
potentially blocking diagnostics; actual composition/FIFO waits contradict an
immediate-success spin. Five tool-discarded findings are reviewed too, with an
editorial M2 status clarification accepted. No runtime changes or second provider
call are made after this disposition.

Before Prism, internal review also restores scripts/check.sh's executable mode,
updates the preparation regression to include stage81 (all 11 tests pass), and
corrects the driver-root package test scope and pending-evidence wording.

The [evidence archive](../../reports/macos-native-workspace/records/checkpoint.tar.gz)
contains the raw provider response, exact reviewed diff, source/execution/results
certificates, independent disposition and all current/failing receipts. Its
adjacent manifest binds every archived byte. Historical failures remain failed;
tracked cleanup and process absence do not close Cocoa deallocation, physical
input, presentation/performance, final SDK or complete Mac acceptance.
''')
run_child(['git','add','--','specs/macos-delivery.md','docs/reports/macos-native-workspace/README.md','docs/reviews/macos-native-workspace/README.md'],cwd=T,timeout=30,capture_output=True,check=True)
r=run_child(['git','diff','--cached','--check'],cwd=T,timeout=30,capture_output=True);assert r.returncode==0,r.stdout+r.stderr
print('Documentation and review disposition staged; qualified runtime Go unchanged')
