"""Synthetic result-oracle refusal controls; executes no native UI."""
from pathlib import Path
import copy,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W));import validate as v
rows=10000;root=v.C/'examples/replay/workspace/records';record=json.loads((root/'10000.json').read_text());goldens=json.loads((root/'10000.golden.json').read_text())
base={'Event':'vellum.workspace-native.result','Result':'PASS_NATIVE_WORKSPACE_RECORD','Error':'','ScenarioJoined':True,'WorkerJoined':True,'Session':{'Started':True,'Closed':True,'Pending':False,'LiveWindows':0,'Issued':1},'Executor':{'Closed':True,'Pending':0,'Running':0,'Failed':0,'Accepted':7,'Completed':7},'Cleanup':{'MainThread':True,'CleanupObserved':True,'CallbacksStopped':True,'PendingCallbacks':0,'NativeOutstanding':0,'AccessibilityWindows':0,'WindowTitles':[],'FilePanels':{'Tracked':0},'Menu':{'Owned':False},'Tray':{'Present':False}},'Workflow':{'Event':'vellum.workspace-native-record.result','Result':'PASS_NATIVE_RECORD_DOMAIN_AND_ROUTING','Rows':rows,'Applied':216,'Operations':[{'Sequence':o['sequence'],'Kind':o['kind'],'Window':o.get('window',''),'Result':'APPLIED'}for o in record['operations']],'Captures':[{'Sequence':g['Sequence'],'Label':g['Label'],'Model':g['Data']['Model'],'Windows':[{'ID':w['ID'],'Snapshot':{'Frame':1,'Size':{'X':1600,'Y':1000},'LogicalDPI':160}}for w in g['Data']['Windows']]}for g in goldens]}}
for r in base['Workflow']['Operations']:
 if r['Sequence']in[17,122]:r.update(NativeChord='Meta+A',TransportNote='mac-select-all')
cases=[]
def case(name,mutate,accept=False):
 d=copy.deepcopy(base);mutate(d);raw=json.dumps(d).encode();error=None
 try:v.validate(raw,rows);passed=True
 except BaseException as e:passed=False;error=str(e)
 assert passed==accept,(name,passed,error);cases.append({'name':name,'expected_accept':accept,'observed_accept':passed,'error':error})
case('synthetic-positive-control',lambda d:None,True)
case('partial-operations',lambda d:d['Workflow']['Operations'].pop())
case('domain-name-mismatch',lambda d:d['Workflow']['Captures'][0]['Model'].__setitem__('Name','unexpected'))
case('unrendered-frame',lambda d:d['Workflow']['Captures'][0]['Windows'][0]['Snapshot'].__setitem__('Frame',0))
case('native-reference-leak',lambda d:d['Session'].__setitem__('LiveWindows',1))
case('worker-not-joined',lambda d:d.__setitem__('WorkerJoined',False))
case('native-inventory-leak',lambda d:d['Cleanup'].__setitem__('NativeOutstanding',1))
case('unbounded-camera-change',lambda d:d['Workflow']['Captures'][0]['Model']['Canvas']['View']['Center'].__setitem__('X',10))
case('wrong-operation-order',lambda d:d['Workflow']['Operations'].reverse())
case('unexpected-retirement',lambda d:d['Workflow']['Operations'][1].__setitem__('Result','EXPECTED_WINDOW_RETIREMENT'))
raw=json.dumps(base).encode()
known=b'2026/10/18 00:42:02 ERROR lines.Lines font style MUST be Monospace. Setting that but should fix upstream | cogentcore.org/core/text/lines.(*Lines).SetFontStyle /bounded/sdk/text/lines/api.go:145\n'
for name,prefix,accept in [('known-fixture-font-diagnostic',known,True),('unexpected-log',b'ERROR unknown native error\n',False),('excess-fixture-font-diagnostics',known*65,False)]:
 error=None
 try:v.validate(prefix+raw,rows);passed=True
 except BaseException as e:passed=False;error=str(e)
 assert passed==accept,(name,passed,error);cases.append({'name':name,'expected_accept':accept,'observed_accept':passed,'error':error})
actual=(W/'native-v2/cpu-10000/stderr').read_bytes()
for name,stdout_prefix,errbytes,accept in [('actual-six-stderr-diagnostics',b'',actual,True),('unknown-stderr',b'',b'ERROR unknown native error\n',False),('json-on-stderr',b'',raw,False),('mixed-stream-combined-limit',known*60,actual,False)]:
 error=None
 try:v.validate(stdout_prefix+raw,rows,errbytes);passed=True
 except BaseException as e:passed=False;error=str(e)
 assert passed==accept,(name,passed,error);cases.append({'name':name,'expected_accept':accept,'observed_accept':passed,'error':error})

case('wrong-native-scroll',lambda d:d['Workflow']['Captures'][7]['Model']['Grid']['Viewport'].__setitem__('ScrollY',1))
case('wrong-selected-row',lambda d:d['Workflow']['Captures'][7]['Model']['Grid']['Active'].__setitem__('RowKey','row:0000001'))
# Exercise each immutable sequence with unequal native allocation, including
# the 1M sorted state that is above bottom and must not be bottom-normalized.
for count in [10000,1000000]:
 reference=v.GridReference();items=json.loads((root/f'{count}.golden.json').read_text())
 for item in items:
  m=item['Data']['Model'];view=dict(m['Grid']['Viewport'])
  if view['Height']==480:view['Height']=482
  x,y=reference.offsets(item['Sequence'],m,view)
  if item['Label']=='sorted':assert y==m['Grid']['Viewport']['ScrollY']-(2 if count==10000 else 0)
  if item['Label']=='filtered':assert y==m['Grid']['Viewport']['ScrollY']-2
 cases.append({'name':f'independent-anchor-reference-{count}','expected_accept':True,'observed_accept':True})
p=W/'validation-controls-v4.json';assert not p.exists();p.write_text(json.dumps({'synthetic':True,'native_executed':False,'cases':cases},indent=2)+'\n');print(json.dumps({'passed':len(cases),'native_executed':False}))
