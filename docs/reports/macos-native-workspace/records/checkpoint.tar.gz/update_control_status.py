from pathlib import Path
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
p=T/'specs/control-acceptance.md';s=p.read_text();start=s.index('The map supplies a named automated scenario');s=s[:start]+'''The map supplies a named automated scenario for every catalogue entry. The
[full native workspace checkpoint](../docs/reports/macos-native-workspace/README.md)
now passes all 216 operations and 27 captures at both 10k/1M rows. It covers the
record's command/history, workers, edits, tab reorder, placement, modal precedence
and two-window survival through native Go event routing. It does not establish
native catalogue completeness, physical input or human assistive-technology use.

The remaining native catalogue work is:

1. In the gallery, exercise ordinary Selector popup and NumberField typed,
   pointer and keyboard edits, including rejection/disabled behavior. The
   deterministic keyboard regression does not qualify an actual desktop popup.
2. Exercise the rest of the supported catalogue's focus, input, state publication
   and lifetime through actual native routing, with named evidence for each
   entry. Keep automated Go routing separate from OS and physical input.
3. Complete real keyboard/pointer and human assistive-technology workflows,
   including modal/focus boundaries, text/IME and virtual data. Follow the M5
   native matrix in `macos-delivery.md`; software DPI changes do not qualify
   physical display transitions.

Full M2/M5 remain open. Live tests require current desktop authorization. No
records or image goldens are regenerated to obtain a passing result. Performance,
idle, memory and endurance belong to M3/M4 with their original thresholds.
''';p.write_text(s)
run_child(['git','add','--','specs/control-acceptance.md'],cwd=T,timeout=30,capture_output=True,check=True)
r=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,capture_output=True,check=True);(W/'pre-prism.diff').write_bytes(r.stdout);print(len(r.stdout))
