#import <Foundation/Foundation.h>
#import <QuartzCore/CAMetalDisplayLink.h>
#include <Block.h>
#include <stdio.h>
static unsigned created,invalidated,live,acquisitions,unavailable,completions;
static uint64_t lastTag,lastDrawable;
static id supplied;
@interface FakeUpdate : NSObject
- (id)drawable;
@end
@implementation FakeUpdate
- (id)drawable { return supplied; }
@end
@interface FakeMetalLink : NSObject
@property(assign) id<CAMetalDisplayLinkDelegate> delegate;
@property float preferredFrameLatency;
@property BOOL paused;
- (id)initWithMetalLayer:(CAMetalLayer *)layer;
- (void)addToRunLoop:(NSRunLoop *)loop forMode:(NSString *)mode;
- (void)invalidate;
@end
@implementation FakeMetalLink
- (id)initWithMetalLayer:(CAMetalLayer *)layer { if ((self=[super init])) { created++;live++; } return self; }
- (void)addToRunLoop:(NSRunLoop *)loop forMode:(NSString *)mode {
 if (![mode isEqualToString:@"VellumDrawableAcquisitionMode"])abort();
 if (supplied) { FakeUpdate *update=[FakeUpdate new]; [_delegate metalDisplayLink:(CAMetalDisplayLink *)self needsUpdate:(CAMetalDisplayLinkUpdate *)update]; [update release]; }
}
- (void)invalidate { invalidated++; }
- (void)dealloc { live--;[super dealloc]; }
@end
#define CAMetalDisplayLink FakeMetalLink
#include "core/system/driver/desktop/presentation_darwin.m"
#undef CAMetalDisplayLink
uint64_t vellumGoDrawableAcquired(uint64_t token,uint64_t tag,uint64_t generation,uint64_t composition,int armed,double at) { acquisitions++;lastTag=tag;return acquisitions; }
void vellumGoDrawableUnavailable(uint64_t token,uint64_t tag,uint64_t generation,uint64_t composition,int armed,double at) { unavailable++;lastTag=tag; }
void vellumGoDrawablePresented(uint64_t token,uint64_t sequence,uint64_t drawable,double at) { completions++;lastDrawable=drawable; }
void vellumGoPresentationReceipt(uint64_t token,uint64_t tag,double at) {}
uint64_t vellumGoDisplayAcquire(uint64_t token,uint64_t credit) { return 1; }
void vellumGoDisplayUnavailable(uint64_t token,uint64_t sequence) {}
void vellumGoDisplayPresented(uint64_t token,uint64_t sequence,double at) {}
@interface FakeDrawable : NSObject { MTLDrawablePresentedHandler _handler; }
@property uint64_t drawableID;
@property double presentedTime;
- (void)addPresentedHandler:(MTLDrawablePresentedHandler)handler;
- (void)fire;
@end
@implementation FakeDrawable
- (void)addPresentedHandler:(MTLDrawablePresentedHandler)handler { if (_handler)Block_release(_handler);_handler=Block_copy(handler); }
- (void)fire { if(_handler)_handler((id<MTLDrawable>)self); }
- (void)dealloc { if(_handler)Block_release(_handler);[super dealloc]; }
@end
#define REQUIRE(x) do { if(!(x)){fprintf(stderr,"assertion line%d\n",__LINE__);return 1;} } while(0)
int main(void) { @autoreleasepool {
 if (@available(macOS 14.0,*)) {
  FakeDrawable *d=[FakeDrawable new];d.drawableID=42;d.presentedTime=123;
  @autoreleasepool {
   CAMetalLayer *layer=(CAMetalLayer *)vellumNewPresentationLayer();vellumPresentationObserver(layer,7);vellumPresentationFrame(layer,11,13,1,1);
   supplied=d;
   REQUIRE([layer nextDrawable]==(id)d && acquisitions==1 && lastTag==11);
   REQUIRE(created==1 && invalidated==1 && live==0);
   supplied=nil;double before=CACurrentMediaTime();
   REQUIRE([layer nextDrawable]==nil && unavailable==1);
   REQUIRE(CACurrentMediaTime()-before<0.30 && created==2 && invalidated==2 && live==0);
   supplied=d;vellumPresentationFrame(layer,12,14,2,1);
   REQUIRE([layer nextDrawable]==(id)d && acquisitions==2 && lastTag==12);
   REQUIRE(created==3 && invalidated==3 && live==0);
   vellumPresentationObserver(layer,0);
  }
  [d fire];REQUIRE(completions==1 && lastDrawable==42);[d release];
  printf("PASS: delivered/nil/retry;all3links invalidated;late scalar callback after layer pool;no window or real GPU\n");
 }
 } return 0; }
