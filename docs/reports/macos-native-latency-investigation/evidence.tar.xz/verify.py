from pathlib import Path
import json,hashlib,importlib.util,sys,re,tarfile,math
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;S=P.parent/'macos-release-default-assessment/assessment.py';sp=importlib.util.spec_from_file_location('reused_validation',S);a=importlib.util.module_from_spec(sp);sys.modules[sp.name]=a;sp.loader.exec_module(a)
plan=json.loads((S.parent/'plan.json').read_text());sdk=a.sdk_vector();assert sdk==plan['sdk']
for name in ['displaylink-candidate','persistent-link-candidate']:
 core=P/name/'core';base=a.SDK/'drivers/cogent/build/upstream';actual={f.relative_to(core).as_posix():a.sha(f) for f in core.rglob('*') if f.is_file()};expected={f.relative_to(base).as_posix():a.sha(f) for f in base.rglob('*') if f.is_file()};assert set(actual)==set(expected);assert [n for n in actual if actual[n]!=expected[n]]==['system/driver/desktop/presentation_darwin.m'];assert actual['system/driver/desktop/presentation_darwin.m']==json.loads((P/name/'binding.json').read_text())['candidate_m_sha256']
# Real invalid journals remain refused by the unchanged strict SDK validator.
for name in ['transaction-candidate','displaylink-candidate','persistent-link-candidate']:
 try:a.validate(a.c.CASES[0],P/name/'presentation.json',a.sha(P/name/'native-grid'))
 except ValueError:pass
 else:raise AssertionError('lost feedback was accepted: '+name)
v=a.validate(a.c.CASES[0],P/'transaction-flush-candidate/presentation.json',a.sha(P/'transaction-flush-candidate/native-grid'));assert v['measured_input_latency_ms']['count']==120 and v['measured_input_latency_ms']['p95']>33.3
# The reference's startup zeroes prevent qualification; none are dropped.
rows=[json.loads(s) for s in (P/'metal-reference/native-run/stdout').read_text().splitlines()];rows=[r for r in rows if 'index'in r];assert len(rows)==248;assert [r['index'] for r in rows if r['presented']<=0]==[0,1,2,3,4,5,6,7,8,9,10,11,12,14];assert all(r['presented']>r['receipt'] for r in rows[128:])
audit={'SDK_files':len(sdk),'SDK_unchanged':True,'candidate_copies_single_recorded_m_diff':True,'strict_negative_controls':3,'valid_latency_failure_preserved':True,'reference_startup_losses':14,'release_qualified':False}
if (P/'source-audit.json').exists():assert json.loads((P/'source-audit.json').read_text())==audit
else:a.write(P/'source-audit.json',audit)
R=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-native-latency-investigation');summary=json.loads((R/'summary.json').read_text());assert summary['native_commands']==7 and summary['probe_commands']==16 and summary['all_owned_groups_retired'];assert summary['release_qualified'] is False
if (R/'evidence-index.json').exists():
 index=json.loads((R/'evidence-index.json').read_text());assert a.sha(R/'evidence.tar.xz')==index['archive']['sha256']
 with tarfile.open(R/'evidence.tar.xz') as tf:
  assert set(tf.getnames())==set(index['files'])
  for n,d in index['files'].items():
   b=tf.extractfile(n).read();assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
for p in [R/'README.md',Path('/private/tmp/vellum-macos-native-results-97aee13/specs/macos-release-assessment.md')]:
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not link.startswith('https:'):assert (p.parent/link).exists(),link
print('PASS:SDK8321 unchanged;two private source copies single pinned diff;3 strict real-capture negative controls;valid120-input latency failure;14 reference startup losses;7native+16probe retirements;archive hashes;current links')
