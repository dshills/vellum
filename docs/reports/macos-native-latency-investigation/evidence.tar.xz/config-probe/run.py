from pathlib import Path
import importlib.util,sys,json,datetime
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
S=P.parent.parent/'macos-release-default-assessment/assessment.py'
s=importlib.util.spec_from_file_location('assessment_reuse',S);a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a)
if (P/'started.json').exists():raise ValueError('single-attempt diagnostic sealed')
plan=json.loads((S.parent/'plan.json').read_text());a.need(a.sdk_vector()==plan['sdk'],'SDK restoration/integrity failure')
for f in ['native-grid','presentation_darwin.m','overlay.json','binding.json', 'run.py']:
 plan['pins'][str(P/f)]=a.sha(P/f)
plan['binaries']['grid']={'path':str(P/'native-grid'),'sha256':a.sha(P/'native-grid')}
a.write(P/'diagnostic-plan.json',{'description':'one observational configuration diagnostic; not release timing evidence','binary':plan['binaries']['grid'],'overlay':json.loads((P/'binding.json').read_text()),'pins':plan['pins']})
start=datetime.datetime.now(datetime.timezone.utc);a.write(P/'started.json',{'started_utc':start.isoformat(),'screen_authorization':'remaining time in approved20minute quiet window; targeted native fix investigation explicitly requested'})
with a.lease_module.LiveLease() as lease:
 h=a.Host(plan,P,start+datetime.timedelta(seconds=60),lease,[False])
 r=h.command(a.arguments(a.c.CASES[0],P/'native-grid',P/'presentation.json'),a.SDK/'examples/loadedgrid',P/'native',45)
 h.finish()
 a.need(a.c.passed(r),'native configuration diagnostic failed')
 configs=[json.loads(line) for line in (P/'native/stdout').read_text().splitlines() if 'vellum.native.layer-config' in line]
 a.need(len(configs)==1,'native configuration output missing/ambiguous')
 a.write(P/'config.json',configs[0]);print(json.dumps(configs[0]))
(P/'sealed').touch()
