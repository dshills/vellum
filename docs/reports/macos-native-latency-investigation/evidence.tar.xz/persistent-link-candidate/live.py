from pathlib import Path
import importlib.util,sys,json,datetime,traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;S=P.parent.parent/'macos-release-default-assessment/assessment.py'
s=importlib.util.spec_from_file_location('assessment_reuse',S);a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);a.P=P
if (P/'started.json').exists():raise ValueError('sealed attempt cannot restart')
plan=json.loads((S.parent/'plan.json').read_text());a.need(a.sdk_vector()==plan['sdk'],'SDK integrity failure')
core=P/'core';baseline=a.SDK/'drivers/cogent/build/upstream';candidate={p.relative_to(core).as_posix():a.sha(p) for p in core.rglob('*') if p.is_file()};original={p.relative_to(baseline).as_posix():a.sha(p) for p in baseline.rglob('*') if p.is_file()};changed=[n for n in candidate if candidate[n]!=original.get(n)];a.need(set(candidate)==set(original) and changed==['system/driver/desktop/presentation_darwin.m'],'unintended source changes')
for p in [P/'native-grid',P/'binding.json',P/'candidate.mod',P/'candidate.sum',P/'live.py',core/changed[0]]:plan['pins'][str(p)]=a.sha(p)
plan['binaries']['grid']={'path':str(P/'native-grid'),'sha256':a.sha(P/'native-grid')}
a.write(P/'diagnostic-plan.json',{'kind':'private persistent display-link prototype; no release qualification','source':'SDKbd3 plus recorded single Objective-C difference','binding':json.loads((P/'binding.json').read_text()),'candidate_core':candidate,'binary':plan['binaries']['grid'],'pins':plan['pins']})
start=datetime.datetime.now(datetime.timezone.utc);a.write(P/'started.json',{'started_utc':start.isoformat(),'authorization':'Yes, test when ready; additional quiet window up to10minutes','deadline_seconds':90})
result={}
try:
 with a.lease_module.LiveLease() as lease:
  h=a.Host(plan,P,start+datetime.timedelta(seconds=90),lease,[False]);result['geometry_before']=h.geometry();result['configuration_before']=h.probes(P/'before')
  r=h.command(a.arguments(a.c.CASES[0],P/'native-grid',P/'presentation.json'),a.SDK/'examples/loadedgrid',P/'native',45);result['native']=r
  result['configuration_after']=h.probes(P/'after');h.finish();a.need(candidate=={p.relative_to(core).as_posix():a.sha(p) for p in core.rglob('*') if p.is_file()},'candidate source drift');result['geometry_after']=h.geometry()
  a.need(a.c.passed(r),'native execution failed; inspect retained journal/logs')
  v=a.validate(a.c.CASES[0],P/'presentation.json',a.sha(P/'native-grid'));a.write(P/'validation.json',v);result['latency_ms']=v['measured_input_latency_ms'];result['passes_latency']=v['measured_input_latency_ms']['p95']<=33.3
  result['outcome']='PASS_SERIAL_CANDIDATE_GATE' if result['passes_latency'] else 'REJECT_LATENCY'
except Exception as e:
 result['outcome']='REJECT_INVALID';result['error']={'type':type(e).__name__,'message':str(e)}
finally:
 a.write(P/'result.json',result);(P/'sealed').touch();print(json.dumps({k:v for k,v in result.items() if k in ['outcome','error','latency_ms','passes_latency']}))
