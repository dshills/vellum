// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
#import <QuartzCore/CAMetalLayer.h>
#import <QuartzCore/CAMediaTiming.h>
#import <Metal/MTLDrawable.h>
#import <QuartzCore/CAMetalDisplayLink.h>
#import <Foundation/Foundation.h>
#include <os/lock.h>
#include <stdio.h>
#include "presentation_darwin.h"

// Cgo exports receive scalars only. No Go pointer or native window is captured.
extern uint64_t vellumGoDrawableAcquired(uint64_t, uint64_t, uint64_t, uint64_t, int, double);
extern void vellumGoDrawableUnavailable(uint64_t, uint64_t, uint64_t, uint64_t, int, double);
extern void vellumGoDrawablePresented(uint64_t, uint64_t, uint64_t, double);
extern void vellumGoPresentationReceipt(uint64_t, uint64_t, double);
extern uint64_t vellumGoDisplayAcquire(uint64_t,uint64_t);
extern void vellumGoDisplayUnavailable(uint64_t,uint64_t);
extern void vellumGoDisplayPresented(uint64_t,uint64_t,double);

typedef struct {
 uint64_t token, tag, generation, composition, displayToken, displayCredit;
 int armed;
} VellumPresentationStamp;

// Private investigation; one native thread, wake source and drawable mailbox.
// The render caller never runs an application run loop while holding its locks.
API_AVAILABLE(macos(14.0))
@interface VellumDrawableBroker : NSObject <CAMetalDisplayLinkDelegate> {
 NSCondition *_condition;
 NSThread *_thread;
 CAMetalLayer *_layer;
 CAMetalDisplayLink *_link;
 CFRunLoopRef _loop;
 CFRunLoopSourceRef _wake;
 id<CAMetalDrawable> _drawable;
 BOOL _closed,_ready,_done,_pending;
}
- (id)initWithLayer:(CAMetalLayer *)layer;
- (id<CAMetalDrawable>)request;
- (void)start;
- (BOOL)isLinkThread;
- (BOOL)retire;
- (void)wakeOnThread;
@end
static void vellumBrokerWake(void *info) { [(VellumDrawableBroker *)info wakeOnThread]; }
@implementation VellumDrawableBroker
- (id)initWithLayer:(CAMetalLayer *)layer {
 if ((self=[super init])) {
  _condition=[NSCondition new];_layer=[layer retain];
  _thread=[[NSThread alloc]initWithTarget:self selector:@selector(run) object:nil];
  _thread.name=@"Vellum Metal display link";
 }
 return self;
}
- (void)start { [_thread start]; }
- (BOOL)isLinkThread { return [NSThread currentThread]==_thread; }
- (void)signalWakeLocked {
 if (_wake) { CFRunLoopSourceSignal(_wake);CFRunLoopWakeUp(_loop); }
}
- (void)run {
 @autoreleasepool {
  CAMetalDisplayLink *link=[[CAMetalDisplayLink alloc]initWithMetalLayer:_layer];
  // The link owns its target after construction; do not keep a second cycle.
  CAMetalLayer *initialLayer=_layer;_layer=nil;
  if (!link) {
   [_condition lock];_closed=YES;_done=YES;[_condition broadcast];[_condition unlock];
   [initialLayer release];return;
  }
  [initialLayer release];
  link.preferredFrameLatency=1;link.paused=YES;link.delegate=self;
  CFRunLoopSourceContext context={0};context.info=self;context.perform=vellumBrokerWake;
  CFRunLoopSourceRef wake=CFRunLoopSourceCreate(NULL,0,&context);
  CFRunLoopRef loop=CFRunLoopGetCurrent();
  CFRunLoopAddSource(loop,wake,kCFRunLoopDefaultMode);
  [link addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
  [_condition lock];_link=link;_loop=loop;_wake=wake;_ready=YES;[_condition broadcast];
  BOOL closed=_closed;[_condition unlock];
  if (!closed) CFRunLoopRun();
  [link invalidate];link.delegate=nil;
  CFRunLoopSourceInvalidate(wake);CFRunLoopRemoveSource(loop,wake,kCFRunLoopDefaultMode);
  [_condition lock];_link=nil;_loop=NULL;_wake=NULL;[_condition unlock];
  CFRelease(wake);[link release];
 }
 [_condition lock];_done=YES;[_condition broadcast];[_condition unlock];
}
- (void)wakeOnThread {
 [_condition lock];BOOL closed=_closed;BOOL active=_pending;CAMetalDisplayLink *link=_link;[_condition unlock];
 if (closed) { link.paused=YES;CFRunLoopStop(CFRunLoopGetCurrent()); }
 else link.paused=!active;
}
- (void)metalDisplayLink:(CAMetalDisplayLink *)link needsUpdate:(CAMetalDisplayLinkUpdate *)update {
 [_condition lock];
 if (!_closed && _pending && !_drawable) {
  _drawable=[update.drawable retain];_pending=NO;[_condition broadcast];
 }
 [_condition unlock];link.paused=YES;
}
- (id<CAMetalDrawable>)request {
 NSDate *deadline=[NSDate dateWithTimeIntervalSinceNow:0.25];
 [_condition lock];
 while (!_ready && !_closed) if (![_condition waitUntilDate:deadline])break;
 if (!_ready || _closed || _pending || _drawable) { [_condition unlock];return nil; }
 _pending=YES;[self signalWakeLocked];
 while (_pending && !_closed) if (![_condition waitUntilDate:deadline])break;
 id<CAMetalDrawable> answer=_drawable;_drawable=nil;_pending=NO;[self signalWakeLocked];
 [_condition unlock];return [answer autorelease];
}
- (BOOL)retire {
 if ([self isLinkThread])return YES; // final native link release may retire its layer
 [_condition lock];_closed=YES;_pending=NO;[_drawable release];_drawable=nil;
 [self signalWakeLocked];[_condition broadcast];
 // The display-link thread owns no Go/window locks and retires autonomously.
 // Never wait for a presented handler, a GUI callback, or an absent drawable.
 NSDate *deadline=[NSDate dateWithTimeIntervalSinceNow:2.0];
 while (!_done) if (![_condition waitUntilDate:deadline])break;
 BOOL done=_done;[_condition unlock];return done;
}
- (void)dealloc {
 [_thread release];[_layer release];[_condition release];[super dealloc];
}
@end

// Only Vellum's own layer overrides acquisition; no global method replacement.
@interface VellumPresentationLayer : CAMetalLayer {
 os_unfair_lock _stampLock;
 uint64_t _observerToken;
 uint64_t _displayToken, _displayCredit;
 int _acquisitionStarted;
 VellumDrawableBroker *_broker;
 os_unfair_lock _brokerLock;
 BOOL _brokerRetired;
 VellumPresentationStamp _stamp;
}
- (void)setObserverToken:(uint64_t)token;
- (void)retireDrawableBroker;
- (void)setTag:(uint64_t)tag generation:(uint64_t)generation composition:(uint64_t)composition armed:(int)armed;
- (VellumPresentationStamp)captureStamp;
- (int)setDisplayToken:(uint64_t)token;
- (void)setDisplayCredit:(uint64_t)credit;
@end
@implementation VellumPresentationLayer
- (id)init {
 if ((self=[super init])) { _stampLock=(os_unfair_lock)OS_UNFAIR_LOCK_INIT; _brokerLock=(os_unfair_lock)OS_UNFAIR_LOCK_INIT; _observerToken=0; _displayToken=0; _displayCredit=0; _acquisitionStarted=0; _stamp=(VellumPresentationStamp){0}; }
 return self;
}
- (void)retireDrawableBroker {
 os_unfair_lock_lock(&_brokerLock);_brokerRetired=YES;VellumDrawableBroker *broker=[_broker retain];os_unfair_lock_unlock(&_brokerLock);
 if (broker) {
  if (![broker retire]) { fprintf(stderr,"vellum: display-link retirement timed out; native owner quarantined\n");[broker release];return; }
  os_unfair_lock_lock(&_brokerLock);VellumDrawableBroker *old=nil;
  if (_broker==broker) { old=_broker;_broker=nil; }
  os_unfair_lock_unlock(&_brokerLock);[old release];[broker release];
 }
}
- (void)dealloc { [self retireDrawableBroker];[super dealloc]; }
- (void)setObserverToken:(uint64_t)token {
 os_unfair_lock_lock(&_stampLock);
 _stamp=(VellumPresentationStamp){.token=token};
 __atomic_store_n(&_observerToken,token,__ATOMIC_RELEASE);
 os_unfair_lock_unlock(&_stampLock);
}
- (void)setTag:(uint64_t)tag generation:(uint64_t)generation composition:(uint64_t)composition armed:(int)armed {
 if (!__atomic_load_n(&_observerToken,__ATOMIC_ACQUIRE))return;
 os_unfair_lock_lock(&_stampLock);
 _stamp.tag=tag;_stamp.generation=generation;_stamp.composition=composition;_stamp.armed=armed;
 os_unfair_lock_unlock(&_stampLock);
}
- (VellumPresentationStamp)captureStamp {
 if (!__atomic_load_n(&_observerToken,__ATOMIC_ACQUIRE) && !__atomic_load_n(&_displayToken,__ATOMIC_ACQUIRE))return (VellumPresentationStamp){0};
 os_unfair_lock_lock(&_stampLock);
 VellumPresentationStamp stamp=_stamp;
 stamp.displayToken=_displayToken;stamp.displayCredit=_displayCredit;
 os_unfair_lock_unlock(&_stampLock);
 return stamp;
}
- (int)setDisplayToken:(uint64_t)token {
 os_unfair_lock_lock(&_stampLock);
 if (token && __atomic_load_n(&_acquisitionStarted,__ATOMIC_ACQUIRE)) { os_unfair_lock_unlock(&_stampLock);return 0; }
 _displayCredit=0;__atomic_store_n(&_displayToken,token,__ATOMIC_RELEASE);
 os_unfair_lock_unlock(&_stampLock);return 1;
}
- (void)setDisplayCredit:(uint64_t)credit {
 os_unfair_lock_lock(&_stampLock);_displayCredit=credit;os_unfair_lock_unlock(&_stampLock);
}
- (id<CAMetalDrawable>)nextDrawable {
 VellumDrawableBroker *broker=nil;BOOL start=NO;
 if (@available(macOS 14.0,*)) {
  os_unfair_lock_lock(&_brokerLock);
  if (_brokerRetired) { os_unfair_lock_unlock(&_brokerLock);return nil; }
  if (!_broker) { _broker=[[VellumDrawableBroker alloc]initWithLayer:self];start=YES; }
  broker=[_broker retain];os_unfair_lock_unlock(&_brokerLock);
  if (start)[broker start];
  if ([broker isLinkThread]) { [broker release];return [super nextDrawable]; }
 }
 __atomic_store_n(&_acquisitionStarted,1,__ATOMIC_RELEASE);
 VellumPresentationStamp before=[self captureStamp];
 uint64_t displaySequence=0;
 if (before.displayToken) {
  displaySequence=vellumGoDisplayAcquire(before.displayToken,before.displayCredit);
  if (!displaySequence) {
   if (before.token)vellumGoDrawableUnavailable(before.token,before.tag,before.generation,before.composition,before.armed,CACurrentMediaTime());
   [broker release];return nil;
  }
 }
 // Keep super's autoreleased return lifetime. No pool may drain it here.
 id<CAMetalDrawable> drawable=nil;
 if (@available(macOS 14.0,*)) {
  drawable=[broker request];
 } else drawable=[super nextDrawable];
 [broker release];
 VellumPresentationStamp stamp=[self captureStamp];
 if (!stamp.token && !displaySequence)return drawable;
 double acquired=CACurrentMediaTime();
 if (!drawable) {
  if (displaySequence)vellumGoDisplayUnavailable(before.displayToken,displaySequence);
  if (stamp.token)vellumGoDrawableUnavailable(stamp.token,stamp.tag,stamp.generation,stamp.composition,stamp.armed,acquired);
  return nil;
 }
 uint64_t sequence=stamp.token ? vellumGoDrawableAcquired(stamp.token,stamp.tag,stamp.generation,stamp.composition,stamp.armed,acquired) : 0;
 if (sequence || displaySequence) {
  // One handler shares immutable scalar identities; no window/layer capture.
  uint64_t token=stamp.token, displayToken=before.displayToken;
  [drawable addPresentedHandler:^(id<MTLDrawable> shown) {
   @autoreleasepool {
    if (sequence)vellumGoDrawablePresented(token,sequence,shown.drawableID,shown.presentedTime);
    if (displaySequence)vellumGoDisplayPresented(displayToken,displaySequence,shown.presentedTime);
   }
  }];
 }
 return drawable;
}
@end

void *vellumNewPresentationLayer(void) { return (__bridge void *)[VellumPresentationLayer layer]; }
void vellumPresentationObserver(void *layer,uint64_t token) { if(!token)[(VellumPresentationLayer *)layer retireDrawableBroker];[(VellumPresentationLayer *)layer setObserverToken:token]; }
void vellumPresentationFrame(void *layer,uint64_t tag,uint64_t generation,uint64_t composition,int armed) {
 [(VellumPresentationLayer *)layer setTag:tag generation:generation composition:composition armed:armed];
}
void vellumPresentationReceipt(void *layer,uint64_t tag) {
 if(!layer)return;
 VellumPresentationStamp stamp=[(VellumPresentationLayer *)layer captureStamp];
 if(stamp.token)vellumGoPresentationReceipt(stamp.token,tag,CACurrentMediaTime());
}

int vellumDisplayBackpressure(void *layer,uint64_t token) { return [(VellumPresentationLayer *)layer setDisplayToken:token]; }
void vellumDisplayFrame(void *layer,uint64_t credit) { [(VellumPresentationLayer *)layer setDisplayCredit:credit]; }

double vellumPresentationHostTime(void) { return CACurrentMediaTime(); }

int vellumPresentationAvailable(void) { if (@available(macOS 10.15.4,*))return 1;return 0; }
