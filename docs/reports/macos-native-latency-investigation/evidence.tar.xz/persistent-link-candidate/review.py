from pathlib import Path
import os,sys,json,hashlib,importlib.util,shlex
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;B=P/'review';B.mkdir(exist_ok=True)
sys.path.insert(0,str(P.parent.parent/'macos-sdk-stage0079-abe67c6-cache-v2/shared'))
s=importlib.util.spec_from_file_location('owned',P.parent.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);sys.modules[s.name]=g;s.loader.exec_module(g)
key=os.environ.get('ANTHROPIC_API_KEY');assert key,'existing Anthropic credential missing'
original=g.child_environment
def env(*args,**kwargs):
 e=original(*args,**kwargs)
 if args and args[0] is True:e['ANTHROPIC_API_KEY']=key
 return e
g.child_environment=env
source=P/'core/system/driver/desktop/presentation_darwin.m';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in [source,P/'fixture.m',P/'binding.json']}
(B/'rules.json').write_text(json.dumps({'rules':[{'id':'scope','text':'Private persistent macOS display-link acquisition candidate. Baseline two-drawable FIFO/vsync latency48-62ms. One native owner thread with its own runloop,persistent paused CAMetalDisplayLink preferredFrameLatency1,one coalescing CF wake source,one drawable slot. No user callbacks/render-caller runloop. External acquirers serialized by existing window/surface locks; CoreAnimation internal acquisition on link thread uses super. Request250ms;close2second join,timeout explicit stderr+native owner quarantine rather than releasing live native refs. No Go/window lock needed by owner thread. Explicit observer-removal seam called on every window close even without recorder. Candidate private,not adopted;production safety/latency not claimed. Return actual drawable to existing scalar native recorder; no synthetic times. Source helper real fake-link fixture covers delivery,timeout,retry,repeated-retire,late scalar callback;real GPU lifecycle stillpending. Review actual changed broker correctness,deadlocks,ownership,unbounded state. Existing first-acquisition experiment latch intentionally refuses late enable;nil on timeout deliberately fails strict validation without unbounded old-path fallback.'}]}))
argv=['/Users/dshills/Development/Go/bin/prism','review','snippet','--path','presentation_darwin.m','--lang','objc','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--chunk-bytes','240000','--max-diff-bytes','240000','--rules',str(B/'rules.json'),'--format','json','--out',str(B/'prism.json')]
r=g.execute(['/bin/sh','-c','cat '+shlex.quote(str(source))+' | '+shlex.join(argv)],'/private/tmp/vellum-macos-native-results-97aee13',B/'run',lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=180,limit=2<<20)
(B/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exit_code':r['exit_code'],'error':r['error'],'seconds':r['seconds']}))
