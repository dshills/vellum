from pathlib import Path
import json,hashlib,tarfile,io,math
P=Path(__file__).resolve().parent;R=Path('/private/tmp/vellum-macos-native-results-97aee13/docs/reports/macos-native-latency-investigation');R.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary={'outcome':'BLOCKER_UNRESOLVED_NO_POLICY_ADOPTED','framework_unchanged':True,'baseline_sdk_source':'bd3cbc9ce2566955dae5dbb61385b0e1a9307eaa','current_main_at_start':'f0c797f','effective_native_configuration':json.loads((P/'config-probe-v3/config.json').read_text()),'trials':{},'native_commands':0,'probe_commands':0,'all_owned_groups_retired':True,'release_qualified':False}
for name in ['config-probe-v2','config-probe-v3','transaction-candidate','transaction-flush-candidate','displaylink-candidate','persistent-link-candidate','metal-reference']:
 root=P/name;cmd=root/('result.json' if name=='metal-reference' else 'native-command.json');r=json.loads(cmd.read_text());summary['native_commands']+=1;summary['all_owned_groups_retired'] &= bool(r['owned']['terminal'] and r['owned']['group_absent'])
 d={'native_binary_sha256':sha(root/('native' if name=='metal-reference' else 'native-grid')),'exit_code':r['exit_code'],'seconds':r['seconds'],'owned_retired':r['owned']['terminal'] and r['owned']['group_absent']}
 if (root/'presentation.json').exists():
  j=json.loads((root/'presentation.json').read_text());s=j['BeforeClose']['Presentation'];d['journal_sha256']=sha(root/'presentation.json');d['prefix_states']={k:v for k,v in s.items() if not isinstance(v,list)};d['prefix_records']=len(s['Samples']);d['run_error']=j['RunError']
 if (root/'validation.json').exists():
  v=json.loads((root/'validation.json').read_text());d['strict_validation']=v['result'];d['measured_latency_ms']=v['measured_input_latency_ms']
 if name in ['displaylink-candidate','persistent-link-candidate']:
  d['decision']='REJECT_INVALID_CAPTURE';d['candidate_binding']=json.loads((root/'binding.json').read_text())
 if name=='transaction-candidate':d['decision']='REJECT_ALL_PREFIX_STATES_SKIPPED'
 if name=='transaction-flush-candidate':d['decision']='REJECT_VALID_CAPTURE_LATENCY_FAILED'
 if name=='config-probe-v2':d['decision']='REFUSE_CONFIGURATION_EVIDENCE; C source overlay absent from executable'
 if name=='config-probe-v3':d['decision']='CONFIGURATION_READ_COMPLETE;observational only'
 if name=='metal-reference':
  lines=[json.loads(s) for s in (root/'native-run/stdout').read_text().splitlines()];rows=[s for s in lines if 'index'in s];measured=rows[128:];d['decision']='REFUSE_QUALIFICATION_STARTUP_FEEDBACK_INVALID';d['all_record_count']=len(rows);d['nonpositive_feedback_indices']=[r['index'] for r in rows if r['presented']<=0];d['measured_nonpositive_count']=sum(r['presented']<=0 for r in measured)
  values=sorted((r['presented']-r['receipt'])*1000 for r in measured);d['partial_measured_diagnostic_ms']={'count':len(values),**{k:values[math.ceil(len(values)*q)-1] for k,q in [('p50',.5),('p95',.95),('p99',.99),('max',1)]}};d['native_os_floor_proven']=False
 summary['trials'][name]=d
for f in P.glob('*/before/*-command.json'):
 r=json.loads(f.read_text());summary['probe_commands']+=1;summary['all_owned_groups_retired'] &= r['owned']['terminal'] and r['owned']['group_absent']
for f in P.glob('*/after/*-command.json'):
 r=json.loads(f.read_text());summary['probe_commands']+=1;summary['all_owned_groups_retired'] &= r['owned']['terminal'] and r['owned']['group_absent']
(R/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for p in P.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(P);parts=rel.parts
 if 'core' in parts and not rel.as_posix().endswith('/core/system/driver/desktop/presentation_darwin.m'):continue
 if p.name in ['native-grid','native','fixture']:continue
 if p.name.endswith(('.a','.o','.zip','.xz')):continue
 if 'tmp' in parts:continue
 files[rel.as_posix()]=p
index={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(files.items())}
with tarfile.open(R/'evidence.tar.xz','w:xz') as tf:
 for n,p in sorted(files.items()):
  b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;i.mode=0o644;tf.addfile(i,io.BytesIO(b))
(R/'evidence-index.json').write_text(json.dumps({'files':index,'archive':{'bytes':(R/'evidence.tar.xz').stat().st_size,'sha256':sha(R/'evidence.tar.xz')},'excluded':['executables','complete prepared Core/SDK payloads','historical archives']},indent=2)+'\n')
print(json.dumps({'native':summary['native_commands'],'probes':summary['probe_commands'],'retired':summary['all_owned_groups_retired'],'archive_files':len(files),'archive_bytes':(R/'evidence.tar.xz').stat().st_size}))
