from pathlib import Path
import importlib.util,sys,json,datetime
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;S=P.parent.parent/'macos-release-default-assessment/assessment.py';s=importlib.util.spec_from_file_location('reuse',S);a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);a.P=P
if (P/'started.json').exists():raise ValueError('sealed reference')
plan=json.loads((S.parent/'plan.json').read_text());plan['pins']={str(P/n):a.sha(P/n) for n in ['native','main.m','run.py']};a.write(P/'plan.json',{'kind':'minimal native Metal clear reference;not framework/timing qualification','pins':plan['pins'],'criteria':'retain every record;128warmup120measured;refuse nonpositive feedback;FIFO/vsync2drawables;no performance gate change'})
start=datetime.datetime.now(datetime.timezone.utc);a.write(P/'started.json',{'started_utc':start.isoformat(),'authorization':'final bounded reference within second approved10minute quiet window'})
with a.lease_module.LiveLease() as lease:
 h=a.Host(plan,P,start+datetime.timedelta(seconds=12),lease,[False]);r=h.command([str(P/'native')],P,P/'native-run',10);a.write(P/'result.json',r);print(json.dumps({'exit_code':r['exit_code'],'seconds':r['seconds'],'owned':r['owned']}))
(P/'sealed').touch()
