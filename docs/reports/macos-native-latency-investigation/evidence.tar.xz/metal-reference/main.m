#import <Cocoa/Cocoa.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <QuartzCore/CAMediaTiming.h>
#include <stdio.h>
static double receipts[248],acquired[248],presented[248];
int main(void) { @autoreleasepool {
 NSApplication *app=[NSApplication sharedApplication];[app setActivationPolicy:NSApplicationActivationPolicyRegular];
 NSWindow *window=[[NSWindow alloc]initWithContentRect:NSMakeRect(50,50,1519,1266) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:NO];window.releasedWhenClosed=NO;window.title=@"Vellum Metal latency reference";
 id<MTLDevice> device=MTLCreateSystemDefaultDevice();id<MTLCommandQueue> queue=[device newCommandQueue];
 CAMetalLayer *layer=[CAMetalLayer layer];layer.device=device;layer.pixelFormat=MTLPixelFormatBGRA8Unorm;layer.maximumDrawableCount=2;layer.displaySyncEnabled=YES;layer.presentsWithTransaction=NO;layer.allowsNextDrawableTimeout=YES;layer.drawableSize=CGSizeMake(1519,1266);layer.framebufferOnly=YES;window.contentView.wantsLayer=YES;window.contentView.layer=layer;
 [window makeKeyAndOrderFront:nil];[app activateIgnoringOtherApps:YES];
 dispatch_group_t group=dispatch_group_create();dispatch_queue_t worker=dispatch_queue_create("vellum.metal.reference",DISPATCH_QUEUE_SERIAL);
 dispatch_async(worker,^{
  for (int i=0;i<248;i++) { @autoreleasepool {
   receipts[i]=CACurrentMediaTime();id<CAMetalDrawable> drawable=[layer nextDrawable];acquired[i]=CACurrentMediaTime();
   if(!drawable)break;
   int tag=i;dispatch_group_enter(group);
   [drawable addPresentedHandler:^(id<MTLDrawable> shown){ presented[tag]=shown.presentedTime;dispatch_group_leave(group); }];
   MTLRenderPassDescriptor *pass=[MTLRenderPassDescriptor renderPassDescriptor];pass.colorAttachments[0].texture=drawable.texture;pass.colorAttachments[0].loadAction=MTLLoadActionClear;pass.colorAttachments[0].storeAction=MTLStoreActionStore;pass.colorAttachments[0].clearColor=MTLClearColorMake(0.2,(i%2)?0.5:0.6,0.75,1);
   id<MTLCommandBuffer> cmd=[queue commandBuffer];id<MTLRenderCommandEncoder> encoder=[cmd renderCommandEncoderWithDescriptor:pass];[encoder endEncoding];[cmd presentDrawable:drawable];[cmd commit];
  }}
  long timedout=dispatch_group_wait(group,dispatch_time(DISPATCH_TIME_NOW,10*NSEC_PER_SEC));
  printf("{\"event\":\"metal.reference\",\"scope\":\"empty changing clear;not framework/workload qualification\",\"warmup\":128,\"samples\":120,\"timedout\":%ld}\n",timedout);
  for(int i=0;i<248;i++)printf("{\"index\":%d,\"receipt\":%.9f,\"acquired\":%.9f,\"presented\":%.9f}\n",i,receipts[i],acquired[i],presented[i]);fflush(stdout);
  dispatch_async(dispatch_get_main_queue(),^{[window close];[app stop:nil];[app postEvent:[NSEvent otherEventWithType:NSEventTypeApplicationDefined location:NSZeroPoint modifierFlags:0 timestamp:0 windowNumber:0 context:nil subtype:0 data1:0 data2:0] atStart:NO];});
 });
 [app run];dispatch_sync(worker,^{});printf("{\"closed\":true}\n");
 }return 0;}
