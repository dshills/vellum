# Local SDK consumption and performance measurements

The root framework module stays standard-library-only. The native adapter is a
separate module, `github.com/dshills/vellum/drivers/cogent`, matching its repository
directory. The framework namespace is `github.com/dshills/vellum` and its own code
is MIT-licensed. Public distribution remains gated on the dependency/native audit
and target qualification.

## Public document editing

The SDK includes the standard-library-only `editor` package and its managed
`ui.MultilineText` descriptor. The independent `examples/editor` module uses
exact document bytes, one history journal and the native input settlement API
before persistence. SDK relocation checks remove the producing source tree and
compile a consumer that reads the exact CRLF/Unicode document from the exported
package. The public API contract consumer also exercises composition, stale
content epochs and `document.Session` installation.

## Native dependency preparation

`drivers/cogent/prepare.sh` and `env.sh` own preparation and Go cache setup.
Preparation reads only driver-owned inputs. Its manifest pins Cogent and go-text
module versions/checksums, patch digests, original input hashes and patch order.
It downloads immutable module source, retains upstream license files, copies into
writable owned staging directories, verifies hashes and applies patches there. The driver multiwindow safety stage
also verifies expected final source hashes and runs its ownership regression tests
through the repository check script.
Both dependencies must pass before replacing existing prepared directories. Failure
rolls back installed directories. If filesystem errors prevent full rollback,
preparation retains original backups in the reported recovery staging directory
and reports their exact paths. Inspect and restore those backups before removing
the recovery directory. A filesystem lock rejects concurrent preparation.
A killed process can leave the lock; inspect for an active process before removing it.

Driver replacements resolve to `drivers/cogent/build/upstream` and
`drivers/cogent/build/typesetting`. Prototype modules and evidence remain historical
and are not required to prepare, test, build or consume the framework modules.

`check-text-backend.py` copies prepared upstream module metadata to a temporary
location and explicitly resolves its typesetting dependency to the prepared
owned tree. It runs exact-text, composition and visual geometry regressions with
an initialized offscreen display and a driver-owned installed-font cache. Direct
upstream tests do not inherit the driver module's replacements. The rendered
fixtures need offscreen display initialization; those results are separate from
native AppKit consumer runs. The helper does not mutate prepared source or OS
preferences.

## Independent application module

`examples/hello` has an independent `go.mod`, imports public framework packages and
the native driver, and renders a working counter and GPU rectangle. Its explicit
replacements cover both framework modules and both patched native dependencies.
Dependency-module replacements are not transitive in Go.

`scripts/new-app.py` creates the same application in a new directory, with a caller
selected application module path and absolute local framework/dependency replacements.
It retains the starter template's MIT LICENSE notice in the generated application.
It refuses existing destinations and requires preparation first. The generated
application can be tested and built outside the repository with `GOWORK=off`; it
still requires this checkout for its local SDK dependencies. Publishing versions,
installing a remotely fetched SDK, and relocating those dependencies are separate
release tasks.

## Repeatable measurements

`scripts/benchmark.sh` runs existing portable data benchmarks plus the standalone
application's UI construction/validation benchmark, with allocation reporting and
three repetitions. `--native` additionally builds and launches three visible native
processes via `benchmark-native.py` on a desktop with a supported GPU.

The standalone app's `-benchmark` mode disables native window-geometry loading
and saving before constructing the app and restores its previous process-local
switch on normal return after teardown. Ordinary interactive behavior is unchanged.
Its report includes the actual `geometry_persistence_disabled_in_fixture` flag;
`scripts/check-sdk.py --runtime` requires exactly one GPU report with that flag
strictly true. The generator copies this same starter, so relocated native checks
exercise the geometry-isolated benchmark rather than saved application geometry.

Every native run reports:

- Startup from application entry to a pixel-verified GPU rectangle; external process
  launch-to-report timing is also recorded. Both include initialization; first frame
  readiness is polled at 25 ms, so this is not compositor presentation latency.
- Ten synchronous GPU render/readback durations. Readback forces rendering; these
  observations include transfer/synchronization and are not ordinary frame FPS.
- Go heap allocation, native image dimensions, runtime/platform/machine metadata,
  and resident memory samples before/after the quiet interval.
- Process CPU-time difference during 60% of the quiet interval after a brief render-settling delay, expressed as seconds
  and percentage of one core. Linux uses `/proc` CPU ticks; other supported
  hosts use `ps` accounting. Reports record the sampling source and time quantum.
  Accounting precision limits small deltas; a zero observed delta does not prove
  zero idle CPU. Linux accounting parsing has fixture tests; native Linux runtime
  measurements remain unverified.

The harness fails if no verified GPU report arrives, the application exits with an
error, or sampling fails. Measurements provide host-specific baselines without
invented pass thresholds. Cold OS/font caches, other desktop processes, GPU/power
state and hardware affect results; comparisons should record matching conditions.
Windows/Linux runtime performance and accessibility/input correctness remain gates.

The public `document` package ships in private SDK archives alongside app/ui/history.
A relocated archive consumer exercises bounded file persistence after deleting
the fixture source checkout. Session/close policies follow [document.md](document.md).

The portable SDK exports `execution` alongside `tasks`, `document`, `editor` and
`app`. The archive relocation test deletes its source fixture and consumes these
packages through an independent module, including a manually stepped task whose
final result is admitted while the ordinary owner queue is full.

## Private ARM64 Mac GPU candidate

The SDK builder accepts an explicit private static-library overlay:

```sh
python3 scripts/release-sdk.py --output /private/tmp/candidate-sdk.tar.gz \
  --macos-gpu-library /absolute/path/libwgpu_native.a \
  --macos-gpu-sha256 <64-lowercase-hex-digest> \
  --macos-gpu-provenance /absolute/path/provenance.json
```

All three options are required together. `--public` rejects them before inventory,
download or output creation, including when other public gates are approved.
Ordinary packaging does not discover or reuse an ignored candidate directory.
The root framework module and portable example modules remain unchanged.

The library must be a regular, bounded ar archive with the expected SHA-256 and
at least one object. Every non-index member must have a thin ARM64 Mach-O
`MH_OBJECT` header; fat, foreign-architecture and unsupported payloads refuse.
This observes headers and exact bytes, not complete Mach-O semantics or ABI
compatibility. The same captured bytes are packaged. The archive limit is 64 MiB;
the provenance JSON limit is 1 MiB, with duplicate and nonfinite JSON values refused.
Provenance requires integer `schema: 1`, `target: "darwin-arm64"` and
`artifact_sha256` matching the selected library. Additional fields are retained
as caller-supplied declarations. The builder never interprets them as commands,
source attestation, executed-build evidence, component closure or rights approval.

The generated `drivers/cogent/build/libs-darwin` capsule contains exactly
`go.mod`, owned `libs.go`, `arm64/libwgpu_native.a` and `PROVENANCE.json`.
`SDK_MANIFEST.native_gpu` records their hashes, observed object count, target,
explicit unverified trust label and pending distribution audit. Its module
rewrite records contain both source and archived hashes. `source.commit` names
the framework baseline and `source.clean` describes the checkout; the candidate
and derived module files are disclosed overlays. Go graph notices remain
separate from native/Rust/standard-library component and rights closure.

Driver and native example main-module manifests receive relative local overrides.
Dependency replacements are not transitive: generated applications receive an
absolute override to the SDK capsule. The generator rechecks the capsule and
recorded module-overlay bytes, refuses symlinks and extra files such as a competing
dylib, and retains the existing destination and starter-license behavior.
The archive verifier couples the optional manifest record to its exact files;
an orphan capsule or mismatched record refuses. Relocation checks require the
actual Go module origin to equal the capsule directory and run candidate builds
only on an ARM64 Mac, explicitly targeting `GOOS=darwin GOARCH=arm64`.
Direct tests/builds from the prepared upstream dependency module are outside
these selected main-module overrides and need their own explicit replacement.

Digest and origin validation do not prove static linkage or runtime behavior.
A candidate qualification must separately inspect the compiled artifact/linkmap
for the exact archive and absence of WGPU dylib fallback, then run admitted native
checks. Other hosts/architectures, older OS runtimes, presentation, physical input,
performance/memory/endurance, signing and public distribution remain separate.
