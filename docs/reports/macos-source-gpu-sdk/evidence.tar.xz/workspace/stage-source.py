from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
files=['scripts/native_gpu.py','scripts/native_gpu_test.py','scripts/release-sdk.py','scripts/check-sdk.py','scripts/new-app.py','specs/sdk.md','specs/release.md','docs/implementation.md'];base='a274e8aa9305f4b458b2d263e2a1c3d3d7b6a623'
assert git(T,'rev-parse','HEAD').decode().strip()==git(C,'rev-parse','HEAD').decode().strip()==base;assert not git(C,'status','--porcelain','-z');assert not git(T,'diff','--cached','--name-only')
changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(files)
for name in files:assert (T/name).is_file()and not(T/name).is_symlink()
git(T,'add','--',*files);git(T,'diff','--cached','--check');assert not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')
diff=git(T,'diff','--cached','--binary');(W/'source-staged.diff').write_bytes(diff)
with(W/'source-stage.json').open('x')as out:out.write(json.dumps({'base_commit':base,'files':{name:sha(T/name)for name in files},'staged_diff_bytes':len(diff),'staged_diff_sha256':sha(W/'source-staged.diff')},indent=2)+'\n')
print(json.dumps({'staged_files':len(files),'bytes':len(diff),'sha256':sha(W/'source-staged.diff')}))
