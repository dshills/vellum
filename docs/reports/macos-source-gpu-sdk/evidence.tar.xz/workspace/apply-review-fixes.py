from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');pins=json.loads((W/'check.json').read_bytes())['inputs'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['native_gpu.py','native_gpu_test.py']:
 p=T/'scripts'/name;assert sha(p)==pins[str(p)];(W/'history'/('pre-review-'+name)).write_bytes(p.read_bytes());p.write_bytes((W/'draft/scripts'/name).read_bytes())
print('Applied finite JSON, orphan capsule and bounded directory review fixes')
