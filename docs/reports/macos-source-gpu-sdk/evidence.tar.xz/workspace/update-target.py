from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');old=json.loads((W/'unit.json').read_bytes())['inputs'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['check-sdk.py','native_gpu_test.py']:
 p=T/'scripts'/name;assert sha(p)==old[str(p)];(W/'history'/('before-target-'+name)).write_bytes(p.read_bytes());p.write_bytes((W/'draft/scripts'/name).read_bytes())
print('Enforced the selected candidate target during SDK checks; added pre-execution refusal regression')
