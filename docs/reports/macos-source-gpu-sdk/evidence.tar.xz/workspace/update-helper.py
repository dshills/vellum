from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((W/'source-binding.json').read_bytes());p=T/'scripts/native_gpu.py';assert sha(p)==b['files']['scripts/native_gpu.py']['draft'];p.write_bytes((W/'draft/scripts/native_gpu.py').read_bytes());print('Corrected native module selection for single-line require')
