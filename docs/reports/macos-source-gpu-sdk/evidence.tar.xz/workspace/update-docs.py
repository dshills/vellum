from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');pins=json.loads((W/'unit-v2.json').read_bytes())['inputs'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['specs/sdk.md','specs/release.md','docs/implementation.md']:
 p=T/name;assert sha(p)==pins[str(p)];p.write_bytes((W/'draft'/name).read_bytes())
print('Installed SDK candidate specification and implementation documentation')
