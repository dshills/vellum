"""Install report files and freeze the combined implementation/evidence checkpoint."""
from pathlib import Path
import hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=60)
def main():
 assert not(W/'binding.json').exists()
 stage=read(W/'source-stage.json');review=read(W/'internal-review.json');disposition=read(W/'prism-disposition.json')
 assert review['results_ready'] and not review['unresolved_findings'] and disposition['accepted'] and not disposition['unresolved_findings']
 assert all(sha(p)==h for p,h in review['inputs'].items())
 assert git(C,'rev-parse','HEAD').decode().strip()==git(T,'rev-parse','HEAD').decode().strip()==stage['base_commit']
 assert not git(C,'status','--porcelain','-z') and not git(T,'diff','--name-only') and not git(T,'ls-files','--others','--exclude-standard')
 assert sha(W/'source-staged.diff')==hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==stage['staged_diff_sha256']
 assert all(sha(T/n)==h for n,h in stage['files'].items())
 report=W/'report';manifest=read(report/'evidence.manifest.json')
 assert manifest['archive']==dict(bytes=(report/'evidence.tar.xz').stat().st_size,sha256=sha(report/'evidence.tar.xz'))
 result=read(report/'result.json');assert result['unit_tests']==68 and result['sdk_archive']['files']==7436 and not result['native_runtime_executed']
 target=Path('docs/reports/macos-source-gpu-sdk')
 sources={str(target/n):(report/n).read_bytes()for n in ['README.md','result.json','evidence.manifest.json','evidence.tar.xz']}
 name='docs/reports/README.md';text=(C/name).read_text();needle='- [Source-built GPU workbench consumer]';assert text.count(needle)==1
 sources[name]=text.replace(needle,'- [Private source-built GPU SDK overlay](macos-source-gpu-sdk/README.md)\n\n'+needle,1).encode()
 links=0
 prospective_names=set(sources)|set(stage['files'])
 for name in prospective_names:
  if not name.endswith('.md'):continue
  body=sources.get(name,(T/name).read_bytes()if(T/name).exists()else b'')
  for destination in re.findall(r'\[[^\]]*\]\(([^\n)]+)\)',body.decode()):
   destination=destination.strip('<>').split('#',1)[0]
   if not destination or ':'in destination or destination.startswith('/'):continue
   path=(C/name).parent.joinpath(destination).resolve();relative=str(path.relative_to(C))
   assert relative in prospective_names or path.exists(),(name,destination)
   links+=1
 for name,body in sources.items():
  p=T/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 assert set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(sources)
 git(T,'add','--',*sorted(sources));git(T,'diff','--cached','--check')
 assert not git(T,'diff','--name-only') and not git(T,'ls-files','--others','--exclude-standard')
 names=set(stage['files'])|set(sources)
 assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==names and len(names)==13
 diff=git(T,'diff','--cached','--binary');(W/'staged.diff').write_bytes(diff)
 binding=dict(base_commit=stage['base_commit'],sources={n:sha(T/n)for n in sorted(names)},staged_diff_sha256=sha(W/'staged.diff'),staged_diff_bytes=len(diff),source_files=4722,prepared_files=6249,relative_file_links=links,provider_reviewed_files=stage['files'],provider_reviewed_diff_sha256=stage['staged_diff_sha256'])
 assert len(git(T,'ls-files','-z').decode().split('\0')[:-1])==4722
 with(W/'binding.json').open('x')as out:out.write(json.dumps(binding,indent=2)+'\n')
 print(json.dumps(dict(result='STAGED_IMPLEMENTATION_AND_EVIDENCE',files=len(names),bytes=len(diff),sha256=binding['staged_diff_sha256'],links=links)))
if __name__=='__main__':main()
