from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((W/'source-binding.json').read_bytes());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip()==b['base_commit']
for name,v in b['files'].items():assert sha(T/name)==v['draft']
p=T/'scripts/native_gpu_test.py';assert not p.exists();p.write_bytes((W/'draft/scripts/native_gpu_test.py').read_bytes());print('Installed SDK GPU regression tests')
