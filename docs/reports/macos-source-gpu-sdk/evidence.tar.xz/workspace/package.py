"""Retain source/check/review evidence; exclude native binaries and caches."""
from pathlib import Path
import hashlib, io, json, sys, tarfile
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
P = Path('/private/tmp/vellum-source-gpu-sdk-a274e8a')
R = W / 'report'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
def need(ok, message):
    if not ok: raise ValueError(message)
def main():
    need(not R.exists(), 'fresh evidence output')
    stage = read(W/'source-stage.json')
    review = read(W/'internal-review.json')
    need(review.get('results_ready') and not review['unresolved_findings'], 'reviewed source/check results')
    need(all(sha(p)==h for p,h in review['inputs'].items()), 'reviewed inputs stable')
    receipt, prism = read(W/'prism/receipt.json'), read(W/'prism/prism.json')
    disposition = read(W/'prism-disposition.json')
    need(receipt['result']=='COMPLETE_SCOPED_PROVIDER_REVIEW' and disposition['accepted'] and not disposition['unresolved_findings'], 'complete provider review and disposition')
    need(disposition['report_sha256']==sha(W/'prism/prism.json') and receipt['staged_diff_sha256']==stage['staged_diff_sha256'], 'provider source binding')
    phases=['unit','unit-v2','unit-v3','package','check','network-probe','package-v2','check-v2']
    checks={n:read(W/(n+'.json')) for n in phases}
    need(all(checks[n]['result']=='PASS_'+n.upper() for n in phases if n!='check'), 'passing final checks and retained intermediate successes')
    need(checks['check']['result']=='FAILED_CHECK' and checks['check']['run']['exit_code']==1, 'original failed Unix socket check retained')
    need(all(d['run']['owned']['terminal'] and d['run']['owned']['group_absent'] and not d['run']['owned']['errors'] for d in checks.values()), 'owned check closure')
    summary=read(W/'sdk-summary.json')
    need(summary['files']==7436 and summary['archive_sha256']=='1777dc32f97e12056b2931f5d6d21a114a0ad191a1415c35d260b414c0d3c05d', 'actual candidate identity')
    need('PRISM_RESULT_PENDING' not in (W/'README.final.md').read_text(), 'completed prose')
    entries={}
    def add(name,path):
        p=Path(path);need(name not in entries and p.is_file() and not p.is_symlink(), 'regular unique evidence')
        entries[name]=p
    # These workspace directories contain only owned source, inventories, receipts and bounded logs.
    for p in sorted(W.rglob('*')):
        if p.is_file() and not p.is_symlink() and not p.is_relative_to(R) and not any(part in ['__pycache__','commit-logs'] for part in p.relative_to(W).parts):
            need(p.stat().st_size<=8<<20,'bounded workspace evidence')
            add('workspace/'+p.relative_to(W).as_posix(),p)
    for name,h in stage['files'].items():
        need(sha(T/name)==h,'exact reviewed production source')
        add('source/'+name,T/name)
    for phase,d in checks.items():
        for name in ['stdout','stderr','owned.json']:
            p=P/phase/name
            if name in d['run']['logs']:
                log=d['run']['logs'][name]
                need(p.stat().st_size==log['bytes'] and sha(p)==log['sha256'],'exact recorded check stream')
            add('runs/'+phase+'/'+name,p)
    helpers={
        'owned_process.py':W.parent/'macos-sdk-native-238b3b6/run.py',
        'fetch_dependencies.py':W.parent/'macos-source-built-gpu-276a654/fetch_dependencies.py',
        'child_process.py':T/'scripts/child_process.py',
        'sdk_environment.py':T/'scripts/sdk_environment.py',
        'native_archive.py':T/'scripts/native_archive.py',
        'live_lease.py':Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'),
    }
    for name,p in helpers.items(): add('helpers/'+name,p)
    index={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())}
    exclusions=[]
    for p in [P/'candidate-sdk.tar.gz',P/'candidate-sdk-v2.tar.gz',Path('/private/tmp/vellum-source-built-gpu-276a654/build-target-v1/aarch64-apple-darwin/release/libwgpu_native.a')]:
        exclusions.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
    R.mkdir()
    with tarfile.open(R/'evidence.tar.xz','w:xz',preset=6) as a:
        for name,p in sorted(entries.items()):
            body=p.read_bytes();need(hashlib.sha256(body).hexdigest()==index[name]['sha256'],'stable package member')
            info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o644;info.mtime=0;a.addfile(info,io.BytesIO(body))
    with tarfile.open(R/'evidence.tar.xz','r:xz') as a:
        need(a.getnames()==sorted(index),'exact archive members')
        for m in a:
            body=a.extractfile(m).read();need(len(body)==index[m.name]['bytes'] and hashlib.sha256(body).hexdigest()==index[m.name]['sha256'],'verified readback member')
    manifest=dict(files=index,archive=dict(bytes=(R/'evidence.tar.xz').stat().st_size,sha256=sha(R/'evidence.tar.xz')),excluded_principal_artifacts=exclusions,other_exclusions='Go caches/temp files and binaries removed by the relocation checker are absent. Full source/prepared/tool input fingerprints remain in check receipts. No native SDK run or physical input was performed.')
    (R/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    result=dict(result='PASS_PRIVATE_ARM64_MAC_GPU_SDK_OVERLAY_CHECKS',source=summary['source'],private_build=True,sdk_archive=summary,unit_tests=68,unit_test_methods_new=9,relocation=checks['check-v2']['record'],transport_probe=checks['network-probe']['record'],original_relocation=dict(result=checks['check']['result'],exit_code=1,reason='Unix socket API test refused by deny-network-all harness; consumer race/vet/build had passed',relabelled=False),internal_review_sha256=sha(W/'internal-review.json'),prism=dict(receipt_sha256=sha(W/'prism/receipt.json'),report_sha256=sha(W/'prism/prism.json'),coverage=prism['coverage'],retained_findings=len(prism['findings']),discarded_findings=len(prism.get('discarded',[])),suppressed_findings=len(prism.get('suppressed',[])),disposition=disposition),warnings_retained=True,native_runtime_executed=False,static_linkage_qualified=False,clean_commit_archive_qualified=False,public_distribution_qualified=False,full_macos_qualified=False,settings_changes=False,physical_input_generated=False)
    (R/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    (R/'README.md').write_bytes((W/'README.final.md').read_bytes())
    need(all(sha(p)==h for p,h in review['inputs'].items()),'terminal reviewed evidence stability')
    print(json.dumps(dict(result='PACKAGED',members=len(index),archive=manifest['archive'])))
if __name__=='__main__':main()
