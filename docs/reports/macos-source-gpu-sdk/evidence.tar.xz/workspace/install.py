from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((W/'source-binding.json').read_bytes());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip()==b['base_commit'];assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=T)
for name,v in b['files'].items():
 p=T/name;assert (sha(p)if p.exists()else None)==v['before'];assert sha(W/'draft'/name)==v['draft']
for name,v in b['files'].items():(T/name).write_bytes((W/'draft'/name).read_bytes());assert sha(T/name)==v['draft']
with(W/'install-receipt.json').open('x')as f:f.write(json.dumps({'result':'SOURCE_DRAFT_INSTALLED','binding':sha(W/'source-binding.json'),'files':b['files']},indent=2)+'\n')
print('Installed four SDK implementation files; no build or native execution')
