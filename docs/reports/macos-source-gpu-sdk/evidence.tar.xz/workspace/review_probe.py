"""Focused non-executing checks of the three provider findings."""
from pathlib import Path
import hashlib,json,struct,sys,tempfile
from unittest import mock
sys.dont_write_bytecode=True
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'scripts'))
import native_gpu as gpu
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
from native_archive_test import member
before={str(p):sha(p)for p in [T/'scripts/native_gpu.py',T/'scripts/native_archive.py',T/'scripts/native_archive_test.py',Path(__file__)]}
controls=[]
with tempfile.TemporaryDirectory(prefix='vellum-provider-merits-')as tmp:
 root=Path(tmp);lib=root/'candidate.a';provenance=root/'provenance.json'
 obj=struct.pack('<IIIIIIII',0xFEEDFACF,0x0100000C,0,1,0,0,0,0)
 def candidate(body):
  lib.write_bytes(body);digest=gpu.digest(body)
  provenance.write_text(json.dumps(dict(schema=1,target='darwin-arm64',artifact_sha256=digest)))
  return gpu.candidate(lib,digest,provenance)
 for name,extended in [('__.SYMDEF',False),('__.SYMDEF',True),('__.SYMDEF SORTED',True),('__.SYMDEF_64 SORTED',True)]:
  record,_=candidate(b'!<arch>\n'+member(name,b'index',extended)+member('long-object.rcgu.o',obj,True))
  assert record['arm64_object_members']==1
  controls.append(dict(kind='index-normalization',name=name,bsd_extended=extended,objects=1))
 valid=b'!<arch>\n'+member('one.o',obj)
 malformed=[valid[:8]+b'bad',valid[:66]+b'xx'+valid[68:],valid[:-1],b'!<arch>\n'+member('one.o',b'odd')[:-1],valid[:56]+b'9999999999'+valid[66:]]
 for i,body in enumerate(malformed):
  with mock.patch.object(gpu,'arm64_objects',wraps=gpu.arm64_objects)as observed:
   try:candidate(body)
   except ValueError as error:message=str(error)
   else:raise AssertionError('malformed candidate accepted')
   assert observed.call_count==0
  controls.append(dict(kind='malformed-refused-before-object-walk',index=i,error=message))
 # A digest mismatch between first byte capture and framing observation also refuses before the walk.
 with mock.patch.object(gpu,'archive_members',return_value=dict(sha256='0'*64,members=[])),mock.patch.object(gpu,'arm64_objects')as observed:
  try:candidate(valid)
  except ValueError as error:assert 'between observations'in str(error)
  else:raise AssertionError('cross-read drift accepted')
  assert observed.call_count==0
 controls.append(dict(kind='cross-read-drift-refused-before-object-walk'))
 default=root/'default-sdk';default.mkdir()
 assert gpu.sdk_candidate(default)is None
 controls.append(dict(kind='source-no-manifest-returns-none'))
 for manifest in [{},{'files':{},'private_build':True}]:
  (default/'SDK_MANIFEST.json').write_text(json.dumps(manifest));assert gpu.sdk_candidate(default)is None
  controls.append(dict(kind='default-sdk-no-candidate-returns-none',manifest=manifest))
 (default/'SDK_MANIFEST.json').write_text('{')
 try:gpu.sdk_candidate(default)
 except ValueError:pass
 else:raise AssertionError('malformed SDK manifest accepted')
 controls.append(dict(kind='malformed-manifest-refuses-intentionally'))
assert all(sha(p)==h for p,h in before.items())
d=dict(result='PASS_PROVIDER_MERITS_PROBE',count=len(controls),controls=controls,inputs=before,production_source_changed=False,native_runtime_executed=False)
with(W/'review-probe.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(result=d['result'],count=d['count'])))
