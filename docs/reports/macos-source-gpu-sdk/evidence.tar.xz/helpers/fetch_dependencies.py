"""Isolated locked target dependency fetch; never compile downloaded packages."""
from pathlib import Path
import hashlib,importlib.util,json,sys,tomllib
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-source-built-gpu-276a654');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
s=importlib.util.spec_from_file_location('source_gpu_owned_process',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def terminal(run):return run['created']and run['error']is None and run['exit_code']==0 and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
def main():
 need(not(P/'cargo-home').exists()and not(W/'dependency-fetch.json').exists(),'new isolated Cargo fetch')
 need(read(W/'source-receipt.json')['result']=='EXACT_PINNED_WGPU_SOURCE_BLOBS_VERIFIED'and read(W/'headers-receipt.json')['result']=='PINNED_ROOT_AND_HEADERS_COMMIT_TREES_AND_GO_ABI_VERIFIED','pinned source/ABI admitted')
 compiler=Path('/Users/dshills/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin');need(all((compiler/n).is_file()for n in['cargo','rustc','rustdoc']),'explicit installed compiler')
 source={str(p):sha(p)for p in(P/'source').rglob('*')if p.is_file()};pins={**source,str(__file__):sha(__file__),**{str(compiler/n):sha(compiler/n)for n in['cargo','rustc','rustdoc']},**{str(W/n):sha(W/n)for n in['source.py','source-receipt.json','source-controls.json','headers.py','headers-receipt.json']}}
 home=P/'cargo-home';home.mkdir(mode=0o700);inventory=read(W.parent/'macos-source-built-gpu-preflight-30025cc/inventory.json');seeded=[]
 for entry in inventory['registry']:
  for cached in entry['verified_cached_archives'][:1]:
   p=Path(cached['path']);body=p.read_bytes();need(hashlib.sha256(body).hexdigest()==entry['checksum'],'rechecked cached locked archive')
   out=home/'registry/cache'/p.parent.name/p.name;out.parent.mkdir(parents=True,exist_ok=True)
   with out.open('xb')as f:f.write(body)
   seeded.append(dict(path=str(out),sha256=entry['checksum'],bytes=len(body)))
 env=['CARGO_HOME='+str(home),'CARGO_TARGET_DIR='+str(P/'target'),'RUSTC='+str(compiler/'rustc'),'RUSTDOC='+str(compiler/'rustdoc'),'RUSTUP_TOOLCHAIN=1.99.0','CARGO_BUILD_JOBS=2','CARGO_HTTP_TIMEOUT=20','CARGO_NET_RETRY=0','PATH='+str(compiler)+':/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin']
 stopping=lambda:(P/'stop-compile').exists();stable=lambda:all(sha(p)==h for p,h in pins.items())
 d=dict(result='INCOMPLETE',source_code_executed=False,native_runtime_executed=False,compiler_settings_changed=False,seeded=seeded,inputs=pins,commands=[],error=None)
 try:
  for label,args in [('rustc-version',[str(compiler/'rustc'),'--version','--verbose']),('cargo-version',[str(compiler/'cargo'),'--version','--verbose']),('fetch',[str(compiler/'cargo'),'fetch','--locked','--target','aarch64-apple-darwin','--manifest-path',str(P/'source/Cargo.toml')])]:
   run=g.execute(['/usr/bin/env',*env,*args],P/'source',P/label,stopping,stable,timeout=240 if label=='fetch'else 30,limit=8<<20);d['commands'].append(dict(label=label,run=run));need(terminal(run),'bounded exact compiler/fetch command '+label)
  lock=tomllib.loads((P/'source/Cargo.lock').read_text());expected={(v['name'],v['version']):v['checksum']for v in lock['package']if v.get('source','').startswith('registry+')};archives=[]
  for p in(home/'registry/cache').glob('*/*.crate'):
   candidates=[(name,version,checksum)for(name,version),checksum in expected.items()if p.name==name+'-'+version+'.crate'];need(len(candidates)==1,'only locked registry archives')
   name,version,checksum=candidates[0];need(not p.is_symlink()and sha(p)==checksum,'Cargo locked archive checksum');archives.append(dict(name=name,version=version,path=str(p),bytes=p.stat().st_size,sha256=checksum))
  need(stable()and not stopping(),'terminal source/compiler identity');d.update(result='PASS_ISOLATED_LOCKED_TARGET_FETCH_NO_SOURCE_COMPILATION',archives=archives,archive_count=len(archives),archive_bytes=sum(v['bytes']for v in archives),root_source_files=len(source))
 except BaseException as error:d.update(result='FAILED_ISOLATED_LOCKED_TARGET_FETCH',error=dict(type=type(error).__name__,message=str(error)));raise
 finally:
  with(W/'dependency-fetch.json').open('x')as out:out.write(json.dumps(d,indent=2)+'\n')
  print(json.dumps({k:v for k,v in d.items()if k not in['seeded','inputs','commands','archives']}),flush=True)
if __name__=='__main__':main()
