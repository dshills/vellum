import datetime,hashlib,json,subprocess,sys,time
from pathlib import Path
phase=Path('/private/tmp/vellum-macos-tree-performance');root=Path('/private/tmp/vellum-large-data')
sys.path.insert(0,str(root/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
# Reuse exact source/prepared identity maps; porcelain strings keep their spaces.
import importlib.util
spec=importlib.util.spec_from_file_location('run_identity',phase/'run-v3.py');identity_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity_module)
expected=identity_module.identity();(phase/'campaign-baseline.json').write_text(json.dumps(expected,indent=2)+'\n')
auth=phase/'testing-authorization.json';assert json.loads(auth.read_text())['live_window_input_performance_tests_allowed']
binaries={name:phase/('loadedtree-'+name)for name in ['baseline','candidate']}
assert all(p.is_file()for p in binaries.values())
env={**child_environment(runtime=True),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
index=[];result='FAILED';start=time.monotonic()
try:
 for repeat in range(5):
  for nodes,deep in [(10000,False),(100000,False),(10000,True),(100000,True)]:
   for build in (['baseline','candidate']if repeat%2==0 else ['candidate','baseline']):
    name=f'{build}-{nodes}-'+('deep'if deep else'wide')+f'-r{repeat+1}'
    argv=[str(binaries[build]),'-perf',f'-nodes={nodes}','-perf-samples=240','-perf-warmup=128']+(['-perf-deep']if deep else[])
    record={'name':name,'build':build,'nodes':nodes,'deep':deep,'repeat':repeat+1,'argv':argv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':expected['commit'],'source_baseline_sha256':hashlib.sha256((phase/'campaign-baseline.json').read_bytes()).hexdigest(),'authorization_sha256':hashlib.sha256(auth.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256(binaries[build].read_bytes()).hexdigest(),'exit_code':None,'error':None}
    began=time.monotonic()
    try:
     with(phase/(name+'.stdout')).open('xb')as out,(phase/(name+'.stderr')).open('xb')as err:record['exit_code']=run_child(argv,cwd=root,env=env,stdout=out,stderr=err,timeout=300).returncode
    except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
    record['elapsed_seconds']=time.monotonic()-began;record['source_prepared_stable']=identity_module.identity()==expected
    for channel in ['stdout','stderr']:record[channel+'_sha256']=hashlib.sha256((phase/(name+'.'+channel)).read_bytes()).hexdigest()
    (phase/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');index.append(record)
    print(json.dumps({k:record[k]for k in ['name','exit_code','error','elapsed_seconds','source_prepared_stable']}),flush=True)
    assert record['exit_code']==0 and record['error']is None and record['source_prepared_stable'],name
 result='PASS_NATIVE_CAMPAIGN_PROCESSES'
finally:
 (phase/'campaign.json').write_text(json.dumps({'result':result,'processes':index,'elapsed_seconds':time.monotonic()-start,'source_prepared_stable':identity_module.identity()==expected},indent=2)+'\n')
print('CAMPAIGN',result,len(index),flush=True)
