import hashlib,json,math,re,statistics
from pathlib import Path
phase=Path('/private/tmp/vellum-macos-tree-performance')
def percentile(values,fraction):
 values=sorted(values);return values[math.ceil(len(values)*fraction)-1]
def read_events(path):return [json.loads(line)for line in path.read_text().splitlines()]
# Preserve the original failing counters and compare all twelve final pixel records.
original=(phase/'tree-update-original-race.stdout').read_text();candidate=(phase/'tree-update-candidate-race.stdout').read_text();pattern=r'TREE_UPDATE_RGBA ([^\n]+)';before=re.findall(pattern,original);after=re.findall(pattern,candidate);assert len(before)==12 and before==after
campaign=json.loads((phase/'campaign.json').read_text());assert campaign['result']=='PASS_NATIVE_CAMPAIGN_PROCESSES'and len(campaign['processes'])==40 and campaign['source_prepared_stable']
runs=[];layouts={};frame_fields=['InputNS','OwnerNS','ReconcileNS','LayoutPaintNS','GatherNS','RasterUploadNS','EncodeSubmitNS']
for receipt in campaign['processes']:
 name=receipt['name'];assert receipt['exit_code']==0 and receipt['error']is None and receipt['source_prepared_stable']
 rows=read_events(phase/(name+'.stdout'));event=lambda k:[r for r in rows if r['event']==k]
 for key in ['tree.perf.setup','tree.perf.geometry','tree.perf.first-scroll','tree.perf.ready','tree.perf.finished']:assert len(event(key))==1
 setup=event('tree.perf.setup')[0];initial=event('tree.perf.geometry')[0]['initial'];ready=event('tree.perf.ready')[0];finished=event('tree.perf.finished')[0];first=event('tree.perf.first-scroll')[0];samples=event('tree.perf.sample');assert len(samples)==240 and finished['samples']==240 and finished['frame_tickets']==370 and ready['warmup']==128
 assert setup['nodes']==receipt['nodes']and setup['deep']==receipt['deep']and setup['data']['Nodes']==receipt['nodes']and setup['target_p95_ns']==4_000_000
 assert first['frame']['Tag']==1 and first['frame']['Generation']==initial['Generation']+1 and first['frame']['Completed']and not first['frame']['Failure']
 assert first['geometry']['Viewport']['ScrollY']==initial['Viewport']['ScrollY']+12
 start=initial['Viewport']['ScrollY'];offset=start;values=[];allocations=[];cardinalities=[]
 for index,row in enumerate(samples):
  frame=row['frame'];g=row['geometry'];phase_index=index%32;delta=12 if phase_index<16 else-12;offset+=delta
  assert row['index']==index and row['phase']==phase_index and frame['Tag']==131+index and frame['Generation']==initial['Generation']+131+index
  assert frame['Completed']and not frame['Failure']and frame['TotalUIWorkNS']==sum(frame[k]for k in frame_fields)
  assert g['Viewport']['ScrollY']==offset and 64<=g['ClippedRows']<=500 and g['MaterializedRows']<=500 and g['RetainedRows']<=500 and row['tree_notifications']==1
  assert g['Scale']==ready['geometry']['Scale']and g['Bounds']==ready['geometry']['Bounds']and {k:g['Viewport'][k]for k in ['Width','Height']}=={k:ready['geometry']['Viewport'][k]for k in ['Width','Height']}
  key=(receipt['deep'],phase_index);identity=(g['Scale'],g['Bounds'],g['Viewport']['Width'],g['Viewport']['Height'],g['ClippedRows'],g['MaterializedRows'],g['RetainedRows'],g['LayoutSHA256'])
  if key in layouts:assert identity==layouts[key],(name,index,'geometry mismatch')
  else:layouts[key]=identity
  values.append(frame['TotalUIWorkNS']);allocations.append(row['allocation_bytes']);cardinalities.append(g['ClippedRows'])
 run={'name':name,'build':receipt['build'],'nodes':receipt['nodes'],'deep':receipt['deep'],'repeat':receipt['repeat'],'samples':len(samples),'ui_work_ns':{'mean':statistics.mean(values),'p50':percentile(values,.5),'p95':percentile(values,.95),'p99':percentile(values,.99),'max':max(values)},'target_p95_pass':percentile(values,.95)<=4_000_000,'allocation_bytes_mean':statistics.mean(allocations),'clipped_rows_range':[min(cardinalities),max(cardinalities)],'first_scroll_ui_work_ns':first['frame']['TotalUIWorkNS'],'stage_p95_ns':{k:percentile([s['frame'][k]for s in samples],.95)for k in frame_fields},'heap_after_data':setup['memory_after_data']['HeapAlloc'],'heap_after_warmup':ready['memory']['HeapAlloc'],'heap_after_measurement':finished['memory']['HeapAlloc']}
 runs.append(run)
cases=[]
for nodes in [10000,100000]:
 for deep in [False,True]:
  result={'nodes':nodes,'deep':deep,'builds':{}}
  for build in ['baseline','candidate']:
   selected=[r for r in runs if r['nodes']==nodes and r['deep']==deep and r['build']==build];assert len(selected)==5
   result['builds'][build]={'p95_ms_mean_of_runs':statistics.mean(r['ui_work_ns']['p95']for r in selected)/1e6,'mean_ms_mean_of_runs':statistics.mean(r['ui_work_ns']['mean']for r in selected)/1e6,'allocation_bytes_mean':statistics.mean(r['allocation_bytes_mean']for r in selected),'target_passes':sum(r['target_p95_pass']for r in selected),'samples':sum(r['samples']for r in selected)}
  base=result['builds']['baseline'];new=result['builds']['candidate'];result['p95_change_percent']=(new['p95_ms_mean_of_runs']/base['p95_ms_mean_of_runs']-1)*100;cases.append(result)
summary={'result':'VALIDATED_TREE_NATIVE_COMPARISON','processes':40,'samples':9600,'runs':runs,'cases':cases,'identical_phase_geometry':True,'software_pixel_records':12,'software_pixels_exact':True,'original_duplicate_pass_errors':len(re.findall(r'passes=2/2',original)),'full_p6_qualified':False,'native_gpu_memory_qualified':False,'notes':'Elapsed recorded work regions, not thread CPU/GPU/presentation; ordinary first scroll is separate and is not cold-cache evidence. Allocation intervals include observers and other process goroutines. This is a64-minimum-row warm workload, not500visible-row or fulltreeinteraction/cold-cache qualification. Raw preflights that refused53rows remain historical diagnostics.'}
(phase/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'result':summary['result'],'cases':cases},indent=2))
