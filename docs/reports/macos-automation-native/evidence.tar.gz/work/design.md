# Native workbench automation checkpoint

Base: bde59225d6bc587c648338bb49d1c027c49e2303, clean C/T, 4691 tracked / 6249 prepared.
P10 still lacks a real native application/external public-Go-client campaign.

Implement an explicit workbench `-automation-check` diagnostic flag, requiring
`-automation -exit-after` in a bounded 5–30 second range and excluding other smoke
or endurance modes. Before creating the app, reuse its process-local geometry
persistence fence. Ordinary workbench/automation behavior remains as before.
The fixture emits a safe ready event only after an owner GPU snapshot and native
window exist. It joins this check and the semantic server's Close/Done/Err on
shutdown and emits bounded safe transport audit metadata. A fixture-specific
signal context allows owned SIGTERM cancellation to use normal cleanup.

Add `examples/automation` as an independent standard-library-only Go consumer of
public automation.Call, not of adapter internals. It launches the known-built
workbench as a child in its own inherited process group, receives the endpoint
only through stdout into bounded memory, waits for the safe native-ready event,
then runs deterministic inspect/select/rotate/raise/Undo/Redo/ABA-stale,
availability, virtual-ID, unknown-target, invalid-params, redacted-DTO and
post-close checks. Never retry invokes. Cases cover100k and1M source rows later.

No bearer credential is written to argv, environment, files or shared logs.
Retain bounded native stdout/stderr in memory; only publish redacted streams
following validated endpoint capture, with no raw output on failed capture.
Controller output contains request IDs, safe DTOs and fixed error codes only.
The controlling test executor already owns the Go controller's group; its native
child inherits that group so stop/watchdog retirement covers both. Normal process
exit must be zero, server Done observed, endpoint socket/owned directory removed
and a public Call after closure refused. No physical input, preferences changes,
GUI AX, frame budgets, native memory or full Mac claim.

Use real regression tests for isolation-config refusal, bounded framing and
credential removal, wrong/missing event records and live public-client scripted
history semantics. Compile/test race/vet offscreen workbench and the new consumer;
review internally, then one bounded Prism Anthropic Sonnet5.5 checkpoint before
source commit. Fresh clean native binaries and live readiness review come after
that commit. Source and native evidence commits remain separate.

Draft refinement: discard ALL raw native output; publish only checked fixed scalar summary. Separately join readiness producer closure after worker teardown. Install check-only signal context before endpoint/workers. Bound final direct-child reap and retain fixed cleanup failure. Canonical private descriptor; 40 serial requests, six fault controls matched to specific refusal reasons. Prototype v1 inspect-envelope failure and v2 mistaken request-count expectation preserved; v3 offscreen race/vet/build pass.
