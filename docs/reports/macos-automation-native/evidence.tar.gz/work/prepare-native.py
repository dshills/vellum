"""Compile fresh clean committed executables; never launch native code here."""
from pathlib import Path
import datetime,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
spec=importlib.util.spec_from_file_location('api_clean_build_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=20)
c=read(W/'commit-receipt.json');assert c['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED'and c['both_clean'];HEAD=c['commit'];P=Path('/private/tmp/vellum-native-automation-clean-'+HEAD[:7]);P.mkdir(mode=0o700)
files={};prepared={}
for root in [T,C]:
 assert git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain','-z')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];assert len(names)==4700
 for n in names:
  p=root/n;assert p.is_file()and not p.is_symlink();files[str(p)]=g.sha(p)
 local={}
 for name in ['upstream','typesetting']:
  for p in(root/'drivers/cogent/build'/name).rglob('*'):
   assert not p.is_symlink()
   if p.is_file():local[str(p)]=g.sha(p)
 assert len(local)==6249;prepared.update(local)
assert all(files[str(T/n)]==files[str(C/n)]for n in names)
assert all(prepared[str(T/'drivers/cogent/build'/Path(p).relative_to(C/'drivers/cogent/build'))]==h for p,h in prepared.items()if str(p).startswith(str(C)))
(P/'source.json').write_text(json.dumps(files,indent=2)+'\n');(P/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
pins={**files,**prepared,str(Path(__file__).resolve()):g.sha(__file__),str(W/'commit-receipt.json'):g.sha(W/'commit-receipt.json')};stable=lambda:all(g.sha(p)==h for p,h in pins.items())
prefix=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go']
commands=[('client',T/'examples/automation',prefix+['build','-trimpath','-o',str(P/'automation'),'.']),('workbench',T/'drivers/cogent',prefix+['build','-trimpath','-o',str(P/'workbench'),'./cmd/workbench'])]
d={'result':'INCOMPLETE','source_commit':HEAD,'native_runtime_executed':False,'commands':[],'error':None}
try:
 for name,cwd,args in commands:
  run=g.execute(args,cwd,P/(name+'-build'),lambda:False,stable,timeout=300,limit=8<<20);d['commands'].append({'name':name,'run':run})
  assert run['exit_code']==0 and run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
  print(json.dumps({'name':name,'seconds':run['seconds'],'exit_code':run['exit_code']}),flush=True)
  metadata=g.execute(prefix+['version','-m','-json',str(P/('automation'if name=='client'else'workbench'))],T,P/(name+'-metadata'),lambda:False,stable,timeout=20,limit=1<<20)
  assert metadata['exit_code']==0 and metadata['error']is None and metadata['logs_complete']and metadata['pins_stable']and metadata['owned']['terminal']and metadata['owned']['group_absent']and not metadata['owned']['errors']and not metadata['observation_errors']
  d['commands'][-1]['metadata']=metadata
  details=read(P/(name+'-metadata')/'stdout');settings={v['Key']:v['Value']for v in details['Settings']};assert settings['vcs.revision']==HEAD and settings['vcs.modified']=='false'
 d.update(result='PASS_CLEAN_COMMITTED_COMPILE_ONLY',binaries={n:{'path':str(P/n),'bytes':(P/n).stat().st_size,'sha256':g.sha(P/n)}for n in ['automation','workbench']})
 (P/'native').mkdir(mode=0o700)
 plan={'source_commit':HEAD,'root':str(P),'native_root':str(P/'native'),'cases':[100000,1000000],'binaries':d['binaries'],'source_pins':files,'prepared_pins':prepared,'physical_input_generated':False,'settings_changes':False,'raw_native_streams_retained':False,'full_macos_qualified':False}
 with(W/'native-plan.json').open('x')as f:f.write(json.dumps(plan,indent=2)+'\n')
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(P/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
