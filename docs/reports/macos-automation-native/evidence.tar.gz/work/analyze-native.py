"""Reconcile retained scalar assertions/ownership metadata; no raw DTO claim."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('api_native_reconcile',W/'native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
plan=read(W/'native-plan.json');P=Path(plan['root']);R=Path(plan['native_root']);r=read(R/'receipt.json');review=read(W/'native-readiness.json')
assert r['result']=='PASS_NATIVE_SEMANTIC_CLIENT_ASSERTIONS'and r['error']is None and not r['finalization_errors']and r['lease_held_through_cleanup']and r['local_stop_present']and(R/'stop-live').is_file()
assert r['producer_sha256']==sha(W/'native.py')and r['review_sha256']==sha(W/'native-readiness.json')and all(sha(p)==h for p,h in review['inputs'].items())
assert r['native_runtime_executed']is True and r['controller_executed']is True and not any(r[k]for k in ['physical_input_generated','settings_changes','raw_native_streams_retained','saved_per_call_DTOs','full_macos_qualified'])
assert read(P/'receipt.json')['result']=='PASS_CLEAN_COMMITTED_COMPILE_ONLY'
assert len(r['cases'])==2 and [v['rows']for v in r['cases']]==plan['cases']==[100000,1000000]
cases=[]
for case in r['cases']:
 rows=case['rows'];run=case['run'];O=R/('case-'+str(rows));owned=read(O/'owned.json')
 assert run['argv']==[plan['binaries']['automation']['path'],'-workbench',plan['binaries']['workbench']['path'],'-rows='+str(rows)]
 assert run['created']and run['exit_code']==0 and run['error']is None and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']
 assert owned['pid']==owned['group']==run['pid']==run['group']==run['owned']['pid']
 assert run['owned']['observation']['group']==run['pid']and run['owned']['observation']['members']==[]
 for stream in ['stdout','stderr']:
  actual=run['logs'][stream]
  assert (O/stream).stat().st_size==actual['bytes']and sha(O/stream)==actual['sha256']
 summary=n.validate((O/'stdout').read_bytes(),(O/'stderr').read_bytes(),rows);assert summary==case['checked_summary']
 # Re-observe only this recorded owned group; never signal it here.
 absence=n.g.absent(run['pid'])
 cases.append({'rows':rows,'requests':summary['requests'],'summary':summary,'controller_group':run['pid'],'seconds':run['seconds'],'terminal_group_absent':True,'reobserved_group_absent':absence,'controller_stdout_sha256':sha(O/'stdout'),'controller_stderr_sha256':sha(O/'stderr')})
for root in [n.T,n.C]:assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==plan['source_commit']and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20)
d={'result':'RECONCILED_NATIVE_SEMANTIC_CLIENT_ASSERTIONS','source_commit':plan['source_commit'],'native_cases':2,'semantic_requests':80,'cases':cases,'binaries':plan['binaries'],'native_receipt_sha256':sha(R/'receipt.json'),'readiness_sha256':sha(W/'native-readiness.json'),'raw_native_streams_retained':False,'saved_per_call_DTOs':False,'physical_input_generated':False,'settings_changes':False,'full_macos_qualified':False,'native_parser_finalization_controls':23,'producer_sha256':sha(__file__),'evidence_scope':'Source-reviewed client assertions/scalar summaries; raw per-call DTOs and native streams are intentionally discarded.'}
with(W/'native-analysis.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items()if k not in ['cases','binaries']}))
