from pathlib import Path
import datetime,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-native-automation-production-bde5922')
spec=importlib.util.spec_from_file_location('native_api_production_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
a=json.loads((W/'adoption.json').read_bytes());assert a['result']=='INTERNALLY_REVIEWED_SOURCE_INSTALLED'and all(g.sha(T/p)==h for p,h in a['sources'].items())
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=T,timeout=20).decode().split('\0')[:-1];source={str(T/n):g.sha(T/n)for n in sorted(set(names))};assert len(source)==4700
prepared={str(p):g.sha(p)for name in['upstream','typesetting']for p in(T/'drivers/cogent/build'/name).rglob('*')if p.is_file()};assert len(prepared)==6249
P.mkdir(mode=0o700);(P/'source.json').write_text(json.dumps(source,indent=2)+'\n');(P/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
pins={**source,**prepared,str(Path(__file__).resolve()):g.sha(__file__),str(W/'adoption.json'):g.sha(W/'adoption.json')};stable=lambda:all(g.sha(p)==h for p,h in pins.items())
prefix=['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go']
commands=[('workbench-race',T/'drivers/cogent',prefix+['test','-tags','offscreen','-race','-count=1','-timeout=3m','./cmd/workbench'],240),('workbench-vet',T/'drivers/cogent',prefix+['vet','-tags','offscreen','./cmd/workbench'],90),('public-api-race',T,prefix+['test','-race','-count=1','-timeout=2m','./automation'],180),('consumer-race',T/'examples/automation',prefix+['test','-race','-count=1','-timeout=1m','./...'],120),('consumer-vet',T/'examples/automation',prefix+['vet','./...'],90),('consumer-build',T/'examples/automation',prefix+['build','-trimpath','-o',str(P/'automation'),'.'],90),('native-compile-only',T/'drivers/cogent',prefix+['build','-p=1','-trimpath','-o',str(P/'workbench'),'./cmd/workbench'],300),('example-suite-syntax',T,['/bin/sh','-n',str(T/'scripts/check-example.sh')],20)]
d={'result':'INCOMPLETE','native_runtime_executed':False,'commands':[],'error':None,'source_files':len(source),'prepared_files':len(prepared)}
try:
 for name,cwd,args,timeout in commands:
  run=g.execute(args,cwd,P/name,lambda:False,stable,timeout=timeout,limit=8<<20);d['commands'].append({'name':name,'run':run});print(json.dumps({'name':name,'exit_code':run['exit_code'],'seconds':run['seconds'],'error':run['error']}),flush=True)
  assert run['exit_code']==0 and run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
 d.update(result='PASS_EXACT_INSTALLED_NON_NATIVE_CHECKS',binaries={name:{'path':str(P/name),'bytes':(P/name).stat().st_size,'sha256':g.sha(P/name)}for name in ['automation','workbench']})
except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(P/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
