"""Pure parser controls; this file never dispatches native applications."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('native_api_summary_controls',W/'native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
results=[]
def check(name,data,stderr=b'',rows=100000,accept=False):
 refused=False
 try:n.validate(data,stderr,rows)
 except ValueError:refused=True
 assert refused!=accept,name
 results.append({'name':name,'expected_accept':accept,'pass':True})
value={'status':'PASS','rows':100000,'requests':40,'native_ready':True,'transport_joined':True,'endpoint_removed':True,'post_close_refused':True,'raw_native_output_published':False}
encode=lambda obj:json.dumps(obj,separators=(',',':')).encode()+b'\n'
check('canonical-100k',encode(value),accept=True)
other={**value,'rows':1000000};check('canonical-million',encode(other),rows=1000000,accept=True)
for key,bad in [('status','FAIL'),('rows',1000000),('requests',39),('native_ready',False),('transport_joined',False),('endpoint_removed',False),('post_close_refused',False),('raw_native_output_published',True)]:check('wrong-'+key,encode({**value,key:bad}))
check('missing-record',b'')
check('extra-record',encode(value)*2)
check('extra-field',encode({**value,'token':'private'}))
check('duplicate-key',encode(value).replace(b'{',b'{"status":"FAIL",',1))
check('stderr-present',encode(value),b'failure')
check('missing-terminal-newline',encode(value).rstrip())
check('trailing-native-output',encode(value)+b'native-data\n')
d={'result':'PASS_PURE_NATIVE_SUMMARY_CONTROLS','native_runtime_executed':False,'controls':results,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'native_producer_sha256':hashlib.sha256((W/'native.py').read_bytes()).hexdigest()}
with(W/'native-controls.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'count':len(results)}))
