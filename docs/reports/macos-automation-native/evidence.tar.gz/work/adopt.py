from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'adoption.json').exists()
r=json.loads((W/'adoption-review.json').read_bytes());plan=json.loads((W/'adoption-plan.json').read_bytes())
assert r['adoption_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
for root in [T,C]:
 assert git(root,'rev-parse','HEAD').decode().strip()==plan['base_commit']and not git(root,'status','--porcelain','-z')
 for p,h in plan['originals'].items():assert (sha(root/p)if(root/p).exists()else None)==h
for p,h in plan['drafts'].items():assert sha(W/p)==h
for p,source in plan['files'].items():
 (T/p).parent.mkdir(parents=True,exist_ok=True);(T/p).write_bytes((W/source).read_bytes())
for p,source in plan['append'].items():(T/p).write_text((T/p).read_text().rstrip()+'\n'+(W/source).read_text())
paths=sorted(plan['originals']);changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==set(paths)
assert not git(C,'status','--porcelain','-z')
d={'result':'INTERNALLY_REVIEWED_SOURCE_INSTALLED','base_commit':plan['base_commit'],'sources':{p:sha(T/p)for p in paths},'native_runtime_executed':False,'adoption_review_sha256':sha(W/'adoption-review.json')}
with(W/'adoption.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
