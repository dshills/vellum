"""Two source-reviewed native semantic campaigns, without raw child UI output."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');STOP=Path('/private/tmp/vellum-macos-same-name-live-ddd23c6/stop-live')
spec=importlib.util.spec_from_file_location('native_api_live_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,message):
 if not ok:raise ValueError(message)
def validate(stdout,stderr,rows):
 need(not stderr,'controller stderr empty')
 expected={'status':'PASS','rows':rows,'requests':40,'native_ready':True,'transport_joined':True,'endpoint_removed':True,'post_close_refused':True,'raw_native_output_published':False}
 # Round-trip canonical encoding additionally refuses duplicate or unknown fields.
 need(stdout==json.dumps(expected,separators=(',',':')).encode()+b'\n','exact safe controller summary')
 return expected

def main():
 need(len(sys.argv)==1,'no native runtime overrides')
 review=read(W/'native-readiness.json');need(review['execution_ready']and not review['unresolved_findings'],'native readiness review')
 plan=read(W/'native-plan.json');R=Path(plan['native_root']);P=Path(plan['root']);HEAD=plan['source_commit']
 need(not any((R/n).exists()for n in ['receipt.json','stop-live','case-100000','case-1000000']),'fresh native root')
 pins=review['inputs'];stable=lambda:all(g.sha(p)==h for p,h in pins.items());stopping=lambda:STOP.exists()or(R/'stop-live').exists()
 def clean():
  for root in [T,C]:
   need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20),'clean committed native source')
  need(all(g.sha(p)==h for p,h in {**plan['source_pins'],**plan['prepared_pins']}.items()),'complete source/prepared parity')
  for binary in plan['binaries'].values():need(g.sha(binary['path'])==binary['sha256']and Path(binary['path']).stat().st_size==binary['bytes'],'clean executable identity')
 need(stable()and not stopping(),'initial admission')
 d={'result':'INCOMPLETE','source_commit':HEAD,'producer_sha256':g.sha(__file__),'review_sha256':g.sha(W/'native-readiness.json'),'native_runtime_executed':False,'native_execution_status':'not_attempted','controller_executed':False,'physical_input_generated':False,'settings_changes':False,'raw_native_streams_retained':False,'saved_per_call_DTOs':False,'evidence_scope':'Source-reviewed client assertions and scalar summary, not retained raw DTO replay','full_macos_qualified':False,'cases':[],'error':None}
 try:
  with g.LiveLease()as lease:
   need(lease.held()and stable()and not stopping(),'lease admission');clean()
   for rows in plan['cases']:
    need(lease.held()and stable()and not stopping(),'per-case admission');clean()
    run=g.execute([plan['binaries']['automation']['path'],'-workbench',plan['binaries']['workbench']['path'],'-rows='+str(rows)],T/'examples/automation',R/('case-'+str(rows)),stopping,stable,timeout=60,limit=1<<20)
    d['cases'].append({'rows':rows,'run':run});d['controller_executed']|=run['created']
    if run['created']:
     d['native_runtime_executed']=None;d['native_execution_status']='unknown_may_have_executed_after_controller_start'
    need(run['created']and run['error']is None and run['exit_code']==0 and not run['observation_errors']and run['logs_complete']and run['pins_stable']and not run['stop_at_exit']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors'],'native controller/owned-group terminal proof')
    record=validate((R/('case-'+str(rows))/'stdout').read_bytes(),(R/('case-'+str(rows))/'stderr').read_bytes(),rows);d['cases'][-1]['checked_summary']=record;d['native_runtime_executed']=True;d['native_execution_status']='confirmed_by_source_reviewed_client_ready_assertion'
    clean();need(stable()and not stopping(),'per-case terminal stability')
    print(json.dumps({'rows':rows,'status':'PASS','requests':40,'seconds':run['seconds']}),flush=True)
   clean();need(stable()and not stopping()and lease.held(),'terminal source/stops/lease');d['lease_held_through_cleanup']=True
 except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)}
 finally:
  finalize(R,d)
 need(d['error']is None and not d['finalization_errors'],'native campaign failed or canceled')
def finalize(root,d,seal=None,write=None,report=None):
 """Attempt every finalization step; one failure cannot hide the others."""
 d['finalization_errors']=[]
 def status():
  d['result']='PASS_NATIVE_SEMANTIC_CLIENT_ASSERTIONS'if d['error']is None and not d['finalization_errors']else'FAILED_OR_CANCELED_NATIVE_SEMANTIC_CLIENT'
 def failed(stage,error):
  d['finalization_errors'].append({'stage':stage,'type':type(error).__name__});status()
 def write_receipt():
  with(root/'receipt.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
 try:
  (seal or (lambda:(root/'stop-live').touch()))();d['local_stop_present']=True
 except BaseException as e:failed('local-seal',e)
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();status()
 def terminal_report():
  payload={k:v for k,v in d.items()if k!='cases'}
  payload['result']='PENDING_EXCLUSIVE_RECEIPT'
  print(json.dumps(payload),flush=True)
 # Report before the exclusive final receipt. A reporting failure therefore
 # enters the saved outcome. Reporting itself never asserts final success.
 try:(report or terminal_report)()
 except BaseException as e:failed('terminal-report',e)
 try:(write or write_receipt)()
 except BaseException as e:failed('exclusive-receipt',e)
 return d
if __name__=='__main__':main()
