from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');O=W/'prototype-checks-v4'
spec=importlib.util.spec_from_file_location('native_api_prototype_guard',W.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
assert not O.exists();O.mkdir(mode=0o700)
files=[p for p in(W/'prototype').rglob('*')if p.is_file()]+[p for n in['app','automation','command','ui']for p in(T/n).rglob('*.go')]+[T/'go.mod',Path(__file__).resolve()]
pins={str(p):g.sha(p)for p in files};(O/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');stable=lambda:all(g.sha(p)==h for p,h in pins.items())
commands=[('race',['test','-race','-count=1','-timeout=60s','./...'],120),('vet',['vet','./...'],60),('build',['build','-trimpath','-o',str(O/'automation'),'.'],90)]
d={'result':'INCOMPLETE','commands':[],'native_runtime_executed':False}
try:
 for name,args,timeout in commands:
  run=g.execute(['/usr/bin/env','GOPROXY=off','GOSUMDB=off','/opt/homebrew/bin/go',*args],W/'prototype',O/name,lambda:False,stable,timeout=timeout,limit=4<<20)
  d['commands'].append({'name':name,'run':run});print(json.dumps({'name':name,'exit_code':run['exit_code'],'seconds':run['seconds'],'error':run['error']}),flush=True)
  assert run['exit_code']==0 and run['error']is None and run['logs_complete']and run['pins_stable']and run['owned']['terminal']and run['owned']['group_absent']and not run['owned']['errors']and not run['observation_errors']
 d['result']='PASS_ISOLATED_NON_NATIVE_PROTOTYPE'
finally:
 d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
