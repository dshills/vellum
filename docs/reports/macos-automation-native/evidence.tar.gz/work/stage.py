from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');P=Path('/private/tmp/vellum-native-automation-production-bde5922')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
assert not(W/'binding.json').exists()
a=read(W/'adoption.json');r=read(P/'receipt.json');assert r['result']=='PASS_EXACT_INSTALLED_NON_NATIVE_CHECKS'and r['error']is None and len(r['commands'])==8 and not r['native_runtime_executed']
for x in r['commands']:
 v=x['run'];assert v['exit_code']==0 and v['error']is None and v['logs_complete']and v['pins_stable']and v['owned']['terminal']and v['owned']['group_absent']and not v['owned']['errors']and not v['observation_errors']
for n in ['source.json','prepared.json']:assert all(sha(p)==h for p,h in read(P/n).items())
assert git(T,'rev-parse','HEAD').decode().strip()==a['base_commit']==git(C,'rev-parse','HEAD').decode().strip()
assert not git(C,'status','--porcelain','-z')and not git(T,'diff','--cached','--name-only')
expected=set(a['sources']);changed=set(git(T,'diff','--name-only').decode().splitlines())|set(git(T,'ls-files','--others','--exclude-standard').decode().splitlines());assert changed==expected
assert all(sha(T/p)==h for p,h in a['sources'].items())
git(T,'add','--',*sorted(expected));git(T,'diff','--cached','--check')
assert not git(T,'diff','--name-only')and not git(T,'ls-files','--others','--exclude-standard')and set(git(T,'diff','--cached','--name-only').decode().splitlines())==expected
payload=git(T,'diff','--cached','--binary');assert 0<len(payload)<80000
(W/'staged.diff').write_bytes(payload)
d={'base_commit':a['base_commit'],'sources':a['sources'],'source_files':4700,'prepared_files':6249,'staged_diff_sha256':sha(W/'staged.diff'),'staged_diff_bytes':len(payload),'production_receipt_sha256':sha(P/'receipt.json'),'native_runtime_executed':False}
with(W/'binding.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
