"""Preserve source-checkpoint evidence; executables are fingerprinted, not copied."""
from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;P=Path('/private/tmp/vellum-native-automation-production-bde5922')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
c=json.loads((W/'commit-receipt.json').read_bytes());assert c['result']=='REVIEWED_SOURCE_COMMITTED_AND_CANONICAL_INTEGRATED'and c['both_clean']
O=W/('checkpoint-'+c['commit'][:7]);O.mkdir(mode=0o700);omitted=[]
for label,root in [('work',W),('production',P)]:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if root==W and (rel.parts[0].startswith('checkpoint-')or rel.as_posix()=='checkpoint.json'):continue
  assert not p.is_symlink()
  if not p.is_file():continue
  if p.name in ['automation','workbench']:
   omitted.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)});continue
  target=O/label/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);assert sha(target)==sha(p)
manifest={p.relative_to(O).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(O.rglob('*'))if p.is_file()}
(O/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
d={'commit':c['commit'],'path':str(O),'manifest_sha256':sha(O/'MANIFEST.json'),'files':len(manifest),'bytes':sum(v['bytes']for v in manifest.values()),'executables_omitted':omitted}
with(W/'checkpoint.json').open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
