"""Add frozen imported helpers/control provenance; preserve the incomplete v1."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
W=Path(__file__).resolve().parent;S=W.parent/'macos-workbench-native-automation';T=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
for name in ['evidence.tar.gz','evidence.manifest.json','result.json','draft-binding.json','binding.json','staged.diff']:
 source=W/name;backup=W/(name+'.v1-incomplete');
 if backup.exists():assert backup.read_bytes()==source.read_bytes()
 else:backup.write_bytes(source.read_bytes())
b=read(W/'draft-binding.json');D=Path(b['draft_root']);report='docs/reports/macos-automation-native';files={}
with tarfile.open(W/'evidence.tar.gz','r:gz')as archive:
 for m in archive:
  assert m.isfile();files[m.name]=archive.extractfile(m).read()
proofs=[read(S/n)['inputs']for n in ['native-readiness.json','result-review.json','final-review.json','preprism-review.json']];known={}
for proof in proofs:
 for p,h in proof.items():
  known.setdefault(p,h)
origins={}
def add(path,member,role):
 p=Path(path);assert p.is_file()and not p.is_symlink()and str(p)in known and sha(p)==known[str(p)],str(p)
 assert all(proof[str(p)]==known[str(p)]for proof in proofs if str(p)in proof)
 files[member]=p.read_bytes();origins[str(p)]={'member':member,'sha256':sha(p),'bytes':p.stat().st_size,'role':role}
helpers={
 W.parent/'macos-sdk-native-238b3b6/run.py':'executor/run.py',
 Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py'):'executor/live_lease.py',
 T/'scripts/child_process.py':'scripts/child_process.py',
 T/'scripts/child_process_test.py':'scripts/child_process_test.py',
 T/'scripts/sdk_environment.py':'scripts/sdk_environment.py',
 W.parent/'macos-grid-native-stacks/commit-pending.py':'git/commit-pending.py',
 Path('/private/tmp/vellum-native-attestation-probe-20261016/run-verifier.py'):'prism/run-verifier.py'}
for p,name in helpers.items():add(p,'provenance/helpers/'+name,'imported owned-execution/lifecycle/Git/provider helper')
prefixes={str(W.parent/'macos-sdk-native-238b3b6')+'/':'provenance/helper-controls/work/', '/private/tmp/vellum-sdk-native-238b3b6/':'provenance/helper-controls/raw/'}
for p in read(S/'native-readiness.json')['inputs']:
 for prefix,dest in prefixes.items():
  if p.startswith(prefix):add(p,dest+p[len(prefix):],'historical non-native controls for byte-equivalent executor/retirement functions')
host={p:{'sha256':h,'bytes':Path(p).stat().st_size}for p,h in known.items()if p in ['/bin/ps','/opt/homebrew/Cellar/git/2.56.0_1/bin/git','/opt/homebrew/Cellar/python@3.15/3.15.0/Frameworks/Python.framework/Versions/3.15/bin/python3.15','/Users/dshills/Development/Go/bin/prism']}
files['provenance/origins.json']=(json.dumps({'retained_sources_and_control_records':origins,'host_executables_fingerprinted_not_bundled':host},indent=2)+'\n').encode()
files['report/fix-closure.py']=Path(__file__).read_bytes()
p=W/'README.template.md';text=p.read_text().replace('''source/prepared/binary/review pins remain
stable, both checkouts remain clean, and the native root is sealed afterward.''','''source/prepared/binary/review pins matched and both checkouts were clean at the
recorded admission and terminal snapshots. The native root is sealed afterward.''')
# Exact existing wrapping differs only at this sentence; require the correction.
if 'both checkouts remain clean' in text:
 text=text.replace('''source/prepared/binary/review pins remain
stable, both checkouts remain clean, and the native root is sealed afterward.''','''source/prepared/binary/review pins matched and both checkouts were clean at the
recorded admission and terminal snapshots. The native root is sealed afterward.''')
assert 'both checkouts remain clean'not in text
needle='and [retained evidence](evidence.tar.gz).';assert needle in text;text=text.replace(needle,needle+''' Imported executor, lease,
process/environment, Git and Prism-retirement helper bytes and their historical
non-native controls are retained under `provenance/`; the origin index binds each
original path/hash to its archive member. Host executables are fingerprinted and
omitted. These historical helper controls are not additional native executions.''')
p.write_text(text);(D/(report+'/README.md')).write_text(text);files['report/current-README.md']=text.encode()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(files.items())}
with(W/'evidence.tar.gz').open('wb')as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0)as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT)as archive:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
(W/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(W/'evidence.tar.gz','r:gz')as archive:
 assert [m.name for m in archive]==sorted(manifest)
 for m in archive:
  assert m.isfile();data=archive.extractfile(m).read();assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
result=read(W/'result.json');result['evidence_archive']={'bytes':(W/'evidence.tar.gz').stat().st_size,'sha256':sha(W/'evidence.tar.gz'),'members':len(manifest),'expanded_bytes':sum(v['bytes']for v in manifest.values())};result['imported_provenance_records']=len(origins);result['supersedes_incomplete_archive_sha256']=sha(W/'evidence.tar.gz.v1-incomplete');(W/'result.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['result.json','evidence.manifest.json','evidence.tar.gz']:(D/(report+'/'+name)).write_bytes((W/name).read_bytes())
b['sources']={p:sha(D/p)for p in b['sources']};(W/'draft-binding.json').write_text(json.dumps(b,indent=2)+'\n')
print(json.dumps({'result':'IMPORTED_HELPER_AND_CONTROL_CLOSURE_ADDED','origins':len(origins),'archive':result['evidence_archive']}))
