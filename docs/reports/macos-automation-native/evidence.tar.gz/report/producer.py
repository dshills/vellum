"""Prepare source-bound native semantic evidence and seven documentation leaves."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
W=Path(__file__).resolve().parent;S=W.parent/'macos-workbench-native-automation';T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='781f847a2d43033d3869d7fdd2f6713656b8a803';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
r=read(S/'result-review.json');assert r['results_ready']and not r['unresolved_findings']and all(sha(p)==h for p,h in r['inputs'].items())
for root in[T,C]:assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=20).decode().strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=20)
plan=read(S/'native-plan.json');P=Path(plan['root']);PROD=Path('/private/tmp/vellum-native-automation-production-bde5922')
files={};omitted=[]
for label,root in [('work',S),('production',PROD),('clean',P)]:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if root==S and rel.parts[0].startswith('checkpoint-'):continue
  assert not p.is_symlink()
  if not p.is_file():continue
  if p.name in ['automation','workbench']:
   omitted.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)});continue
  files[label+'/'+rel.as_posix()]=p.read_bytes()
files['report/producer.py']=Path(__file__).read_bytes();files['report/README.template.md']=(W/'README.template.md').read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(files.items())}
with(W/'evidence.tar.gz').open('xb')as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0)as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT)as archive:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
(W/'evidence.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(W/'evidence.tar.gz','r:gz')as archive:
 assert [m.name for m in archive]==sorted(manifest)
 for m in archive:
  assert m.isfile();data=archive.extractfile(m).read();assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
analysis=read(S/'native-analysis.json');result={**analysis,'evidence_archive':{'bytes':(W/'evidence.tar.gz').stat().st_size,'sha256':sha(W/'evidence.tar.gz'),'members':len(manifest),'expanded_bytes':sum(x['bytes']for x in manifest.values())},'result_review_sha256':sha(S/'result-review.json'),'implementation_commit':HEAD,'prism_calls':1,'prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_complete':True,'prism_findings':0,'evidence_checkpoint_provider_calls':0,'executables_omitted':omitted,'source_files':4700,'prepared_files':6249}
(W/'result.json').write_text(json.dumps(result,indent=2)+'\n')
report='docs/reports/macos-automation-native';dest=W/'draft';dest.mkdir(mode=0o700)
new={report+'/README.md':(W/'README.template.md').read_bytes(),report+'/result.json':(W/'result.json').read_bytes(),report+'/evidence.manifest.json':(W/'evidence.manifest.json').read_bytes(),report+'/evidence.tar.gz':(W/'evidence.tar.gz').read_bytes()}
p='docs/implementation.md';old=(T/p).read_text();needle='''example check suite. Native execution results will be recorded separately; these
source changes alone do not qualify physical input, AX, presentation, frame,
memory, endurance, release or full macOS acceptance.''';assert needle in old;new[p]=old.replace(needle,'''example check suite. The [native campaign](reports/macos-automation-native/README.md)
passes 40 semantic requests each at 100k and one million actual records from clean
781f847. Evidence is the source-reviewed client assertions and saved scalar
summaries; raw per-call DTOs/native streams are deliberately discarded. Both
workbenches exit normally and their inherited owned groups are observed absent.
Physical input, AX, presentation, frame, memory, endurance, release and full macOS
acceptance remain open.''').encode()
p='specs/macos-completion.md';old=(T/p).read_text();needle='''inspection and a narrow shared-domain action allowlist. Headless transport/domain
checks are separate from a live professional automation campaign.''';assert needle in old;new[p]=old.replace(needle,'''inspection and a narrow shared-domain action allowlist. The
[native public-Go client campaign](../docs/reports/macos-automation-native/README.md)
passes two 40-request cases at 100k/million rows on clean 781f847, with native
window/nonempty snapshot readiness, command/history and revision checks, normal
closure, socket removal and inherited owned-group absence. This is source-reviewed
semantic assertions plus retained scalar summaries, with raw native streams/DTOs
discarded. Physical input, AX, GPU execution/presentation, frame/memory/endurance
and full professional automation workflows remain separate.''').encode()
p='docs/reports/README.md';old=(T/p).read_text();needle='The [implementation status](../implementation.md) describes the current framework.\n';assert needle in old;new[p]=old.replace(needle,needle+'\n- [Native workbench external semantic automation](macos-automation-native/README.md)\n',1).encode()
assert len(new)==7
for p,data in new.items():target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
binding={'base_commit':HEAD,'sources':{p:hashlib.sha256(data).hexdigest()for p,data in new.items()},'draft_root':str(dest),'old':{p:sha(T/p)if(T/p).exists()else None for p in new},'source_files_after':4704,'prepared_files':6249,'native_runtime_sources_unchanged':True,'provider_calls':0,'result_review_sha256':sha(S/'result-review.json')}
(W/'draft-binding.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({'result':'PREPARED_NATIVE_SEMANTIC_EVIDENCE_DRAFT','leaves':len(new),'archive':result['evidence_archive']}))
