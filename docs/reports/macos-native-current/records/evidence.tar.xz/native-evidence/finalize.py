from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-native-evidence');P=Path('/private/tmp/vellum-macos-native-evidence');E=Path('/private/tmp/vellum-macos-current-endurance');S=Path('/private/tmp/vellum-macos-span-scratch-native');G=Path('/private/tmp/vellum-macos-geometry-native')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines())
assert len(names)==4 and all(n.endswith('.md')for n in names);sources={n:sha(R/n)for n in sorted(names)}
reviews={}
for key,root,result in [('endurance',E,'APPROVED_SCOPED_NATIVE_RETENTION_EVIDENCE'),('span_scratch',S,'APPROVED_SCOPED_NATIVE_COMPARISON_EVIDENCE'),('geometry',G,'APPROVED_SCOPED_NATIVE_COMPARISON_EVIDENCE')]:
 f=root/'evidence-review.json';d=json.loads(f.read_text());assert d['result']==result and not d['unresolved_findings'];reviews[key]={'path':str(f),'sha256':sha(f),'result':result}
end=json.loads((E/'retention-summary.json').read_text());assert end['result']=='PASS_1000_INTERACTING_COMPOSED_CYCLES'and end['cycles']==1000 and end['actions']==24000 and end['steps_with_retries']==60 and end['prepared_files']==6214
for stage in ['interacting-1000','retention-validation']:
 d=json.loads((E/(stage+'.controller.json')).read_text());assert d['exit_code']==0 and d['error']is None and d['owned_group_retired']and d['producer_sha256']==sha(E/'campaign.py')
 for ch in ['stdout','stderr']:assert d[ch+'_sha256']==sha(E/(stage+'.controller.'+ch))
assert end['heap_profile_sha256']==sha(E/'final.heap')and end['heap_profile_bytes']==(E/'final.heap').stat().st_size==450135
clean=end['native_cleanup'];assert clean['MainThread']and clean['CleanupObserved']and clean['CallbacksStopped']and clean['NativeOutstanding']==clean['AccessibilityWindows']==clean['PendingCallbacks']==0 and not clean['WindowTitles']and not clean['Menu']['Owned']and not clean['Menu']['OriginalRestored']
comparisons={}
for key,root,processes,samples,endpoint in [('span_scratch',S,40,4800,'87e7de154b96732cad5dcb67703087115909c6f2'),('geometry',G,80,9600,'8c1709e3ecc7a1a787cc5530df966155203f0053')]:
 terminal=json.loads((root/'native-queue.json').read_text());q=json.loads((root/'native-summary.json').read_text());assert terminal['exit_code']==0 and terminal['error']is None and q['processes']==processes and q['ordinary_samples']==samples and q['endpoint_commit']==endpoint
 assert terminal['producer_sha256']==sha(root/'launch.py')and terminal['queue_producer_sha256']==q['producer_sha256']==sha(root/'compare.py')and terminal['inputs_sha256']==q['inputs_sha256']==sha(root/'inputs.json')
 for ch in ['stdout','stderr']:assert terminal[ch+'_sha256']==sha(root/('native-queue.'+ch))
 assert q['summary_sha256']==sha(root/'native-comparison/summary.json')and len(json.loads((root/'native-comparison/progress.json').read_text()))==processes
 s=json.loads((root/'native-comparison/summary.json').read_text());timings={};p95_passes=p99_passes=both_passes=0
 for mode,versions in s.items():
  timings[mode]={}
  for case in versions['original']:
   timings[mode][case]={}
   for version in ['original','candidate']:
    v=versions[version][case];u=v['timings_ns']['ui_work_ns'];assert u['pooled']['count']==600 and len(u['per_run'])==5
    p95_passes+=sum(x['p95']<=4000000 for x in u['per_run']);p99_passes+=sum(x['p99']<=6000000 for x in u['per_run']);both_passes+=sum(x['p95']<=4000000 and x['p99']<=6000000 for x in u['per_run'])
    timings[mode][case][version]={'p95_ns':u['pooled']['p95'],'p99_ns':u['pooled']['p99'],'alloc_p50':v['go_process_alloc_bytes']['p50'],'malloc_p50':v['go_process_mallocs']['p50']}
 assert p95_passes==both_passes==0 and p99_passes==(2 if key=='geometry'else 0)
 comparisons[key]={'endpoint':endpoint,'processes':processes,'ordinary_samples':samples,'terminal_sha256':sha(root/'native-queue.json'),'summary_sha256':sha(root/'native-summary.json'),'pooled_summary_sha256':sha(root/'native-comparison/summary.json'),'timings':timings,'p95_passing_runs':p95_passes,'p99_passing_runs':p99_passes,'both_targets_passing_runs':both_passes}
prep=json.loads((P/'prepare.json').read_text());assert prep['exit_code']==0 and not prep['error']and prep['source_delta_stable']and len(prep['prepared_after'])==6216
prepared={f.relative_to(R/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((R/'drivers/cogent/build'/m).rglob('*'))if f.is_file()};assert prepared==prep['prepared_after']==json.loads((G/'inputs.json').read_text())['endpoint']['prepared']
q={'result':'PASS_SOURCE_BOUND_NATIVE_EVIDENCE_CHECKPOINT','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources,'prepared_count':6216,'prepared_map_sha256':hashlib.sha256(json.dumps(prepared,sort_keys=True).encode()).hexdigest(),'evidence_reviews':reviews,'endurance':{'endpoint':end['base_commit'],'prepared_count':6214,'cycles':1000,'activity_steps':24000,'summary_sha256':sha(E/'retention-summary.json'),'heap_profile_sha256':end['heap_profile_sha256'],'heap_profile_bytes':450135,'profile_before_global_closure':True,'retry_steps':60,'retry_cause_observed':False,'total_attempts':24060,'total_admissions':24060},'comparisons':comparisons,'runtime_source_changed':False,'consistent_native_latency_gain_qualified':False,'full_p4_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False,'native_gpu_memory_budget_qualified':False,'full_mac_qualified':False,'scope':'Report/spec only. Completed e7/6214 retention and distinct87/6216 plus8c/6216 comparisons; noendpointinheritance orfullcompiler/physicalGPU/presentation/human/Mac qualification.'}
(P/'checkpoint-source.json').write_text(json.dumps({'base_commit':q['base_commit'],'sources':sources},indent=2)+'\n');(P/'final-summary.json').write_text(json.dumps(q,indent=2)+'\n');print('PASS four docs, three distinct reviewed native endpoints, both targets passing0; two geometryGPU p99-only passes')
