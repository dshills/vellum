Resolved without source change:2d868019ce83261b is a false positive caused by conflating pooled and per-run percentiles. Raw Prism exit1 and its medium finding remain unchanged.

GPU original variable-million run5 has raw p99=5.891544ms and p95=5.766582ms. GPU candidate fixed-million run3 has raw p99=5.984083ms and p95=5.722373ms. Their pooled600-sample case p99s are6.567291 and6.121502ms. All four values are correct: the pooled tail does not equal the minimum or average of five process tails.

Both runs meet p99 alone and miss p95; none meets both targets. The suggested zero-p99-pass correction would contradict the raw records. The exact four sources, raw provider/process, both raw runs/logs and prior complete evidence review are bound in JSON. No source change, native test or provider rerun occurred.
