"""Ordinary paired opt-in GPU scene frames after owned endurance cleanup."""
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,subprocess,sys,time
R=Path('/private/tmp/vellum-span-scratch');P=Path('/private/tmp/vellum-macos-span-scratch-native');E=Path('/private/tmp/vellum-macos-current-endurance');Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from native_identity import identity,sha

def canceled():return (Q/'stop-live').exists()or(P/'stop-live').exists()
def check_stop():
 if canceled():raise InterruptedError('human returned; stop native comparison')
check_stop();inputs_digest=sha(P/'inputs.json');producer_digest=sha(__file__);inputs=json.loads((P/'inputs.json').read_text());endpoint=inputs['endpoint'];assert endpoint['clean']and len(endpoint['prepared'])==6216
assert sha(P/'native_identity.py')==inputs['identity_helper_sha256']and sha(R/'scripts/benchmark-grid.py')==inputs['benchmark_helper_sha256']and sha(R/'scripts/sdk_environment.py')==inputs['sdk_environment_sha256']
assert sha(R/'docs/reports/macos-span-scratch/records/qualification.json')==inputs['qualification_sha256']
assert all(endpoint['tracked'][n]==h for n,h in inputs['sources'].items())
assert sha(inputs['generated_testdata']['path'])==inputs['generated_testdata']['sha256']
assert json.loads(Path(inputs['generated_testdata']['path']).read_text())==inputs['generated_testdata']['files']
assert sha(inputs['baseline_builder']['path'])==inputs['baseline_builder']['sha256']
assert inputs['baseline_builder']['sha256']==json.loads((R/'drivers/cogent/native/patches/spanscratch/original-hashes.json').read_text())['paint/renderers/sceneplan/builder.go']
bins={mode:Path(x['path'])for mode,x in inputs['binaries'].items()};assert set(bins)=={'original','candidate'}
for mode,selected in inputs['build_receipts'].items():
 f=Path(selected['path']);assert sha(f)==selected['sha256'];d=json.loads(f.read_text())
 assert d['exit_code']==0 and not d['error']and d['source_delta_stable']and d['producer_sha256']==inputs['build_producer_sha256']
 assert d['source_commit']==inputs['baseline_builder']['origin_commit']
 assert d['argv'][:2]==['go','build']and d['argv'][-3:]==['-o',str(bins[mode]),'.']
 for ch in ['stdout','stderr']:assert sha(f.with_suffix('.'+ch))==d[ch+'_sha256']
 # Only the later report and Python test-count correction are not compilation
 # inputs. All remaining changed files and every prepared production/test leaf
 # equal the current committed checkpoint. Generated raster PNGs are artifacts.
 for n,h in inputs['sources'].items():
  if n not in ['docs/reports/macos-span-scratch/README.md','drivers/cogent/prepare_test.py']:assert d['source_delta_before'][n]==d['source_delta_after'][n]==h
 for stamp in ['prepared_before','prepared_after']:
  assert all(d[stamp].get(k)==h for k,h in endpoint['prepared'].items())
  assert all(inputs['generated_testdata']['files'].get(k)==d[stamp][k]for k in set(d[stamp])-set(endpoint['prepared']))
 assert d['overlay_inputs_before']==d['overlay_inputs_after']
 if mode=='original':
  overlay=Path(d['argv'][2].split('=',1)[1]);assert sha(overlay)==inputs['original_overlay_sha256']
  expected={str(R/'drivers/cogent/build/upstream/paint/renderers/sceneplan/builder.go'):inputs['baseline_builder']['path']}
  assert json.loads(overlay.read_text())=={'Replace':expected}
  assert d['overlay_inputs_after']=={str(overlay):sha(overlay),inputs['baseline_builder']['path']:inputs['baseline_builder']['sha256']}
 else:assert not d['overlay_inputs_after']and inputs['binaries'][mode]['sha256']==inputs['candidate_compiled_sha256']
def stable():
 assert sha(P/'inputs.json')==inputs_digest and sha(__file__)==producer_digest,'native queue inputs/producer changed'
 assert identity(R)==endpoint,'frozen comparison source changed'
 assert all(sha(bins[n])==inputs['binaries'][n]['sha256']and bins[n].stat().st_size==inputs['binaries'][n]['bytes']for n in bins)
stable();deadline=time.monotonic()+12000
# A current terminal validation receipt is emitted only after the outer owner
# has killed/reaped its validation group. Native cleanup is separately required.
while not(E/'retention-validation.controller.json').exists():
 check_stop()
 if time.monotonic()>deadline:raise TimeoutError('current endurance terminal validation missing')
 time.sleep(2)
terminal=json.loads((E/'retention-validation.controller.json').read_text());live_terminal=json.loads((E/'interacting-1000.controller.json').read_text());summary=json.loads((E/'retention-summary.json').read_text())
for d in [terminal,live_terminal]:assert d['exit_code']==0 and d['error']is None and d['owned_group_retired']and d['producer_sha256']==sha(E/'campaign.py')
assert summary['result']=='PASS_1000_INTERACTING_COMPOSED_CYCLES'and summary['cycles']==1000 and summary['actions']==24000 and summary['prepared_files']==6214
clean=summary['native_cleanup'];assert clean['MainThread']and clean['CleanupObserved']and clean['CallbacksStopped']and clean['NativeOutstanding']==clean['AccessibilityWindows']==clean['PendingCallbacks']==0 and not clean['WindowTitles']
assert summary['run_receipt_sha256']==sha(E/'interacting-1000.json')and summary['build_receipt_sha256']==sha(E/'build-cycles.json')and summary['heap_profile_sha256']==sha(E/'final.heap')
(P/'predecessor-binding.json').write_text(json.dumps({'terminal_sha256':sha(E/'retention-validation.controller.json'),'live_terminal_sha256':sha(E/'interacting-1000.controller.json'),'summary_sha256':sha(E/'retention-summary.json'),'campaign_producer_sha256':sha(E/'campaign.py')},indent=2)+'\n')
# Serialize against every newer short live-check wrapper. The OS releases this
# lock even if the owned queue dies. Stop/watchdog checks continue during wait.
lock=(Q/'native-live.lock').open('a+')
while True:
 check_stop()
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
 except BlockingIOError:
  if time.monotonic()>deadline:raise TimeoutError('live-test lock watchdog expired')
  time.sleep(.25)
try:
 stable();spec=importlib.util.spec_from_file_location('benchmark',R/'scripts/benchmark-grid.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
 class OwnedSubprocess:
  def __getattr__(self,n):return getattr(subprocess,n)
  def Popen(self,*args,**options):
   assert options.pop('start_new_session')is True
   child=subprocess.Popen(*args,**options)
   try:assert os.getpgid(child.pid)==os.getpgrp()
   except BaseException:
    if child.poll()is None:child.kill()
    child.wait(timeout=5);raise
   return child
 def stop_direct(child):
  if child.poll()is None:child.kill()
 b.subprocess=OwnedSubprocess();b.terminate_owned_group=stop_direct
 factory=b.selectors.DefaultSelector
 class StopAwareSelector:
  def __init__(self):self.inner=factory()
  def register(self,*args,**kwargs):return self.inner.register(*args,**kwargs)
  def select(self,*args,**kwargs):check_stop();return self.inner.select(*args,**kwargs)
  def close(self):return self.inner.close()
 b.selectors.DefaultSelector=StopAwareSelector
 out=P/'native-comparison';out.mkdir(exist_ok=False);results={'gpu':{n:{}for n in bins}};progress=[]
 for variable in [False,True]:
  for rows in [10000,1000000]:
   case=f"{'variable'if variable else 'fixed'}-{rows}"
   for n in bins:results['gpu'][n][case]=[]
   for repetition in range(5):
    for n in (['original','candidate']if repetition%2==0 else ['candidate','original']):
     check_stop();stable();directory=out/'gpu'/n/case/f'run-{repetition+1}'
     samples,process=b.run_case(bins[n],directory,rows,variable,120,128,False,180,gpu_scene_rendering=True)
     assert process['result']=='PASS'and process['exit_code']==0
     assert all(r.get('warmup_guard')==1 for r in process['records'])and process['records'][1]['warmup']==process['records'][1]['warm_callbacks']==128
     stable();results['gpu'][n][case].append(samples);progress.append({'mode':'gpu','version':n,'case':case,'repetition':repetition+1,'result_sha256':sha(directory/'result.json')});(out/'progress.json').write_text(json.dumps(progress,indent=2)+'\n');print(n,case,repetition+1,flush=True)
    left,right=results['gpu']['original'][case][-1],results['gpu']['candidate'][case][-1]
    b.compare_geometry(left,right);assert all(a['geometry']==c['geometry']for a,c in zip(left,right))
 for n in bins:
  for prefix in ['fixed','variable']:
   for small,large in zip(results['gpu'][n][prefix+'-10000'],results['gpu'][n][prefix+'-1000000']):b.compare_geometry(small,large)
 summary={mode:{n:{case:{'timings_ns':b.summarize(runs),'go_process_alloc_bytes':b.distribution([s['go_process_alloc_bytes']for run in runs for s in run]),'go_process_mallocs':b.distribution([s['go_process_mallocs']for run in runs for s in run])}for case,runs in cases.items()}for n,cases in versions.items()}for mode,versions in results.items()}
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 q={'result':'MEASURED_PAIRED_STAGE62_NATIVE_OPT_IN_GPU_FRAMES','processes':40,'ordinary_samples':4800,'endpoint_commit':endpoint['commit'],'original_builder_origin_commit':inputs['baseline_builder']['origin_commit'],'binaries':inputs['binaries'],'inputs_sha256':inputs_digest,'producer_sha256':producer_digest,'warm_targets_ns':{'p95':4000000,'p99':6000000},'warm_target_met':{mode:{n:b.warm_target_met(cases)for n,cases in versions.items()}for mode,versions in summary.items()},'summary_sha256':sha(out/'summary.json'),'full_p6_qualified':False,'full_p11_qualified':False,'scope':'Four ordinary native cases, five interleaved pairs in opt-in GPU scene mode with exact geometry. Same current application; original uses pinned old builder overlay. Mode flags do not certify physical GPU work/presentation, native/GPU memory, physical input or fullP6/P11.'}
 (P/'native-summary.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q),flush=True)
finally:
 fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
