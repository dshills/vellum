"""Own the queued native campaign and clean its entire group on every exit."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
P=Path('/private/tmp/vellum-macos-geometry-native');Q=Path('/private/tmp/vellum-macos-quiet-current');R=Path('/private/tmp/vellum-geometry-reuse')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
review=json.loads((P/'harness-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['unresolved_findings']
for n,h in review['files'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
assert hashlib.sha256((P/'inputs.json').read_bytes()).hexdigest()==review['inputs_sha256']
argv=['python3',str(P/'compare.py')]
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
d={'argv':argv,'producer_sha256':sha(__file__),'queue_producer_sha256':sha(P/'compare.py'),'inputs_sha256':sha(P/'inputs.json'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':7200,'exit_code':None,'error':None};child=None;start=time.monotonic()
try:
 with(P/'native-queue.stdout').open('xb')as so,(P/'native-queue.stderr').open('xb')as se:
  child=subprocess.Popen(argv,cwd=R,env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
  (P/'native-queue.owned-process.json').write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'owner_pid':os.getpid(),'argv':argv,'queue_producer_sha256':d['queue_producer_sha256'],'started_utc':d['started_utc']},indent=2)+'\n')
  while child.poll()is None:
   if(Q/'stop-live').exists():raise InterruptedError('human returned; stop queued native campaign')
   if time.monotonic()-start>7200:raise TimeoutError('native queue watchdog expired')
   time.sleep(.25)
  d['exit_code']=child.returncode
except BaseException as error:d['error']={'type':type(error).__name__,'message':str(error)}
finally:
 # Native/go children inherit this group. Even a normally exited queue may have
 # descendants after an interrupted Go test; retire the owned group always.
 if child is not None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait(timeout=5);d['exit_code']=child.returncode
 d['elapsed_seconds']=time.monotonic()-start
 for c in ['stdout','stderr']:
  f=P/('native-queue.'+c);d[c+'_sha256']=sha(f)if f.exists()else None
 (P/'native-queue.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
sys.exit(0 if d['exit_code']==0 and d['error']is None else 1)
