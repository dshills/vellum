Approved scoped stage62 native comparison evidence; no unresolved findings.

All40 opt-inGPU processes,4800 ordinary samples,128 warm callbacks per process, raw stream/result hashes,20 full-geometry pairs and20 row-count workload comparisons reconcile. Independent nearest-rank recomputation matches every stored timing and process-wide allocation statistic. No tests or native processes were launched by this reviewer.

Every run misses both unchanged4-ms p95 and6-ms p99 targets. UI p95/p99 changes are mixed; variable-million p99 worsens6.532581→6.806500ms (+4.19%). Go allocation-byte medians fall1.00–1.74% and malloc medians3.05–3.07%, without native/GPU-memory attribution or a consistent frame gain. No cause or noise explanation is inferred.

Original is an old-builder-only overlay on the same application, not a pristine baseline. Full endpoint/build vectors and known17-PNG extras are recorded and linked; full source inventories were not rehashed here. Binaries.launched=false is inherited pre-campaign metadata, while40 runtime receipts establish actual launches. The owned controller exits zero and its exact group is separately observed absent by the successor. This is process cleanup, not native resource accounting.

Scope remains87e7de1/6216, GPU opt-in and the stated overlay. DefaultCPU gains, physical GPU/presentation, human input, memory budgets, fullMac/P6/P11 and later geometry endpoints remain unqualified.
