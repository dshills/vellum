"""Current committed composed lifecycle campaign; preflight gates the long run."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-current-endurance');P=Path('/private/tmp/vellum-macos-current-endurance')
Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-current-endurance');O.mkdir(parents=True,exist_ok=True)
assert R.is_dir() and not (Q/'stop-live').exists() and not (P/'stop-live').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
def status(stage,result):
 (O/'status.json').write_text(json.dumps({'stage':stage,'result':result,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'scope':'Current committed framework/6214 prepared leaves. Native composed24-step lifecycle, not fullP6/P11, latency, physicalGPU/native budgets, physicalinput/humanaccessibility or distribution.','producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
def invoke(stage,args,timeout):
 status(stage,'RUNNING')
 with(P/(stage+'.controller.stdout')).open('xb')as so,(P/(stage+'.controller.stderr')).open('xb')as se:
  d=run_child([sys.executable,*args],cwd=P,env=child_environment(runtime=True),stdout=so,stderr=se,timeout=timeout)
 if d.returncode:status(stage,'FAILED');raise SystemExit(d.returncode)
 status(stage,'TERMINAL_PASS')
invoke('build',['run.py','build-cycles','build','drivers/cogent','240','go','build','-tags=vellum_native_checks','-o',str(P/'window-cycle'),'./cmd/window-cycle-smoke'],260)
invoke('preflight',['run_live.py','interacting-preflight','drivers/cogent','180',str(P/'window-cycle'),'-composed','-cycles=5','-sample-every=5','-timeout=2m'],195)
invoke('preflight-validation',['validate_retention.py','preflight'],60)
assert not (Q/'stop-live').exists() and not (P/'stop-live').exists()
invoke('interacting-1000',['run_live.py','interacting-1000','drivers/cogent','11100',str(P/'window-cycle'),'-composed','-cycles=1000','-sample-every=25','-timeout=3h','-heap-profile='+str(P/'final.heap')],11120)
invoke('retention-validation',['validate_retention.py','full'],120)
status('completed','PASS_SCOPED_CURRENT_SOURCE_INTERACTING_RETENTION')
print('PASS current committed1000-window lifecycle; broaderMac qualification remains open',flush=True)
