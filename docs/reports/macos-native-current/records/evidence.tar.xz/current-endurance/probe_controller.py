import json,os,subprocess,sys,time
from pathlib import Path
p=Path(sys.argv[1]);child=subprocess.Popen([sys.executable,str(p.parent/'probe_native.py'),str(p)],start_new_session=False)
(p/'controller.json').write_text(json.dumps({'pid':os.getpid(),'group':os.getpgrp(),'native_pid':child.pid,'native_group':os.getpgid(child.pid)}))
time.sleep(60)
