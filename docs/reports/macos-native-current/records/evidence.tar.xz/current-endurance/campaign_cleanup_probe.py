from pathlib import Path
import ast,hashlib,json,os,signal,subprocess,sys,time
P=Path('/private/tmp/vellum-macos-current-endurance');base=P/'campaign-cleanup-probe';base.mkdir(exist_ok=False)
sys.path.insert(0,'/private/tmp/vellum-tabs-integration/scripts')
from sdk_environment import child_environment
source=(P/'campaign.py').read_text();tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='invoke')
results=[]
for mode in ['normal','failure','timeout']:
 out=base/mode;out.mkdir();stages=[]
 env={'Path':Path,'hashlib':hashlib,'json':json,'os':os,'signal':signal,'subprocess':subprocess,'sys':sys,'time':time,'P':out,'Q':Path('/private/tmp/vellum-macos-quiet-current'),'child_environment':child_environment,'status':lambda stage,result:stages.append((stage,result)),'__file__':str(P/'campaign.py')}
 exec(compile(ast.Module(body=[node],type_ignores=[]),str(P/'campaign.py'),'exec'),env)
 stopped=None
 try:env['invoke'](mode,[str(P/'probe_controller_current.py'),str(out),mode],1)
 except SystemExit as e:stopped=e.code
 c=json.loads((out/'controller.json').read_text());n=json.loads((out/'native.json').read_text());assert c['group']==c['native_group']==n['group']==n['observer_group']
 states={}
 for pid in [c['pid'],n['pid'],n['observer_pid']]:
  for _ in range(40):
   state=subprocess.run(['ps','-p',str(pid),'-o','stat='],capture_output=True,text=True).stdout.strip()
   if not state or state.startswith('Z'):break
   time.sleep(.05)
  states[str(pid)]=state
 assert all(not s or s.startswith('Z')for s in states.values()),states
 receipt=json.loads((out/(mode+'.controller.json')).read_text())
 assert receipt['owned_group_retired'] and receipt['producer_sha256']==hashlib.sha256((P/'campaign.py').read_bytes()).hexdigest()
 if mode=='normal':assert stopped is None and receipt['exit_code']==0 and receipt['error']is None and stages[-1][1]=='TERMINAL_PASS'
 elif mode=='failure':assert stopped==3 and receipt['exit_code']==3 and stages[-1][1]=='FAILED'
 else:assert stopped and receipt['error']['type']=='TimeoutError' and stages[-1][1]=='FAILED'
 results.append({'case':mode,'exit_signal':stopped,'states':states,'receipt':receipt,'stage_results':stages})
(base/'result.json').write_text(json.dumps({'result':'PASS_ACTUAL_CAMPAIGN_INVOKE_GROUP_RETIREMENT','cases':results,'actual_cocoa_or_gui_launched':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'campaign_sha256':hashlib.sha256((P/'campaign.py').read_bytes()).hexdigest(),'method':'Execute unchanged invoke FunctionDef from actual campaign AST with isolated paths and a scalar status sink; inherited-group children simulate native/RSS observer. Three actual normal/failure/timeout process scenarios.'},indent=2)+'\n')
print('PASS actual campaign invoke retires all owned simulated descendants on normal exit, failure and timeout; no GUI')
