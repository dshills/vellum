APPROVED_HARNESS. No unresolved findings.

Four exact final producers are bound. Original24-step/safety/sample/profile validation is unchanged apart from the new6214 endpoint and explicit build→binary link. Exclusive successful build identity is checked immediately before native use and at terminal validation.

Campaign owns the controller group; native/compiler/observer children inherit it. Always killpg/reap handles success, failure, timeout and cancellation, with local/global stop checks. Five-window validation gates the1000-window3h run, bounded by11100s native and11120s controller watchdogs. All failures abort and preserve status.

Parent-run synthetic actual-invoke probes support normal/error/timeout group retirement only; no GUI/Cocoa was used. This reviewer executed no harness/tests/native/provider/Git actions. Approval is for campaign-owned use, not standalone borrowed wrappers; future runtime results and broaderMac/P6/P11/memory/physical/human acceptance remain unqualified.
