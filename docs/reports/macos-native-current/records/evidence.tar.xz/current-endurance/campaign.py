"""Current committed composed lifecycle campaign; preflight gates the long run."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
R=Path('/private/tmp/vellum-current-endurance');P=Path('/private/tmp/vellum-macos-current-endurance')
Q=Path('/private/tmp/vellum-macos-quiet-current')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment
O=Path('/Users/dshills/Documents/ChatGPT/Go Native UI/artifacts/macos-current-endurance');O.mkdir(parents=True,exist_ok=True)
assert R.is_dir() and not (Q/'stop-live').exists() and not (P/'stop-live').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
def status(stage,result):
 (O/'status.json').write_text(json.dumps({'stage':stage,'result':result,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'scope':'Current committed framework/6214 prepared leaves. Native composed24-step lifecycle, not fullP6/P11, latency, physicalGPU/native budgets, physicalinput/humanaccessibility or distribution.','producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
def invoke(stage,args,timeout):
 status(stage,'RUNNING');child=None;started=time.monotonic();code=None;error=None
 try:
  with(P/(stage+'.controller.stdout')).open('xb')as so,(P/(stage+'.controller.stderr')).open('xb')as se:
   child=subprocess.Popen([sys.executable,*args],cwd=P,env=child_environment(runtime=True),stdout=so,stderr=se,start_new_session=True)
   (P/(stage+'.controller-owned.json')).write_text(json.dumps({'pid':child.pid,'process_group':child.pid,'owner_pid':os.getpid(),'argv':[sys.executable,*args]}))
   while child.poll()is None:
    if (Q/'stop-live').exists()or(P/'stop-live').exists():raise InterruptedError('human returned; stop native campaign')
    if time.monotonic()-started>timeout:raise TimeoutError('owned campaign stage watchdog expired')
    time.sleep(.25)
   code=child.returncode
 except BaseException as exc:
  error={'type':type(exc).__name__,'message':str(exc)}
 finally:
  if child is not None:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait(timeout=5);code=child.returncode
  receipt={'argv':[sys.executable,*args],'exit_code':code,'error':error,'elapsed_seconds':time.monotonic()-started,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'owned_group_retired':child is not None}
  for channel in ['stdout','stderr']:
   f=P/(stage+'.controller.'+channel);receipt[channel+'_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()if f.is_file()else None
  (P/(stage+'.controller.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 if code!=0 or error is not None:status(stage,'FAILED');raise SystemExit(code or 125)
 status(stage,'TERMINAL_PASS')
invoke('build',['run.py','build-cycles','build','drivers/cogent','240','go','build','-tags=vellum_native_checks','-o',str(P/'window-cycle'),'./cmd/window-cycle-smoke'],260)
invoke('preflight',['run_live.py','interacting-preflight','drivers/cogent','180',str(P/'window-cycle'),'-composed','-cycles=5','-sample-every=5','-timeout=2m'],195)
invoke('preflight-validation',['validate_retention.py','preflight'],60)
assert not (Q/'stop-live').exists() and not (P/'stop-live').exists()
invoke('interacting-1000',['run_live.py','interacting-1000','drivers/cogent','11100',str(P/'window-cycle'),'-composed','-cycles=1000','-sample-every=25','-timeout=3h','-heap-profile='+str(P/'final.heap')],11120)
invoke('retention-validation',['validate_retention.py','full'],120)
status('completed','PASS_SCOPED_CURRENT_SOURCE_INTERACTING_RETENTION')
print('PASS current committed1000-window lifecycle; broaderMac qualification remains open',flush=True)
