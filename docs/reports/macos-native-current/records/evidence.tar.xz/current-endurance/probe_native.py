import json,os,subprocess,sys,time
from pathlib import Path
p=Path(sys.argv[1]);child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'])
(p/'native.json').write_text(json.dumps({'pid':os.getpid(),'group':os.getpgrp(),'observer_pid':child.pid,'observer_group':os.getpgid(child.pid)}))
time.sleep(60)
