from pathlib import Path
import hashlib,json,math,sys,statistics
from run import R, P, sha, identity

full = sys.argv[1:] == ['full']
assert full or sys.argv[1:] == ['preflight']
name='interacting-1000' if full else 'interacting-preflight'
count,every,cooperative,watchdog=(1000,25,'3h',11100) if full else (5,5,'2m',180)
baseline=json.loads((P/'baseline.json').read_text())
assert baseline['clean'] and len(baseline['prepared'])==6214
actual=identity();assert actual['commit']==baseline['commit']and actual['tracked']==baseline['tracked']and actual['prepared']==baseline['prepared']
def receipt(n):
 j=json.loads((P/(n+'.json')).read_text())
 assert j['exit_code']==0 and not j['error']and j['source_prepared_stable']
 assert j['cwd']==str(R/'drivers/cogent')
 assert j['source_commit']==baseline['commit']and j['baseline_sha256']==sha(P/'baseline.json')and j['producer_sha256']==sha(P/('run.py' if n=='build-cycles' else 'run_live.py'))
 assert j['authorization_sha256']==sha(P/'testing-authorization.json')
 for ch in ['stdout','stderr']:assert j[ch+'_sha256']==sha(P/(n+'.'+ch))
 return j
build=receipt('build-cycles');run=receipt(name)
assert build['mode']=='build'and build['argv']==['go','build','-tags=vellum_native_checks','-o',str(P/'window-cycle'),'./cmd/window-cycle-smoke']
argv=[str(P/'window-cycle'),'-composed',f'-cycles={count}',f'-sample-every={every}',f'-timeout={cooperative}']
if full:argv.append('-heap-profile='+str(P/'final.heap'))
assert run['mode']=='live'and run['argv']==argv and run['timeout_seconds']==watchdog and run['executable_sha256']==sha(P/'window-cycle')
events=[json.loads(line)for line in (P/(name+'.stdout')).read_text().splitlines()if line.startswith('{')]
cycles=[x for x in events if x.get('event')=='vellum.composed-cycle'];partials=[x for x in events if x.get('event')=='vellum.native-action'];results=[x for x in events if x.get('event')=='vellum.window-cycle.result']
assert len(cycles)==count and len(partials)==count*24 and len(results)==1 and [c['cycle']for c in cycles]==list(range(1,count+1))
plan=[('check','set','false'),('switch','press',''),('toggle','press',''),('check','set','true'),('slider','set','37'),('number','increment',''),('radio','set','a'),('segment','set','b'),('selector','set','a'),('button','press',''),('disclosure','collapse',''),('disclosure','expand',''),('tabs','set','about'),('tabs','set','live'),('tabs','set','colors'),('color/color/red','set','12'),('color/color/hex','set','#3567B580'),('tabs','set','live'),('tree:b3V0bGluZQ:row:bjA','press',''),('tree:b3V0bGluZQ:row:bjA','collapse',''),('tree:b3V0bGluZQ:row:bjA','expand',''),('text','set','Cocoa composed edit'),('dialog-open','press',''),('dialog-close','press','')]
for i,c in enumerate(cycles):
 assert all(c[k] for k in ['native_text_accepted','native_tree_selection','editor_history_replayed','grid_tree_completed','tree_accessibility_completed','modal_open_close','all_dense_labels_fully_visible'])
 assert c['tree_accessibility_rows']>0 and c['native_color_edits']==2 and c['native_tree_disclosures']==2
 assert c['dense_defined']==c['dense_fully_visible']==1000 and c['requested_logical_size']==[1920,1080]and not c['full_p11_qualified']
 actions=c['native_actions'];assert len(actions)==24 and [(a['Target'],a['Kind'],a['Value'])for a in actions]==plan
 assert [p['action']for p in partials[i*24:(i+1)*24]]==actions
 assert all(p['window']==f'native-cycle-{i:04d}'for p in partials[i*24:(i+1)*24])
 for a in actions:
  assert type(a['Attempts']) is int and type(a['Admissions']) is int and 1<=a['Admissions']<=a['Attempts'] and a['OwnerAndNativeCompleted'] is True and a['NativeRole']
  assert isinstance(a['ElapsedSeconds'],(int,float))and math.isfinite(a['ElapsedSeconds'])and 0<a['ElapsedSeconds']<=5
 for index,role in [(15,'AXSlider'),(16,'AXTextField')]:assert actions[index]['NativeRole']==role
result=results[0]
assert result['result']=='PASS_NATIVE_WINDOW_CYCLES'and result['requested_cycles']==result['completed_cycles']==count and result['composed_workspace']and result['dense_labels_per_composed_window']==1000
assert result['cooperative_timeout_seconds']==(10800 if full else 120)and not result['full_p11_qualified']and not result['gpu_memory_qualified']and not result['native_heap_qualified']and not result['preferences_changed']and not result['clipboard_access']
cleanup=result['native_cleanup'];assert cleanup['MainThread']and cleanup['CleanupObserved']and cleanup['CallbacksStopped']and not cleanup['WindowTitles']and cleanup['NativeOutstanding']==cleanup['AccessibilityWindows']==cleanup['PendingCallbacks']==0
samples=result['samples'];assert [s['Completed']for s in samples]==list(range(0,count+1,every))and [x['sample']for x in events if x.get('event')=='vellum.window-cycle.sample']==samples
assert result['rss_guard_bytes']==1<<30 and result['go_heap_guard_bytes']==512<<20 and result['samples_after_forced_gc']and result['geometry_persistence_disabled_in_fixture']
assert all(s['HeapAlloc']<=512<<20 and s['RSSBytes']<=1<<30 for s in samples)
assert result['heap_profile_requested']==full
if full:assert 0<(P/'final.heap').stat().st_size<=8<<20
warm=[s for s in samples if s['Completed']>=100]if full else samples[1:]
action_times={str(i+1)+':'+target+':'+kind:[c['native_actions'][i]['ElapsedSeconds']for c in cycles]for i,(target,kind,value)in enumerate(plan)}
summary={'result':'PASS_1000_INTERACTING_COMPOSED_CYCLES'if full else 'PASS_FIVE_INTERACTING_PREFLIGHT_CYCLES','base_commit':baseline['commit'],'baseline_sha256':sha(P/'baseline.json'),'run_receipt_sha256':sha(P/(name+'.json')),'build_receipt_sha256':sha(P/'build-cycles.json'),'executable_sha256':run['executable_sha256'],'elapsed_seconds':run['elapsed_seconds'],'cycles':count,'actions':24*count,'steps_per_cycle':24,'native_color_edits_per_cycle':2,'dense_labels_per_cycle':1000,'tree_ax_rows_counts':sorted(set(c['tree_accessibility_rows']for c in cycles)),'forced_gc_samples':len(samples),'warm_go_heap_bytes':[min(s['HeapAlloc']for s in warm),max(s['HeapAlloc']for s in warm)],'warm_rss_bytes':[min(s['RSSBytes']for s in warm),max(s['RSSBytes']for s in warm)],'terminal_sample':samples[-1],'native_cleanup':cleanup,'prepared_files':6214,'prepared_changed':False,'action_wall_time_seconds':{k:{'median':statistics.median(v),'max':max(v)}for k,v in action_times.items()},'action_time_scope':'Diagnostic inspection/owner/native publication wall time including waits, not CPU/GPU/frame/input latency.','full_p6_qualified':False,'full_p11_qualified':False,'native_heap_budget_qualified':False,'gpu_memory_qualified':False,'human_voiceover_qualified':False,'physical_input_qualified':False}
summary.update({'queue_admissions_are_not_accepted_callbacks':True,'retry_cause_observed':False,'total_attempts':sum(a['Attempts']for c in cycles for a in c['native_actions']),'total_admissions':sum(a['Admissions']for c in cycles for a in c['native_actions']),'retries':[{'cycle':i+1,'step':j+1,'action':a}for i,c in enumerate(cycles)for j,a in enumerate(c['native_actions'])if a['Attempts']!=1 or a['Admissions']!=1]})
summary['steps_with_retries']=len(summary['retries'])
if full:summary.update({'heap_profile_sha256':sha(P/'final.heap'),'heap_profile_bytes':(P/'final.heap').stat().st_size})
(P/('retention-summary.json'if full else 'preflight-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k!='action_wall_time_seconds'},indent=2))
