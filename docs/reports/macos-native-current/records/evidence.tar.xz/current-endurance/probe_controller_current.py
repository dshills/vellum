import json,os,subprocess,sys,time
from pathlib import Path
p=Path(sys.argv[1]);mode=sys.argv[2];child=subprocess.Popen([sys.executable,str(p.parent.parent/'probe_native.py'),str(p)],start_new_session=False)
(p/'controller.json').write_text(json.dumps({'pid':os.getpid(),'group':os.getpgrp(),'native_pid':child.pid,'native_group':os.getpgid(child.pid)}))
for _ in range(100):
 if (p/'native.json').exists():break
 time.sleep(.01)
assert (p/'native.json').exists()
if mode=='normal':raise SystemExit(0)
if mode=='failure':raise SystemExit(3)
time.sleep(60)
