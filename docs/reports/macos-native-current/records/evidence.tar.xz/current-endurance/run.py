"""Bound quiet-machine native checks to one clean committed source endpoint."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
R=Path('/private/tmp/vellum-current-endurance');P=Path('/private/tmp/vellum-macos-current-endurance')
sys.path.insert(0,str(R/'scripts'))
from sdk_environment import child_environment

def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode().strip()
def identity():
 names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0') if n]
 return {'commit':git('rev-parse','HEAD'),'clean':not git('status','--porcelain'),'tracked':{n:sha(R/n) for n in names},'prepared':{f.relative_to(R/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting'] for f in sorted((R/'drivers/cogent/build'/m).rglob('*')) if f.is_file()}}
def baseline():
 x=identity();assert x['clean'] and len(x['prepared'])==6214
 f=P/'baseline.json'
 if f.exists():assert x==json.loads(f.read_text()),'source endpoint changed'
 else:f.write_text(json.dumps(x,indent=2)+'\n')
 return x
if __name__=='__main__':
 name,mode,relative,seconds=sys.argv[1:5];argv=sys.argv[5:];assert mode in ['build','native-gpu','live','performance']
 auth=P/'testing-authorization.json';assert json.loads(auth.read_text())['live_window_input_performance_tests_allowed'];before=baseline();timeout=float(seconds);assert 0<timeout<=11100
 env={**child_environment(runtime=mode!='build'),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
 if mode=='native-gpu':env.update({'VELLUM_GPU_SCENE_TEST':'1','GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go'})
 output=Path(argv[argv.index('-o')+1]) if mode=='build' and '-o' in argv else None
 if output:assert output.parent==P and not output.exists()
 d={'argv':argv,'mode':mode,'cwd':str(R/relative),'source_commit':before['commit'],'baseline_sha256':sha(P/'baseline.json'),'producer_sha256':sha(__file__),'authorization_sha256':sha(auth),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':timeout,'executable_sha256':sha(argv[0]) if Path(argv[0]).is_file() else None,'exit_code':None,'error':None};start=time.monotonic()
 try:
  with(P/(name+'.stdout')).open('xb') as so,(P/(name+'.stderr')).open('xb') as se:d['exit_code']=subprocess.run(argv,cwd=R/relative,env=env,stdout=so,stderr=se,timeout=timeout).returncode
 except BaseException as e:d['error']={'type':type(e).__name__,'message':str(e)}
 finally:
  d['elapsed_seconds']=time.monotonic()-start;d['source_prepared_stable']=identity()==before
  for c in ['stdout','stderr']:d[c+'_sha256']=sha(P/(name+'.'+c))
  if output:d.update({'produced_file':str(output),'produced_file_sha256':sha(output) if output.exists() else None,'produced_file_bytes':output.stat().st_size if output.exists() else None,'binary_launched':False})
  (P/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 sys.exit(0 if d['exit_code']==0 and not d['error'] and d['source_prepared_stable'] else 1)
