Approved scoped native retention evidence for frozene7f8e30 and6214 prepared files; no unresolved findings.

Raw order and values reconcile for1000 cycles,24000 checked24-step workflows,1000 contained dense labels per cycle and17 completed native tree rows. All partial records match their completed cycle actions. There are60 retry steps (54 tabs,6 disclosure expansion), yielding24060 attempts and queue admissions. Their causes remain unobserved; admission is not callback acceptance.

The run passes in9404.36 seconds. Its41 forcedGC samples reproduce post100 warm Go heap44,163,024–50,707,512 bytes and RSS370,753,536–398,311,424 bytes. Final heap is50,474,304 bytes and RSS398,311,424 bytes. Samples and the450,135-byte heap profile precede global teardown while the survivor is still alive. Sampled512MiB-Go/1GiB-RSS safety guards do not qualify memory budgets or unsampled peaks.

The recorded main-thread cleanup is complete for its tracked inventory, with stopped callbacks and zero window/panel/AX/native-operation/menu/tray callback counts. Menu Owned=false and OriginalRestored=false remain explicit; no restoration is claimed. Separate terminal group observations find no members. Source/build/executable/raw/profile bindings and reviewed producer hashes reconcile.

No fullMac/P6/P11, native/GPU budget, latency, physical display/input or human VoiceOver qualification follows. The old11-retry campaign and343-cycle failure remain separate; this success does not explain them or qualify later geometry/render endpoints. Only selected source bytes were rehashed; compilation/module-cache closure was not re-audited.
