from pathlib import Path
import hashlib,json,subprocess,sys,time
from subprocess import TimeoutExpired
P=Path('/private/tmp/vellum-macos-current-endurance');out=P/'group-cleanup-probe-v2';out.mkdir(exist_ok=False)
sys.path.insert(0,'/private/tmp/vellum-tabs-integration/scripts')
from child_process import run_child
from sdk_environment import child_environment
caught=False
try:
 with(out/'stdout.log').open('xb')as so,(out/'stderr.log').open('xb')as se:
  run_child([sys.executable,str(P/'probe_controller.py'),str(out)],env=child_environment(),stdout=so,stderr=se,timeout=1)
except TimeoutExpired:caught=True
assert caught
c=json.loads((out/'controller.json').read_text());n=json.loads((out/'native.json').read_text());assert c['group']==c['native_group']==n['group']==n['observer_group'] and c['native_pid']==n['pid']
states={}
for pid in [c['pid'],n['pid'],n['observer_pid']]:
 for _ in range(40):
  r=subprocess.run(['ps','-p',str(pid),'-o','stat='],capture_output=True,text=True)
  state=r.stdout.strip()
  if not state or state.startswith('Z'):break
  time.sleep(.05)
 states[str(pid)]=state
assert all(not s or s.startswith('Z')for s in states.values()),states
(out/'result.json').write_text(json.dumps({'result':'PASS_INHERITED_CONTROLLER_GROUP_TIMEOUT_RETIREMENT','timeout_detected':caught,'controller':c,'native_simulation':n,'final_process_states':states,'actual_cocoa_or_gui_launched':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'child_process_sha256':hashlib.sha256(Path('/private/tmp/vellum-tabs-integration/scripts/child_process.py').read_bytes()).hexdigest()},indent=2)+'\n')
print('PASS actual controller-group timeout retired controller/native-simulation/observer processes; no GUI')
