"""Matched ordinary CPU/GPU native frames after preceding owned campaigns retire."""
from pathlib import Path
import fcntl,importlib.util,json,os,subprocess,time
from native_identity import identity,sha
R=Path('/private/tmp/vellum-geometry-reuse');P=Path('/private/tmp/vellum-macos-geometry-native');S=Path('/private/tmp/vellum-macos-span-scratch-native');Q=Path('/private/tmp/vellum-macos-quiet-current')
def stop():
 if(Q/'stop-live').exists()or(P/'stop-live').exists():raise InterruptedError('human returned; stop native comparison')
stop();inputs_digest=sha(P/'inputs.json');producer_digest=sha(__file__);inputs=json.loads((P/'inputs.json').read_text());endpoint=inputs['endpoint']
assert endpoint['clean']and len(endpoint['tracked'])==4287 and len(endpoint['prepared'])==6216 and endpoint['commit']==inputs['source_checkpoint']
assert sha(P/'native_identity.py')==inputs['identity_helper_sha256']and sha(R/'scripts/benchmark-grid.py')==inputs['benchmark_helper_sha256']and sha(R/'scripts/sdk_environment.py')==inputs['sdk_environment_sha256']
assert sha(R/'docs/reports/macos-geometry-reuse/records/qualification.json')==inputs['qualification_sha256']
assert all(endpoint['tracked'][n]==h for n,h in inputs['sources'].items())
bins={n:Path(d['path'])for n,d in inputs['binaries'].items()};assert set(bins)=={'original','candidate'}
assert sha(inputs['original_adapter_path'])==inputs['original_adapter_sha256']and sha(inputs['original_overlay_path'])==inputs['original_overlay_sha256']
assert Path(inputs['original_adapter_path']).read_bytes()==subprocess.check_output(['git','show',inputs['build_source_base_commit']+':drivers/cogent/accessibility.go'],cwd=R)
changed=subprocess.check_output(['git','diff','--name-only',inputs['build_source_base_commit'],'HEAD'],cwd=R).decode().splitlines()
assert {n for n in changed if Path(n).suffix in {'.go','.mod','.sum','.m','.h','.c','.patch','.py','.sh'}}==set(inputs['sources'])
for version,selected in inputs['build_receipts'].items():
 f=Path(selected['path']);assert sha(f)==selected['sha256'];d=json.loads(f.read_text())
 assert d['exit_code']==0 and d['error']is None and d['source_delta_stable']and d['producer_sha256']==inputs['build_producer_sha256']
 assert d['source_commit']==inputs['build_source_base_commit']and d['source_delta_before']==d['source_delta_after']==inputs['sources']and d['prepared_before']==d['prepared_after']==endpoint['prepared']
 for ch in ['stdout','stderr']:assert sha(f.with_suffix('.'+ch))==d[ch+'_sha256']
 assert d['argv'][:2]==['go','build']and d['argv'][-3:]==['-o',str(bins[version]),'.']
 if version=='original':
  assert d['argv'][2]=='-overlay='+inputs['original_overlay_path']
  expected={'Replace':{str(R/'drivers/cogent/accessibility.go'):inputs['original_adapter_path'],str(R/'drivers/cogent/accessibility_geometry_cache.go'):''}}
  assert json.loads(Path(inputs['original_overlay_path']).read_text())==expected
  assert d['overlay_inputs_before']==d['overlay_inputs_after']=={inputs['original_overlay_path']:inputs['original_overlay_sha256'],inputs['original_adapter_path']:inputs['original_adapter_sha256']}
 else:assert not d['overlay_inputs_before']and not d['overlay_inputs_after']
def stable():
 assert sha(P/'inputs.json')==inputs_digest and sha(__file__)==producer_digest
 assert identity(R)==endpoint,'frozen native comparison endpoint changed'
 assert all(sha(bins[n])==inputs['binaries'][n]['sha256']and bins[n].stat().st_size==inputs['binaries'][n]['bytes']for n in bins)
stable();deadline=time.monotonic()+3600
while not(S/'native-queue.json').exists():
 stop()
 if time.monotonic()>deadline:raise TimeoutError('preceding native comparison terminal missing')
 time.sleep(2)
terminal=json.loads((S/'native-queue.json').read_text());prior=json.loads((S/'native-summary.json').read_text());owned=json.loads((S/'native-queue.owned-process.json').read_text())
assert terminal['exit_code']==0 and terminal['error']is None and terminal['producer_sha256']==inputs['predecessor_launcher_sha256']==sha(S/'launch.py')and terminal['queue_producer_sha256']==inputs['predecessor_producer_sha256']==sha(S/'compare.py')
assert terminal['inputs_sha256']==prior['inputs_sha256']==sha(S/'inputs.json')and prior['producer_sha256']==inputs['predecessor_producer_sha256']
assert prior['result']=='MEASURED_PAIRED_STAGE62_NATIVE_OPT_IN_GPU_FRAMES'and prior['processes']==40 and prior['ordinary_samples']==4800 and prior['endpoint_commit']=='87e7de154b96732cad5dcb67703087115909c6f2'
assert prior['summary_sha256']==sha(S/'native-comparison/summary.json')
for ch in ['stdout','stderr']:assert terminal[ch+'_sha256']==sha(S/('native-queue.'+ch))
# Observe the exact recorded predecessor group after its owner wrote the terminal
# receipt. Never kill a preceding or unowned group from this campaign.
try:os.killpg(owned['process_group'],0)
except ProcessLookupError:pass
else:raise RuntimeError('preceding owned native group still exists after terminal')
(P/'predecessor-binding.json').write_text(json.dumps({'terminal_sha256':sha(S/'native-queue.json'),'summary_sha256':sha(S/'native-summary.json'),'owned_process_sha256':sha(S/'native-queue.owned-process.json'),'predecessor_group_missing':True,'preceding_scope':'40 stage62GPUprocesses gated by frozen e7 endurance. Their outcomes do not qualify this later geometry source.'},indent=2)+'\n')
lock=(Q/'native-live.lock').open('a+');locked=False
try:
 while not locked:
  stop()
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);locked=True
  except BlockingIOError:
   if time.monotonic()>deadline:raise TimeoutError('native comparison lock wait expired')
   time.sleep(.25)
 stop();stable()
 spec=importlib.util.spec_from_file_location('benchmark',R/'scripts/benchmark-grid.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
 class OwnedSubprocess:
  def __getattr__(self,n):return getattr(subprocess,n)
  def Popen(self,*args,**options):
   assert options.pop('start_new_session')is True
   child=subprocess.Popen(*args,**options)
   try:assert os.getpgid(child.pid)==os.getpgrp()
   except BaseException:
    if child.poll()is None:child.kill()
    child.wait(timeout=5);raise
   return child
 def stop_direct(child):
  if child.poll()is None:child.kill()
 b.subprocess=OwnedSubprocess();b.terminate_owned_group=stop_direct
 factory=b.selectors.DefaultSelector
 class StopAwareSelector:
  def __init__(self):self.inner=factory()
  def register(self,*args,**kwargs):return self.inner.register(*args,**kwargs)
  def select(self,*args,**kwargs):stop();return self.inner.select(*args,**kwargs)
  def close(self):return self.inner.close()
 b.selectors.DefaultSelector=StopAwareSelector
 out=P/'native-comparison';out.mkdir(exist_ok=False);results={mode:{n:{}for n in bins}for mode in ['cpu','gpu']};progress=[]
 for mode in ['cpu','gpu']:
  for variable in [False,True]:
   for rows in [10000,1000000]:
    case=f"{'variable'if variable else 'fixed'}-{rows}"
    for n in bins:results[mode][n][case]=[]
    for repetition in range(5):
     for n in (['original','candidate']if repetition%2==0 else ['candidate','original']):
      stop();stable();directory=out/mode/n/case/f'run-{repetition+1}'
      samples,process=b.run_case(bins[n],directory,rows,variable,120,128,False,180,gpu_scene_rendering=mode=='gpu')
      assert process['result']=='PASS'and process['exit_code']==0 and len(samples)==120
      assert all(r['warmup_guard']==1 and not r['cpu_profile']and not r['allocation_profile']and not r['source_details']and not r['input_details']for r in process['records'])
      assert process['records'][1]['warmup']==process['records'][1]['warm_callbacks']==128
      stable();results[mode][n][case].append(samples);progress.append({'mode':mode,'version':n,'case':case,'repetition':repetition+1,'result_sha256':sha(directory/'result.json')});(out/'progress.json').write_text(json.dumps(progress,indent=2)+'\n');print(mode,n,case,repetition+1,flush=True)
     left,right=results[mode]['original'][case][-1],results[mode]['candidate'][case][-1]
     b.compare_geometry(left,right);assert all(a['geometry']==c['geometry']for a,c in zip(left,right))
 for mode in results:
  for n in bins:
   for prefix in ['fixed','variable']:
    for small,large in zip(results[mode][n][prefix+'-10000'],results[mode][n][prefix+'-1000000']):b.compare_geometry(small,large)
 summary={mode:{n:{case:{'timings_ns':b.summarize(runs),'go_process_alloc_bytes':b.distribution([s['go_process_alloc_bytes']for run in runs for s in run]),'go_process_mallocs':b.distribution([s['go_process_mallocs']for run in runs for s in run])}for case,runs in cases.items()}for n,cases in versions.items()}for mode,versions in results.items()}
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 q={'result':'MEASURED_PAIRED_ORDINARY_GEOMETRY_NATIVE_FRAMES','processes':80,'ordinary_samples':9600,'endpoint_commit':endpoint['commit'],'original_adapter_origin_commit':inputs['build_source_base_commit'],'binaries':inputs['binaries'],'inputs_sha256':inputs_digest,'producer_sha256':producer_digest,'warm_targets_ns':{'p95':4000000,'p99':6000000},'warm_target_met':{mode:{n:b.warm_target_met(cases)for n,cases in versions.items()}for mode,versions in summary.items()},'summary_sha256':sha(out/'summary.json'),'full_p6_qualified':False,'full_p11_qualified':False,'scope':inputs['scope']}
 (P/'native-summary.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q),flush=True)
finally:
 if locked:fcntl.flock(lock,fcntl.LOCK_UN)
 lock.close()
