Approved scoped geometry native comparison evidence; no unresolved findings.

All80 actual CPU/GPU processes,9600 ordinary samples,128 guarded warm callbacks,40 paired geometries and40 row-count workload checks reconcile. Independent nearest-rank recomputation matches every timing/allocation statistic. All runs miss p95 and none meets both unchanged4/6-ms targets; two GPU runs meet p99 alone.

CPU pooled tails are slightly lower in these cases; GPU results are mixed. GPU variable-million p99 increases6.567291→6.893667ms (+4.97%). CPU fixed10k process allocation p50 rises5,892,768→6,363,168 bytes (+7.98%). No consistent latency gain, significance, cause or noise explanation is inferred.

The successful owned controller, current producer/input hashes, pinned old-adapter overlay, three consumed sources,6216 prepared vector and exact observed binary bytes reconcile. Source8c is a later committed endpoint while binaries were built from590 plus the recorded changes; original is not a pristine baseline. Cleanup is supported by the reviewed launcher and process exits, without independent final-group or native-resource counters.

No tests/native/provider calls or source mutations were performed. Compiler closure, physicalGPU/presentation, native allocation/memory budgets, defaultGPU enablement, human input and fullMac/P6/P11 remain unqualified.
