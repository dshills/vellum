# Mac services and accessibility allocation checkpoint

Semantic encoding may use a local, never-reused string builder to avoid a separate
byte-to-string copy. The resulting compact JSON must equal independent stdlib
Marshal output after removing only the encoder's final record newline. Refusal
returns no partial publication. Escaping, nil/empty input, RawMessage, large integer
and invalid values require parity; subsequent calls cannot mutate prior output.
Initial rejection remains before cache preparation and completed encoding after it.

Completed grid records may reserve exact capacity from nonempty measured cells,
headers and unique visible rows. First-visible row order, empty-overscan exclusion,
semantic actions and stale-action eligibility stay unchanged. The prepass must not
introduce domain callbacks, native geometry reads or cache ownership transfer.

Correctness requires the focused repeated race checks, complete adapter offscreen
race suite, vet and the stored 400-cell Cocoa publication fixture. Native menu/tray
lifecycle checks separately verify actual selector routing, replacement, stale
action refusal, window survival and final native service retirement. Physical
pointer/keyboard, VoiceOver and notification workflows remain separate.

The ordinary comparison uses preceding committed and candidate optimized binaries,
the same prepared dependencies, all four stored-table cases, five fresh interleaved
process pairs per case, 128 guarded warmups, 120 events/process and exact paired
geometry. Preserve all samples and per-run variability. The runner owns the native
process and observer group through normal completion, refusal and hard timeout.
Diagnostic allocation profiles run separately and never satisfy warm acceptance.

Unchanged targets remain total recorded UI work p95 ≤4 ms and p99 ≤6 ms. Lower
process-wide Go allocation does not establish framework-only/retained/native/GPU
memory savings or consistent latency improvement. P6, P11 and full Mac qualification
require their broader workloads. The [report](../docs/reports/macos-service-performance/README.md)
records current results, ownership scope and remaining gates.


The ordinary geometry reuse checkpoint uses exact last-payload equality and native
ordinary membership invalidation. It must preserve shared-host overwrites,
remove/readd without an intervening render, unknown/presemantic IDs, scope changes,
close, and the existing text/grid transaction paths. The bounded cache's reuse is
qualified through sender oracles with intentional faults and the existing native
Cocoa control/modal and stored-grid consumers. A sampled process-wide CPU profile
may guide the change but does not qualify latency; ordinary comparisons remain a
separate checkpoint with unchanged 4/6 ms targets.


The [completed native evidence checkpoint](../docs/reports/macos-native-current/README.md)
retains both the 40-process stage-62 opt-in GPU comparison and the 80-process
CPU/GPU ordinary geometry comparison. Neither establishes a consistent frame gain.
All process-wide allocation observations, including increases, remain scoped to
those measured processes. Sampled CGO/profile attribution does not predict elapsed
UI savings. Inherited pre-run `launched=false` metadata must remain distinguished
from actual argv/result launch receipts. Tested endpoints, original overlays,
prepared identities, cleanup and producer versions are preserved independently.
