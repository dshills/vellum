from pathlib import Path
import hashlib,json,os
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');d=json.loads((q/'build-identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,v in d['binaries'].items():assert sha(q/name)==v['sha256']==sha(Path(v['reused_from'])) and os.access(q/name,os.X_OK) and (q/name).stat().st_mode&0o111
assert (q/'match.json').read_bytes()==(q.parent/'macos-matched-calibration-v3/match.json').read_bytes();p=t/'tools/macos-calibration/backend/build_control.py';compile(p.read_text(),str(p),'exec')
print('PASS: both exact reused binary identities, executablemodes,match,controller syntax. Existing unchanged tests reused; no native claim.')
