from pathlib import Path
import importlib.util,os,json,hashlib,sys,shutil
T=Path('/private/tmp/vellum-macos-native-results-97aee13');W=Path(__file__).resolve().parent;D=Path('/private/tmp/vellum-packed-stage0080-proof')
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('prepared_textbatch',T/'drivers/cogent/prepare.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
assert not D.exists();D.mkdir()
def digest(root):
 values={}
 for f in root.rglob('*'):
  assert not f.is_symlink(),str(f)
  if f.is_file():values[f.relative_to(root).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
 return values
expected={};actual={}
for dependency in json.loads((T/'drivers/cogent/native/dependencies.json').read_text())['dependencies']:
 name=dependency['name'];p.prepare_dependency(dependency,D/name)
 expected.update({name+'/'+n:v for n,v in digest(T/'drivers/cogent/build'/name).items()})
 actual.update({name+'/'+n:v for n,v in digest(D/name).items()})
assert expected==actual,sorted(n for n in expected.keys()|actual.keys() if expected.get(n)!=actual.get(n))
record={'result':'PASS','files':len(actual),'sha256':hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'scope':'Fresh pinned-module preparation through all stage0080 and typesetting stages matches every compiled prepared file. Temporary source proof deleted after exact match.'}
(W/'prepared-source-proof.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));shutil.rmtree(D)
