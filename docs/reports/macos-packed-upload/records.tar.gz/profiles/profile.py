from pathlib import Path
import _thread,datetime,hashlib,importlib.util,json,os,subprocess,sys,threading
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');STOP=W/'stop-native';BIN=Path('/private/tmp/vellum-ready-native-5482f9b/bin/text-batch');finished=threading.Event()
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'scripts'));from child_process import run_child

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('grid_profile',T/'scripts/benchmark-grid.py');l=load('live_lease','/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=15)
def boundary():
 assert not STOP.exists()
 for root in [T,C]:assert git(root,'rev-parse','HEAD').decode().strip()=='6e366fc31cee83ce295664168dec6dc84bfa5468' and not git(root,'status','--porcelain')
 assert sha(BIN)=='38a98dcaddb7855a2476943aa468ae6f8294f11f665e0b88946ea65e677fb9da'
def watch():
 while not finished.wait(.2):
  if STOP.exists():_thread.interrupt_main();return
record={'result':'INCOMPLETE','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':'6e366fc31cee83ce295664168dec6dc84bfa5468','binary_sha256':sha(BIN),'scope':'Separate process-wide CPU profile600measured events and sampledallocationdelta120events after128warm. Fixed10k/400cells. These diagnostic timing values never qualify ordinary frame gates. CPU samples may include native wait attribution; native/GPU allocations not attributed.','cases':{}}
try:
 boundary()
 with l.LiveLease():
  threading.Thread(target=watch,daemon=True).start()
  for label,count,kwargs in [('cpu',600,{'cpu_profile':str(W/'frame.cpu.pprof')}),('allocations',120,{'alloc_profile':str(W/'frame-alloc')})]:
   boundary();data,outcome=b.run_case(BIN,W/label,10000,False,count,128,False,180,gpu_scene_rendering=True,**kwargs)
   record['cases'][label]={'measured_records':len(data),'exit_code':outcome['exit_code'],'log_sha256':outcome['log_sha256']};print(json.dumps({'case':label,**record['cases'][label]}),flush=True)
  boundary();record['result']='MEASURED'
except BaseException as e:record.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
finally:
 finished.set();STOP.touch();record['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(record,indent=2)+'\n')
if record['result']!='MEASURED':print(json.dumps(record),flush=True);sys.exit(1)
for label,options,path in [('cpu-flat',[],W/'frame.cpu.pprof'),('cpu-cumulative',['-cum'],W/'frame.cpu.pprof'),('allocation-flat',['-alloc_space','-base',str(W/'frame-alloc.before.pprof')],W/'frame-alloc.after.pprof'),('allocation-cumulative',['-alloc_space','-cum','-base',str(W/'frame-alloc.before.pprof')],W/'frame-alloc.after.pprof')]:
 argv=['/opt/homebrew/Cellar/go/1.27.2/libexec/bin/go','tool','pprof',*options,'-top','-nodecount=70',str(BIN),str(path)]
 with (W/(label+'.txt')).open('xb')as out,(W/(label+'.stderr')).open('xb')as err:r=run_child(argv,cwd=T,stdout=out,stderr=err,timeout=45)
 (W/(label+'-command.json')).write_text(json.dumps({'argv':argv,'exit_code':r.returncode},indent=2)+'\n');assert r.returncode==0
print(json.dumps({'result':record['result']}),flush=True)
