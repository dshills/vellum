"""Persist only the reviewed overlay as a hash-pinned owned dependency stage."""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path('/private/tmp/vellum-large-data'); PHASE=Path('/private/tmp/vellum-macos-scene-scratch')
sha=lambda b:hashlib.sha256(b).hexdigest()
review=json.loads((PHASE/'overlay-source-review.json').read_text())
assert review['result']=='APPROVED_SOURCE' and not review['findings']
overlay=json.loads((PHASE/'candidate-overlay.json').read_text())['Replace']
base=json.loads((PHASE/'baseline.json').read_text())['prepared']
prepared=ROOT/'drivers/cogent/build/upstream'
original={}; outputs={}; chunks=[]
for target,candidate in sorted(overlay.items()):
 t=Path(target); c=Path(candidate); relative=t.relative_to(prepared).as_posix()
 before=t.read_bytes() if t.exists() else None; after=c.read_bytes()
 assert sha(after)==review['reviewed_file_sha256'][str(c)]
 assert (sha(before) if before is not None else None)==base.get('upstream/'+relative)
 original[relative]=sha(before) if before is not None else None; outputs[relative]=sha(after)
 chunks.extend(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+relative if before else '/dev/null',tofile='b/'+relative))
stage=ROOT/'drivers/cogent/native/patches/scenescratch'; stage.mkdir()
patch=stage/'0054-bounded-scene-scanner-reuse.patch'; patch.write_text(''.join(chunks))
for name,content in [('original-hashes.json',original),('output-hashes.json',outputs)]:
 (stage/name).write_text(json.dumps(content,indent=2)+'\n')
(stage/'README.md').write_text('# Bounded scene scanner reuse\n\nPatch 0054 reuses one private Rasterx scene-capture scanner under the existing\nserialized renderer owner. Borrow removes it from the idle cache. The unchanged\nfresh Dasher resets bounds and winding; capture restores the original winding.\nReturn detaches the current Spanner, clears clip and accumulation, and retains\nonly combined row/cell backing capacities of at most 64 KiB per renderer.\nResize on size change and Release retire the cache. No Packet, Builder, source\nimage or Font reference survives through the cached scanner.\n\nThe bound covers idle scanner array backing, not peak capture allocation or total\nprocess/native memory. Oversized backing is discarded without changing successful\ncapture admission. Original whole preflight, work charges, immutable packet\nemission and CPU fallback remain unchanged. GPU scene rendering remains opt-in.\n\nAn independent copied fresh-capture oracle checks Encode and software pixels,\nprevious-packet immutability, repeated winding/bounds, preflight and late builder\nrefusal, retirement and capacity. Native parity and interleaved frame measurements\nare recorded in the Mac scene-scratch report. New helpers/tests are MIT; upstream\nfiles preserve their original notices. Preparation verifies original/output hashes\nand the patch SHA256.\n')
manifest=ROOT/'drivers/cogent/native/dependencies.json'; m=json.loads(manifest.read_text())
upstream=next(d for d in m['dependencies'] if d['name']=='upstream')
upstream['stages'].append({'origin':'drivers/cogent/native/patches/scenescratch','inputs':'native/patches/scenescratch/original-hashes.json','outputs':'native/patches/scenescratch/output-hashes.json','patches':[{'file':'native/patches/scenescratch/'+patch.name,'sha256':sha(patch.read_bytes())}]})
manifest.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(outputs,indent=2))

test=ROOT/'drivers/cogent/prepare_test.py'
text=test.read_text();assert 'list(range(1, 54))' in text
test.write_text(text.replace('list(range(1, 54))','list(range(1, 55))'))
