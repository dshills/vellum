// Copyright (c) 2026, Davin Hills.
// SPDX-License-Identifier: MIT
package rasterx

import (
	"cogentcore.org/core/paint/renderers/rasterx/scan"
	"image"
	"unsafe"
)

// Retain at most64KiB of scanner row/cell backing per renderer. Metadata is
// fixed scalar state. No packet, source image, builder or font is retained.
const sceneScratchMaxBytes = 64 << 10

func sceneScannerBytes(s *scan.Scanner) int {
	return cap(s.Cell)*int(unsafe.Sizeof(scan.Cell{})) + cap(s.CellIndex)*int(unsafe.Sizeof(int(0)))
}
func (rs *Renderer) borrowSceneScanner(spanner *sceneSpanner) *scan.Scanner {
	s := rs.sceneScanner
	rs.sceneScanner = nil // Active scratch never becomes another capture's cache.
	if s == nil {
		return scan.NewScannerWithRowTracking(spanner, rs.image.Bounds().Dx(), rs.image.Bounds().Dy())
	}
	s.Spanner = spanner
	s.SetClip(image.Rectangle{})
	s.Clear()
	// NewDasher resets complete bounds and default winding below; ScenePacket
	// subsequently restores the current original renderer winding as before.
	return s
}
func (rs *Renderer) returnSceneScanner(s *scan.Scanner) {
	s.Spanner = nil
	s.SetClip(image.Rectangle{})
	s.Clear()
	if sceneScannerBytes(s) <= sceneScratchMaxBytes {
		rs.sceneScanner = s
	}
}
