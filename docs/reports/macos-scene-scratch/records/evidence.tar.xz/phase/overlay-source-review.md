APPROVED_SOURCE. No unresolved findings.

Four final overlay files are bound in the JSON certificate. Scanner reuse preserves the original fresh Dasher/bounds/winding setup and all admission/emission work. Deferred detachment/reset drops capture owners; the 64 KiB limit bounds idle plain row/cell backing, while oversize capture backing is discarded. Packet data and ordinary CPU fallback state remain separate.

The strengthened exact-original oracle now validates an old packet after later successful captures, plus explicit late builder refusal and subsequent parity. The supplied selected offscreen race count-three receipt is exit 0 with all current overlay inputs exact and identical 6,200 prepared endpoints. I did not rerun it.

This is source approval only. Benchmarks, native frame performance, physical resources and full Mac acceptance remain outside scope.
