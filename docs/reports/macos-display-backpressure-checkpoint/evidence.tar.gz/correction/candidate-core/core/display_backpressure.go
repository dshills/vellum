// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package core

import (
	"cogentcore.org/core/system"
	"cogentcore.org/core/system/composer"
)

type displayFrameAdmission interface {
	AdmitDisplayFrame() (uint64, error)
	FinishDisplayFrame(uint64)
}

func admitDisplayFrame(window system.Window) (uint64, error) {
	if gate, ok := window.(displayFrameAdmission); ok {
		return gate.AdmitDisplayFrame()
	}
	return 0, nil
}
func finishDisplayFrame(window system.Window, credit uint64) {
	if credit != 0 {
		if gate, ok := window.(displayFrameAdmission); ok {
			gate.FinishDisplayFrame(credit)
		}
	}
}
func displayFramePending(err error) bool {
	pending, ok := err.(interface{ DisplayPending() bool })
	return ok && pending.DisplayPending()
}
func beginDisplayFrame(window system.Window) func() {
	if gate, ok := window.(interface {
		DisplayBackpressureEnabled() bool
		BeginDisplayFrame()
		EndDisplayFrame()
	}); ok && gate.DisplayBackpressureEnabled() {
		gate.BeginDisplayFrame()
		return gate.EndDisplayFrame
	}
	return nil
}

// The existing renderContext/window owners and CPU-batch retirement are kept.
// The display credit ends only after this CPU batch and its native callback.
func (w *renderWindow) renderDisplayAsync(cp composer.Composer, trace *FrameTrace, tag, credit uint64) {
	rc := w.renderContext()
	rc.Lock()
	defer rc.Unlock()
	w.renderDisplayAsyncOwned(cp, trace, tag, credit)
}
func (w *renderWindow) renderDisplayAsyncOwned(cp composer.Composer, trace *FrameTrace, tag, credit uint64) {
	defer finishDisplayFrame(w.SystemWindow, credit)
	if tag != 0 {
		w.renderAsyncMeasuredOwned(cp, trace, tag)
	} else {
		w.renderAsyncOwned(cp)
	}
}
