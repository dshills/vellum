//go:build offscreen

// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package core

import (
	"context"
	"image"
	"image/color"
	"sync"
	"testing"
)

// The real manual owner, layout, software compositor and pixels remain in use.
// Only asynchronous native presentation is replaced by an explicit callback.
type fakeDisplayPending struct{}

func (fakeDisplayPending) Error() string        { return "controlled display pending" }
func (fakeDisplayPending) DisplayPending() bool { return true }

type displayAdmissionWindow struct {
	*completionPaintWindow
	mu                            sync.Mutex
	next, active                  uint64
	admitted, finished, begun     int
	cpuDone, nativePending, dirty bool
}

func (w *displayAdmissionWindow) AdmitDisplayFrame() (uint64, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.active != 0 {
		w.dirty = true
		return 0, fakeDisplayPending{}
	}
	w.next++
	w.active = w.next
	w.cpuDone = false
	w.admitted++
	return w.active, nil
}
func (w *displayAdmissionWindow) FinishDisplayFrame(credit uint64) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if credit == 0 || credit != w.active {
		return
	}
	w.finished++
	w.cpuDone = true
	if !w.nativePending {
		w.active = 0
	}
}
func (w *displayAdmissionWindow) DisplayBackpressureEnabled() bool { return true }
func (w *displayAdmissionWindow) BeginDisplayFrame() {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.begun++
	w.nativePending = true
}
func (w *displayAdmissionWindow) EndDisplayFrame() {}
func (w *displayAdmissionWindow) present() {
	w.mu.Lock()
	w.nativePending = false
	if w.cpuDone {
		w.active = 0
	}
	dirty := w.dirty
	w.dirty = false
	w.mu.Unlock()
	if dirty {
		w.RequestPaintAfter(0)
	}
}
func displayManualFixture(t *testing.T) (*ManualWindow, *Body, *fixtureClock, *busyRetryDrawer, *displayAdmissionWindow) {
	t.Helper()
	m, b, clock, drawer := busyRetryFixture(t)
	close(drawer.release)
	w := &displayAdmissionWindow{completionPaintWindow: observeCompletionPaint(m)}
	m.window.SystemWindow = w
	return m, b, clock, drawer, w
}
func displayDirty(body *Body, c color.RGBA) {
	body.Styles.Background = image.NewUniform(c)
	body.NeedsRender()
}
func TestVellumDisplayAdmissionDefersRealPixelsUntilNativeAcknowledgement(t *testing.T) {
	m, body, _, drawer, w := displayManualFixture(t)
	displayDirty(body, color.RGBA{R: 211, G: 23, B: 43, A: 255})
	m.window.renderWindow()
	if drawer.ends.Load() != 1 || w.finished != 1 || !w.cpuDone || !w.nativePending || w.active == 0 {
		t.Fatalf("CPU completion lost native reservation: compositions%d state%+v", drawer.ends.Load(), w)
	}
	displayDirty(body, color.RGBA{R: 23, G: 211, B: 43, A: 255})
	for range 32 {
		m.window.renderWindow()
	}
	if drawer.ends.Load() != 1 || w.admitted != 1 {
		t.Fatal("another real composition bypassed asynchronous display credit")
	}
	w.present()
	m.window.renderWindow()
	if drawer.ends.Load() != 2 || w.admitted != 2 || w.finished != 2 {
		t.Fatal("acknowledgement lost or duplicated dirty composition")
	}
	img, err := m.Image(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	p := img.RGBAAt(img.Bounds().Dx()/2, img.Bounds().Dy()/2)
	if p.G < 180 || p.R > 60 || p.B > 80 {
		t.Fatalf("resumed real software frame is stale: %v", p)
	}
	w.present()
}
func TestVellumDisplayAdmissionRetiresUnchangedReservation(t *testing.T) {
	m, _, _, drawer, w := displayManualFixture(t)
	m.window.renderWindow()
	if drawer.ends.Load() != 0 || w.admitted != 1 || w.finished != 1 || w.active != 0 || w.begun != 0 {
		t.Fatalf("unchanged pass leaked display reservation: compositions%d state%+v", drawer.ends.Load(), w)
	}
}
func TestVellumDisplayAdmissionCoversEarlyResizeReplay(t *testing.T) {
	m, _, _, drawer, w := displayManualFixture(t)
	original := TheApp.App
	TheApp.App = &busyRetryPlatformApp{App: original}
	defer func() { TheApp.App = original }()
	m.window.lastResize = m.config.Now()
	before := m.window.flags.HasFlag(winRenderSkipped)
	w.active = 99
	w.nativePending = true
	w.cpuDone = true
	m.window.renderWindow()
	if w.admitted != 0 || !w.dirty || drawer.ends.Load() != 0 || m.window.flags.HasFlag(winRenderSkipped) != before {
		t.Fatal("early resize/cache path bypassed pending display admission")
	}
	w.present()
}
