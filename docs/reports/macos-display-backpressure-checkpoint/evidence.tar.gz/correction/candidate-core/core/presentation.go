// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package core

import "cogentcore.org/core/system"

// Native frame stamps carry immutable acquisition-time identity. The backend
// supplies composition ordinals. A pre-armed frame cannot inherit a later owner
// transition, even if drawable acquisition waits until that transition finishes.
func (trace *FrameTrace) presentationStamp(tag uint64) (uint64, uint64, bool) {
	if trace == nil || tag == 0 {
		return 0, 0, false
	}
	trace.mu.Lock()
	defer trace.mu.Unlock()
	if p := trace.pending; p != nil && p.Tag == tag && p.rendering && !p.ready {
		return p.Tag, p.frameGeneration, p.frameArmed
	}
	return 0, 0, false
}
func beginPresentationFrame(window system.Window, trace *FrameTrace, tag uint64) func() {
	endDisplay := beginDisplayFrame(window)
	observer, ok := window.(interface {
		PresentationEnabled() bool
		BeginPresentationFrame(uint64, uint64, bool)
		EndPresentationFrame()
	})
	if !ok || !observer.PresentationEnabled() {
		return endDisplay
	}
	input, generation, armed := trace.presentationStamp(tag)
	observer.BeginPresentationFrame(input, generation, armed)
	return func() {
		observer.EndPresentationFrame()
		if endDisplay != nil {
			endDisplay()
		}
	}
}
func redrawCachedObserved(window system.Window) bool {
	if end := beginPresentationFrame(window, nil, 0); end != nil {
		defer end()
	}
	return redrawCached(window.Composer())
}
