//go:build darwin

// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package desktop

/*
#cgo CFLAGS: -x objective-c
#cgo LDFLAGS: -framework QuartzCore -framework Metal
#include "presentation_darwin.h"
*/
import "C"
import "time"

// EnableDisplayBackpressure is a private opt-in Mac experiment, not a default
// scheduling policy. It must run before the layer's first drawable acquisition.
// A missing/zero display callback latches typed refusal; it never guesses that a
// live frame retired. Callers must observe refusal and close the diagnostic.
func (w *Window) EnableDisplayBackpressure(timeout time.Duration) error {
	if C.vellumPresentationAvailable() == 0 {
		return displayFailure("native presentation callback unavailable")
	}
	if !w.Lock() {
		return displayFailure("window closed")
	}
	defer w.Unlock()
	if w.nativeLayer == nil || w.displayGate.Load() != nil {
		return displayFailure("native layer unavailable or experiment already enabled")
	}
	paint := w.Paint
	if paint == nil {
		return displayFailure("owner paint mailbox unavailable")
	}
	g, err := newDisplayGate(timeout, paint.Request)
	if err != nil {
		return err
	}
	token, err := displayRegistry.register(g)
	if err != nil {
		return err
	}
	if C.vellumDisplayBackpressure(w.nativeLayer, C.uint64_t(token)) == 0 {
		displayRegistry.close(token)
		return displayFailure("drawable acquisition already started")
	}
	w.displayToken.Store(token)
	w.displayGate.Store(g)
	return nil
}

// Begin/End require existing SystemWindow.Mu, matching native frame stamps.
func (w *Window) BeginDisplayFrame() {
	if g := w.displayGate.Load(); g != nil {
		status := g.status()
		C.vellumDisplayFrame(w.nativeLayer, C.uint64_t(status.Active))
	}
}
func (w *Window) EndDisplayFrame() {
	if w.displayGate.Load() != nil {
		C.vellumDisplayFrame(w.nativeLayer, 0)
	}
}

//export vellumGoDisplayAcquire
func vellumGoDisplayAcquire(token, credit C.uint64_t) C.uint64_t {
	if g := displayGateForToken(uint64(token)); g != nil {
		return C.uint64_t(g.acquire(uint64(credit)))
	}
	return 0
}

//export vellumGoDisplayUnavailable
func vellumGoDisplayUnavailable(token, sequence C.uint64_t) {
	if g := displayGateForToken(uint64(token)); g != nil {
		g.unavailable(uint64(sequence))
	}
}

//export vellumGoDisplayPresented
func vellumGoDisplayPresented(token, sequence C.uint64_t, at C.double) {
	if g := displayGateForToken(uint64(token)); g != nil {
		g.complete(uint64(sequence), float64(at), false)
	}
}
