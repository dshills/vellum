// Copyright 2019 Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// originally based on golang.org/x/exp/shiny:
// Copyright 2015 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package desktop

import (
	"image"
	"log"
	"math"
	"sync"
	"sync/atomic"
	"unsafe"

	"cogentcore.org/core/events"
	"cogentcore.org/core/gpu"
	"cogentcore.org/core/gpu/gpudraw"
	"cogentcore.org/core/styles/sides"
	"cogentcore.org/core/system"
	"cogentcore.org/core/system/composer"
	"cogentcore.org/core/system/driver/base"
	"github.com/go-gl/glfw/v3.4/glfw"
)

// Window is the implementation of [system.Window] for the desktop platform.
type Window struct {
	chrome               system.WindowChrome         // immutable before publication
	chromeClientPosition atomic.Pointer[image.Point] // full-view top-left, published on native main

	Native                  NativeAttachment
	nativeLayer             unsafe.Pointer // borrowed from content view, under Mu
	presentationToken       atomic.Uint64
	presentationComposition uint64                      // monotonic under Mu
	displayGate             atomic.Pointer[displayGate] // opt-in; retained closed after teardown
	displayToken            atomic.Uint64
	closeOnce               sync.Once
	cursorScale             atomic.Uint64 // packed DPI/DPR, published under Mu after creation
	pointerFocus            atomic.Uint64 // focus rebase publication, never cleared by producer
	pointerFocusUsed        uint64        // native producer only
	pointerDPRUsed          uint32        // native producer only
	cursor                  *Cursor       // published before the window, retained closed after teardown
	composerPointer         atomic.Pointer[composer.ComposerDrawer]
	base.WindowMulti[*App, *composer.ComposerDrawer]

	// Glw is the glfw window associated with this window
	Glw *glfw.Window

	// Draw is the [gpudraw.Drawer] used for the Composer.
	Draw *gpudraw.Drawer // TODO: really need this separately?

	// ScreenName is the name of the last known screen this window was on
	ScreenWindow string
}

// Composer is published once before window event loops start, and withdrawn
// under Mu before native teardown completes. IsClosed must not read Compose while
// the native main thread clears it.
func (w *Window) Composer() composer.Composer {
	if w == nil {
		return nil
	}
	value := w.composerPointer.Load()
	if value == nil {
		return nil
	}
	return value
}
func (w *Window) IsClosed() bool { return w == nil || w.composerPointer.Load() == nil }

// Lock rechecks after acquiring Mu: teardown may have won while this caller
// waited. Rendering must never enter using an already released composer.
func (w *Window) Lock() bool {
	if w == nil {
		return false
	}
	w.Mu.Lock()
	if w.IsClosed() {
		w.Mu.Unlock()
		return false
	}
	return true
}

func (w *Window) IsVisible() bool {
	return w.WindowMulti.IsVisible() && w.Glw != nil
}

func (w *Window) SendPaintEvent() {
	TheApp.PollScreenChanges()
	w.This.Events().WindowPaint()
}

// Activate() sets this window as the current render target for gpu rendering
// functions, and the current context for gpu state (equivalent to
// MakeCurrentContext on OpenGL).
// If it returns false, then window is not visible / valid and
// nothing further should happen.
// Must call this on app main thread using system.TheApp.RunOnMain
//
//	system.TheApp.RunOnMain(func() {
//	   if !win.Activate() {
//	       return
//	   }
//	   // do GPU calls here
//	})
func (w *Window) Activate() bool {
	// note: activate is only run on main thread so we don't need to check for mutex
	if w == nil || w.Glw == nil {
		return false
	}
	w.Glw.MakeContextCurrent()
	return true
}

// DeActivate() clears the current render target and gpu rendering context.
// Generally more efficient to NOT call this and just be sure to call
// Activate where relevant, so that if the window is already current context
// no switching is required.
// Must call this on app main thread using system.TheApp.RunOnMain
func (w *Window) DeActivate() {
	glfw.DetachCurrentContext()
}

// newGlfwWindow makes a new glfw window for this window.
// It must be run on main.
func (w *Window) newGlfwWindow(opts *system.NewWindowOptions, sc *system.Screen) error {
	if err := validateNativeWindowChrome(opts.Chrome); err != nil {
		return err
	}
	// glfw.DefaultWindowHints()
	if opts.Flags.HasFlag(system.FixedSize) {
		glfw.WindowHint(glfw.Resizable, glfw.False)
	} else {
		glfw.WindowHint(glfw.Resizable, glfw.True)
	}
	glfw.WindowHint(glfw.Visible, glfw.False) // needed to position
	glfw.WindowHint(glfw.Focused, glfw.True)
	// glfw.WindowHint(glfw.ScaleToMonitor, glfw.True)
	glfw.WindowHint(glfw.ClientAPI, glfw.NoAPI)
	// glfw.WindowHint(glfw.Samples, 0) // don't do multisampling for main window -- only in sub-render
	if opts.Flags.HasFlag(system.Maximized) {
		glfw.WindowHint(glfw.Maximized, glfw.True)
	}
	if opts.Flags.HasFlag(system.Tool) {
		glfw.WindowHint(glfw.Decorated, glfw.False)
	} else {
		glfw.WindowHint(glfw.Decorated, glfw.True)
	}
	glfw.WindowHint(glfw.CocoaRetinaFramebuffer, glfw.True)
	// glfw.WindowHint(glfw.TransparentFramebuffer, glfw.True)
	// todo: glfw.Floating for always-on-top -- could set for modal
	sz := opts.Size
	if TheApp.Platform() == system.MacOS {
		// on macOS, the size we pass to glfw must be in window manager units
		sz = sc.WindowSizeFromPixels(opts.Size)
	}
	fullscreen := opts.Flags.HasFlag(system.Fullscreen)
	var mon *glfw.Monitor
	if fullscreen && sc.ScreenNumber < len(TheApp.Monitors) {
		mon = TheApp.Monitors[sc.ScreenNumber]
		sz = sc.PixelSize // use screen size for fullscreen video mode resolution
	}
	glw, err := glfw.CreateWindow(sz.X, sz.Y, opts.GetTitle(), mon, nil)
	if err != nil {
		return err
	}
	if err := applyNativeWindowChrome(glw, opts.Chrome); err != nil {
		glw.Destroy()
		return err
	}
	w.chrome = opts.Chrome
	if !fullscreen {
		pos := opts.Pos.Add(sc.Geometry.Min) // screen relative
		if !w.setChromePositionOnMain(glw, pos.X, pos.Y) {
			glw.SetPos(pos.X, pos.Y)
		}
		w.Pos = pos
	}
	if opts.Icon != nil {
		glw.SetIcon(opts.Icon)
	}
	w.Glw = glw
	return nil
}

// Screen gets the screen of the window, computing various window parameters.
func (w *Window) Screen() *system.Screen {
	if w == nil || w.Glw == nil {
		return TheApp.ScreenSnapshot(0)
	}
	var sc *system.Screen
	mon := w.Glw.GetMonitor() // this returns nil for windowed windows -- i.e., most windows
	// that is super useless it seems. only works for fullscreen
	if mon != nil {
		if ScreenDebug {
			log.Printf("ScreenDebug: desktop.Window.Screen: %v: got screen: %v\n", w.Nm, mon.GetName())
		}
		sc = TheApp.ScreenByName(mon.GetName())
		if sc == nil {
			log.Printf("ScreenDebug: desktop.Window.Screen: could not find screen of name: %v\n", mon.GetName())
			sc = TheApp.ScreenSnapshot(0)
		}
		goto setScreen
	}
	sc = w.GetScreenOverlap()
	if sc == nil {
		return nil
	}
	// if monitorDebug {
	// 	log.Printf("ScreenDebug: desktop.Window.GetScreenOverlap: %v: got screen: %v\n", w.Nm, sc.Name)
	// }
setScreen:
	w.Mu.Lock()
	defer w.Mu.Unlock()
	defer w.publishCursorScale()
	w.ScreenWindow = sc.Name
	w.PhysDPI = sc.PhysicalDPI
	if w.DevicePixelRatio != sc.DevicePixelRatio {
		w.DevicePixelRatio = sc.DevicePixelRatio
	}
	if w.LogDPI == 0 {
		w.LogDPI = sc.LogicalDPI
	}
	return sc
}

// GetScreenOverlap gets the monitor for given window
// based on overlap of geometry, using limited glfw 3.3 api,
// which does not provide this functionality.
// See: https://github.com/glfw/glfw/issues/1699
// This is adapted from slawrence2302's code posted there.
func (w *Window) GetScreenOverlap() *system.Screen {
	w.App.Mu.Lock()
	defer w.App.Mu.Unlock()

	var wgeom image.Rectangle
	if p, ok := w.chromePositionSnapshot(); ok {
		wgeom.Min = p
	} else {
		wgeom.Min.X, wgeom.Min.Y = w.Glw.GetPos()
	}
	var sz image.Point
	sz.X, sz.Y = w.Glw.GetSize()
	wgeom.Max = wgeom.Min.Add(sz)

	var csc *system.Screen
	var ovlp int
	for _, sc := range TheApp.Screens {
		isect := sc.Geometry.Intersect(wgeom).Size()
		ov := isect.X * isect.Y
		if ov > ovlp || ovlp == 0 {
			csc = sc
			ovlp = ov
		}
	}
	if csc == nil {
		return nil
	}
	copy := *csc
	return &copy
}

func (w *Window) Position(screen *system.Screen) image.Point {
	w.Mu.Lock()
	defer w.Mu.Unlock()
	if w.Glw == nil {
		return w.Pos
	}
	var ps image.Point
	if p, ok := w.chromePositionSnapshot(); ok {
		ps = p
	} else {
		ps.X, ps.Y = w.Glw.GetPos()
	}
	w.Pos = ps
	if screen != nil {
		ps = ps.Sub(screen.Geometry.Min)
	}
	return ps
}

func (w *Window) SetTitle(title string) {
	if w.IsClosed() {
		return
	}
	w.Titl = title
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		w.Glw.SetTitle(title)
	})
}

func (w *Window) SetIcon(images []image.Image) {
	if w.IsClosed() {
		return
	}
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		w.Glw.SetIcon(images)
	})
}

func (w *Window) SetWinSize(sz image.Point) {
	if w.IsClosed() || w.Is(system.Fullscreen) {
		return
	}
	// note: anything run on main only doesn't need lock -- implicit lock
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		if !w.setChromeSizeOnMain(sz.X, sz.Y) {
			w.Glw.SetSize(sz.X, sz.Y)
		}
	})
}

func (w *Window) SetSize(sz image.Point) {
	sc := w.Screen()
	sz = sc.WindowSizeFromPixels(sz)
	w.SetWinSize(sz)
}

func (w *Window) SetPos(pos image.Point, screen *system.Screen) {
	if w.IsClosed() || w.Is(system.Fullscreen) {
		return
	}
	if screen != nil {
		pos = pos.Add(screen.Geometry.Min)
	}
	// note: anything run on main only doesn't need lock -- implicit lock
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		if !w.setChromePositionOnMain(w.Glw, pos.X, pos.Y) {
			w.Glw.SetPos(pos.X, pos.Y)
		}
	})
}

func (w *Window) SetGeometry(fullscreen bool, pos, size image.Point, screen *system.Screen) {
	if w.IsClosed() {
		return
	}
	w.App.RunOnMain(func() { w.setGeometryOnMain(fullscreen, pos, size, screen) })
}

// setGeometryOnMain is used by already-admitted native operations without
// recursively dispatching to the main queue.
func (w *Window) setGeometryOnMain(fullscreen bool, pos, size image.Point, screen *system.Screen) {
	if w.IsClosed() || w.Glw == nil {
		return
	}
	w.Mu.Lock()
	if pos == (image.Point{}) {
		pos = w.Pos
	}
	if size == (image.Point{}) {
		size = w.PixelSize
	}
	if screen != nil {
		pos = pos.Add(screen.Geometry.Min)
	}
	w.Mu.Unlock()
	sc := w.Screen()
	if screen != nil {
		sc = screen // critical to use this b/c w.Screen() can be wrong on new screen sequence
	}
	if sc == nil {
		return
	}
	size = sc.WindowSizeFromPixels(size)
	func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		switch {
		case w.Is(system.Fullscreen) && !fullscreen:
			w.Flgs.SetFlag(false, system.Fullscreen)
			w.Glw.SetMonitor(nil, pos.X, pos.Y, size.X, size.Y, glfw.DontCare)
			// GLFW restores a nominal Cocoa content rect. Unified uses the full view.
			if w.setChromeSizeOnMain(size.X, size.Y) {
				w.setChromePositionOnMain(w.Glw, pos.X, pos.Y)
			}
		case fullscreen:
			w.Flgs.SetFlag(true, system.Fullscreen)
			if screen != nil {
				sc = screen
			}
			mon := w.App.Monitors[sc.ScreenNumber]
			w.Glw.SetMonitor(mon, 0, 0, sc.PixelSize.X, sc.PixelSize.Y, glfw.DontCare)
		default:
			if !w.setChromeSizeOnMain(size.X, size.Y) {
				w.Glw.SetSize(size.X, size.Y)
			}
			if !w.setChromePositionOnMain(w.Glw, pos.X, pos.Y) {
				w.Glw.SetPos(pos.X, pos.Y)
			}
		}
	}()
}

func (w *Window) ConstrainFrame(topOnly bool) sides.Sides[int] {
	w.Mu.Lock()
	frameSize := w.FrameSize
	w.Mu.Unlock()
	w.App.RunOnMain(func() { frameSize = w.constrainFrameOnMain(topOnly) })
	return frameSize
}

// constrainFrameOnMain keeps any resulting geometry change in the same native
// callback. Public callers dispatch once through ConstrainFrame.
func (w *Window) constrainFrameOnMain(topOnly bool) sides.Sides[int] {
	w.Mu.Lock()
	frameSize, position := w.FrameSize, w.Pos
	w.Mu.Unlock()
	if w.Glw == nil || w.IsClosed() || w.Is(system.Fullscreen) || w.Is(system.Maximized) {
		return frameSize
	}
	if TheApp.Platform() == system.Windows && (position.X == -32000 || position.Y == -32000) {
		return frameSize
	}
	l, t, r, b := w.chromeFrameSizeOnMain()
	w.Mu.Lock()
	w.FrameSize.Set(t, r, b, l)
	frameSize, position = w.FrameSize, w.Pos
	if p, ok := w.chromePositionSnapshot(); ok {
		position = p
	}
	windowSize := w.WnSize
	w.Mu.Unlock()
	sc := w.Screen()
	if sc == nil {
		return frameSize
	}
	scSize := sc.Geometry.Size()
	// fmt.Println("\tconstrainframe screen:", sc.Name, scSize, w.FrameSize, "geom:", w.Pos, w.WnSize)
	frSize := image.Pt(frameSize.Left+frameSize.Right, frameSize.Top+frameSize.Bottom)
	frOff := image.Pt(frameSize.Left, frameSize.Top)
	sz := windowSize.Add(frSize)
	scpos := position.Sub(sc.Geometry.Min)
	pos := scpos.Sub(frOff)
	cpos, csz := system.ConstrainWindowGeometry(pos, sz, scSize)
	cpos = cpos.Add(frOff)
	csz = csz.Sub(frSize)
	// fmt.Println("\tconstrainframe pos:", scpos, "cpos:", cpos, "size:", w.WnSize, "csz:", csz)
	change := false
	pos = scpos
	if !topOnly && cpos.X > pos.X {
		change = true
		pos.X = cpos.X
	}
	if cpos.Y > pos.Y {
		change = true
		pos.Y = cpos.Y
	}
	sz = windowSize
	if !topOnly && csz.X < sz.X {
		change = true
		sz.X = csz.X
	}
	if !topOnly && csz.Y < sz.Y {
		change = true
		sz.Y = csz.Y
	}
	if change {
		// fmt.Println("\tconstrainframe changed:", pos, sz)
		w.setGeometryOnMain(false, pos, sz, sc)
	}
	return frameSize
}

func (w *Window) Show() {
	if w.IsClosed() {
		return
	}
	// note: anything run on main only doesn't need lock -- implicit lock
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		w.Glw.Show()
	})
}

func (w *Window) Raise() {
	if w.IsClosed() {
		return
	}
	// note: anything run on main only doesn't need lock -- implicit lock
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		if w.Is(system.Minimized) {
			w.Glw.Restore()
		} else {
			w.Glw.Focus()
		}
	})
}

func (w *Window) Minimize() {
	if w.IsClosed() {
		return
	}
	// note: anything run on main only doesn't need lock -- implicit lock
	w.App.RunOnMain(func() {
		if w.Glw == nil { // by time we got to main, could be diff
			return
		}
		w.Glw.Iconify()
	})
}

func (w *Window) Close() {
	if w == nil {
		return
	}
	w.closeOnce.Do(func() {
		w.retireDisplayBackpressure()
		if w.cursor != nil {
			w.cursor.retireStatus()
		}
		// Stop native callbacks before application cleanup and before GPU/view release.
		w.App.RunOnMainQueued(func() {
			if w.Native != nil {
				w.Native.Close()
				w.Native = nil
			}
		})
		w.Window.Close()
		w.Mu.Lock()
		defer w.Mu.Unlock()
		w.App.RunOnMainQueued(w.releaseNativeResources)
	})
}

// releaseNativeResources runs on the main thread, including failed creation.
func (w *Window) releaseNativeResources() {
	w.retireDisplayBackpressure()
	w.composerPointer.Store(nil)
	w.App.retireCursor(w.cursor)
	w.closePresentationObserver()
	if w.Native != nil {
		w.Native.Close()
		w.Native = nil
	}
	if w.Glw == nil {
		return
	}
	if w.Draw != nil {
		w.Draw.System.WaitDone()
		if w.DestroyGPUFunc != nil {
			w.DestroyGPUFunc()
		}
		var surf *gpu.Surface
		if sf, ok := w.Draw.Renderer().(*gpu.Surface); ok {
			surf = sf
		}
		w.Draw.Release()
		if surf != nil {
			surf.Release()
		}
	}
	w.Glw.Destroy()
	w.Glw = nil
	w.Draw = nil
	w.Compose = nil
}

// SetMousePos accepts window pixel coordinates, including fractional/outside
// positions. Native positioning requires a live focused, visible window.
func (w *Window) SetMousePos(x, y float64) { _ = w.setMousePos(x, y) }

// SetCursorEnabled controls relative mode. Raw motion is optional; unsupported
// platforms use ordinary relative motion. Hide/Show preference survives this.
func (w *Window) SetCursorEnabled(enabled, raw bool) {
	if w.cursor != nil {
		_ = w.cursor.modeRequest(func(c *Cursor) { c.wantEnabled, c.wantRaw = enabled, raw })
	}
}
func (w *Window) IsCursorEnabled() bool {
	cu := w.cursor
	if cu == nil {
		return false
	}
	cu.mu.Lock()
	defer cu.mu.Unlock()
	return !cu.closed && cu.modeKnown && cu.mode != glfw.CursorDisabled
}

////////  Window Callbacks

func (w *Window) Moved(gw *glfw.Window, x, y int) {
	// Capture on native main before handing the scalar geometry to the worker.
	w.recordChromePositionOnMain(gw)
	if p, ok := w.chromePositionSnapshot(); ok {
		x, y = p.X, p.Y
	}
	go func() {
		w.Mu.Lock()
		w.Pos = image.Pt(x, y)
		w.Mu.Unlock()
		// w.app.GetScreens() // this can crash here on win disconnect..
		w.updateGeometry() // critical to update size etc here.
		w.Event.Window(events.WinMove)
	}()
}

func (w *Window) WinResized(gw *glfw.Window, width, height int) {
	w.recordChromePositionOnMain(gw)
	go func() {
		// w.app.GetScreens()  // this can crash here on win disconnect..
		if ScreenDebug {
			log.Printf("desktop.Window.WinResized: %v: %v (was: %v)\n", w.Nm, image.Pt(width, height), w.PixelSize)
		}
		w.updateMaximized()
		w.updateGeometry()
	}()
}

func (w *Window) updateMaximized() {
	w.Flgs.SetFlag(w.Glw.GetAttrib(glfw.Maximized) == glfw.True, system.Maximized)
}

func (w *Window) updateGeometry() {
	w.Mu.Lock()
	cursc := w.ScreenWindow
	w.Mu.Unlock()
	sc := w.Screen() // gets parameters
	w.Mu.Lock()
	w.updateMaximized()
	var wsz image.Point
	wsz.X, wsz.Y = w.Glw.GetSize()
	w.WnSize = wsz
	var fbsz image.Point
	fbsz.X, fbsz.Y = w.Glw.GetFramebufferSize()
	w.PixelSize = fbsz
	w.PhysDPI = sc.PhysicalDPI
	w.LogDPI = sc.LogicalDPI
	w.publishCursorScale()
	// Keep surface reconfiguration inside composer ownership: an acquired
	// presentation texture must not be invalidated before queue submission.
	w.Draw.System.Renderer.SetSize(w.PixelSize)
	nextsc := w.ScreenWindow
	w.Mu.Unlock()
	if cursc != nextsc {
		if ScreenDebug {
			log.Printf("desktop.Window.updateGeometry: %v: got new screen: %v (was: %v)\n", w.Nm, nextsc, cursc)
		}
	}
	w.Event.WindowResize()
}

func (w *Window) FbResized(gw *glfw.Window, width, height int) {
	go func() {
		if w.Is(system.Fullscreen) {
			sc := w.Screen()
			width = sc.PixelSize.X
			height = sc.PixelSize.Y
		}
		fbsz := image.Point{width, height}
		w.Mu.Lock()
		previousSize := w.PixelSize
		w.Mu.Unlock()
		if previousSize != fbsz {
			if ScreenDebug {
				log.Printf("desktop.Window.FbResized: %v: %v (was: %v)\n", w.Nm, fbsz, previousSize)
			}
			w.updateGeometry()
		}
	}()
}

func (w *Window) OnCloseReq(gw *glfw.Window) {
	go w.CloseReq()
}

func (w *Window) Focused(gw *glfw.Window, focused bool) {
	if w.Native != nil {
		w.Native.Focus(focused)
	}
	// w.Flgs.SetFlag(focused, system.Focused)
	if focused {
		w.pointerFocus.Add(1) // Cocoa may recenter after this callback returns.
		w.Event.Window(events.WinFocus)
	} else {
		w.Event.Last.MousePos = image.Point{-1, -1} // key for preventing random click to same location
		w.Event.Window(events.WinFocusLost)
	}
}

func (w *Window) Iconify(gw *glfw.Window, iconified bool) {
	w.Flgs.SetFlag(iconified, system.Minimized)
	if iconified {
		w.Event.Window(events.WinMinimize)
	} else {
		w.Screen() // gets parameters
		w.Event.Window(events.WinMinimize)
	}
}

// publishCursorScale runs under Mu, or before the new window is published.
func (w *Window) publishCursorScale() {
	packed := uint64(math.Float32bits(w.LogDPI))<<32 | uint64(math.Float32bits(w.DevicePixelRatio))
	w.cursorScale.Store(packed)
}
func (w *Window) SetLogicalDPI(dpi float32) {
	w.Mu.Lock()
	defer w.Mu.Unlock()
	w.LogDPI = dpi
	w.publishCursorScale()
}
