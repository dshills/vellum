// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package desktop

import (
	"errors"
	"math"
	"sync"
	"time"
)

// DisplayBackpressureError is a terminal refusal of the opt-in experiment.
// It does not claim successful presentation. Close remains available.
type DisplayBackpressureError struct{ Reason string }

func (e *DisplayBackpressureError) Error() string {
	return "desktop: display backpressure refused: " + e.Reason
}

type displayPendingError struct{}

func (displayPendingError) Error() string        { return "desktop: presentation still outstanding" }
func (displayPendingError) DisplayPending() bool { return true }

var errDisplayPending error = displayPendingError{}

// DisplayBackpressureStatus is detached scalar state, not native qualification.
// Retired counts admission reservations, including unused/cancelled batches.
type DisplayBackpressureStatus struct {
	Enabled                                       bool
	Issued, Retired, Epoch, Active, NativePending uint64
	Dirty, CPUFinished, Closed                    bool
	Failure                                       string
}

type displayGate struct {
	refusals                                                  chan error // internally owned buffer1; clients receive only
	mu                                                        sync.Mutex
	issued, retired, epoch, active, nextNative, nativePending uint64
	dirty, cpuFinished, closed                                bool
	failure                                                   string
	timeout                                                   time.Duration
	timer                                                     *time.Timer
	wake                                                      func() // only a bounded mailbox notification; never a window/main call
}

func newDisplayGate(timeout time.Duration, wake func()) (*displayGate, error) {
	if timeout < 100*time.Millisecond || timeout > 5*time.Second || wake == nil {
		return nil, errors.New("desktop: bounded display timeout and owner mailbox required")
	}
	return &displayGate{timeout: timeout, wake: wake, refusals: make(chan error, 1)}, nil
}
func (g *displayGate) status() DisplayBackpressureStatus {
	g.mu.Lock()
	defer g.mu.Unlock()
	return DisplayBackpressureStatus{true, g.issued, g.retired, g.epoch, g.active, g.nativePending, g.dirty, g.cpuFinished, g.closed, g.failure}
}
func (g *displayGate) failLocked(reason string) {
	if g.failure == "" {
		g.failure = reason
		select {
		case g.refusals <- &DisplayBackpressureError{reason}:
		default:
		}
	}
}
func (g *displayGate) admit() (uint64, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.closed {
		return 0, &DisplayBackpressureError{"window retired"}
	}
	if g.failure != "" {
		return 0, &DisplayBackpressureError{g.failure}
	}
	if g.epoch == math.MaxUint64 {
		g.failLocked("admission epoch exhausted")
		return 0, &DisplayBackpressureError{g.failure}
	}
	g.epoch++
	if g.active != 0 {
		g.dirty = true
		return 0, errDisplayPending
	}
	if g.issued == math.MaxUint64 {
		g.failLocked("admission identity exhausted")
		return 0, &DisplayBackpressureError{g.failure}
	}
	g.issued++
	g.active = g.issued
	g.cpuFinished = false
	g.dirty = false
	credit := g.active
	g.timer = time.AfterFunc(g.timeout, func() { g.expire(credit) })
	return credit, nil
}

// expire never returns a live native credit. It latches failure and wakes the
// owner so the diagnostic can refuse; only close revokes an unacknowledged one.
func (g *displayGate) expire(credit uint64) {
	g.mu.Lock()
	notify := !g.closed && g.active == credit
	if notify {
		g.failLocked("presentation deadline exceeded")
		if g.timer != nil {
			g.timer.Stop()
			g.timer = nil
		}
	}
	g.mu.Unlock()
	if notify {
		g.wake()
	}
}
func (g *displayGate) retireLocked() bool {
	if !g.cpuFinished || g.nativePending != 0 {
		return false
	}
	if g.timer != nil {
		g.timer.Stop()
		g.timer = nil
	}
	g.retired = g.active
	g.active = 0
	return g.dirty || g.failure != ""
}
func (g *displayGate) finish(credit uint64) {
	if credit == 0 {
		return
	}
	g.mu.Lock()
	if g.closed || credit != g.active {
		g.mu.Unlock()
		return
	}
	g.cpuFinished = true
	notify := g.retireLocked()
	g.mu.Unlock()
	if notify {
		g.wake()
	}
}

// acquire runs BEFORE nextDrawable. A second live native acquisition is refused
// before entering Metal, including another acquisition in the same CPU batch.
func (g *displayGate) acquire(credit uint64) uint64 {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.closed || g.failure != "" || credit == 0 || credit != g.active || g.cpuFinished {
		return 0
	}
	if g.nativePending != 0 {
		g.failLocked("overlapping drawable acquisition refused")
		return 0
	}
	if g.nextNative == math.MaxUint64 {
		g.failLocked("drawable identity exhausted")
		return 0
	}
	g.nextNative++
	g.nativePending = g.nextNative
	return g.nativePending
}
func (g *displayGate) unavailable(sequence uint64) {
	g.complete(sequence, 1, true)
}
func (g *displayGate) complete(sequence uint64, at float64, unavailable bool) {
	g.mu.Lock()
	if g.closed || sequence == 0 || sequence != g.nativePending {
		g.mu.Unlock()
		return
	}
	// Zero presentedTime is a terminal skipped record, never display success.
	// It frees native ownership but permanently refuses this experimental gate.
	if !unavailable && (at <= 0 || math.IsNaN(at) || math.IsInf(at, 0)) {
		g.failLocked("drawable was not presented")
	}
	g.nativePending = 0
	notify := g.retireLocked()
	g.mu.Unlock()
	if notify {
		g.wake()
	}
}
func (g *displayGate) close() {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.closed {
		return
	}
	g.closed = true
	close(g.refusals)
	g.retired = g.issued
	g.active = 0
	g.nativePending = 0
	g.dirty = false
	if g.timer != nil {
		g.timer.Stop()
		g.timer = nil
	}
}

// The registry is reused for bounded scalar token lookup; the diagnostic
// presentation observer retains its independent subscription and sequence.
var displayRegistry nativePresentationRegistry

func (*displayGate) Receipt(uint64, float64)                    {}
func (*displayGate) Acquired(PresentationFrame, float64) uint64 { return 0 }
func (*displayGate) Unavailable(PresentationFrame, float64)     {}
func (g *displayGate) Presented(sequence, _ uint64, at float64) { g.complete(sequence, at, false) }
func (g *displayGate) Closed()                                  { g.close() }

// DisplayBackpressureRefusals delivers at most the first typed terminal failure,
// even when no FrameTrace is active. The stream closes on window retirement.
func (w *Window) DisplayBackpressureRefusals() <-chan error {
	if w != nil {
		if g := w.displayGate.Load(); g != nil {
			return g.refusals
		}
	}
	return nil
}

// RetireDisplayBackpressure cancels the opt-in experiment without waiting for a
// native callback. It never permits enabling again on the same window.
func (w *Window) RetireDisplayBackpressure()       { w.retireDisplayBackpressure() }
func (w *Window) DisplayBackpressureEnabled() bool { return w != nil && w.displayGate.Load() != nil }
func (w *Window) DisplayBackpressureSnapshot() DisplayBackpressureStatus {
	if w != nil {
		if g := w.displayGate.Load(); g != nil {
			return g.status()
		}
	}
	return DisplayBackpressureStatus{}
}
func (w *Window) AdmitDisplayFrame() (uint64, error) {
	if w == nil {
		return 0, &DisplayBackpressureError{"nil window"}
	}
	if g := w.displayGate.Load(); g != nil {
		return g.admit()
	}
	return 0, nil
}
func (w *Window) FinishDisplayFrame(credit uint64) {
	if w != nil {
		if g := w.displayGate.Load(); g != nil {
			g.finish(credit)
		}
	}
}
func (w *Window) retireDisplayBackpressure() {
	if w == nil {
		return
	}
	if g := w.displayGate.Load(); g != nil {
		g.close()
	}
	displayRegistry.close(w.displayToken.Swap(0))
}
func displayGateForToken(token uint64) *displayGate {
	if s := displayRegistry.lookup(token); s != nil && !s.closed.Load() {
		g, _ := s.observer.(*displayGate)
		return g
	}
	return nil
}
func displayFailure(reason string) error { return &DisplayBackpressureError{reason} }
