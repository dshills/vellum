//go:build !darwin

// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package desktop

import "time"

func (*Window) EnableDisplayBackpressure(time.Duration) error {
	return displayFailure("experiment requires macOS")
}
func (*Window) BeginDisplayFrame() {}
func (*Window) EndDisplayFrame()   {}
