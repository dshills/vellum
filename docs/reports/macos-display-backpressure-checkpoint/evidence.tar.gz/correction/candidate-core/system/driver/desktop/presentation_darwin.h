// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
#ifndef VELLUM_PRESENTATION_DARWIN_H
#define VELLUM_PRESENTATION_DARWIN_H
#include <stdint.h>
void *vellumNewPresentationLayer(void);
void vellumPresentationObserver(void *layer, uint64_t token);
void vellumPresentationFrame(void *layer, uint64_t tag, uint64_t generation, uint64_t composition, int armed);
void vellumPresentationReceipt(void *layer, uint64_t tag);
int vellumDisplayBackpressure(void *layer, uint64_t token);
void vellumDisplayFrame(void *layer, uint64_t credit);
double vellumPresentationHostTime(void);
int vellumPresentationAvailable(void);
#endif
