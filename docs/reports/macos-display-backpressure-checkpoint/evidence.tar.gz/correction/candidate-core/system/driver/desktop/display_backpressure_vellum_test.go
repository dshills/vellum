// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
package desktop

import (
	"errors"
	"math"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func displayGateFixture(t *testing.T) (*displayGate, *atomic.Int64) {
	t.Helper()
	wake := new(atomic.Int64)
	g, err := newDisplayGate(5*time.Second, func() { wake.Add(1) })
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(g.close)
	return g, wake
}
func displayAdmit(t *testing.T, g *displayGate) uint64 {
	t.Helper()
	c, err := g.admit()
	if err != nil || c == 0 {
		t.Fatal(c, err)
	}
	return c
}
func displayPending(t *testing.T, g *displayGate) {
	t.Helper()
	if c, err := g.admit(); c != 0 || !errors.Is(err, errDisplayPending) {
		t.Fatal("second batch was admitted", c, err)
	}
}
func TestVellumDisplayBackpressureWaitsForAsynchronousPresentation(t *testing.T) {
	g, wake := displayGateFixture(t)
	credit := displayAdmit(t, g)
	native := g.acquire(credit)
	if native == 0 {
		t.Fatal("no native reservation")
	}
	g.finish(credit)
	for range 64 {
		displayPending(t, g)
	}
	if s := g.status(); s.Active != credit || s.NativePending != native || !s.CPUFinished || !s.Dirty || wake.Load() != 0 {
		t.Fatalf("CPU completion freed display ownership: %+v", s)
	}
	release := make(chan struct{})
	done := make(chan struct{})
	go func() { defer close(done); <-release; g.complete(native, 1, false) }()
	close(release)
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("asynchronous acknowledgement blocked")
	}
	if s := g.status(); s.Active != 0 || s.NativePending != 0 || s.Retired != credit || wake.Load() != 1 {
		t.Fatalf("lost or duplicate dirty wake: %+v wakes%d", s, wake.Load())
	}
	next := displayAdmit(t, g)
	if next <= credit {
		t.Fatal("batch identity reused")
	}
	g.finish(next)
}
func TestVellumDisplayBackpressurePresentationBeforeCPUEnd(t *testing.T) {
	g, _ := displayGateFixture(t)
	credit := displayAdmit(t, g)
	seq := g.acquire(credit)
	g.complete(seq, 1, false)
	displayPending(t, g)
	if g.status().Active != credit {
		t.Fatal("callback freed live CPU batch")
	}
	g.finish(credit)
	if g.status().Active != 0 {
		t.Fatal("CPU end lost earlier native acknowledgement")
	}
}
func TestVellumDisplayBackpressureUnavailableRetryAndStaleCompletion(t *testing.T) {
	g, _ := displayGateFixture(t)
	credit := displayAdmit(t, g)
	first := g.acquire(credit)
	g.unavailable(first)
	second := g.acquire(credit)
	if first == 0 || second <= first {
		t.Fatal("retry identity reused")
	}
	g.complete(first, 1, false)
	g.finish(credit)
	if g.status().NativePending != second {
		t.Fatal("stale callback retired newer retry")
	}
	g.complete(second, 1, false)
	if g.status().Active != 0 {
		t.Fatal("retry did not retire")
	}
}
func TestVellumDisplayBackpressureRefusesOverlappingNativeAcquisition(t *testing.T) {
	g, _ := displayGateFixture(t)
	credit := displayAdmit(t, g)
	seq := g.acquire(credit)
	if g.acquire(credit) != 0 {
		t.Fatal("second live drawable entered Metal")
	}
	g.finish(credit)
	if s := g.status(); s.NativePending != seq || s.Failure == "" {
		t.Fatalf("overlap refusal lost live identity: %+v", s)
	}
	g.complete(seq, 1, false)
	_, err := g.admit()
	var refused *DisplayBackpressureError
	if !errors.As(err, &refused) {
		t.Fatal("overlap failure was reset", err)
	}
}
func TestVellumDisplayBackpressureUnusedBatchRetiresWithoutNativeCallback(t *testing.T) {
	g, wake := displayGateFixture(t)
	credit := displayAdmit(t, g)
	g.finish(credit)
	g.finish(credit)
	if s := g.status(); s.Active != 0 || s.Retired != credit || s.NativePending != 0 || wake.Load() != 0 {
		t.Fatalf("unchanged batch leaked or woke: %+v", s)
	}
	next := displayAdmit(t, g)
	g.finish(next)
}
func TestVellumDisplayBackpressureSkippedCallbackRefusesRatherThanSucceeds(t *testing.T) {
	for _, at := range []float64{0, math.NaN(), math.Inf(1)} {
		t.Run("invalid-display-time", func(t *testing.T) {
			g, _ := displayGateFixture(t)
			credit := displayAdmit(t, g)
			seq := g.acquire(credit)
			g.finish(credit)
			g.complete(seq, at, false)
			if s := g.status(); s.NativePending != 0 || s.Active != 0 || s.Failure == "" {
				t.Fatalf("skipped frame misclassified: %+v", s)
			}
			if c, err := g.admit(); c != 0 || err == nil {
				t.Fatal("skipped callback allowed another batch")
			}
		})
	}
}
func TestVellumDisplayBackpressureLostCallbackNeverReleasesLiveToken(t *testing.T) {
	g, wake := displayGateFixture(t)
	credit := displayAdmit(t, g)
	seq := g.acquire(credit)
	g.finish(credit)
	g.expire(credit)
	if s := g.status(); s.Active != credit || s.NativePending != seq || s.Failure == "" || wake.Load() != 1 {
		t.Fatalf("deadline guessed native retirement: %+v", s)
	}
	if c, err := g.admit(); c != 0 || err == nil {
		t.Fatal("timeout readmitted a live frame")
	}
	g.complete(seq, 1, false)
	if g.status().Active != 0 {
		t.Fatal("late actual callback did not retire ownership")
	}
	if c, err := g.admit(); c != 0 || err == nil {
		t.Fatal("late callback reset failure latch")
	}
}
func TestVellumDisplayBackpressureCloseRevokesLateCallbacks(t *testing.T) {
	g, wake := displayGateFixture(t)
	credit := displayAdmit(t, g)
	seq := g.acquire(credit)
	displayPending(t, g)
	g.close()
	before := g.status()
	g.finish(credit)
	g.complete(seq, 1, false)
	g.unavailable(seq)
	g.expire(credit)
	if after := g.status(); after != before || after.Active != 0 || !after.Closed || wake.Load() != 0 {
		t.Fatalf("late callback changed retired state: %+v -> %+v", before, after)
	}
	if c, err := g.admit(); c != 0 || err == nil {
		t.Fatal("closed window readmitted")
	}
}
func TestVellumDisplayBackpressureRegistryDoesNotCreditReusedWindow(t *testing.T) {
	var registry nativePresentationRegistry
	first, _ := displayGateFixture(t)
	old, err := registry.register(first)
	if err != nil {
		t.Fatal(err)
	}
	registry.close(old)
	next, _ := displayGateFixture(t)
	token, err := registry.register(next)
	if err != nil || token <= old {
		t.Fatal(token, err)
	}
	defer registry.close(token)
	credit := displayAdmit(t, next)
	seq := next.acquire(credit)
	next.finish(credit)
	registry.presented(old, seq, 0, 1)
	if next.status().NativePending != seq {
		t.Fatal("old subscription released replacement window")
	}
	registry.presented(token, seq, 0, 1)
	if next.status().Active != 0 {
		t.Fatal("replacement callback lost")
	}
}
func TestVellumDisplayBackpressureConcurrentDirtyAndCompletion(t *testing.T) {
	g, wake := displayGateFixture(t)
	credit := displayAdmit(t, g)
	seq := g.acquire(credit)
	var wg sync.WaitGroup
	for range 64 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if c, err := g.admit(); c != 0 || err == nil {
				t.Error("duplicate admitted")
			}
		}()
	}
	wg.Wait()
	wg.Add(2)
	go func() { defer wg.Done(); g.finish(credit) }()
	go func() { defer wg.Done(); g.complete(seq, 1, false) }()
	wg.Wait()
	if s := g.status(); s.Active != 0 || s.Retired != credit || s.NativePending != 0 || wake.Load() != 1 {
		t.Fatalf("completion race lost/coalesced incorrectly: %+v wakes%d", s, wake.Load())
	}
}
func TestVellumDisplayBackpressureIdentityBoundsRefuseWithoutWrapping(t *testing.T) {
	g, _ := displayGateFixture(t)
	g.issued = math.MaxUint64
	if c, err := g.admit(); c != 0 || err == nil {
		t.Fatal("batch sequence wrapped")
	}
	other, _ := displayGateFixture(t)
	credit := displayAdmit(t, other)
	other.nextNative = math.MaxUint64
	if other.acquire(credit) != 0 || other.status().Failure == "" {
		t.Fatal("native sequence wrapped")
	}
}
func TestVellumDisplayBackpressureRequiresBoundedTimeoutAndMailbox(t *testing.T) {
	for _, timeout := range []time.Duration{0, -1, 99 * time.Millisecond, 6 * time.Second} {
		if _, err := newDisplayGate(timeout, func() {}); err == nil {
			t.Fatal("unbounded timeout admitted", timeout)
		}
	}
	if _, err := newDisplayGate(time.Second, nil); err == nil {
		t.Fatal("missing owner wake accepted")
	}
}

func TestVellumDisplayBackpressureUntypedFrameAbsenceStillReportsFailure(t *testing.T) {
	g, _ := displayGateFixture(t)
	credit := displayAdmit(t, g)
	seq := g.acquire(credit)
	g.finish(credit)
	g.expire(credit)
	g.expire(credit)
	select {
	case err := <-g.refusals:
		var failure *DisplayBackpressureError
		if !errors.As(err, &failure) {
			t.Fatal("missing typed refusal", err)
		}
	default:
		t.Fatal("no refusal without FrameTrace")
	}
	select {
	case err := <-g.refusals:
		t.Fatal("duplicate terminal refusal", err)
	default:
	}
	if g.status().NativePending != seq {
		t.Fatal("reporting guessed native retirement")
	}
	g.close()
	select {
	case _, ok := <-g.refusals:
		if ok {
			t.Fatal("refusal stream not retired")
		}
	default:
		t.Fatal("retirement left monitor blocked")
	}
}

func TestVellumDisplayBackpressureOldBatchCannotRetireReplacement(t *testing.T) {
	g, _ := displayGateFixture(t)
	old := displayAdmit(t, g)
	first := g.acquire(old)
	g.finish(old)
	g.complete(first, 1, false)
	next := displayAdmit(t, g)
	second := g.acquire(next)
	before := g.status()
	g.finish(old)
	g.complete(first, 1, false)
	g.unavailable(first)
	g.expire(old)
	if after := g.status(); after != before {
		t.Fatalf("stale completion changed newer batch: %+v -> %+v", before, after)
	}
	g.finish(next)
	g.complete(second, 1, false)
}
