# Bounded headless checks awaiting root admission

`check.py` reuses the exact owned executor used by the empty-publication checks. No execution has occurred. The frozen candidate proposal and independent source review remain unchanged.

After source review, materialize the actual post-Q plan with:

```
/opt/homebrew/bin/python3 -B check.py prepare
```

Preparation reads complete clean C/T source and prepared maps at head68358cb7de98df40bfa353a5926793069845cc2d and the immutable actual70bf391 SDK. It ignores the old prospective5911 count. It writes only plan metadata; no clone, stage application, tests or build runs. Root must then write admission.json with approved:true, the exact plan_sha256 and controller_sha256 before:

```
/opt/homebrew/bin/python3 -B check.py run
```

The first three owned phases are scratch-stage reproduction, the27 Python validator controls and focused Core display-gate/registry race tests. Remaining phases cover actual ManualWindow software composition plus existing paint/lifetime races; a behavioral original103 negative; Core vet; driver offscreen race/vet; loadedgrid/tree race/vet; actual module graphs; Darwin driver-library and demo executable builds; and optimized Go metadata. The driver suite retains E's900s Go timeout/960s watchdog; other phases are at most330s and all streams cap at8MiB. Stop on the first unexpected result and retain the failed scope.

The scratch source is a clone of the existing verified SDK with exact Q+104 candidate edits, explicitly a modified test workspace. Its retained manifest is not a release assertion and is not passed to check-sdk. Original C/T/SDK and candidate/recipe/controller inputs are write-denied. The separate negative Core copies original103 plus only the3 new Core integration tests; failure must be behavioral with all3 expected markers, never a compile failure or data race.

Driver uses all8 actual SDK local replacements; demos use9 including the Driver module. Core and its negative use narrow alternative modfiles with the same local typesetter and all5 native shims. Every module graph and optimized executable metadata must resolve into this scratch tree. Darwin archive must hash786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883.

Flags-only cancellation, final stop checks after complete scans, owned group retirement and before/after full source/prepared/SDK boundaries are retained. Hash reuse requires identical regular-file device/inode/size/mtime/ctime; changed identity is rehashed. The previously owned `/private/tmp/vellum-macapps-go-cache` is reused for ordinary count1 checks; no cold-cache compile claim. Temp/build outputs are separate and writable. The reviewed IP-denial profile permits Unix-domain IPC needed by existing automation tests. The driver native build is a Go library artifact; only grid/tree outputs are executables and receive optimized metadata inspection. No application executable, NSApp/window, native input, performance run or provider is launched. A future genuine native watchdog-refusal/Driver.Run close-and-join check is still needed; fake monitors do not establish it. Startup drainage remains separate.
