"""Prospective owned headless checks; prepare binds current clean post-Q inputs.
No import-time setup, builds, tests, native launch, source mutation or admission.
"""
from pathlib import Path
import contextlib,datetime,hashlib,importlib.util,io,json,os,re,shutil,signal,subprocess,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;W=H.parent;X=W.parent
C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
HEAD='68358cb7de98df40bfa353a5926793069845cc2d'
GO=Path('/Users/dshills/Development/Go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin/go')
PY=Path('/opt/homebrew/bin/python3').resolve();GUARD=X/'macos-sdk-native-238b3b6/run.py'
SDK_BINDING=X/'macos-presentation-after-empty-publication/binding.json'
RECEIPT=X/'macos-deep-origin-status-checkpoint/commit-result.json'
PROPOSAL_SHA='2c153f8551508bd62951606f05b21aff8adb8b93a9c99d1af1f8a00398de040f'
ROOT=Path('/private/tmp/vellum-display-backpressure-headless-68358cb');SRC=ROOT/'source';NEG=ROOT/'negative-core';MOD=ROOT/'modfiles';OUT=H/'checks'
cache={}
stop=[False]
def flag(*_):stop[0]=True
def stopping():return stop[0]or(H/'stop-checks').exists()
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):
 p=Path(p);before=p.lstat();need(p.is_file()and not p.is_symlink(),'regular pinned input')
 stamp=(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)
 if str(p)in cache and cache[str(p)][0]==stamp:return cache[str(p)][1]
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 after=p.lstat();need(stamp==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'input changed while hashing')
 cache[str(p)]=(stamp,h.hexdigest());return h.hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def write(p,v):
 with Path(p).open('x')as f:f.write(json.dumps(v,indent=2,allow_nan=False)+'\n')
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def vector(root):
 out={}
 for f in root.rglob('*'):
  need(not f.is_symlink(),'source symlink')
  if f.is_file():out[f.relative_to(root).as_posix()]=sha(f)
 return out
def identity(root):
 git=lambda *a:subprocess.check_output(['git',*a],cwd=root,timeout=30)
 need(git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-z'),'clean exact post-Q source')
 names=git('ls-files','-z').decode().split('\0')[:-1]
 need(0<len(names)<20000,'source bound')
 need(all((root/n).is_file()and not(root/n).is_symlink()for n in names),'regular tracked files')
 return {n:sha(root/n)for n in names}
def passed(r):
 return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def boundary(p,scratch=False):
 need(identity(C)==identity(T)==p['source'],'complete C/T source drift')
 for r in [C,T]:need({d+'/'+n:h for d in ['upstream','typesetting']for n,h in vector(r/'drivers/cogent/build'/d).items()}==p['prepared'],'complete prepared drift')
 need(vector(Path(p['sdk_root']))==p['sdk'],'historical SDK drift')
 need(all(Path(k).is_file()and not Path(k).is_symlink()and sha(k)==v for k,v in p['pins'].items()),'pinned controller/candidate input drift')
 if scratch:
  state=read(H/'scratch.json')
  for key,root in [('source',SRC),('negative',NEG),('modfiles',MOD)]:need(vector(root)==state[key],'immutable scratch drift '+key)
 need(not stopping(),'stop after complete boundary scan')
def prepare():
 need(not(H/'plan.json').exists()and not ROOT.exists(),'fresh scope')
 proposal=read(W/'proposal.json');need(sha(W/'proposal.json')==PROPOSAL_SHA,'frozen candidate')
 need(read(RECEIPT)['head']==HEAD and read(RECEIPT)['clean_C_T'],'post-Q receipt')
 source=identity(C);need(identity(T)==source and len(source)==read(RECEIPT)['source_files'],'whole current source parity')
 prepared={d+'/'+n:h for d in ['upstream','typesetting']for n,h in vector(T/'drivers/cogent/build'/d).items()}
 need({n.removeprefix('upstream/'):h for n,h in prepared.items()if n.startswith('upstream/')}==read(W/'baseline-vector.json'),'Core103 candidate preimage')
 b=read(SDK_BINDING);sdk=Path(b['sdk']);need(vector(sdk)==b['sdk_files'],'historical native-library SDK unchanged')
 pins={**proposal['inputs'],str(W/'proposal.json'):PROPOSAL_SHA,str(W/'independent-review.json'):sha(W/'independent-review.json')}
 pins.update({str(p):sha(p)for p in [Path(__file__),RECEIPT,SDK_BINDING,GO,PY,GUARD,T/'drivers/cogent/prepare.py',T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]})
 expected=read(W/'adapter-preimages.json')
 for n,e in expected.items():
  if e:need(source.get(n)==e['sha256'],'post-Q public preimage '+n)
  else:need(n not in source,'new path already exists '+n)
 plan={'head':HEAD,'source':source,'prepared':prepared,'sdk_root':str(sdk),'sdk':b['sdk_files'],'sdk_scope':'Immutable historical source70bf391 SDK cloned to a modified test workspace. Candidate includes exact Q validator correction. Original manifest is not valid for modified clone; no SDK release/checker claim.','pins':pins,'commands':commands(),'scratch_root':str(ROOT),'candidate_proposal_sha256':PROPOSAL_SHA,'replay_core_files':6029,'source_count_claim':'Derived from complete clean post-Q source; ignores historical prospective5911 candidate count.','native_execution':False,'execution_ready':False,'compiler_cache':'/private/tmp/vellum-macapps-go-cache','compiler_cache_scope':'Reuses the previously owned cache for ordinary count1 checks; no cold-cache compile or performance claim.'}
 boundary(plan);write(H/'plan.json',plan)
 print(json.dumps({'plan_sha256':sha(H/'plan.json'),'source':len(source),'prepared':len(prepared),'phases':len(plan['commands']),'checks_executed':False}))
def stage(p):
 need(not SRC.exists()and not NEG.exists()and not MOD.exists(),'fresh scratch sources')
 shutil.copytree(Path(p['sdk_root']),SRC)
 need(vector(SRC/'drivers/cogent/build/upstream')==read(W/'baseline-vector.json'),'SDK Core103 preimage')
 shutil.copytree(SRC/'drivers/cogent/build/upstream',NEG)
 test='core/display_backpressure_vellum_test.go';shutil.copyfile(W/'candidate-core'/test,NEG/test)
 for n,h in read(W/'adapter-files.json').items():
  need(not stopping(),'stage cancelled')
  f=W/'adapter-candidate'/n;need(sha(f)==h,'public candidate copy');d=SRC/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,d)
 m=load('prospective_stage104_prepare',T/'drivers/cogent/prepare.py');m.ROOT=SRC/'drivers/cogent'
 m.apply_stage(read(W/'recipe/stage-0104.json'),SRC/'drivers/cogent/build/upstream')
 need(vector(SRC/'drivers/cogent/build/upstream')==read(W/'candidate-vector.json'),'exact full6029Core replay')
 # All SDK local native shims remain in the clone; Core standalone checks
 # use bounded modfiles with the same five local modules and pinned typesetter.
 need(sha(SRC/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')=='786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883','owned archive')
 MOD.mkdir()
 for name,root in [('core',SRC/'drivers/cogent/build/upstream'),('negative',NEG)]:
  text=(root/'go.mod').read_text()
  pattern=r'(?m)^replace github.com/go-text/typesetting => [^\n]+'
  need(len(re.findall(pattern,text))==1,'single Core typesetting replacement')
  text=re.sub(pattern,lambda _: 'replace github.com/go-text/typesetting => '+json.dumps(str(SRC/'drivers/cogent/build/typesetting')),text)
  for platform in ['android','darwin','ios','linux','windows']:
   text+='\nreplace github.com/oliverbestmann/webgpu/libs-'+platform+' => '+json.dumps(str(SRC/('drivers/cogent/build/libs-'+platform)))+'\n'
  (MOD/(name+'.mod')).write_text(text);shutil.copyfile(root/'go.sum',MOD/(name+'.sum'))
 state={'source':vector(SRC),'negative':vector(NEG),'modfiles':vector(MOD),'Core104_replayed':True,'core_files':6029,'native_runtime':False,'scope':'Modified verified SDK clone; manifest deliberately not validated as release SDK.'}
 write(H/'scratch.json',state)
def commands():
 core=SRC/'drivers/cogent/build/upstream';driver=SRC/'drivers/cogent';g=SRC/'examples/loadedgrid';t=SRC/'examples/loadedtree'
 phases=[{'id':'stage','cwd':str(H),'argv':[str(PY),'-B',str(Path(__file__)),'stage'],'timeout':180}]
 def go(name,cwd,module,args,timeout=330):phases.append({'id':name,'cwd':str(cwd),'argv':[str(GO),*args[:1],*(['-modfile',str(MOD/(module+'.mod'))]if module in ['core','negative']else[]),*args[1:]],'timeout':timeout})
 test=['test','-v','-race','-count=1','-p=1','-tags=offscreen','-timeout=240s']
 go('core-gate-race',core,'core',test+['./system/driver/desktop','-run','^TestVellum(DisplayBackpressure|PresentationRegistry|WindowComposer)'])
 go('core-integration-race',core,'core',test+['./core','-run','^Test(Vellum(DisplayAdmission|Busy|Manual)|CompositionWaits|InlineComposition|IdleBarrier)'])
 go('negative-original',NEG,'negative',test+['./core','-run','^TestVellumDisplayAdmission'])
 go('core-vet',core,'core',['vet','-p=1','-tags=offscreen','./core','./system/driver/desktop'])
 go('driver-race',driver,'driver',['test','-v','-race','-count=1','-p=1','-tags=offscreen','-timeout=900s','.'],960)
 go('driver-vet',driver,'driver',['vet','-p=1','-tags=offscreen','./...'])
 for name,cwd in [('grid',g),('tree',t)]:
  go(name+'-race',cwd,name,test+['./...']);go(name+'-vet',cwd,name,['vet','-p=1','-tags=offscreen','./...'])
 phases.append({'id':'validator','cwd':str(SRC),'argv':[str(PY),'-B',str(SRC/'scripts/check_presentation_test.py'),'-v'],'timeout':60})
 for name,cwd in [('driver',driver),('grid',g),('tree',t)]:
  go(name+'-module-graph',cwd,name,['list','-m','-json','all'],60)
  go(name+'-native-build',cwd,name,['build','-p=1','-o',str(ROOT/'binaries'/('native-'+name)),'.'])
  if name!='driver':phases.append({'id':name+'-metadata','cwd':str(cwd),'argv':[str(GO),'version','-m',str(ROOT/'binaries'/('native-'+name))],'timeout':60})
 phases.insert(1,phases.pop(next(i for i,v in enumerate(phases)if v['id']=='validator')))
 return phases
def expected_modules(kind):
 modules={'cogentcore.org/core':SRC/'drivers/cogent/build/upstream','github.com/dshills/vellum':SRC,'github.com/dshills/vellum/drivers/cogent':SRC/'drivers/cogent','github.com/go-text/typesetting':SRC/'drivers/cogent/build/typesetting',**{'github.com/oliverbestmann/webgpu/libs-'+n:SRC/('drivers/cogent/build/libs-'+n)for n in ['android','darwin','ios','linux','windows']}}
 if kind=='driver':del modules['github.com/dshills/vellum/drivers/cogent']
 return modules
def verify_graph(kind,raw):
 decoder=json.JSONDecoder();items=[];text=raw.decode()
 while text.strip():
  text=text.lstrip();value,end=decoder.raw_decode(text);items.append(value);text=text[end:]
 modules={v['Path']:Path(v['Replace']['Dir']).resolve()for v in items if 'Replace'in v}
 need(modules==expected_modules(kind),'actual local module graph differs')
 main=[v for v in items if v.get('Main')];need(len(main)==1 and Path(main[0]['Dir']).resolve()==(SRC/'drivers/cogent'if kind=='driver'else SRC/'examples'/('loaded'+kind)),'actual module main differs')
 return {k:str(v)for k,v in modules.items()}
def verify_metadata(kind,raw):
 binary=ROOT/'binaries'/('native-'+kind);text=raw.decode();need(text.splitlines()[0]==str(binary)+': go1.25.6','actual optimized compiler identity')
 settings={};modules={};dep=None;cwd=SRC/'examples'/('loaded'+kind)
 for line in text.splitlines():
  if line.startswith('\tbuild\t'):
   k,_,v=line[len('\tbuild\t'):].partition('=');need(k not in settings,'duplicate build setting');settings[k]=v
  if line.startswith('\tdep\t'):dep=line.split('\t')[2]
  elif line.startswith('\t=>\t'):
   parts=line.split('\t');need(dep is not None and dep not in modules and parts[3]=='(devel)','unique local module attachment');modules[dep]=(cwd/parts[2]).resolve();dep=None
  else:dep=None
 need(modules==expected_modules(kind),'optimized binary module roots differ')
 need(settings.get('GOOS')=='darwin'and settings.get('GOARCH')=='arm64'and settings.get('CGO_ENABLED')=='1'and settings.get('-race')!='true'and 'offscreen'not in settings.get('-tags','')and '-N'not in settings.get('-gcflags','')and '-l'not in settings.get('-gcflags',''),'optimized Darwin build settings differ')
 return {'settings':settings,'local_replacements':{k:str(v)for k,v in modules.items()},'binary_sha256':sha(binary)}
def run():
 p=read(H/'plan.json');admit=read(H/'admission.json');need(admit['approved']is True and admit['plan_sha256']==sha(H/'plan.json')and admit['controller_sha256']==sha(__file__),'root exact plan/source admission')
 need(not(H/'result.json').exists()and not(H/'stop-checks').exists()and not ROOT.exists(),'fresh admitted run')
 write(H/'running.json',{'owner_pid':os.getpid(),'plan_sha256':sha(H/'plan.json'),'admission_sha256':sha(H/'admission.json'),'controller_sha256':sha(__file__)})
 ROOT.mkdir();(ROOT/'tmp').mkdir();(ROOT/'binaries').mkdir();OUT.mkdir()
 guard=load('existing_empty_publication_owned_executor',GUARD)
 env=guard.child_environment();env.update(PATH=str(GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=str(GO.parents[1]),GOTOOLCHAIN='local',GOENV='off',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOPATH='/Users/dshills/Development/Go',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod',GOMAXPROCS='2',CGO_ENABLED='1',GOCACHE=p['compiler_cache'],TMPDIR=str(ROOT/'tmp'),GOFLAGS='-mod=readonly',CGO_CFLAGS='',CGO_CPPFLAGS='',CGO_CXXFLAGS='',CGO_LDFLAGS='',PYTHONDONTWRITEBYTECODE='1')
 guard.child_environment=lambda *a,**k:env.copy()
 runtime={str(H/n):sha(H/n)for n in ['plan.json','admission.json','running.json']};result={'result':'INCOMPLETE','head':HEAD,'commands':{},'native_executed':False,'error':None}
 def stable(scratch):
  boundary(p,scratch);return all(sha(k)==v for k,v in runtime.items())and not stopping()
 try:
  for item in p['commands']:
   before=item['id']!='stage';need(stable(before),'initial runtime/source pins')
   protected=[C,T,Path(p['sdk_root']),Path('/Users/dshills/Library/Cogent Core'),W/'candidate-core',W/'adapter-candidate',W/'baseline',W/'history',W/'recipe',*[Path(v)for v in p['pins']],*[Path(v)for v in runtime]]
   if before:protected += [SRC,NEG,MOD,H/'scratch.json']
   if item['id'].endswith('-metadata'):protected.append(ROOT/'binaries')
   profile='(version 1)(allow default)(deny network* (remote ip) (local ip))'+''.join('(deny file-write* (subpath '+json.dumps(str(v))+'))'for v in protected)
   r=guard.execute(['/usr/bin/sandbox-exec','-p',profile,*item['argv']],item['cwd'],OUT/item['id'],stopping,lambda:stable(before),timeout=item['timeout'],limit=8<<20)
   r.update(candidate_proposal_sha256=PROPOSAL_SHA,plan_sha256=sha(H/'plan.json'),source_pins=p['pins'],native_executed=False,boundary_stable=False)
   try:boundary(p,True);r['boundary_stable']=True
   except BaseException as e:r['boundary_error']={'type':type(e).__name__,'message':str(e)}
   acceptable=passed(r)
   raw=(OUT/item['id']/'stdout').read_bytes()+(OUT/item['id']/'stderr').read_bytes()
   if item['id']=='negative-original':
    neutral={**r,'exit_code':0};acceptable=r['exit_code']==1 and passed(neutral)and b'build failed'not in raw and b'DATA RACE'not in raw and all(s in raw for s in [b'CPU completion lost native reservation',b'unchanged pass leaked display reservation',b'early resize/cache path bypassed pending display admission'])
   if item['id']=='validator':acceptable=acceptable and b'Ran 27 tests'in raw and raw.rstrip().endswith(b'OK')
   try:
    if item['id'].endswith('-module-graph'):r['actual_local_modules']=verify_graph(item['id'].split('-')[0],(OUT/item['id']/'stdout').read_bytes())
    if item['id'].endswith('-metadata'):r['actual_optimized_metadata']=verify_metadata(item['id'].split('-')[0],(OUT/item['id']/'stdout').read_bytes())
    if item['id'].endswith('-native-build'):
     kind=item['id'].split('-')[0];binary=ROOT/'binaries'/('native-'+kind);need(binary.is_file()and not binary.is_symlink()and binary.stat().st_size<=256<<20,'regular bounded build artifact');r['build_artifact']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary),'kind':'Darwin driver library'if kind=='driver'else'optimized Darwin executable, not executed'}
   except BaseException as e:acceptable=False;r['artifact_validation_error']={'type':type(e).__name__,'message':str(e)}
   r['expected_outcome_passed']=acceptable and r['boundary_stable'];write(OUT/(item['id']+'.json'),r);result['commands'][item['id']]={'receipt_sha256':sha(OUT/(item['id']+'.json')),'expected_outcome_passed':r['expected_outcome_passed']}
   need(r['expected_outcome_passed'],'owned headless phase failed '+item['id']);need(stable(True),'post-command stop/inputs')
   print(json.dumps({'id':item['id'],'seconds':r['seconds'],'passed':True,'group_absent':r['owned']['group_absent']}),flush=True)
  result['result']='PASS_SCOPED_HEADLESS_CHECKS'
 except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  try:boundary(p,(H/'scratch.json').exists())
  except BaseException as e:result.update(result='FAILED_OR_CANCELED',final_boundary_error={'type':type(e).__name__,'message':str(e)})
  (H/'stop-checks').touch();write(H/'result.json',result)
 need(result['result']=='PASS_SCOPED_HEADLESS_CHECKS','headless run failed; all evidence retained')
if __name__=='__main__':
 need(Path(sys.executable).resolve()==PY,'use the pinned Homebrew Python interpreter')
 need(sys.argv[1:]in [['prepare'],['run'],['stage']],'fixed phase')
 old={s:signal.signal(s,flag)for s in[signal.SIGTERM,signal.SIGINT]}
 try:
  if sys.argv[1]=='prepare':prepare()
  elif sys.argv[1]=='stage':
   admitted=read(H/'admission.json');running=read(H/'running.json')
   need(admitted['approved']is True and admitted['plan_sha256']==sha(H/'plan.json')and admitted['controller_sha256']==sha(__file__),'admitted stage only')
   need(os.getpid()==os.getpgrp()and os.getppid()==running['owner_pid']and running['controller_sha256']==sha(__file__)and running['admission_sha256']==sha(H/'admission.json'),'owned stage child')
   stage(read(H/'plan.json'))
  else:run()
 finally:
  for s,f in old.items():signal.signal(s,f)
