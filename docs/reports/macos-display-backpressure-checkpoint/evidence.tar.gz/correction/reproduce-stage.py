"""Prospective artifact-only stage104 replay; do not run until root admission."""
from pathlib import Path
import hashlib,json,shutil,importlib.util,contextlib,io
W=Path(__file__).resolve().parent
U=Path('/private/tmp/vellum-macos-native-results-97aee13/drivers/cogent/build/upstream')
P=Path('/private/tmp/vellum-macos-native-results-97aee13/drivers/cogent/prepare.py')
R=W/'recipe';D=W/'reproduced-core'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def vector(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise RuntimeError('unexpected source symlink')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
baseline=json.loads((W/'baseline-vector.json').read_text());candidate=json.loads((W/'candidate-vector.json').read_text())
assert vector(U)==baseline
for n,h in json.loads((W/'candidate-files.json').read_text()).items():assert sha(W/'candidate-core'/n)==h
assert not D.exists();shutil.copytree(U,D)
spec=importlib.util.spec_from_file_location('stage104_prepare',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=R
output=io.StringIO()
with contextlib.redirect_stdout(output):m.apply_stage(json.loads((R/'stage-0104.json').read_text()),D)
assert vector(D)==candidate and vector(U)==baseline
(W/'preparation.stdout').write_text(output.getvalue())
(W/'preparation-result.json').write_text(json.dumps({'result':'PASS_ISOLATED_STAGE_0104_REPRODUCTION','baseline_files':len(baseline),'candidate_files':len(candidate),'baseline_prepared_unchanged':True,'whole_reproduced_tree_matches_candidate':True,'native_executed':False,'tests_or_builds_run':False},indent=2)+'\n')
