"""Bounded code-only checks after the human's quiet-host window; no native app launch."""
import datetime, hashlib, json, subprocess, sys, time
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-workbench-endurance')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
name,cwd=sys.argv[1:3];argv=sys.argv[3:]
assert argv[:2] in [['go','vet'],['go','test'],['go','build'],['python3','prepare.py'],['python3','prepare_test.py'],['python3','native/patches/autorelease/check.py']], 'Only explicitly selected code/build/preparation checks allowed'
def delta():
    names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=r).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r).decode().splitlines())
    return {n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names if (r/n).is_file()}
headless=True
env={**child_environment(),'GOCACHE':'/tmp/vellum-p0-cache/build','GOMODCACHE':'/tmp/vellum-p0-cache/mod','GOPATH':'/tmp/vellum-p0-cache/gopath'}
if headless:env['VELLUM_GPU_SCENE_TEST']='1'


def prepared():
    return {f.relative_to(r/'drivers/cogent/build').as_posix():hashlib.sha256(f.read_bytes()).hexdigest()for module in ['upstream','typesetting']for f in sorted((r/'drivers/cogent/build'/module).rglob('*'))if f.is_file()}
def overlay_inputs():
    selected={}
    for argument in argv:
        if argument.startswith('-overlay='):
            overlay=Path(argument.split('=',1)[1]);selected[str(overlay)]=hashlib.sha256(overlay.read_bytes()).hexdigest()
            for target in json.loads(overlay.read_text())['Replace'].values():
                if target:selected[target]=hashlib.sha256(Path(target).read_bytes()).hexdigest()
    return selected
d={'argv':argv,'cwd':str(r/cwd),'mode':'code','live_tests':False,'headless_gpu_requested':headless,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_delta_before':delta(),'prepared_before':prepared(),'overlay_inputs_before':overlay_inputs(),'executable_sha256':None,'exit_code':None,'error':None};start=time.monotonic()
try:
    with(p/(name+'.stdout')).open('xb')as so,(p/(name+'.stderr')).open('xb')as se:
        d['exit_code']=run_child(argv,cwd=r/cwd,env=env,stdout=so,stderr=se,timeout=60 if headless else 240).returncode
except BaseException as error:d['error']={'type':type(error).__name__,'message':str(error)}
finally:
    d['elapsed_seconds']=time.monotonic()-start;d['source_delta_after']=delta();d['source_delta_stable']=d['source_delta_before']==d['source_delta_after'];d['prepared_after']=prepared();d['overlay_inputs_after']=overlay_inputs()
    for channel in ['stdout','stderr']:
        f=p/(name+'.'+channel);d[channel+'_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()if f.exists()else None
    (p/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if not k.startswith('prepared_') and not k.startswith('source_delta_')}))
if d['exit_code']!=0 or d['error']is not None:sys.exit(1)
