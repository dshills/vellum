"""Bounded process-memory observation of the exact live fixture PID."""
from pathlib import Path
import datetime,json,subprocess,hashlib
p=Path('/private/tmp/vellum-macos-workbench-endurance');out=p/'ten-minute-v1';rows=[json.loads(x) for x in (out/'observations.jsonl').read_text().splitlines()]
ready=next(r for r in rows if r['event']=='vellum.endurance.ready');pid=ready['pid']
command=subprocess.check_output(['/bin/ps','-p',str(pid),'-o','command='],timeout=3).decode().strip()
assert command.startswith(str(p/'workbench-v9')+' -endurance=10m ')
index=len(list(out.glob('vmmap-*.txt')))+1
result=subprocess.run(['/usr/bin/vmmap','-summary',str(pid)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
assert result.returncode==0,result.stderr
path=out/f'vmmap-{index:02d}.txt';path.write_bytes(result.stdout)
rss=subprocess.check_output(['/bin/ps','-p',str(pid),'-o','rss='],timeout=3).decode().strip()
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':pid,'rss_bytes':int(rss)*1024,'vmmap_path':path.name,'sha256':hashlib.sha256(result.stdout).hexdigest(),'observed_latest_step':rows[-1].get('step'),'scope':'Process physical footprint/RSS include opaque driver/caches; no native orGPUallocation attribution.'}
with (out/'memory-observations.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
print(json.dumps(record))
