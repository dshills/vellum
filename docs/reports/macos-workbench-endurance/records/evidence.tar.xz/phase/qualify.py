"""Qualify only completed diagnostic composition, never complete P11/P6."""
from pathlib import Path
import hashlib,json,re,subprocess
p=Path('/private/tmp/vellum-macos-workbench-endurance');out=p/'ten-minute-v1'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
r=json.loads((p/'native-ten-minute-v1.json').read_text());assert r['exit_code']==0 and r['error'] is None and r['source_delta_stable'] and r['prepared_before']==r['prepared_after'] and len(r['prepared_after'])==6200
rows=[json.loads(x) for x in (out/'observations.jsonl').read_text().splitlines()];ready=rows[0];final=rows[-1];samples=rows[1:-1]
assert ready['event']=='vellum.endurance.ready' and ready['duration_seconds']==600 and ready['rows']==1000000
assert final['event']=='vellum.endurance.result' and final['result']=='PASS_COMPOSED_ACTIVITY' and final['elapsed_seconds']>=600
assert all(s['event']=='vellum.endurance.sample' for s in samples) and len(samples)>=100
assert [s['step'] for s in samples]==list(range(20,final['steps']+1,20))
assert final['native_edits']==final['steps']//4 and final['resizes']==final['steps']//12
assert final['workers_started']==final['workers_committed']+final['workers_stale_discarded'] and final['workers_committed']>0 and final['workers_stale_discarded']>0 and final['workers']==0
assert final['pending']['Ordinary']==final['pending']['Reserved']==final['pending']['ReadyCompletions']==final['pending']['Cleanup']==0 and final['pending']['Dispatching']==1
geometries=sorted({(s['window_manager_units']['X'],s['window_manager_units']['Y']) for s in samples});assert geometries==[(1100,780),(1280,900)]
memories=[json.loads(x) for x in (out/'memory-observations.jsonl').read_text().splitlines()]
assert len(memories)>=5
footprints=[];surfaces=[]
for m in memories:
 text=(out/m['vmmap_path']).read_text();assert sha(out/m['vmmap_path'])==m['sha256']
 footprints.append(float(re.search(r'Physical footprint:\s+([\d.]+)M',text)[1]))
 surfaces.append(float(re.search(r'^IOSurface\s+([\d.]+)M',text,re.M)[1]))
for f,limit in [('execution.trace',256<<20),('heap.pprof',8<<20)]:assert 0<(out/f).stat().st_size<=limit
summary={'result':'PASS_DIAGNOSTIC_COMPOSED_ACTIVITY','source_commit':r['source_commit'],'binary_sha256':r['executable_sha256'],'native_receipt_sha256':sha(p/'native-ten-minute-v1.json'),'observations_sha256':sha(out/'observations.jsonl'),'ordinary_frame_samples':0,'go_observations':len(samples),'native_result':final,'sampled_window_manager_units':geometries,'goroutine_range':[min(s['goroutines'] for s in samples),max(s['goroutines'] for s in samples)],'go_heap_alloc_range_bytes':[min(s['heap_alloc'] for s in samples),max(s['heap_alloc'] for s in samples)],'go_sys_range_bytes':[min(s['go_sys'] for s in samples),max(s['go_sys'] for s in samples)],'gc_cycles_first_last':[samples[0]['gc_cycles'],samples[-1]['gc_cycles']],'physical_footprint_observations_mib':footprints,'rss_observations_bytes':[m['rss_bytes'] for m in memories],'iosurface_observations_mib':surfaces,'trace_bytes':(out/'execution.trace').stat().st_size,'trace_sha256':sha(out/'execution.trace'),'heap_profile_sha256':sha(out/'heap.pprof'),'producer_sha256':sha(__file__),'limits':['Profiled single composition run, not five ordinary latency runs or confidence/performance qualification.','Legacytable viewport/canvas mutations and commands run onowner; nativeAXrequests mayretry aftersemanticrevocation. Not physicalinput/noindividualdelivery guarantee.','Native/GPUallocation, droppedframes/inputbacklog/presentation unavailable; sampledRSS/physicalfootprint include driver/caches.','1000composed lifecycle, overnightidle, allacceptedcomponent/1000visiblecontrol primary andalternatephysicaldisplay gates stillopen.']}
(p/'native-qualification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
