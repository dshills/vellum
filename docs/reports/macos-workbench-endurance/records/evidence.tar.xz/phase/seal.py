"""Seal reviewed current source and distinct original/final native vectors."""
from pathlib import Path
import hashlib,io,json,tarfile
ROOT=Path('/private/tmp/vellum-large-data');PHASE=Path('/private/tmp/vellum-macos-workbench-endurance')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources=json.loads((PHASE/'checkpoint-source.json').read_text())['sources'];assert len(sources)==8 and all(sha(ROOT/n)==h for n,h in sources.items())
review=json.loads((PHASE/'final-source-review.json').read_text());assert review['result']=='APPROVED_SOURCE' and not review['findings'];assert review['reviewed_file_sha256']=={str(ROOT/n):h for n,h in sources.items()}
for path,digest in review.get('reviewed_artifact_sha256',{}).items():assert sha(path)==digest,path
original=json.loads((PHASE/'source-review.json').read_text())['reviewed_file_sha256']
for name,digest in original.items():assert sha(PHASE/'owned-v9'/Path(name).name)==digest
old=(PHASE/'owned-v9/endurance.go').read_text();new=(ROOT/'drivers/cogent/cmd/workbench/endurance.go').read_text().split('// The native-loop cause precedes')[0].rstrip()+'\n'
assert new.replace('if geometryErr != nil {\n\t\t\t\tcancel()\n\t\t\t\treturn geometryErr\n\t\t\t}', 'if geometryErr != nil {\n\t\t\t\treturn geometryErr\n\t\t\t}')==old
receipts={};prepared=None
for name in ['focused-race-v6','adapter-race-v3','adapter-vet-v3','build-v11','native-short-v7','native-ten-minute-v1']:
 r=json.loads((PHASE/(name+'.json')).read_text());assert r['exit_code']==0 and r['error'] is None and r['source_delta_stable']
 assert r['prepared_before']==r['prepared_after'] and len(r['prepared_after'])==6200
 prepared=r['prepared_after'] if prepared is None else prepared;assert prepared==r['prepared_after']
 for c in ['stdout','stderr']:assert sha(PHASE/(name+'.'+c))==r[c+'_sha256']
 receipts[name]=sha(PHASE/(name+'.json'))
actual={f.relative_to(ROOT/'drivers/cogent/build').as_posix():sha(f) for m in ['upstream','typesetting'] for f in sorted((ROOT/'drivers/cogent/build'/m).rglob('*')) if f.is_file()};assert actual==prepared
(PHASE/'formal-prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
native=json.loads((PHASE/'native-qualification.json').read_text());assert native['result']=='PASS_DIAGNOSTIC_COMPOSED_ACTIVITY' and native['native_result']['elapsed_seconds']>=600
profiles=json.loads((PHASE/'profile-validation.json').read_text());assert profiles['result']=='PASS_PARSED_TRACE_AND_HEAP'
first_process=json.loads((PHASE/'prism-v1/process.json').read_text());first=json.loads((PHASE/'prism-v1/prism.json').read_text())
assert first_process['exit_code']==1 and first_process['source_index_stable'] and first['coverage']['complete'] and first['coverage']['files']==8
assert len(first['findings'])==1 and first['findings'][0]['id']=='baad453567de06cf'
process=json.loads((PHASE/'prism-v2/process.json').read_text());prism=json.loads((PHASE/'prism-v2/prism.json').read_text());assert process['exit_code']==1 and process['error'] is None and process['source_index_stable']
assert prism['coverage']['complete'] and prism['coverage']['files']==4 and len(prism['findings'])==1
assert prism['findings'][0]['id']=='726b66507d7097be'
disposition=json.loads((PHASE/'finding-disposition.json').read_text())
assert disposition['result']=='REJECTED_NOT_APPLICABLE' and disposition['finding_id']=='726b66507d7097be'
for mapping in ['reviewed_file_sha256','primary_source_sha256']:
 for path,digest in disposition[mapping].items():assert sha(path)==digest,path
assert disposition['provider_sha256']==sha(PHASE/'prism-v2/prism.json')
assert process['before']==process['after']
for n,h in sources.items():assert h==process['after'].get(n,first_process['after'].get(n)),n
q={'result':'REVIEWED_MAC_WORKBENCH_ENDURANCE','base_commit':native['source_commit'],'source':sources,'prepared_files':6200,'prepared_manifest_sha256':sha(PHASE/'formal-prepared.json'),'required_receipts':receipts,'native_qualification_sha256':sha(PHASE/'native-qualification.json'),'profile_validation_sha256':sha(PHASE/'profile-validation.json'),'original_v9_source_review_sha256':sha(PHASE/'source-review.json'),'final_source_review_sha256':sha(PHASE/'final-source-review.json'),'final_vs_ten_minute_delta':'Geometryrefusal cancellation andshutdown native-error preservation. Originalv9fiveleaves retained; finalv11shortnativepass. Steadyactivityunchanged; binary/sourcevectorsdistinct.','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_findings':0,'prism_original_findings':1,'prism_followup_raw_findings':1,'prism_rejected_finding_ids':['726b66507d7097be'],'finding_disposition_sha256':sha(PHASE/'finding-disposition.json'),'prism_resolved_finding_ids':['baad453567de06cf'],'prism_original_sha256':sha(PHASE/'prism-v1/prism.json'),'prism_coverage_complete':True,'prism_sha256':sha(PHASE/'prism-v2/prism.json'),'full_p11_qualified':False,'ordinary_frame_samples':0,'limits':native['limits']}
(PHASE/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
records=ROOT/'docs/reports/macos-workbench-endurance/records';records.mkdir()
suffixes={'.go','.py','.md','.txt','.json','.stdout','.stderr','.log','.trace','.pprof','.jsonl'}
members={'phase/'+p.relative_to(PHASE).as_posix():p.read_bytes() for p in sorted(PHASE.rglob('*')) if p.is_file() and p.suffix in suffixes};members.update({'root/'+n:(ROOT/n).read_bytes() for n in sources})
for n in ['observations.jsonl','memory-observations.jsonl','execution.trace','heap.pprof','sched.pprof']:
 assert 'phase/ten-minute-v1/'+n in members,n
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in members.items()}
with tarfile.open(records/'evidence.tar.xz','x:xz') as archive:
 for n,b in members.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;archive.addfile(info,io.BytesIO(b))
(records/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(records/'evidence.tar.xz','r:xz') as archive:
 assert archive.getnames()==list(index)
 for item in archive:
  b=archive.extractfile(item).read();assert len(b)==index[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==index[item.name]['sha256']
checkpoint={**q,'archive_sha256':sha(records/'evidence.tar.xz'),'index_sha256':sha(records/'evidence-index.json'),'archive_members':len(index),'archive_index_verified':True,'qualification_sha256':sha(PHASE/'qualification.json'),'seal_producer_sha256':sha(__file__)}
(records/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
print(json.dumps({k:v for k,v in checkpoint.items() if k not in ['source','required_receipts']},indent=2))
