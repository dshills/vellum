from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;A=Q.parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=A/'macos-acquisition-diagnostics-4ce6ba4'
s=importlib.util.spec_from_file_location('frame_guard',A/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sdk=Path(json.loads((P/'plan.json').read_bytes())['sdk']);name,kind=sys.argv[1:]
assert not(Q/name).exists() and kind in ['focused']
modfile=A/'macos-catalogue-visibility-90fc432/checked.mod'
overlay=Q/'overlay-actual.json'
# Go's overlay does not replace compiler-read Objective-C units. Compile actual
# candidate sources, using an external manifest that pins only dependency paths.
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
names=run_child(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=T,timeout=30,capture_output=True,check=True).stdout.decode().split('\0')[:-1]
paths=[T/n for n in names]+[p for directory in ['upstream','typesetting']for p in (T/'drivers/cogent/build'/directory).rglob('*')if p.is_file()]+[modfile,modfile.with_suffix('.sum'),overlay,*[Path(v)for v in json.loads(overlay.read_bytes())['Replace'].values()],Path(__file__),Path(h.__file__),h.GUARD,h.GO,T/'scripts/child_process.py',sdk/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a']
paths += [p for p in (sdk/'drivers/cogent/build/libs-darwin').rglob('*')if p.is_file()] + [h.PROV,T/'release/native-components/wgpu-darwin-arm64/INVENTORY.json']
pins={str(p):h.sha(p)for p in paths}
base=['-p=1','-modfile='+str(modfile),'-overlay='+str(overlay),'-tags=offscreen']
if kind in ['negative','focused']:args=['test','-v','-race','-count=1',*base,'-timeout=3m','-run','^TestTabClose', '.']
elif kind=='driver':args=['test','-v','-race','-count=1',*base,'-timeout=8m','.']
elif kind=='gallery':args=['test','-v','-race','-count=1',*base,'-timeout=3m','./cmd/gallery']
elif kind=='vet':args=['vet',*base,'.','./cmd/gallery']
elif kind=='build':args=['build','-p=1','-modfile='+str(modfile),'-overlay='+str(overlay),'-o',str(Q/'native-gallery'),'./cmd/gallery']
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$','PYTHONDONTWRITEBYTECODE':'1'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))(deny file-write* (subpath '+json.dumps(str(T))+'))'
def interrupted(signum,frame):raise InterruptedError('frame check signal '+str(signum))
previous=signal.signal(signal.SIGTERM,interrupted)
try:r=h.g.execute(['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args],T/'drivers/cogent',Q/name,lambda:False,lambda:all(h.sha(p)==v for p,v in pins.items()),timeout=540 if kind=='driver'else 300,limit=4<<20)
finally:signal.signal(signal.SIGTERM,previous)
r['source_pins']=pins;r['native_executed']=False
if kind=='build'and r['exit_code']==0:r['binary']={'path':str(Q/'native-gallery'),'sha256':h.sha(Q/'native-gallery')}
(Q/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}));sys.exit(0 if r['exit_code']==0 and r['error']is None and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
