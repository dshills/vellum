# Retain document header focus after a controlled close click

The separately admitted structural native catalogue at90fc432 failed after the
rejected close of Notes: the accepted documents and selected Notes remain intact,
one close proposal is delivered, but the tab strip has no actual focus. The130
correlations contain50 startup refusals followed by80 completed Frames; none
reports an actual unavailable/failed Frame. The process exited1, its owned group is absent,
the whole source/prepared/SDK boundary remains stable, and the scope is sealed.
The text/modal case was not dispatched. This is no native catalogue pass.

Core clears focus before sending the private close button's Click. That passive
button does not own keyboard focus. The controlled native CloseRequest callback
therefore restores quiet focus to the originating live header, then uses the
existing guarded owner queue for the close proposal. This does not select the
page, delete content, add a Tab stop, or mutate focus during an owner callback
drained by another window. Old artwork, disabled/hidden controls and retired
scope capabilities cannot acquire focus. Semantic close stays passive.

A new actual Manual routing regression covers closing the selected and an
unselected tab while the application rejects the proposal. It requires actual
header focus, published strip focus, unchanged accepted selection/page identity,
exactly one proposal, and a subsequent Delete directed to the same header. The
unchanged implementation must fail before using the fix. Existing close lifetime,
queue refusal, semantics, accepted removal and keyboard coverage remain required.

This is a significant product fix: internal review, affected checks and one Prism
Anthropic Claude Sonnet5.5 checkpoint precede commit. A new separately reviewed
native scope can follow; the failed native record remains immutable. No physical
input, IME, human accessibility, native pixel/presentation or full Mac claim.
