"""Two fresh current-runtime catalogue cases, serial and sealed, no replay."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');HEAD='90fc432b416784f3559b79fcba9c30bcdd7821f1';SDK=Path('/private/tmp/vellum-sdk-stage0079-abe67c6-cache-v2/retained SDK/vellum-v0.1.0-alpha.2')
s=importlib.util.spec_from_file_location('trusted_catalogue_guard',Q.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g;sha=h.sha;need=h.need
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sys.path.insert(0,str(Q));import validate as validator
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'no vector symlink')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean90fc432')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5501,'current tracked source count')
 return{n:sha(root/n)for n in sorted(names)}
def baseline():
 a=source(C);need(source(T)==a,'whole C/T source identity')
 prepared=lambda root:{m+'/'+n:v for m in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/m).items()}
 p=prepared(C);need(prepared(T)==p and len(p)==6276 and digest(p)=='1cf2dfa8fd75d4c78cfe7e347ac81bf6e66d7c4072e9134e682897de4835d1ed','unchanged stage86')
 sdk=vector(SDK);need(len(sdk)==7880 and digest(sdk)=='4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26','whole SDK unchanged')
 mapping=read(Q/'overlay.json')['Replace'];original=read(Q/'consumer-originals.json');need(len(mapping)==len(original)==3,'three Go-only consumer overlays')
 for name,v in original.items():need(name.endswith('.go')and sha(T/'drivers/cogent/cmd/gallery'/name)==v and mapping.get(str(T/'drivers/cogent/cmd/gallery'/name))==str(Q/'consumer'/name),'unmodified original consumer source')
 return{'source':a,'prepared':p,'sdk':sdk}
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def runtime_options():
 env={**g.child_environment(True),'GOMAXPROCS':'2'}
 return{k:env.get(k)for k in ['GOMAXPROCS','GOMEMLIMIT','GORACE']}
def prepare():
 need(not(Q/'plan.json').exists()and not(Q/'stop-live').exists()and not(Q/'structure').exists()and not(Q/'text').exists(),'fresh two-case scope')
 b=baseline();review=read(Q/'internal-source-review.json');need(review['approved']and review['source_controller_ready']and not review['unresolved_findings']and all(sha(k)==v for k,v in review['inputs'].items()),'exact source/controller review')
 reuse=read(Q/'runtime-reuse.json');need(reuse['qualified_reuse']and all(sha(k)==v for k,v in reuse['inputs'].items()),'exact unchanged runtime reuse')
 pins=dict(reuse['inputs']);pins[str(Q/'runtime-reuse.json')]=sha(Q/'runtime-reuse.json')
 for name in ['gallery-v1','vet-v1','build-v1']:
  p=Q/(name+'.json');r=read(p);need(passing(r)and all(sha(k)==v for k,v in r['source_pins'].items()),'current owned prerequisite '+name);pins.update(r['source_pins']);pins[str(p)]=sha(p)
  for stream,info in r['logs'].items():
   p=Q/name/stream;need(p.stat().st_size==info['bytes']and sha(p)==info['sha256'],'raw prerequisite streams');pins[str(p)]=sha(p)
 controls=read(Q/'validation-controls.json');need(controls['synthetic_only']and not controls['native_executed']and len(controls['cases'])==2 and all(len(v['refusals'])==16 for v in controls['cases'].values())and all(sha(k)==v for k,v in controls['inputs'].items()),'current independent validation controls');pins.update(controls['inputs'])
 files=[Path(__file__),Q/'check.py',Q/'design.md',Q/'internal-source-review.json',Q/'validate.py',Q/'validation_controls.py',Q/'validation-controls.json',Q/'consumer-originals.json',Q/'overlay.json',Q/'oracles.json',Q/'prepare_consumer.py',Q/'reuse_runtime.py',Path(h.__file__),h.GUARD,h.GO,h.PROV,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(p):sha(p)for p in files});binary=read(Q/'build-v1.json')['binary'];need(sha(binary['path'])==binary['sha256']and sha(h.GO)==h.GOSHA and sha(SDK/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a')==h.LIBSHA,'exact native binary/compiler/archive')
 oldpaths=[Q.parent/'macos-structure-catalogue-e9896d6',Q.parent/'macos-acquisition-diagnostics-4ce6ba4',Q.parent/'macos-text-modal-9854e5d',Q.parent/'macos-native-visibility-2aca9b6',Q.parent/'macos-native-visibility-corrected-2aca9b6']
 seals={str(p/'stop-live'):sha(p/'stop-live')for p in oldpaths if(p/'stop-live').exists()};need(len(seals)==5,'all five prior structural/text/visibility scopes sealed');pins.update(seals)
 now=datetime.datetime.now(datetime.timezone.utc);plan={'head':HEAD,'boundary':b,'pins':pins,'binary':binary,'runtime_options':runtime_options(),'old_seals':seals,'cases':[{'id':'structure','flag':'-structure-native-check','inputs':50,'observations':42},{'id':'text','flag':'-text-native-check','inputs':68,'observations':33}],'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':120,'stream_limit_bytes':4<<20,'scope':'Two newly admitted current90fc432 visibility-correlated catalogue cases, unchanged public views/actions/independentoracles, privateGo-onlyboundedconsumer instrumentation; actualcurrentTnativeunits/SDK786a/stage86. Serialoneprocesspercase/sharedlease/permanentseals/stopfirstfailure/nooldcasereset/Frameunavailableneverretried. No product/native/SDK/prepared/OSinput/preferences change, physical/pixels/presentation/performance/resource/rights/distribution/fullMacclaim.'}
 (Q/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(Q/'plan.json'),'native_executed':False}))
def run():
 raw=(Q/'plan.json').read_bytes();adraw=(Q/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(adraw);stop=Q/'stop-live'
 need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact plan admission');need(not stop.exists()and not(Q/'result.json').exists()and all(not(Q/c['id']).exists()for c in p['cases']),'fresh serial scope')
 def stable():return(Q/'plan.json').read_bytes()==raw and(Q/'admission.json').read_bytes()==adraw and all(sha(k)==v for k,v in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():need(not stop.exists()and stable(),'stable/no stop');need(baseline()==p['boundary']and runtime_options()==p['runtime_options'],'whole source/prepared/SDK/runtime boundary')
 d={'result':'INCOMPLETE','native_executed':False,'cases':{},'error':None,'closed_full_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('catalogue visibility controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary()
   for case in p['cases']:
    kind=case['id'];root=Q/kind;need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline per case')
    boundary();root.mkdir();entry={'result':'INCOMPLETE','error':None};d['cases'][kind]=entry
    try:
     profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(q))+'))'for q in [C,T,SDK,Q/'consumer'])
     need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline immediately before launch')
     r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],case['flag']],T/'drivers/cogent',root/'run',lambda:stop.exists()or(root/'stop-live').exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);entry['run']=r;d['native_executed']|=r['created']
     boundary();need(lease.held(),'lease through retirement');entry['post_boundary_pass']=True;need(passing(r),'owned native '+kind)
     entry['summary']=validator.validate(kind,(root/'run/stdout').read_bytes(),(root/'run/stderr').read_bytes());entry['result']='PASS_NATIVE_'+kind.upper()
    except BaseException as e:entry.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)});raise
    finally:(root/'stop-live').touch();(root/'result.json').write_text(json.dumps(entry,indent=2)+'\n')
   d['result']='PASS_BOTH_NATIVE_CATALOGUES'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(Q/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error']}));print(json.dumps({k:v.get('summary')for k,v in d['cases'].items()}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
