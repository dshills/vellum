# Remaining native catalogue under observed visibility

This advances M2's outstanding structural50-input42-state and text/modal68-input
33-state records using the current Mac runtime at90fc432 (unchanged Go/native
implementation2aca9b6). The authoritative actual-window visibility recovery
prerequisite now passes. Earlier structural/text scopes stay failed/sealed.
This is a newly reviewed binary and two newly admitted one-shot scope IDs, not
a reset of an old case. All original actions, models, geometry and validators
remain unchanged. No product Go, native, prepared, SDK or OS setting is modified.

Reuse the ordinary gallery and its public APIs/views. A private Go-only overlay
instruments catalogueReady and adds a bounded Availability field to the two
final reports. Before each existing Frame call, inspect the original reference's
copied native visibility; retain the observation, actual request IDs, Frame
outcome and error. This read does not admit a drawable, promise readiness, change
Frame retry rules or waive a failed acquisition. Existing unavailable errors
remain terminal. Startup refusals remain distinguishable from an actual first
composition. A successful Frame whose Snapshot subsequently becomes stale may
be superseded by a new request under the existing owner/layout contract.

Exactly one catalogue worker writes a fixed1024-entry log per process. The main
reader copies it only after joining that worker. No native pointer, callback,
unbounded history, OS input or visibility polling is introduced. Existing native
consumer shutdown cancellation, independently bounded close acknowledgement and
six-second join remain unchanged. Visibility correlation adds Go FIFO work and
therefore is not ordinary performance evidence.

The correlation validator deliberately fails conservatively if the initial
Visibility request is refused immediately before the first Frame succeeds.
Window registration can complete between those requests. Such a result seals
this scope as an instrumentation/startup refusal; it is not evidence of a
framework rendering defect. Preserve both actual outcomes and do not invent
a Frame error, suppress the visibility error, or retry an unavailable Frame.

Compile actual checkout native units with an external dependency manifest and
three Go-only consumer overlays. The retained source-built786a SDK native module
and stage86 dependencies remain unchanged. Full runtime source and prior checks
are reusable only after exact compiled-input correspondence; rerun the affected
gallery race suite, vet and native build. Independent authored validators still
must accept every original model/focus/geometry/input/refusal/history/lifecycle
assertion. Additional controls verify every used frame came from a completed
request and correlate visibility without inferring availability from its bit.

Before native execution, obtain internal source/controller review and separate
exact-plan admission. Run structure and text as separate owned processes, serial
under the shared live lease, one case each, bounded120seconds/4MiB streams and
permanently sealed. Stop the campaign at the first failed case; do not rerun it
or dispatch later cases on unvalidated evidence. Do not relax goldens, omit
actions, replace validation with prefixes, or treat diagnostics as a native pass.

Physical/OS input, IME, human VoiceOver, native pixels/presentation, display
transitions, performance/resources, final SDK/rights and full Mac remain open.
No new provider review is needed for this acceptance-only continuation of the
unchanged Prism-reviewed runtime; significant product fixes found here receive
their own implementation review/checkpoint.
