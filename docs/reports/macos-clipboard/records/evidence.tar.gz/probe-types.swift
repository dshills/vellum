import AppKit
import Foundation
let b=NSPasteboard.withUniqueName();defer{b.releaseGlobally()}
func put(_ values:[(String,Data)]) -> NSPasteboardItem {let i=NSPasteboardItem();for (t,d) in values {precondition(i.setData(d,forType:.init(t)))};return i}
let items=[put([(NSPasteboard.PasteboardType.string.rawValue,Data("guardian original".utf8)),("org.vellum.guardian.binary",Data([0,255,42]))]),put([("org.vellum.guardian.empty",Data())])]
b.clearContents();precondition(b.writeObjects(items))
let result:[String:Any]=["fixture_owned":true,"legacy_alias_equals_first_text":b.data(forType:.init("NSStringPboardType"))==b.pasteboardItems?.first?.data(forType:.string),"general_pasteboard_access":false,"declared":b.types?.map{$0.rawValue} ?? [],"item_types":b.pasteboardItems?.map{$0.types.map{$0.rawValue}} ?? []]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:result));print("")
