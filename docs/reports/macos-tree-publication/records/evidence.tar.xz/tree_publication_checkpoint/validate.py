from pathlib import Path
import hashlib,json,math
P=Path('/private/tmp/vellum-macos-tree-publication'); R=Path('/private/tmp/vellum-large-data')
def sha(f): return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def load(n):return json.loads((P/(n+'.json')).read_text())
def events(n):return [json.loads(x)for x in (P/(n+'.stdout')).read_text().splitlines()if x.startswith('{')]
def receipt(n,code=False):
 x=load(n);assert x['exit_code']==0 and x['error']is None
 for c in ['stdout','stderr']:assert x[c+'_sha256']==sha(P/(n+'.'+c))
 if code:assert x['source_delta_stable']and x['prepared_before']==x['prepared_after']and len(x['prepared_after'])==6204
 else:assert x['source_prepared_stable']and x['executable_sha256']==sha(x['argv'][0])
 return x
checks=['final-adapter-race','final-adapter-vet','final-consumer-race','final-consumer-build','final-composed-build','native-envelope-validator-v2-race','composed-envelope-v2-build']
summary={'result':'PASS_FINAL_FRAMEWORK_AND_NATIVE_PREFLIGHTS','code_checks':{n:{k:v for k,v in receipt(n,True).items()if k in ['argv','exit_code','elapsed_seconds','source_delta_stable']}for n in checks},'tree_preflights':[]}
framework=load('final-adapter-race')['source_delta_after'];final=load('composed-envelope-v2-build')['source_delta_after']
changed=[n for n in set(framework)|set(final)if framework.get(n)!=final.get(n)and Path(n).suffix in {'.go','.m','.h','.c','.mod','.sum','.patch'}]
assert set(changed)=={'drivers/cogent/cmd/window-cycle-smoke/composed.go','drivers/cogent/cmd/window-cycle-smoke/main_test.go'}
summary['later_source_changes']=changed;summary['version_note']='Full adapter/consumer suite and original native preflights use final framework source. Only acceptance command and tests change later; final command race/build and five composed cycles use final checker.'
for n in ['native-tree-wide','native-tree-deep']:
 x=receipt(n);ev=events(n);samples=[s for s in ev if s.get('event')=='tree.perf.sample'];assert len(samples)==120
 assert [s['index']for s in samples]==list(range(120))
 for s in samples:
  assert not s['gpu_scene_rendering']and not s['source_details']and s['nodes']==100000
  assert s['frame']['Completed']and not s['frame']['Failure']and s['tree_notifications']==1
  assert s['geometry']['ClippedRows']>=64 and s['geometry']['MaterializedRows']==s['geometry']['ClippedRows']and s['geometry']['RetainedRows']<=256
 work=sorted(s['frame']['TotalUIWorkNS']for s in samples);p95=work[math.ceil(.95*len(work))-1]
 assert any(s.get('event')=='tree.perf.finished'and s['samples']==120 and not s['full_p6_qualified']for s in ev)
 summary['tree_preflights'].append({'name':n,'samples':120,'clipped_rows':sorted(set(s['geometry']['ClippedRows']for s in samples)),'p95_total_ui_work_ns':p95,'target_ns':4000000,'target_pass':p95<=4000000,'elapsed_seconds':x['elapsed_seconds'],'scope':'one-process compatibility preflight, no matched speed comparison'})
receipt('native-tree-smoke');smoke=events('native-tree-smoke');assert len(smoke)==9 and smoke[-1]['stage']=='pass';summary['native_workflow_stages']=9;summary['native_workflow_teardown_joined']=False
for name in ['native-composed-five','native-composed-envelope','native-composed-envelope-v2']:
 receipt(name);ev=events(name);cycles=[x for x in ev if x.get('event')=='vellum.composed-cycle'];end=[x for x in ev if x.get('event')=='vellum.window-cycle.result'];assert len(end)==1 and len(cycles)==5
 end=end[0];assert end['result']=='PASS_NATIVE_WINDOW_CYCLES'and end['completed_cycles']==5 and not end['full_p11_qualified']
 clean=end['native_cleanup'];assert clean['MainThread']and clean['CleanupObserved']and clean['CallbacksStopped']and not clean['WindowTitles']and clean['NativeOutstanding']==clean['AccessibilityWindows']==clean['PendingCallbacks']==0
 for c in cycles:assert c['dense_defined']==c['dense_fully_visible']==1000 and c['native_text_accepted']and c['modal_open_close']and c['grid_tree_completed']
 if name!='native-composed-five':assert all(c['tree_accessibility_completed']and c['tree_accessibility_rows']==18 for c in cycles)
 if name=='native-composed-envelope-v2':summary['final_composed']={'cycles':5,'tree_ax_rows_each':18,'dense_labels_each':1000,'cleanup':clean,'last_heap_bytes':end['samples'][-1]['HeapAlloc'],'last_rss_bytes':end['samples'][-1]['RSSBytes'],'elapsed_seconds':load(name)['elapsed_seconds'],'full_1000_cycle_qualified':False}
internal=json.loads((P/'internal-review.json').read_text());assert internal['result']=='APPROVED_SOURCE'and not internal['unresolved_findings']and all(sha(R/n)==h for n,h in internal['sources'].items())
checker={'result':'APPROVED_SOURCE','reviewer':'/root/platform_completion','sources':{n:sha(R/n)for n in ['drivers/cogent/cmd/window-cycle-smoke/composed.go','drivers/cogent/cmd/window-cycle-smoke/main_test.go']},'resolved_findings':['Reject duplicate DomainIDs even with distinct native ID/ObjectIdentity','Require exact [row index,1] range and full visible row count'],'unresolved_findings':[],'scope':'Read-only narrow checker review; no tests run by reviewer'}
(P/'internal-checker-review.json').write_text(json.dumps(checker,indent=2)+'\n')
summary['full_p6_qualified']=summary['full_p11_qualified']=False;summary['prepared_files']=6204
(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
