# Tree and retained-view geometry publication

Managed trees now refuse completed-frame inspection, hit coordinates and queued
accessibility actions during a full scene layout, even when the portable model
generation is unchanged. Completed geometry retains an atomic originating scene
reference and checks that scene's full-layout fence. Same-generation pending-index
metadata is also checked. The last completed geometry remains available privately
for read-only semantic retention.

Outlines now use the existing bounded virtual-view pending/completed transaction.
The legacy Grid-prefixed wire/inspection fields keep their names and apply to both
managed tables and outlines. Owner snapshots stamp every host/row/page with one
binding incarnation, target/completed generation, pending state and copied frame.
While layout is pending, the bridge retains last-completed data/frames but revokes
actions, enabled/focused state and owner handlers. Cocoa selectors independently
refuse pending actions. Completed-frame publication restores current semantics and
frames atomically while preserving compatible object identities.

The completion comparer includes all TreeInspection data/geometry except frame
ordinal. A full layout schedules owner publication even if final bounds/generation
are unchanged. Source stamps, viewport, scale, selection, pending metadata,
row/disclosure/page frames and retained cardinalities remain separate provenance.
A scoped host-role transition is a cache/native ownership boundary; unrelated
ordinary controls and independent view scopes retain their existing behavior.

Internal review found retained scene transfers that bypass each descendant's
reparent path. Recursive withdrawal now precedes modal preparation, native modal
close, programmatic close, keyed ancestor parking and workbench parking. It
revokes both Grid and Tree completion and captured scene references; Grid's local
layout stamp becomes invalid/pending. The scoped read-only AX cache is separate.
Retained widgets/models remain the same; only a destination frame restores geometry.

The original manual regression returns stale inspection/hit geometry and accepts
an old AX action during full layout. It fails before the fix. Additional inert
sentinel regressions fail before modal-transfer/workbench-parking withdrawal;
they exercise actual transfer/reconciliation and the real panel.View callback,
without claiming that a seeded sentinel is a native frame. Final race checks cover
restored publication, all data/geometry comparator fields, scope-kind changes,
retained ancestor moves and both modal close paths.

A Cocoa production transaction fixture checks same-generation pending/ready
identity, readable retained frames, independence from ordinary geometry callbacks,
selector defenses, binding replacement, real removal, scope-kind replacement and
terminal retirement. It creates actual Cocoa accessibility objects without OS
windows and does not certify human screen-reader behavior.

Full test/native results will be recorded after final-source verification.

The first new test used the wrong snapshot helper name and failed compilation;
its corrected original-source failing regression supplies the oracle. An early
programmatic-close edit missed the direct path; the regression caught it, and
that failure is preserved alongside the fix. The first full offscreen suite
passes the driver but is denied the workbench test's owned Unix socket; an
explicitly admitted complete rerun passes. No failed run is promoted as evidence.

This checkpoint addresses current geometry and retained-view accessibility
ownership. It does not close full P6/P11 latency, native/GPU memory, physical
input/displays, overnight soak, human accessibility or Mac distribution gates.
