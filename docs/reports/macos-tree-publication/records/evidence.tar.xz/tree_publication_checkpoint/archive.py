from pathlib import Path
import json,hashlib,tarfile
R=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-tree-publication');D=R/'docs/reports/macos-tree-publication/records'
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
review=json.loads((P/'prism-v1/prism.json').read_text());process=json.loads((P/'prism-v1/process.json').read_text());disposition=json.loads((P/'prism-disposition.json').read_text());assert process['exit_code']==1 and not process['error']and process['source_index_stable']and review['coverage']['complete']and review['coverage']['files']==19 and len(review['findings'])==1 and disposition['result']=='REVIEWED_FINDING_DISPOSITION'
sources=json.loads((P/'final-source.json').read_text())['sources'];assert all(sha(R/n)==h for n,h in sources.items())
inputs={};allowed={'.json','.stdout','.stderr','.txt','.py','.go','.m','.log','.md'}
for f in sorted(P.rglob('*')):
 if f.is_file()and not f.is_symlink()and '__pycache__'not in f.parts and f.suffix in allowed:inputs['tree_publication_checkpoint/'+f.relative_to(P).as_posix()]=f
for n in sources:inputs['final_source/'+n]=R/n
index={n:{'sha256':sha(f),'bytes':f.stat().st_size}for n,f in inputs.items()};archive=D/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=3)as tar:
 for n,f in inputs.items():tar.add(f,arcname=n,recursive=False)
with tarfile.open(archive,'r:xz')as tar:
 assert set(tar.getnames())==set(index)
 for item in tar:assert item.isfile()and hashlib.sha256(tar.extractfile(item).read()).hexdigest()==index[item.name]['sha256']
(D/'evidence-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'files':index,'note':'Original stale-layout, modal-transfer and real parking regressions and failed attempts; final race/vet/native preflights; versioned final native outline checker; one Prism checkpoint with reviewed not-applicable disposition and explicit clipped-row tests. Binaries excluded; receipt hashes retained.'},indent=2)+'\n')
summary=json.loads((P/'final-summary.json').read_text());q={'result':'REVIEWED_TREE_AND_RETAINED_VIEW_PUBLICATION','base_commit':json.loads((P/'checkpoint-source.json').read_text())['base_commit'],'sources':sources,'internal_review':'APPROVED_SOURCE','prism_provider':'anthropic','prism_model':'claude-sonnet-5-5','prism_exit_code':1,'prism_coverage_complete':True,'prism_files':19,'prism_reported_findings':1,'prism_unresolved_findings':0,'prism_disposition':'6676cba3705e2053 not applicable: production explicitly omits clipped rows; internal confirmation and positive/negative race fixtures','prepared_files':6204,'prepared_changed':False,'final_native_composed_cycles':5,'final_tree_ax_rows_each':18,'native_tree_samples':240,'native_workflow_stages':9,'full_p6_qualified':False,'full_p11_qualified':False,'full_1000_cycle_qualified':False,'archive_sha256':sha(archive),'archive_members':len(inputs),'archive_bytes':archive.stat().st_size}
(D/'qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='sources'},indent=2))
