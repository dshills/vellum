from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-tree-publication')
for name in ['tree.go','tree_geometry.go','tree_accessibility.go','accessibility.go','accessibility_grid_publication.go','accessibility_darwin.m']:(p/('before-'+name)).write_bytes((r/'drivers/cogent'/name).read_bytes())
f=r/'drivers/cogent/tree.go';s=f.read_text().replace('measurement                atomic.Pointer[TreeInspection]','measurement                atomic.Pointer[TreeInspection]\n measurementScene atomic.Pointer[core.Scene]',1).replace('\tt.measurement.Store(nil)\n\toutlineRegistry.Lock()', '\tt.measurement.Store(nil)\n t.measurementScene.Store(nil)\n\toutlineRegistry.Lock()',1);f.write_text(s)
f=r/'drivers/cogent/tree_geometry.go';s=f.read_text().replace('"math"','"math"\n "slices"',1);s=s.replace('\tt.measurement.Store(m)\n\tif old == nil || old.Generation != m.Generation || old.Bounds != m.Bounds {','\tt.measurementScene.Store(t.host.Scene)\n\tt.measurement.Store(m)\n\tif t.host.Scene != nil && t.host.Scene.GlobalLayoutPending() || !sameTreeAccessibilityMeasurement(old, m) {',1);needle='''	t.requestMu.Lock()
	request := t.requested''';idx=s.index('func (t *outlineBinding) currentMeasurement()');before=s[:idx];after=s[idx:];after=after.replace('m.Viewport != t.projection.State.Viewport {','m.Viewport != t.projection.State.Viewport || m.Pending != t.projection.State.Pending {',1);after=after.replace(needle,''' if scene := t.measurementScene.Load(); scene != nil && scene.GlobalLayoutPending() {
  return nil
 }
 if t.measurement.Load() != m {
  return nil
 }
'''+needle,1);f.write_text(before+after)
f=r/'drivers/cogent/accessibility.go';s=f.read_text().replace('GridGeneration       uint64', '// Grid-prefixed fields are the existing bounded virtual-view wire protocol.\n // Both managed tables and outlines use its pending/completed transaction.\n GridGeneration       uint64',1);needle='''		if n.Kind == ui.DataGrid && r.control != nil && r.control.grid != nil {
			stampGridAccessibility''';s=s.replace(needle,'''  if n.Kind == ui.DataTree && r.control != nil && r.control.outline != nil {
   stampTreeAccessibility(r, nodes[start:])
   guardTreeAccessibility(r.control.outline, nodes[start:], handlers)
  }
'''+needle,1);f.write_text(s)
f=r/'drivers/cogent/accessibility_grid_publication.go';s=f.read_text().replace('previous[0].Parent == host.Parent {','previous[0].Parent == host.Parent && previous[0].Role == host.Role {',1);f.write_text(s)
f=r/'drivers/cogent/accessibility_darwin.m';s=f.read_text();old='![host[@"role"] isEqual:@"table"]';assert s.count(old)==1;s=s.replace(old,'(![host[@"role"] isEqual:@"table"]&&![host[@"role"] isEqual:@"outline"])',1);f.write_text(s)
