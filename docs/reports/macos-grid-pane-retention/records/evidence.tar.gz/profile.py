import hashlib,importlib.util,json,sys
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-grid-latency')
sys.path.insert(0,str(r/'scripts'))
spec=importlib.util.spec_from_file_location('grid_benchmark',r/'scripts/benchmark-grid.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
binary=p/'loadedgrid-baseline';before=m.selected_inputs()
samples,outcome=m.run_case(binary,p/'baseline-profile',10000,False,2048,128,False,180,cpu_profile=p/'baseline-cpu.pprof')
after=m.selected_inputs();assert before==after
d={'result':'DIAGNOSTIC_CPU_PROFILE','scope':'Actual fixed10k,2048 measured events after128 warm events, process-wide Go CPU profile; excluded from warm target qualification.','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'selected_inputs_before':before,'selected_inputs_after':after,'source_stable':True,'profile_sha256':hashlib.sha256((p/'baseline-cpu.pprof').read_bytes()).hexdigest(),'outcome':outcome,'timings_ns':m.summarize([samples])}
(p/'profile-summary.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'result':d['result'],'samples':len(samples),'binary_sha256':d['binary_sha256'],'profile_sha256':d['profile_sha256']}))
