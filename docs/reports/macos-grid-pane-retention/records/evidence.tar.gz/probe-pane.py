import hashlib,importlib.util,json,sys
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-grid-latency');sys.path.insert(0,str(r/'scripts'))
spec=importlib.util.spec_from_file_location('grid_benchmark',r/'scripts/benchmark-grid.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
binary=p/'loadedgrid-pane-final';before=m.selected_inputs()
samples,outcome=m.run_case(binary,p/'pane-probe',10000,False,120,128,False,60)
after=m.selected_inputs();assert before==after
d={'result':'SINGLE_PROCESS_PROBE','scope':'One unchanged stored400-cell fixed10k workload; not five-process/full-case qualification.','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'selected_inputs_before':before,'selected_inputs_after':after,'source_stable':True,'outcome':outcome,'timings_ns':m.summarize([samples])}
(p/'pane-probe-summary.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'result':d['result'],'samples':len(samples),'ui_work_ns':d['timings_ns']['ui_work_ns']['pooled']}))
