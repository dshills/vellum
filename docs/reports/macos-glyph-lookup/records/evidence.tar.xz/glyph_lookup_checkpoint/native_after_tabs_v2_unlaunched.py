"""Paired original/stage59 native frame measurements after reviewed GUI fixtures."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
R=Path('/private/tmp/vellum-glyph-lookup');B=Path('/private/tmp/vellum-large-data');P=Path('/private/tmp/vellum-macos-glyph-lookup');Q=Path('/private/tmp/vellum-macos-quiet-current');T=Path('/private/tmp/vellum-macos-tab-close-native')
sys.path.insert(0,str(R/'scripts'))
from child_process import run_child
from sdk_environment import child_environment

def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def identity(root):
 names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if n]
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=root),'tracked':{n:sha(root/n)for n in names},'prepared':{f.relative_to(root/'drivers/cogent/build').as_posix():sha(f)for m in ['upstream','typesetting']for f in sorted((root/'drivers/cogent/build'/m).rglob('*'))if f.is_file()}}
def canceled():return(Q/'stop-live').exists()
if canceled():raise InterruptedError('native tests canceled by returning human')
assert json.loads((Q/'testing-authorization.json').read_text())['live_window_input_performance_tests_allowed']
inputs=json.loads((P/'native-queue-inputs.json').read_text());assert inputs['candidate_commit']==identity(R)['commit']
endpoints={'original':identity(B),'candidate':identity(R)}
assert all(e['clean']for e in endpoints.values()) and len(endpoints['original']['prepared'])==6209 and len(endpoints['candidate']['prepared'])==6210
bins={'original':Q/'loadedgrid','candidate':P/'stage59-loadedgrid'}
assert all(sha(bins[n])==inputs['binaries'][n]for n in bins)
assert endpoints['original']==json.loads((Q/'baseline.json').read_text()),'original committed runtime endpoint changed'
original_build=json.loads((Q/'build-grid.json').read_text());candidate_build=json.loads((P/'stage59-native-build-v2.json').read_text())
assert original_build['exit_code']==0 and not original_build['error'] and original_build['source_prepared_stable']
assert original_build['source_commit']==endpoints['original']['commit'] and original_build['baseline_sha256']==sha(Q/'baseline.json') and original_build['produced_file_sha256']==inputs['binaries']['original']
assert candidate_build['exit_code']==0 and not candidate_build['error'] and candidate_build['source_commit']==endpoints['original']['commit']
assert sha(Q/'build-grid.json')==inputs['build_receipts']['original'] and sha(P/'stage59-native-build-v2.json')==inputs['build_receipts']['candidate']
for n,h in inputs['reviewed_sources'].items():
 assert endpoints['candidate']['tracked'][n]==h
 if n.startswith('drivers/'):
  assert candidate_build['source_delta_before'][n]==candidate_build['source_delta_after'][n]==h
assert all(candidate_build['prepared_before'][n]==candidate_build['prepared_after'][n]==h for n,h in endpoints['candidate']['prepared'].items())
(P/'native-runtime-baseline.json').write_text(json.dumps(endpoints,indent=2)+'\n')
predecessor=T/'native-summary.json';deadline=time.monotonic()+11200
while not predecessor.exists():
 if canceled():raise InterruptedError('human returned; do not launch native performance')
 if time.monotonic()>deadline:raise TimeoutError('tab sequence terminal receipt missing')
 time.sleep(2)
tab_summary=json.loads(predecessor.read_text());assert tab_summary['result']=='PASS_SCOPED_NATIVE_TAB_CLOSE_WITH_TWO_DETECTED_FAULTS'
assert all(c['native_cleanup_zero']for c in tab_summary['checks'].values())
predecessor_binding={'summary_sha256':sha(predecessor),'runtime_baseline_sha256':tab_summary['runtime_baseline_sha256'],'source_review_sha256':tab_summary['source_review_sha256'],'checks':tab_summary['checks']}
assert sha(T/'runtime-baseline.json')==predecessor_binding['runtime_baseline_sha256'] and sha(T/'source-review-v3.json')==predecessor_binding['source_review_sha256']
for n,c in tab_summary['checks'].items():assert sha(T/(n+'.json'))==c['receipt_sha256']
(P/'native-predecessor-binding.json').write_text(json.dumps(predecessor_binding,indent=2)+'\n')
# Revalidate both endpoints before starting and between every reaped process.
def stable():
 assert identity(B)==endpoints['original'] and identity(R)==endpoints['candidate'],'native source endpoints changed'
 assert all(sha(bins[n])==inputs['binaries'][n]for n in bins)
stable()
# Explicit compute readback first; no window or global input changes.
argv=['go','test','-json','-count=1','-run','^TestVellumGPUSceneNative','./paint/renderers/gpuscene']
env={**child_environment(runtime=True),'VELLUM_GPU_SCENE_TEST':'1','GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go'}
start=time.monotonic();d={'argv':argv,'cwd':str(R/'drivers/cogent/build/upstream'),'producer_sha256':sha(__file__),'authorization_sha256':sha(Q/'testing-authorization.json'),'candidate_commit':endpoints['candidate']['commit'],'exit_code':None,'error':None}
try:
 if canceled():raise InterruptedError('native tests canceled')
 with(P/'stage59-native-gpu.stdout').open('xb')as so,(P/'stage59-native-gpu.stderr').open('xb')as se:d['exit_code']=run_child(argv,cwd=R/'drivers/cogent/build/upstream',env=env,stdout=so,stderr=se,timeout=180).returncode
except BaseException as error:d['error']={'type':type(error).__name__,'message':str(error)}
finally:
 d['elapsed_seconds']=time.monotonic()-start
 for c in ['stdout','stderr']:
  f=P/('stage59-native-gpu.'+c);d[c+'_sha256']=sha(f)if f.exists()else None
 (P/'stage59-native-gpu.json').write_text(json.dumps(d,indent=2)+'\n')
assert d['exit_code']==0 and d['error']is None
records=[json.loads(l)for l in(P/'stage59-native-gpu.stdout').read_text().splitlines()if l.startswith('{')]
roots=[r for r in records if r.get('Test','').startswith('TestVellumGPUSceneNative')and '/'not in r['Test']and r.get('Action')in ['pass','fail','skip']]
assert len(roots)==4 and all(r['Action']=='pass'for r in roots)and not any(r.get('Action')=='skip'for r in records)
stable()
spec=importlib.util.spec_from_file_location('benchmark',R/'scripts/benchmark-grid.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
# The queue is launched in its own owned group. Native children inherit it, so
# the outer owner's timeout/kill reaps them even if the queue cannot cooperate.
class OwnedSubprocess:
 def __getattr__(self,n):return getattr(subprocess,n)
 def Popen(self,*args,**options):
  assert options.pop('start_new_session') is True
  child=subprocess.Popen(*args,**options)
  try:assert os.getpgid(child.pid)==os.getpgrp()
  except BaseException:
   if child.poll()is None:child.kill()
   child.wait(timeout=5);raise
  return child
def stop_direct_child(child):
 if child.poll()is None:child.kill()
b.subprocess=OwnedSubprocess();b.terminate_owned_group=stop_direct_child
# Check stop requests inside each bounded process observation loop.
selector_factory=b.selectors.DefaultSelector
class StopAwareSelector:
 def __init__(self):self.inner=selector_factory()
 def register(self,*args,**kwargs):return self.inner.register(*args,**kwargs)
 def select(self,*args,**kwargs):
  if canceled():raise InterruptedError('human returned; stop owned native benchmark')
  return self.inner.select(*args,**kwargs)
 def close(self):return self.inner.close()
b.selectors.DefaultSelector=StopAwareSelector
out=P/'native-comparison';out.mkdir(exist_ok=False);results={mode:{n:{}for n in bins}for mode in ['cpu','gpu']};progress=[]
for mode in results:
 for variable in [False,True]:
  for rows in [10000,1000000]:
   case=f"{'variable'if variable else 'fixed'}-{rows}"
   for n in bins:results[mode][n][case]=[]
   for repetition in range(5):
    for n in (['original','candidate']if repetition%2==0 else ['candidate','original']):
     if canceled():raise InterruptedError('native tests canceled')
     stable();directory=out/mode/n/case/f'run-{repetition+1}'
     samples,process=b.run_case(bins[n],directory,rows,variable,120,128,False,180,gpu_scene_rendering=mode=='gpu')
     assert process['result']=='PASS'and process['exit_code']==0
     assert all(r.get('warmup_guard')==1 for r in process['records']);stable()
     results[mode][n][case].append(samples);progress.append({'mode':mode,'version':n,'case':case,'repetition':repetition+1,'result_sha256':sha(directory/'result.json')});(out/'progress.json').write_text(json.dumps(progress,indent=2)+'\n');print(mode,n,case,repetition+1,flush=True)
    b.compare_geometry(results[mode]['original'][case][-1],results[mode]['candidate'][case][-1]);assert all(a['geometry']==c['geometry']for a,c in zip(results[mode]['original'][case][-1],results[mode]['candidate'][case][-1]))
for mode in results:
 for n in bins:
  for prefix in ['fixed','variable']:
   for a,c in zip(results[mode][n][prefix+'-10000'],results[mode][n][prefix+'-1000000']):b.compare_geometry(a,c)
summary={mode:{n:{case:{'timings_ns':b.summarize(runs),'go_process_alloc_bytes':b.distribution([s['go_process_alloc_bytes']for run in runs for s in run]),'go_process_mallocs':b.distribution([s['go_process_mallocs']for run in runs for s in run])}for case,runs in cases.items()}for n,cases in versions.items()}for mode,versions in results.items()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
q={'result':'MEASURED_PAIRED_STAGE59_NATIVE_FRAMES','processes':80,'ordinary_samples':9600,'sources':{n:endpoints[n]['commit']for n in endpoints},'binaries':inputs['binaries'],'runtime_baseline_sha256':sha(P/'native-runtime-baseline.json'),'predecessor_binding':predecessor_binding,'authorization_sha256':sha(Q/'testing-authorization.json'),'producer_sha256':sha(__file__),'native_gpu_roots_passed':4,'warm_targets_ns':{'p95':4000000,'p99':6000000},'warm_target_met':{mode:{n:b.warm_target_met(cases)for n,cases in versions.items()}for mode,versions in summary.items()},'summary_sha256':sha(out/'summary.json'),'full_p6_qualified':False,'full_p11_qualified':False,'scope':'Four ordinary native cases, five interleaved original/candidate pairs each in CPU and opt-inGPU modes; exact geometry. Physical presentation/input/GPU allocation and fullP6 remain separate.'}
(P/'native-summary.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q),flush=True)
