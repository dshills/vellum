NEEDS_FIX for one portable test expectation; production source remains approved.

`span_scratch_test.go:152` assumes capacity256 admits exactly10 rows, which relies on a24-byte span. On32-bit the correct12-byte layout admits21. Derive the expected count from `unsafe.Sizeof(span{})` and the32-slot/64KiB limits.

The production builder exactly matches the approved pilot. All10 reference methods reproduce the pinned original; per-event lockstep, actual reused-pointer held operation, ownership/bound/refusal checks and the current race receipt are meaningful. No other concrete source/oracle issue found. Fault controls should target nonzero pool reset, packet alias and borrow-before-refusal. Runtime/performance adoption remains separate.

Exact inputs and finding are bound in [candidate-review-v1.json](candidate-review-v1.json).
