from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/vellum-span-scratch');P=Path('/private/tmp/vellum-macos-span-scratch')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
base=json.loads((P/'prepared-baseline.json').read_text());expected=json.loads((P/'final-prepare.json').read_text())['prepared_after'];assert len(base)==6214 and len(expected)==6216
changed={k for k in base.keys()|expected.keys()if base.get(k)!=expected.get(k)};assert changed=={'upstream/paint/renderers/sceneplan/'+n for n in ['builder.go','span_scratch_reference_test.go','span_scratch_test.go']}
after=json.loads((P/'final-prepare-clean.json').read_text())['prepared_after'];assert after==expected
code_names=['drivers/cogent/native/dependencies.json','drivers/cogent/native/patches/spanscratch/0062-reuse-bounded-span-row-scratch.patch','drivers/cogent/native/patches/spanscratch/original-hashes.json','drivers/cogent/native/patches/spanscratch/output-hashes.json']
code={n:sha(R/n)for n in code_names}
checks={}
for name in ['final-prepare','final-prepare-clean','final-preparation-tests-v2','final-sceneplan-race','final-renderer-vet','final-adapter-race','final-adapter-vet','original-matrix','candidate-matrix','final-native-gpu','final-native-build']:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==0 and not d['error'] and d['source_delta_stable']
 assert all(d['source_delta_before'].get(n)==d['source_delta_after'].get(n)==h for n,h in code.items())
 assert d['overlay_inputs_before']==d['overlay_inputs_after']
 for channel in ['stdout','stderr']:assert sha(P/(name+'.'+channel))==d[channel+'_sha256']
 # Existing upstream raster tests write generated PNGs. Every actual dependency
 # leaf remains exact; retain these generated artifacts separately, then normal
 # preparation must restore the precise6216-leaf installation.
 for stamp in ['prepared_before','prepared_after']:
  assert all(d[stamp].get(k)==v for k,v in expected.items())
  added=set(d[stamp])-set(expected)
  assert all(k.startswith('upstream/paint/renderers/rasterx/testdata/')and k.endswith('.png')for k in added)
 checks[name]={'receipt_sha256':sha(P/(name+'.json')),'elapsed_seconds':d['elapsed_seconds'],'argv':d['argv'],'exit_code':0,'generated_artifacts_in_prepared_before':len(set(d['prepared_before'])-set(expected)),'generated_artifacts_in_prepared_after':len(set(d['prepared_after'])-set(expected))}
for name,needle in [('fault-reset-v2','invalid scratch row'),('fault-ownership','reused staging changed earlier operation'),('fault-admission','warm row borrowed before budget admission')]:
 d=json.loads((P/(name+'.json')).read_text());assert d['exit_code']==1 and not d['error'] and d['source_delta_stable'] and needle in(P/(name+'.stdout')).read_text() and not(P/(name+'.stderr')).read_text()
 assert d['overlay_inputs_before']==d['overlay_inputs_after'];assert all(sha(k)==v for k,v in d['overlay_inputs_after'].items())
local=json.loads((P/'paired-local-summary.json').read_text());assert local['pairs']==5
for pair in range(1,6):
 for mode in ['original','candidate']:
  d=json.loads((P/f'pair-{pair}-{mode}.json').read_text());assert d['exit_code']==0 and not d['error'] and d['source_delta_stable'] and d['prepared_before']==d['prepared_after'];assert d['overlay_inputs_before']==d['overlay_inputs_after']
  for channel in ['stdout','stderr']:assert sha(P/f'pair-{pair}-{mode}.{channel}')==d[channel+'_sha256']
 assert json.loads((P/f'pair-{pair}-original-packet.json').read_text())[0]['batch_pixels_sha256']==json.loads((P/f'pair-{pair}-candidate-packet.json').read_text())[0]['batch_pixels_sha256']
a=json.loads((P/'original-matrix-pixels.json').read_text());b=json.loads((P/'candidate-matrix-pixels.json').read_text());assert len(a)==len(b)==48 and a==b
roots=[json.loads(line)for line in(P/'final-native-gpu.stdout').read_text().splitlines()];assert not any(x.get('Action')=='skip'for x in roots)
passed=[x['Test']for x in roots if x.get('Action')=='pass' and x.get('Test','').startswith('TestVellumGPUSceneNative')and '/'not in x['Test']];assert len(passed)==4
report=R/'docs/reports/macos-span-scratch/README.md';s=report.read_text().replace('Final preparation, matrix, race/vet, explicit headless GPU\nchecks, negative controls and checkpoint review are pending.','Normal preparation reproduces three pinned outputs (6,214 to 6,216 leaves);\nall other dependency leaves are unchanged. All 48 current-driver matrix records\nmatch across four DPI settings and fixed/variable rows. The affected renderer\nand complete offscreen adapter race/vet suites pass. All four explicit native\nGPU readback roots pass without skips. Three isolated injected faults are caught\nby assertions for stale row length, held output mutation and pre-admission\nborrowing. The native loaded-grid candidate is built and hash-bound, unlaunched.\n\nThe initial preparation unittest retained the old 61-patch expectation and\nfailed; updating its expected contiguous range to 62 passes all 11 checks.\nExisting upstream raster tests generate 17 PNGs beneath prepared testdata.\nTheir receipts retain those artifacts; regeneration restores the exact 6,216\nsource leaves before commit. Internal final review and one bounded Anthropic\nClaude Sonnet 5.5 Prism review precede commit.');report.write_text(s)
names=sorted(set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R).decode().splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).decode().splitlines()));assert len(names)==8,names
sources={n:sha(R/n)for n in names};manifest={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sources':sources};(P/'checkpoint-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={**manifest,'result':'PASS_SCOPED_SPAN_SCRATCH','checks':checks,'prepared_before_files':6214,'prepared_after_files':6216,'all_other_leaves_unchanged':True,'software_frames_identical':48,'negative_controls_detected':3,'local_capture_pairs':5,'local_capture_cpu_profiling_active':False,'host_native_endurance_concurrent':True,'local_capture_medians':local['medians'],'native_gpu_roots_passed':passed,'native_build_sha256':sha(P/'loadedgrid'),'native_binary_launched':False,'native_performance_gain_qualified':False,'physical_or_retained_memory_gain_qualified':False,'full_p6_qualified':False,'full_p11_qualified':False};(P/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS11code/buildgates,48exactframes,3detectedfaults,5localpairs,4nativeGPUroots,6214to6216;8sourcefiles bound')
