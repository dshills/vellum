The builder-local transient row-span pool is a sound bounded optimization; no concrete source blocker found.

Current `Builder.Span` repeatedly appends into newly nil rows across glyph streams. The pilot preserves its reserve and row-band growth formula, reuses only after reserve succeeds, and copies stage60 detached packet storage before recycling. Its32 slots/64KiB/256-span per-buffer limits bound idle backing; Seal drops all scratch. Cached physical capacity must never become logical row capacity or an admission discount.

Required tests compare the original and candidate after every span/flush and at warm exact/refused boundaries, hold prior packet/encoded data through scratch overwrites, cover moving/gapped/multi-span rows and pool exhaustion, and detect no-reset/alias/budget faults. Measure fresh-builder repeated streams and the actual400-cell workload before adoption.

This optimization affects ScenePacket capture; defaultCPU ImgSpanner stays unchanged. The profiled concurrent-host software samples are diagnostic only, with no native/frame/performance or fullMac qualification. Exact source/diagnostic hashes and detailed guards are in [builder-pilot-review.json](builder-pilot-review.json).
