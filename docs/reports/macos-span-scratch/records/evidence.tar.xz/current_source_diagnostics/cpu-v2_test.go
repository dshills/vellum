//go:build offscreen

package cogent

import (
	"bytes"
	"cogentcore.org/core/math32"
	"cogentcore.org/core/paint/render"
	"cogentcore.org/core/paint/renderers/rasterx"
	"cogentcore.org/core/paint/renderers/sceneplan"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"github.com/dshills/vellum/app"
	"github.com/dshills/vellum/ui"
	"github.com/dshills/vellum/virtual"
	"image"
	"image/draw"
	"os"

	"reflect"
	"runtime"
	"runtime/pprof"
	"testing"
	"time"
)

func TestVellumCurrentRasterProfile(t *testing.T) {
	records := []map[string]any{}
	for _, dpi := range []float32{96} {
		for _, variable := range []bool{false} {
			t.Run(fmt.Sprintf("dpi%g-variable%t", dpi, variable), func(t *testing.T) {
				columns := make([]virtual.GridColumn, 20)
				for i := range columns {
					columns[i] = virtual.GridColumn{ID: fmt.Sprintf("c%d", i), Width: 96}
				}
				var src virtual.GridSource = &nativeGridSource{rows: 10000, revision: 1}
				rowHeight := 12
				if variable {
					src = &variableNativeSource{rows: 10000, revision: 1}
					rowHeight = 1
				}
				model, err := virtual.NewGrid(src, columns, virtual.GridConfig{RowHeight: rowHeight, HeaderHeight: 24, FrozenColumns: 2, OverscanRows: 2, OverscanColumns: 1, MaxCells: 4096}, virtual.GridViewport{Width: 768, Height: 624})
				if err != nil {
					t.Fatal(err)
				}
				a, err := app.New(app.Config{QueueCapacity: 64})
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(a.Close)
				if err = a.Open(app.Window{ID: "one", Title: "Software grid matrix", Width: 1500, Height: 1250, View: func() ui.Node {
					return ui.Node{ID: "root", Kind: ui.Column, Style: ui.Style{Padding: ui.Some(ui.Insets{}), Gap: ui.Some(float32(0))}, Children: []ui.Node{{ID: "title", Kind: ui.Label, Text: "Exact coverage grid matrix"}, {ID: "data", Kind: ui.DataGrid, Grid: model, Style: ui.Style{Grow: ui.Some(float32(0)), MinSize: ui.Some(ui.Size{Width: 1299, Height: 1060}), MaxSize: ui.Some(ui.Size{Width: 1299, Height: 1060})}}}}
				}}); err != nil {
					t.Fatal(err)
				}
				config := manualConfig(t, 7)
				config.LogicalDPI = dpi
				config.Theme.Default.Typography = ui.Some(ui.Typography{Family: "Noto Sans", Size: 15})
				manual, err := NewManual(testContext, a, config)
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(func() {
					if e := manual.Close(testContext); e != nil {
						t.Error(e)
					}
				})
				unitSettle(t, manual)
				var probe *coveredGridProbe
				if err = a.Do(func() {
					sc := manual.implementation.find("one").state.body.Scene
					probe = &coveredGridProbe{Renderer: sc.Renderer}
					sc.Renderer = probe
				}); err != nil {
					t.Fatal(err)
				}
				for frame, step := range []image.Point{{0, 12}} {
					if err = a.Do(func() {
						if e := model.Scroll(step.X, step.Y); e != nil {
							t.Error(e)
						}
						_ = a.Invalidate("one")
					}); err != nil {
						t.Fatal(err)
					}
					unitSettle(t, manual)
					pixels, err := manual.Capture(testContext, "one")
					if err != nil {
						t.Fatal(err)
					}
					g := gridInspection(t, a, model)
					visible := 0
					for _, c := range g.Cells {
						if !c.Bounds.Empty() {
							visible++
						}
					}
					if visible == 0 || visible > 4096 {
						t.Fatal("bad actual density", visible)
					}
					if len(probe.last) == 0 {
						t.Fatal("actual paint batch missing")
					}
					seed := probe.Renderer.Image().(*image.RGBA)
					rs := rasterx.New(math32.FromPoint(seed.Rect.Size())).(*rasterx.Renderer)
					rs.Render(probe.last)
					packet := rs.ScenePacket(probe.last)
					if packet == nil {
						t.Fatal("actual batch refused")
					}

					if !packet.Independent() {
						t.Fatal("batch is not independently repeatable")
					}
					baselinePixels := append([]byte(nil), rs.Image().(*image.RGBA).Pix...)
					for i := 0; i < 128; i++ {
						rs.Render(probe.last)
					}

					pf, err := os.OpenFile("/private/tmp/vellum-macos-current-raster-profile/cpu-v2.cpu", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
					if err != nil {
						t.Fatal(err)
					}
					runtime.GC()
					if err = pprof.StartCPUProfile(pf); err != nil {
						pf.Close()
						t.Fatal(err)
					}
					measured := func() testing.BenchmarkResult {
						defer pprof.StopCPUProfile()
						var before, after runtime.MemStats
						runtime.ReadMemStats(&before)
						started := time.Now()
						for i := 0; i < 1000; i++ {
							rs.Render(probe.last)
						}
						elapsed := time.Since(started)
						runtime.ReadMemStats(&after)
						return testing.BenchmarkResult{N: 1000, T: elapsed, MemAllocs: after.Mallocs - before.Mallocs, MemBytes: after.TotalAlloc - before.TotalAlloc}
					}()
					if err = pf.Close(); err != nil {
						t.Fatal(err)
					}
					if !bytes.Equal(baselinePixels, rs.Image().(*image.RGBA).Pix) {
						t.Fatal("repeated profile rendering changes pixels")
					}
					t.Logf("PROFILE_MODE %s %s %s", "cpu", measured.String(), measured.MemString())

					original, ok := packet.Encode()
					if !ok {
						t.Fatal("original encoded batch refused")
					}

					_ = reflect.DeepEqual
					compact, ok := packet.EncodeGPU()
					if !ok {
						t.Fatal("compact encoded batch refused")
					}
					got := image.NewRGBA(seed.Rect)
					replayCoveredGridGPU(t, compact, got)
					if !bytes.Equal(got.Pix, rs.Image().(*image.RGBA).Pix) {
						t.Fatal("serialized GPU batch differs from actual CPU raster")
					}
					records = append(records, map[string]any{"original_encoded_ops": len(original.Ops) / 64, "compact_encoded_ops": len(compact.Ops) / 64, "original_encoded_bytes": len(original.Ops) + len(original.Rows) + len(original.Refs) + len(original.Data), "compact_encoded_bytes": len(compact.Ops) + len(compact.Rows) + len(compact.Refs) + len(compact.Data), "profile_mode": "cpu", "iterations": measured.N, "ns_per_op": measured.NsPerOp(), "bytes_per_op": measured.AllocedBytesPerOp(), "allocations_per_op": measured.AllocsPerOp(), "batch_commands": len(probe.last), "batch_pixels_sha256": fmt.Sprintf("%x", sha256.Sum256(got.Pix)), "dpi": dpi, "variable": variable, "frame": frame, "pixels_sha256": fmt.Sprintf("%x", sha256.Sum256(pixels.Pix)), "image_bounds": pixels.Rect, "grid_bounds": g.Bounds, "scale": g.Scale, "viewport": g.Viewport, "visible_cells": visible, "cell_pool": len(g.Cells)})
				}
			})
		}
	}
	if len(records) != 1 {
		t.Fatal("incomplete software matrix", len(records))
	}
	f, e := os.OpenFile("/private/tmp/vellum-macos-current-raster-profile/cpu-v2-packet.json", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		t.Fatal(e)
	}
	if e = json.NewEncoder(f).Encode(records); e != nil {
		f.Close()
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
	_ = math32.Identity2()
}

type coveredGridProbe struct {
	render.Renderer
	last render.Render
}

func (p *coveredGridProbe) Render(r render.Render) render.Renderer {
	p.last = r.Clone()
	p.Renderer.Render(r)
	return p
}
func replayCoveredGridGPU(t *testing.T, e *sceneplan.Encoded, dst *image.RGBA) {
	t.Helper()
	word := func(b []byte, i uint32) uint32 { return binary.LittleEndian.Uint32(b[int(i)*4:]) }
	blend := func(dst, src, alpha, coverage uint32, over bool) uint32 {
		if !over {
			return (src * coverage / 16776960) & 255
		}
		a := (65535 - alpha*coverage/65535) * 257
		return ((dst*a + src*coverage) / 16776960) & 255
	}
	for y := 0; y < dst.Rect.Dy(); y++ {
		for x := 0; x < dst.Rect.Dx(); x++ {
			tile := uint32((y/sceneplan.TileSize)*e.Tiles.X + x/sceneplan.TileSize)
			start := word(e.Rows, tile*2)
			count := word(e.Rows, tile*2+1)
			at := dst.PixOffset(x, y)
			for ri := start; ri < start+count; ri++ {
				oi := word(e.Refs, ri) * 16
				minX, minY := int(word(e.Ops, oi)), int(word(e.Ops, oi+1))
				if x < minX || y < minY || x >= int(word(e.Ops, oi+2)) || y >= int(word(e.Ops, oi+3)) {
					continue
				}
				kind, over := word(e.Ops, oi+8), word(e.Ops, oi+9) == uint32(draw.Over)
				src := [4]uint32{word(e.Ops, oi+4), word(e.Ops, oi+5), word(e.Ops, oi+6), word(e.Ops, oi+7)}
				if kind == sceneplan.Spans {
					row := word(e.Ops, oi+10) + uint32(y-minY)*2
					s0, n := word(e.Data, row), word(e.Data, row+1)
					for si := s0; si < s0+n*3; si += 3 {
						if uint32(x) >= word(e.Data, si) && uint32(x) < word(e.Data, si+1) {
							for ch := 0; ch < 4; ch++ {
								dst.Pix[at+ch] = byte(blend(uint32(dst.Pix[at+ch]), src[ch], src[3], word(e.Data, si+2), over))
							}
						}
					}
					continue
				}
				if kind == sceneplan.Pixels {
					v := word(e.Data, word(e.Ops, oi+10)+uint32(y-minY)*word(e.Ops, oi+11)+uint32(x-minX))
					for ch := 0; ch < 4; ch++ {
						src[ch] = ((v >> uint(ch*8)) & 255) * 257
					}
				}
				mask := word(e.Ops, oi+12)
				if mask != ^uint32(0) {
					byteAt := (uint32(y-minY)+word(e.Ops, oi+15))*word(e.Ops, oi+13) + uint32(x-minX) + word(e.Ops, oi+14)
					a := ((word(e.Data, mask+byteAt/4) >> ((byteAt % 4) * 8)) & 255) * 257
					for ch := 0; ch < 4; ch++ {
						dst.Pix[at+ch] = byte(blend(uint32(dst.Pix[at+ch]), src[ch], src[3], a, over))
					}
				} else {
					for ch := 0; ch < 4; ch++ {
						v := src[ch]
						if over {
							v = (uint32(dst.Pix[at+ch])*(65535-src[3])*257/65535 + src[ch])
						}
						dst.Pix[at+ch] = byte(v >> 8)
					}
				}
			}
		}
	}
}

var captureProfileSink *sceneplan.Packet
