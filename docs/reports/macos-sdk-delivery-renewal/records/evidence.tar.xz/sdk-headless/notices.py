"""Reuse reviewed original notice constructor; bind conservative superset to calculator."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;X=W.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=json.loads((W/'plan.json').read_bytes());P=Path(p['output']);SDK=Path(p['sdk']);build=P/'owned native build'
assert all(sha(k)==v for k,v in p['pins'].items())
r=json.loads((build/'build-receipt.json').read_bytes())
assert r['runtime_executed'] is False and r['artifact_pair_binding']=='producer-observed-same-build'
assert r['source']['kind']=='sdk-payload' and r['source']['sdk_manifest_sha256']==p['sdk_manifest_sha256']
m=load('reviewed_notice_constructor',X/'macos-sdk-build-snapshot/integration.py');m.P=P;m.W=W/'notice-construction';m.W.mkdir()
bundle,workbench_record=m.notices(SDK,build)
# The full conservative module/native superset is explicitly reused. Do not label
# workbench selected-member evidence as calculator-specific link observation.
main_result=json.loads((W/'consume-v2-result.json').read_bytes());assert main_result['result']=='PASS_ALL_LISTED_SDK_MAIN_BUILDS'
calc=next(x for x in main_result['modules']['examples/macapps']['binaries']if x['import']=='github.com/dshills/vellum/examples/macapps/cmd/calculator')
assert sha(calc['path'])==calc['sha256']
destination=P/'calculator notices';shutil.copytree(bundle,destination)
manifest=json.loads((destination/'INVENTORY.json').read_bytes());manifest['artifact_sha256']=calc['sha256']
# The old constructor predates these three actual driver go:embed symbols.
# Retain their unchanged Apache declarations and exact source receipt explicitly.
refs=[]
for name in ['LICENSE_APACHE.txt','NOTICE.md','SOURCE.json']:
    source=SDK/'drivers/cogent/native/assets/symbols'/name
    body=m.native_gpu.read_regular(source,m.app_notices.MAX_FILE_BYTES);digest=hashlib.sha256(body).hexdigest();target='NOTICES/'+digest+'.txt'
    expected=json.loads((W/'sdk-transport.json').read_bytes())['current_driver_symbol_declarations'][str(source.relative_to(SDK))]
    assert digest==expected
    if target not in manifest['files']:
        (destination/target).write_bytes(body);manifest['files'][target]={'bytes':len(body),'sha256':digest}
    if target not in refs:refs.append(target)
manifest['components'].append({'id':'Vellum driver additional unchanged Material weather symbols','notice_files':refs})
manifest['scope']='Conservative post-empty-publication SDK Go/module/framework/standard-library and exact owned GPU archive compiled-component notice superset, rebound to the actual SDK calculator binary. Source identities and transport only; calculator-specific native survivor attribution is not established. All original declarations retained; no rights approval, public distribution, signing, runtime, visual, fixed-size or scrolling qualification.'
(destination/'INVENTORY.json').write_text(json.dumps(manifest,indent=2)+'\n')
sys.path.insert(0,str(SDK/'scripts'));import app_notices
calculator_record,_=app_notices.load(destination,calc['sha256'])
(W/'notice-result.json').write_text(json.dumps({'result':'PASS_SOURCE_BOUND_CONSERVATIVE_NOTICE_ASSEMBLY','sdk_manifest_sha256':p['sdk_manifest_sha256'],'build_receipt_sha256':sha(build/'build-receipt.json'),'workbench':{'bundle':str(bundle),'record':workbench_record},'calculator':{'binary':calc,'bundle':str(destination),'record':calculator_record},'constructor_sha256':sha(X/'macos-sdk-build-snapshot/integration.py'),'native_executed':False,'distribution_audit':'pending','applicability':'review-required'},indent=2)+'\n')
print(json.dumps({'result':'PASS_SOURCE_BOUND_CONSERVATIVE_NOTICE_ASSEMBLY','calculator_binary':calc['path'],'notice_components':calculator_record['components'],'notice_files':calculator_record['files']}))
