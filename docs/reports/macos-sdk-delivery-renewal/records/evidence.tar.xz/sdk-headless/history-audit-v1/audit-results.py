"""Read-only reconciliation of actual admitted headless outputs; never launch artifacts."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;X=W.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,why):
 if not ok:raise ValueError(why)
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'immutable symlink')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
b=read(X/'macos-sdk-post-empty-publication/binding.json');p=read(W/'plan.json');S=Path(p['sdk']);P=Path(p['output']);m=read(W/'consume-v2-result.json');h=read(W/'headless-controller-result.json');r=read(W/'result.json');inputs={**p['pins']};inputs[str(Path(__file__))]=sha(__file__)
need(m['result']=='PASS_ALL_LISTED_SDK_MAIN_BUILDS' and m['sdk_unchanged']and m['source_prepared_unchanged'],'all-main result');need(h['result']=='PASS_HEADLESS_COMMANDS' and not h['error']and h['pins_stable']and not h['stop'],'headless result')
need(list(h['commands'])==[x['name']for x in read(W/'headless-plan.json')['commands']],'exact5commands')
receipts=[(W/'consume-v2'/n,c)for n,c in m['commands'].items()]+[(W/'commands'/n,c)for n,c in h['commands'].items()];groups=[]
for directory,c in receipts:
 need(c['created']and c['exit_code']==0 and c['error']is None and not c['observation_errors']and c['logs_complete']and c['pins_stable']and not c['stop_at_exit']and c['owned']['terminal']and c['owned']['group_absent']and not c['owned']['errors'],'owned receipt')
 groups.append(c['owned']['group'])
 for name,log in c['logs'].items():
  f=directory/name;need(f.stat().st_size==log['bytes']and sha(f)==log['sha256'],'raw log hash/length');inputs[str(f)]=sha(f)
 f=directory/'owned.json';need(read(f)['group_absent'],'raw group receipt');inputs[str(f)]=sha(f)
# Fresh group membership observation, no command lines, no signal or process mutation.
ps=subprocess.run(['/bin/ps','-axo','pgid='],check=True,capture_output=True,timeout=10);live={int(n)for n in ps.stdout.split()};need(not set(groups)&live,'owned group still live')
for root in [Path(b['canonical']),Path(b['candidate'])]:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=30).decode().strip();status=subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=30);need(head==b['head']and not status,'current clean source HEAD');need({n:sha(root/n)for n in b['source']}==b['source'],'source bytes');prepared={d+'/'+n:v for d in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/d).items()};need(prepared==b['prepared'],'prepared vector')
need(vector(S)==b['sdk_files'],'complete SDK vector');need(all(sha(k)==v for k,v in p['pins'].items()),'all plan pins');need(sha(p['archive']['path'])==p['archive']['sha256'],'SDK archive')
binaries=[x for mod in m['modules'].values()for x in mod['binaries']]+[m['tagged_helper']]
for binary in binaries:
 f=Path(binary['path']);need(f.stat().st_size==binary['bytes']and sha(f)==binary['sha256'],'actual binary bytes');inputs[str(f)]=sha(f)
calc=read(W/'notice-result.json')['calculator']['binary'];app=P/'Vellum Calculator.app';need(sha(app/'Contents/MacOS/Vellum Calculator')==calc['sha256'],'app executable');need(vector(app)==r['app_files'],'complete app vector');need(r['native_app_launched']is False and r['signed']is False and r['notarized']is False,'app limitations')
inv=read(P/'owned native build/inventory.json');expected={(a['module'],a['file']):a['sha256']for a in read(W/'sdk-transport.json')['selected_assets']};need(len(inv['embedded_assets'])==4441 and {(a['module'],a['file']):a['sha256']for a in inv['embedded_assets']}==expected,'actual selected asset inventory');build=read(P/'owned native build/build-receipt.json');need(build['runtime_executed']is False and build['artifact_pair_binding']=='producer-observed-same-build','workbench build identity')
for directory in [W/'consume-v2',W/'commands']:
 for f in directory.rglob('*'):
  if f.is_file():inputs[str(f)]=sha(f)
for n in ['plan.json','consume-v2-plan.json','headless-plan.json','consume-v2-admission.json','root-execution-review.json','consume-v2-result.json','headless-controller-result.json','headless-inputs.json','sdk-transport.json','notice-result.json','result.json','refresh-bindings.json','source-refresh-review.json']:
 f=W/n;inputs[str(f)]=sha(f)
for f in [P/'owned native build/build-receipt.json',P/'owned native build/inventory.json',P/'owned native build/vellum-workbench',P/'owned native build/vellum-workbench.map',app/'Contents/Resources/APP_MANIFEST.json',app/'Contents/Resources/THIRD_PARTY_NOTICES/INVENTORY.json']:
 if f.is_file():inputs[str(f)]=sha(f)
notice=read(W/'notice-result.json')['calculator']['record'];out={'approved':True,'result':'PASS_INDEPENDENT_RECONCILIATION_CURRENT_PRIVATE_SDK_HEADLESS','unresolved_findings':[],'head':b['head'],'default_mains':m['main_count'],'tagged_helpers':1,'modules':len(m['modules']),'actual_owned_commands':len(receipts),'current_owned_groups_absent':groups,'group_membership_observation_sha256':hashlib.sha256(ps.stdout).hexdigest(),'raw_logs_reconciled':2*len(receipts),'source_files':len(b['source']),'prepared_files':len(b['prepared']),'SDK_files':len(b['sdk_files']),'source_prepared_SDK_archive_unchanged':True,'selected_assets':4441,'app_files':len(r['app_files']),'calculator_sha256':calc['sha256'],'notice_components':notice['components'],'notice_files':notice['files'],'workbench_native_selected_members':r['workbench_native_selected_members'],'native_original_components':82,'native_original_notice_files':408,'scope':'30actual default mains and one tagged helper built, optimized metadata checked; calculator viewport race regression; public workbench owned build/inventory; conservative notices and unsigned calculator app package/byte verification.','limits':['No application/native UI/runtime/probe execution.','Read-only Git HEAD/status observed; no Git/source/SDK mutations.','No signing, notarization, public distribution, rights approval, full M6/Mac closure or renewed performance/lifecycle acceptance.','Conservative workbench notice superset rebound to calculator; no calculator-specific native survivor attribution.'],'inputs':inputs}
with(W/'actual-result-audit.json').open('x')as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['inputs','current_owned_groups_absent','limits','scope']},indent=2));print('audit_sha256='+sha(W/'actual-result-audit.json'))
