"""Owned headless command controller; controller/artifact outputs are distinct."""
from pathlib import Path
import importlib.util,json,os,signal,sys
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');P=Path('/private/tmp/vellum-m6-post-empty-publication')
s=importlib.util.spec_from_file_location('cursor_host',W.parent/'macos-sdk-clean-0372adc/run.py');host=importlib.util.module_from_spec(s);s.loader.exec_module(host);h=host.h
name=sys.argv[1];plan=json.loads((W/(name+'-plan.json')).read_text());resultpath=W/(name+'-controller-result.json');assert not resultpath.exists()
(W/'commands').mkdir(exist_ok=True);P.mkdir(exist_ok=True)
prepared=[f for n in ['upstream','typesetting']for f in(T/'drivers/cogent/build'/n).rglob('*')if f.is_file()]
pins={str(p):h.sha(p)for p in[Path(__file__),h.GO,h.PY,h.GUARD,*[T/n for n in h.git(T,'ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')if n],*prepared,*[W/p for p in plan.get('helpers',[])]]}
(W/(name+'-inputs.json')).write_text(json.dumps({'plan':plan,'pins':pins},indent=2)+'\n')
stop=[False];previous={}
def interrupted(sig,frame):stop[0]=True
for sig in [signal.SIGTERM,signal.SIGINT]:previous[sig]=signal.signal(sig,interrupted)
stopping=lambda:stop[0]or(W/('stop-'+name)).exists();stable=lambda:all(h.sha(p)==v for p,v in pins.items())
prior=json.loads((W.parent/'macos-core-vet/scope.json').read_text())['prior_sdks'];prior['/private/tmp/vellum-core-vet-clean/relocated SDK/vellum-v0.1.0-alpha.2']={}

profile=h.PROFILE+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in[*prior,*plan.get('readonly',[])])
env={k:v for k,v in os.environ.items()if k in['HOME','USER','LANG','TMPDIR']};env.update(PATH=str(h.GO.parent)+':'+str(h.PY.parent)+':/usr/bin:/bin:/usr/sbin:/sbin',GOWORK='off',GOENV='off',GOTOOLCHAIN='local',GOFLAGS='-mod=readonly',GOMAXPROCS='2',CGO_ENABLED='1',GOPROXY='off',GOSUMDB='off',GOPATH='/Users/dshills/Development/Go',GOMODCACHE='/Users/dshills/Development/Go/pkg/mod')
result={'commands':{},'native_executed':False,'error':None}
try:
 for cmd in plan['commands']:
  command_profile=profile+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in cmd.get('readonly',[]))
  argv=['/usr/bin/sandbox-exec','-p',command_profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*cmd['argv']]
  r=h.g.execute(argv,Path(cmd['cwd']),W/'commands'/cmd['name'],stopping,stable,timeout=cmd.get('timeout',600),limit=16<<20);result['commands'][cmd['name']]=r
  h.need(r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors'],'owned '+cmd['name'])
  print(cmd['name']+' PASS',flush=True)
 result['result']='PASS_HEADLESS_COMMANDS'
except BaseException as e:result.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
finally:
 result['pins_stable']=stable();result['stop']=stopping()
 if not result['pins_stable']or result['stop']:result.update(result='FAILED_OR_CANCELED',error={'type':'BoundaryError','message':'drift or stop'})
 (W/('stop-'+name)).touch();resultpath.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in['result','error']}),flush=True)
 for sig,handler in previous.items():signal.signal(sig,handler)
if result['error']:sys.exit(1)
