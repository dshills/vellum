# Post-empty-publication private SDK and application package checks

This preparation binds clean source `70bf39175903f0bc8408e358d58781efdfa5032c`
to the genuine retained current SDK, archive SHA256
`fa6e9134404f445bf7334391c18eb755d08d89c0a374ec031caa828cf0d2bb4f`.
The retained SDK has 8,293 files including its manifest. Root's package and full
unchanged relocation checker already passed. This preparation executes no Go
builds and launches no application or native display probe.

`plan.json` pins source/SDK binding, genuine package/retention receipts, current
public scripts and reused external helpers. `headless-plan.json` lists exact
commands for root's later review/admission. No admission is supplied here.
`consume-v2-plan.json` and the source vector in `plan.json` adapt the already reviewed consumer:
14 current example/driver modules are discovered from the actual SDK manifest,
including placement. Actual Go list determines default mains; all resulting
executables and optimized metadata are checked. The original tagged window-cycle
helper remains a separate build; no main count is guessed. `mains.py` changes only
paths/current binding and uses that existing consumer's run function and executor.
Root must supply its `consume-v2-admission.json` after review before execution.

`execute.py` reuses the fixture checkpoint's owned headless controller byte for
byte except its output root. `grouped.py` reuses the exact reviewed ordinary
Python wrapper except the allowed current SDK path. Public `build-macos.py`
produces a workbench binary/linker map/build receipt/inventory. Public
`package-app.py` packages the built Calculator executable without signing.
`notices.py` reuses the original notice constructor, conservatively copies its
whole SDK/module/standard-library/native compiled superset, and explicitly
rebinds that superset to the calculator binary. It also adds the current driver weather-symbol Apache license, notice and source receipt that the older root-driver-license constructor did not collect. This is not a claim that the
workbench's observed native archive members are calculator-specific survivors.
The existing public app notice loader/copy/verifier enforce executable binding,
counts, paths, size limits and all transported bytes.

`sdk-transport.json` is an actual read-only retained-SDK observation, not a build
result: 4,105 current icon SVG identities, 28 SDK fonts (12 runtime), cursor and
other framework assets, exact notices, 82 native components and all 408 original
native notice files. The 268 Chroma lexer XMLs remain external module selected
embed inputs; the fresh workbench inventory must confirm those bytes. The final
verification requires all 4,441 current selected embed identities (the prior 4,438 plus three driver weather symbols), every original native
notice hash in the packaged app, SDK immutability, actual main build results and
unsigned calculator binary identity. Content-address notice deduplication means
packaged notice-file count need not equal 408 plus all Go declarations.

Calculator source still requests exactly 240x420dp, fixed size and disabled root
scrolling. The planned existing offscreen viewport regression verifies keys and
routing; it uses a 256x436 offscreen window to compensate its root decoration.
Neither that test nor packaging establishes current physical native window size,
resize behavior or scrolling. Those require separate live verification if
needed. No physical pointer/input, native lifecycle/performance, signing,
notarization, public distribution or blanket rights approval follows here.

Run only after root review/admission and away from timing preflight. Root may use
`python3 execute.py headless` after supplying the consumer admission. The planned
commands are serial to avoid competing builds. Outputs are new and previous
checkpoint receipts are read-only. A failure stops later work and retains logs;
there is no silent retry or replacement of a sealed result.
