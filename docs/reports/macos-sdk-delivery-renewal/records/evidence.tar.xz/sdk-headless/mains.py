"""Bind the reviewed all-main consumer to post-empty-publication; no new executor or validator."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
X=W.parent

def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    c=load('current_presentation_bindings',X/'macos-presentation-after-empty-publication/controller.py');b=c.configure_binding()
    p=json.loads((W/'plan.json').read_bytes());assert c.HEAD==p['head'] and str(c.SDK)==p['sdk']
    assert c.sha(X/'macos-presentation-after-empty-publication/binding.json')==p['binding_sha256']
    c.boundary({'source':b['source'],'prepared':b['prepared'],'sdk':b['sdk_files'],'pins':p['pins']})
    m=load('reviewed_all_main_consumer',X/'macos-sdk-stage0088-7c941a9/consume-v2.py')
    m.W=W;m.P=Path(p['output']);m.P.mkdir(exist_ok=True);m.PLAN=W/'consume-v2-plan.json'
    m.h.HEAD=c.HEAD
    def source(root):
        prepared={d+'/'+n:h for d in ['upstream','typesetting']for n,h in c.vector(root/'drivers/cogent/build'/d).items()}
        return {'head':c.HEAD,'tracked':c.source(root),'prepared':prepared}
    m.h.source=source
    m.h.PROFILE+=''.join('(deny file-write* (subpath '+json.dumps(str(root))+'))'for root in [c.C,c.T])
    m.run()
if __name__=='__main__':
    if sys.argv[1:]:raise ValueError('fixed reviewed all-main run only')
    main()
