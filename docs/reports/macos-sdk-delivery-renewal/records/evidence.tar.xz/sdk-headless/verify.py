"""Verify post-empty-publication SDK build/package transport; never execute an application."""
from pathlib import Path
import hashlib,json,plistlib,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;X=W.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
p=read(W/'plan.json');P=Path(p['output']);SDK=Path(p['sdk']);build=P/'owned native build';app=P/'Vellum Calculator.app'
assert all(sha(k)==v for k,v in p['pins'].items())
retention=read(X/'macos-sdk-post-empty-publication/retention.json')
vector={f.relative_to(SDK).as_posix():sha(f)for f in SDK.rglob('*')if f.is_file()}
assert vector==retention['files'] and not any(f.is_symlink()for f in SDK.rglob('*'))
receipt=read(build/'build-receipt.json');inventory=read(build/'inventory.json');n=read(W/'notice-result.json');calc=n['calculator']['binary']
assert receipt['runtime_executed']is False and receipt['artifact_pair_binding']=='producer-observed-same-build'
assert receipt['source']['kind']=='sdk-payload' and receipt['source']['sdk_manifest_sha256']==p['sdk_manifest_sha256']
assert sha(build/'vellum-workbench')==receipt['artifacts']['vellum-workbench']['sha256']
assert {x['file']:x['sha256']for x in inventory['sdk_files']}==retention['files']
modules={'cogentcore.org/core':SDK/'drivers/cogent/build/upstream','github.com/dshills/vellum/drivers/cogent':SDK/'drivers/cogent'}
transport=read(W/'sdk-transport.json');expected={(a['module'],a['file']):a['sha256']for a in transport['selected_assets']};assert len(inventory['embedded_assets'])==len(expected)==4441
assert {(a['module'],a['file']):a['sha256']for a in inventory['embedded_assets']}==expected
native=[a for a in inventory['native_link_observation']['archives']if a['sha256']==p['native_archive_sha256']]
assert len(native)==1 and native[0]['selected_members']
manifest=read(app/'Contents/Resources/APP_MANIFEST.json')
assert manifest['signed_identity']is None and manifest['notarized']is False
assert sha(calc['path'])==calc['sha256']==sha(app/'Contents/MacOS/Vellum Calculator')
with (app/'Contents/Info.plist').open('rb')as f:plist=plistlib.load(f)
assert plist['CFBundleExecutable']=='Vellum Calculator' and plist['CFBundleIdentifier']=='org.vellum.private.calculator'
sys.path.insert(0,str(SDK/'scripts'));import app_notices
app_notices.verify(app/'Contents/Resources/THIRD_PARTY_NOTICES',calc['sha256'],n['calculator']['record'])
# Verify all original native-component files have actually reached app notice payload,
# allowing content-address deduplication and conservative over-inclusion.
app_inventory=read(app/'Contents/Resources/THIRD_PARTY_NOTICES/INVENTORY.json')
shipped={a['sha256']for a in app_inventory['files'].values()}
ni=read(SDK/'release/native-components/wgpu-darwin-arm64/INVENTORY.json')
assert len(ni['components'])==82 and len(ni['files'])==408 and set(ni['files'].values())<=shipped
assert {sha(SDK/'drivers/cogent/native/assets/symbols'/name)for name in ['LICENSE_APACHE.txt','NOTICE.md','SOURCE.json']}<=shipped
third=read(SDK/'THIRD_PARTY_INVENTORY.json')
for mod in third['modules']:
    if mod['module']in ['cogentcore.org/core','github.com/go-text/typesetting']:
        assert {a['sha256']for a in mod['license_files']}<=shipped
mains=read(W/'consume-v2-result.json');assert mains['result']=='PASS_ALL_LISTED_SDK_MAIN_BUILDS' and mains['sdk_unchanged'] and mains['source_prepared_unchanged']
result={'result':'PASS_POST_EMPTY_PUBLICATION_PRIVATE_SDK_DEMO_BUILDS_UNSIGNED_CALCULATOR_APP_AND_NOTICES','head':p['head'],'sdk_manifest_sha256':p['sdk_manifest_sha256'],'sdk_files':len(vector),'mains':mains['main_count'],'modules':len(mains['modules']),'selected_assets':len(inventory['embedded_assets']),'runtime_fonts':12,'sdk_fonts':28,'native_components':82,'native_original_notice_files':408,'workbench_native_selected_members':len(native[0]['selected_members']),'calculator_sha256':calc['sha256'],'app_files':{f.relative_to(app).as_posix():sha(f)for f in app.rglob('*')if f.is_file()},'SDK_unchanged':True,'calculator_source_contract':{'width_dp':240,'height_dp':420,'fixed_size':True,'disable_root_scrolling':True,'physical_behavior_verified_this_phase':False},'native_app_launched':False,'signed':False,'notarized':False,'public_distribution':False,'distribution_audit':'pending','applicability':'review-required','scope':'Actual SDK builds, original declarations and executable-bound conservative notice transport. Calculator source flags and offscreen checks do not establish current physical window behavior; no calculator-specific link-map, visual, native lifecycle or overall Mac qualification claim.'}
(W/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['result','modules','mains','selected_assets','native_components','SDK_unchanged']}))
