"""Read-only post-delay failure/cleanup reconciliation. No launch, signal or restoration."""
from pathlib import Path
import datetime,hashlib,json,subprocess
W=Path(__file__).resolve().parent;X=W.parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
def need(ok,why):
 if not ok:raise ValueError(why)
def vector(root):
 out={}
 for f in root.rglob('*'):
  need(not f.is_symlink(),'immutable symlink')
  if f.is_file():out[f.relative_to(root).as_posix()]=sha(f)
 return out
r=read(W/'result.json');p=read(W/'plan.json');start=read(W/'started.json');late=read(W/'post-tool-delay-observation.json');retired=read(W/'cua-relaunch-retirement.json');binding=X/'macos-sdk-post-empty-publication/binding.json';b=read(binding);proof=read(X/'macos-m6-post-empty-publication/result.json');app=Path(p['app']);binary=str(app/'Contents/MacOS/Vellum Calculator');cmd=r['command']
need(r['result']=='FAILED_OR_CANCELED'and r['native_executed']is True and r['performance_qualified']is False,'preserve actual failure');need(cmd['created']and cmd['group']==98310 and cmd['watchdog_seconds']==600 and cmd['error']=={'type':'TimeoutError','message':'native watchdog'}and 600<=cmd['seconds']<601 and cmd['exit_code']is None and cmd['logs_complete']is False,'watchdog incomplete command');need(cmd['owned']['terminal']and cmd['owned']['group_absent']and cmd['owned']['exit_code']==-15 and not cmd['owned']['errors'],'original group terminal');need(not r['finalization_errors']and r['source_prepared_SDK_app_unchanged']and r['persisted_geometry_unchanged'],'recorded original finalization boundary')
for channel,log in cmd['logs'].items():
 f=W/'native'/channel;need(f.stat().st_size==log['bytes']and sha(f)==log['sha256'],'preserved retained log bytes; does not make incomplete capture complete')
need(start['plan_sha256']==sha(W/'plan.json')and all(sha(k)==v for k,v in p['pins'].items()),'plan/source/evidence pins')
need(retired['task_relaunched_pid']==61507 and retired['retired']and retired['signals']==['SIGINT']and retired['current_exact_binary_processes']==[] and retired['source_or_settings_restore_attempted']is False,'separate relaunch retirement record');need(late['owned_group_98310_members']==[]and len(late['exact_binary_processes'])==1 and late['exact_binary_processes'][0]['pid']==61507 and late['exact_binary_processes'][0]['command']==binary,'exact task relaunch observation')
# ps is a read-only current absence observation; retain only relevant rows, not unrelated process commands.
ps=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,stat=,command='],capture_output=True,check=True,timeout=10);relevant=[]
for line in ps.stdout.decode().splitlines():
 parts=line.split(None,4)
 if len(parts)!=5:continue
 pid,ppid,group=map(int,parts[:3]);command=parts[4]
 if command==binary or command.startswith(binary+' ')or group in [98310,61507]:relevant.append({'pid':pid,'ppid':ppid,'group':group,'state':parts[3],'command':command})
need(not relevant,'current task executable/group still present')
for root in [Path(b['canonical']),Path(b['candidate'])]:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,timeout=30).decode().strip();status=subprocess.check_output(['git','status','--porcelain','-z'],cwd=root,timeout=30);names=subprocess.check_output(['git','ls-files','-z'],cwd=root,timeout=30).decode().split('\0')[:-1];need(head==b['head']==p['head']and not status and set(names)==set(b['source']),'full current clean source identity');need({n:sha(root/n)for n in names}==b['source'],'full source vector');need({d+'/'+n:v for d in ['upstream','typesetting']for n,v in vector(root/'drivers/cogent/build'/d).items()}==b['prepared'],'full prepared vector')
need(vector(Path(b['sdk']))==b['sdk_files'],'full SDK vector');need(vector(app)==proof['app_files'],'full app vector')
core=Path('/Users/dshills/Library/Cogent Core');geometry={}
for n in ['window-geometry-0.3.6.json','window-geometry-0.3.6.lst','window-geometry-0.3.6.lck']:
 f=core/n;need(not f.is_symlink(),'geometry symlink')
 if f.exists():need(f.is_file()and f.stat().st_size<=16<<20,'bounded geometry');geometry[n]={'bytes':f.stat().st_size,'sha256':sha(f)}
need(geometry==retired['all_geometry_files'],'current geometry still equals post-retirement observation');need(geometry['window-geometry-0.3.6.json']==start['geometry']['files']['window-geometry-0.3.6.json'],'geometry JSON bytes preserved');changed=[n for n in geometry if geometry[n]!=start['geometry']['files'].get(n)];need(changed==['window-geometry-0.3.6.lst']and retired['geometry_matches_original']is False,'explicit timestamp-list drift')
inputs={str(f):sha(f)for f in [Path(__file__),W/'run.py',W/'plan.json',W/'admission.json',W/'source-review.json',W/'started.json',W/'result.json',W/'post-tool-delay-observation.json',W/'cua-relaunch-retirement.json',W/'native/owned.json',W/'native/stdout',W/'native/stderr',binding,X/'macos-m6-post-empty-publication/result.json',X/'macos-m6-post-empty-publication/actual-result-audit.json']};inputs.update(p['pins'])
out={'result':'FAILED_NATIVE_SCOPE_AUDITED_AND_CURRENT_TASK_CLEANUP_VERIFIED','review_approved':True,'native_case_passed':False,'physical_or_OS_pointer_checks_passed':False,'performance_qualified':False,'full_Mac_qualified':False,'current_cleanup_verified':True,'source_freeze_may_be_released':True,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':b['head'],'failed_owned_group':98310,'watchdog_seconds_actual':cmd['seconds'],'original_owned_retirement':cmd['owned'],'retained_logs_match_recorded_hashes':True,'logs_complete':False,'stderr':'315 retained bytes: denied geometry JSON save attempt; not a successful settings write.','CUA_delay_and_relaunch':'Root-authored records report27352.1394s blocked getApp and exact task binary relaunched as61507 outside owned group; separately SIGINT-retired. These records do not establish pointer/key/resize acceptance.','current_exact_binary_and_two_groups':relevant,'process_snapshot_sha256':hashlib.sha256(ps.stdout).hexdigest(),'complete_current_boundaries':{'C_and_T_clean_source_files':len(b['source']),'prepared_files':len(b['prepared']),'SDK_files':len(b['sdk_files']),'app_files':len(proof['app_files']),'source_prepared_SDK_app_unchanged':True},'geometry':{'current':geometry,'JSON_bytes_unchanged':True,'changed_from_original':changed,'post_retirement_drift':False,'restoration_attempted_by_reviewer':False},'material_failure_facts':['Owned launch reached600-second watchdog; output capture incomplete and no successful close verdict.','Delayed tool caused separate task relaunch outside original owned watchdog group.','Persisted geometry timestamp-list bytes changed after original scope finalized; original geometry JSON bytes remain identical.'],'limits':['Failed result and all original records left unchanged.','Current absence does not prove window/native-object deallocation.','No native, CUA, build, test, signal, OS settings or restoration action performed by reviewer.','Read-only Git HEAD/status and process inventory used solely for cleanup/source observations.'],'inputs':inputs}
with(W/'internal-failed-scope-review.json').open('x')as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({'result':out['result'],'review_sha256':sha(W/'internal-failed-scope-review.json'),'source_files':len(b['source']),'SDK_files':len(b['sdk_files']),'geometry_changed':changed,'current_relevant_processes':relevant}))
