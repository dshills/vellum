"""One owned relocated calculator launch for separate OS-pointer checks."""
from pathlib import Path
import datetime,importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;X=W.parent;M=X/'macos-m6-post-empty-publication'
APP=Path('/private/tmp/vellum-m6-post-empty-publication/Vellum Calculator.app')
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load('calculator_binding',X/'macos-presentation-after-empty-publication/controller.py')
b=c.configure_binding();g=load('calculator_owned_executor',c.GUARD);l=load('calculator_exclusive_lease',c.LEASE)
read=lambda p:json.loads(Path(p).read_bytes())
def run():
 c.need(not(W/'result.json').exists()and not(W/'stop-live').exists(),'fresh native scope')
 p=read(W/'plan.json');a=read(W/'admission.json')
 c.need(a['approved']and a['plan_sha256']==c.sha(W/'plan.json')and a['head']==p['head']==c.HEAD,'exact reviewed calculator admission')
 issued=datetime.datetime.fromisoformat(a['issued_utc']);deadline=datetime.datetime.fromisoformat(a['last_launch_utc'])
 c.need(issued.tzinfo is not None and deadline.tzinfo is not None and 0<(deadline-issued).total_seconds()<=900 and a['user_availability']=="I'm logging out so the machine is yours to use",'bounded user availability')
 required=[Path(__file__),M/'result.json',M/'headless-controller-result.json',M/'consume-v2-result.json',M/'root-execution-review.json',c.P/'binding.json',c.P/'controller.py',c.GUARD,c.LEASE]
 c.need(all(p['pins'].get(str(k))==c.sha(k)for k in required),'mandatory executable/evidence/binding pins')
 proof=read(M/'result.json');suite=read(M/'headless-controller-result.json');mains=read(M/'consume-v2-result.json')
 c.need(proof['head']==c.HEAD and proof['sdk_manifest_sha256']==c.sha(c.SDK/'SDK_MANIFEST.json')and proof['result']=='PASS_POST_EMPTY_PUBLICATION_PRIVATE_SDK_DEMO_BUILDS_UNSIGNED_CALCULATOR_APP_AND_NOTICES','current genuine package')
 c.need(suite['result']=='PASS_HEADLESS_COMMANDS'and suite['pins_stable']and not suite['stop']and suite['error']is None and len(suite['commands'])==5 and all(c.passed(r)for r in suite['commands'].values()),'genuine five-command prerequisites')
 c.need(mains['result']=='PASS_ALL_LISTED_SDK_MAIN_BUILDS'and mains['source_commit']==c.HEAD and mains['sdk_unchanged']and mains['source_prepared_unchanged'],'genuine current all-main build')
 c.need(p['app']==str(APP)and APP.resolve(strict=True)==APP and all(not q.is_symlink()for q in[APP,*APP.parents])and all(not APP.is_relative_to(root)for root in[c.C,c.T,c.SDK]),'canonical relocated app outside source/SDK')
 binary=APP/'Contents/MacOS/Vellum Calculator'
 c.need(c.vector(APP)==proof['app_files']and c.sha(binary)==proof['calculator_sha256'],'complete packaged app identity')
 pins={**p['pins'],str(W/'plan.json'):c.sha(W/'plan.json'),str(W/'admission.json'):c.sha(W/'admission.json')}
 boundary={'source':b['source'],'prepared':b['prepared'],'sdk':b['sdk_files'],'pins':pins}
 stop=[False]
 def interrupt(sig,frame):stop[0]=True
 previous={sig:signal.signal(sig,interrupt)for sig in[signal.SIGINT,signal.SIGTERM]}
 stopping=lambda:stop[0]or(W/'stop-live').exists()
 result={'result':'INCOMPLETE','native_executed':False,'error':None,'finalization_errors':[],'os_pointer_verdict':'separate CUA observations required','performance_qualified':False}
 profile='(version 1)(allow default)(deny network* (remote ip) (local ip))'+''.join('(deny file-write* (subpath '+json.dumps(str(root.resolve()))+'))'for root in[c.C,c.T,c.SDK,c.CORE_DATA,APP])
 env={'HOME':os.environ['HOME'],'USER':os.environ.get('USER','dshills'),'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'en_US.UTF-8','GOMAXPROCS':'2'}
 argv=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(binary)]
 try:
  with l.LiveLease()as lease:
   geometry=None
   def stable():
    ok=c.stable(boundary)and c.vector(APP)==proof['app_files']
    return ok and lease.held()and not stopping()and issued<=datetime.datetime.now(datetime.timezone.utc)<=deadline
   try:
    c.boundary(boundary);geometry=c.geometry_state();c.need(stable(),'current availability before launch')
    c.write(W/'started.json',{'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':c.sha(W/'plan.json'),'geometry':geometry,'scope':'CUA-generated OS pointer/native keys; no hardware/human or timing claim'})
    command=g.execute(argv,APP.parent,W/'native',stopping,stable,timeout=600,limit=2<<20)
    result.update(native_executed=command['created'],command=command);c.need(c.passed(command),'native command completion/cleanup')
    result['result']='PASS_OWNED_PACKAGED_CALCULATOR_LAUNCH_AND_CLEANUP'
   except BaseException as error:result.update(result='FAILED_OR_CANCELED',error={'type':type(error).__name__,'message':str(error)})
   finally:
    for name,check in [('source_prepared_SDK_app',lambda:(c.boundary(boundary),c.need(c.vector(APP)==proof['app_files'],'app drift'))),('persisted_geometry',lambda:c.need(geometry is not None and c.geometry_state()==geometry,'geometry unavailable or changed'))]:
     try:check();result[name+'_unchanged']=True
     except BaseException as error:result['finalization_errors'].append({'phase':name,'type':type(error).__name__,'message':str(error)})
    if result['finalization_errors']:result['result']='FAILED_OR_CANCELED'
    (W/'stop-live').touch();c.write(W/'result.json',result)
 finally:
  for sig,handler in previous.items():signal.signal(sig,handler)
 print(json.dumps({'result':result['result'],'error':result['error']}),flush=True)
 if result['error']or result['finalization_errors']:raise SystemExit(1)
if __name__=='__main__':
 if sys.argv[1:]:raise ValueError('fixed reviewed native scope only')
 run()
