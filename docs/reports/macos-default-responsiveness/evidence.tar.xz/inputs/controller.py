"""Private native feedback preflight. prepare is headless; run needs fresh admission.

Reuses Vellum's reviewed owned executor and strict public journal validator.
No native launch, display query or settings read occurs at import/prepare time.
"""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, signal, subprocess, sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
X = P.parent
B = P / 'builds'
SDK105_SOURCE = X / 'macos-sdk-display105'
STAGE105_PINS = {}
STAGE105_HELPER_SHA = '82d666b9588204c5d3348e5ca10a9f7331b73e762ddedfb6b22f9daa0e51b95f'
SEALED104 = X / 'macos-presentation-display104'
OLD = X / 'macos-presentation-native-7c941a9'
PREVIOUS = X / 'macos-presentation-after-empty-publication'
SOURCE103 = X / 'macos-presentation-source103'
FAILED = X / 'macos-presentation-source102'
PRIOR = X / 'macos-presentation-source101'
OLDER = X / 'macos-presentation-source100'
LEGACY = X / 'macos-presentation-current'
BINDING = None
GO = Path('/Users/dshills/Development/Go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.6.darwin-arm64/bin/go')
GO_SHA = '9c35eaeb87fd3df884c3540b25f3556902c164d88afe8a88e62ceb819d0da211'
HELPER = X / 'macos-app-examples/go-check'
C = Path('/Users/dshills/Development/projects/Vellum')
T = Path('/private/tmp/vellum-macos-native-results-97aee13')
# Final stage0105 source/SDK association is supplied only after actual retention and independent association.
# Import and synthetic controls do not admit a build or a native execution.
SDK = P / 'UNBOUND_SDK'
HEAD = None
CORE_DATA = Path('/Users/dshills/Library/Cogent Core')
LIB = SDK / 'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'
LIB_SHA = '786aaad8bd66fa5f7c0dd395c57ff7454838387c8aae29f33f3c6652ecec4883'
GUARD = X / 'macos-sdk-native-238b3b6/run.py'
LEASE = Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')
CASES = [
    {'id':'serial-grid-cpu','kind':'grid','gpu':False,'paced':False,'samples':120},
    {'id':'serial-tree-gpu','kind':'tree','gpu':True,'paced':False,'samples':120},
    {'id':'paced-grid-gpu','kind':'grid','gpu':True,'paced':True,'samples':600},
    {'id':'paced-tree-cpu','kind':'tree','gpu':False,'paced':True,'samples':600},
]
PROBES = {'display':['/usr/sbin/system_profiler','SPDisplaysDataType','-json'],
          'power':['/usr/bin/pmset','-g','batt'],
          'power-settings':['/usr/bin/pmset','-g','custom'],
          'os':['/usr/bin/sw_vers']}

def need(ok, message):
    if not ok: raise ValueError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1<<20), b''): h.update(block)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_bytes())
def write(path, value):
    with Path(path).open('x') as f: f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def vector(root):
    result={}
    for f in root.rglob('*'):
        need(not f.is_symlink(),'symlink in immutable input')
        if f.is_file(): result[f.relative_to(root).as_posix()]=sha(f)
    return result

def file_record(path,bound):
    archive=load('preflight_regular_reader',T/'scripts/native_archive.py')
    stream,before=archive.regular_stream(path,bound);h=hashlib.sha256();size=0
    with stream:
        while block:=stream.read(min(1<<20,bound-size+1)):
            size+=len(block);need(size<=bound,'output exceeds admitted byte bound');h.update(block)
        archive.unchanged(stream,before)
    need(size==before.st_size,'short or growing output')
    after=Path(path).lstat()
    need((after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)==(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns),'output path changed during observation')
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}

def source(root):
    git=lambda *a:subprocess.check_output(['git',*a],cwd=root,timeout=30)
    need(git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-z'),'clean current source required')
    names=git('ls-files','-z').decode().split('\0')[:-1]
    need(0<len(names)<20000 and all((root/n).is_file()and not(root/n).is_symlink()for n in names),'current regular source names')
    return {n:sha(root/n)for n in names}

def configure_binding():
    global HEAD, SDK, LIB, BINDING, STAGE105_PINS
    b=read(P/'binding.json')
    need(b['schema']==1 and type(b['head'])is str and len(b['head'])==40 and all(v in '0123456789abcdef'for v in b['head']),'explicit full final source commit')
    need(b['canonical']==str(C) and b['candidate']==str(T),'fixed source roots')
    root=Path(b['sdk']);need(root.is_absolute() and all(not v.is_symlink()for v in[root,*root.parents]),'absolute regular private SDK root')
    need(b['go']=={'path':str(GO),'sha256':GO_SHA,'version':'go1.25.6'} and sha(GO)==GO_SHA,'fixed Go compiler')
    need(type(b['association_inputs'])is dict and 0<len(b['association_inputs'])<=64 and all(sha(k)==v for k,v in b['association_inputs'].items()),'root-supplied final SDK/source association evidence')
    need(type(b['source'])is dict and type(b['prepared'])is dict and type(b['sdk_files'])is dict,'complete association vectors')
    need(sha(SDK105_SOURCE/'final_source.py')==STAGE105_HELPER_SHA,'reviewed explicit stage0105 source helper')
    identity=load('presentation_stage0105_identity',SDK105_SOURCE/'final_source.py')
    committed,stage_pins=identity.load_final_source(SDK105_SOURCE)
    need(committed['head']==b['head']and committed['source_files']==b['source']and committed['prepared_files']==b['prepared'],'binding differs from explicit accepted stage0105 source')
    need(all(b['association_inputs'].get(k)==v for k,v in stage_pins.items()),'stage0105 complete identity pins missing from SDK binding')
    need(sha(P/'binding.json')==sha(SDK105_SOURCE/'binding.json'),'exact actual retained SDK105 binding copy required')
    proof=read(SDK105_SOURCE/'association-review.json')
    need(proof['approved']is True and proof['findings']==[]and proof['head']==b['head']and proof['binding_sha256']==sha(P/'binding.json'),'actual independent SDK105 association review required')
    STAGE105_PINS={**stage_pins,**{str(f):sha(f)for f in[SDK105_SOURCE/'binding.json',SDK105_SOURCE/'association-review.json']}}
    HEAD,SDK,BINDING=b['head'],root,b
    LIB=SDK/'drivers/cogent/build/libs-darwin/arm64/libwgpu_native.a'
    return b

def sdk_association(plan):
    need(sha(GO)==GO_SHA and sha(LIB)==LIB_SHA,'current compiler and source-built archive')
    manifest=read(SDK/'SDK_MANIFEST.json')
    need(manifest['source']=={'clean':True,'commit':HEAD} and manifest['private_build']is True,'fresh private SDK source association')
    need(manifest['files']=={k:v for k,v in plan['sdk'].items()if k!='SDK_MANIFEST.json'},'complete private SDK manifest/vector association')
    for rel in ['scripts/check-presentation.py','scripts/native_archive.py','scripts/child_process.py','scripts/sdk_environment.py']:
        need(plan['sdk'][rel]==sha(T/rel),'current public validation/process scripts in SDK')

def boundary(plan):
    need(source(C)==source(T)==plan['source'],'source association changed')
    for root in [C,T]:
        v={d+'/'+n:h for d in ['upstream','typesetting']for n,h in vector(root/'drivers/cogent/build'/d).items()}
        need(v==plan['prepared'],'prepared native input changed')
    need(vector(SDK)==plan['sdk'],'full fresh SDK changed')
    sdk_association(plan)
    need(stable(plan),'controller/build/binary input changed')

def stable(plan):
    return all(Path(p).is_file()and not Path(p).is_symlink()and sha(p)==h for p,h in plan['pins'].items())

def geometry_state():
    need(all(not p.is_symlink()for p in[CORE_DATA,*CORE_DATA.parents]),'Core data path redirection')
    values={}
    for name in ['window-geometry-0.3.6.json','window-geometry-0.3.6.lst','window-geometry-0.3.6.lck']:
        p=CORE_DATA/name;need(not p.is_symlink(),'geometry path redirection')
        if p.exists():
            need(p.is_file()and p.stat().st_size<=16<<20,'bounded geometry file')
            record=file_record(p,16<<20);values[name]={'bytes':record['bytes'],'sha256':record['sha256']}
    return {'directory_exists':CORE_DATA.exists(),'files':values}

def passed(r):
    return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']

def previous_evidence():
    """Retain exact FAILED source70: two valid serials, failed third, absent fourth.

    Only direct campaign bytes and sealed prior audit manifests are rehashed;
    nested source103/older evidence is preserved, not requalified or rewalked.
    Historical retirement below is a recorded observation, not a current scan.
    """
    prior=read(PREVIOUS/'result.json');names=[case['id']for case in CASES]
    need(prior['result']=='FAILED_OR_CANCELED'and prior['native_executed']is True and prior['release_qualified']is False,'retained failed source70 campaign')
    need(prior['completed']==names[:2]and list(prior['cases'])==names[:3]and prior['error']=={'type':'ValueError','message':'case failed; later cases remain unexecuted'}and 'final_boundary_error'not in prior,'exact historical attempted/completed population')
    need(not(PREVIOUS/names[3]).exists(),'fourth historical case must remain absent')
    audit=read(PREVIOUS/'native-result-review.json')
    need(audit['approved']is True and audit['audit_result']=='PASS_ACTUAL_FAILED_SCOPE_AUDIT'and audit['outcome']=='FAILED'and audit['acceptance']is False and audit['release_qualified']is False and audit['full_M3_qualified']is False and audit['unresolved_audit_findings']==[],'sealed failed scope audit, no acceptance')
    need(audit['actual_owned_groups']==23 and len(audit['actual_commands'])==23 and audit['all_actual_groups_terminal_and_currently_absent']is True and audit['final_boundary_error_absent']is True,'exact recorded23historicalgroups')
    groups=[]
    frozen=read(P/'refresh-baseline.json')['previous_case_files']
    for index,case in enumerate(CASES[:3]):
        name=case['id'];root=PREVIOUS/name;record=read(root/'result.json')
        need(record==prior['cases'][name]and record['geometry_before']==record['geometry_after'],'historical case/geometry observations differ')
        expected={'result.json','sealed','native-command.json','presentation.json','native/stdout','native/stderr','native/owned.json'}
        for phase in(['before','after']if index<2 else['before']):
            for probe in PROBES:expected.update([phase+'/'+probe+'-command.json',*[phase+'/'+probe+'/'+f for f in['stdout','stderr','owned.json']]])
        actual={f.relative_to(root).as_posix()for f in root.rglob('*')if f.is_file()or f.is_symlink()}
        need(actual==expected and len(expected)==(39 if index<2 else 23),'historical raw files missing/extra')
        journal=read(root/'presentation.json')
        historical_config={k:v for k,v in expected_config(case).items()if k!='DisplayBackpressureNS'}
        need(journal['Config']==historical_config,'historical workload changed')
        if index<2:
            v=record['validation'];need(record['result']=='PASS_SCOPED_NATIVE_FEEDBACK'and record['error']is None and v['result']=='VALID_SERIAL_NATIVE_FEEDBACK_JOURNAL'and v['config']==historical_config and v['measured_input_latency_ms']['count']==120 and v['measured_input_latency_ms']['p95']>33.3 and v['cadence_qualified']is False and v['physical_latency_qualified']is False,'two valid serial captures retain latency FAIL')
            need(journal['Result']=='CAPTURED_DIAGNOSTIC'and journal['RunError']=='','historical serial journal state')
        else:
            need(record['result']=='FAILED_OR_CANCELED'and record['error']=={'type':'ValueError','message':'owned native case failed or canceled'}and 'validation'not in record,'failed third must not become validated')
            need(journal['Result']=='FAILED_DIAGNOSTIC'and journal['RunError']=='presentation capture: lost prefix feedback\npresentation capture: lost prefix feedback','preserved failed capture')
            point=journal['BeforeClose']['Presentation'];samples=point['Samples'][:journal['AcquisitionCutoff']];inputs=point['Inputs'][:journal['ReceiptCutoff']];first=min(v['Received']for v in inputs)
            lost=[v for v in samples if v['State']=='skipped'];armed=[v for v in samples if v['Armed']]
            need(len(samples)==733 and len(inputs)==728 and len(lost)==3 and all(v['Tag']==0 and v['Armed']is False and v['Acquired']>first for v in lost)and len(armed)==728 and all(v['State']=='presented'for v in armed),'three late skips/all728armed presented; no startup repair')
            need(audit['cases'][name]['promoted_or_repaired']is False and audit['cases'][name]['latency_or_cadence_acceptance']is False,'failed paced raw metrics remain unqualified')
        paths=[root/'native-command.json',*[root/phase/(probe+'-command.json')for phase in(['before','after']if index<2 else['before'])for probe in PROBES]]
        for path in paths:
            receipt=read(path);native=path.name=='native-command.json';code=1 if index==2 and native else 0
            need(receipt['created']and receipt['exit_code']==code and receipt['error']is None and not receipt['observation_errors']and receipt['logs_complete']and receipt['pins_stable']and not receipt['stop_at_exit']and receipt['owned_tmp_empty']is True,'historical complete receipt')
            owned=receipt['owned'];need(owned['terminal']and owned['group_absent']and owned['exit_code']==code and not owned['errors'],'historical retirement receipt')
            output=root/'native'if native else path.parent/path.name.removesuffix('-command.json')
            need(read(output/'owned.json')=={k:receipt[k]for k in['pid','group','argv','cwd']},'historical launch identity')
            for channel,info in receipt['logs'].items():
                f=output/channel;need(f.stat().st_size==info['bytes']and sha(f)==info['sha256'],'historical raw receipt log')
            groups.append(owned['group'])
    need(len(groups)==len(set(groups))==23,'exact23distinct historical groups')
    actual={str(f):sha(f)for case in CASES[:3]for f in(PREVIOUS/case['id']).rglob('*')if f.is_file()}
    need(actual==frozen==audit['case_file_vector'],'comparison evidence changed: exact101direct case files')
    pins=read(P/'comparison-baseline.json')['inputs']
    need(all(sha(k)==v for k,v in pins.items()),'comparison evidence changed')
    return pins

def expected_config(case):
    return {'Method':'routed-'+case['kind']+'-scroll','Samples':case['samples'],'Warmup':128,'DataSize':10000,'Variable':False,'Deep':False,'Novel':False,'GPURequested':case['gpu'],'DisplayBackpressureNS':1_000_000_000,**({'Paced':True}if case['paced']else{})}

def arguments(case,binary,journal):
    result=[binary,'-perf','-'+('rows'if case['kind']=='grid'else'nodes')+'=10000','-perf-warmup=128','-perf-samples='+str(case['samples']),'-perf-presentation='+str(journal),'-experimental-display-backpressure=1s']
    if case['gpu']: result.append('-gpu-scene'if case['kind']=='grid'else'-perf-gpu-scene')
    if case['paced']: result.append('-perf-60hz')
    return result

def admission(plan,review,record,now):
    need(plan['head']==HEAD and plan['cases']==CASES and plan['native_execution_ready']is False,'fixed headless plan')
    need(review['approved']is True and review['controller_ready']is True and review['unresolved_findings']==[]and review['plan_sha256']==sha(P/'plan.json'),'reviewed exact controller plan')
    need(all(sha(k)==v for k,v in review['inputs'].items()),'reviewed controller changed')
    need(record['execution_ready']is True and record['plan_sha256']==sha(P/'plan.json')and record['review_sha256']==sha(P/'controller-review.json'),'fresh native admission binding')
    auth=record['human_authorization']
    need(auth['desktop_available']is True and type(auth['message'])is str and 0<len(auth['message'])<=4096,'explicit current desktop availability required')
    start=datetime.datetime.fromisoformat(record['not_before_utc']);end=datetime.datetime.fromisoformat(record['last_launch_utc'])
    need(start.tzinfo is not None and end.tzinfo is not None and start<=now<end and datetime.timedelta(0)<end-start<=datetime.timedelta(minutes=30),'native admission expired or invalid')
    return end

def validate_capture(path,case,binary_sha):
    validator=load('preflight_presentation_validator',T/'scripts/check-presentation.py')
    journal=validator.load(path,file_record(path,64<<20)['sha256'])
    need(journal['Config']==expected_config(case),'captured workload differs from admitted case')
    result=validator.validate(journal,HEAD,binary_sha)
    need(result['cadence_qualified']is False and result['physical_latency_qualified']is False,'unexpected qualification escalation')
    return result

def execute_cases(plan,host,root):
    """Serial single-attempt orchestration. host supplies the admitted OS boundary."""
    result={'result':'INCOMPLETE','native_executed':False,'completed':[],'cases':{},'error':None,'release_qualified':False}
    try:
        for case in plan['cases']:
            host.check();d={'result':'INCOMPLETE','error':None};result['cases'][case['id']]=d
            directory=root/case['id'];directory.mkdir(mode=0o700)
            before=None; journal=directory/'presentation.json'
            try:
                before=host.geometry();d['geometry_before']=before
                d['configuration_before']=host.probes(directory/'before')
                host.check()
                need(not journal.exists(),'fresh capture output')
                d['native']=host.native(case,journal,directory/'native');result['native_executed']|=d['native']['created']
                need(passed(d['native']),'owned native case failed or canceled')
                need((directory/'native/stderr').stat().st_size==0,'native stderr requires review')
                d['journal']=file_record(journal,64<<20)
                d['validation']=host.validate(case,journal)
                d['configuration_after']=host.probes(directory/'after')
                host.check()
                d['result']='PASS_SCOPED_NATIVE_FEEDBACK'
            except BaseException as error:
                d.update(result='FAILED_OR_CANCELED',error={'type':type(error).__name__,'message':str(error)})
                raise
            finally:
                try:
                    d['geometry_after']=host.geometry();need(before==d['geometry_after'],'Core geometry files changed')
                except BaseException as error:
                    d.update(result='FAILED_OR_CANCELED',geometry_cleanup_error={'type':type(error).__name__,'message':str(error)})
                try:
                    if journal.exists() or journal.is_symlink():
                        d['retained_journal']=file_record(journal,64<<20)
                        need('journal'not in d or d['journal']==d['retained_journal'],'journal changed after validation')
                except BaseException as error:
                    d.update(result='FAILED_OR_CANCELED',journal_cleanup_error={'type':type(error).__name__,'message':str(error)})
                (directory/'sealed').touch()
                write(directory/'result.json',d)
                need(d['result']=='PASS_SCOPED_NATIVE_FEEDBACK','case failed; later cases remain unexecuted')
            result['completed'].append(case['id'])
        result['result']='PASS_SCOPED_NATIVE_FEEDBACK_PREFLIGHT'
    except BaseException as error: result.update(result='FAILED_OR_CANCELED',error={'type':type(error).__name__,'message':str(error)})
    finally:
        try: host.finish()
        except BaseException as error: result.update(result='FAILED_OR_CANCELED',final_boundary_error={'type':type(error).__name__,'message':str(error)})
        (root/'stop-live').touch();write(root/'result.json',result)
    return result

class NativeHost:
    def __init__(self,plan,deadline,lease,signaled):
        self.plan=plan;self.deadline=deadline;self.lease=lease;self.signaled=signaled
        self.g=load('preflight_owned_executor',GUARD)
        self.runtime_pins={str(P/n):sha(P/n)for n in['plan.json','controller-review.json','native-admission.json']}
    def runtime_stable(self): return all(sha(k)==v for k,v in self.runtime_pins.items())
    def stopping(self): return self.signaled[0]or(P/'stop-live').exists()or datetime.datetime.now(datetime.timezone.utc)>=self.deadline or not self.lease.held()
    def launch_stable(self):
        # Executor calls this after its own stop poll. Recheck stop/lease/deadline
        # AFTER the final potentially slow hash scan, immediately before Popen.
        return stable(self.plan) and self.runtime_stable() and self.lease.held() and not self.stopping()
    def check(self):
        need(self.lease.held()and not self.stopping()and self.runtime_stable(),'lease/stop/admission guard')
        need(datetime.datetime.now(datetime.timezone.utc)<self.deadline,'last launch deadline expired')
        boundary(self.plan)
        need(self.runtime_stable() and self.lease.held() and not self.stopping(),'final stop/deadline/lease after complete source scan')
    def finish(self):
        # Always inspect after cleanup, including cancellation, without launching
        # another probe or allowing an expired admission to hide input drift.
        need(self.lease.held()and self.runtime_stable(),'lease/admission lost through cleanup');boundary(self.plan)
        need(self.runtime_stable()and self.lease.held()and not self.signaled[0]and not(P/'stop-live').exists(),'controller canceled/admission or lease lost during cleanup')
    def geometry(self): return geometry_state()
    def command(self,argv,cwd,out,timeout):
        self.check();out.parent.mkdir(parents=True,exist_ok=True)
        tmp=out.parent/'tmp';tmp.mkdir(exist_ok=True,mode=0o700)
        profile='(version 1)(allow default)(deny network* (remote ip) (local ip))'+''.join('(deny file-write* (subpath '+json.dumps(str(p))+'))'for p in[C,T,SDK,CORE_DATA,SDK105_SOURCE,SEALED104,OLD,PREVIOUS,SOURCE103,FAILED,PRIOR,OLDER,LEGACY])
        env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(Path.home()),'TMPDIR':str(tmp),'GOMAXPROCS':'2','LANG':os.environ.get('LANG','en_US.UTF-8')}
        wrapped=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*argv]
        r=self.g.execute(wrapped,cwd,out,self.stopping,self.launch_stable,timeout=timeout,limit=16<<20)
        r['owned_tmp_empty']=tmp.is_dir() and not tmp.is_symlink() and not list(tmp.iterdir())
        if not r['owned_tmp_empty']:r['observation_errors'].append({'stage':'temporary-directory','message':'owned TMPDIR not empty; retained for review'})
        write(out.parent/(out.name+'-command.json'),r);return r
    def probes(self,root):
        values={}
        for name,argv in PROBES.items():
            r=self.command(argv,T,root/name,60);values[name]=r
            need(passed(r)and r['logs']['stdout']['bytes']>0 and r['logs']['stderr']['bytes']==0,'configuration probe failed '+name)
        return values
    def native(self,case,journal,out): return self.command(arguments(case,self.plan['binaries'][case['kind']]['path'],journal),SDK/'examples'/('loaded'+case['kind']),out,330)
    def validate(self,case,journal): return validate_capture(journal,case,self.plan['binaries'][case['kind']]['sha256'])

def prepare():
    need(not(P/'plan.json').exists(),'fresh headless preflight plan')
    binding=configure_binding()
    controls=read(P/'controls.json')
    need(passed(controls)and all(sha(k)==v for k,v in controls['source_pins'].items()),'current complete synthetic controls required')
    for channel,info in controls['logs'].items():
        f=P/'controls'/channel;need(sha(f)==info['sha256']and f.stat().st_size==info['bytes'],'raw headless controls')
    builds=read(B/'clean-native-builds.json')
    need(builds['source_commit']==HEAD and builds['binding_sha256']==sha(P/'binding.json') and set(builds['binaries'])=={'grid','tree'},'fresh bound optimized preflight binaries')
    source_files=source(C);need(source(T)==source_files==binding['source'],'complete final source association')
    pins={str(P/'binding.json'):sha(P/'binding.json'),**binding['association_inputs'],**STAGE105_PINS,**previous_evidence()};binaries=builds['binaries']
    for kind,entry in binaries.items():
        receipt=read(entry['build_receipt']);need(passed(receipt)and sha(entry['build_receipt'])==entry['build_receipt_sha256'],'owned optimized native build')
        need(receipt['binding_sha256']==sha(P/'binding.json') and all(sha(k)==v for k,v in receipt['source_pins'].items()),'genuine final SDK/compiler/build input association')
        for channel,info in receipt['logs'].items():
            f=B/('compile-'+kind)/channel;need(sha(f)==info['sha256']and f.stat().st_size==info['bytes'],'raw build logs');pins[str(f)]=sha(f)
        for f in[Path(entry['path']),Path(entry['build_receipt']),B/('compile-'+kind+'-build-info.txt')]:pins[str(f)]=sha(f)
        need(sha(entry['path'])==entry['sha256']==receipt['binary']['sha256']and entry['path']==receipt['binary']['path'],'binary drift')
        need(sha(B/('compile-'+kind+'-build-info.txt'))==entry['build_metadata_sha256'],'binary metadata drift')
    clock_sources=read(X/'macos-paced-presentation-cc2ec6a/clock-sources.json')
    for entry in clock_sources:
        need(sha(entry['path'])==entry['sha256'],'clock primary source changed');pins[entry['path']]=entry['sha256']
    for f in[Path(__file__),P/'tests.py',P/'check.py',P/'finalize_metadata_test.py',P/'comparison-baseline.json',P/'refresh-baseline.json',P/'controls.json',P/'controls/stdout',P/'controls/stderr',P/'README.md',B/'clean-native-builds.json',GO,HELPER,GUARD,LEASE,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',T/'scripts/check-presentation.py',X/'macos-sdk-stage0079-abe67c6-cache-v2/run.py']:
        pins[str(f)]=sha(f)
    for f in[OLD/n for n in ['controller.py','tests.py','check.py','README.md','plan.json','controller-review.json','headless-result.json','prism.json']]+list(OLD.rglob('stop-live')):
        pins[str(f)]=sha(f)
    plan={'head':HEAD,'binding_sha256':sha(P/'binding.json'),'source':source_files,'prepared':binding['prepared'],'sdk':binding['sdk_files'],'pins':pins,'binaries':binaries,'cases':CASES,'native_execution_ready':False,'scope':'UNPROFILED stage0105 acknowledged-skip opt-in one-second display-backpressure four-case experiment, not full80-case or M3 qualification. Same cases, thresholds, public validator, owned executor and exclusive live lease. Fresh private SDK and full final source vectors bind real optimized builds. No physical input/settings/service/deallocation claim.'}
    boundary(plan);write(P/'plan.json',plan)
    print(json.dumps({'head':HEAD,'plan_sha256':sha(P/'plan.json'),'cases':len(CASES),'native_executed':False,'native_execution_ready':False}))

def cancellation_handler(state):
    def interrupted(signum,frame): state[0]=True
    return interrupted

def run():
    need(not any((P/n).exists()for n in['result.json','started.json','stop-live']),'campaign already attempted or sealed')
    configure_binding()
    plan=read(P/'plan.json');review=read(P/'controller-review.json');record=read(P/'native-admission.json')
    deadline=admission(plan,review,record,datetime.datetime.now(datetime.timezone.utc))
    lease_module=load('preflight_live_lease',LEASE);signaled=[False];previous={}
    try:
        # Never raise asynchronously inside process retirement or evidence writes.
        # Existing executor polls the flag before Popen and throughout active work.
        for sig in[signal.SIGINT,signal.SIGTERM]:previous[sig]=signal.signal(sig,cancellation_handler(signaled))
        with lease_module.LiveLease()as lease:
            host=None
            try:
                host=NativeHost(plan,deadline,lease,signaled);host.check()
                write(P/'started.json',{'head':HEAD,'admission_sha256':sha(P/'native-admission.json'),'review_sha256':sha(P/'controller-review.json'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
                result=execute_cases(plan,host,P)
            except BaseException as error:
                if not(P/'result.json').exists():
                    result={'result':'FAILED_OR_CANCELED','native_executed':False,'completed':[],'cases':{},'release_qualified':False,'error':{'type':type(error).__name__,'message':str(error)}}
                    try:
                        if host is not None:host.finish()
                    except BaseException as final:result['final_boundary_error']={'type':type(final).__name__,'message':str(final)}
                    (P/'stop-live').touch();write(P/'result.json',result)
                raise
            print(json.dumps({'result':result['result'],'completed':result['completed'],'native_executed':result['native_executed'],'release_qualified':False}))
            need(result['result']=='PASS_SCOPED_NATIVE_FEEDBACK_PREFLIGHT','native preflight failed or canceled')

    finally:
        for sig,handler in previous.items():signal.signal(sig,handler)

if __name__=='__main__':
    need(sys.argv[1:]in[['prepare'],['run']],'fixed prepare/run phase')
    prepare()if sys.argv[1]=='prepare'else run()
