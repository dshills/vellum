"""Synthetic controls for the fresh default-path adapter; no native launch."""
from pathlib import Path
import importlib.util,tempfile,json,unittest
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('assessment',P/'assessment.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
import sys
sys.path.insert(0,str(a.X/'macos-presentation-display105'))
old=a.load('prior_synthetic_controls',a.X/'macos-presentation-display105/tests.py')
class AdapterTests(unittest.TestCase):
 def test_exact_default_flags_and_omitted_zero_config(self):
  for case in a.c.CASES:
   args=a.arguments(case,'/binary',Path('/journal'))
   self.assertFalse(any('experimental' in v for v in args))
   self.assertNotIn('DisplayBackpressureNS',a.expected(case))
   self.assertIn('-perf-warmup=128',args)
   self.assertEqual('-perf-60hz'in args,case['paced'])
   self.assertEqual(len([v for v in args if v.startswith('-perf-presentation=')]),1)
 def test_unchanged_strict_serial_validation_and_experiment_refusal(self):
  for case in a.c.CASES[:2]:
   j=old.journal(case);j['Config'].pop('DisplayBackpressureNS')
   with tempfile.TemporaryDirectory()as d:
    p=Path(d)/'capture.json';p.write_text(json.dumps(j));r=a.validate(case,p,'a'*64)
    self.assertEqual(r['result'],'VALID_SERIAL_NATIVE_FEEDBACK_JOURNAL');self.assertFalse(r['cadence_qualified'])
    j['Config']['DisplayBackpressureNS']=1000000000;p.write_text(json.dumps(j))
    with self.assertRaisesRegex(ValueError,'default-path'):a.validate(case,p,'a'*64)
 def test_missing_feedback_stays_invalid(self):
  case=a.c.CASES[0];j=old.journal(case);j['Config'].pop('DisplayBackpressureNS');j['BeforeClose']['Presentation']['Samples'][2]['State']='unavailable'
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'capture.json';p.write_text(json.dumps(j))
   with self.assertRaises(ValueError):a.validate(case,p,'a'*64)
if __name__=='__main__':unittest.main()
