from pathlib import Path
import json,hashlib,tarfile,re,math
T=Path('/private/tmp/vellum-macos-native-results-97aee13'); R=T/'docs/reports/macos-default-responsiveness'
idx=json.loads((R/'evidence-index.json').read_text());a=R/'evidence.tar.xz';assert hashlib.sha256(a.read_bytes()).hexdigest()==idx['archive']['sha256']
summary=json.loads((R/'summary.json').read_text());probes=0
with tarfile.open(a) as tf:
 assert set(tf.getnames())==set(idx['files'])
 for n,x in idx['files'].items():
  b=tf.extractfile(n).read();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 for name,count in [('serial-grid-cpu',120),('serial-tree-gpu',120),('paced-grid-gpu',600)]:
  base='round1/'+name+'/'
  r=json.load(tf.extractfile(base+'result.json'));assert r['native']['owned']['terminal'] and r['native']['owned']['group_absent'];assert r['geometry_before']==r['geometry_after']
  for phase in ['configuration_before','configuration_after']:
   for v in r.get(phase,{}).values():
    assert v['exit_code']==0 and v['owned']['group_absent'];probes+=1
  v=json.load(tf.extractfile(base+'validation.json'));j=json.load(tf.extractfile(base+'presentation.json'))
  measured=[x for x in v['latencies'] if x['role']=='measured'];assert len(measured)==count
  tags={x['tag'] for x in measured};assert len(tags)==count
  samples=[x for x in j['BeforeClose']['Presentation']['Samples'] if x['Armed'] and x['Tag'] in tags]
  frames=[x for x in j['BeforeClose']['Frames']['Samples'] if x['Tag'] in tags];assert len(samples)==len(frames)==count
  d=summary['cases'][name]
  for k in ['latency_ms','receipt_to_acquired_ms','acquired_to_presented_ms']:assert d[k]['count']==count
  elapsed=sorted((x['Presented']-x['Acquired'])*1000 for x in samples)
  assert elapsed[math.ceil(count*.95)-1]==d['acquired_to_presented_ms']['p95']
  assert d['latency_ms']==v['measured_input_latency_ms']
 v=json.load(tf.extractfile('round1/paced-grid-gpu/validation.json')); assert v['paced_metrics']['within_1_1_period']==599 and not v['paced_metrics']['input_latency_threshold_met']
 assert probes==20
for f in ['specs/macos-completion.md','specs/macos-delivery.md','specs/macos-release-assessment.md','docs/reports/macos-default-responsiveness/README.md']:
 p=T/f
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if 'macos-default-responsiveness' in target or f.startswith('docs/reports/macos-default-responsiveness') or target=='macos-release-assessment.md': assert (p.parent/target).exists(), (f,target)
print('PASS: archive members/hashes, measured populations120/120/600,3 native+20 probe retirements,geometry,strict paced failure,checkpoint links')
