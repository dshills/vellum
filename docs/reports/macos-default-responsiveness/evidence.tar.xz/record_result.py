from pathlib import Path
import json, hashlib, math, tarfile, io
P=Path(__file__).resolve().parent
T=Path('/private/tmp/vellum-macos-native-results-97aee13')
R=T/'docs/reports/macos-default-responsiveness'
R.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def stats(v):
 v=sorted(v)
 return {'count':len(v),**{k:v[max(0,math.ceil(len(v)*q)-1)] for k,q in [('p50',.5),('p95',.95),('p99',.99),('max',1)]}}
plan=json.loads((P/'plan.json').read_text()); result=json.loads((P/'result.json').read_text())
summary={'outcome':'VALID_DEFAULT_CAPTURE_LATENCY_GATE_FAILED','runtime_source':plan['sdk_source'],'main_at_assessment':plan['current_main_reference'],'experimental_backpressure':False,'release_qualified':False,'started':json.loads((P/'started.json').read_text()),'finished_utc':result['finished_utc'],'cases':{},'unexecuted':['paced-tree-cpu','rounds2-5'],'five_runs_qualified':False,'native_library':plan['native_library'],'binaries':{k:{'sha256':v['sha256']} for k,v in plan['binaries'].items()}}
for name in ['serial-grid-cpu','serial-tree-gpu','paced-grid-gpu']:
 root=P/'round1'/name
 j=json.loads((root/'presentation.json').read_text()); v=json.loads((root/'validation.json').read_text()); r=json.loads((root/'result.json').read_text());b=j['BeforeClose'];ins={x['Tag']:x['Received'] for x in b['Presentation']['Inputs']};tags={x['tag'] for x in v['latencies'] if x['role']=='measured'};frames=[x for x in b['Frames']['Samples'] if x['Tag'] in tags];s=[x for x in b['Presentation']['Samples'] if x['Armed'] and x['Tag'] in tags]
 d={'submetric_population':'strict validator measured-role tags only; setup/warmup excluded','configuration_after_captured':'configuration_after' in r,'journal_sha256':sha(root/'presentation.json'),'capture':v['result'],'latency_ms':v['measured_input_latency_ms'],'receipt_to_acquired_ms':stats([(x['Acquired']-ins[x['Tag']])*1000 for x in s]),'acquired_to_presented_ms':stats([(x['Presented']-x['Acquired'])*1000 for x in s]),'cpu_ms':{k:stats([x[k]/1e6 for x in frames]) for k in ['QueuedNS','TotalUIWorkNS','AcquireNS']},'before_state_counts':v['before_state_counts'],'after_state_counts':v['after_state_counts'],'geometry_unchanged':r['geometry_before']==r['geometry_after'],'native_retired':r['native']['owned']['terminal'] and r['native']['owned']['group_absent'],'native_exit_code':r['native']['exit_code']}
 if 'paced_metrics' in v:
  m=v['paced_metrics'];d['paced']={k:v for k,v in m.items() if not isinstance(v,(list,dict))};d['paced']['interval_ms']=stats(m['intervals_ms']);d['paced']['over_two_periods']=sum(x>1000/30 for x in m['intervals_ms'])
 summary['cases'][name]=d
(R/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={p.relative_to(P).as_posix():p for p in P.rglob('*') if p.is_file() and p.name not in ['native-grid','native-tree'] and not p.name.startswith('plan-before-') and not p.name.startswith('evidence')}
# Source helpers are retained once, without recursive historical evidence.
for name,p in [('controller.py',P.parent/'macos-presentation-display105/controller.py'),('owned_executor.py',P.parent/'macos-sdk-native-238b3b6/run.py'),('live_lease.py',P.parent/'macos-sdk-stage0079-abe67c6-cache-v2/shared/live_lease.py'),('check-presentation.py',Path(plan['sdk_root'])/'scripts/check-presentation.py')]:files['inputs/'+name]=p
index={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(files.items())}
archive=R/'evidence.tar.xz'
with tarfile.open(archive,'w:xz') as tf:
 for n,p in sorted(files.items()):
  data=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(data);i.mtime=0;i.mode=0o644;tf.addfile(i,io.BytesIO(data))
(R/'evidence-index.json').write_text(json.dumps({'files':index,'archive':{'bytes':archive.stat().st_size,'sha256':sha(archive)},'excluded':['executables','SDK payload','historical archives','superseded preparation plans']},indent=2)+'\n')
print(json.dumps({'files':len(index),'archive_bytes':archive.stat().st_size,'result':summary['outcome']}))
