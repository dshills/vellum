from pathlib import Path
import json,datetime,sys,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-cache-control';load=lambda p:json.loads(p.read_text())
s=importlib.util.spec_from_file_location('cache_result_summary',t/'tools/macos-calibration/cachecontrol/check.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
d=load(q/'result.json');assert d['outcome']=='VALID_PRIVATE_FRAMEWORK_CACHE_CONTROL';start=load(q/'started.json')['started_utc'];match=load(q/'match.json');rows=[]
for c in d['cases']:
 root=q/('pair'+str(c['pair'])+'-'+c['kind']);doc=v.base.load(root/'native/stdout')[0];metrics=v.validate(doc,match,c['kind']);assert metrics==c['validation']
 presentation=v.base.validate(doc,match)
 rows.append({'pair':c['pair'],'mode':c['kind'],'metrics':metrics,'presentation_diagnostic':presentation})
out={'outcome':d['outcome'],'started_utc':start,'finished_utc':d['finished_utc'],'elapsed_seconds':(datetime.datetime.fromisoformat(d['finished_utc'])-datetime.datetime.fromisoformat(start)).total_seconds(),'maximum_seconds':240,'total_warmup':768,'total_measured':720,'owned_native_and_probe_groups':54,'runs':rows,'gate_changed':False,'release_qualified':False,'shipping_policy_adopted':False,'interpretation':'Same private library/binary with detailed Go and native CPU observers on in both modes. Only exact transient upload staging cache mode differs, including extra write_buffer staging. Ordinary binary equivalence, observer neutrality, physical pixel correctness, resource allocation balance and release qualification are not established.'}
out['receipt_to_actual_presentation_p95_limit_ms']=33.3;out['release_gate_met']=False
for row in out['runs']:row['diagnostic_receipt_p95_within_limit']=row['presentation_diagnostic']['receipt_to_present_ms']['p95']<=33.3
for p in [q/'summary.json',r/'summary.json']:p.write_text(json.dumps(out,indent=2)+'\n')
for row in rows:
 m=row['metrics'];print(row['pair'],row['mode'],'CPUcopy',m['CPU_phase_ms']['copy_ns']['p95'],'imageAPI',m['source_phase_ms']['SetFromGoImageNS']['p95'],'receipt-present',row['presentation_diagnostic']['receipt_to_present_ms']['p95'],'actualpolicy',m['cache_policy'])
print('elapsed',out['elapsed_seconds'])
