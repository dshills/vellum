from pathlib import Path
import json,hashlib,importlib.util,sys,datetime,tarfile
from decimal import Decimal
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');r=t/'docs/reports/macos-cache-control';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=load(q/'bound-plan.json');assert all(sha(Path(p))==h for p,h in plan['pins'].items())
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
v=module('cache_control_validator',t/'tools/macos-calibration/cachecontrol/check.py');a=module('CPU_upload_integrity',q.parent/'macos-release-default-assessment/assessment.py');assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
result=load(q/'result.json');assert result['outcome']=='VALID_PRIVATE_FRAMEWORK_CACHE_CONTROL' and result['error'] is None and [(c['pair'],c['kind']) for c in result['cases']]==[(1,'writecombined'),(1,'default'),(2,'default'),(2,'writecombined'),(3,'writecombined'),(3,'default')];match=load(q/'match.json');count=0
for c in result['cases']:
 root=q/('pair'+str(c['pair'])+'-'+c['kind']);lines=v.base.load(root/'native/stdout');assert len(lines)==1;actual=v.validate(lines[0],match,c['kind']);assert actual==c['validation']==load(root/'validation.json');assert c['geometry_before']==c['geometry_after'];assert all(c['configuration_before'][k]['logs']['stdout']['sha256']==c['configuration_after'][k]['logs']['stdout']['sha256'] for k in c['configuration_before'])
 work=[(c['native'],root/'native')]
 for phase,folder in [('configuration_before','before'),('configuration_after','after')]:work.extend((cmd,root/folder/k) for k,cmd in c[phase].items())
 for cmd,folder in work:
  assert cmd['exit_code']==0 and cmd['error'] is None and cmd['pins_stable'] and cmd['logs_complete'] and cmd['owned']['terminal'] and cmd['owned']['group_absent'] and cmd['logs']['stderr']['bytes']==0
  for stream,d in cmd['logs'].items():assert sha(folder/stream)==d['sha256'] and (folder/stream).stat().st_size==d['bytes']
  count+=1
assert count==54;s=load(q/'summary.json');assert s['elapsed_seconds']==(datetime.datetime.fromisoformat(result['finished_utc'])-datetime.datetime.fromisoformat(load(q/'started.json')['started_utc'])).total_seconds()<240
for row,c in zip(s['runs'],result['cases']):assert row['pair']==c['pair'] and row['mode']==c['kind'] and row['metrics']==c['validation'] and row['presentation_diagnostic']==v.base.validate(v.base.load(q/('pair'+str(c['pair'])+'-'+c['kind'])/'native/stdout')[0],match)
assert s==load(r/'summary.json')
assert s['receipt_to_actual_presentation_p95_limit_ms']==33.3 and s['release_gate_met'] is False
assert all(row['diagnostic_receipt_p95_within_limit'] is (row['presentation_diagnostic']['receipt_to_present_ms']['p95']<=33.3) for row in s['runs'])
assert s['total_warmup']==768 and s['total_measured']==720
for name in ['preparation','result']:
 index=r/(name+'-evidence-index.json');archive=r/(name+'-evidence.tar.xz')
 if not index.exists():continue
 d=load(index);assert sha(archive)==d['archive_sha256']
 with tarfile.open(archive) as tf:
  assert set(tf.getnames())==set(d['files'])
  for n,e in d['files'].items():b=tf.extractfile(n).read();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
print('PASS six ordered cases;768warmup720measured;actual observed cache policy and complete native/source/presentation joins;54 owned groups retired;source/native/binary/overlay/config/geometry/log pins;SDK8321 unchanged;no shipping or gate adoption')
