from pathlib import Path
import importlib.util,sys,hashlib,json
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');code=t/'tools/macos-calibration/cachecontrol';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={str(p):sha(p) for p in [code/'control.rs',code/'check.py',code/'check_test.py']}
sys.path.insert(0,str(q.parent/'macos-grid-capture-repair/preflight-v2'));s=importlib.util.spec_from_file_location('cache_tests_owned',q.parent/'macos-sdk-native-238b3b6/run.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
commands=[('rust-test-build',['/Users/dshills/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustc','--edition=2021','--test',str(code/'control.rs'),'-o',str(q/'control-tests')]),('python-tests',['/usr/bin/python3','-B','-m','unittest','discover','-s',str(code),'-p','*_test.py'])]+[(name,[str(q/'control-tests'),'--exact','tests::'+name,'--test-threads=1']) for name in ['writecombined','default_mode','refuse_late_configuration']]
for name,argv in commands:
 r=g.execute(argv,t,q/name,lambda:False,lambda:all(sha(Path(p))==h for p,h in pins.items()),timeout=60,limit=2<<20)
 (q/(name+'-receipt.json')).write_text(json.dumps({'argv':argv,'pins':pins,'run':r},indent=2)+'\n');print(json.dumps({name:{k:r[k] for k in ['exit_code','error','seconds']}}),flush=True)
 assert r['exit_code']==0 and r['error'] is None and r['owned']['terminal'] and r['owned']['group_absent']
