from pathlib import Path
import json,hashlib,os,sys,importlib.util
sys.dont_write_bytecode=True
q=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());d=load(q/'build-identity.json')
assert sha(q/'framework')==d['binary_sha256'] and os.access(q/'framework',os.X_OK) and sha(Path('/private/tmp/vellum-cache-control/libs-darwin/arm64/libwgpu_native.a'))==d['archive_sha256']
for group in ['private_source_pins','fixture_source_pins','overlay_file_pins']:assert all(sha(Path(p))==h for p,h in d[group].items())
assert sha(q/'source-audit.json')==d['source_audit_sha256']
for n in ['rust-test-build','python-tests','writecombined','default_mode','refuse_late_configuration','build','go-build']:
 r=load(q/(n+'-receipt.json'))['run'];assert r['exit_code']==0 and r['error'] is None and r['pins_stable'] and r['logs_complete'] and r['owned']['terminal'] and r['owned']['group_absent']
 for stream,v in r['logs'].items():assert sha(q/n/stream)==v['sha256'] and (q/n/stream).stat().st_size==v['bytes']
s=importlib.util.spec_from_file_location('private_cache_SDK_integrity',q.parent/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a);assert a.sdk_vector()==load(q.parent/'macos-release-default-assessment/plan.json')['sdk']
print('PASS Rust3/Python3 refusal tests; native+Go builds; exact HAL archive84 members/lock change; source/native/binary/3overlay/view pins; SDK8321 unchanged; native experiment not executed')
