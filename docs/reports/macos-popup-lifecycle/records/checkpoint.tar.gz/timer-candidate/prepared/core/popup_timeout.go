// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT

package core

import "time"

// A fresh ticket identifies each arming, including reuse of the same Stage and
// Scene. All ticket fields and Stage links are accessed under the render context.
// A stopped callback may already be waiting for that lock; retirement never joins it.
type popupTimeout struct {
	stage  *Stage
	scene  *Scene
	owner  *renderContext
	window *renderWindow
	timer  ManualTimer
}

// stopPopupTimeout runs under the render context, including from Stage.delete
// while the popup stack is locked. Stop never waits for a running callback.
func (st *Stage) stopPopupTimeout() {
	t := st.popupTimeout
	st.popupTimeout = nil
	if t != nil && t.timer != nil {
		t.timer.Stop()
	}
}

func (st *Stage) startPopupTimeout() {
	st.stopPopupTimeout()
	if st.Timeout <= 0 || st.Scene == nil || st.renderContext == nil || st.Mains == nil {
		return
	}
	t := &popupTimeout{stage: st, scene: st.Scene, owner: st.renderContext, window: st.Mains.renderWindow}
	st.popupTimeout = t
	if t.owner.manual != nil {
		// The manual seam dispatches under the owner; locking again would deadlock.
		t.timer = t.scene.afterEvent(st.Timeout, t.expireOwned)
	} else {
		t.timer = time.AfterFunc(st.Timeout, t.run)
	}
	if t.timer == nil {
		st.popupTimeout = nil
	}
}

func (t *popupTimeout) run() {
	// Capture the owner at arming. Reading a live Stage to find its lock here
	// would race deletion, and it may already have been detached entirely.
	t.owner.Lock()
	defer t.owner.Unlock()
	t.expireOwned()
}

func (t *popupTimeout) expireOwned() {
	st := t.stage
	if st.popupTimeout != t {
		return
	}
	st.popupTimeout = nil
	if st.Main == nil || st.Scene != t.scene || t.scene.This == nil || st.popups == nil {
		return
	}
	if st.popups.deleteStage(st) && t.window != nil && t.window.SystemWindow != nil {
		// An on-demand native window has no periodic paint to remove the popup.
		t.window.requestPaintAfter(0)
	}
}

// deleteStages is the terminal event-loop teardown, outside normal event dispatch.
// It must acquire the owner before stack/widget destruction, just like a callback.
func (w *renderWindow) deleteStages() {
	rc := w.renderContext()
	rc.Lock()
	defer rc.Unlock()
	w.mains.deleteAll()
}
