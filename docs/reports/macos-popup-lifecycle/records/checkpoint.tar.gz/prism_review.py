"""One bounded Anthropic review of the implemented native workspace checkpoint."""
from pathlib import Path
import hashlib,json,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13')
sys.path.insert(0,str(T/'scripts'))
from child_process import run_child
review=json.loads((W/'internal-pre-prism-review.json').read_text())
assert review['approved']
assert not(W/'prism.json').exists()and not(W/'prism.stdout').exists()
diff=run_child(['git','diff','--cached','--binary'],cwd=T,timeout=30,capture_output=True,check=True).stdout
assert 0<len(diff)<50000
assert hashlib.sha256(diff).hexdigest()==review['staged_diff_sha256'],'reviewed diff changed'
(W/'prism-staged.diff').write_bytes(diff)
args=['/Users/dshills/Development/Go/bin/prism','review','staged','--provider','anthropic','--model','claude-sonnet-5-5','--reasoning-effort','low','--max-findings','4','--baseline','none','--min-severity','medium','--fail-on','medium','--no-auto-exclude','--no-function-context','--chunk-bytes','40000','--max-diff-bytes','50000','--rules',str(W/'prism-rules.json'),'--format','json','--out',str(W/'prism.json')]
start=time.monotonic()
with(W/'prism.stdout').open('xb')as out,(W/'prism.stderr').open('xb')as err:r=run_child(args,cwd=T,timeout=300,stdout=out,stderr=err,log_limit_bytes=2<<20)
d={'argv':args,'staged_diff_sha256':hashlib.sha256(diff).hexdigest(),'staged_diff_bytes':len(diff),'exit_code':r.returncode,'seconds':time.monotonic()-start}
(W/'prism-command.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
