// Copyright (c) 2026, Davin Hills. SPDX-License-Identifier: MIT
//go:build offscreen

package core

import (
	"context"
	"testing"
	"time"

	"cogentcore.org/core/system"
)

type popupPaintRecorder struct {
	system.Window
	delays []time.Duration // accessed only under the owning render context
}

func (p *popupPaintRecorder) RequestPaint()                     { p.RequestPaintAfter(0) }
func (p *popupPaintRecorder) RequestPaintAfter(d time.Duration) { p.delays = append(p.delays, d) }
func (p *popupPaintRecorder) IsOnDemand() bool                  { return true }

func timeoutPopup(t *testing.T) (*ManualWindow, *Stage, *fixtureClock) {
	t.Helper()
	m, body, clock := manualFixture(t, nil)
	drainManual(t, m)
	sc := NewScene("timeout-popup")
	NewButton(sc).SetText("popup")
	st := NewPopupStage(MenuStage, sc, body).SetTimeout(time.Second).Run()
	drainManual(t, m)
	return m, st, clock
}

func waitPopupCallback(t *testing.T, done <-chan struct{}) {
	t.Helper()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("popup callback did not join")
	}
}

// Schedule the exact native callback with an entry/exit barrier, rather than
// infer lock acquisition from sleeps. No OS window or physical input is used.
func scheduledPopupCallback(t *testing.T, ticket *popupTimeout) <-chan struct{} {
	t.Helper()
	entered, done := make(chan struct{}), make(chan struct{})
	ticket.timer.Stop()
	ticket.timer = time.AfterFunc(0, func() {
		close(entered)
		ticket.run()
		close(done)
	})
	waitPopupCallback(t, entered)
	return done
}

func TestPopupTimeoutNativeOwnerAndRepaint(t *testing.T) {
	m, st, _ := timeoutPopup(t)
	rc := m.window.renderContext()
	rc.Lock()
	// Exercise native arming with the real time.AfterFunc branch, while retaining
	// the software scene/window fixture for deterministic, race-enabled checks.
	manual := rc.manual
	rc.manual = nil
	st.Timeout = time.Hour
	st.startPopupTimeout()
	rc.manual = manual
	ticket := st.popupTimeout
	if _, ok := ticket.timer.(*time.Timer); !ok {
		rc.Unlock()
		t.Fatal("native timer not armed")
	}
	painter := &popupPaintRecorder{}
	ticket.window = &renderWindow{SystemWindow: painter}
	done := scheduledPopupCallback(t, ticket)
	select {
	case <-done:
		rc.Unlock()
		t.Fatal("native callback escaped owner lock")
	default:
	}
	if st.Scene == nil || st.popupTimeout != ticket {
		rc.Unlock()
		t.Fatal("popup changed while owner held")
	}
	rc.Unlock()
	waitPopupCallback(t, done)
	ticket.run() // duplicate completion must not delete another popup or repaint
	rc.Lock()
	defer rc.Unlock()
	if st.Scene != nil || st.popupTimeout != nil || len(painter.delays) != 1 || painter.delays[0] != 0 {
		t.Fatalf("expiry scene=%p ticket=%p paints=%v", st.Scene, st.popupTimeout, painter.delays)
	}
}

func TestPopupTimeoutNativeCallbackAfterRetirement(t *testing.T) {
	for _, closeWindow := range []bool{false, true} {
		t.Run(map[bool]string{false: "popup", true: "window"}[closeWindow], func(t *testing.T) {
			m, st, _ := timeoutPopup(t)
			rc := m.window.renderContext()
			rc.Lock()
			ticket := st.popupTimeout
			painter := &popupPaintRecorder{}
			ticket.window = &renderWindow{SystemWindow: painter}
			done := scheduledPopupCallback(t, ticket)
			if closeWindow {
				// Same destructive path used for native window retirement, under rc.
				st.Main.delete()
			} else if !st.ClosePopup() {
				rc.Unlock()
				t.Fatal("close refused")
			}
			if st.popupTimeout != nil || st.Scene != nil {
				rc.Unlock()
				t.Fatal("retirement retained popup authority")
			}
			rc.Unlock()
			waitPopupCallback(t, done)
			rc.Lock()
			paints := len(painter.delays)
			rc.Unlock()
			if paints != 0 {
				t.Fatal("retired callback requested paint")
			}
		})
	}
}

func TestPopupTimeoutRearmAndDisableRejectOldCallbacks(t *testing.T) {
	m, st, clock := timeoutPopup(t)
	rc := m.window.renderContext()
	rc.Lock()
	old := st.popupTimeout
	st.startPopupTimeout()
	fresh := st.popupTimeout
	if old == fresh || fresh == nil {
		rc.Unlock()
		t.Fatal("rearm reused ticket")
	}
	old.expireOwned()
	if st.Scene == nil || st.popupTimeout != fresh {
		rc.Unlock()
		t.Fatal("old callback expired rearmed popup")
	}
	st.Timeout = 0
	st.startPopupTimeout()
	fresh.expireOwned()
	if st.Scene == nil || st.popupTimeout != nil {
		rc.Unlock()
		t.Fatal("disabled timeout retained authority")
	}
	rc.Unlock()
	clock.Advance(2 * time.Second)
	drainManual(t, m)
	if st.Scene == nil {
		t.Fatal("stopped manual timer expired popup")
	}
	snap, err := m.Snapshot(context.Background())
	if err != nil || snap.Timers != 0 {
		t.Fatalf("timer retirement %+v %v", snap, err)
	}
}

func TestPopupTimeoutManualDispatchUnderOwner(t *testing.T) {
	m, st, clock := timeoutPopup(t)
	clock.Advance(time.Second)
	if st.Scene == nil {
		t.Fatal("clock callback bypassed native FIFO")
	}
	drainManual(t, m) // A double lock in the manual callback would deadlock here.
	if st.Scene != nil || st.popupTimeout != nil {
		t.Fatal("manual event did not retire popup")
	}
	snap, err := m.Snapshot(context.Background())
	if err != nil || snap.Timers != 0 || snap.Failure != nil {
		t.Fatalf("manual cleanup %+v %v", snap, err)
	}
}
