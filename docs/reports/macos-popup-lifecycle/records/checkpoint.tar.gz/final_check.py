from pathlib import Path
import importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;name,kind=sys.argv[1:];I=W/'timer-candidate'
s=importlib.util.spec_from_file_location('catalogue_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
sdk=Path(json.loads((W/'sdk.json').read_text())['sdk'])
pins={str(p):h.sha(p)for p in [*I.rglob('*'),Path(__file__),Path(h.__file__),h.GUARD,h.GO]if p.is_file()}
cwd=sdk/'drivers/cogent/build/upstream'
base=['-p=1','-overlay='+str(I/'overlay.json'),'-tags=offscreen']
if kind=='focused':args=['test','-race','-count=1',*base,'-timeout=2m','-run','^(TestPopupTimeout|TestVellumManualSnackbarTimeoutAndRetirement)','./core']
elif kind=='core':args=['test','-v','-race','-count=1',*base,'-timeout=3m','-run','^(TestManual|TestVellumManual|TestOriginCustom|TestPopupTimeout|TestFrameTrace|TestPointerCapture)','./core']
elif kind=='driver':cwd=sdk/'drivers/cogent';args=['test','-race','-count=1',*base,'-timeout=8m','.']
elif kind=='build':cwd=sdk/'drivers/cogent';args=['build','-p=1','-overlay='+str(I/'overlay.json'),'-o',str(W/'gallery-timer'),'./cmd/gallery']
elif kind=='vet':args=['vet','-composites=false','-unreachable=false',*base,'./core']
else:raise ValueError(kind)
env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$'}
profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(sdk))+'))'
av=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),*args]
r=h.g.execute(av,cwd,W/name,lambda:(W/'stop-checks').exists(),lambda:all(h.sha(k)==z for k,z in pins.items()),timeout=420,limit=8<<20)
r['source_pins']=pins;r['native_ui_executed']=False
(W/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r.get(k)for k in ['exit_code','error','seconds','logs_complete','pins_stable','owned']}))
sys.exit(0 if r['exit_code']==0 and not r['error']and r['logs_complete']and r['pins_stable']and r['owned']['group_absent']and not r['owned']['errors']else 1)
