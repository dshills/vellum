from pathlib import Path
import hashlib,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;T=Path('/private/tmp/vellum-macos-native-results-97aee13');C=Path('/Users/dshills/Development/projects/Vellum');sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
scope=json.loads((W/'review-scope.json').read_text());prism=json.loads((W/'prism.json').read_text());call=json.loads((W/'prism-command.json').read_text());disposition=json.loads((W/'internal-prism-disposition.json').read_text())

for n in ['prism.json','prism-command.json']:
 assert disposition['inputs'][str(W/n)]==hashlib.sha256((W/n).read_bytes()).hexdigest()
expected_ids={'2090be065fdf75f4','7f96bf93b96a24c3'}
assert set(disposition['assessed_discarded_ids'])==expected_ids
assert {d['finding']['id']for d in json.loads((W/'prism.json').read_text())['discarded']}==expected_ids

assert disposition['approved']and call['exit_code']==0 and prism['coverage']['complete']and prism['coverage']['llmCalls']==1 and not prism['findings']
assert not prism['coverage']['excluded']and not prism['coverage']['truncatedBytes']and not prism['suppressed']
assert sha(git(T,'diff','--cached','--binary','--',*scope['paths']))==scope['staged_diff_sha256']==call['staged_diff_sha256']
for n in ['owned-core-final','driver-final','qualified-vet-final','gallery-build-final','adopted-build','prepare-final','adopted-prepare','prepare-tests-v2']:
 r=json.loads((W/(n+'.json')).read_text());assert r['exit_code']==0 and not r['error']and r['owned']['group_absent']and not r['owned']['errors']and r['logs_complete']and r['pins_stable']
 for p,z in r['source_pins'].items():assert Path(p).is_file()and sha(Path(p).read_bytes())==z,p
R=T/'docs/reports/macos-popup-lifecycle/records';manifest=json.loads((R/'manifest.json').read_text());MAX_MEMBERS=256;MAX_MEMBER=10<<20;MAX_EXPANDED=32<<20;MAX_COMPRESSED=8<<20
assert len(manifest)<=MAX_MEMBERS and(R/'checkpoint.tar.gz').stat().st_size<=MAX_COMPRESSED
seen=set();expanded=0
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as archive:
 for m in archive:
  assert m.isfile()and m.name in manifest and m.name not in seen and not m.name.startswith('/')and'..'not in Path(m.name).parts
  seen.add(m.name);expanded+=m.size;assert len(seen)<=MAX_MEMBERS and m.size<=MAX_MEMBER and expanded<=MAX_EXPANDED
  b=archive.extractfile(m).read();assert len(b)==manifest[m.name]['bytes']and sha(b)==manifest[m.name]['sha256']
assert seen==set(manifest)
extra=['docs/reports/macos-popup-lifecycle/records/'+n for n in ['checkpoint.tar.gz','archive.json','manifest.json']];git(T,'add','--',*extra);git(T,'diff','--cached','--check');assert not git(T,'diff','--name-only')
assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths']+extra)
assert not git(C,'status','--porcelain')and git(C,'rev-parse','HEAD').decode().strip()=='acea588d185007e862d8575dfc6e8cc58307eb7f'
r={'approved':True,'staged_diff_sha256':sha(git(T,'diff','--cached','--binary')),'reviewed_source_diff_sha256':scope['staged_diff_sha256'],'evidence_members':len(seen),'source_unchanged_after_provider':True,'native_ui_executed':False,'sdk_refreshed':False,'goal_complete':False};(W/'final-ready.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
