from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');D=W/'timer-install'
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
base='acea588d185007e862d8575dfc6e8cc58307eb7f'
assert all(git(r,'rev-parse','HEAD').decode().strip()==base and not git(r,'status','--porcelain')for r in[C,T])
r=json.loads((W/'internal-timer-review-v2.json').read_text());assert r['approved']
for p in D.rglob('*'):
 if not p.is_file():continue
 n=p.relative_to(D);q=T/n
 if q.exists():assert q.read_bytes()==(C/n).read_bytes(),str(n)
 else:assert not(C/n).exists(),str(n)
 q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
print(git(T,'diff','--stat').decode())
