from pathlib import Path
import gzip,hashlib,io,json,tarfile,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13')
assert(W/'prism-command.json').exists()and(W/'internal-prism-disposition.json').exists()
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
def git(root,*args):return run_child(['git',*args],cwd=root,timeout=30,capture_output=True,check=True).stdout
scope=json.loads((W/'review-scope.json').read_text());call=json.loads((W/'prism-command.json').read_text());disposition=json.loads((W/'internal-prism-disposition.json').read_text())
assert disposition['approved']and call['exit_code']==0
for n in ['prism.json','prism-command.json']:
 assert disposition['inputs'][str(W/n)]==hashlib.sha256((W/n).read_bytes()).hexdigest()
expected_ids={'2090be065fdf75f4','7f96bf93b96a24c3'}
assert set(disposition['assessed_discarded_ids'])==expected_ids
assert {d['finding']['id']for d in json.loads((W/'prism.json').read_text())['discarded']}==expected_ids

assert hashlib.sha256(git(T,'diff','--cached','--binary')).hexdigest()==scope['staged_diff_sha256']==call['staged_diff_sha256']
assert set(git(T,'diff','--cached','--name-only').decode().splitlines())==set(scope['paths'])and len(scope['paths'])==11
assert not git(T,'diff','--name-only')and not git(C,'status','--porcelain')and git(C,'rev-parse','HEAD').decode().strip()=='acea588d185007e862d8575dfc6e8cc58307eb7f'
MAX_MEMBERS=256;MAX_MEMBER=10<<20;MAX_EXPANDED=32<<20;MAX_COMPRESSED=8<<20
files={}
def add(p,name=None):
 p=Path(p)
 assert p.is_file()and not p.is_symlink()
 name=name or p.relative_to(W).as_posix()
 assert name not in files and not name.startswith('/')and'..'not in Path(name).parts
 files[name]=p
for n in ['scope.json','timer-scope.json','sdk.json','sdk-after-tests.json','sdk-generated-delta.json','sdk-restored.json','sdk-final.json','stage82-initial-outputs.json','stage82-patch.json','prepared-overlay-parity.json','timer-results.json','review-scope.json','pre-prism.diff','internal-timer-review.json','internal-timer-review-v2.json','internal-pre-prism-review.json','prism-command.json','prism-rules.json','prism-staged.diff','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json']:
 add(W/n)
for n in ['focused-v1','core-v1','vet-v1','focused-v2','owned-core-v2','qualified-vet-v2','owned-core-final','qualified-vet-final','driver-final','gallery-build-final','adopted-build','prepare-v1','prepare-final','adopted-prepare','prepare-tests-final','prepare-tests-v2']:
 add(W/(n+'.json'))
 for p in(W/n).iterdir():
  if p.is_file():add(p)
for n in ['check.py','timer_check.py','final_check.py','prepare_check.py','prepare_check_final.py','prepare_tests.py','prepare_tests_v2.py','adopt_timer.py','prepare_adopt.py','adopted_build.py','prism_review.py','archive.py','ready.py']:
 add(W/n)
for p in(W/'versions').iterdir():
 if p.is_file():add(p)
for variant in ['candidate','timer-candidate']:
 for n in ['stage.go','popupstage.go','renderwindow.go','popup_timeout.go','popup_timeout_offscreen_test.go']:
  add(W/variant/'prepared/core'/n)
 add(W/variant/'overlay.json')
for n in ['stage.go','popupstage.go','renderwindow.go']:
 add(C/'drivers/cogent/build/upstream/core'/n,'original-stage81/'+n)
assert len(files)<=MAX_MEMBERS
assert all(p.stat().st_size<=MAX_MEMBER for p in files.values())and sum(p.stat().st_size for p in files.values())<=MAX_EXPANDED
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for n,p in sorted(files.items())}
R=T/'docs/reports/macos-popup-lifecycle/records';R.mkdir(parents=True,exist_ok=True)
assert not(R/'checkpoint.tar.gz').exists()
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as archive:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=MAX_COMPRESSED
seen=set();expanded=0
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as check:
 for m in check:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size<=MAX_MEMBER
  seen.add(m.name);expanded+=m.size;assert len(seen)<=MAX_MEMBERS and expanded<=MAX_EXPANDED
  data=check.extractfile(m).read();assert len(data)==manifest[m.name]['bytes']and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
r={'members':len(files),'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':hashlib.sha256((R/'checkpoint.tar.gz').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((R/'manifest.json').read_bytes()).hexdigest(),'generated_pngs':'300 files remain in private quarantine; only their names/hashes are archived, not acceptance goldens.','binaries_included':False}
(R/'archive.json').write_text(json.dumps(r,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
