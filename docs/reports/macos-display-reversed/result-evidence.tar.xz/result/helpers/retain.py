from pathlib import Path
import hashlib,tarfile,io,json,sys
x=Path(__file__).resolve().parent;q=x/'prepared';mode=sys.argv[1]
if mode=='preparation':
 paths=[p for p in q.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts and '__pycache__' not in p.relative_to(q).parts and p.name not in ['framework','framework-unused-v1','native-fixture','counter-fixture'] and not p.name.endswith('.tar.xz') and not p.name.endswith('evidence-index.json')]
 paths += [p for p in x.glob('*.py') if not p.name.startswith(('install','publish'))]
else:
 names=['result.json','bound-plan.json','started.json','preparation-commit.json','result-summary.json','result-internal-review.json','result-review-completion.json','verification.stdout']
 paths=[q/n for n in names if (q/n).exists()]+[p for folder in ['off','on','result-review','final-result-review','result-reviewed-docs'] for p in (q/folder).rglob('*') if p.is_file() and 'tmp' not in p.relative_to(q).parts]
 paths+=[p for p in x.glob('*result*.py')]+[x/'retain.py']
archive=q/(mode+'-evidence.tar.xz');files={}
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in sorted(set(paths)):
  b=p.read_bytes();name=mode+'/'+('artifacts/'+p.relative_to(q).as_posix() if p.is_relative_to(q) else 'helpers/'+p.name);m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o644;m.mtime=m.uid=m.gid=0;m.uname=m.gname='';tar.addfile(m,io.BytesIO(b));files[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with tarfile.open(archive,'r:xz') as tar:
 assert sorted(tar.getnames())==sorted(files)
 for m in tar:
  b=tar.extractfile(m).read();assert len(b)==files[m.name]['bytes'] and hashlib.sha256(b).hexdigest()==files[m.name]['sha256']
index={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'scope':'Local diagnostic checkpoint only. No executable/native archive/full SDK/cache/credentials. All startup, failures, logs, review dispositions and compiled source proofs retained.'};(q/(mode+'-evidence-index.json')).write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'members':len(files),'bytes':archive.stat().st_size,'sha256':index['archive_sha256']}))
