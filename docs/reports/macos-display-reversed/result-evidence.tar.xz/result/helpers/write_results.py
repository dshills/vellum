from pathlib import Path
import json,shutil
x=Path(__file__).resolve().parent;q=x/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');d=r/'docs/reports/macos-display-reversed';s=json.loads((q/'result-summary.json').read_text());assert s['outcome']=='VALID_REVERSED_DISPLAY_CLOCK_CONTROL';by={c['mode']:c for c in s['cases']};on,off=by['on'],by['off'];old=s['prior_pair'];fmt=lambda x:f"{x:.3f}"
rows=[]
for pair,order,values in [('Previous','off → on',old['run_p95_ms']),('Reversed','on → off',{m:c['receipt_to_shown_ms']['p95'] for m,c in by.items()})]:
 rows.append(f"| {pair} | {order} | {values['off']:.3f} ms | {values['on']:.3f} ms | {values['on']-values['off']:.3f} ms |")
text=f"""# Reversed-order display-clock observer result

The fresh observer-on then observer-off control passes complete accounting. It
uses the exact executable and native archive from the [previous off/on pair](../macos-display-scheduling/README.md).
No production scheduling change or performance qualification follows.

| Pair | Execution order | Off p95 | On p95 | On minus off p95 |
| --- | --- | ---: | ---: | ---: |
{chr(10).join(rows)}

These are separate differences of run quantiles, calculated by observer mode.
They are not percentiles of paired input differences or calibrated observer cost.
The earlier approximately one-refresh-period advantage did not reproduce: this
reversed pair differs by only 0.040 ms at p95. Both reversed cases exceed the
unchanged 33.3 ms gate. This does not establish equivalence or observer neutrality.
Neither samples nor process clocks are pooled across runs. One reversed pair
can challenge a simple order explanation; it cannot establish causation,
observer neutrality or ordinary-build performance. Earlier captures show multiple
latency bands. Both the prior evidence and this complete attempt remain retained.

| Reversed case | p50 | p95 | p99 | Maximum | Above 33.3 ms |
| --- | ---: | ---: | ---: | ---: | ---: |
"""
for c in s['cases']:
 t=c['receipt_to_shown_ms'];text+=f"| {c['mode'].title()} | {t['p50']:.3f} ms | {t['p95']:.3f} ms | {t['p99']:.3f} ms | {t['max']:.3f} ms | {c['over33_3ms']}/120 |\n"
text+=f"""
The on case retains all {on['callback_count']:,} callbacks, including startup and
the common 50 ms held tail outside the cohort. Timestamp interval p95 is
{on['callback_timestamp_intervals_ms']['p95']:.6f} ms; observation minus reported
timestamp p95 is {on['callback_observation_minus_timestamp_ms']['p95']:.3f} ms.
Actual shown feedback is within {on['nearest_reported_timestamp_absolute_error_ms']['max']*1000:.3f}
microseconds of the nearest reported timestamp over the 120 measured inputs.
Counts of reported timestamps strictly between final-present GPU end and shown
are {json.dumps(on['reported_timestamp_between_counts'],sort_keys=True)}.
These retrospective clock relations are not optical scanout, guaranteed latch
opportunities, missed-vsync counts or proof of prior callback delivery. Late
observations and gaps are retained. Off records zero callbacks.

Each case has its own actual p95-ranked input: on revision
{on['p95_rank_ticket']['accepted_revision']}, scope {on['p95_rank_ticket']['scope']},
tag {on['p95_rank_ticket']['opaque_tag']}, generation {on['p95_rank_ticket']['generation']},
drawable {on['p95_rank_ticket']['drawable_id']}, with final-present GPU end to shown
{on['p95_rank_ticket']['present_gpu_end_to_shown_ms']:.3f} ms; off revision
{off['p95_rank_ticket']['accepted_revision']}, scope {off['p95_rank_ticket']['scope']},
tag {off['p95_rank_ticket']['opaque_tag']}, generation {off['p95_rank_ticket']['generation']},
drawable {off['p95_rank_ticket']['drawable_id']}, with that interval
{off['p95_rank_ticket']['present_gpu_end_to_shown_ms']:.3f} ms. These individual-input
intervals do not decompose the difference of run p95 values and do not isolate
compositor, driver or WebGPU cost.

Execution takes {s['elapsed_seconds']:.3f} seconds within the 100-second bound.
Native on/off cases take {on['native_seconds']:.3f}/{off['native_seconds']:.3f} seconds,
each below 40 seconds. All {s['owned_groups_retired']} owned groups retire. Native
stderr is empty. The unchanged strict classifier independently verifies both
journals: each has 128 warmup plus 120 measured inputs, 248 full joins, 50 startup
commands and ten startup presents. Configuration, persistent geometry, source,
binary, native archive, modules and all 8,321 SDK files verify unchanged.
Preparation checkpoint is `{s['prepared_commit'][:7]}`. Five focused orchestration
methods/seven failure subcases and actual inherited Host/executor guard tests
pass; native ownership, pixel and classifier evidence is reused by exact identity.
Prism using Anthropic Claude Sonnet 5.5 reviewed preparation with source-backed
dispositions for two inherited-guard concerns. Results receive a separate review.

The original Cogent/WebGPU/Metal design, features, SDK/app, allocation/cache,
FIFO/vsync, two drawables, nontransactional presentation and pacing defaults stay
unchanged. The gate remains 33.3 ms receipt-to-actual-shown p95, with separate
cadence/resize/workflow qualification still required. No permanent display link
is adopted and M3–M7 remain open. The next bounded step is to inspect the existing journals for
receipt/render/submission phase relative to actual callback delivery and reported
clocks before proposing another native control. This is a sparse instrumented fixture; it does
not establish sustained 60 Hz responsiveness, physical input, displayed pixels,
resize acceptance or whole-GPU allocation balance. The approved scope is consumed,
sealed and not retried. The desktop is free; no native job remains active.

See the [protocol](../../../tools/macos-calibration/displayclock/REVERSED.md),
[preparation checks](preparation-checks.json), [guard audit](host-guard-audit.json),
[result summary](result-summary.json) and indexed preparation/result evidence.
"""
(d/'README.md').write_text(text);shutil.copyfile(q/'result-summary.json',d/'result-summary.json');shutil.copyfile(x/'verify_results.py',d/'execution-sources/verify_results.py.txt')
p=r/'specs/macos-release-assessment.md';p.write_text(p.read_text()+f"""
The [reversed-order observer result](../docs/reports/macos-display-reversed/README.md)
passes the fresh on/off pair in {s['elapsed_seconds']:.3f} seconds with
{s['owned_groups_retired']} owned groups retired and 248 joined inputs per case.
Receipt-to-shown p95 is {on['receipt_to_shown_ms']['p95']:.3f} ms on and
{off['receipt_to_shown_ms']['p95']:.3f} ms off; on-minus-off run p95 is
{s['difference_of_run_p95_on_minus_off_ms']:.3f} ms. The previous off/on pair remains
separate ({old['run_p95_ms']['on']:.3f} ms on / {old['run_p95_ms']['off']:.3f} ms off).
No pooling, causal claim, observer overhead calibration or ordinary qualification.
Complete callbacks/startup/held tails and source/native/SDK identity are retained.
No permanent link or production/default/feature/SDK/app/gate change. M3–M7 open;
approved scope consumed, desktop free, no native job active.
""")
(q/'result-internal-review.json').write_text(json.dumps({'result':'PASS','checks':['Independently classified both raw journals with unchanged complete strict validator','All logs/source pins/SDK8321/config/geometry unchanged;18groups retired','Correct mode-keyed on-minus-off despite reversed order','Prior pair pinned and reported separately, no pooling or cross-process timestamp joining','Actual rank tickets distinct; no phase quantile sum or causal/observer-overhead claim','Reported timestamps not scanout/latch/missedvsync; all callback records retained','No feature/gate/default/SDK/app changes; scope sealed'],'unresolved_findings':[]},indent=2)+'\n')
