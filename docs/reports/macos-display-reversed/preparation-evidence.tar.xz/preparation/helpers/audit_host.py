from pathlib import Path
import sys,importlib.util,hashlib,json,datetime,time,tempfile,inspect
sys.dont_write_bytecode=True
x=Path(__file__).resolve().parent.parent;q=Path(__file__).resolve().parent/'prepared';r=Path('/Users/dshills/Development/projects/Vellum');sys.path.insert(0,str(r/'scripts'));sp=importlib.util.spec_from_file_location('audit_actual_host',x/'macos-release-default-assessment/assessment.py');a=importlib.util.module_from_spec(sp);sys.modules[sp.name]=a;sp.loader.exec_module(a);a.T=r
class Lease:
 def held(self):return True
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory);a.P=root;host=a.Host({'pins':{}},root,datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(seconds=1),Lease(),[False]);original=a.g.execute
 def forbidden(*args,**kwargs):raise AssertionError('expired host launched a child')
 a.g.execute=forbidden
 for name,call in [('expired-command',lambda:host.command(['unused'],r,root/'unused',40)),('expired-probes',lambda:host.probes(root/'probes'))]:
  try:call()
  except ValueError as e:assert 'stop/deadline' in str(e)
  else:raise AssertionError(name)
 a.g.execute=original
 # Exercise the actual executor's finally-retire path with an overall stop,
 # not a native window. The per-process timeout deliberately exceeds it.
 deadline=time.monotonic()+.2
 run=a.g.execute(['/usr/bin/sandbox-exec','-p','(version 1)(allow default)(deny network*)',sys.executable,'-c','import time; time.sleep(5)'],r,q/'global-stop-child',lambda:time.monotonic()>=deadline,lambda:True,timeout=5,limit=1<<20)
 assert run['error'] and run['owned']['terminal'] and run['owned']['group_absent'] and not run['owned']['errors'] and run['seconds']<3
(q/'global-stop-child-receipt.json').write_text(json.dumps(run,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit={'result':'PASS','actual_host_expired_command':'Refuses before executor invocation','actual_host_expired_probe':'Refuses before executor invocation','actual_executor_global_stop':'0.2s overall stop interrupts5s child/percase5s; actual finally retires owned group','owned_stop_seconds':run['seconds'],'owned_stop_group_absent':True,'Host_finish_role':'Integrity assertion only; no child, lease or native resource cleanup. Calling it in finally would not add cleanup and could mask the original failure.','lifetime':'Host.command invokes check before all launches/probes; actual executor checks stopping before/during launch and polling, and retires in finally. LiveLease exits through outer with, and runner seals attempt in finally.','pins':{str(Path(a.__file__)):sha(Path(a.__file__)),str(Path(a.g.__file__)):sha(Path(a.g.__file__)),str(r/'scripts/child_process.py'):sha(r/'scripts/child_process.py')},'source':{n:inspect.getsource(getattr(a.Host,n)) for n in ['finish','command','stopping']},'no_native_application_or_settings_changed':True}
(q/'host-guard-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps({k:v for k,v in audit.items() if k not in ['source','pins']}))
