from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-menu-observation')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def identity():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
 sources={n:sha(r/n)for n in names if n}
 prepared={q.relative_to(r/'drivers/cogent/build').as_posix():sha(q)for module in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/module).rglob('*'))if q.is_file()and not q.is_symlink()}
 return sources,prepared
name=sys.argv[1];before=identity();stage=json.loads((p/'stage.json').read_bytes());assert before[1]==stage['prepared']
cases={
 'regression':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=30s','-v','-run','^TestNativeMenuObservationDistinguishesUncapturedOriginal$','.'],
 'adapter':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=120s','./...'],
 'vet':['go','vet','-p=1','-tags=offscreen','./...'],
 'build-native':['go','build','-p=1','-tags=vellum_native_checks','-o',str(p/'services-smoke'),'./cmd/services-smoke'],
}
argv=cases[name];v={'case':name,'argv':argv,'cwd':str(r/'drivers/cogent'),'producer_sha256':sha(Path(__file__)),'source_files':before[0],'prepared':before[1],'native_gpu_or_ui_admitted':False,'exit_code':None,'error':None,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
assert 'VELLUM_GPU_SCENE_TEST'not in env
start=time.monotonic()
try:
 with(p/(name+'.stdout')).open('xb')as out,(p/(name+'.stderr')).open('xb')as err:
  v['exit_code']=run_child(argv,cwd=r/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=360,log_limit_bytes=8<<20).returncode
except BaseException as e:v['error']={'type':type(e).__name__,'message':str(e)}
finally:
 v['source_and_prepared_stable']=identity()==before
 v.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 v['logs']={n:{'bytes':(p/(name+'.'+n)).stat().st_size,'sha256':sha(p/(name+'.'+n))}for n in ['stdout','stderr']}
 if name=='build-native'and v['exit_code']==0:v['binary']={'file':'services-smoke','bytes':(p/'services-smoke').stat().st_size,'sha256':sha(p/'services-smoke'),'executed':False}
 v['result']='PASS_OFFSCREEN_OR_COMPILE_ONLY_CHECK'if v['exit_code']==0 and not v['error'] and v['source_and_prepared_stable']else'FAILED_CHECK'
 with(p/(name+'.json')).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
 print(json.dumps({k:v[k]for k in ['result','case','exit_code','error','elapsed_seconds','source_and_prepared_stable']}))
if v['result']=='FAILED_CHECK':sys.exit(1)
