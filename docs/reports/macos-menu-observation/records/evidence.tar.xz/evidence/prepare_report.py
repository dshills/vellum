from pathlib import Path
import hashlib,json,tarfile,io,datetime,subprocess
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-menu-observation')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source_names=['drivers/cogent/cmd/services-smoke/main.go','drivers/cogent/native_services_checks_darwin.go','drivers/cogent/services_darwin.go','drivers/cogent/services_darwin.m','drivers/cogent/menu_observation_darwin_test.go','specs/macos-service-performance.md']
sources={n:sha(r/n)for n in source_names}
checks={};first=None
for case in ['regression','adapter','vet','build-native']:
 d=json.loads((p/(case+'.json')).read_bytes())
 assert d['exit_code']==0 and not d['error'] and d['source_and_prepared_stable'] and d['native_gpu_or_ui_admitted']is False
 assert all(d['source_files'][n]==h for n,h in sources.items())
 if first is None:first=d
 else:assert d['source_files']==first['source_files']and d['prepared']==first['prepared']
 for channel in ['stdout','stderr']:
  q=p/(case+'.'+channel);assert d['logs'][channel]=={'bytes':q.stat().st_size,'sha256':sha(q)}
 checks[case]={'receipt_sha256':sha(p/(case+'.json')),'argv':d['argv'],'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'source_and_prepared_stable':True,'logs':d['logs']}
assert len(first['prepared'])==6230
review=json.loads((p/'source-review.json').read_bytes())
# The reviewer supplies disposition and exact source bindings; require its
# approved marker and independently compare every owned source snapshot below.
assert review.get('source_ready')is True or str(review.get('result','')).startswith('APPROVED')
recorddir=r/'docs/reports/macos-menu-observation/records';recorddir.mkdir(parents=True)
entries={}
for name in ['stage.py','stage.json','check.py','prepare_report.py','source-review.json','source-review.md']+[case+'.'+ext for case in checks for ext in ['json','stdout','stderr']]:entries['evidence/'+name]=(p/name).read_bytes()
for name in source_names:entries['source/'+name]=(r/name).read_bytes()
index={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(entries.items())}
with(recorddir/'evidence.tar.xz').open('xb')as f:
 with tarfile.open(fileobj=f,mode='w:xz',format=tarfile.USTAR_FORMAT)as archive:
  for name,data in sorted(entries.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
with(recorddir/'archive-index.json').open('x')as f:json.dump(index,f,indent=2);f.write('\n')
q={'schema':1,'result':'PASS_SCOPED_MENU_OBSERVATION_SERIALIZATION','base_commit':'b8fd3e902a5d8d0a626f1aff5c1a4f6be46e95d7','source_files':sources,'tested_source_files':len(first['source_files']),'prepared_files':len(first['prepared']),'checks':checks,'internal_source_review':{'file':'evidence/source-review.json','sha256':sha(p/'source-review.json'),'result':review['result']},'archive':{'file':'evidence.tar.xz','bytes':(recorddir/'evidence.tar.xz').stat().st_size,'sha256':sha(recorddir/'evidence.tar.xz'),'members':len(index),'uncompressed_bytes':sum(x['bytes']for x in index.values())},'archive_index_sha256':sha(recorddir/'archive-index.json'),'prism':'Deferred to next significant checkpoint; small internal-review checkpoint between provider reviews.','native_executable':json.loads((p/'build-native.json').read_bytes())['binary'],'native_appkit_menu_runtime_executed':False,'native_menu_restoration_qualified':False,'physical_menu_interaction_qualified':False,'full_mac_qualified':False,'settings_changed':False}
with(recorddir/'qualification.json').open('x')as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'checks':len(checks),'archive':q['archive']}))
