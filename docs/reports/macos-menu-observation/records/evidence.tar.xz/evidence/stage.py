from pathlib import Path
import hashlib,json,shutil,subprocess,datetime
p=Path(__file__).resolve().parent
r=Path('/private/tmp/vellum-menu-observation')
c=Path('/Users/dshills/Development/projects/Vellum')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def tree(base):
 d={}
 for mod in ['upstream','typesetting']:
  for q in sorted((base/mod).rglob('*')):
   if q.is_symlink():raise ValueError('prepared symlink')
   if q.is_file():d[q.relative_to(base).as_posix()]=sha(q)
 return d
before=tree(c/'drivers/cogent/build')
assert len(before)==6230
(r/'drivers/cogent/build').mkdir()
for mod in ['upstream','typesetting']:shutil.copytree(c/'drivers/cogent/build'/mod,r/'drivers/cogent/build'/mod)
assert before==tree(c/'drivers/cogent/build')==tree(r/'drivers/cogent/build')
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
sources={n:sha(r/n)for n in names if n}
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'source_files':sources,'prepared':before,'producer_sha256':sha(Path(__file__)),'native_gpu_or_ui_admitted':False,'result':'COPIED_MATCHING_PREPARED_BASELINE'}
with(p/'stage.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'result':result['result'],'source_files':len(sources),'prepared_files':len(before)}))
