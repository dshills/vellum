import datetime,hashlib,json,selectors,subprocess,sys,time
from pathlib import Path
r=Path('/private/tmp/vellum-large-data');p=Path('/private/tmp/vellum-macos-quiet');sys.path.insert(0,str(r/'scripts'))
from child_process import run_child,terminate_owned_group
from sdk_environment import child_environment
binary=p/'DropBounded.app/Contents/MacOS/VellumDropFinal';helper=Path('/private/tmp/vellum-native-choosers/ax')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='fab110d5fa0b258023497f20fec5c0bff1e6afa375f2248cdc1fc334939e6d0d'
assert json.loads((p/'ax-trust-check.stdout').read_text())['trusted'] is True
end=datetime.datetime.fromisoformat(json.loads((p/'testing-authorization.json').read_text())['authorized_until_utc']);assert datetime.datetime.now(datetime.timezone.utc)<end
record={'schema':1,'scope':'Read-only external AX queries to exact owned PID/executable/windows; no physical drag, activation, CGEvents, settings or clipboard changes','argv':[str(binary),'-interactive','-timeout=30s'],'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'queries':[],'result':'FAILED'}
env=child_environment(runtime=True);process=None;start=time.monotonic();selector=None
try:
 with (p/'external-ax-app.stdout').open('xb') as appout,(p/'external-ax-app.stderr').open('xb') as apperr:
  process=subprocess.Popen(record['argv'],cwd=r/'drivers/cogent',env=env,stdout=subprocess.PIPE,stderr=apperr,start_new_session=True)
  record['owned_pid']=process.pid;selector=selectors.DefaultSelector();selector.register(process.stdout,selectors.EVENT_READ);pending=bytearray();ready=False
  until=time.monotonic()+8
  while time.monotonic()<until and not ready:
   if selector.select(timeout=.2):
    import os
    data=os.read(process.stdout.fileno(),65536)
    if not data:break
    appout.write(data);appout.flush();pending.extend(data);ready=b'READY physical drag target:' in pending
  assert ready,'native fixture not ready';record['ready']=True
  # Allow demand painting to settle; this is outside any measured performance run.
  time.sleep(2)
  for name,title,label in [('second','Vellum second file drop smoke','Second window target'),('main','Vellum file drop smoke','File target 0')]:
   argv=[str(helper),str(process.pid),'dump'];qs=time.monotonic();query={'argv':argv,'window':title}
   with (p/('external-ax-'+name+'.stdout')).open('xb') as so,(p/('external-ax-'+name+'.stderr')).open('xb') as se:
    result=run_child(argv,env={**env,'VELLUM_AX_EXECUTABLE':str(binary),'VELLUM_AX_WINDOW':title},stdout=so,stderr=se,timeout=8)
   query.update({'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-qs});record['queries'].append(query)
   assert result.returncode==0,'external AX dump failed'
   data=json.loads((p/('external-ax-'+name+'.stdout')).read_text());states=[n['state'] for n in data['nodes']]
   assert title in data['window_titles'] and any(label in str(s) for s in states),'expected owned window/label absent'
   assert not any(e['status'] not in [-25205,-25212] for e in data['read_errors']),'unexpected AX read error'
  # No drag is issued. The fixture's expected deadline failure gives normal
  # native teardown rather than an external close/action or forced process kill.
  remaining,_=process.communicate(timeout=35);appout.write(remaining);appout.flush()
  record['app_exit_code']=process.returncode;assert process.returncode==1,'expected no-drag deadline failure'
  record['result']='PASS_BOUNDED_EXTERNAL_AX_RESPONSE'
except BaseException as e:record['error']={'type':type(e).__name__,'message':str(e)};raise
finally:
 if selector is not None:selector.close()
 if process is not None and process.poll() is None:
  terminate_owned_group(process)
  process.wait(timeout=5)
 record['elapsed_seconds']=time.monotonic()-start
 record['app_exit_code']=process.returncode if process else None
 for f in [p/'external-ax-app.stdout',p/'external-ax-main.stdout',p/'external-ax-second.stdout']:
  record[f.name+'_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
 (p/'external-ax-result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'result':record['result'],'elapsed_seconds':record['elapsed_seconds'],'queries':record['queries']}))
