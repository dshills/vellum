//go:build offscreen

package core

import (
	"context"
	"slices"
	"sync"
	"testing"
	"time"

	"cogentcore.org/core/events"
)

func TestVellumRetiredManualWindowAllowsOrdinaryWindow(t *testing.T) {
	m, _, _ := manualFixture(t, nil)
	drainManual(t, m)
	retired := m.window
	if err := m.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	if currentRenderWindowSnapshot() == retired || slices.Contains(AllRenderWindows.snapshot(), retired) || slices.Contains(mainRenderWindows.snapshot(), retired) || slices.Contains(dialogRenderWindows.snapshot(), retired) {
		t.Fatal("closed manual window retained the construction context or registry ownership")
	}
	body := NewBody("ordinary after manual close")
	shown := make(chan struct{}, 1)
	body.OnFinal(events.Show, func(events.Event) {
		select {
		case shown <- struct{}{}:
		default:
		}
	})
	body.RunWindow()
	w := body.Scene.RenderWindow()
	if w == nil || w.manual != nil {
		t.Fatal("ordinary construction inherited the retired manual context")
	}
	t.Cleanup(func() {
		rc := w.renderContext()
		rc.Lock()
		body.Close()
		rc.Unlock()
		deadline := time.Now().Add(3 * time.Second)
		for slices.Contains(AllRenderWindows.snapshot(), w) {
			if time.Now().After(deadline) {
				t.Error("ordinary window did not retire")
				return
			}
			time.Sleep(time.Millisecond)
		}
	})
	select {
	case <-shown:
	case <-time.After(3 * time.Second):
		t.Fatal("ordinary window did not show after manual retirement")
	}
}

func windowRetirementRegistryFixture(t *testing.T) {
	t.Helper()
	renderWindowGlobalMu.Lock()
	all, main, dialogs, current := AllRenderWindows, mainRenderWindows, dialogRenderWindows, currentRenderWindow
	AllRenderWindows, mainRenderWindows, dialogRenderWindows, currentRenderWindow = nil, nil, nil, nil
	renderWindowGlobalMu.Unlock()
	t.Cleanup(func() {
		renderWindowGlobalMu.Lock()
		AllRenderWindows, mainRenderWindows, dialogRenderWindows, currentRenderWindow = all, main, dialogs, current
		renderWindowGlobalMu.Unlock()
	})
}

func TestVellumWindowRetirementSelectsLiveContextAndReleasesBeforeRaise(t *testing.T) {
	windowRetirementRegistryFixture(t)
	a := &renderWindow{SystemWindow: &vellumWindowListNative{}}
	b := &renderWindow{SystemWindow: &vellumWindowListNative{}}
	raises := 0
	c := &renderWindow{SystemWindow: &vellumWindowListNative{raise: func() {
		raises++
		// Reenter the registry from the native callout. Retirement must have
		// released its mutex and removed the closed window from every list.
		if slices.Contains(AllRenderWindows.snapshot(), b) || slices.Contains(mainRenderWindows.snapshot(), b) || slices.Contains(dialogRenderWindows.snapshot(), b) {
			t.Error("native focus restoration ran before registry withdrawal")
		}
	}}}
	renderWindowGlobalMu.Lock()
	AllRenderWindows, mainRenderWindows, dialogRenderWindows = renderWindowList{a, b, c}, renderWindowList{a, b, c}, renderWindowList{b}
	currentRenderWindow = a
	renderWindowGlobalMu.Unlock()
	b.closed()
	if currentRenderWindowSnapshot() != a || raises != 1 {
		t.Fatal("closing a noncurrent window changed the construction context")
	}
	a.closed()
	if currentRenderWindowSnapshot() != c || raises != 2 {
		t.Fatal("closing the current window did not select the survivor")
	}
	c.closed()
	c.closed()
	if currentRenderWindowSnapshot() != nil || len(AllRenderWindows.snapshot()) != 0 || len(mainRenderWindows.snapshot()) != 0 || len(dialogRenderWindows.snapshot()) != 0 {
		t.Fatal("last or repeated close retained registry or current-window state")
	}
}

func TestVellumWindowFocusRetirementCannotRepublishClosedWindow(t *testing.T) {
	windowRetirementRegistryFixture(t)
	for round := 0; round < 64; round++ {
		survivor := &renderWindow{SystemWindow: &vellumWindowListNative{}}
		closing := &renderWindow{SystemWindow: &vellumWindowListNative{}}
		renderWindowGlobalMu.Lock()
		AllRenderWindows = renderWindowList{survivor, closing}
		mainRenderWindows = slices.Clone(AllRenderWindows)
		dialogRenderWindows = nil
		currentRenderWindow = closing
		renderWindowGlobalMu.Unlock()
		start := make(chan struct{})
		var workers sync.WaitGroup
		workers.Add(2)
		go func() {
			defer workers.Done()
			<-start
			for range 512 {
				closing.handleWindowEvents(events.NewWindow(events.WinFocus))
			}
		}()
		go func() {
			defer workers.Done()
			<-start
			closing.handleWindowEvents(events.NewWindow(events.WinClose))
		}()
		close(start)
		workers.Wait()
		closing.handleWindowEvents(events.NewWindow(events.WinFocus))
		if currentRenderWindowSnapshot() != survivor || !slices.Equal(AllRenderWindows.snapshot(), renderWindowList{survivor}) || !slices.Equal(mainRenderWindows.snapshot(), renderWindowList{survivor}) {
			t.Fatal("late focus republished a retired window or changed membership")
		}
		survivor.closed()
	}
}
