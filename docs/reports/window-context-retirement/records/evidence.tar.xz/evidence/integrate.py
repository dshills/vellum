"""Create the driver-owned reproducible patch and its pinned integration files."""
from pathlib import Path
import difflib,hashlib,json
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement');o=p/'integration'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
names=['core/renderwindow.go','core/windowlists.go','core/window_retirement_vellum_test.go']
patchdir='drivers/cogent/native/patches/windowretirement'
patchname='0070-retire-current-window-context.patch'
original={};outputs={};chunks=[]
for n in names:
 old=p/'before'/n;new=p/'draft'/n
 original[n]=sha(old)if old.exists()else None;outputs[n]=sha(new)
 chunks.extend(difflib.unified_diff(old.read_text().splitlines(keepends=True)if old.exists()else[],new.read_text().splitlines(keepends=True),fromfile='a/'+n if old.exists()else'/dev/null',tofile='b/'+n))
q=o/patchdir;q.mkdir(parents=True,exist_ok=True)
(q/patchname).write_text(''.join(chunks))
for filename,v in [('original-hashes.json',original),('output-hashes.json',outputs)]:
 (q/filename).write_text(json.dumps(v,indent=2)+'\n')
readme='''# Render-window context retirement

Patch 0070 withdraws a closed window from all three render registries and
replaces its current construction context with a registered survivor, or nil.
Without this, closing the last manual window leaves a manual context that
silently refuses the next ordinary window.

Focus membership, ordering and current-context publication share the retirement
mutex. Raise refuses an unregistered window and publishes before its native
callout so a reentrant close cannot be overwritten afterward. Native calls run
after releasing the registry mutex; snapshots do not extend native lifetimes.

Offscreen regressions cover actual manual close followed by ordinary Show,
survivor/last/repeated retirement, registry reentry during Raise, native Raise
closing its own window, and concurrent native focus/close events. Existing live
manual-mode and mixed-mode refusal contracts remain in place. Physical desktop
focus and native object deallocation require separate live evidence.
'''
(q/'README.md').write_text(readme)
manifest=json.loads((r/'drivers/cogent/native/dependencies.json').read_text())
manifest['dependencies'][0]['stages'].append({'origin':patchdir,'inputs':'native/patches/windowretirement/original-hashes.json','outputs':'native/patches/windowretirement/output-hashes.json','patches':[{'file':'native/patches/windowretirement/'+patchname,'sha256':sha(q/patchname)}]})
target=o/'drivers/cogent/native/dependencies.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(manifest,indent=2)+'\n')
text=(r/'drivers/cogent/prepare_test.py').read_text();assert text.count('list(range(1, 70))')==1
(o/'drivers/cogent/prepare_test.py').write_text(text.replace('list(range(1, 70))','list(range(1, 71))'))
spec=(r/'specs/native-window-lifecycle.md').read_text()
spec+='''

## Retired construction contexts

Closing a render window withdraws it from all render registries and replaces its
current construction context with a registered survivor, or nil when none remain.
After the last manual window closes, a subsequent ordinary window must open and
deliver Show through its ordinary event loop. A retired manual context must not
make that construction silently fail the live manual-mode restrictions.

Native focus membership checks, focus ordering and current-context publication
are atomic with registry withdrawal. Raise refuses retired windows and publishes
before invoking native code, so a reentrant close remains withdrawn. Native
focus/raise calls run outside the registry mutex. This does not extend native
object lifetimes or replace owner-thread requirements.

Owned patch 0070 includes offscreen manual-to-ordinary construction, retirement,
reentrant Raise and concurrent focus/close regression coverage. Existing mixed
live manual/ordinary mode refusals still apply. Offscreen routing evidence does
not establish physical desktop focus, native object deallocation or full Mac
acceptance.
'''
q=o/'specs/native-window-lifecycle.md';q.parent.mkdir(exist_ok=True);q.write_text(spec)
files={q.relative_to(o).as_posix():sha(q)for q in sorted(o.rglob('*'))if q.is_file()}
v={'base_commit':'4da0d6b42c67f52ba3243bad6fc6cd65d34c7d8f','files':files,'prepared_outputs':outputs,'prepared_inputs':original,'producer_sha256':sha(Path(__file__))}
with(p/'integration.json').open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps({'integration_files':len(files),'patch_bytes':(o/patchdir/patchname).stat().st_size,'prepared_outputs':len(outputs)}))
