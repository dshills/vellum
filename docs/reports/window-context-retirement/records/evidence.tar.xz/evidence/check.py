"""Actual bounded offscreen checks with complete before/after source bindings."""
from pathlib import Path
import datetime,hashlib,json,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
name,phase=sys.argv[1:]
cases={
 'pair':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=15s','-v','-run','^TestVellum(ManualConstructionAndExplicitInput|RenderedGeometryScrollAndWrap)$','./core'],
 'regression':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=30s','-v','-run','^TestVellum(Retired|WindowRetirement|WindowFocusRetirement)','./core'],
 'core':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=120s','-v','-run','^TestVellum','./core'],
 'adapter':['go','test','-race','-p=1','-count=1','-tags=offscreen','-timeout=120s','./...'],
 'vet':['go','vet','-p=1','-tags=offscreen','./...'],
 'prepare-tests':[sys.executable,'prepare_test.py'],
}
cwd=r/'drivers/cogent'
if name in ['pair','regression','core']:cwd=cwd/'build/upstream'
argv=cases[name];prefix=phase+'-'+name
assert not(p/(prefix+'.json')).exists()
expected=json.loads((p/(phase+'.json')).read_text())
def identity():
 sources={n:sha(r/n)for n in expected['source_files']}
 prepared={q.relative_to(r/'drivers/cogent/build').as_posix():sha(q)for module in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/module).rglob('*'))if q.is_file()and not q.is_symlink()}
 return sources,prepared
before=identity();assert before==(expected['source_files'],expected['prepared'])
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
assert 'VELLUM_GPU_SCENE_TEST'not in env
v={'case':name,'phase':phase,'argv':argv,'cwd':str(cwd),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_binding_sha256':sha(p/(phase+'.json')),'producer_sha256':sha(Path(__file__)),'exit_code':None,'error':None,'native_gpu_or_ui_admitted':False}
start=time.monotonic()
try:
 with(p/(prefix+'.stdout')).open('xb')as out,(p/(prefix+'.stderr')).open('xb')as err:
  v['exit_code']=run_child(argv,cwd=cwd,env=env,stdout=out,stderr=err,timeout=360,log_limit_bytes=8<<20).returncode
except BaseException as error:v['error']={'type':type(error).__name__,'message':str(error)}
finally:
 v['source_and_prepared_stable']=identity()==before
 v.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 v['logs']={n:{'bytes':(p/(prefix+'.'+n)).stat().st_size,'sha256':sha(p/(prefix+'.'+n))}for n in ['stdout','stderr']}
 v['result']='PASS_OFFSCREEN_CHECK'if v['exit_code']==0 and v['error']is None and v['source_and_prepared_stable']else'FAILED_OFFSCREEN_CHECK'
 with(p/(prefix+'.json')).open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
 print(json.dumps({k:v[k]for k in ['result','phase','case','exit_code','error','elapsed_seconds','source_and_prepared_stable']}),flush=True)
if v['result']!='PASS_OFFSCREEN_CHECK':sys.exit(1)
