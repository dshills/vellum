"""Install pinned integration and verify a full clean dependency preparation."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
baseline=json.loads((p/'baseline.json').read_text());integration=json.loads((p/'integration.json').read_text())
assert all(sha(r/n)==h for n,h in baseline['source_files'].items())
negative=json.loads((p/'negative-v2-regression.json').read_text());assert negative['exit_code']==1 and negative['error']is None and negative['source_and_prepared_stable']
assert not(p/'candidate.json').exists()
for n,h in integration['files'].items():
 q=r/n;q.parent.mkdir(parents=True,exist_ok=True);assert sha(p/'integration'/n)==h;q.write_bytes((p/'integration'/n).read_bytes())
names=[n.decode()for n in subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=r,timeout=15).split(b'\0')if n]
sources={n:sha(r/n)for n in names}
expected=dict(baseline['prepared']);expected.update({'upstream/'+n:h for n,h in integration['prepared_outputs'].items()})
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
argv=[sys.executable,str(r/'drivers/cogent/prepare.py')];start=time.monotonic()
with(p/'candidate-prepare.stdout').open('xb')as out,(p/'candidate-prepare.stderr').open('xb')as err:
 code=run_child(argv,cwd=r/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=300,log_limit_bytes=8<<20).returncode
prepared={q.relative_to(r/'drivers/cogent/build').as_posix():sha(q)for module in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/module).rglob('*'))if q.is_file()and not q.is_symlink()}
assert code==0 and prepared==expected and all(sha(r/n)==h for n,h in sources.items())
v={'result':'PREPARED_EXACT_WINDOW_RETIREMENT_CANDIDATE','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':baseline['head'],'source_files':sources,'prepared':prepared,'source_file_count':len(sources),'prepared_file_count':len(prepared),'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'producer_sha256':sha(Path(__file__)),'integration_sha256':sha(p/'integration.json'),'baseline_sha256':sha(p/'baseline.json'),'logs':{n:{'sha256':sha(p/n),'bytes':(p/n).stat().st_size}for n in ['candidate-prepare.stdout','candidate-prepare.stderr']},'canonical_or_frozen_sources_modified':False,'native_application_executed':False}
with(p/'candidate.json').open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v[k]for k in ['result','source_file_count','prepared_file_count','elapsed_seconds']}))
