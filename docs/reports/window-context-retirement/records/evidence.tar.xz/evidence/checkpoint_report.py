"""Package actual offscreen evidence and draft the scoped lifecycle checkpoint."""
from pathlib import Path
import datetime,hashlib,io,json,re,tarfile
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement');o=p/'integration'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
read=lambda q:json.loads(q.read_text())
integration=read(p/'integration.json');source_review=read(p/'source-review.json');review=read(p/'integration-source-review.json')
assert not review['unresolved_findings']and review['prism_ready']
assert all(sha(o/n)==h for n,h in integration['files'].items())
assert all(sha(p/'draft'/n)==h for n,h in source_review['sources'].items())
checks={}
for name in ['candidate-regression','candidate-pair','candidate-prepare-tests','candidate-core','candidate-adapter','candidate-vet']:
 v=read(p/(name+'.json'))
 assert v['result']=='PASS_OFFSCREEN_CHECK'and v['source_and_prepared_stable']and not v['native_gpu_or_ui_admitted']
 for channel,entry in v['logs'].items():assert entry['sha256']==sha(p/(name+'.'+channel))
 checks[name]={'receipt_sha256':sha(p/(name+'.json')),'exit_code':v['exit_code'],'elapsed_seconds':v['elapsed_seconds']}
baseline=read(p/'baseline-pair.json');negative=read(p/'negative-v2-regression.json')
assert baseline['exit_code']==negative['exit_code']==1 and baseline['source_and_prepared_stable']and negative['source_and_prepared_stable']
assert 'panic: test timed out after 15s'in(p/'baseline-pair.stdout').read_text()
negative_text=(p/'negative-v2-regression.stdout').read_text()
assert len(re.findall(r'^--- FAIL: ',negative_text,re.M))==4
core=(p/'candidate-core.stdout').read_text()
passed=re.findall(r'^--- PASS: (Test[^/\s]+) ',core,re.M)
assert len(passed)==114 and not re.findall(r'^--- (FAIL|SKIP): ',core,re.M)
summary={'result':'PASS_SCOPED_OFFSCREEN_WINDOW_RETIREMENT','baseline_pair_failed_same_show_wait':True,'negative_regressions_intended_failures':4,'candidate_selected_core_top_level_passes':len(passed),'candidate_selected_core_skips':0,'checks':checks,'source_review_sha256':sha(p/'source-review.json'),'integration_review_sha256':sha(p/'integration-source-review.json'),'candidate_source_binding_sha256':sha(p/'candidate.json'),'native_gpu_or_ui_executed':False,'physical_focus_qualified':False,'full_mac_qualified':False}
with(p/'summary.json').open('x')as f:f.write(json.dumps(summary,indent=2)+'\n')
d=o/'docs/reports/window-context-retirement';d.mkdir(parents=True,exist_ok=True)
text='''# Window construction after manual retirement

Closing the last manual window left it as the global construction context.
A subsequent ordinary window inherited that retired manual mode and silently
refused to open. The committed baseline reproduces this as a 15-second Show wait
timeout when the manual-construction test precedes rendered geometry.

Owned patch 0070 removes all three registry memberships and withdraws or replaces
the current context in one mutex transaction. Native focus checks membership,
orders focus and publishes the current context under the same mutex. Raise
refuses unregistered windows and publishes before the native call, so reentrant
close cannot be overwritten afterward. Native calls run outside the mutex.

The exact failing two-test sequence now passes without resetting global state.
Four new regressions fail against unchanged production and pass with the fix:
real manual close followed by ordinary Show; survivor/last/repeated retirement;
reentrant native Raise that closes itself; and concurrent focus/close events.
The broader selected `^TestVellum` core race run passes all 114 top-level tests
with no skips, including live mixed-mode refusal checks. Full adapter-module
race and vet checks and all 11 preparation Python tests pass. Fresh preparation
reproduces all 6,230 dependency files, with exactly the declared three changed
or added leaves relative to the 6,229-file baseline.

`records/evidence.tar.xz` and `records/archive-index.json` preserve the producers,
exact baseline/candidate maps, terminal logs, four intended negative assertions,
draft source and internal reviews. An earlier regression fixture incorrectly
expected focus restoration to preserve the previous current window; its original
failed run is preserved separately and supplies no acceptance evidence.
`records/qualification.json` binds the final source and review associations.
The archive excludes private executables; scripts retain original absolute paths
and are evidence records rather than a portable replay package.

These are offscreen construction/routing and race observations while the user
is online. No live UI or native GPU test was admitted. Native handle lifetimes,
physical desktop focus, native object deallocation, ordinary frame budgets,
overnight acceptance and the remaining Mac gates need separate evidence.
The prior GPU-host diagnostics draft is outside this patch and must be rebased
onto the new lifecycle source before its remaining native checks.
'''
(d/'README.md').write_text(text)
index=r/'docs/reports/README.md';q=o/'docs/reports/README.md';q.parent.mkdir(parents=True,exist_ok=True)
q.write_text(index.read_text()+'\n- [Window construction after manual retirement](window-context-retirement/README.md): reproduced manual-to-ordinary Show failure, atomic registry/context withdrawal, reentrant Raise safety and offscreen race controls.\n')
selected={q.relative_to(p).as_posix():q for q in sorted(p.rglob('*'))if q.is_file()and 'integration'not in q.relative_to(p).parts and '__pycache__'not in q.parts}
assert not any(q.is_symlink()for q in selected.values())and sum(q.stat().st_size for q in selected.values())<16<<20
records=d/'records';records.mkdir()
members={}
with tarfile.open(records/'evidence.tar.xz','x:xz',preset=3)as archive:
 for n,q in sorted(selected.items()):
  data=q.read_bytes();member=tarfile.TarInfo('evidence/'+n);member.size=len(data);member.mode=0o644;member.mtime=0
  archive.addfile(member,io.BytesIO(data));members[member.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(records/'evidence.tar.xz','r:xz')as archive:
 assert len(archive.getmembers())==len(members)
 for m in archive.getmembers():
  assert m.isfile()and hashlib.sha256(archive.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
archive_index={'members':members,'member_count':len(members),'uncompressed_bytes':sum(v['bytes']for v in members.values()),'private_executables_included':False,'portable_replay_claimed':False}
(records/'archive-index.json').write_text(json.dumps(archive_index,indent=2)+'\n')
sources={**integration['files'],**{n:sha(o/n)for n in ['docs/reports/window-context-retirement/README.md','docs/reports/README.md']}}
qualification={'schema':1,'result':'PREPARED_SCOPED_WINDOW_RETIREMENT_CHECKPOINT','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':integration['base_commit'],'sources':sources,'summary':summary,'archive_sha256':sha(records/'evidence.tar.xz'),'archive_index_sha256':sha(records/'archive-index.json'),'internal_report_review_pending':True,'provider_review_pending':True,'checkpoint_complete':False,'native_ui_qualified':False,'full_mac_qualified':False}
(records/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
with(p/'checkpoint-sources.json').open('x')as f:f.write(json.dumps({'sources':sources,'archive_members':len(members),'archive_sha256':sha(records/'evidence.tar.xz'),'qualification_sha256':sha(records/'qualification.json'),'producer_sha256':sha(Path(__file__))},indent=2)+'\n')
print(json.dumps({'result':summary['result'],'sources':len(sources),'archive_members':len(members),'archive_bytes':(records/'evidence.tar.xz').stat().st_size}))
