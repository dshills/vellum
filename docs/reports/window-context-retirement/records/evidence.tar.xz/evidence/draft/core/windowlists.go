// Copyright (c) 2018, Cogent Core. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
	"reflect"
	"slices"

	"cogentcore.org/core/base/reflectx"
	"cogentcore.org/core/system"
)

// renderWindowList is a list of [renderWindow]s.
type renderWindowList []*renderWindow

// unregister removes all registry ownership and withdraws a retired construction
// context in one transaction. The returned focus candidate must be used outside
// the mutex; this snapshot does not extend its native lifetime.
func (w *renderWindow) unregister() *renderWindow {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	for _, list := range []*renderWindowList{&AllRenderWindows, &mainRenderWindows, &dialogRenderWindows} {
		*list = slices.DeleteFunc(*list, func(candidate *renderWindow) bool { return candidate == w })
	}
	var next *renderWindow
	if len(AllRenderWindows) > 0 {
		next = AllRenderWindows[len(AllRenderWindows)-1]
	}
	if currentRenderWindow == w {
		currentRenderWindow = next
	}
	return next
}

// publishFocus checks live membership, orders focus and publishes the current
// context under the same mutex as unregister. A delayed native focus event must
// not republish a window removed by a concurrent close.
func (w *renderWindow) publishFocus() bool {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	i := slices.Index(AllRenderWindows, w)
	if i < 0 {
		return false
	}
	copy(AllRenderWindows[i:], AllRenderWindows[i+1:])
	AllRenderWindows[len(AllRenderWindows)-1] = w
	currentRenderWindow = w
	return true
}

// add adds a window to the list.
func (wl *renderWindowList) add(w *renderWindow) {
	renderWindowGlobalMu.Lock()
	*wl = append(*wl, w)
	renderWindowGlobalMu.Unlock()
}

// delete removes a window from the list.
func (wl *renderWindowList) delete(w *renderWindow) {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	*wl = slices.DeleteFunc(*wl, func(rw *renderWindow) bool {
		return rw == w
	})
}

// snapshot detaches collection membership from concurrent adds/removals. It
// does not acquire the individual windows' render contexts or extend their
// native lifetimes. Callers retain each window's normal ownership checks.
func (wl *renderWindowList) snapshot() renderWindowList {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	return slices.Clone(*wl)
}

// last reads the focus-restoration candidate under the collection mutex.
// Native methods on the returned window must run after releasing that mutex.
func (wl *renderWindowList) last() *renderWindow {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	if len(*wl) == 0 {
		return nil
	}
	return (*wl)[len(*wl)-1]
}

// promoteExisting moves a registered window to the end in one transaction.
// A delayed focus event for a removed window cannot reinsert it. No native
// methods or render-context locks are acquired while holding the registry lock.
func (wl *renderWindowList) promoteExisting(w *renderWindow) bool {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	i := slices.Index(*wl, w)
	if i < 0 {
		return false
	}
	copy((*wl)[i:], (*wl)[i+1:])
	(*wl)[len(*wl)-1] = w
	return true
}

// FindName finds the window with the given name or title
// on the list (case sensitive).
// It returns the window if found and nil otherwise.
func (wl *renderWindowList) FindName(name string) *renderWindow {
	renderWindowGlobalMu.Lock()
	defer renderWindowGlobalMu.Unlock()
	for _, w := range *wl {
		if w.name == name || w.title == name {
			return w
		}
	}
	return nil
}

// findData finds window with given Data on list -- returns
// window and true if found, nil, false otherwise.
// data of type string works fine -- does equality comparison on string contents.
func (wl *renderWindowList) findData(data any) (*renderWindow, bool) {
	if reflectx.IsNil(reflect.ValueOf(data)) {
		return nil, false
	}
	typ := reflect.TypeOf(data)
	if !typ.Comparable() {
		fmt.Printf("programmer error in RenderWinList.FindData: Scene.Data type %s not comparable (value: %v)\n", typ.String(), data)
		return nil, false
	}
	for _, wi := range wl.snapshot() {
		msc := wi.MainScene()
		if msc == nil {
			continue
		}
		if msc.Data == data {
			return wi, true
		}
	}
	return nil, false
}

// focused returns the (first) window in this list that has the WinGotFocus flag set
// and the index in the list (nil, -1 if not present)
func (wl *renderWindowList) focused() (*renderWindow, int) {
	for i, fw := range wl.snapshot() {
		if fw.flags.HasFlag(winGotFocus) {
			return fw, i
		}
	}
	return nil, -1
}

// focusNext focuses on the next window in the list, after the current Focused() one.
// It skips minimized windows.
func (wl *renderWindowList) focusNext() (*renderWindow, int) {
	// Focus and its index must come from the same detached list: a removal
	// between separate lock sections can invalidate the former focused index.
	windows := wl.snapshot()
	var fw *renderWindow
	i := -1
	for index, window := range windows {
		if window.flags.HasFlag(winGotFocus) {
			fw, i = window, index
			break
		}
	}
	if fw == nil {
		return nil, -1
	}
	sz := len(windows)
	if sz == 1 {
		return nil, -1
	}

	for j := 0; j < sz-1; j++ {
		if i == sz-1 {
			i = 0
		} else {
			i++
		}
		fw = windows[i]
		if fw.SystemWindow != nil && !fw.SystemWindow.Is(system.Minimized) {
			fw.SystemWindow.Raise()
			return fw, i
		}
	}
	return nil, -1
}

// AllRenderWindows is the list of all [renderWindow]s that have been created
// (dialogs, main windows, etc).
var AllRenderWindows renderWindowList

// dialogRenderWindows is the list of only dialog [renderWindow]s that
// have been created.
var dialogRenderWindows renderWindowList

// mainRenderWindows is the list of main [renderWindow]s (non-dialogs) that
// have been created.
var mainRenderWindows renderWindowList
