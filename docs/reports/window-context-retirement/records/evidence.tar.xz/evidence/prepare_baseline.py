"""Prepare an independent committed baseline for the two-test lifecycle control."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement')
canonical=Path('/Users/dshills/Development/projects/Vellum')
sys.path.insert(0,str(canonical/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,timeout=30)
head='4da0d6b42c67f52ba3243bad6fc6cd65d34c7d8f'
assert git(canonical,'rev-parse','HEAD').decode().strip()==head and not git(canonical,'status','--porcelain','-z')
assert not r.exists()
with(p/'clone.stdout').open('xb')as out,(p/'clone.stderr').open('xb')as err:
 assert run_child(['git','clone','--no-hardlinks','--no-checkout',str(canonical),str(r)],cwd=p,env=env,stdout=out,stderr=err,timeout=120).returncode==0
subprocess.run(['git','checkout','--detach',head],cwd=r,stdout=subprocess.DEVNULL,check=True,timeout=30)
names=[n.decode()for n in git(r,'ls-files','-z').split(b'\0')if n]
sources={n:sha(r/n)for n in names}
expected=json.loads(Path('/private/tmp/vellum-macos-parent-graph-endurance/binaries.json').read_text())['source_identity']['prepared']
start=time.monotonic();argv=[sys.executable,str(r/'drivers/cogent/prepare.py')]
with(p/'baseline-prepare.stdout').open('xb')as out,(p/'baseline-prepare.stderr').open('xb')as err:
 code=run_child(argv,cwd=r/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=300,log_limit_bytes=8<<20).returncode
prepared={q.relative_to(r/'drivers/cogent/build').as_posix():sha(q)for module in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/module).rglob('*'))if q.is_file()and not q.is_symlink()}
assert code==0 and prepared==expected and all(sha(r/n)==h for n,h in sources.items())and not git(r,'status','--porcelain','-z')
v={'result':'PREPARED_EXACT_COMMITTED_BASELINE','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'source_files':sources,'prepared':prepared,'source_file_count':len(sources),'prepared_file_count':len(prepared),'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'producer_sha256':sha(Path(__file__)),'logs':{n:{'sha256':sha(p/n),'bytes':(p/n).stat().st_size}for n in ['clone.stdout','clone.stderr','baseline-prepare.stdout','baseline-prepare.stderr']},'canonical_or_frozen_sources_modified':False,'native_application_executed':False}
with(p/'baseline.json').open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v[k]for k in ['result','source_file_count','prepared_file_count','elapsed_seconds']}))
