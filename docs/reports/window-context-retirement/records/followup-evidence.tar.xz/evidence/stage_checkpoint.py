"""Stage the exact approved lifecycle fix and documentation for one provider review."""
from pathlib import Path
import datetime,hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=Path('/Users/dshills/Development/projects/Vellum');o=p/'integration'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=r,timeout=20)
review=json.loads((p/'checkpoint-source-review.json').read_text())
assert review['prism_ready']and not review['unresolved_findings']
sources=json.loads((p/'checkpoint-sources.json').read_text())['sources'];assert review['sources']==sources
assert git('rev-parse','HEAD').decode().strip()=='4da0d6b42c67f52ba3243bad6fc6cd65d34c7d8f'
assert not git('status','--porcelain','-z')
for n,h in sources.items():assert(o/n).is_file()and not(o/n).is_symlink()and sha(o/n)==h
for n,h in sources.items():
 q=r/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((o/n).read_bytes());assert sha(q)==h
subprocess.run(['git','add','--',*sources],cwd=r,timeout=20,check=True)
assert set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==set(sources)
assert all(hashlib.sha256(git('show',':'+n)).hexdigest()==h for n,h in sources.items())
subprocess.run(['git','diff','--cached','--check'],cwd=r,timeout=20,check=True)
v={'result':'STAGED_EXACT_APPROVED_WINDOW_RETIREMENT_SOURCES','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'review_sha256':sha(p/'checkpoint-source-review.json'),'producer_sha256':sha(Path(__file__))}
with(p/'stage-checkpoint.json').open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps({'result':v['result'],'files':len(sources)}))
