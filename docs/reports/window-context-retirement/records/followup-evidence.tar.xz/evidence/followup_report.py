"""Bind the one provider finding, unchanged production and tested narrow follow-up."""
from pathlib import Path
import datetime,hashlib,io,json,re,shutil,tarfile
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement');o=p/'integration'
d=o/'docs/reports/window-context-retirement/records'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
read=lambda q:json.loads(q.read_text())
provider=read(p/'prism.json');execution=read(p/'prism-execution.json');assessment=read(p/'provider-source-assessment.json')
original=read(p/'checkpoint-sources.json')['sources'];integration=read(p/'integration.json')
assert execution['exit_code']==0 and execution['error']is None and execution['sources']==execution['staged_sources']==original
assert all(execution[k]for k in ['sources_stable','staged_sources_stable','staged_diff_stable'])
coverage=provider['coverage']
assert coverage['complete']and coverage['files']==9 and coverage['llmCalls']==coverage['chunks']==1
assert coverage['reviewer']==[{'provider':'anthropic','model':'claude-sonnet-5-5'}]
assert not any([coverage['excluded'],coverage['skipped'],coverage['truncatedBytes']])
assert [f['id']for f in provider['findings']]==['835af72b05c055a4']and not provider['discarded']and not provider['suppressed']
assert assessment['result']=='SUPPORTED_BY_EXISTING_MAC_NATIVE_GUARDS'
for n,h in assessment['reviewed_prepared_source_sha256'].items():assert sha(r/'drivers/cogent/build/upstream'/n)==h
checks={}
for name in ['final-regression','final-core','final-prepare-tests']:
 v=read(p/(name+'.json'));assert v['result']=='PASS_OFFSCREEN_CHECK'and v['source_and_prepared_stable']and not v['native_gpu_or_ui_admitted']
 for channel,meta in v['logs'].items():assert sha(p/(name+'.'+channel))==meta['sha256']
 checks[name]={'receipt_sha256':sha(p/(name+'.json')),'exit_code':0,'elapsed_seconds':v['elapsed_seconds']}
assert len(re.findall(r'^--- PASS: (Test[^/\s]+) ',(p/'final-core.stdout').read_text(),re.M))==115
assert len(re.findall(r'^--- FAIL: ',(p/'negative-final-regression.stdout').read_text(),re.M))==5
prior=read(p/'history/provider-reviewed-v1/candidate.json');final=read(p/'final.json')
delta={n for n in set(prior['prepared'])|set(final['prepared'])if prior['prepared'].get(n)!=final['prepared'].get(n)}
assert delta=={'upstream/core/window_retirement_vellum_test.go'}
summary={'result':'PASS_SCOPED_FINAL_OFFSCREEN_WINDOW_RETIREMENT','final_checks':checks,'final_source_binding_sha256':sha(p/'final.json'),'baseline_pair_failed_same_show_wait':True,'negative_final_intended_regression_failures':5,'final_selected_core_passes':115,'final_selected_core_skips':0,'prior_full_adapter_race_and_vet':{'race_receipt_sha256':sha(p/'candidate-adapter.json'),'vet_receipt_sha256':sha(p/'candidate-vet.json'),'production_prepared_sources_unchanged':True,'only_prepared_delta':'core/window_retirement_vellum_test.go','rerun_after_test_only_delta':False},'native_or_gpu_executed':False,'full_mac_qualified':False}
with(p/'final-summary.json').open('x')as f:f.write(json.dumps(summary,indent=2)+'\n')
q=o/'docs/reports/window-context-retirement/README.md';text=q.read_text()
text=text.replace('Four new regressions fail against unchanged production and pass with the fix:', 'Five new regressions fail against unchanged production and pass with the fix:')
text=text.replace('reentrant native Raise that closes itself; and concurrent focus/close events.', 'reentrant native Raise that closes itself; admitted Raise concurrent with close;\nand concurrent focus/close events.')
text=text.replace('all 114 top-level tests','all 115 top-level tests').replace('four intended negative assertions','five intended negative assertions')
needle='The archive excludes private executables; scripts retain original absolute paths\nand are evidence records rather than a portable replay package.\n'
assert text.count(needle)==1
text=text.replace(needle,'The archives exclude private executables; scripts retain original absolute paths\nand are evidence records rather than a portable replay package.\n\n'
 'The single Anthropic Claude Sonnet 5.5 Prism review returned one low concern\n'
 'about native Raise after a concurrent close. Existing Mac code checks closed\n'
 'state and rechecks the native handle inside its main-queue callback, while\n'
 'destruction runs on that same owner. Source assessment is retained in\n'
 '`records/provider-source-assessment.json`; no new production change was needed.\n'
 'A deterministic concurrent-close regression was added afterward. It verifies\n'
 'core context withdrawal, not Cocoa handle lifetime. The final 115-test core\n'
 'run and five intended negative failures are in `records/followup-evidence.tar.xz`\n'
 'and `records/followup-index.json`. The two production files are byte-identical\n'
 'to the reviewed and fully adapter-tested version; adapter race/vet was not\n'
 'repeated after this test-only prepared-source delta. The final test, pin and\n'
 'documentation delta receives internal review separately from the provider\n'
 'reviewed vector.\n')
q.write_text(text)
sources={n:sha(o/n)for n in original}
resolution={'result':'PROVIDER_CONCERN_ASSESSED_EXISTING_GUARD_AND_TESTED_CONCURRENT_FOLLOWUP','observed_finding_counts':{k:len(provider[k])for k in ['findings','discarded','suppressed']},'all_findings_triaged':True,'unresolved_blocking_findings':[],'prism_report_sha256':sha(p/'prism.json'),'prism_execution_sha256':sha(p/'prism-execution.json'),'source_assessment_sha256':sha(p/'provider-source-assessment.json'),'provider_reviewed_sources':original,'final_sources':sources,'production_prepared_sources_changed':False,'second_provider_call':False,'final_delta_requires_internal_review':True,'dispositions':[{'id':'835af72b05c055a4','disposition':'EXISTING_MAIN_OWNER_NATIVE_GUARDS_VERIFIED_BY_SOURCE; CONCURRENT_CORE_CONTRACT_REGRESSION_ADDED_AND_TESTED','native_execution_qualification':False}]}
with(p/'provider-resolution.json').open('x')as f:f.write(json.dumps(resolution,indent=2)+'\n')
for n in ['prism.json','prism-execution.json','provider-resolution.json','provider-source-assessment.json','provider-source-assessment.md']:shutil.copyfile(p/n,d/n)
selected=['prism_run.py','prism.json','prism-execution.json','prism.stdout','prism.stderr','prism-staged.diff','stage_checkpoint.py','stage-checkpoint.json','checkpoint-source-review.json','checkpoint-source-review.md','checkpoint-sources.json','provider-source-assessment.json','provider-source-assessment.md','provider-resolution.json','prepare_followup.py','followup_report.py','final.json','final-prepare.stdout','final-prepare.stderr','final-regression.json','final-regression.stdout','final-regression.stderr','final-core.json','final-core.stdout','final-core.stderr','final-prepare-tests.json','final-prepare-tests.stdout','final-prepare-tests.stderr','final-summary.json','negative-final.json','negative-final-regression.json','negative-final-regression.stdout','negative-final-regression.stderr','integration.json']
members={}
files={'evidence/'+n:p/n for n in selected}
files.update({'final-sources/'+n:o/n for n in sources})
files['final-prepared/core/window_retirement_vellum_test.go']=p/'draft/core/window_retirement_vellum_test.go'
with tarfile.open(d/'followup-evidence.tar.xz','x:xz',preset=3)as archive:
 for name,f in sorted(files.items()):
  assert f.is_file()and not f.is_symlink();data=f.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0
  archive.addfile(entry,io.BytesIO(data));members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(d/'followup-evidence.tar.xz','r:xz')as archive:
 assert len(archive.getmembers())==len(members)
 for m in archive.getmembers():assert m.isfile()and sha(files[m.name])==hashlib.sha256(archive.extractfile(m).read()).hexdigest()
(d/'followup-index.json').write_text(json.dumps({'members':members,'private_executables_included':False,'portable_replay_claimed':False},indent=2)+'\n')
qualification=read(d/'qualification.json')
qualification.update(result='PREPARED_FINAL_WINDOW_RETIREMENT_PENDING_INTERNAL_REVIEW',sources=sources,summary=summary,provider_review_pending=False,internal_report_review_pending=True,final_internal_review_required=True,checkpoint_complete=False,followup_archive_sha256=sha(d/'followup-evidence.tar.xz'),followup_index_sha256=sha(d/'followup-index.json'),provider_review={'coverage':coverage,'counts':resolution['observed_finding_counts'],'resolution_sha256':sha(p/'provider-resolution.json'),'reviewed_sources':original,'final_delta_provider_reviewed':False})
(d/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
vector={f.relative_to(o).as_posix():sha(f)for f in sorted(o.rglob('*'))if f.is_file()}
with(p/'final-checkpoint-files.json').open('x')as f:f.write(json.dumps({'result':'PREPARED_FOR_FINAL_INTERNAL_REVIEW','files':vector,'final_sources':sources,'provider_reviewed_sources':original,'producer_sha256':sha(Path(__file__))},indent=2)+'\n')
print(json.dumps({'result':summary['result'],'files':len(vector),'followup_members':len(members),'final_core_passes':115,'production_delta':False,'final_internal_review_pending':True}))
