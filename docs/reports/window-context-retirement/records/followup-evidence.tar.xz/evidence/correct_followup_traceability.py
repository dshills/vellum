"""Correct which immutable archive contains the initial four negative assertions."""
from pathlib import Path
import hashlib,io,json,shutil,tarfile
p=Path(__file__).resolve().parent;o=p/'integration';d=o/'docs/reports/window-context-retirement/records'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
read=lambda q:json.loads(q.read_text())
h=p/'history/followup-traceability-v1';h.mkdir(parents=True,exist_ok=False)
for name in ['followup-evidence.tar.xz','followup-index.json','qualification.json','provider-resolution.json']:shutil.copyfile(d/name,h/name)
for name in ['final-checkpoint-files.json','provider-resolution.json']:shutil.copyfile(p/name,h/('root-'+name))
q=o/'docs/reports/window-context-retirement/README.md';shutil.copyfile(q,h/'README.md')
text=q.read_text();needle='exact baseline/candidate maps, terminal logs, five intended negative assertions,\n'
assert text.count(needle)==1
q.write_text(text.replace(needle,'exact baseline/candidate maps, terminal logs, the initial four intended negative\nassertions,\n'))
resolution=read(p/'provider-resolution.json');resolution['final_sources']['docs/reports/window-context-retirement/README.md']=sha(q)
(p/'provider-resolution.json').write_text(json.dumps(resolution,indent=2)+'\n');shutil.copyfile(p/'provider-resolution.json',d/'provider-resolution.json')
prior_index=read(d/'followup-index.json');payload={}
with tarfile.open(d/'followup-evidence.tar.xz','r:xz')as archive:
 for m in archive.getmembers():
  assert m.isfile()and m.name in prior_index['members']
  data=archive.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==prior_index['members'][m.name]['sha256'];payload[m.name]=data
assert len(payload)==44
payload['final-sources/docs/reports/window-context-retirement/README.md']=q.read_bytes()
payload['evidence/provider-resolution.json']=(p/'provider-resolution.json').read_bytes()
payload['evidence/correct_followup_traceability.py']=Path(__file__).read_bytes()
index={};next_archive=d/'followup-evidence.next.tar.xz'
with tarfile.open(next_archive,'x:xz',preset=3)as archive:
 for n,data in sorted(payload.items()):
  m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;archive.addfile(m,io.BytesIO(data));index[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with tarfile.open(next_archive,'r:xz')as archive:
 assert len(archive.getmembers())==45
 for m in archive.getmembers():assert m.isfile()and hashlib.sha256(archive.extractfile(m).read()).hexdigest()==index[m.name]['sha256']
next_archive.replace(d/'followup-evidence.tar.xz')
(d/'followup-index.json').write_text(json.dumps({'members':index,'private_executables_included':False,'portable_replay_claimed':False},indent=2)+'\n')
v=read(d/'qualification.json');v['sources']=resolution['final_sources'];v['followup_archive_sha256']=sha(d/'followup-evidence.tar.xz');v['followup_index_sha256']=sha(d/'followup-index.json');v['provider_review']['resolution_sha256']=sha(d/'provider-resolution.json')
(d/'qualification.json').write_text(json.dumps(v,indent=2)+'\n')
manifest=read(p/'final-checkpoint-files.json');manifest['final_sources']=resolution['final_sources'];manifest['files']={f.relative_to(o).as_posix():sha(f)for f in sorted(o.rglob('*'))if f.is_file()};manifest['traceability_correction_producer_sha256']=sha(Path(__file__))
(p/'final-checkpoint-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'result':'CORRECTED_ARCHIVE_TRACEABILITY_ONLY','files':len(manifest['files']),'followup_members':45,'original_archive_unchanged':sha(d/'evidence.tar.xz')==v['archive_sha256']}))
