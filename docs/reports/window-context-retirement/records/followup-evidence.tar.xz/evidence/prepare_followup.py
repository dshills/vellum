"""Restore all prepared production from pinned sources after the negative control."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/private/tmp/vellum-window-retirement')
sys.path.insert(0,str(r/'scripts'))
from child_process import run_child
from sdk_environment import child_environment
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
negative=json.loads((p/'negative-final-regression.json').read_text())
assert negative['exit_code']==1 and negative['error']is None and negative['source_and_prepared_stable']
assert(p/'negative-final-regression.stdout').read_text().count('--- FAIL: ')==5
integration=json.loads((p/'integration.json').read_text());baseline=json.loads((p/'baseline.json').read_text())
assert all(sha(r/n)==h for n,h in integration['files'].items())
names=[n.decode()for n in subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=r,timeout=15).split(b'\0')if n]
sources={n:sha(r/n)for n in names};expected=dict(baseline['prepared'])
expected.update({'upstream/'+n:h for n,h in integration['prepared_outputs'].items()})
env={**child_environment(False),'GOCACHE':'/Users/dshills/Library/Caches/go-build','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOPATH':'/Users/dshills/Development/Go','GOMAXPROCS':'2','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
argv=[sys.executable,str(r/'drivers/cogent/prepare.py')];start=time.monotonic()
with(p/'final-prepare.stdout').open('xb')as out,(p/'final-prepare.stderr').open('xb')as err:
 code=run_child(argv,cwd=r/'drivers/cogent',env=env,stdout=out,stderr=err,timeout=300,log_limit_bytes=8<<20).returncode
prepared={q.relative_to(r/'drivers/cogent/build').as_posix():sha(q)for module in ['upstream','typesetting']for q in sorted((r/'drivers/cogent/build'/module).rglob('*'))if q.is_file()and not q.is_symlink()}
assert code==0 and prepared==expected and all(sha(r/n)==h for n,h in sources.items())
v={'result':'PREPARED_EXACT_FINAL_TEST_FOLLOWUP','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':sources,'prepared':prepared,'source_file_count':len(sources),'prepared_file_count':len(prepared),'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'producer_sha256':sha(Path(__file__)),'integration_sha256':sha(p/'integration.json'),'baseline_sha256':sha(p/'baseline.json'),'logs':{n:{'sha256':sha(p/n),'bytes':(p/n).stat().st_size}for n in ['final-prepare.stdout','final-prepare.stderr']},'native_gpu_or_ui_executed':False}
with(p/'final.json').open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v[k]for k in ['result','source_file_count','prepared_file_count','elapsed_seconds']}))
