from pathlib import Path
import json,hashlib
q=Path(__file__).resolve().parent;t=Path('/private/tmp/vellum-macos-native-results-97aee13');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());d=load(q/'policy-initial-tests.json');assert d['source_sha256']==sha(t/'tools/macos-calibration/reusepolicy/policy.rs') and d['binary_sha256']==sha(q/'policy-tests') and d['exit_code']==0 and d['methods']==5
for name in ['reject-inflight-admission','reject-pending-mutation']:
 r=load(q/(name+'-receipt.json'));assert r['exit_code']!=0 and sha(q/(name+'.rs'))==r['source_sha256'] and sha(q/(name+'-stderr'))==r['stderr_sha256'] and r['expected_diagnostic'] in (q/(name+'-stderr')).read_text() and r['policy_sha256']==d['source_sha256'] and not (q/name).exists()
audit=load(q/'source-lifecycle-audit.json');assert all(sha(Path(p))==h for p,h in audit['files'].items());assert audit['original_archive_member_sha256']['src/device/life.rs']==audit['files']['/private/tmp/vellum-upload-probe/core/src/device/life.rs'];assert audit['original_archive_member_sha256']['src/device/resource.rs']==audit['files']['/private/tmp/vellum-upload-probe/core/src/device/resource.rs']
print('PASS policy5/negativecompiler2, source and binary pins, exact Core lifecycle audit; no native integration/GPU/pool-safety or release claim')
