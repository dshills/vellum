#[path="/private/tmp/vellum-macos-native-results-97aee13/tools/macos-calibration/reusepolicy/policy.rs"] mod policy;
use std::num::NonZeroU64;
fn main() { let nz=|n| NonZeroU64::new(n).unwrap(); let mut pool=policy::Pool::new(8,32); let mut pending=policy::Upload::new(nz(1),nz(8),vec![0u8;8]).submit(nz(1)); let _ = pending.resource_mut(); }
