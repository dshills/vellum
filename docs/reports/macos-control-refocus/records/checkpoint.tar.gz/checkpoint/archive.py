from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;F=W.parent/'macos-control-refocus-4d0b5f7';S=W.parent/'macos-control-reenable-4d0b5f7';T=Path('/private/tmp/vellum-macos-native-results-97aee13');R=T/'docs/reports/macos-control-refocus/records'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert read(W/'internal-prism-disposition.json')['approved']and not read(W/'internal-prism-disposition.json')['unresolved_findings']
files={}
def add(path,name):
 p=Path(path);assert p.is_file()and not p.is_symlink()and name not in files and not name.startswith('/')and '..'not in Path(name).parts;files[name]=p
for root,prefix in [(F,'refocus-attempt'),(S,'styling-attempt'),(W,'final-attempt')]:
 for n in ['run.py','plan.json','admission.json','result.json','stop-live']:add(root/n,prefix+'/'+n)
 for p in (root/'case').iterdir():
  if p.is_file():add(p,prefix+'/case/'+p.name)
for n in ['build','reenable-negative','reenable-positive','driver-race','fix-vet','fix-build','focused-negative','prefix-diagnostic','prefix-diagnostic-v2','prefix-diagnostic-v3','multiclick-negative','multiclick-positive','multiclick-positive-v2','driver-race-final','final-vet','final-build']:
 add(F/(n+'.json'),'checks/'+n+'.json')
 for p in (F/n).iterdir():
  if p.is_file():add(p,'checks/'+n+'/'+p.name)
for n in ['check_fix.py','negative-check.py','check_focus_fix.py','check_prefix.py','check_multiclick.py','original-driver.go','style-fixed-driver.go','original-controls.go','focused-reenable-diagnostic.go','prefix-diagnostic.go','prefix-diagnostic-invalid-window.go','prefix-diagnostic-invalid-config.go','multiclick-counterfactual-test.go','multiclick-selection-test-v1.go','negative-overlay.json','fix-overlay.json','focus-negative-overlay.json','focus-fix-overlay.json','prefix-overlay.json','multiclick-negative-overlay.json','multiclick-overlay.json','internal-fix-review.json','internal-multiclick-review.json']:
 add(F/n,'diagnostics/'+n)
for n in ['machine.json','finish_docs.py','review-paths.json','review-scope.json','final-scope.json','internal-pre-prism-review.json','prism_review.py','prism-rules.json','prism-staged.diff','prism-command.json','prism.json','prism.stdout','prism.stderr','internal-prism-disposition.json','archive.py','ready_commit.py','post_promotion.py']:
 add(W/n,'checkpoint/'+n)
for n in read(W/'final-scope.json')['paths']:add(T/n,'source/'+n)
for n in ['core/flags.go','styles/style.go','LICENSE']:
 add(T/'drivers/cogent/build/upstream'/n,'context/'+n)
origins={n:str(p)for n,p in sorted(files.items())};(W/'member-origins.json').write_text(json.dumps(origins,indent=2)+'\n');add(W/'member-origins.json','checkpoint/member-origins.json')
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(files.items())};expanded=sum(z['bytes']for z in manifest.values());assert len(files)<=256 and expanded<=32<<20 and all(z['bytes']<=10<<20 for z in manifest.values())
assert not(R/'checkpoint.tar.gz').exists()
with(R/'checkpoint.tar.gz').open('xb')as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='')as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT)as out:
 for n,p in sorted(files.items()):
  data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;out.addfile(m,io.BytesIO(data))
assert(R/'checkpoint.tar.gz').stat().st_size<=8<<20
seen=set()
with tarfile.open(R/'checkpoint.tar.gz','r:gz')as check:
 for m in check:
  assert m.isfile()and m.name in manifest and m.name not in seen and m.size==manifest[m.name]['bytes'];data=check.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256'];seen.add(m.name)
assert seen==set(manifest)
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');r={'members':len(files),'expanded_bytes':expanded,'archive_bytes':(R/'checkpoint.tar.gz').stat().st_size,'archive_sha256':sha(R/'checkpoint.tar.gz'),'manifest_sha256':sha(R/'manifest.json'),'binaries_included':False,'physical_input_verified':False,'native_record':'PASS57/21','full_mac_complete':False};(R/'archive.json').write_text(json.dumps(r,indent=2)+'\n');(W/'archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
