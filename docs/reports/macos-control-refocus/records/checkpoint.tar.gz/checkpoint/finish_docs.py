from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;F=W.parent/'macos-control-refocus-4d0b5f7';S=W.parent/'macos-control-reenable-4d0b5f7';T=Path('/private/tmp/vellum-macos-native-results-97aee13')
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(W/'result.json');assert r['result']=='PASS_NATIVE_CONTROLS'and r['summary']['inputs']==57 and r['summary']['observations']==21
report=T/'docs/reports/macos-control-refocus';(report/'records').mkdir(parents=True,exist_ok=False)
(report/'README.md').write_text('''# Retained disabled styling and actual multi-click focus

The complete ordinary Selector/NumberField native record now passes: **57 Go FIFO
inputs and 21 independently expected observations**. The source includes two Go
adapter fixes over `4d0b5f7`; the consumer, validator, expected models and input
sequence are unchanged. This qualifies that named native routing record in the
controlled configuration below. Full catalogue/M2, physical/human M5, performance,
resource/endurance, release and full Mac completion remain open.

The first fix refreshes a retained widget after its effective Disabled state
changes, after control synchronization and before synchronizing descendants.
An ancestor update could previously style children using their old Disabled
flags; clearing the flags later left read-only dimensions and Focusable ability
stale when the child's own descriptor had not changed. Passive widgets are
included. Re-enabling a parent preserves explicitly disabled children and widget
identities; it does not request focus or invoke Change.

The second fix restores actual scene focus before ordinary double/triple-click
handlers on managed text and numeric fields. A disabled field can retain a stale
visual Focused flag after an ordinary key moves actual focus. Native multi-click
handlers use that flag and consume the event without focusing the field. The Go
adapter's first-phase handler checks actual ContainsFocus, enabled/read-only state
and Focusable, then calls SetFocus only when needed. It does not handle the event,
change values or replace ordinary word/all selection.

## Evidence

- The original driver fails the two inherited NumberField/TextField focusability
  regressions; direct-disable controls pass. The styling fix passes all four
  through three cycles, plus passive Label styling and own-disabled preservation.
- A gallery-shaped software diagnostic at 729x658 and DPI162 reproduces the
  remaining actual-focus failure for rapid clicks, while advancing the manual
  clock beyond the double-click interval passes. A generic already-focused
  fixture did not reproduce it and is retained as diagnostic evidence only.
- The original multi-click handlers fail all four rapid double/triple field
  cases; all four separated controls pass. The final source passes eight cases,
  actual word/all selection, no model proposal during refocus and exactly one
  subsequent numeric/text edit. Together with the five disabled-state cases,
  thirteen focused subcases pass under race.
- The final complete driver-root package race suite, driver/gallery vet and
  native gallery build pass. No Core/dependency patch changes; stage83's full
  6267 prepared-file vectors remain identical.
- The final native process passes all 57 inputs/21 observations, including
  numeric rejection, invalid/corrected/clamped values, disabled target refusal,
  re-enabled input, outside-release consumption, exactly-once callbacks, closing
  with an actual menu open and stale original-reference input refusal. The
  independent validator verifies the complete record, not a successful prefix.

Two earlier fresh 57-input attempts in this checkpoint remain **failed and
sealed**. Both reach 54 input receipts/19 source-asserted observations and fail
`reenabled-step target not actually focused`. The styling-only native case restores
correct widths but does not restore actual focus. They are not passes. The four
older 49-input failures remain in the preceding
[checkpoint](../macos-native-controls/README.md). No sealed case is reset or retried;
each changed-source case has a distinct plan/admission/lease/stop scope.

The first software prefix fixtures refused a missing title and the manual
adapter's explicit font/color requirements before input. Those failures remain.
A first post-focus software assertion expected an append after a word/all
selection; the result correctly replaced the selected word/all text. That failed
assertion and original bytes remain; the final test explicitly expects `alpha x`
for word replacement and `x` for whole-field replacement. No native oracle changes.

## Configuration and limits

Go1.25.6 Darwin/ARM64, CPU-scene native routing, controlled GOMAXPROCS=2 and the
retained SDK's pinned native archive `786aaad8...` are explicit. This is current
Go source/stage83 over that library, not a refreshed SDK or qualification of the
source checkout's other default native archive. The retained SDK remains exactly
7880 files with whole-vector SHA256
`4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26`.

Every native process has complete logs, stable pins and confirmed owned group
absence. Final public session state is Closed, zero pending and zero live windows;
this does not prove Cocoa deallocation or classify the separate hidden TUINS
window. No OS input operator, physical input, IME/VoiceOver, preferences, clipboard,
display transition, presentation/performance, signing or public release is used.
No full Mac gate closes.

Source and result reviews are retained with one scoped Anthropic Claude Sonnet5.5
Prism checkpoint. [Structured results](records/results.json) and the bounded
[raw evidence archive](records/checkpoint.tar.gz) retain successes, failures and
counterfactuals. Continue the remaining named native catalogue scenarios, then the
unchanged M3–M7 delivery gates.
''')
checks={n:{'exit_code':read(F/(n+'.json'))['exit_code'],'seconds':read(F/(n+'.json'))['seconds'],'receipt_sha256':sha(F/(n+'.json'))}for n in ['reenable-negative','reenable-positive','focused-negative','prefix-diagnostic','prefix-diagnostic-v2','prefix-diagnostic-v3','multiclick-negative','multiclick-positive','multiclick-positive-v2','driver-race','driver-race-final','final-vet','final-build']}
results={'base_commit':'4d0b5f76319809300ce8a5057d2e8a1ab5e77884','final_native':r,'earlier_native_attempts':[{'scope':x.name,'result':read(x/'result.json'),'inputs':54,'source_asserted_observations':19}for x in [F,S]],'checks':checks,'prepared_files':6267,'sdk_unchanged':True,'sdk_files':7880,'sdk_vector_sha256':'4ce384e5873e00f148b72458ead131f42d4b3d7a464980423cb2f01881e94f26','physical_input_verified':False,'closed_full_mac_gates':[],'goal_complete':False}
(report/'records/results.json').write_text(json.dumps(results,indent=2)+'\n')
link='[retained-state and multi-click checkpoint](../docs/reports/macos-control-refocus/README.md)'
paragraph='''The subsequent '''+link+''' completes the unchanged native
Selector/NumberField record: 57 routed inputs and 21 independently expected
observations. Go adapter fixes restore inherited disabled styling and actual
focus before ordinary double/triple-click handling, preserving selection and
exactly-once edits. Two preceding 57-input cases remain failed at 54 receipts/19
source-asserted observations; the styling-only case did not fix actual focus.
Controlled Go2/SDK786a CPU-scene routing is qualified for this record only. Full
catalogue/M2, physical/human M5 and M3–M7 remain open; no SDK refresh occurs.

'''
for name,marker in [('macos-delivery.md','## Finish line'),('macos-completion.md','## M1 SDK command ownership')]:
 p=T/'specs'/name;s=p.read_text();assert marker in s;s=s.replace(marker,paragraph+marker,1);p.write_text(s)
p=T/'specs/controls.md';s=p.read_text();marker='`Disabled` blocks model changes, including descendants of disabled managed\ncontainers. Native styles reflect that disabled state.';assert marker in s;s=s.replace(marker,marker+''' Reconciliation refreshes
retained descendants when effective disabled state changes, even when their own
descriptors are unchanged. Re-enabling an ancestor preserves a child's own
Disabled state. Text/numeric multi-clicks restore actual focus when eligible
before ordinary word/all selection; they do not propose a value just to focus.''',1);p.write_text(s)
p=T/'specs/control-acceptance.md';s=p.read_text();marker='The remaining native catalogue work is:';assert marker in s;s=s.replace(marker,paragraph+marker,1).replace('1. Run the corrected 57-input native gallery record and complete\n   ordinary Selector popup and NumberField typed,\n   pointer and keyboard edits, including rejection/disabled behavior. The\n   deterministic keyboard regression does not qualify an actual desktop popup.\n2. Exercise','1. Exercise').replace('3. Complete real keyboard','2. Complete real keyboard');p.write_text(s)
p=T/'drivers/cogent/cmd/gallery/README.md';s=p.read_text();marker='Current status:';s=s[:s.index(marker)]+'''Current status: the complete 57-input/21-observation native record passes with
the inherited-state and actual multi-click focus fixes. Six preceding attempts
remain failed/sealed. This is automated native Go routing in the controlled
Go2/SDK786a CPU-scene configuration; physical/OS input and full Mac acceptance
remain open. See the [result](../../../../docs/reports/macos-control-refocus/README.md).
''';p.write_text(s)
p=T/'docs/reports/macos-native-controls/README.md';s=p.read_text();first=s.index('\n\n');s=s[:first]+'''\n\nHistorical checkpoint: its four attempts remain failed. The subsequent
[retained-state and multi-click checkpoint](../macos-control-refocus/README.md)
passes the corrected 57-input/21-observation record after two further product
fixes. The pending statements below describe this earlier checkpoint.'''+s[first:];p.write_text(s)
paths=['drivers/cogent/controls.go','drivers/cogent/driver.go','drivers/cogent/disabled_state_offscreen_test.go','drivers/cogent/reenable_offscreen_test.go','drivers/cogent/field_multiclick_offscreen_test.go','docs/reports/macos-control-refocus/README.md','docs/reports/macos-control-refocus/records/results.json','specs/controls.md','specs/control-acceptance.md','specs/macos-completion.md','specs/macos-delivery.md','drivers/cogent/cmd/gallery/README.md','docs/reports/macos-native-controls/README.md']
(W/'review-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'source_and_doc_paths':len(paths),'final_native':r['summary']}))
