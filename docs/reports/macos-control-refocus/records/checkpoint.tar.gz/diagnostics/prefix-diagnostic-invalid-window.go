//go:build offscreen
package cogent
import(
 "testing"
 "time"
 "image/color"
 "fmt"
 "cogentcore.org/core/core"
 "cogentcore.org/core/events"
 "cogentcore.org/core/events/key"
 "github.com/dshills/vellum/app"
 "github.com/dshills/vellum/ui"
)
func TestNativeControlDisabledPrefixDiagnostic(t *testing.T){
 for _,separated:=range []bool{false,true}{t.Run(fmt.Sprint("separated=",separated),func(t *testing.T){
  enabled:=true;number:=float32(99);calls:=0
  a,err:=app.New(app.Config{});if err!=nil{t.Fatal(err)};defer a.Close()
  view:=func()ui.Node{return ui.Node{ID:"control-catalogue",Kind:ui.Column,Grow:true,Style:ui.Style{Gap:ui.Some(float32(12))},Children:[]ui.Node{
   {ID:"heading",Kind:ui.Label,Text:"Selector and numeric field acceptance"},
   {ID:"fields",Kind:ui.FormGroup,Text:"Ordinary controls",Disabled:!enabled,Children:[]ui.Node{
    {ID:"selection",Kind:ui.Selector,SelectedID:"basic",Options:[]ui.Option{{ID:"basic",Label:"Basic"},{ID:"advanced",Label:"Advanced"}},Change:func(ui.ChangeEvent){}},
    {ID:"number",Kind:ui.NumberField,Number:number,Numeric:ui.Numeric{Min:0,Max:100,Step:1},Change:func(e ui.ChangeEvent){number=e.Number;calls++}},
   }},
   {ID:"outside",Kind:ui.Button,Text:"Outside action"},
  }}}
  if err=a.Open(app.Window{ID:"one",Width:729,Height:658,View:view});err!=nil{t.Fatal(err)}
  cfg:=manualConfig(t,7);cfg.LogicalDPI=162;cfg.Theme=ui.Theme{Default:ui.Style{Typography:ui.Some(ui.Typography{Size:16}),Foreground:ui.Some(color.NRGBA{R:32,G:36,B:42,A:255})},Kinds:map[ui.Kind]ui.Style{ui.Column:{Gap:ui.Some(float32(8))}}}
  m,err:=NewManual(testContext,a,cfg);if err!=nil{t.Fatal(err)};defer m.Close(testContext);unitSettle(t,m);w:=m.implementation.find("one")
  click:=func(){t.Helper();if separated{if _,err:=cfg.Clock.Advance(core.TimingSettings.DoubleClickInterval+time.Millisecond);err!=nil{t.Fatal(err)}};b:=findRecord(w.state.root,"number").widget.AsWidget().Geom.TotalBBox;for _,typ:=range []events.Types{events.MouseDown,events.MouseUp}{if err:=m.Input(testContext,ManualInput{Window:"one",WindowIncarnation:w.incarnation,Type:typ,Button:events.Left,Position:b.Min.Add(b.Size().Div(2))});err!=nil{t.Fatal(err)};unitSettle(t,m)}}
  keyUp:=func(){t.Helper();if err:=m.Input(testContext,ManualInput{Window:"one",WindowIncarnation:w.incarnation,Type:events.KeyChord,Code:key.CodeUpArrow});err!=nil{t.Fatal(err)};unitSettle(t,m)}
  click();if !findRecord(w.state.root,"number").widget.AsWidget().ContainsFocus(){t.Fatal("initial number not focused")}
  if err=a.Do(func(){enabled=false;_ = a.Invalidate("one")});err!=nil{t.Fatal(err)};unitSettle(t,m);keyUp();if calls!=0||number!=99{t.Fatal("disabled key mutated model")}
  if err=a.Do(func(){enabled=true;_ = a.Invalidate("one")});err!=nil{t.Fatal(err)};unitSettle(t,m);click()
  if !findRecord(w.state.root,"number").widget.AsWidget().ContainsFocus(){t.Fatal("number lost actual focus after disabled prefix",number,calls)}
  keyUp();if number!=100||calls!=1{t.Fatal("step after native-shaped prefix",number,calls)}
 })}
}
