"""One reviewed native run of the effective-disabled fix; distinct from sealed cases."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;F=W.parent/'macos-control-refocus-4d0b5f7'
s=importlib.util.spec_from_file_location('committed_controls_guard',F/'run.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b);h=b.h;g=b.g;sha=b.sha;need=b.need;read=b.read;C=b.C;T=b.T;SDK=b.SDK
CHANGED=['drivers/cogent/driver.go'];NEW=['drivers/cogent/disabled_state_offscreen_test.go','drivers/cogent/reenable_offscreen_test.go']
def candidate():
 need(b.git(T,'rev-parse','HEAD').decode().strip()==b.HEAD,'candidate base');need(b.git(T,'diff','--name-only').decode().splitlines()==CHANGED,'only expected tracked fix');need(set(b.git(T,'ls-files','--others','--exclude-standard').decode().splitlines())==set(NEW),'only expected new regressions');need(not b.git(T,'diff','--cached','--name-only'),'unstaged exact candidate')
 names=b.git(T,'ls-files','-z').decode().split('\0')[:-1]+NEW;return{n:sha(T/n)for n in names}
def baseline():
 a=b.source(C);t=candidate();need(set(t)==set(a)|set(NEW)and all(t[n]==z for n,z in a.items()if n not in CHANGED),'unchanged other source');p=b.prepared(C);need(b.prepared(T)==p and len(p)==6267,'unchanged stage83')
 sdk=read(b.P.parent/'macos-native-workspace-594bd37/native-v5/plan.json')['sdk_files'];need(b.vector(SDK)==sdk,'retained SDK unchanged');mapping=read(F/'fix-overlay.json')['Replace']
 for original,replacement in mapping.items():
  rel=Path(original).relative_to(SDK)
  if rel.as_posix().startswith('examples/'):continue
  need(Path(replacement).read_bytes()==(T/rel).read_bytes(),'current candidate overlay '+str(rel))
 for n,z in p.items():
  original=SDK/'drivers/cogent/build'/n;need(sha(mapping.get(str(original),str(original)))==z,'whole prepared correspondence')
 return a,t,p,sdk

def prepare():
 need(not(W/'plan.json').exists()and not(W/'case').exists(),'fresh scope');a,t,p,sdk=baseline();review=read(F/'internal-fix-review.json');need(review['approved']and not review['unresolved_findings']and all(sha(k)==z for k,z in review['inputs'].items()),'exact internal fix review')
 pins={}
 for name in ['reenable-positive','driver-race','fix-vet','fix-build']:
  r=read(F/(name+'.json'));need(b.passing(r),'owned prerequisite '+name);need(all(sha(k)==z for k,z in r['source_pins'].items()),'unchanged prerequisite sources');pins.update(r['source_pins']);pins[str(F/(name+'.json'))]=sha(F/(name+'.json'))
  for stream,info in r['logs'].items():q=F/name/stream;need(q.stat().st_size==info['bytes']and sha(q)==info['sha256'],'complete raw prerequisite');pins[str(q)]=sha(q)
 paths=[Path(__file__),F/'run.py',F/'internal-fix-review.json',Path(b.validator.__file__),h.GO,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]
 pins.update({str(q):sha(q)for q in paths});now=datetime.datetime.now(datetime.timezone.utc)
 plan={'head':b.HEAD,'canonical_source':a,'candidate_source':t,'prepared':p,'sdk':str(SDK),'sdk_files':sdk,'pins':pins,'binary':{'path':str(F/'gallery-fix'),'sha256':sha(F/'gallery-fix')},'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'runtime_options':{k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']},'watchdog_seconds':120,'stream_limit_bytes':4<<20,'scope':'One fresh corrected57-input/21-observation native CPU-scene controls record with the effective-disabled reconciliation fix and2new regression files over4d0b5f7. Prior four49-input and one57-input cases remain immutable/sealed/failed. No consumer/validator/model expectation changes. Source-stable whole C/T/prepared/SDK/binary boundaries, shared lease, one attempt and terminal seal, owned group retirement. GOMAXPROCS2/native library786a configuration. No physical/OS input, IME/VoiceOver, clipboard/preferences, display/performance/Cocoa deallocation/full catalogue or Mac completion qualification, SDK refresh, sealed placement operator or public release.'}
 (W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(W/'plan.json'),'native_executed':False}))

def run():
 raw=(W/'plan.json').read_bytes();araw=(W/'admission.json').read_bytes();p=json.loads(raw);a=json.loads(araw);stop=W/'stop-live';need(a['approved']and a['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact plan admission');need(not stop.exists()and not(W/'case').exists()and not(W/'result.json').exists(),'fresh one-case scope')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==araw and all(sha(k)==z for k,z in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  need(not stop.exists()and stable(),'stop/pin boundary');need(baseline()==(p['canonical_source'],p['candidate_source'],p['prepared'],p['sdk_files']),'whole source/prepared/SDK boundary');need({k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']}==p['runtime_options'],'runtime options')
 d={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('reenable controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline');profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(SDK))+'))'
   r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],'-control-native-check'],SDK/'drivers/cogent',W/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);d['run']=r;d['native_executed']=r['created'];need(b.passing(r),'owned native result');d['summary']=b.validator.validate((W/'case/stdout').read_bytes(),(W/'case/stderr').read_bytes());boundary();need(lease.held(),'lease through cleanup');d['result']='PASS_NATIVE_CONTROLS'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error','summary']}))
 if d['error']:sys.exit(1)
if __name__=='__main__':need(sys.argv[1:]in [['prepare'],['run']],'fixed phase');{'prepare':prepare,'run':run}[sys.argv[1]]()
