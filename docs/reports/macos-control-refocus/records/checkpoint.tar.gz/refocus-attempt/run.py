"""Fresh committed-source native controls scope; never retries a sealed case."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,signal,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parent/'macos-control-popup-a1f92bb';I=P/'candidate';C=Path('/Users/dshills/Development/projects/Vellum');T=Path('/private/tmp/vellum-macos-native-results-97aee13');HEAD='4d0b5f76319809300ce8a5057d2e8a1ab5e77884'
s=importlib.util.spec_from_file_location('controls_sdk_guard',W.parent/'macos-sdk-stage0079-abe67c6-cache-v2/run.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
sys.path.insert(0,str(T/'scripts'));from child_process import run_child
sys.path.insert(0,str(P));import validate_refocus as validator
SDK=Path(json.loads((P/'scope.json').read_text())['sdk']);sha=h.sha
need=h.need
read=lambda p:json.loads(Path(p).read_bytes())
def git(root,*args):return run_child(['git',*args],cwd=root,capture_output=True,check=True,timeout=30).stdout
def vector(root):
 out={}
 for p in root.rglob('*'):
  need(not p.is_symlink(),'no symlinks in vector')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def source(root):
 need(git(root,'rev-parse','HEAD').decode().strip()==HEAD and not git(root,'status','--porcelain'),'clean committed source')
 names=git(root,'ls-files','-z').decode().split('\0')[:-1];need(len(names)==5370,'tracked count')
 return {n:sha(root/n)for n in names}
def prepared(root):return {m+'/'+n:z for m in ['upstream','typesetting']for n,z in vector(root/'drivers/cogent/build'/m).items()}
def passing(r):return r['created']and r['exit_code']==0 and r['error']is None and not r['observation_errors']and r['logs_complete']and r['pins_stable']and not r['stop_at_exit']and r['owned']['terminal']and r['owned']['group_absent']and not r['owned']['errors']
def baseline():
 a=source(C);need(source(T)==a,'C/T tracked parity');b=prepared(C);need(prepared(T)==b and len(b)==6267,'stage83 prepared parity')
 expected=read(W.parent/'macos-native-workspace-594bd37/native-v5/plan.json')['sdk_files'];need(vector(SDK)==expected,'retained SDK unchanged')
 mapping=read(I/'overlay.json')['Replace'];count=0
 for original,replacement in mapping.items():
  rel=Path(original).relative_to(SDK)
  if rel.as_posix().startswith('examples/'):continue
  need(Path(replacement).read_bytes()==(C/rel).read_bytes(),'current adopted overlay '+str(rel));count+=1
 need(count==31,'current31 overlay mappings')
 for n,z in b.items():
  original=SDK/'drivers/cogent/build'/n;need(sha(mapping.get(str(original),str(original)))==z,'whole prepared overlay '+n)
 for name in ['gallery-tests-refocus','number-refocus-v1','consumer-vet-v6','validation-refocus-controls-v2']:
  r=read(P/(name+'.json'));need(passing(r),'source prerequisite '+name)
  for stream,info in r['logs'].items():need((P/name/stream).stat().st_size==info['bytes']and sha(P/name/stream)==info['sha256'],'raw prerequisite '+name)
 need(read(P/'internal-prism-disposition.json')['approved']and read(P/'internal-archive-commit-review.json')['commit_ready'],'source reviews')
 return a,b,expected

def build():
 need(not(W/'build.json').exists()and not(W/'gallery').exists(),'fresh build')
 a,b,sdk=baseline();pins={str(p):sha(p)for p in [*I.rglob('*'),Path(__file__),Path(validator.__file__),Path(h.__file__),h.GUARD,h.GO]if p.is_file()}
 env={'PATH':str(h.GO.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':os.environ['HOME'],'GOPATH':'/Users/dshills/Development/Go','GOMODCACHE':'/Users/dshills/Development/Go/pkg/mod','GOWORK':'off','GOENV':'off','GOTOOLCHAIN':'local','GOFLAGS':'-mod=readonly','GOMAXPROCS':'2','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','CGO_LDFLAGS_ALLOW':'^-Wl,-rpath,@executable_path/native$'}
 profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(SDK))+'))'
 argv=['/usr/bin/sandbox-exec','-p',profile,'/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],str(h.GO),'build','-p=1','-overlay='+str(I/'overlay.json'),'-o',str(W/'gallery'),'./cmd/gallery']
 r=g.execute(argv,SDK/'drivers/cogent',W/'build',lambda:False,lambda:all(sha(p)==z for p,z in pins.items()),timeout=420,limit=4<<20)
 r['source_pins']=pins;r['source_head']=HEAD;r['native_executed']=False
 if passing(r):r['binary']={'path':str(W/'gallery'),'sha256':sha(W/'gallery')}
 (W/'build.json').write_text(json.dumps(r,indent=2)+'\n');need(passing(r),'owned exact committed-source build');need(baseline()==(a,b,sdk),'postbuild source/SDK boundary');print(json.dumps({'build':'PASS','binary':r['binary'],'seconds':r['seconds']}))

def prepare():
 need(not(W/'plan.json').exists()and not(W/'case').exists(),'fresh native scope');a,b,sdk=baseline();r=read(W/'build.json');need(passing(r)and r['source_head']==HEAD and sha(r['binary']['path'])==r['binary']['sha256'],'exact fresh binary')
 need(all(sha(p)==z for p,z in r['source_pins'].items()),'build pins unchanged')
 paths=[Path(__file__),Path(validator.__file__),P/'validation_refocus_controls.py',P/'internal-prism-disposition.json',P/'internal-archive-commit-review.json',P/'post-promotion.json',W/'build.json',Path(h.__file__),h.GUARD,h.GO,T/'scripts/child_process.py',T/'scripts/sdk_environment.py',Path('/private/tmp/vellum-empty-text-native-isolated-v2/live_lease.py')]+[P/(n+'.json')for n in ['gallery-tests-refocus','number-refocus-v1','consumer-vet-v6','validation-refocus-controls-v2']]
 pins={**r['source_pins'],**{str(p):sha(p)for p in paths}}
 now=datetime.datetime.now(datetime.timezone.utc)
 p={'head':HEAD,'source':a,'prepared':b,'sdk':str(SDK),'sdk_files':sdk,'pins':pins,'binary':r['binary'],'launch_deadline_utc':(now+datetime.timedelta(minutes=30)).isoformat(),'watchdog_seconds':120,'stream_limit_bytes':4<<20,'gomaxprocs':'2','runtime_options':{k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']},'scope':'One fresh corrected57-input/21-observation native CPU-scene Selector/NumberField record from clean4d0b5f7. Four previous49-input attempts remain immutable/sealed. Reuse ordinary public constructors and DesktopSession Go FIFO; actual popup pointer/keyboard/rejection/Escape/outside-release consumption, typed/invalid/corrected/clamped/rejected/disabled/reenabled numeric controls, exact callback counts and original-reference/session retirement. Four authored public pointer refocus pairs after numeric Enter. Independent validator with17 prior synthetic controls. Controlled GOMAXPROCS2 and retained native library786a; no performance, presentation, physical/OS input, IME/VoiceOver, display transition, Cocoa deallocation or full catalogue/M2-M7 acceptance claim. Owner-posted enabled/reject flags are fixture setup only. Shared exclusive live lease; source/prepared/SDK/binary pins before/after, network/SDK writes denied, owned process group retired, one attempt then terminal seal. No OS preferences/input-source/clipboard changes, new OS input operator, sealed-placement retry/reset, SDK refresh or public release.'}
 (W/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'plan_sha256':sha(W/'plan.json'),'head':HEAD,'native_executed':False}))

def run():
 raw=(W/'plan.json').read_bytes();araw=(W/'admission.json').read_bytes();p=json.loads(raw);ad=json.loads(araw);stop=W/'stop-live'
 need(ad['approved']and ad['plan_sha256']==hashlib.sha256(raw).hexdigest(),'exact independently admitted plan');need(not stop.exists()and not(W/'case').exists()and not(W/'result.json').exists(),'one fresh case')
 def stable():return(W/'plan.json').read_bytes()==raw and(W/'admission.json').read_bytes()==araw and all(sha(k)==z for k,z in p['pins'].items())and sha(p['binary']['path'])==p['binary']['sha256']
 def boundary():
  need(not stop.exists()and stable(),'stable inputs/no stop');need(source(C)==source(T)==p['source']and prepared(C)==prepared(T)==p['prepared']and vector(SDK)==p['sdk_files'],'whole source/prepared/SDK parity');need({k:g.child_environment(True).get(k)for k in ['GOMEMLIMIT','GORACE']}==p['runtime_options'],'runtime options')
 d={'result':'INCOMPLETE','native_executed':False,'error':None,'closed_mac_gates':[]}
 def interrupted(signum,frame):raise InterruptedError('controls controller signal '+str(signum))
 old=signal.signal(signal.SIGTERM,interrupted)
 try:
  with g.LiveLease()as lease:
   boundary();need(lease.held()and datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(p['launch_deadline_utc']),'lease/deadline')
   profile=h.PROFILE+'(deny file-write* (subpath '+json.dumps(str(SDK))+'))'
   r=g.execute(['/usr/bin/sandbox-exec','-p',profile,p['binary']['path'],'-control-native-check'],SDK/'drivers/cogent',W/'case',lambda:stop.exists(),stable,timeout=p['watchdog_seconds'],limit=p['stream_limit_bytes']);d['run']=r;d['native_executed']=r['created'];need(passing(r),'owned native result')
   d['summary']=validator.validate((W/'case/stdout').read_bytes(),(W/'case/stderr').read_bytes());boundary();need(lease.held(),'lease through cleanup');d['result']='PASS_NATIVE_CONTROLS'
 except BaseException as e:d.update(result='FAILED_OR_CANCELED',error={'type':type(e).__name__,'message':str(e)})
 finally:
  signal.signal(signal.SIGTERM,old);stop.touch();d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(W/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in ['result','native_executed','error','summary']}))
 if d['error']:sys.exit(1)
if __name__=='__main__':
 need(sys.argv[1:]in [['build'],['prepare'],['run']],'fixed phase');{'build':build,'prepare':prepare,'run':run}[sys.argv[1]]()
